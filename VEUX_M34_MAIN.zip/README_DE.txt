VEUX M34 – BQ-Initialisierung: alle Schreibfehler und fehlgeschlagene IRQ-Wiederherstellung – NOFLASH
Basis: gruener M33-Lauf 43739581882 / Commit 60fc13b38cb71e108407eaf8bd4e9a4c97837251.

UPLOAD AM SMARTPHONE
1. VEUX_M34_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M34_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden unveraendert aus festen Commits authentifiziert geladen.

M33 AUSGEWERTET
Alle 32 Artefakte heruntergeladen und SHA-256/ZIP-CRC geprueft: 920 Dateien,
848 Textdateien, 222 JSON-Dateien, 36.058.249 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M33 unabhaengig geprueft:
tatsaechliche Quellen, LLVM-Objekt/CFI-Kommando, verlinkter Shutdown, 40 erfolgreiche
make-Aufrufe, eingebettete Konfiguration in Image/vmlinux und unveraenderte
Exporttabelle. Import-CRCs neu berechnet: 1.423 passend, keine CRC-Abweichung,
kein fehlender Export und 37 passende Module. Boot.img und AK3 byteidentisch aus
den gepinnten Referenzen rekonstruiert; AVB und Stock-Ramdisk/Paar geprueft.
Alle Archivberichte sind ausgewertet; tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M33. Berichte: Reports/RUN43739581882_32_ARTEFAKTE.zip und
Reports/M33_INDEPENDENT_VERIFICATION.json. Device Pass bleibt NEIN.

M34 REPARATUR
init_device ignoriert bisher mehrere Registerfehler und meldet danach Erfolg.
M34 prueft alle 15 Initialisierungsstufen fuer beide Chips und gibt den ersten
Fehler unveraendert zurueck. Danach werden keine abhaengigen Schritte ausgefuehrt.
Die bereits erfolgreich ausgefuehrten Teiloperationen werden nicht zurueckgerollt;
ein physischer Busfehler beweist nicht den wirklichen Chipzustand.
Der IRQ-Fehlerpfad prueft zusaetzlich Chip-Reset und anschliessende Initialisierung.
Bei einem Fehler endet die Wiederherstellung vor weiteren Reset-/Init-Schritten
und vor der abschliessenden Ladetyp-Auswertung. Beginnt der Shutdown waehrend
der bestehenden 5-ms-Wartezeit, startet keine weitere Initialisierung.
Die erfolgreichen Registerwerte, Reihenfolgen, beide getrennten Reset-Pfade bei
gleichzeitig gesetzten Fehlerbits sowie die bisherigen cfg-/curr_flag-Zuweisungen
bleiben erhalten. Keine Strom-/Spannungsschwelle, keine 5-V-VINDPM-Regel und
keine Defconfig-Aenderung. Ausschliesslich init_device und charger_irq_workfunc
sind gegenueber dem gepinnten M33 veraendert. Der gesamte Rest einschliesslich
Shutdown, Mutex-/Ready-Gates, Sysfs-Pufferkorrektur und M30/M31-Lese-/Schreibkoerpern
bleibt byteidentisch. Beide Header bleiben unveraendert; bq2589x_iio.h bleibt
1.763 Bytes ohne EOF-Zeilenumbruch.

PRUEFUNGEN
33 M34-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Der neue native Test fuehrt echte Init-/IRQ-Funktionen und echte Register-Setter aus:
8.963 C-Assertions, 14 identische Erfolgsablaeufe und 2.160 gezielt injizierte Fehler
an allen 15 Init-Stufen und den Reset-/IRQ-Aufrufstellen. Die alten Fehler wurden
mit der authentischen M33-Funktion reproduziert; die neue Fehlererwartung weist
diese alte Funktion ab. Abbruch bei Shutdown waehrend der Wartezeit ist geprueft.
Alle aktuellen nativen Tests zusammen: 57.525 C-Assertions; dazu 156 Assertions
des unveraenderten alten Probetests auf der M31-Referenz.
Der komplette geaenderte Treiber kompiliert fuer ARM64 mit dem gepinnten
AOSP Clang 12.0.5/CFI/ThinLTO und den Headern des aktuellen M33-Laufs.
Kein vollstaendiger lokaler M34-Kernelbau und kein Test am Geraet.

CI UND OFFENE ARBEIT
M33 und alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue BQ-Schicht nutzt weiter den authentischen M28-R2-Baukern mit saemtlichen
Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M34 muss neue
Quellen, LLVM-Objekt, CFI-Kommando, verlinkten IRQ-/Shutdown-Callback und neue Init-/
Recovery-Fehlerzweige in Image UND vmlinux nachweisen. Konfiguration und komplette
Exporttabelle muessen unveraendert bleiben. Boot.img/AK3 erst nach diesen Gates.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M34-GitHub-Bau und Artefaktpruefung; weitere Adapter- und
Versorgungspfade. Diese Reparatur serialisiert keine normalen parallelen
Adapterarbeiten und behauptet keine atomare Hardware-Wiederherstellung.
Kein Vollvergleich aller historischen ueber 7.100 Quellabweichungen und kein
universeller GKI-Nachweis. Geraeteboot, Laden, OTG, Suspend, Shutdown und
Wiederherstellung bleiben ungetestet. Device Pass NEIN. Flashfreigabe NEIN.
