import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase, main, mock
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import veux_r61_nomount22_only as n

class NoMountOnly(TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.kernel=self.base/'stage'/'kernel'
        self.donor=self.base/'donor'/'kernel'/'src'
        self.donor.mkdir(parents=True)
        (self.kernel/'fs/nomount').mkdir(parents=True)
        (self.kernel/'include/linux').mkdir(parents=True)
        (self.kernel/'KernelSU/kernel').mkdir(parents=True)
        (self.kernel/'fs/Makefile').write_text('obj-$(CONFIG_NOMOUNT) += nomount/\n')
        (self.kernel/'fs/Kconfig').write_text('source "fs/nomount/Kconfig"\n')
        (self.kernel/'fs/susfs.c').write_text('ORIGINAL SUSFS NEVER CHANGED')
        (self.kernel/'KernelSU/kernel/core.c').write_text('ORIGINAL BAKASU NEVER CHANGED')
        for item in n.PINNED_BLOBS:
            (self.kernel/'fs/nomount'/item).write_text('old-'+item)
            (self.donor/item).write_text('new-v22-'+item)
        self.dynamic_bridge='0'*39+'1'
        self.replay_commit='0'*39+'2'
        self.r54=self.base/'R54_REAL_BAKASU_REPLAY.json'
        self.r54.write_text(json.dumps({
          'status':n.R54_STATUS,'original_port':n.BAKASU_R13_PORT,
          'official_head':n.BAKASU_OFFICIAL_HEAD,
          'result_tree':n.BAKASU_STABLE_TREE,
          'kernel_delta_sha256':n.BAKASU_STABLE_KERNEL_DELTA,
          'historical_tree_byte_identical':True,
          'calculated_source_version':35259,'genuine_git_commit_count':4559,
          'result_commit':self.replay_commit,
        }))
        self.source=self.base/'stage'/'R58_SOURCE_STAGE.json'
        self.source.write_text(json.dumps({
            'schema':'VEUX_R58_INTEGRATED_SOURCE_DIAGNOSTIC_V1',
            'version_from_history':35260,
            'bakasu_real_git_count':4560,
            'base_r13_git':n.BAKASU_R13_PORT,
            'bakasu_35259_replay_git':self.replay_commit,
            'bakasu_local_bridge_git':self.dynamic_bridge,
            'susfs_snapshot_basis':n.SUSFS_SNAPSHOT,
            'native54_susfs_sha256':n.R60_SUSFS_SOURCE_SHA,
            'protected_r13_config_sha256':n.R60_BASE_CONFIG_SHA,
            'native54_sus_type_hash_collision_guard':True,
            'susfs_8a120081_update_ported':False,
        }))
        self.report=self.base/'R61_NOMOUNT22_SOURCE.json'
    def run_stage(self):
        with mock.patch.object(n,'validate_donor',return_value=(self.donor, 300)):
            return n.stage(self.kernel,self.donor.parents[1],self.report,self.r54)
    def test_stage_changes_only_nomount(self):
        pre=n.protected_hashes(self.kernel)
        result=self.run_stage()
        self.assertTrue((self.kernel/'fs/nomount').is_symlink())
        self.assertEqual(n.protected_hashes(self.kernel),pre)
        self.assertEqual(result['nomount_protocol'],22)
        self.assertEqual(result['changed_source_paths'],['fs/nomount/'])
        self.assertFalse(result['flash_allowed'])
        self.assertFalse(result['bakasu_or_susfs_updated'])
    def test_rerun_fails_closed(self):
        self.run_stage()
        with self.assertRaisesRegex(RuntimeError,'REPORT_REUSE'):
            self.run_stage()
    def test_missing_wiring_fails_closed(self):
        (self.kernel/'fs/Kconfig').write_text('source "fs/susfs/Kconfig"\n')
        with self.assertRaisesRegex(RuntimeError,'KCONFIG_NOMOUNT_NOT_EXACTLY_ONCE'):
            self.run_stage()
    def test_duplicate_wiring_fails_closed(self):
        with (self.kernel/'fs/Makefile').open('a') as f:f.write('obj-$(CONFIG_NOMOUNT) += nomount/\n')
        with self.assertRaisesRegex(RuntimeError,'MAKEFILE_NOMOUNT_NOT_EXACTLY_ONCE'):
            self.run_stage()
    def test_extra_prior_nomount_file_fails_closed(self):
        (self.kernel/'fs/nomount/extra').write_text('sentinel')
        with self.assertRaisesRegex(RuntimeError,'PRIOR_NOMOUNT_UNEXPECTED_FILES'):
            self.run_stage()
    def test_prior_nomount_source_same_fails_closed(self):
        (self.kernel/'fs/nomount/nomount.c').write_bytes((self.donor/'nomount.c').read_bytes())
        with self.assertRaisesRegex(RuntimeError,'NOMOUNT_ALREADY_V22'):
            self.run_stage()
    def test_missing_original_bakasu_fails_closed(self):
        (self.kernel/'KernelSU/kernel/core.c').unlink()
        with self.assertRaisesRegex(RuntimeError,'FROZEN_BAKASU_MISSING'):
            self.run_stage()
    def test_original_susfs_never_changes(self):
        r=self.run_stage()
        (self.kernel/'fs/susfs.c').write_text('CHANGED!!')
        self.assertNotEqual(n.protected_hashes(self.kernel),r['protected_source_sha256'])
    def test_ephemeral_bridge_commit_can_change_when_tree_is_same(self):
        expected=self.run_stage()
        self.assertEqual(expected['bakasu_expected_tree'],n.BAKASU_STABLE_TREE)
        self.assertEqual(expected['bakasu_observed_local_commit'],self.dynamic_bridge)
    def test_second_unique_bridge_commit_is_accepted_with_unchanged_tree(self):
        new='f'*40
        source=json.loads(self.source.read_text())
        source['bakasu_local_bridge_git']=new
        self.source.write_text(json.dumps(source))
        result=self.run_stage()
        self.assertEqual(result['bakasu_observed_local_commit'],new)
    def test_unexpected_bakasu_tree_is_blocked(self):
        a=json.loads(self.r54.read_text());a['result_tree']='f'*40
        self.r54.write_text(json.dumps(a))
        with self.assertRaisesRegex(RuntimeError,'R60_BAKASU_TREE_VERSION_OR_REAL_HISTORY_DRIFT'):
            self.run_stage()
    def test_unexpected_bakasu_delta_is_blocked(self):
        a=json.loads(self.r54.read_text());a['kernel_delta_sha256']='a'*64
        self.r54.write_text(json.dumps(a))
        with self.assertRaisesRegex(RuntimeError,'R60_BAKASU_TREE_VERSION_OR_REAL_HISTORY_DRIFT'):
            self.run_stage()
    def test_wrong_genuine_replay_commit_is_blocked(self):
        a=json.loads(self.r54.read_text());a['result_commit']='3'*40
        self.r54.write_text(json.dumps(a))
        with self.assertRaisesRegex(RuntimeError,'R60_BAKASU_TREE_VERSION_OR_REAL_HISTORY_DRIFT'):
            self.run_stage()
    def test_wrong_real_bakasu_version_is_blocked(self):
        a=json.loads(self.source.read_text());a['version_from_history']=35261
        self.source.write_text(json.dumps(a))
        with self.assertRaisesRegex(RuntimeError,'R60_BAKASU_TREE_VERSION_OR_REAL_HISTORY_DRIFT'):
            self.run_stage()
    def test_wrong_immutable_susfs_source_is_blocked(self):
        a=json.loads(self.source.read_text());a['native54_susfs_sha256']='f'*64
        self.source.write_text(json.dumps(a))
        with self.assertRaisesRegex(RuntimeError,'R60_FROZEN_SUSFS_OR_CONFIG_DRIFT'):
            self.run_stage()
    def test_bakasu_legitimate_symlinks_are_fingerprinted(self):
        p=self.kernel/'KernelSU/kernel/link.h'
        p.symlink_to('core.c')
        result=self.run_stage()
        self.assertIn('KernelSU/kernel/link.h',result['protected_source_sha256'])
        p.unlink()
        p.symlink_to('alternate.c')
        self.assertNotEqual(n.protected_hashes(self.kernel),result['protected_source_sha256'])
    def test_verify_against_different_r54_tree_is_blocked(self):
        self.run_stage()
        a=json.loads(self.r54.read_text());a['result_tree']='0'*40
        self.r54.write_text(json.dumps(a))
        b=self.base/'build';b.mkdir()
        (b/'.config').write_text('not a build')
        with self.assertRaisesRegex(RuntimeError,'R60_BASE_CONFIG_CHANGED'):
            n.verify(self.kernel,b,self.report,self.base/'R61_NOMOUNT22_COMPILED.json',self.r54)
    def test_verify_requires_real_compilation(self):
        self.run_stage()
        build=self.base/'build';build.mkdir()
        with self.assertRaisesRegex(RuntimeError,'R60_BASE_CONFIG_CHANGED'):
            n.verify(self.kernel,build,self.report,self.base/'R61_NOMOUNT22_COMPILED.json',self.r54)

if __name__=='__main__':main()
