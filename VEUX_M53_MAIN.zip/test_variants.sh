#!/usr/bin/env bash
# The release uses out/.config with LSE disabled. Test the optional hardware
# path in a separate Kbuild output directory using the original M52 config.
set -euo pipefail
tools=$(cd "$(dirname "$0")" && pwd)
objects=(lib/refcount.o lib/dec_and_lock.o kernel/locking/qspinlock.o kernel/locking/spinlock.o
         arch/arm64/kernel/cpufeature.o arch/arm64/net/bpf_jit_comp.o)
mkdir -p lse-on
cp baseline.config lse-on/.config
bash "$tools/kbuild.sh" src lse-on clang olddefconfig
for variant in out lse-on; do
    bash "$tools/kbuild.sh" src "$variant" clang "${objects[@]}"
    clang/bin/ld.lld -r "${objects[@]/#/$variant/}" -o "evidence/Atomics-$variant.o"
done
python3 -B "$tools/atomics.py" stock clang/bin boot.img evidence/Xiaomi-Atomics.json
python3 -B "$tools/atomics.py" objects clang/bin evidence/Atomics-out.o evidence/M53-Objekte.json \
    --enabled-object evidence/Atomics-lse-on.o
bash "$tools/test_atomic_runtime.sh" src out clang
