"""Check three named code paths in Xiaomi Stock, linked ARM64 objects and a finished Image."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from check import BOOT, BASE_IMAGE, sha
from config_proof import require

# Locations of the two consecutive R_AARCH64_RELATIVE records for value/name
# in the authenticated Xiaomi Image. Resolve and validate both before reading code.
BASE = 0xffffffc010080000
# symbol: relocation record, expected ordered pair, old M52 opcode
CASES = {
    '_raw_spin_lock': (0x273f988, 'ldaxr', 'stxr', 'casa'),
    'refcount_dec_not_one': (0x2777908, 'ldxr', 'stlxr', 'casl'),
    '_atomic_dec_and_lock': (0x273f418, 'ldxr', 'stlxr', 'casal'),
}
PREFIX = 96


def stock_offsets(image):
    offsets = {}
    for name, (rel, *_) in CASES.items():
        slot, r1, fn, name_slot, r2, string = struct.unpack_from('<6Q', image, rel)
        require(r1 == r2 == 1027 and name_slot == slot + 8, 'Stock relocation: ' + name)
        require(image.startswith(name.encode() + b'\0', string - BASE), 'Stock export: ' + name)
        stub = fn - BASE
        branch, = struct.unpack_from('<I', image, stub)
        require(branch >> 26 == 5, 'Stock CFI jump: ' + name)
        displacement = ((branch & 0x03ffffff) ^ 0x02000000) - 0x02000000
        offsets[name] = stub + displacement * 4
    return offsets


def map_offsets(system_map):
    wanted = set(CASES) | {'_text'}
    addr = {}
    with system_map.open() as src:
        for row in src:
            fields = row.split()
            if len(fields) == 3 and fields[2] in wanted and fields[1] == 'T':
                require(fields[2] not in addr, 'Duplicate symbol: ' + fields[2])
                addr[fields[2]] = int(fields[0], 16)
    require(addr.keys() == wanted, 'Incomplete Image symbol map')
    return {name: addr[name] - addr['_text'] for name in CASES}


def listing(tc, file, *flags):
    return subprocess.check_output([tc / 'llvm-objdump', '--mattr=+lse', '--no-show-raw-insn',
                                    *flags, file], text=True)


def signature(assembly, name, old):
    lines = []
    for match in re.finditer(r'^\s*([0-9a-f]+):\s+([.\w]+)\s*(.*?)$', assembly, re.M):
        addr, op, arg = match.groups()
        if op in ('ret', 'b'):
            break
        lines.append((int(addr, 16), op, arg.strip()))
    _, load, store, previous = CASES[name]
    ops = [item[1] for item in lines]
    if old:
        require(previous in ops and load not in ops and store not in ops, 'M52 opcode: ' + name)
        return [previous]
    require(load in ops and store in ops and previous not in ops, 'Stock atomics: ' + name)
    first = ops.index(load)
    last = ops.index(store)
    require(first < last < len(lines)-1, 'Load/store order: ' + name)
    st_args = lines[last][2].split(',')
    require(lines[first][2].split(',')[-1].strip() == st_args[-1].strip(), 'Atomic address: ' + name)
    retry = re.fullmatch(r'(w\d+),\s+0x([0-9a-f]+)(?:\s+<.*>)?', lines[last+1][2])
    require(lines[last+1][1] == 'cbnz' and retry and retry.group(1) == st_args[0] and
            int(retry.group(2),16) == lines[first][0], 'Exclusive store retry: ' + name)
    result = [load, store, 'cbnz -> ' + load]
    if name == '_atomic_dec_and_lock':
        require(lines[last+2][1:] == ('dmb','ish'), 'Missing full barrier: ' + name)
        result.append('dmb ish')
    return result


def image_proof(tc, image, offsets, old=False):
    result = {}
    with tempfile.TemporaryDirectory() as tmp:
        raw = Path(tmp)/'prefix.bin'
        obj = Path(tmp)/'prefix.o'
        for name, offset in offsets.items():
            require(0 < offset < len(image)-PREFIX and offset % 4 == 0, 'Image offset: ' + name)
            raw.write_bytes(image[offset:offset+PREFIX])
            subprocess.run([tc/'llvm-objcopy', '-I','binary','-O','elf64-littleaarch64','-B','aarch64',
                            '--rename-section','.data=.text,alloc,code,contents,load,readonly',raw,obj], check=True)
            result[name] = signature(listing(tc,obj,'-D','-j','.text'),name,old)
    return result


def alternative_proof(tc, obj, enabled):
    with tempfile.TemporaryDirectory() as tmp:
        section = Path(tmp)/'alt'
        subprocess.run([tc/'llvm-objcopy','--dump-section',f'.altinstructions={section}',obj,
                        Path(tmp)/'copy.o'],check=True)
        rows = [(a,b) for _,_,cap,a,b in struct.iter_unpack('<iiHBB',section.read_bytes()) if cap==5]
    require(bool(rows) == enabled and all(a==b and a>0 for a,b in rows), 'ARM64 LSE alternative records')
    reloc = subprocess.check_output([tc/'llvm-readelf','-rW',obj],text=True)
    blocks = re.split(r"Relocation section '([^']+)'[^\n]*\n",reloc)
    sections = dict(zip(blocks[1::2],blocks[2::2]))
    jumps = sections.get('.rela__jump_table','')
    require(bool(re.search(r'cpu_hwcap_keys \+ 51\b',jumps)) == enabled, 'LSE static key')
    if enabled:
        require('arm64_const_caps_ready' in jumps,'CPU capability initialization guard')
    jit = ''.join(body for title,body in sections.items() if title.startswith(('.rela.text.build_body', '.rela.text.build_insn')))
    require(bool(jit) and (' cpu_hwcaps + ' in jit) == enabled,'BPF hardware capability check')
    return {'capability_5_records':len(rows), 'lse_static_key':enabled,'jit_checks_cpu_caps':enabled}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage', choices=['stock','objects','image','m52'])
    p.add_argument('tc', type=Path)
    p.add_argument('input',type=Path)
    p.add_argument('result',type=Path)
    p.add_argument('--system-map',type=Path)
    p.add_argument('--enabled-object',type=Path)
    args=p.parse_args()
    if args.stage=='objects':
        proof={name:signature(listing(args.tc,args.input,'-d','--disassemble-symbols='+name),name,False)
               for name in CASES}
        proof['variant_off']=alternative_proof(args.tc,args.input,False)
        proof['variant_on']=alternative_proof(args.tc,args.enabled_object,True)
    elif args.stage=='stock':
        require(sha(args.input)==BOOT,'Xiaomi stock boot identity')
        data=args.input.read_bytes()
        image=data[4096:4096+struct.unpack_from('<I',data,8)[0]]
        proof=image_proof(args.tc,image,stock_offsets(image))
    else:
        if args.stage=='m52':
            require(sha(args.input)==BASE_IMAGE,'M52 Image identity')
        proof=image_proof(args.tc,args.input.read_bytes(),map_offsets(args.system_map),args.stage=='m52')
    args.result.write_text(json.dumps(proof,indent=2)+'\n')
    print('PASS',args.stage,', '.join(CASES))

if __name__=='__main__':
    main()
