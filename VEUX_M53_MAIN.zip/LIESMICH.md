# VEUX M53 · ARM64-Atomics und Radixbaum

Die Basis ist der bestätigte M52-Kernel 5.4.274-qgki-g82179e362f33 für Xiaomi VEUX, Build V816.0.12.0.TKCMIXM. Der vollständige M52-Bau und seine Modultests sind in [Lauf 45009894725](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45009894725/job/137169679596) dokumentiert.

## Upload

1. VEUX_M53_MAIN.zip ins Hauptverzeichnis des Repositories legen.
2. VEUX_M53_ARM64_NOFLASH.yml unter .github/workflows/ im selben Branch speichern.
3. Unter Actions den Workflow „VEUX M53 – Stock-Atomics, QGKI 5.4.274“ manuell auf diesem Branch starten.

Der Lauf prüft die ZIP-Prüfsumme, den vollständigen M52-Quellstand (Artefakt 14750027225), die Xiaomi-Stockreferenz (Artefakt 14706022228) und die Dateihashes nach Anwendung des Patches. Die beiden Ausgangsartefakte müssen beim Start verfügbar sein. Das Paket dient zum Bauen und Prüfen auf GitHub.

## Warum der Eingriff nötig ist

M52 setzte die ARM64-Erweiterung LSE für atomare Speicherzugriffe voraus. In der aktiven Konfiguration wählte der Kernel diese Befehle auch ohne Prüfung der CPU-Fähigkeiten. Der Vergleich dreier exportierter Funktionen im originalen Xiaomi-Image mit denselben Funktionen im gebauten M52-Image zeigt den Unterschied im tatsächlich ausgeführten Code.

| Funktion | Xiaomi-Stock und M53-Vorprüfung | M52 |
|---|---|---|
| _raw_spin_lock | ldaxr, stxr, Wiederholung bei Konflikt | casa |
| refcount_dec_not_one | ldxr, stlxr, Wiederholung bei Konflikt | casl |
| _atomic_dec_and_lock | ldxr, stlxr, Wiederholung und dmb ish | casal |

M53 deaktiviert LSE in der VEUX-Baukonfiguration. Der Quellpatch stellt auch bei optional aktiviertem LSE die CPU-Prüfung und umschaltbaren, gleich langen Befehlssequenzen wieder her. Die atomare Addition des ARM64-BPF-JIT berücksichtigt den unterstützten CPU-Befehlssatz. Die Portierung nutzt die betroffenen Stellen aus [Xiaomis öffentlichem VEUX-Quellstand 5.4.134](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/61397e524093d1ccb94769b5460825e2eaf8871e/arch/arm64) zusammen mit der vorhanden gebliebenen ARM64- und Kconfig-Infrastruktur von 5.4.274.

M52 meldete beim GCC-Bau des Radixbaum-Hosttests außerdem einen möglicherweise uninitialisierten Offset in radix_tree_tag_clear. Beim direkten Eintrag an der Wurzel entfällt der Baumabstieg. M53 initialisiert den Offset für diesen Pfad. Der Test prüft einen leeren Baum, den direkten Wurzeleintrag, einen unbelegten Index und Markierungen auf mehreren Blättern.

## Ergebnisse und Grenzen

- M52 hat 52 textliche Konfigurationsunterschiede zu Xiaomi. M53 hat weiterhin 52. Zwei dieser Einträge erklären sich jetzt durch die Darstellung der abgeschalteten LSE-Option in den beiden Kconfig-Versionen. Die 50 übrigen Einträge enthalten sowohl Funktionsunterschiede als auch Werkzeug- und Namensunterschiede. Restkonfiguration.csv enthält alle Zeilen.
- Die Stockprüfung löst die Exportrelokationen und die CFI-Sprünge im per SHA-256 identifizierten Xiaomi-Kernel auf. Sie prüft je Funktion Lade-/Speicherbefehle, Wiederholungsziel und beim vollständig geordneten Zugriff die Speicherbarriere. Die M52-Gegenprobe steht unter Nachweise/.
- Lokal wurden die betroffenen Kernelobjekte für ARM64 übersetzt und die Varianten mit und ohne LSE separat gelinkt. Das Laufzeittestprogramm verwendet die Atomikfunktionen aus den M53-Kernelheadern. Zwei QEMU-CPU-Modelle führen je 65.536 Runden mit 32- und 64-Bit-Operationen aus. Diese Tests prüfen die Befehle im Userspace. Die Ausführung des Kernels auf dem VEUX ist offen.
- Vor dem Vollbau wiederholt GitHub die Bootinfo-, F2FS-, Radixbaum-, DTB- und Atomikprüfungen. Nach dem Bau vergleicht der Workflow die drei Atomikpfade im fertigen Image mit Xiaomi und prüft die Kernelkennung, die eingebetteten Konfigurationen, vier Module, 3.148 Vendor-Importe sowie das Stock-Bootlayout. Die Bauprodukte und Ergebnisse stehen in KERNEL-NACHWEISE, die Quellbasis in QUELLSTAND.
- Zu den offenen Stock-Abgleichen gehören die Prozessauswahl bei Speichermangel und die CPU-Isolation bei thermischer Drosselung. Ein F2FS-Wiederanlauf nach unterbrochenem Schreibvorgang, der Start des Kandidaten auf dem Gerät und ein praktisch bestätigter Rückweg bleiben eigenständige Prüfungen. Eine Flash-Freigabe steht aus.
