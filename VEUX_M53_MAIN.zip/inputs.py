"""Authenticate the M52 source and extract the matching Xiaomi reference image."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, write, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m52.zip') as archive:
    require(sha(work/'m52.zip')=='6a9066ed1096bb67079b046c183de0335d82d3221e043095c9566218554137e0', 'M52 artifact digest')
    manifest=json.loads(archive.read('M52_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M52 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M52 config identity')
    archive.extract('M52-kernel-source.tar.gz',work)
tar=work/'M52-kernel-source.tar.gz'
require(sha(tar)=='ba6e9212935073a7e5f370f0db8b43960ed6c0364a1aecbee4f29de825e480ab','M52 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'arm64-atomics.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-d','ARM64_USE_LSE_ATOMICS'],check=True)
