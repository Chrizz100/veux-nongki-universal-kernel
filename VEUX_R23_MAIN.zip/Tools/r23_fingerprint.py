#!/usr/bin/env python3
"""Restore stock fingerprint options on the authenticated R21 full-build path."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
FLAGS = ('CONFIG_INPUT_FINGERPRINT', 'CONFIG_FINGERPRINT_FPC',
         'CONFIG_FINGERPRINT_GOODIX_FOD', 'CONFIG_FINGERPRINT_SILEAD')
UNITS = {'fpc/fpc1020_platform_tee': 'fpc1020_init6',
         'goodix/gf_spi': 'gf_init6', 'silead/silead_fp': 'silfp_dev_init7'}
FP = 'drivers/input/fingerprint/'
STATUS = 'R23_FULL_BUILD_FINGERPRINT_1423_CRCS_37_MODULES_STOCK_RELEASE_PASS_NOFLASH'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def profile():
    return json.loads((ROOT/'References/PROFILE.json').read_text())


def pins():
    return json.loads((ROOT/'References/SOURCE_PINS.json').read_text())


def config_values(text):
    values = {}
    for line in text.splitlines():
        if line.startswith('CONFIG_'):
            key, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            key, value = line[2:-11], 'n'
        else:
            continue
        require(key not in values, 'DUPLICATE_CONFIG:' + key)
        values[key] = value
    return values


def values_sha(values):
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def verify_package():
    names = set()
    for line in (ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in names,
                'UNSAFE_R23_MANIFEST')
        require(not (ROOT/path).is_symlink() and sha(ROOT/path) == digest, 'R23_FILE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names, 'R23_MANIFEST_SCOPE_CHANGED')
    require(len(pins()) == 19 and profile()['expected_release'] == '5.4.274-qgki-g82179e362f33',
            'R23_PROFILE_SCOPE_CHANGED')


def check_source(source):
    source = Path(source).resolve(strict=True)
    hashes = {}
    for name, pin in pins().items():
        path = source/name
        require(path.is_file() and not path.is_symlink()
                and all(not p.is_symlink() for p in path.parents if p.is_relative_to(source)),
                'FINGERPRINT_SOURCE_NOT_REGULAR:' + name)
        hashes[name] = sha(path)
        require(hashes[name] == pin['sha256'], 'FINGERPRINT_PREIMAGE_DRIFT:' + name)
    require(sha(source/'scripts/config') == profile()['scripts_config_sha256'], 'SCRIPTS_CONFIG_CHANGED')
    return {'source_hashes': hashes, 'source_changed': False}


def normalize_fingerprint(values):
    require(all(values.get(n) == 'y' for n in FLAGS), 'ALL_FOUR_FINGERPRINT_OPTIONS_MUST_BE_BUILTIN')
    old = dict(values)
    old[FLAGS[0]] = 'n'
    for name in FLAGS[1:]:
        del old[name]
    require(values_sha(old) == profile()['baseline_config_values_sha256'],
            'CONFIG_CHANGED_OUTSIDE_FOUR_FINGERPRINT_KEYS')
    return old


def config_delta(values):
    normalize_fingerprint(values)
    return {n: ['n' if i == 0 else None, values[n]] for i, n in enumerate(FLAGS)}


def request_fingerprint(source, config):
    source = Path(source)
    require(sha(source/'scripts/config') == profile()['scripts_config_sha256'], 'SCRIPTS_CONFIG_CHANGED')
    cmd = ['bash', str(source/'scripts/config'), '--file', str(config)]
    for name in FLAGS:
        cmd += ['--enable', name.removeprefix('CONFIG_')]
    p = subprocess.run(cmd, text=True, capture_output=True)
    require(p.returncode == 0, 'FINGERPRINT_CONFIG_REQUEST_FAILED:' + p.stderr)
    # The full config is checked after the original olddefconfig and again after the build.
    return {'requested_builtin_keys': list(FLAGS), 'defconfig_modified': False, 'source_modified': False}


def load_pinned(path, key, module_name):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()[key], 'AUTHENTIC_PARENT_TOOL_CHANGED:' + path.name)
    spec = importlib.util.spec_from_file_location(module_name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def linked_initcalls(text):
    result = {}
    for name, suffix in UNITS.items():
        matches = re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(__initcall_\S*'
                             + re.escape(suffix) + r'(?:\.llvm\.\S+)?)$', text)
        require(len(matches) == 1, 'FINGERPRINT_INITCALL_NOT_UNIQUELY_LINKED:' + name)
        result[name] = matches[0]
    return result


def object_proof(path, cmd, unit):
    with Path(path).open('rb') as f:
        magic = f.read(4)
    require(magic in (b'BC\xc0\xde', b'\xde\xc0\x17\x0b'), 'FINGERPRINT_OBJECT_NOT_LLVM_BITCODE:' + unit)
    text = Path(cmd).read_text()
    require(FP + unit + '.c' in text and '-fsanitize=cfi' in text and '-flto=thin' in text,
            'FINGERPRINT_REAL_CFI_THINLTO_COMMAND_MISSING:' + unit)
    if unit.startswith('silead/'):
        require('-DBSP_SIL_PLAT_QCOM' in text and '-DCONFIG_SILEAD_FP_PLATFORM' in text,
                'SILEAD_QCOM_PLATFORM_COMMAND_MISSING')
    return {'object_sha256': sha(path), 'command_sha256': sha(cmd), 'CFI_ThinLTO': True}


def fingerprint_build_proof(build):
    build = Path(build).resolve(strict=True)
    out = build/'candidate-out'
    source = check_source(build/'candidate-source')
    values = config_values((out/'.config').read_text())
    delta = config_delta(values)
    objects = {}
    for unit in UNITS:
        name = FP + unit + '.o'
        cmd = out/Path(name).parent/('.' + Path(name).name + '.cmd')
        objects[unit] = object_proof(out/name, cmd, unit)
    return {'only_config_changes_against_actual_R21_R2': delta, 'fingerprint_objects': objects,
            'fingerprint_linked_initcalls': linked_initcalls((out/'System.map').read_text()),
            'fingerprint_source': source, 'System_map_sha256': sha(out/'System.map')}


def write_result(out, name, result):
    if out.is_dir():
        (out/name).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def build(args):
    verify_package()
    check_source(args.source)
    parent = load_pinned(args.r21_tool, 'r21_tool_sha256', 'r23_authentic_r21')
    parent.verify_package()
    original_request, original_normalize = parent.request_release, parent.normalize_release_config
    out = Path(args.output).resolve()
    result = {'status': 'R23_BUILD_PENDING', 'kernel_compiled': False, 'device_pass': False,
              'flash_allowed': False, 'baseline_run': profile()['baseline_run'],
              'legacy_R21_config_delta_scope': 'Release controls only; complete R23 delta measured separately.'}

    def request(source, config):
        release = original_request(source, config)
        fingerprint = request_fingerprint(source, config)
        result['fingerprint_request'] = fingerprint
        return dict(release, only_requested_keys=release['only_requested_keys'] + list(FLAGS),
                    fingerprint_request=fingerprint)

    def normalize(values):
        return original_normalize(normalize_fingerprint(values))

    parent.request_release, parent.normalize_release_config = request, normalize
    try:
        parent.build(args)
        legacy = json.loads((out/'R21_RESULT.json').read_text())
        require(legacy['kernel_compiled'] is True and legacy['all_1423_import_crcs_match'] is True
                and legacy['fully_matching_modules'] == 37, 'R21_FULL_BUILD_AND_ABI_NOT_PROVEN')
        result.update(fingerprint_build_proof(out))
        for name, digest in legacy['kernel_product_hashes'].items():
            require(sha(out/'candidate-out'/name) == digest, 'FULL_BUILD_PRODUCT_CHANGED:' + name)
        result.update(status=STATUS, kernel_compiled=True, qgki_counts=legacy['qgki_counts'],
                      fully_matching_modules=37, all_1423_import_crcs_match=True,
                      kernel_product_hashes=legacy['kernel_product_hashes'], release=legacy['release'])
    except Exception as error:
        result.update(status='R23_BUILD_OR_FINGERPRINT_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.request_release, parent.normalize_release_config = original_request, original_normalize
        write_result(out, 'R23_RESULT.json', result)
    print(result['status'], 'DEVICE_PASS=NO FLASH=NO')


def verify_fresh_build(build):
    build = Path(build).resolve(strict=True)
    result = json.loads((build/'R23_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_R23_FULL_BUILD_REQUIRED')
    actual = fingerprint_build_proof(build)
    require(all(result.get(k) == v for k, v in actual.items()), 'FINGERPRINT_PROOF_CHANGED_AFTER_BUILD')
    legacy = json.loads((build/'R21_RESULT.json').read_text())
    require(result['kernel_product_hashes'] == legacy['kernel_product_hashes'], 'R23_R21_PRODUCTS_DISAGREE')
    for name, digest in result['kernel_product_hashes'].items():
        require(sha(build/'candidate-out'/name) == digest, 'R23_KERNEL_PRODUCT_CHANGED:' + name)
    return result


def package(args):
    verify_package()
    result = verify_fresh_build(args.build)
    parent = load_pinned(args.r21_package_tool, 'r21_package_tool_sha256', 'r23_authentic_r21_packager')
    # The unchanged packager independently rechecks real exports, releases, binaries, and the 37-module cohort.
    parent.package(args)
    out = Path(args.output).resolve(strict=True)
    legacy = json.loads((out/'R21_PACKAGE_RESULT.json').read_text())
    require(legacy.get('static_boot_path_pass') is True and legacy.get('device_pass') is False,
            'BOOT_AK3_STATIC_PATH_NOT_PROVEN')
    pair = {}
    for p in sorted((out/'review').iterdir()):
        require(p.is_file() and p.name.startswith('VEUX_R21_'), 'UNEXPECTED_REVIEW_FILE')
        new = p.with_name(p.name.replace('VEUX_R21_', 'VEUX_R23_', 1))
        require(not new.exists(), 'REVIEW_TARGET_EXISTS')
        p.rename(new)
        pair[new.name] = sha(new)
    require(len(pair) == 2 and any(n.endswith('_boot.img') for n in pair)
            and any(n.endswith('_AK3.zip') for n in pair), 'COMPLETE_PAIR_REQUIRED')
    require(sha(Path(args.build)/'candidate-out/arch/arm64/boot/Image') == legacy['image_sha256'],
            'PACKAGED_KERNEL_CHANGED')
    verify_fresh_build(args.build)
    write_result(out, 'R23_PACKAGE_RESULT.json', {
        'status': 'R23_FINGERPRINT_STATIC_BOOT_AK3_PAIR_PASS_DEVICE_UNTESTED_NOFLASH',
        'review_pair_sha256': pair, 'static_boot_path_pass': True, 'device_pass': False,
        'flash_allowed': False, 'kernel_release': result['release']['verified_release'],
        'image_sha256': legacy['image_sha256'], 'fingerprint_linked_initcalls': result['fingerprint_linked_initcalls'],
        'underlying_container_evidence': 'R21_PACKAGE_RESULT.json (unchanged R20/R21 method)'})
    print('R23_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='op', required=True)
    subs.add_parser('verify-package')
    subs.add_parser('check-source').add_argument('--source', required=True)
    b = subs.add_parser('build')
    for n in ('r21-tool', 'r19-tool', 'r18-tool', 'r17-tool', 'base-tool', 'source',
              'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + n, required=True)
    p = subs.add_parser('package')
    for n in ('r21-package-tool', 'build', 'packager-tool', 'work', 'output'):
        p.add_argument('--' + n, required=True)
    args = parser.parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'check-source':
        print(json.dumps(check_source(args.source), sort_keys=True))
    else:
        print('R23_PACKAGE_VERIFIED FULL_GITHUB_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
