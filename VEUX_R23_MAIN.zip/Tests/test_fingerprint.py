import contextlib
import copy
import importlib.util
import io
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r23_tested_driver', ROOT/'Tools/r23_fingerprint.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def baseline():
    data = lzma.decompress((ROOT/'References/R21.config.xz').read_bytes())
    return m.config_values(data.decode())


def restored():
    values = baseline()
    values.update({n: 'y' for n in m.FLAGS})
    return values


def delivered_command():
    if 'R23_WORKFLOW' not in os.environ:
        return (ROOT/'References/R23_BUILD_COMMAND.sh').read_text()
    rows = Path(os.environ['R23_WORKFLOW']).read_text().splitlines()
    matches = []
    for i, row in enumerate(rows):
        if not row.strip().startswith('run: |'):
            continue
        indent = len(row) - len(row.lstrip())
        body = []
        for line in rows[i+1:]:
            if line.strip() and len(line) - len(line.lstrip()) <= indent:
                break
            body.append(line)
        script = textwrap.dedent('\n'.join(body)) + '\n'
        if 'python3 -B "$R23_DIR/Tools/r23_fingerprint.py" build' in script:
            matches.append(script)
    if len(matches) != 1:
        raise ValueError('ACTUAL_R23_WORKFLOW_COMMAND_NOT_UNIQUE')
    return matches[0]


class FingerprintTests(unittest.TestCase):
    def test_fixture_is_actual_green_r21_config(self):
        import hashlib
        data = lzma.decompress((ROOT/'References/R21.config.xz').read_bytes())
        self.assertEqual(hashlib.sha256(data).hexdigest(), m.profile()['baseline_config_sha256'])
        self.assertEqual(m.values_sha(baseline()), m.profile()['baseline_config_values_sha256'])

    def test_exact_four_option_delta_and_original_baseline(self):
        self.assertEqual(m.normalize_fingerprint(restored()), baseline())
        self.assertEqual(m.config_delta(restored()), {n: ['n' if i == 0 else None, 'y']
                                                    for i, n in enumerate(m.FLAGS)})

    def test_every_fingerprint_option_is_mandatory_builtin(self):
        for name in m.FLAGS:
            for wrong in (None, 'n', 'm'):
                values = restored()
                if wrong is None:
                    values.pop(name)
                else:
                    values[name] = wrong
                with self.subTest(name=name, wrong=wrong), self.assertRaises(ValueError):
                    m.normalize_fingerprint(values)

    def test_unrelated_cfi_walt_rtmm_and_release_changes_are_rejected(self):
        for name, value in [('CONFIG_CFI_CLANG', 'n'), ('CONFIG_SCHED_WALT', 'n'),
                            ('CONFIG_RTMM', 'y'), ('CONFIG_LOCALVERSION', '"-Positron"')]:
            values = restored()
            values[name] = value
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'OUTSIDE_FOUR'):
                m.normalize_fingerprint(values)

    def test_real_scripts_config_changes_only_four_values_without_defconfig(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            (source/'scripts').mkdir()
            shutil.copyfile(ROOT/'References/scripts_config', source/'scripts/config')
            config = source/'.config'
            config.write_bytes(lzma.decompress((ROOT/'References/R21.config.xz').read_bytes()))
            defconfig = source/'defconfig'
            defconfig.write_bytes(b'original untouched defconfig\n')
            before = m.sha(defconfig)
            m.request_fingerprint(source, config)
            self.assertEqual(m.config_values(config.read_text()), restored())
            self.assertEqual(m.sha(defconfig), before)

    def test_all_19_source_files_are_checked_without_mutation(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            shutil.copytree(ROOT/'Sources', source, dirs_exist_ok=True)
            (source/'scripts').mkdir()
            shutil.copyfile(ROOT/'References/scripts_config', source/'scripts/config')
            first = m.check_source(source)
            self.assertEqual(len(first['source_hashes']), 19)
            self.assertEqual(first, m.check_source(source))
            victim = source/'drivers/input/fingerprint/goodix/gf_spi.c'
            victim.write_text(victim.read_text() + '\n/* changed source */\n')
            with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
                m.check_source(source)

    def test_all_three_actual_initcall_forms_required(self):
        lines = ['ffffff8008100000 d __initcall_162_775_fpc1020_init6',
                 'ffffff8008100008 d __initcall_190_870_gf_init6.llvm.12345',
                 'ffffff8008100010 d __initcall_191_1509_silfp_dev_init7']
        self.assertEqual(set(m.linked_initcalls('\n'.join(lines))), set(m.UNITS))
        for i in range(3):
            with self.subTest(missing=i), self.assertRaises(ValueError):
                m.linked_initcalls('\n'.join(lines[:i] + lines[i+1:]))
        with self.assertRaises(ValueError):
            m.linked_initcalls('\n'.join(lines + [lines[0]]))

    def test_actual_cfi_and_silead_platform_commands_are_required(self):
        with tempfile.TemporaryDirectory() as temp:
            obj = Path(temp)/'silead_fp.o'
            cmd = Path(temp)/'.silead_fp.o.cmd'
            obj.write_bytes(b'BC\xc0\xde' + b'test-fixture')
            good = ('clang -fsanitize=cfi -flto=thin -DBSP_SIL_PLAT_QCOM '
                    '-DCONFIG_SILEAD_FP_PLATFORM ' + m.FP + 'silead/silead_fp.c')
            cmd.write_text(good)
            self.assertTrue(m.object_proof(obj, cmd, 'silead/silead_fp')['CFI_ThinLTO'])
            for flag in ['-fsanitize=cfi', '-flto=thin', '-DBSP_SIL_PLAT_QCOM', '-DCONFIG_SILEAD_FP_PLATFORM']:
                cmd.write_text(good.replace(flag, ''))
                with self.subTest(flag=flag), self.assertRaises(ValueError):
                    m.object_proof(obj, cmd, 'silead/silead_fp')
            cmd.write_text(good)
            obj.write_bytes(b'\x7fELF ordinary object')
            with self.assertRaises(ValueError):
                m.object_proof(obj, cmd, 'silead/silead_fp')

    def test_duplicate_config_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'DUPLICATE_CONFIG'):
            m.config_values('CONFIG_TEST=y\nCONFIG_TEST=n\n')

    def test_old_build_cannot_be_packaged_as_r23(self):
        with tempfile.TemporaryDirectory() as temp:
            import json
            (Path(temp)/'R23_RESULT.json').write_text(json.dumps({'status': 'R21_FULL_BUILD_PASS'}))
            with self.assertRaisesRegex(ValueError, 'FRESH_R23_FULL_BUILD_REQUIRED'):
                m.verify_fresh_build(temp)

    def test_real_r21_release_normalizer_accepts_only_exact_fingerprint_extension(self):
        import argparse
        import json
        parent_root = Path(os.environ.get('R21_SCHED_DIR', str(ROOT.parent/'r21-r2-main')))
        parent = m.load_pinned(parent_root/'Tools/r21_scheduler_release.py',
                               'r21_tool_sha256', 'r23_real_parent_contract_test')
        original_request, original_normalize = parent.request_release, parent.normalize_release_config
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)/'source'
            shutil.copytree(ROOT/'Sources', source)
            (source/'scripts').mkdir()
            shutil.copyfile(ROOT/'References/scripts_config', source/'scripts/config')
            out = Path(temp)/'result'
            out.mkdir()
            config = out/'.config'
            config.write_bytes(lzma.decompress((ROOT/'References/R21.config.xz').read_bytes()))

            def stopped_build(args):
                request = parent.request_release(source, config)
                self.assertEqual(set(request['only_requested_keys']), set(m.FLAGS) |
                                 {'CONFIG_LOCALVERSION', 'CONFIG_LOCALVERSION_AUTO'})
                normalized = parent.normalize_release_config(m.config_values(config.read_text()))
                self.assertEqual(normalized['CONFIG_LOCALVERSION'], '"-qgki"')
                self.assertEqual(normalized['CONFIG_LOCALVERSION_AUTO'], 'y')
                raise RuntimeError('TEST_STOPS_BEFORE_ANY_KERNEL_COMPILATION')

            args = argparse.Namespace(source=str(source), output=str(out),
                                      r21_tool=str(parent_root/'Tools/r21_scheduler_release.py'))
            with patch.object(m, 'load_pinned', return_value=parent), \
                    patch.object(parent, 'build', side_effect=stopped_build) as build:
                with self.assertRaisesRegex(RuntimeError, 'TEST_STOPS_BEFORE_ANY_KERNEL_COMPILATION'):
                    m.build(args)
            build.assert_called_once()
            self.assertIs(parent.request_release, original_request)
            self.assertIs(parent.normalize_release_config, original_normalize)
            report = json.loads((out/'R23_RESULT.json').read_text())
            self.assertFalse(report['kernel_compiled'])
            self.assertFalse(report['device_pass'])
            self.assertFalse(report['flash_allowed'])

    def capture(self, body):
        with tempfile.TemporaryDirectory(prefix='r23 cli spaces ') as temp:
            base = Path(temp)
            shim = base/'bin'
            shim.mkdir()
            program = shim/'python3'
            program.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$R23_CAPTURE"\n')
            program.chmod(0o755)
            keys = ['R21_SCHED_DIR', 'R19_RMNET_DIR', 'R18_IRQ_DIR', 'R17_CACHE_DIR', 'R16_REPAIR_DIR',
                    'R9_SNAPSHOT', 'R13_OBJOUT', 'R47_REPORT_DIR', 'R47_TOOLS_DIR',
                    'GITHUB_WORKSPACE', 'R16_REPAIR_OUTPUT']
            values = {n: str(base/(n + ' with spaces')) for n in keys}
            values['R23_DIR'] = str(ROOT)
            env = dict(os.environ, **values, R23_CAPTURE=str(base/'args'),
                       PATH=str(shim) + os.pathsep + os.environ['PATH'])
            r = subprocess.run(['bash', '-c', body], env=env, capture_output=True, text=True, timeout=10)
            self.assertEqual(r.returncode, 0, r.stderr)
            data = (base/'args').read_bytes().split(b'\0')
            self.assertEqual(data.pop(), b'')
            return [x.decode() for x in data], values

    def test_actual_yaml_bash_argv_passes_real_parser(self):
        body = delivered_command()
        self.assertEqual(body, (ROOT/'References/R23_BUILD_COMMAND.sh').read_text())
        argv, env = self.capture(body)
        self.assertEqual(argv[:2], ['-B', str(ROOT/'Tools/r23_fingerprint.py')])
        with patch.object(sys, 'argv', [argv[1], *argv[2:]]), patch.object(m, 'verify_package'), \
                patch.object(m, 'build') as build:
            m.main()
        build.assert_called_once()
        actual = vars(build.call_args.args[0])
        expected = {'op': 'build'}
        for key, var, suffix in [
            ('r21_tool', 'R21_SCHED_DIR', '/Tools/r21_scheduler_release.py'),
            ('r19_tool', 'R19_RMNET_DIR', '/Tools/r19_rmnet_vendor_abi.py'),
            ('r18_tool', 'R18_IRQ_DIR', '/Tools/r18_irq_affinity.py'),
            ('r17_tool', 'R17_CACHE_DIR', '/Tools/r17_cache_alignment.py'),
            ('base_tool', 'R16_REPAIR_DIR', '/Tools/restore_memory_network.py'),
            ('source', 'R9_SNAPSHOT', ''), ('objout', 'R13_OBJOUT', ''),
            ('r6_report', 'R47_REPORT_DIR', '/R47_RESULT.json'),
            ('r6_tool', 'R47_TOOLS_DIR', '/Tools/veux_r47_r13_on_r46.py'),
            ('project', 'GITHUB_WORKSPACE', '/project'), ('output', 'R16_REPAIR_OUTPUT', '')]:
            expected[key] = env[var] + suffix
        self.assertEqual(actual, expected)

    def test_previous_stray_plus_failure_is_rejected_before_build(self):
        body = delivered_command().replace(' build \\\n', ' build \\\n  + \\\n', 1)
        argv, _ = self.capture(body)
        self.assertIn('+', argv)
        with patch.object(sys, 'argv', [argv[1], *argv[2:]]), patch.object(m, 'build') as build, \
                contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit) as error:
                m.main()
        self.assertEqual(error.exception.code, 2)
        build.assert_not_called()


if __name__ == '__main__':
    unittest.main()
