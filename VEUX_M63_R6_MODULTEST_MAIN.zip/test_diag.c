#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
typedef uint8_t u8;
struct ufs_hba { int id; };
struct device { int id; };
struct device_attribute { int id; };
#define QUERY_DESC_MAX_SIZE 255
#define QUERY_DESC_HDR_SIZE 2
#define QUERY_DESC_IDN_STRING 5
#define QUERY_DESC_IDN_DEVICE 0
#define DEVICE_DESC_PARAM_SN 22
#define PAGE_SIZE 4096
#define ARRAY_SIZE(a) (sizeof(a)/sizeof((a)[0]))
#define DEFINE_SPINLOCK(l) int l
#define spin_lock_irqsave(l,f) do { (f)=1; assert(!(*(l))++); } while (0)
#define spin_unlock_irqrestore(l,f) do { assert((f)==1 && (*(l))--==1); } while (0)
#define scnprintf snprintf
#define kfree free
#define DEVICE_ATTR_RO(name)
static int stacks, descriptor_err, source_index=3, len, reported_len;
static u8 descriptor[255];
static void dump_stack(void) { stacks++; }
static char *bin2hex(char *dst, const u8 *src, size_t n)
{
    while(n--) dst+=sprintf(dst,"%02x",*src++);
    return dst;
}
static int ufshcd_read_desc_param(struct ufs_hba *h, int id, int idx, int off, u8 *dest, int n)
{
    assert(id==0 && idx==0 && off==22 && n==1);
    *dest=source_index; return descriptor_err;
}
static int ufshcd_read_string_desc(struct ufs_hba *h, u8 idx, u8 **out, bool ascii)
{
    assert(idx==source_index && !ascii);
    if(len<=0) return len;
    *out=malloc(len); assert(*out); memcpy(*out,descriptor,len);
    return reported_len;
}
#include "diag.inc"
int main(void)
{
    struct ufs_hba h={1}, wrong={2};
    char buf[PAGE_SIZE], expected[1024];
    const char *events[]={"0\n","1\n","2\n","3\n","4\n","5\n","6\n","7\n","8\n","9\n","10\n","11\n"};
    reset_diagnostics(NULL);
    assert(err_state_show(NULL,NULL,buf)==0 && err_reason_show(NULL,NULL,buf)==0);
    reset_diagnostics(&h);
    for (int i=0;i<12;i++) mi_memory_record_error(&h,events[i]);
    mi_memory_record_error(&wrong,"wrong\n");
    assert(stacks==12 && err_state_show(NULL,NULL,buf)==3 && !strcmp(buf,"12\n"));
    assert(err_reason_show(NULL,NULL,buf)>0 && !strcmp(buf,"11\n10\n9\n8\n7\n6\n5\n4\n3\n2\n"));
    descriptor[0]=len=reported_len=6; descriptor[1]=5;
    descriptor[2]=0; descriptor[3]=0xab; descriptor[4]=0x80; descriptor[5]=0xff;
    mi_memory_cache_serial(&h);
    assert(dump_string_desc_serial_show(NULL,NULL,buf)==16 && !strcmp(buf,"serial:00ab80ff\n"));
    for(int i=0;i<8;i++){
        source_index=3; descriptor_err=0; descriptor[0]=len=reported_len=6; descriptor[1]=5; descriptor[3]=0x44;
        struct ufs_hba *owner=&h;
        switch(i){
        case 0: owner=&wrong; break;
        case 1: descriptor_err=-EIO; break;
        case 2: source_index=0; break;
        case 3: len=-ETIMEDOUT; break;
        case 4: reported_len=5; break;
        case 5: descriptor[0]=len=reported_len=5; break;
        case 6: descriptor[1]=0; break;
        case 7: descriptor[0]=len=reported_len=2; break;
        }
        mi_memory_cache_serial(owner);
        assert(dump_string_desc_serial_show(NULL,NULL,buf)==16 && !strcmp(buf,"serial:00ab80ff\n"));
    }
    memset(descriptor,0xaf,sizeof(descriptor)); descriptor[0]=len=reported_len=254; descriptor[1]=5;
    mi_memory_cache_serial(&h); strcpy(expected,"serial:");
    for(int i=0;i<252;i++) strcat(expected,"af");
    strcat(expected,"\n"); assert(dump_string_desc_serial_show(NULL,NULL,buf)==strlen(expected) && !strcmp(buf,expected));
    reset_diagnostics(NULL); assert(err_reason_show(NULL,NULL,buf)==0);
    assert(dump_string_desc_serial_show(NULL,NULL,buf)==8 && !strcmp(buf,"serial:\n"));
    assert(!diag_lock);
    puts("PASS serial formats and descriptor bounds, cached reads, zero events, ten newest reasons, wrong host, reset and unbind");
}
