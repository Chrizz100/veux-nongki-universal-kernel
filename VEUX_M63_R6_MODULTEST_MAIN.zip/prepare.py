"""Apply the previous-console repair to the hash-pinned GitHub R5 source."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
SOURCE = '565a4ba4be1abd695032be802308a5c7b3bb3fba918e17f33cf7888d54902330'
TAR = 'fdc65531a3e70b02e6105f8946056c95203c66f7bb274204d01ecd931de98f87'
CONFIG = 'c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54'
IMAGE = '1e1ab1aec47b3f29b779fb55af90c506720d19439f0c865edfc14ce8c3adf14b'
TARGET = 'fs/pstore/inode.c'
BEFORE = '3c37fd8ecfc8bfea049cd0e18850cd5a0d3b6e6194a411e735396acd728c1a6a'
AFTER = '01163e5460add59299ed9c24905e02a928b734557e5ab58d20ba69803b8970f3'

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def prepare(work, archive, stock):
    require(digest(archive) == SOURCE and digest(stock) == BOOT, 'GitHub R5 source archive and Xiaomi original')
    work.mkdir(parents=True, exist_ok=True)
    src = work / 'src'
    src.mkdir()
    with tempfile.TemporaryDirectory(dir=work) as temp, zipfile.ZipFile(archive) as bundle:
        metadata = json.loads(bundle.read('M63-R5_KERNEL.json'))
        require(metadata['image_sha256'] == IMAGE and metadata['config_sha256'] == CONFIG, 'GitHub R5 metadata')
        config = bundle.read('kernel.config')
        require(hashlib.sha256(config).hexdigest() == CONFIG and
                bundle.read('kbuild-veux.sh') == (ROOT/'tools/kbuild.sh').read_bytes(), 'R5 build inputs')
        tar = Path(bundle.extract('M63-R5-kernel-source.tar.gz', temp))
        require(digest(tar) == TAR, 'R5 source tar')
        subprocess.run(['tar','--no-same-owner','--no-same-permissions','-xzf',tar,'-C',src],check=True)
    patch = ROOT/'last-kmsg.patch'
    require(digest(src/TARGET) == BEFORE, 'R5 pstore source before repair')
    subprocess.run(['git','apply','--check',patch],cwd=src,check=True)
    subprocess.run(['git','apply',patch],cwd=src,check=True)
    require(digest(src/TARGET) == AFTER, 'R6 pstore source after repair')
    (work/'out').mkdir()
    (work/'out/.config').write_bytes(config)
    (work/'baseline.config').write_bytes(config)
    shutil.copyfile(stock,work/'boot.img')
    evidence=work/'evidence'
    evidence.mkdir()
    proof={'base_run':45209223790,'source_archive_sha256':SOURCE,'source_tar_sha256':TAR,'config_sha256':CONFIG,
           'changed_files':{TARGET:{'before':BEFORE,'after':AFTER,'patch_sha256':digest(patch)}}}
    (evidence/'Quellstand.json').write_text(json.dumps(proof,indent=2)+'\n')

if __name__=='__main__':
    prepare(*(Path(arg).resolve() for arg in sys.argv[1:]))
