"""Compare loader-visible exports, versions and providers to the original Xiaomi binaries."""

import collections
import csv
import hashlib
import json
from pathlib import Path
import struct
import sys
from vendor import read_module


def check(value, message):
    if not value:
        raise ValueError(message)


def exports(image, symbols, is_stock):
    from mi_memory_image import Linked

    obj = Linked(image, symbols, is_stock, None, None)
    result = {}
    for kind in ("", "_gpl", "_gpl_future", "_unused", "_unused_gpl"):
        start, end = (obj.names[p + "___ksymtab" + kind] for p in ("__start", "__stop"))
        crc, crc_end = (
            obj.names[p + "___kcrctab" + kind] for p in ("__start", "__stop")
        )
        check(
            (end - start) % 24 == 0 and (end - start) // 24 == (crc_end - crc) // 4,
            "Export table lengths",
        )
        last = ""
        for slot in range(start, end, 24):
            symbol = obj.string(obj.ptr(slot + 8))
            check(symbol > last and symbol not in result, "Ambiguous export " + symbol)
            last = symbol
            result[symbol] = (struct.unpack_from("<I", image, crc)[0], kind)
            crc += 4
    return result


def module_table(vendor):
    root = vendor / "lib/modules"
    ref = json.loads(Path(__file__).with_name("vendor-ranges.json").read_text())
    for name, meta in ref["files"].items():
        check(
            hashlib.sha256((vendor / name.lstrip("/")).read_bytes()).hexdigest()
            == meta["sha256"],
            "Factory file " + name,
        )
    mods = {p.name: read_module(p) for p in sorted(root.glob("*.ko"))}
    check(
        len(mods) == 37 and len(set(d["vermagic"] for d in mods.values())) == 1,
        "QGKI module set",
    )
    dep = {}
    for line in (root / "modules.dep").read_text().splitlines():
        module, deps = line.split(":", 1)
        dep[Path(module).name] = {Path(n).name for n in deps.split()}
    check(set(mods) == set(dep), "modules.dep coverage")
    load = {
        p
        for p in (root / "modules.load").read_text().splitlines()
        if p and not p.startswith("#")
    }
    check(load == set(mods), "modules.load coverage")
    providers = {}
    for mod, info in mods.items():
        for sym, crc in info["exports"].items():
            check(sym not in providers, "Conflicting factory modules " + sym)
            providers[sym] = (mod, crc)
    return mods, dep, providers


def contract(exports, modules, dependencies, vendors):
    collisions = {s: vendors[s][0] for s in sorted(exports.keys() & vendors.keys())}
    imports = {}
    for name, meta in modules.items():
        for sym, crc in meta["imports"].items():
            if sym in vendors:
                provider, value = vendors[sym]
                check(
                    provider in dependencies[name],
                    f"{name} missing dependency {provider} for {sym}",
                )
                imports[name, sym] = (provider, value, "module")
            elif sym in exports:
                value, kind = exports[sym]
                imports[name, sym] = ("vmlinux", value, kind)
            else:
                imports[name, sym] = ("unresolved", None, None)
    return collisions, imports


def run(boot, image, sysmap, vendor, result, upstream, symvers=None):
    sys.path.insert(0, str(upstream.resolve()))
    from check import BOOT, STOCK_IMAGE, REL
    from memory_image import stock_symbols, mapped_symbols

    raw = boot.read_bytes()
    stock = raw[4096 : 4096 + struct.unpack_from("<I", raw, 8)[0]]
    check(
        hashlib.sha256(raw).hexdigest() == BOOT
        and hashlib.sha256(stock).hexdigest() == STOCK_IMAGE,
        "Exact Xiaomi boot/Image identity",
    )
    stock_exp = exports(stock, stock_symbols(stock), True)
    exp = exports(image.read_bytes(), mapped_symbols(sysmap), False)
    if symvers:
        sv = {
            name: int(crc, 16)
            for crc, name, owner, *_ in (
                line.split() for line in symvers.read_text().splitlines()
            )
            if owner == "vmlinux"
        }
        check(
            sv == {sym: v[0] for sym, v in exp.items()},
            "Module.symvers and linked ARM64 export table disagree",
        )
    mods, deps, providers = module_table(vendor)
    check(
        all(
            d["vermagic"] == REL + " SMP preempt mod_unload modversions aarch64"
            for d in mods.values()
        ),
        "Factory vermagic",
    )
    stock_conf, baseline = contract(stock_exp, mods, deps, providers)
    check(not stock_conf, "Collisions in factory reference")
    check(
        all(
            baseline[mod, sym][1] == crc
            for mod, d in mods.items()
            for sym, crc in d["imports"].items()
        ),
        "Inconsistent QGKI Stock reference",
    )
    collisions, candidate = contract(exp, mods, deps, providers)
    bad = [
        dict(module=m, symbol=s, stock=original, candidate=candidate[m, s])
        for (m, s), original in baseline.items()
        if candidate[m, s] != original
    ]
    rows = [(m, s, v, candidate[m, s]) for (m, s), v in sorted(baseline.items())]
    with result.with_suffix(".csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            (
                "module",
                "symbol",
                "stock_owner",
                "stock_crc",
                "stock_license_table",
                "candidate_owner",
                "candidate_crc",
                "candidate_license_table",
            )
        )
        for m, s, expected, actual in rows:
            writer.writerow(
                [
                    m,
                    s,
                    expected[0],
                    hex(expected[1]),
                    expected[2],
                    actual[0],
                    "" if actual[1] is None else hex(actual[1]),
                    actual[2],
                ]
            )
    report = dict(
        stock_boot_sha256=BOOT,
        stock_image_sha256=STOCK_IMAGE,
        candidate_image_sha256=hashlib.sha256(image.read_bytes()).hexdigest(),
        vendor_partition_sha256=json.loads(
            Path(__file__).with_name("vendor-ranges.json").read_text()
        )["vendor_sha256"],
        modules=len(mods),
        imports=len(baseline),
        unique_imports=len({s for m, s in baseline}),
        factory_exports=sum(len(d["exports"]) for d in mods.values()),
        stock_collisions=0,
        candidate_collisions=len(collisions),
        affected_modules=sorted(set(collisions.values())),
        collisions=collisions,
        stock_provider_counts=dict(
            collections.Counter(v[0] for v in baseline.values())
        ),
        provider_or_crc_errors=bad,
        passed=not collisions and not bad,
        device_pass=False,
    )
    result.write_text(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(
        f"{len(mods)} modules / {len(baseline)} imports / {len(collisions)} duplicate exports / {len(bad)} provider, CRC or license table differences"
    )
    return report


if __name__ == "__main__":
    report = run(*(Path(arg) for arg in sys.argv[1:]))
    if not report["passed"]:
        sys.exit(1)
