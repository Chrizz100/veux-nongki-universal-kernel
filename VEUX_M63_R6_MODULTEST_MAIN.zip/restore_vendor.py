"""Fetch and verify just the original firmware data needed for the QGKI module check."""

import bz2
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import lzma
from pathlib import Path
import sys
import tempfile
from urllib.request import Request, urlopen

OTA = "OS1.0.12.0.TKCMIXM/miui_VEUXGlobal_OS1.0.12.0.TKCMIXM_c42114b47d_13.0.zip"
OTA_SIZE = 4020559092
BLOCK = 4096


def fetch(op):
    start, length = op["offset"], op["length"]
    end = start + length - 1
    errors = []
    for host in ("cdnorg", "bigota", "hugeota", "bn"):
        url = f"https://{host}.d.miui.com/{OTA}?range={start}-{length}"
        req = Request(
            url,
            headers={"Range": f"bytes={start}-{end}", "Accept-Encoding": "identity"},
        )
        try:
            with urlopen(req, timeout=40) as response:
                if (
                    response.status != 206
                    or response.headers.get("Content-Range")
                    != f"bytes {start}-{end}/{OTA_SIZE}"
                ):
                    raise ValueError("incorrect HTTP range")
                raw = response.read(length + 1)
            if len(raw) != length or hashlib.sha256(raw).hexdigest() != op["sha256"]:
                raise ValueError("OTA operation SHA-256 mismatch")
            dat = {0: lambda b: b, 1: bz2.decompress, 8: lzma.decompress}[op["type"]](
                raw
            )
            if len(dat) != sum(n * BLOCK for _, n in op["extents"]):
                raise ValueError("Incorrect decompressed length")
            return op["extents"], dat
        except (OSError, ValueError) as err:
            errors.append(str(err))
    raise RuntimeError(f"Xiaomi OTA at {start}: " + ", ".join(errors))


def restore(dest):
    ref = json.loads(Path(__file__).with_name("vendor-ranges.json").read_text())
    dest.mkdir(parents=True, exist_ok=True)
    with (
        tempfile.TemporaryFile(dir=dest) as part,
        ThreadPoolExecutor(max_workers=6) as pool,
    ):
        for extents, dat in pool.map(fetch, ref["operations"]):
            idx = 0
            for block, count in extents:
                size = count * BLOCK
                part.seek(block * BLOCK)
                part.write(dat[idx : idx + size])
                idx += size
        for absolute, meta in ref["files"].items():
            data = bytearray((meta["size"] + BLOCK - 1) // BLOCK * BLOCK)
            for logical, physical, count in meta["extents"]:
                part.seek(physical * BLOCK)
                chunk = part.read(count * BLOCK)
                if len(chunk) != count * BLOCK:
                    raise ValueError("Incomplete extent " + absolute)
                data[logical * BLOCK : (logical + count) * BLOCK] = chunk
            del data[meta["size"] :]
            if hashlib.sha256(data).hexdigest() != meta["sha256"]:
                raise ValueError("Xiaomi file digest " + absolute)
            target = dest / absolute.lstrip("/")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    print(
        f"{len(ref['files'])} verified Xiaomi files, {sum(op['length'] for op in ref['operations'])} downloaded bytes"
    )


if __name__ == "__main__":
    restore(Path(sys.argv[1]))
