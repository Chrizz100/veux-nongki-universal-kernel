"""Read the Millet ABI, hook registrations and UFS report entry from both linked ARM64 images."""
import hashlib
import json
from pathlib import Path
import re
import struct
import sys
import tempfile

tools, stock_path, image_path, sysmap, clang, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(tools.resolve()))
from check import BOOT, STOCK_IMAGE, require, sha
from memory_image import mapped_symbols, stock_symbols
from mi_memory_image import Linked, MILLET
from providers import exports

binder_hooks = {
    "binder_alloc_new_buf_locked_hook": "mi_binder_alloc_new_buf_locked",
    "binder_reply_hook": "mi_binder_replay",
    "binder_trans_hook": "mi_binder_transaction",
    "binder_wait_for_work_hook": "mi_binder_wait_for_work",
    "binder_preset_hook": "mi_get_hhead_and_lock",
}
signal_hook = "do_send_sig_info_hook"
all_hooks = {**binder_hooks, signal_hook: "millet_sig"}
exports_expected = ("binder_warn_ahead_space", "frozen_uid_min", "init_millet_subsystem",
                    "millet_sendmsg", "millet_sendto_user", "millet_sig", "oem_register_binder_hook",
                    "query_binder_app_stat", "register_millet_hook", "unregister_millet_hook")
vendors = ["WDC","TOSHIBA","KIOXIA","SAMSUNG","MICRON","SKhynix"]
net_hooks = ["pkg_ip4_in","pkg_ip6_in","pkg_ip4_out","pkg_ip6_out"]
def calls(link, insns, name):
    hits = []
    for i, (_, op, arg) in enumerate(insns):
        if op in ("b","bl") and arg.startswith("0x") and name in link.funcs.get(int(arg,16), ()):
            hits.append(i)
    return hits

def constant_before(insns, index, reg):
    for _,op,arg in reversed(insns[max(0,index-22):index]):
        if op in ("bl","blr"): break
        if arg.startswith(reg+", "):
            found=re.fullmatch(reg+r", #(0x[\da-f]+|\d+)",arg)
            if op=="mov" and found:
                return int(found[1],0)
            break
    raise ValueError("Unresolved immediate "+reg)

def validate(link, symbols):
    byname = set().union(*link.funcs.values())
    require(set(MILLET) <= byname,"15 required Millet functions")
    info = {"functions":list(MILLET),"sysfs":link.groups()}
    assert sum(len(group) for group in info["sysfs"].values())==10
    init = link.access("millet_init")
    call, = calls(link,init,"__netlink_kernel_create")
    channel = constant_before(init,call,"w1")
    message = link.access("millet_sendto_user")
    call, = calls(link,message,"__nlmsg_put")
    msg_size = constant_before(message,call,"w4")
    receive = link.access("recv_handler")
    receive_sizes=[]
    for i,(_,op,_) in enumerate(receive):
        if op=="blr":
            try: receive_sizes.append(constant_before(receive,i,"w1"))
            except ValueError: pass
    require(channel==30 and msg_size==144 and 80 in receive_sizes,"Millet Netlink protocol and message sizes")
    require({"millet","millet_stat","version"}<=set(link.reachable_strings("millet_init")),"Millet proc entries")
    require(len(calls(link,init,'proc_mkdir'))==1 and len(calls(link,init,'proc_create'))==2,"Millet proc registrations")
    assert struct.unpack_from('<I',link.image,link.names['millet_v'])[0]==1
    assert struct.unpack_from('<I',link.image,link.names['frozen_uid_min'])[0]==10000
    info.update(netlink=channel, out_bytes=msg_size, in_bytes=80, version=1, min_app_uid=10000)
    for name in all_hooks:
        off=link.names['__tracepoint_'+name]
        require(link.string(link.ptr(off))==name,"Named tracepoint "+name)
    if link.stock:
        base=link.names['interests']
        for i,(name,func) in enumerate(binder_hooks.items()):
            require(link.string(link.ptr(base+32*i))==name,"OEM Binder tracepoint registration table "+name)
            link.callback(link.ptr(base+32*i+8),func)
        sig=link.access('sig_mod_init')
        (sig_i,)=calls(link,sig,'tracepoint_probe_register')
        link.callback(link.register_address(sig[:sig_i],'x1'),'millet_sig')
    else:
        for fn, mapping in [('init_binder_gki',binder_hooks),('sig_mod_init',{signal_hook:'millet_sig'})]:
            code=link.access(fn)
            registered=calls(link,code,'tracepoint_probe_register')
            require(len(registered)==len(mapping),fn+" registrations")
            for i,(name,func) in zip(registered,mapping.items()):
                window=code[max(0,i-8):i]
                require(link.register_address(window,'x0')==link.names['__tracepoint_'+name],"Registered "+name)
                link.callback(link.register_address(window,'x1'),func)
    info['tracepoints_and_callbacks']=all_hooks
    table=link.names['pkg_nf_ops']
    network=[]
    for i,func in enumerate(net_hooks):
        off=table+40*i
        link.callback(link.ptr(off),func)
        family,number,priority=struct.unpack_from('<B3xIi',link.image,off+24)
        network.append([func,family,number,priority])
    require([r[1:3] for r in network]==[[2,1],[10,1],[2,3],[10,3]],'IPv4 and IPv6 hook families and directions')
    info['netfilter']=network
    functions=['hr_show']
    if not link.stock:
        for n in ('mi_ufs_health_report','collect_hr'):
            if n in byname: functions.append(n)
    strings=[s for n in functions for s in link.reachable_strings(n)]
    require([s for s in strings if s in vendors]==vendors,'Vendor selection in linked UFS report')
    require({'NOT SUPPORTED %s\n','Fail to get hr, err is: %d\n'}<=set(strings),'OEM UFS return cases')
    info['ufs_vendors']=vendors
    s=exports(link.image,symbols,link.stock)
    info['millet_kernel_exports']={n:[f'{s[n][0]:08x}',s[n][1]] for n in exports_expected}
    return info

require(sha(stock_path)==BOOT,'Pinned Xiaomi original')
raw=stock_path.read_bytes()
factory=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
require(hashlib.sha256(factory).hexdigest()==STOCK_IMAGE,'Pinned Xiaomi kernel')
image=image_path.read_bytes()
with tempfile.TemporaryDirectory() as tmp:
    orig=stock_symbols(factory)
    built=mapped_symbols(sysmap)
    baseline=validate(Linked(factory,orig,True,clang,Path(tmp)),orig)
    current=validate(Linked(image,built,False,clang,Path(tmp)),built)
    discrepancies={k:(baseline[k],v) for k,v in current.items() if baseline[k]!=v}
    require(not discrepancies,'Differences in linked OEM interfaces: '+json.dumps(discrepancies,sort_keys=True))
    output.write_text(json.dumps(dict(reference_boot_sha256=BOOT, reference_image_sha256=STOCK_IMAGE,
        image_sha256=hashlib.sha256(image).hexdigest(), verified_against_stock=current,
        device_pass=False,flash_allowed=False),indent=2)+'\n')
print('PASS 10 read-only storage attributes, 6 UFS manufacturers, 15 Millet functions, 6 tracepoints, 4 network callbacks and 10 OEM export CRCs')
