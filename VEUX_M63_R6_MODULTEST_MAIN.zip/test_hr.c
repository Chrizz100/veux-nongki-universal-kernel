/* Positive OEM report transactions and cleanup with an in-memory SCSI device. */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#define PAGE_SIZE 4096
#define GFP_KERNEL 0
#define HZ 250
#define RQF_PM 1
#define DMA_FROM_DEVICE 2
#define DMA_TO_DEVICE 1
#define DMA_NONE 3
#define INQUIRY 0x12
#define READ_BUFFER 0x3c
#define QUERY_DESC_IDN_HEALTH 9
#define QUERY_DESC_HEALTH_DEF_SIZE 0x25
#define pr_err(...) ((void)0)
#define scnprintf snprintf
#define spin_lock_irqsave(lock, flags) do { (void)(lock); (flags) = 0; } while (0)
#define spin_unlock_irqrestore(lock, flags) do { (void)(lock); (void)(flags); } while (0)

struct Scsi_Host { bool eh_noresume; int host_lock; };
struct ufs_hba { struct Scsi_Host *host; };
struct scsi_device { const char *vendor; };
static struct Scsi_Host host;
static struct ufs_hba hba = { &host };
static struct scsi_device target;
static int refs, pm, allocations, calls, descriptors, fail_call;
static bool miss, offline, no_memory, fail_pm;
static char ops[12];
static char *bin2hex(char *p, const void *data, size_t size)
{
	static const char hex[] = "0123456789abcdef";
	const unsigned char *d = data;
	while (size--) { *p++ = hex[*d >> 4]; *p++ = hex[*d++ & 15]; }
	return p;
}
static struct scsi_device *scsi_device_lookup(struct Scsi_Host *h,int c,int id,int lun)
{
	assert(h == &host && !c && !id && !lun);
	if (miss) return NULL;
	refs++; return &target;
}
static int scsi_device_online(struct scsi_device *s) { assert(s == &target); return !offline; }
static void scsi_device_put(struct scsi_device *s) { assert(s == &target && refs == 1); refs--; }
static void *kzalloc(size_t size,int flags) { (void)flags; if (no_memory) return NULL; allocations++; return calloc(1,size); }
static void kfree(void *ptr) { free(ptr); allocations--; }
static int scsi_autopm_get_device(struct scsi_device *s) { assert(s == &target && refs == 1); if (fail_pm) return -EIO; pm++; return 0; }
static void scsi_autopm_put_device(struct scsi_device *s) { assert(s == &target && pm == 1); pm--; }
static int ufshcd_read_desc_param(struct ufs_hba *h,int id,int index,int offset,void *buf,int size)
{
	assert(h == &hba && id == QUERY_DESC_IDN_HEALTH && index == 0 && offset == 0 && size == QUERY_DESC_HEALTH_DEF_SIZE);
	memset(buf,0xb2,size); descriptors++; return 0;
}
static int scsi_execute(struct scsi_device *s,unsigned char *cmd,int dir,void *buf,int len,
			void *sense,void *hdr,int timeout,int retries,int flags,int req_flags,void *resid)
{
	char op=0;
	assert(s == &target && pm == 1 && refs == 1 && host.eh_noresume);
	assert(!sense && !hdr && !resid && timeout == 30*HZ && retries == 3 && !flags && req_flags == RQF_PM);
	if (cmd[0]==INQUIRY) {
		assert(len==512 && cmd[1]==0x69 && cmd[2]==0xc0 && cmd[3]==2 && !cmd[4]); op='T';
	} else if (cmd[0]==READ_BUFFER && cmd[1]==1) {
		assert(len==512 && !memcmp(cmd+2,(unsigned char[]){1,0x7d,0x9c,0x69,0,2,0},7)); op='W';
	} else if (cmd[0]==0xd0) {
		assert(len==76 && cmd[1]==3 && cmd[2]==0x58 && cmd[11]==0x2c); op='H';
	} else if (cmd[0]==0xc0 && cmd[1]==0x40) {
		assert(cmd[4]==1 && ((cmd[5]==0xc && cmd[15]==28 && len==28) || (cmd[5]==0xa && cmd[15]==76 && len==76))); op=len==28?'S':'N';
	} else if (cmd[0]==0xc0) {
		assert(!len && !buf && dir==DMA_NONE);
		assert(cmd[1]==0 || cmd[1]==1 || cmd[1]==3); op=cmd[1]==0?'E':cmd[1]==1?'X':'P';
	} else if (cmd[0]==0x3b) {
		assert(dir==DMA_TO_DEVICE && len==44 && cmd[1]==0xe1 && cmd[8]==44);
		assert(!memcmp(buf,(unsigned char[]){0xfe,0x40,0,0x10,1},5)); op='M';
	} else {
		assert(cmd[0]==READ_BUFFER && cmd[1]==0xc1 && cmd[7]==2 && len==512); op='R';
	}
	assert(calls+1<(int)sizeof(ops)); ops[calls++]=op;
	if (calls==fail_call) return 1;
	if (op!='M' && dir!=DMA_NONE) {
		assert(dir==DMA_FROM_DEVICE); memset(buf,0xab,len);
		if (op=='T') ((unsigned char *)buf)[1]=0xc0;
	}
	return 0;
}
#include "health-body.inc"
static void exercise(const char *vendor,const char *sequence,int bad,int expected)
{
	char buf[PAGE_SIZE+1]={0};
	bool saved=host.eh_noresume;
	target.vendor=vendor; fail_call=bad; calls=0; descriptors=0; memset(ops,0,sizeof(ops));
	ssize_t size=mi_ufs_health_report(&hba,buf);
	assert(!refs && !pm && !allocations && host.eh_noresume==saved);
	assert(strcmp(ops,sequence)==0);
	if (expected>=0) assert(size==expected);
	else if (expected==-100) assert(size>0 && !strcmp(buf,"Fail to get hr, err is: -5\n"));
	else if (expected==-101) assert(size>0 && !strcmp(buf,"NOT SUPPORTED OTHER\n"));
	else assert(size==expected);
	if (size==1025) {
		assert(buf[1024]=='\n' && buf[1025]==0);
		if (*sequence=='S') assert(!strncmp(buf,"ab",2) && !strncmp(buf+56,"00",2) && !strncmp(buf+256,"ab",2));
		if (*sequence=='H') assert(descriptors==1 && !strncmp(buf,"b2",2) && !strncmp(buf+256,"ab",2));
		for (int i=0;i<1024;i++) assert(strchr("0123456789abcdef",buf[i]) && buf[i]);
	}
}
int main(void)
{
	exercise("WDC","W",0,1025); exercise("TOSHIBA","T",0,1025); exercise("KIOXIA","T",0,1025);
	exercise("SAMSUNG","SENX",0,1025); exercise("SAMSUNG","SEPENX",2,1025);
	exercise("MICRON","MR",0,1025); exercise("SKhynix","H",0,1025); exercise("OTHER","",0,-101);
	exercise("SAMSUNG","S",1,-100); exercise("MICRON","M",1,-100); exercise("MICRON","MR",2,-100);
	exercise("WDC","W",1,-100); exercise("TOSHIBA","T",1,-100);
	miss=true; exercise("SAMSUNG","",0,-ENODEV); miss=false;
	offline=true; exercise("SAMSUNG","",0,-ENODEV); offline=false;
	no_memory=true; exercise("SAMSUNG","",0,-ENOMEM); no_memory=false;
	fail_pm=true; exercise("SAMSUNG","",0,-EIO); fail_pm=false;
	host.eh_noresume=true; exercise("SAMSUNG","SENX",0,1025);
	puts("PASS 18 UFS health cases, all six OEM names, report layout and balanced references");
	return 0;
}
