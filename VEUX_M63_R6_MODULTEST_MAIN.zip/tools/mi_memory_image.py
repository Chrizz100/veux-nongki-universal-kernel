"""Read the groups and callback pointers of the VEUX memory driver from linked ARM64 code."""
import json
import re
import struct
import sys
import tempfile
from pathlib import Path

from check import BOOT, require, sha
from memory_image import Code, mapped_symbols, stock_symbols

BASE = 0xffffffc010080000
DDR = {'ddr_size','ddr_id','ddr_vendor'}
UFS = {'dump_device_desc','dump_health_desc','show_hba','dump_string_desc_serial','err_state','err_reason'}
UFS.add('hr')
MILLET = ('millet_init','millet_pkg_init','millet_hs_init','init_millet_binder_drv',
          'millet_sendmsg','millet_sig','millet_can_attach','mi_binder_reply_hook','mi_binder_trans_hook',
          'mi_binder_wait4_hook','mi_query_binder_st_hook','mi_binder_overflow_hook','pkg_ip4_in','pkg_ip6_in','hs_recv_hook')

def canonical(name):
    return name.split('$')[0].split('.llvm.')[0]

class Linked:
    def __init__(self, image, symbols, stock, tc, tmp):
        self.image = image
        self.stock = stock
        self.names = {canonical(n):a for a, kind, n in symbols if '$' not in n and '.cfi_jt' not in n}
        self.code = Code(image, symbols, tc, tmp)
        self.funcs = {}
        for a, kind, n in symbols:
            if kind.lower() in ('t','w') and not n.startswith('$') and '.cfi_jt' not in n:
                self.funcs.setdefault(a,set()).add(canonical(n))
        self.reloc = {}
        if stock:
            tag = struct.pack('<Q',1027)
            offset = image.find(tag,8)
            while offset >= 0:
                if offset % 8 == 0 and offset + 16 <= len(image):
                    loc, _, target = struct.unpack_from('<3Q',image,offset-8)
                    if BASE <= loc < BASE+len(image) and BASE <= target < BASE+len(image):
                        self.reloc[loc-BASE] = target-BASE
                offset = image.find(tag,offset+1)
    def ptr(self, pos):
        value, = struct.unpack_from('<Q',self.image,pos)
        if not value:
            return self.reloc.get(pos)
        require(BASE<=value<BASE+len(self.image),'Unexpected pointer at '+hex(pos))
        return value-BASE
    def string(self, pos):
        end = self.image.index(0,pos,pos+256)
        return self.image[pos:end].decode('ascii')
    def callback(self, pos, expected):
        if expected in self.funcs.get(pos, ()):
            return
        word, = struct.unpack_from('<I',self.image,pos)
        require(word>>26==5,'ARM64 callback trampoline for '+expected)
        delta = word & 0x3ffffff
        target = pos + (delta-(1<<26) if delta&(1<<25) else delta)*4
        require(expected in self.funcs.get(target,()),'Incorrect callback for '+expected)
    def access(self, name):
        if name in self.code.names:
            return self.code.instructions(name)
        matches = [key for key in self.code.names if canonical(key)==name]
        require(len(matches)==1,'Missing or ambiguous function '+name)
        return self.code.instructions(matches[0])
    def addresses(self, instructions):
        addresses = []
        reg = {}
        for _,op,args in instructions:
            fields = args.split(', ')
            dest = fields[0]
            if op in ('adr','adrp'):
                reg[dest] = int(fields[1],16)
                if op=='adr':
                    addresses.append(reg[dest])
            elif op=='add' and len(fields)==3 and fields[1] in reg and fields[2].startswith('#'):
                reg[dest]=reg[fields[1]]+int(fields[2][1:],0)
                addresses.append(reg[dest])
            elif op in ('bl','blr'):
                for i in range(19):
                    reg.pop('x'+str(i),None)
            elif op not in ('cmp','tst','str','strb','strh','stp','cbz','cbnz','tbz','tbnz','br','b','ret') and re.fullmatch(r'[xw]\d+',dest):
                reg.pop('x'+dest[1:],None)
        return addresses
    def register_address(self, instructions, register):
        # PC-relative argument immediately preceding the registration call.
        value=None
        for _,op,args in instructions:
            fields=args.split(', ')
            if op in ('bl','blr'):
                value=None
            elif fields[0]==register:
                if op in ('adrp','adr'):
                    value=int(fields[1],16)
                elif op=='add' and fields[1]==register and fields[2].startswith('#') and value is not None:
                    value+=int(fields[2][1:],0)
                else:
                    value=None
        require(value is not None,'Unresolved function argument '+register)
        return value
    def groups(self):
        array = self.names['memory_sysfs_groups']
        result = {}
        for i in range(3):
            group = self.ptr(array+8*i)
            if group is None:
                require(i==2,'Missing memory attribute group')
                break
            group_name = self.string(self.ptr(group))
            table = self.ptr(group+24)
            attrs = {}
            for j in range(12):
                attr = self.ptr(table+8*j)
                if attr is None:
                    break
                name = self.string(self.ptr(attr))
                require(name not in attrs and self.ptr(attr+24) is None,'Repeated or writable attribute '+name)
                mode, = struct.unpack_from('<H',self.image,attr+8)
                require(mode==0o444,'Mode '+name)
                self.callback(self.ptr(attr+16),name+'_show')
                attrs[name] = '0444'
            require(group_name not in result,'Repeated group')
            result[group_name]=attrs
        require(set(result)=={'ddr','ufshcd0'} and set(result['ddr'])==DDR,'DDR group')
        require(set(result['ufshcd0'])==UFS,'UFS group')
        return result
    def reachable_strings(self, name):
        result=[]
        for addr in self.addresses(self.access(name)):
            raw=self.image[addr:addr+200].split(b'\0')[0]
            if raw and all(32<=n<127 or n in (9,10) for n in raw):
                result.append(raw.decode('ascii'))
        return result
    def contract(self):
        init=self.access('mi_memory_sysfs_init')
        init_refs=self.addresses(init)
        require(self.names['memory_sysfs_groups'] in init_refs,'Init never references the groups')
        init_strings=self.reachable_strings('mi_memory_sysfs_init')
        require({'mi_memory','mi_memory_device','mi_memory_module','mv'}<=set(init_strings),'Memory init registration strings')
        procs = {'proc_create','proc_create_single_data'}
        calls = [i for i,(_,op,arg) in enumerate(init) if op=='bl' and self.funcs.get(int(arg,16),set()) & procs]
        require(len(calls)==1 and any(o=='mov' and a=='w1, #365' for _,o,a in init[max(0,calls[0]-12):calls[0]]),'/proc/mv registration mode')
        params=init[max(0,calls[0]-12):calls[0]]
        require(self.string(self.register_address(params,'x0'))=='mv','Incorrect proc entry name')
        handler=self.register_address(params,'x3')
        if self.stock:
            require(handler==self.names['mv_proc_fops'],'Incorrect Stock file operations')
            self.callback(self.ptr(handler+112),'mv_proc_open')
            opened=self.access('mv_proc_open')
            call,=[i for i,(_,op,a) in enumerate(opened) if op=='bl' and 'single_open' in self.funcs.get(int(a,16),())]
            handler=self.register_address(opened[:call],'x1')
        self.callback(handler,'mv_proc_show')
        formats=self.reachable_strings('mv_proc_show')
        require('D: 0x%02x %d\n' in formats and any(s in formats for s in ('U: 0x%04x %d %s %s\n','U: 0x%04x %d %.15s %.5s\n')),'/proc/mv formats')
        hba=[s for s in self.reachable_strings('show_hba_show') if ' = ' in s]
        require(len(hba)==len(set(hba))==40,'Expected 40 distinct fields in show_hba: '+str(len(hba)))
        return dict(groups=self.groups(),proc={'mv':'0555'},hba_fields=hba)
    def device_fields(self):
        if self.stock:
            # Stock uses an array of 35 records (name pointer, int offset, int width).
            pointers=self.addresses(self.access('dump_device_desc_show'))
            bases=[p for p in pointers if p in self.reloc and self.string(self.reloc[p])=='bLength']
            require(len(bases)==1,'Stock device descriptor table')
            base=bases[0]
            fields=[struct.unpack_from('<II',self.image,base+16*i+8) for i in range(35)]
        else:
            base=self.names['device_fields']
            fields=[struct.unpack_from('<BB',self.image,base+16*i+8) for i in range(35)]
        return [(self.string(self.ptr(base+16*i)),off,width) for i,(off,width) in enumerate(fields)]

def main():
    boot, image, sysmap, tc, output = map(Path,sys.argv[1:])
    require(sha(boot)==BOOT,'Xiaomi factory image identity')
    raw=boot.read_bytes()
    factory=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    with tempfile.TemporaryDirectory() as tmp:
        stock=Linked(factory,stock_symbols(factory),True,tc,Path(tmp))
        candidate=Linked(image.read_bytes(),mapped_symbols(sysmap),False,tc,Path(tmp))
        stock_info=stock.contract()
        rebuilt=candidate.contract()
        require(stock_info['hba_fields']==rebuilt['hba_fields'],'Order or format of UFS controller fields differs')
        fields=stock.device_fields()
        require(fields==candidate.device_fields(),'UFS device descriptor names, offsets or widths differ')
        health_names = ['bLength','bDescriptorType','bPreEOLInfo','bDeviceLifeTimeEstA','bDeviceLifeTimeEstB']
        stock_health = [s for s in stock.reachable_strings('dump_health_desc_show') if s in health_names]
        require(stock_health==health_names,'Stock health descriptor fields')
        base=candidate.names['health_fields']
        health_fields=[(candidate.string(candidate.ptr(base+16*i)), *struct.unpack_from('<BB',candidate.image,base+16*i+8)) for i in range(5)]
        require(health_fields==[(name,i,1) for i,name in enumerate(stock_health)],'Candidate health fields')
        stock_func=set().union(*stock.funcs.values())
        cand_func=set().union(*candidate.funcs.values())
        millet={n:{'stock':n in stock_func,'candidate':n in cand_func} for n in MILLET}
        require(all(v['stock'] and v['candidate'] for v in millet.values()),'Unexpected Stock Millet inventory')
        result={'stock':stock_info,'candidate':rebuilt,'device_descriptor_fields':fields,'health_descriptor_fields':health_fields,'open_ufs':sorted(set(stock_info['groups']['ufshcd0']) - set(rebuilt['groups']['ufshcd0'])),
                'millet':millet,'device_test':False}
        output.write_text(json.dumps(result,indent=2)+'\n')
        print('PASS 10 Stock sysfs callbacks, /proc/mv, HBA fields, UFS descriptors and all 15 Millet functions')
if __name__=='__main__':
    main()
