"""Build a host test from the actual M60 UFS reading and formatting functions."""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

tree = Path(sys.argv[1]) / 'drivers/scsi/ufs'
source = (tree / 'mi-memory.c').read_text()
header = (tree / 'ufs.h').read_text()
parts = []
for tag in ('device_desc_param', 'geometry_desc_param', 'health_desc_param', 'desc_idn'):
    match = re.search(r'enum '+tag+r'\s*\{.*?^};', header, re.S | re.M)
    if not match:
        raise ValueError(tag)
    parts.append(match.group())
for name in ('ddr_capacity', 'ufs_capacity', 'ddr_id', 'ddr_vendor', 'read_descriptor',
             'format_fields', 'descriptor_show', 'mv_proc_show'):
    match = re.search(r'^static [^\n]*\b'+name+r'\(.*?^}', source, re.S | re.M)
    if not match:
        raise ValueError(name)
    parts.append(match.group())
for name in ('mi_memory_bind', 'mi_memory_ready', 'mi_memory_unbind'):
    begin = source.index('void '+name+'(')
    end = source.index('\n}',begin)+2
    parts.append(source[begin:end])
tables = source[source.index('struct mi_field {'):source.index('static int read_descriptor')]
with tempfile.TemporaryDirectory() as folder:
    tmp = Path(folder)
    (tmp/'functions.inc').write_text('\n'.join(parts[:4]+[tables]+parts[4:]))
    exe = tmp/'test-memory'
    subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Werror','-I',str(tmp),
                    str(Path(__file__).with_suffix('.c')),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
