"""Attach every raw stock config delta to a testable subsystem and record linked symbols."""
import csv
import json
import struct
import sys
import tempfile
from pathlib import Path

from check import BOOT, require, sha
from memory_image import Code, mapped_symbols, stock_symbols

# The symbol checks are evidence of named implementations. They do not test behavior.
GROUPS = [
 ('Boot und Speichergerät','MI_UFS_FFU',
  'PMIC-Fehlermerkmal repariert. Der FFU-Pfad mit sechs festen Stock-Regeln und zusätzlichen Partitionsregeln ist offen.'),
 ('Dateisysteme','EROFS_FS_CLUSTER_PAGE_LIMIT EROFS_FS_PCPU_KTHREAD EXFAT_DEBUG_MSG EXFAT_DEFAULT_CODEPAGE EXFAT_DELAYED_SYNC EXFAT_DISCARD EXFAT_KERNEL_DEBUG PASSTHROUGH_SYSTEM',
  'Treiberverhalten für EROFS, exFAT einschließlich Discard sowie die FUSE-Schnittstellen vergleichen.'),
 ('Xiaomi-Speicherverwaltung und Dienste','HAVE_USERSPACE_LOW_MEMORY_KILLER MIHW MILLET',
  'Sechs Speicherattribute und /proc/mv sind im M60-Image prüfbar. Vier UFS-Anzeigen und die Millet-Pfade sind offen.'),
 ('Gerätetreiber','FINGERPRINT INPUT_FINGERPRINT SILEAD_FP SILEAD_FP_PLATFORM SILEAD_FP_SPI QCA_CLD_WLAN SPRD_ROTATION_TASK',
  'Aktive DT-Geräte, tatsächlichen Treiber und Modulbindung vergleichen. Stock deaktiviert die drei Silead-Schalter.'),
 ('Scheduler und Diagnose','PANIC_ON_RT_THROTTLING PANIC_ON_SCHED_BUG PRESS_KEY_TRIGGER_PANIC UBSAN_ALIGNMENT',
  'Diagnose- und Fehlerpfade vergleichen. Stock aktiviert die UBSAN-Ausrichtungsprüfung.'),
 ('Werkzeugkette und Architektur','ANDROID_KABI_RESERVE ANDROID_VENDOR_OEM_DATA CC_HAS_ASM_GOTO_OUTPUT CC_HAS_ASM_INLINE CC_OPTIMIZE_FOR_PERFORMANCE_O3 CC_VERSION_TEXT CC_WERROR CLANG_VERSION COMPAT_VDSO GENERIC_COMPAT_VDSO GENERIC_FIND_FIRST_BIT HAVE_FUTEX_CMPXCHG RELR THUMB2_COMPAT_VDSO TOOLS_SUPPORT_RELR',
  'Compiler, Konfigurationsmerkmale, vDSO, Relokationen und Struktur-ABI unterscheiden. Vendor-Importprüfung deckt CRC und Anbieter ab.'),
 ('Geprüfte Auswirkung im Image','ARM64_LSE_ATOMICS ARM64_USE_LSE_ATOMICS ZRAM_DEF_COMP ZRAM_DEF_COMP_LZ4 ZRAM_DEF_COMP_LZO ZRAM_DEF_COMP_LZORLE ZRAM_DEF_COMP_ZSTD LOCALVERSION LOCALVERSION_AUTO',
  'Die vorhandenen Image-Prüfungen belegen die untersuchten Atomikpfade, den Standardkompressor und die tatsächliche Kernelkennung.'),
]
PROBES = ('qpnp_pon_uvlo_get','qpnp_pon_uvlo_set','ufs_qcom_probe','ufs_ffu','dm_verity_avb_error_handler','verity_ctr','fpc1020_probe',
          'mi_memory_sysfs_init','millet_init','millet_pkg_init','fuse_passthrough_open')


def named_text(rows):
    return {name.split('$')[0].split('.llvm.')[0] for _,kind,name in rows
            if kind.lower() in ('t','w') and '.cfi_jt' not in name}


def main():
    folder, boot, system_map, compiler = map(Path, sys.argv[1:])
    groups = {}
    for group, options, why in GROUPS:
        for opt in options.split():
            key='CONFIG_'+opt
            require(key not in groups,'Duplicate stock row '+key)
            groups[key]=group,why
    with (folder/'Restkonfiguration.csv').open() as file:
        rows=list(csv.DictReader(file,delimiter=';'))
    require(len(rows)==len(groups)==47 and {r['Option'] for r in rows}==groups.keys(),
            'Stock delta grouping must account for every raw config difference')
    with (folder/'Restgruppen.csv').open('w',newline='') as out:
        writer=csv.writer(out,delimiter=';')
        writer.writerow(['Funktionsgruppe','Option','Xiaomi','Kandidat','Prüfstand oder nächste Prüfung'])
        for row in sorted(rows,key=lambda r:(groups[r['Option']][0],r['Option'])):
            group,why=groups[row['Option']]
            writer.writerow([group,row['Option'],row['Xiaomi 5.4.274'],row['M60'],why])
    require(sha(boot)==BOOT,'Stock reference')
    raw=boot.read_bytes()
    image = raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    symbols = stock_symbols(image)
    stock=named_text(symbols)
    candidate=named_text(mapped_symbols(system_map))
    report={name:{'Xiaomi':name in stock,'Kandidat':name in candidate} for name in PROBES}
    with tempfile.TemporaryDirectory() as tmp:
        code = Code(image,symbols,compiler,Path(tmp))
        def direct_calls(caller,callee):
            return [hex(pc) for pc,op,arg in code.instructions(caller)
                    if op=='bl' and int(arg,16)==code.names[callee]]
        paths = {f'{a} -> {b}':direct_calls(a,b) for a,b in
                 [('sd_probe','ufs_ffu'),('ufs_ffu','ufs_scsi_write_buf'),('ufs_ffu','machine_restart')]}
    require(all(paths.values()),'Incomplete Xiaomi UFS reference paths')
    (folder/'Xiaomi-UFS-Aufrufe.json').write_text(json.dumps(paths,indent=2)+'\n')
    (folder/'Subsystem-Symbole.json').write_text(json.dumps(report,indent=2)+'\n')
    print('47/47 differences assigned to',len(GROUPS),'groups')


if __name__=='__main__':
    main()
