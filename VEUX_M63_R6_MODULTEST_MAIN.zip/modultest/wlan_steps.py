"""LLDB command that follows the instructions observed in the original ARM64 driver."""
import lldb

def follow(debugger, command, result, internal_dict):
    target=debugger.GetSelectedTarget()
    proc=target.GetProcess()
    thread=proc.GetSelectedThread()
    first=thread.GetFrameAtIndex(0)
    ret=first.FindRegister('x30').GetValueAsUnsigned() or first.FindRegister('lr').GetValueAsUnsigned()
    if not ret:raise RuntimeError('return address unavailable')
    for _ in range(48):
        frame=thread.GetFrameAtIndex(0)
        pc=frame.GetPC()
        if pc==ret:
            raw=frame.FindRegister('x0').GetValueAsUnsigned() & 0xffffffff
            print('WLAN_RETURN',raw-(1<<32) if raw & (1<<31) else raw)
            return
        ins=target.ReadInstructions(frame.GetPCAddress(),1).GetInstructionAtIndex(0)
        mnemonic=ins.GetMnemonic(target); operands=ins.GetOperands(target)
        values=' '.join(f'{n}={frame.FindRegister(n).GetValue()}' for n in ['x0','x8','x9','x19','x20'])
        print('WLAN_STEP',hex(pc),mnemonic,operands,values)
        thread.StepInstruction(False)
    raise RuntimeError('trace exceeded 48 instructions')

def __lldb_init_module(debugger,internal_dict):
    debugger.HandleCommand('command script add -f wlan_steps.follow wlan-follow')
