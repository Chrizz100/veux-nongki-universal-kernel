/* Invoke Linux finit_module on one file without forcing flags. Return errno. */
.text
.global _start
_start:
    ldr x1, [sp, #16]
    mov x0, #-100
    mov x2, #0
    mov x3, #0
    mov x8, #56
    svc #0
    tbnz x0, #63, 1f
    adr x1, parameters
    mov x2, #0
    mov x8, #273
    svc #0
1:  neg x0, x0
    mov x8, #93
    svc #0
.section .rodata
parameters:
    .asciz ""
