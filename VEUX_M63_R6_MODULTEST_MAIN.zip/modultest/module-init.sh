#!/busybox sh
bb=/busybox
$bb mount -t proc proc /proc || exit 1
$bb mount -t sysfs sysfs /sys || exit 1
: >/results
while read -r module; do
    echo "VEUX_TRY $module" > /dev/console
    /load_one "/vendor/lib/modules/$module"
    rc=$?
    echo "VEUX_RESULT $module $rc" >> /results
done < /order
echo VEUX_RESULTS_BEGIN
$bb cat /results
echo VEUX_RESULTS_END
echo VEUX_LIVE_BEGIN
$bb cat /proc/modules
echo VEUX_LIVE_END
echo VEUX_DMESG_BEGIN
$bb dmesg
echo VEUX_DMESG_END
echo VEUX_MODULES_DONE
$bb poweroff -f
while :; do $bb sleep 1; done
