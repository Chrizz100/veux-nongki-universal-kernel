# M63-R6 auf originalen Xiaomi-Vendormodulen prüfen

Die Datei VEUX_M63_R6_MODULTEST_MAIN.zip gehört als ZIP ins Hauptverzeichnis. Der Workflow VEUX_M63_R6_MODULTEST_NOFLASH.yml gehört unter .github/workflows/. Beide Dateien tragen einen eigenen Namen.

Unter Actions prüft die Voreinstellung `pruefen` das veröffentlichte Boot- und AK3-Paar aus Lauf 45224069479 anhand der fest hinterlegten Prüfsummen. Sie benötigt die GitHub-Artefakte 14842996768 und 14842313486. Die Option `bauen` führt den bestehenden R6-Quellbau einschließlich der bisherigen Kontrollen und des zusätzlichen Modultests aus.

Die Prüfung startet beide Kernel mit identischer ARM64-Testumgebung. Sie ruft für 37 Originalmodule aus Xiaomis OS1.0.12.0.TKCMIXM die native Schnittstelle finit_module ohne Zwangsoptionen auf. Abhängigkeiten stammen aus modules.dep. LLDB verfolgt die erste Initialisierung, liest den Namen des Moduls und beobachtet den Rücksprung. Später hält LLDB im Qualcomm-WLAN-Treiber und verfolgt dessen tatsächlich genommenen Zweig bis zur Rückgabe. Im virtuellen Board ohne Qualcomm-WLAN-Gerät erwartet der Test bei beiden Kerneln 36 geladene Module und beim WLAN-Modul EINVAL mit ENODEV aus der Plattformregistrierung.

Kernelkennung und Originalmodule werden vor der Messung geprüft. Die Ergebnisse enthalten getrennte Konsolen- und LLDB-Protokolle und die Rückgabe jedes Moduls. Die Freigabe für einen Gerätetest bleibt separat. Die mitgelieferte Datei gen_init_cpio.c stammt aus dem Kernelquellstand und steht unter GPL-2.0.
