"""Load the original 37 Xiaomi modules and trace their initialization with LLDB."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import socket
import struct
import subprocess
import sys
import tempfile
import time
from zipfile import ZipFile

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
sys.path[:0] = [str(KIT), str(KIT / 'tools'), str(KIT / 'diagnose')]
from fruehstart import STOCK_BOOT, STOCK_IMAGE, unpack_boot
from memory_image import mapped_symbols, stock_symbols
from providers import module_table

def require(value, message):
    if not value:
        raise RuntimeError(message)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def ramdisk(boot):
    kernel_size, size = struct.unpack_from('<II', boot, 8)
    start = (4096 + kernel_size + 4095) & -4096
    return boot[start:start+size]

def inputs(work, target_hash):
    stock_path = work / 'boot.img'
    pair = work / 'pair'
    manifest = json.loads((pair/'M63-R6-Stock-Boot.json').read_text())
    require(manifest['static_boot_pass'] and not manifest['device_pass'] and not manifest['flash_allowed'], 'NOFLASH-Paar erwartet')
    boot_path = pair / 'VEUX_M63-R6_boot_NOFLASH.img'
    stock = unpack_boot(stock_path, STOCK_BOOT, STOCK_IMAGE)
    kernel = unpack_boot(boot_path, manifest['boot_sha256'], manifest['kernel_sha256'])
    if target_hash:
        require(digest(kernel) == target_hash, 'Unerwarteter GitHub-Kernel')
    require(ramdisk(stock_path.read_bytes()) == ramdisk(boot_path.read_bytes()), 'Xiaomi-Ramdisk weicht ab')
    ak = pair / 'VEUX_M63-R6_AK3_NOFLASH.zip'
    require(digest(ak.read_bytes()) == manifest['ak3_sha256'], 'AK3-Prüfsumme')
    with ZipFile(ak) as z:
        require(z.read('Image') == kernel, 'AK3 und boot.img enthalten unterschiedliche Kernel')
    reference = json.loads((work/'evidence/M63-R6_KERNEL.json').read_text())
    require(digest(kernel) == reference['image_sha256'] and reference['release'] == '5.4.274-qgki-g82179e362f33',
            'Kernel im Bauprotokoll')
    return [('Xiaomi', stock, stock_symbols(stock)), ('R6', kernel, mapped_symbols(work/'out/System.map'))]

def prepare_guest(work, tmp, clang):
    vendor = work/'stock-vendor'
    module_table(vendor)  # Check original OEM hashes, filenames, exports and vermagic.
    modules = vendor/'lib/modules'
    deps = {}
    for line in (modules/'modules.dep').read_text().splitlines():
        key, values = line.split(':')
        deps[Path(key).name] = [Path(p).name for p in values.split()]
    order = []
    def add(name, parents):
        if name in order:
            return
        require(name not in parents, 'Zyklische Modulabhängigkeit')
        for dep in deps[name]:
            add(dep, parents | {name})
        order.append(name)
    for name in (modules/'modules.load').read_text().splitlines():
        if name and not name.startswith('#'):
            add(name, set())
    require(len(order) == 37 and set(order) == set(deps), 'Unvollständiger QGKI-Modulsatz')
    (tmp/'order').write_text('\n'.join(order)+'\n')
    with ZipFile(KIT/'ak3-tools.zip') as archive:
        (tmp/'busybox').write_bytes(archive.read('tools/busybox'))
    subprocess.run([clang,'--target=aarch64-linux-gnu','-fuse-ld=lld','-nostdlib','-static','-Wl,-e,_start',
                    HERE/'load_one.S','-o',tmp/'load_one'], check=True)
    subprocess.run(['cc','-O2',HERE/'gen_init_cpio.c','-o',tmp/'gen_init_cpio'],check=True)
    entries = ['dir /dev 0755 0 0','nod /dev/console 0600 0 0 c 5 1','nod /dev/null 0666 0 0 c 1 3',
               'dir /proc 0755 0 0','dir /sys 0755 0 0','dir /vendor 0755 0 0','dir /vendor/lib 0755 0 0',
               'dir /vendor/lib/modules 0755 0 0',f'file /init {HERE/"module-init.sh"} 0755 0 0',
               f'file /busybox {tmp/"busybox"} 0755 0 0',f'file /load_one {tmp/"load_one"} 0755 0 0',
               f'file /order {tmp/"order"} 0444 0 0']
    entries += [f'file /vendor/lib/modules/{n} {modules/n} 0444 0 0' for n in order]
    (tmp/'cpio.list').write_text('\n'.join(entries)+'\n')
    with (tmp/'probe.cpio').open('wb') as out:
        subprocess.run([tmp/'gen_init_cpio','-t','0',tmp/'cpio.list'],stdout=out,check=True)
    return order

def lldb_script(symbols, port, elf):
    names = ['__arm64_sys_finit_module','load_module','do_init_module','do_one_initcall','__icnss_register_driver']
    pcs = {}
    for name in names:
        candidates = {0xffffffc010080000 + off for off, kind, n in symbols
                      if kind in 'tT' and '.cfi_jt' not in n and n.split('$')[0]==name}
        require(len(candidates)==1, 'Uneindeutiger Haltepunkt '+name)
        pcs[name] = candidates.pop()
    commands = ['settings set target.default-arch aarch64',f'target create --arch aarch64 {json.dumps(str(elf))}',
                'settings set plugin.process.gdb-remote.packet-timeout 30',f'gdb-remote 127.0.0.1:{port}']
    for number, name in enumerate(names[:4], 1):
        commands += [f'breakpoint set --hardware --address {pcs[name]:#x}','continue',
                     f'script print("MOD_PC {name}",hex(lldb.frame.GetPC()))','register read pc x0 x1 x30']
        if name=='do_init_module':
            commands += ['script print("FIRST_MODULE",lldb.process.ReadCStringFromMemory(lldb.frame.FindRegister("x0").GetValueAsUnsigned()+24,56,lldb.SBError()))']
        commands += [f'breakpoint delete {number}']
    commands += ['script caller=lldb.frame.FindRegister("x30").GetValueAsUnsigned() or lldb.frame.FindRegister("lr").GetValueAsUnsigned(); assert caller; lldb.debugger.HandleCommand("breakpoint set --hardware --address " + hex(caller))',
                 'continue','script print("FIRST_RETURN",lldb.frame.FindRegister("x0").GetValueAsUnsigned())',
                 'breakpoint delete 5',f'breakpoint set --hardware --address {pcs[names[-1]]:#x}','continue',
                 'script print("MOD_PC __icnss_register_driver",hex(lldb.frame.GetPC()))',
                 'script print("WLAN_OWNER",lldb.process.ReadCStringFromMemory(lldb.frame.FindRegister("x1").GetValueAsUnsigned()+24,56,lldb.SBError()))',
                 'breakpoint delete 6','command script import '+json.dumps(str(HERE/'wlan_steps.py')),
                 'wlan-follow','process detach','quit']
    return commands, pcs

def run_guest(label, image, symbols, tmp, dest, order, args):
    out = dest/label
    out.mkdir(exist_ok=True)
    kernel = tmp/(label+'.Image')
    kernel.write_bytes(image)
    with socket.socket() as s:
        s.bind(('127.0.0.1',0))
        port = s.getsockname()[1]
    commands, expected_pcs = lldb_script(symbols, port, tmp/'load_one')
    script = out/'Haltepunkte.lldb'
    script.write_text('\n'.join(commands)+'\n')
    pidfile = tmp/(label+'.pid')
    cmd=[args.qemu]
    if args.qemu_data:
        cmd+=['-L',args.qemu_data]
    cmd+=['-no-user-config','-nodefaults','-machine','virt-8.2,gic-version=3,virtualization=on',
          '-cpu','cortex-a55','-smp','4','-accel','tcg','-m','1024','-serial','stdio','-display','none',
          '-monitor','none','-nic','none','-no-reboot','-initrd',tmp/'probe.cpio','-kernel',kernel,
          '-append','console=ttyAMA0 nokaslr loglevel=3 log_buf_len=2M rdinit=/init panic=-1',
          '-pidfile',pidfile,'-S','-gdb',f'tcp:127.0.0.1:{port}']
    uart=out/'Konsole.log'
    with uart.open('wb') as f,subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT) as proc:
        try:
            end=time.monotonic()+15
            while not pidfile.exists() and time.monotonic()<end and proc.poll() is None:
                time.sleep(.05)
            require(pidfile.exists(), 'QEMU-Start fehlgeschlagen')
            with (out/'LLDB.log').open('wb') as trace:
                subprocess.run([args.lldb,'-b','-s',script],stdout=trace,stderr=subprocess.STDOUT,timeout=150,check=True)
            end=time.monotonic()+90
            while proc.poll() is None and time.monotonic()<end:
                if b'VEUX_MODULES_DONE' in uart.read_bytes():
                    break
                time.sleep(.15)
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
    log=uart.read_text(errors='replace')
    debug=(out/'LLDB.log').read_text(errors='replace')
    pcs={n:int(v,16) for n,v in re.findall(r'^MOD_PC (\w+) (0x[0-9a-f]+)$',debug,re.M)}
    require(pcs==expected_pcs and re.search(r'^FIRST_MODULE btpower$',debug,re.M)
            and re.search(r'^FIRST_RETURN 0$',debug,re.M), 'Modul-Init nicht im Debugger bestätigt')
    require(re.search(r'^WLAN_OWNER wlan$',debug,re.M) and re.search(r'^WLAN_RETURN -19$',debug,re.M),
            'Abweichender Rückgabepfad des WLAN-Treibers')
    require('VEUX_MODULES_DONE' in log and not re.search(r'Kernel panic - not syncing|Oops:|Unable to handle kernel',log),
            'Abbruch des Modul-Ladetests')
    errnos={n:int(e) for n,e in re.findall(r'^VEUX_RESULT ([\w.-]+) (\d+)$',log,re.M)}
    require(list(errnos)==order, 'Unvollständige Modulreihe')
    live_text=log.split('VEUX_LIVE_BEGIN\n')[1].split('VEUX_LIVE_END')[0]
    live=sorted(re.findall(r'^([\w-]+) \d+ \d+ .*? Live ',live_text,re.M))
    expected_live=sorted(Path(n).stem.replace('-','_') for n,errno in errnos.items() if errno==0)
    require(live==expected_live, 'Erfolgreich gemeldete Module fehlen in /proc/modules')
    data={'kernel_sha256':digest(image),'initramfs_sha256':digest((tmp/'probe.cpio').read_bytes()),
          'pcs':{n:hex(v) for n,v in pcs.items()},'finit_module_errno':errnos,'live':live,
          'icnss_wlan_return':-19,'first_module':'btpower','first_init_return':0}
    (out/'Ergebnis.json').write_text(json.dumps(data,indent=2)+'\n')
    return data

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('work',type=Path)
    p.add_argument('out',type=Path)
    p.add_argument('--qemu',default='qemu-system-aarch64')
    p.add_argument('--qemu-data')
    p.add_argument('--clang',default='clang')
    p.add_argument('--lldb',default='lldb')
    p.add_argument('--candidate-hash')
    args=p.parse_args()
    args.out.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='veux-modules-') as tmp:
        tmp=Path(tmp)
        order=prepare_guest(args.work,tmp,args.clang)
        rows={n:run_guest(n,img,table,tmp,args.out,order,args) for n,img,table in inputs(args.work,args.candidate_hash)}
    factory=rows['Xiaomi']
    fails={n:rc for n,rc in factory['finit_module_errno'].items() if rc}
    require(fails=={'qca_cld3_wlan.ko':22} and len(factory['live'])==36, 'Xiaomi-Kontrolle fehlgeschlagen')
    require(rows['R6']['live']==factory['live'] and rows['R6']['finit_module_errno']==factory['finit_module_errno']
            and rows['R6']['initramfs_sha256']==factory['initramfs_sha256'], 'R6 weicht vom Xiaomi-Test ab')
    result={'images':{n:r['kernel_sha256'] for n,r in rows.items()},'tested_modules':len(order),'live_modules':36,
            'wlan_syscall_errno':22,'wlan_icnss_result':-19,'device_pass':False,'flash_allowed':False}
    (args.out/'Stockvergleich.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
