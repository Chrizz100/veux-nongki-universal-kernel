"""Resolve reason strings passed to the recorder in both linked UFS drivers."""

import bisect
import collections
from pathlib import Path
import re
import struct
import sys
import tempfile
import json


def arguments(linked, recorder, arg):
    # Find direct BL / tail calls in executable code, then examine just their callers.
    first = linked.names["_text"]
    end = linked.names["_etext"]
    addresses = sorted(linked.code.starts)
    names = {a: n for n, a in linked.code.names.items()}
    target = linked.code.names[recorder]
    sites = collections.defaultdict(set)
    for pos in range(first, end, 4):
        (v,) = struct.unpack_from("<I", linked.image, pos)
        if v >> 26 not in (5, 37):
            continue
        offset = v & 0x3FFFFFF
        if offset & (1 << 25):
            offset -= 1 << 26
        if pos + 4 * offset != target:
            continue
        caller = names[addresses[bisect.bisect_right(addresses, pos) - 1]]
        if "ufshcd" in caller:
            sites[caller].add(pos)
    found = []
    for name, points in sites.items():
        registers = {}
        for pc, op, args in linked.code.instructions(name):
            fields = args.split(", ")
            if pc in points:
                ptr = registers.get(arg)
                if ptr is None:
                    raise ValueError(f"{name} unresolved reason at {pc:x}")
                reason = linked.string(ptr)
                if len(reason) > 31 or not reason.endswith("\n"):
                    raise ValueError(f"{name} invalid UFS reason")
                found.append((name, hex(pc), reason))
            if op in ("bl", "blr"):
                for i in range(19):
                    registers.pop("x" + str(i), None)
            elif op in ("adr", "adrp"):
                registers[fields[0]] = int(fields[1], 16)
            elif op == "mov" and len(fields) == 2 and fields[1] in registers:
                registers[fields[0]] = registers[fields[1]]
            elif (
                op == "add"
                and len(fields) == 3
                and fields[1] in registers
                and fields[2].startswith("#")
            ):
                registers[fields[0]] = registers[fields[1]] + int(fields[2][1:], 0)
            elif op not in (
                "stp",
                "str",
                "strb",
                "strh",
                "cmp",
                "tst",
                "ccmp",
                "cbnz",
                "cbz",
                "tbnz",
                "tbz",
                "b",
                "ret",
                "br",
            ) and re.fullmatch(r"[wx][0-9]+", fields[0]):
                registers.pop("x" + fields[0][1:], None)
    return found


def main(upstream, boot, out, tc, result):
    sys.path.insert(0, str(upstream.resolve()))
    from check import BOOT, sha
    from memory_image import stock_symbols, mapped_symbols
    from mi_memory_image import Linked

    if sha(boot) != BOOT:
        raise ValueError("Factory boot image identity")
    b = boot.read_bytes()
    original = b[4096 : 4096 + struct.unpack_from("<I", b, 8)[0]]
    image = (out / "arch/arm64/boot/Image").read_bytes()
    with tempfile.TemporaryDirectory() as folder:
        stock = Linked(
            original, stock_symbols(original), True, tc.resolve(), Path(folder)
        )
        candidate = Linked(
            image, mapped_symbols(out / "System.map"), False, tc.resolve(), Path(folder)
        )
        baseline = arguments(stock, "ufsdbg_set_err_state", "x0")
        actual = arguments(candidate, "mi_memory_record_error", "x1")
    if len(baseline) != 20 or len({r for _, _, r in baseline}) != 17:
        raise ValueError(f"Unexpected original call sites {len(baseline)}")

    def event_counts(rows):
        return collections.Counter(
            (n.split("$")[0].split(".llvm.")[0], r) for n, _, r in rows
        )

    if event_counts(baseline) != event_counts(actual):
        raise ValueError("UFS error reasons differ")
    result.write_text(
        json.dumps(
            dict(stock_calls=baseline, candidate_calls=actual, distinct_reasons=17),
            indent=2,
        )
        + "\n"
    )
    print(
        f"PASS 17 original UFS reasons, {len(baseline)} Stock and {len(actual)} rebuilt call sites"
    )


if __name__ == "__main__":
    main(*(Path(arg) for arg in sys.argv[1:]))
