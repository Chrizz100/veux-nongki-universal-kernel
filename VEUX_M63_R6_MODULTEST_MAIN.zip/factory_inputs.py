"""Verify cached OEM inputs or restore them from the same Xiaomi OTA."""

from pathlib import Path
import sys
import tempfile
import zipfile
from prepare import BOOT, digest
from providers import module_table
from restore_vendor import restore


def main(tools, dest):
    dest.mkdir(parents=True, exist_ok=True)
    boot = dest / "boot.img"
    if not boot.is_file() or digest(boot) != BOOT:
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder)
            bundle = tools / "layout/m45-base.zip"
            if (
                digest(bundle)
                != "6c31c1189deb4a5c0909f2737dc87e1c395dcd25c8abd96a70764e8efb5e5bcd"
            ):
                raise ValueError("Original stock extractor")
            with zipfile.ZipFile(bundle) as archive:
                for member in ("stock_ota.py", "stock-ota.json"):
                    archive.extract(member, base)
            sys.path.insert(0, str(base))
            from stock_ota import restore as restore_boot

            restore_boot(boot)
    if digest(boot) != BOOT:
        raise ValueError("Xiaomi boot SHA-256")
    target = dest / "stock-vendor"
    try:
        module_table(target)
    except (OSError, ValueError):
        with tempfile.TemporaryDirectory(dir=dest) as temp:
            stage = Path(temp) / "verified"
            restore(stage)
            module_table(stage)
            if target.exists():
                target.rename(Path(temp) / "replaced")
            stage.rename(target)
    print("PASS exact Xiaomi boot, vendor modules and loader inputs")


if __name__ == "__main__":
    main(*(Path(arg).resolve() for arg in sys.argv[1:]))
