"""Read exports, imports and module metadata from ELF64 little-endian ARM64 .ko files."""

import hashlib
import struct


def read_module(path):
    raw = path.read_bytes()
    if raw[:7] != b"\x7fELF\x02\x01\x01" or struct.unpack_from("<HH", raw, 16) != (
        1,
        183,
    ):
        raise ValueError("Expected ARM64 relocatable ELF: " + str(path))
    (start,) = struct.unpack_from("<Q", raw, 40)
    step, count, index = struct.unpack_from("<HHH", raw, 58)
    rows = [
        struct.unpack_from("<IIQQQQIIQQ", raw, start + i * step) for i in range(count)
    ]

    def data(row):
        pos, size = row[4:6]
        return raw[pos : pos + size]

    def name(table, i):
        return table[i : table.index(0, i)].decode("ascii")

    names = data(rows[index])
    sections = {name(names, row[0]): row for row in rows}
    symbols = sections[".symtab"]
    strings = data(rows[symbols[6]])
    exported = set()
    crcs = {}
    undefined = set()
    for off, info, other, sec, val, size in struct.iter_unpack(
        "<IBBHQQ", data(symbols)
    ):
        key = name(strings, off)
        if (
            key.startswith("__ksymtab_")
            and sec < len(rows)
            and name(names, rows[sec][0])
            in (
                "__ksymtab",
                "__ksymtab_gpl",
                "__ksymtab_gpl_future",
                "__ksymtab_unused",
                "__ksymtab_unused_gpl",
            )
        ):
            exported.add(key[len("__ksymtab_") :])
        elif key.startswith("__crc_") and sec == 0xFFF1:
            crcs[key[len("__crc_") :]] = val
        elif not sec and info >> 4 == 1:
            undefined.add(key)
    if exported != set(crcs):
        raise ValueError(
            "Unpaired export CRC: " + str(path) + str(exported ^ set(crcs))
        )
    imports = {}
    for crc, n in struct.iter_unpack("<Q56s", data(sections["__versions"])):
        key = n.split(b"\0", 1)[0].decode("ascii")
        if key in imports:
            raise ValueError("Duplicate import " + key)
        imports[key] = crc
    if undefined - set(imports):
        raise ValueError(
            "Unversioned required symbols " + str(undefined - set(imports))
        )
    modinfo = {}
    for info in data(sections[".modinfo"]).strip(b"\0").split(b"\0"):
        if b"=" in info:
            k, v = info.decode("utf-8", "replace").split("=", 1)
            modinfo.setdefault(k, []).append(v)
    return dict(
        sha256=hashlib.sha256(raw).hexdigest(),
        name=modinfo.get("name", [path.stem])[0],
        vermagic=modinfo["vermagic"][0],
        depends=modinfo.get("depends", [""])[0].split(","),
        imports=imports,
        exports=crcs,
    )
