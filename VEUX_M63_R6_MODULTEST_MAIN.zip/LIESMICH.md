# POCO X4 Pro 5G · M63-R6

M63-R5 aus GitHub-Lauf 45209223790 enthält die zwei Scheduler-Reparaturen. Im Vergleich mit dem Originalkernel aus HyperOS OS1.0.12.0.TKCMIXM fehlt in R5 die frühere Kernelkonsole unter `/proc/last_kmsg`. R6 stellt diese Leseansicht auf die von ramoops gesicherte Konsole wieder her. Die Änderung betrifft `fs/pstore/inode.c`. Die Kernelkennung lautet `5.4.274-qgki-g82179e362f33`.

## GitHub-Bau

Die geschlossene `VEUX_M63_R6_MAIN.zip` gehört ins Hauptverzeichnis. Die Datei `VEUX_M63_R6_LAST_KMSG_NOFLASH.yml` gehört unter `.github/workflows/`. Der Workflow kann unter Actions auf main manuell gestartet werden. Er prüft die SHA-256 des Baupakets, lädt den gesicherten GitHub-R5-Quellstand und erhält dessen Konfiguration und Buildbefehl.

## Nachweis

Xiaomi registriert die Datei mit Modus 0444. Die neue Leseansicht gibt die bereits gesicherte vorherige Konsole aus dem eingehängten pstore zurück. Dabei gelten die bestehenden Zugriffsprüfungen für den Speicher und sein Konsolenprotokoll. Im Test ist der Eintrag vor dem Einhängen leer. Nach einem simulierten Warmstart vergleicht der Test die vollständigen Bytes beider Lesewege mit einem eindeutigen Marker. Er prüft auch parallele Leser, erneutes Einhängen und das Entfernen einer alten Testaufzeichnung im Gast. Mit Besitzer und Dateirechten aus Xiaomis init.rc vergleicht die Android-System-UID beide Dateien. Eine separate unprivilegierte UID muss am Lesen scheitern. Die unveränderten Originalimages von Xiaomi und R5 sind die Positiv- und Negativkontrolle. LLDB setzt Haltepunkte auf konkrete Kerneladressen. Die Messwerte und seriellen Mitschnitte stehen im Nachweisartefakt unter `last-kmsg/`.

Der Workflow prüft außerdem die beiden WALT-Sperren, den frühen Android-Start, die 37 originalen QGKI-Module und die Firmware-Eingaben. Er liefert das Boot-Image und ein AK3-Prüfpaket mit Kennzeichnung NOFLASH. Der Gerätestart auf einem physischen POCO ist offen.
