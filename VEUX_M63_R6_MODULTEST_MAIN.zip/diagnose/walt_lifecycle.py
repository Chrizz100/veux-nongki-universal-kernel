"""Check scheduler accounting calls against the shipped Xiaomi kernel."""
import json
from pathlib import Path
import struct
import sys
import tempfile

from fruehstart import STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from memory_image import Code, mapped_symbols, stock_symbols

EDGES = {
    'sched_fork': ('init_new_task_load',),
    'wake_up_new_task': ('mark_task_starting',),
    'finish_task_switch': ('walt_task_dead',),
    'set_task_cpu': ('fixup_busy_time',),
    '__schedule': ('walt_update_task_ravg',) * 3,
    'sched_cpu_starting': ('set_window_start',),
    'copy_process': ('free_task_load_ptrs',),
    'enqueue_task_fair': ('sched_update_nr_prod',),
    'dequeue_task_fair': ('sched_update_nr_prod',),
    'enqueue_task_rt': ('sched_update_nr_prod',),
    'dequeue_task_rt': ('sched_update_nr_prod',),
    'enqueue_task_dl': ('sched_update_nr_prod',),
    'dequeue_task_dl': ('sched_update_nr_prod',),
    'enqueue_task_stop': ('sched_update_nr_prod',),
    'dequeue_task_stop': ('sched_update_nr_prod',),
}

QUEUE_HELPERS = {
    'enqueue_task_rt': 'enqueue_top_rt_rq',
    'dequeue_task_rt': 'enqueue_top_rt_rq',
    'dequeue_task_dl': '__dequeue_task_dl',
}


def account_calls(image, symbols, tools, temp):
    code = Code(image, symbols, tools, temp)
    ends, paths = {}, {}
    names = {address: name for name, address in code.names.items()}
    def callees(caller):
        return [names.get(int(operand, 16)) for _, op, operand in code.instructions(caller)
                if op in ('bl', 'b') and operand.startswith('0x')]
    for caller, expected in EDGES.items():
        children = callees(caller)
        found = [[caller, name] for name in children if name in expected]
        helper = QUEUE_HELPERS.get(caller)
        if not found and helper and helper in children:
            found = [[caller, helper, name] for name in callees(helper) if name in expected]
        ends[caller] = [path[-1] for path in found]
        paths[caller] = found
    data = {n: struct.unpack_from('<I', image, pos)[0] for pos, _, n in symbols
            if n in {'sysctl_walt_rtg_cfs_boost_prio', 'min_cfs_boost_prio', 'max_cfs_boost_prio'}}
    return dict(calls=ends, paths=paths, rtg_priority=data)


def main(work, target):
    out = work / 'out'
    stock = unpack_boot(work / 'boot.img', STOCK_BOOT, STOCK_IMAGE)
    image = (out / 'arch/arm64/boot/Image').read_bytes()
    with tempfile.TemporaryDirectory() as path:
        tmp, tools = Path(path), work / 'clang/bin'
        factory = account_calls(stock, stock_symbols(stock), tools, tmp)
        built = account_calls(image, mapped_symbols(out / 'System.map'), tools, tmp)
    result = dict(factory=factory, candidate=built, factory_sha256=STOCK_IMAGE, candidate_sha256=digest(image))
    target.write_text(json.dumps(result, indent=2) + '\n')
    require(all(factory['calls'][caller] == list(required) for caller, required in EDGES.items()),
            'Unexpected scheduler call structure in the stock reference')
    require(built['calls'] == factory['calls'] and built['rtg_priority'] == factory['rtg_priority'],
            'Linked WALT accounting calls or RTG bounds differ from Xiaomi')
    print('PASS linked WALT task and runqueue accounting against Xiaomi')


if __name__ == '__main__':
    main(*(Path(x).resolve() for x in sys.argv[1:]))
