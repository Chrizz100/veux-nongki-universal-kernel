#!/busybox sh
# SPDX-License-Identifier: MIT
set -eu
/busybox mount -t pstore pstore /store
/busybox mount -t proc proc /proc
if [ -e /store/console-ramoops-0 ] && [ -e /store/unused-ramoops-0 ]; then
    echo "VEUX_PSTORE_FAIL duplicate console records"
    exit 1
fi
for name in console-ramoops-0 unused-ramoops-0; do
    if [ -r "/store/$name" ]; then
        if /busybox grep -Fq 'VEUX_PSTORE_PREVIOUS_BOOT_6341' "/store/$name"; then
            echo "VEUX_PSTORE_READ $name"
            exec /busybox sleep 300
        fi
        echo "VEUX_PSTORE_FAIL missing marker in $name"
        exit 1
    fi
done
exercise_queue() {
    n=0
    while [ "$n" -lt 12 ]; do
        /busybox true
        n=$((n + 1))
    done
    /busybox chrt -f 1 /busybox true
}
exercise_queue &
first=$!
exercise_queue &
second=$!
wait "$first"
wait "$second"
echo VEUX_WALT_QUEUE_OK
echo '<4>VEUX_PSTORE_PREVIOUS_BOOT_6341' > /dev/kmsg
echo VEUX_PSTORE_WROTE
echo b > /proc/sysrq-trigger
exec /busybox sleep 300
