// SPDX-License-Identifier: MIT
// Move this test process between online CPUs using the ordinary userspace ABI.
#include <asm-generic/unistd.h>
.text
.global _start
_start:
    adr x19, masks
    mov x20, #8
    sub sp, sp, #16
1:
    ldrb w3, [x19], #1
    str x3, [sp]
    mov x0, #0
    mov x1, #8
    mov x2, sp
    mov x8, #__NR_sched_setaffinity
    svc #0
    cbnz x0, 2f
    subs x20, x20, #1
    b.ne 1b
    mov x0, #0
    b 3f
2:
    mov x0, #1
3:
    mov x8, #__NR_exit
    svc #0
.section .rodata
masks:
    .byte 1,64,2,128,1,64,2,128
