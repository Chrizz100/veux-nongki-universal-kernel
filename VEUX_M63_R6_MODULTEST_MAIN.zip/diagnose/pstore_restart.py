"""Verify the previous boot's console file by rebooting the same ARM64 VM."""
import os
from pathlib import Path
import re
import selectors
import subprocess
import tempfile
import time

from fruehstart import digest, require
from pstore_vm import command as fixture_command

HERE = Path(__file__).resolve().parent


def run(image, out, log_path, expected_name, geometry):
    with tempfile.TemporaryDirectory() as directory:
        command = fixture_command(image, out, Path(directory), geometry, HERE / "pstore-init.sh")
        data = bytearray()
        with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT) as proc:
            try:
                with selectors.DefaultSelector() as ready:
                    ready.register(proc.stdout, selectors.EVENT_READ)
                    deadline = time.monotonic() + 75
                    while time.monotonic() < deadline:
                        if not ready.select(timeout=0.5):
                            continue
                        chunk = os.read(proc.stdout.fileno(), 32768)
                        if not chunk:
                            break
                        data.extend(chunk)
                        if (re.search(rb'(?m)^VEUX_PSTORE_READ [\w-]+\r?\n', data)
                                or b'VEUX_PSTORE_FAIL ' in data or re.search(rb'Kernel panic - not syncing:[^\r\n]+\r?\n', data)
                                or data.count(b'VEUX_PSTORE_WROTE') > 1 or len(data) > 2_000_000):
                            break
            finally:
                proc.kill()
                proc.wait()
                log_path.write_bytes(data)
        if expected_name is None:
            require(b'Kernel panic - not syncing: Fatal exception in interrupt' in data
                    and re.search(rb'pc\s*:\s*update_task_rq_cpu_cycles\+', data)
                    and b'walt_update_task_ravg+' in data and b'scheduler_tick+' in data
                    and b'Registered ramoops as persistent store backend' not in data
                    and b'Run /init as init process' not in data, 'Missing early M62 negative control')
            return dict(walt_panic_before_ramoops=True, serial_sha256=digest(data), serial_log=log_path.name)
        read = re.findall(rb'(?m)^VEUX_PSTORE_READ ([\w-]+)\r?$', data)
        boots = len(re.findall(rb'Linux version 5\.4\.274', data))
        wrote = list(re.finditer(rb'(?m)^VEUX_PSTORE_WROTE\r?$', data))
        restarts = list(re.finditer(rb'(?im)sysrq:\s*Resetting\r?$', data))
        read_pos = data.find(b'VEUX_PSTORE_READ ')
        require(boots == 2 and len(wrote) == 1 and len(restarts) == 1 and
                len(re.findall(rb'(?m)^VEUX_WALT_QUEUE_OK\r?$', data)) == 1 and
                wrote[0].start() < restarts[0].start() < read_pos and
                read == [expected_name.encode()] and b'Kernel panic - not syncing' not in data,
                f'Previous-boot marker check failed in {log_path}')
        return dict(boots=boots, previous_boot_marker_read=True, fair_and_fifo_workload=True,
                    filename=read[0].decode(),
                    serial_sha256=digest(data), serial_log=log_path.name)
