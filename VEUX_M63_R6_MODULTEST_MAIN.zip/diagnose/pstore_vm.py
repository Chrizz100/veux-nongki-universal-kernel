"""Build the shared ARM64 persistent-console restart fixture."""
from pathlib import Path
import shutil
import struct
import subprocess
import zipfile
from fruehstart import COMMAND_LINE, MACHINE, require

HERE = Path(__file__).resolve().parent
RAMOOPS = """
/ {
    reserved-memory {
        #address-cells = <2>;
        #size-cells = <2>;
        ranges;
        ramoops@70000000 {
            compatible = "ramoops";
            reg = <0 0x70000000 0 %#x>;
            console-size = <%#x>;
            pmsg-size = <%#x>;
        };
    };
};
"""


def command(image, out, temp, geometry, guest_init):
    qemu = shutil.which('qemu-system-aarch64')
    require(qemu, 'qemu-system-aarch64 missing')
    dtc = out / 'scripts/dtc/dtc'
    base = [qemu, '-no-user-config', '-nodefaults', '-cpu', 'cortex-a76',
            '-accel', 'tcg', '-smp', '2', '-m', '1024M', '-display', 'none',
            '-monitor', 'none', '-nic', 'none', '-seed', '1']
    dtb = temp / 'virt.dtb'
    subprocess.run(base + ['-machine', f'{MACHINE},dumpdtb={dtb}'], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    dts = subprocess.check_output([dtc, '-qqq', '-I', 'dtb', '-O', 'dts', dtb])
    _, size = struct.unpack('>QQ', bytes.fromhex(geometry['reg']))
    require(set(geometry) == {'reg', 'compatible', 'console-size', 'pmsg-size'},
            'Unexpected layout in the VEUX pstore test')
    region = RAMOOPS % (size, int(geometry['console-size'], 16), int(geometry['pmsg-size'], 16))
    subprocess.run([dtc, '-qqq', '-I', 'dts', '-O', 'dtb', '-o', dtb],
                   input=dts + region.encode(), check=True)
    with zipfile.ZipFile(HERE.parent / 'ak3-tools.zip') as archive:
        (temp / 'busybox').write_bytes(archive.read('tools/busybox'))
    manifest = temp / 'initramfs.list'
    manifest.write_text(
        'dir /dev 0755 0 0\nnod /dev/console 0600 0 0 c 5 1\nnod /dev/null 0666 0 0 c 1 3\n'
        'nod /dev/kmsg 0600 0 0 c 1 11\ndir /store 0755 0 0\ndir /proc 0755 0 0\n'
        f'file /init {guest_init} 0755 0 0\n'
        f'file /busybox {temp / "busybox"} 0755 0 0\n')
    initrd = temp / 'initramfs.cpio'
    with initrd.open('wb') as stream:
        subprocess.run([out / 'usr/gen_init_cpio', '-t', '0', manifest], stdout=stream, check=True)
    return base + ['-machine', MACHINE, '-serial', 'stdio', '-kernel', str(image),
                      '-initrd', str(initrd), '-dtb', str(dtb), '-append', COMMAND_LINE]
