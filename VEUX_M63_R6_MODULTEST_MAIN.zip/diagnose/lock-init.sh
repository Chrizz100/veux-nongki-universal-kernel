#!/bin/busybox sh
/bin/busybox mount -t proc proc /proc || exit 1
/bin/affinity || exit 1
for group in 1 2 3; do
    for worker in 1 2 3 4 5 6 7 8 9 10 11 12; do
        (i=0; while [ "$i" -lt 1800 ]; do i=$((i + 1)); done) &
    done
    wait
done
echo VEUX_RUNQUEUE_PID1_DONE
echo b > /proc/sysrq-trigger
exec /bin/busybox sleep 30
