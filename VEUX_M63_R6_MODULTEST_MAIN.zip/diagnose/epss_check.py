"""Check the linked Qualcomm/WALT startup paths and run stock, previous and repaired arm64 Images."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tools'))
from fruehstart import STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot
from memory_image import mapped_symbols, stock_symbols
from mi_memory_image import Linked
from pstore_stock import device_tree, signed_regions

PREVIOUS_BOOT = 'bbefaee4d6f92ed23e31c5105a3e7040dbad726329c4f2319a736740ad5ee1e5'
PREVIOUS_IMAGE = '46c925b15bd240c6f59bd961306c9f1eae6b67920e3384bf5f631cbc51a4b8a1'

def call_site(link, body, symbol):
    address = link.names[symbol]
    matches = [i for i, (_, op, arg) in enumerate(body)
               if op in ('bl', 'b') and arg.startswith('0x') and int(arg, 16) == address]
    require(len(matches) == 1, 'Expected one direct call to '+symbol)
    return matches[0]

def provider_pointer(link, body, registration):
    # Both reference toolchains pass the single-field callback structure on the stack.
    _, op, arg = body[registration-1]
    stack = re.fullmatch(r'x0, sp, #(\d+)', arg)
    require(op=='add' and stack, 'Expected stack structure argument for the counter registration')
    stores = [(i, re.fullmatch(r'(x\d+), \[sp, #'+stack[1]+r'\]',arg))
              for i, (_, op, arg) in enumerate(body[:registration]) if op=='str']
    stores = [(i,m[1]) for i,m in stores if m]
    require(len(stores)==1, 'Expected a single initialization of the callback field')
    i, register = stores[0]
    return link.register_address(body[:i], register)

def inspect(data, symbols, stock, compiler, temp):
    linked = Linked(data, symbols, stock, compiler, temp)
    notifier = linked.access('init_cpu_capacity_callback')
    probe = linked.access('qcom_cpufreq_hw_driver_probe')
    topology = call_site(linked, notifier, 'walt_update_cluster_topology')
    registration = call_site(linked, probe, 'register_cpu_cycle_counter_cb')
    call_site(linked, probe[:registration], 'cpufreq_register_driver')
    counter = provider_pointer(linked, probe, registration)
    linked.callback(counter, 'qcom_cpufreq_get_cpu_cycle_counter')
    entries = {}
    for name, expected in [('cpufreq_qcom_std_offsets',0x9c0),('cpufreq_qcom_epss_std_offsets',0x3c4)]:
        value, = struct.unpack_from('<H',data,linked.names[name]+8)
        require(value==expected, 'Incorrect cycle counter register '+name)
        entries[name]=hex(value)
    return dict(image_sha256=digest(data), cluster_setup_call=hex(notifier[topology][0]),
                cycle_counter_registration_call=hex(probe[registration][0]),
                callback='qcom_cpufreq_get_cpu_cycle_counter', cycle_counter_offsets=entries)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('work',type=Path)
    parser.add_argument('previous_boot',type=Path)
    parser.add_argument('dest',type=Path)
    args=parser.parse_args()
    work=args.work.resolve()
    dest=args.dest.resolve()
    dest.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        tmp=Path(td)
        factory=unpack_boot(work/'boot.img',STOCK_BOOT,STOCK_IMAGE)
        previous=unpack_boot(args.previous_boot,PREVIOUS_BOOT,PREVIOUS_IMAGE)
        candidate=unpack_boot(work/'pair/VEUX_M63-R6_boot_NOFLASH.img')
        out=work/'out'
        img=out/'arch/arm64/boot/Image'
        require(candidate==img.read_bytes(), 'Kernel in packaged candidate does not match Kbuild output')
        tree=tmp/'veux.dtb'
        tree.write_bytes(device_tree(signed_regions(tmp)))
        require(digest(candidate) not in (STOCK_IMAGE,PREVIOUS_IMAGE),'Expected a newly linked kernel')
        binaries={}
        for name, data, syms in [('Xiaomi',factory,stock_symbols(factory)),
                                 ('M63-R6',candidate,mapped_symbols(out/'System.map'))]:
            binaries[name]=inspect(data,syms,name=='Xiaomi',work/'clang/bin',tmp)
        runs={}
        for name, data in [('Xiaomi',factory),('M63-R2',previous),('M63-R6',candidate)]:
            image=tmp/(name+'.Image')
            image.write_bytes(data)
            report=dest/(name+'.json')
            subprocess.run([sys.executable,'-B',HERE/'probe_epss.py',image,out,HERE.parent,tree,report],check=True)
            runs[name]=json.loads(report.read_text())
            require(runs[name]['image_sha256']==digest(data), 'Wrong input '+name)
            expected={} if name=='M63-R2' else {'0':6,'6':2}
            require(runs[name]['core_ctl_max_cpus']==expected,'Wrong WALT groups '+name)
        summary=dict(linked_startup=binaries, model_runs=runs, stock_dtb_sha256=digest(tree.read_bytes()),
                     
                     m63_r5_physical_boot='untested', flash_allowed=False)
        (dest/'EPSS.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=='__main__':
    main()
