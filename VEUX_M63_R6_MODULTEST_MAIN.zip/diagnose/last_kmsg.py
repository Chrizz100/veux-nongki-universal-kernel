"""Follow registration in LLDB and compare the previous-console interface across a warm restart."""
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time

from fruehstart import STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot
from pstore_vm import command as fixture_command

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tools'))
from memory_image import stock_symbols, mapped_symbols

R5_BOOT = '6352e8a8bd5d0595b6a346cfaa6c3efae660724e8c2ce197b94707990e20c195'
R5_IMAGE = '1e1ab1aec47b3f29b779fb55af90c506720d19439f0c865edfc14ce8c3adf14b'
BASE = 0xffffffc010080000

def debugger(label, symbols, port, elf, root):
    def address(name):
        addresses = {BASE + a for a, t, n in symbols if t.lower() == 't' and '.cfi_jt' not in n and n.split('$')[0] == name}
        require(len(addresses) == 1, name)
        return addresses.pop()
    names = ['pstore_init_fs'] if label == 'M63-R5' else ['ram_console_late_init']
    names.append('load_elf_binary')
    targets = {name:address(name) for name in names}
    cmds = ['settings set target.default-arch aarch64', 'target create --arch aarch64 ' + json.dumps(str(elf)),
            f'gdb-remote 127.0.0.1:{port}']
    for i, (name, addr) in enumerate(targets.items(), 1):
        cmds.extend([f'breakpoint set --hardware --address {addr:#x}', 'continue',
                     f'script print("VEUX_LAST_PC {name}",hex(lldb.frame.GetPC()))','register read pc x0 x1 x30',
                     f'breakpoint delete {i}'])
    cmds.extend(['process detach','quit'])
    script = root / (label + '.lldb')
    script.write_text('\n'.join(cmds) + '\n')
    return script, targets

def run(label, data, symbols, work, dest, geometry):
    with tempfile.TemporaryDirectory() as dirname:
        temp = Path(dirname)
        image = temp/'Image'
        image.write_bytes(data)
        cmd = fixture_command(image, work/'out', temp, geometry, HERE/'last-kmsg-init.sh')
        cmd[cmd.index('-append')+1] += ' nokaslr'
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0))
            port = sock.getsockname()[1]
        pidfile = temp/'qemu.pid'
        cmd.extend(['-S','-gdb',f'tcp:127.0.0.1:{port}','-pidfile',str(pidfile)])
        # The static userspace ELF selects AArch64 in LLDB; symbols come from the kernel itself.
        elf = temp/'pid1.elf'
        tc = work/'clang/bin'
        subprocess.run([tc/'clang','--target=aarch64-linux-gnu','-fuse-ld=lld','-nostdlib','-static','-Wl,-e,_start',HERE/'pid1.S','-o',elf],check=True)
        script, targets = debugger(label, symbols, port, elf, dest)
        serial = dest/(label+'-Neustart.log')
        log = dest/(label+'-LLDB.log')
        with serial.open('wb') as out, subprocess.Popen(cmd,stdout=out,stderr=subprocess.STDOUT) as qemu:
            try:
                until=time.monotonic()+12
                while not pidfile.exists() and time.monotonic()<until and qemu.poll() is None:
                    time.sleep(.08)
                with log.open('wb') as f:
                    subprocess.run([tc/'lldb.sh','-b','-s',script],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=90)
                until=time.monotonic()+75
                while time.monotonic()<until and qemu.poll() is None:
                    s=serial.read_bytes()
                    if b'VEUX_ALIAS_DONE' in s or b'Kernel panic - not syncing' in s:
                        break
                    time.sleep(.15)
            finally:
                if qemu.poll() is None:qemu.kill()
                qemu.wait()
    text=serial.read_text(errors='replace')
    hits={n:int(a,16) for n,a in re.findall(r'^VEUX_LAST_PC (\w+) (0x[0-9a-f]+)$',log.read_text(),re.M)}
    require(hits==targets, f'{label}: debugger did not observe the expected code')
    lines=text.splitlines()
    require(text.count('Linux version 5.4.274')==2 and lines.count('VEUX_MARKER_WRITTEN')==lines.count('VEUX_NATIVE_MARKER')==lines.count('VEUX_ALIAS_DONE')==1,
            f'{label}: incomplete reset or previous-boot marker')
    size=re.findall(r'^VEUX_ALIAS_MATCH (\d+)$',text,re.M)
    if label=='M63-R5':
        require(lines.count('VEUX_ALIAS missing')==2 and not size,'R5 negative control')
    else:
        require(lines.count('VEUX_ALIAS 444 PRE 0')==2 and len(size)==1 and int(size[0])>0 and 'VEUX_ALIAS_REMOUNT_ERASE_OK' in lines
                and 'VEUX_ANDROID_DAC_OK' in lines,
                f'{label}: previous-console alias failed')
    return dict(kernel_sha256=digest(data), debugger_pc={n:hex(a) for n,a in hits.items()},
                boots=2, native_marker=True, proc_present=bool(size), proc_bytes=int(size[0]) if size else None,
                repeated_read_remount_erase=('VEUX_ALIAS_REMOUNT_ERASE_OK' in lines),
                android_file_permissions_checked=('VEUX_ANDROID_DAC_OK' in lines), log_sha256=digest(serial.read_bytes()))

def main(work, dest, labels):
    dest.mkdir(parents=True,exist_ok=True)
    geo=json.loads((work/'evidence/pstore/pstore.json').read_text())['oem_ramoops']
    for label in labels:
        if label=='Xiaomi':
            data=unpack_boot(work/'boot.img',STOCK_BOOT,STOCK_IMAGE)
            symbols=stock_symbols(data)
        elif label=='M63-R5':
            data=unpack_boot(work/'M63-R5-Kontrolle.img',R5_BOOT,R5_IMAGE)
            symbols=mapped_symbols(HERE/'ref/M63-R5-Last-Kmsg.map')
        elif label=='M63-R6':
            data=unpack_boot(work/'pair/VEUX_M63-R6_boot_NOFLASH.img')
            require(data==(work/'out/arch/arm64/boot/Image').read_bytes(),'Linked R6 differs from pair')
            symbols=mapped_symbols(work/'out/System.map')
        else:
            raise ValueError(label)
        result=run(label,data,symbols,work,dest,geo)
        (dest/(label+'.json')).write_text(json.dumps(result,indent=2)+'\n')
        print(label,result,flush=True)
if __name__=='__main__':
    main(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve(),sys.argv[3:] or ['Xiaomi','M63-R5','M63-R6'])
