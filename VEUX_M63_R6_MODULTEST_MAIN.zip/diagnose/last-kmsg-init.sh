#!/busybox sh
set -eu
bb=/busybox
$bb mount -t proc proc /proc
alias_file=/proc/last_kmsg
record=/store/console-ramoops-0
if [ -e "$alias_file" ]; then
    mode=$($bb stat -c '%a' "$alias_file")
    pre=$($bb wc -c < "$alias_file")
    echo "VEUX_ALIAS $mode PRE $pre"
else
    echo 'VEUX_ALIAS missing'
fi
$bb mount -t pstore pstore /store
if [ ! -e "$record" ]; then
    echo '<4>VEUX_PREVIOUS_CONSOLE_71B5' > /dev/kmsg
    echo VEUX_MARKER_WRITTEN
    echo b > /proc/sysrq-trigger
    exec $bb sleep 180
fi
$bb grep -Fq 'VEUX_PREVIOUS_CONSOLE_71B5' "$record"
echo VEUX_NATIVE_MARKER
if [ -e "$alias_file" ]; then
    $bb cmp "$alias_file" "$record"
    bytes=$($bb wc -c < "$alias_file")
    echo "VEUX_ALIAS_MATCH $bytes"
    $bb cmp "$alias_file" "$record" & first=$!
    $bb cmp "$alias_file" "$record" & second=$!
    wait "$first"
    wait "$second"
    # Apply the stock HyperOS init.rc ownership and modes in the test guest.
    $bb chown 1000:1007 /store "$record" "$alias_file"
    $bb chmod 0550 /store
    $bb chmod 0440 "$record" "$alias_file"
    [ "$($bb setuidgid 1000:1000 $bb id -u)" = 1000 ]
    $bb setuidgid 1000:1000 $bb cmp "$alias_file" "$record"
    [ "$($bb setuidgid 10123:10123 $bb id -u)" = 10123 ]
    if $bb setuidgid 10123:10123 $bb cat "$alias_file" >/dev/null 2>&1; then
        echo VEUX_UNEXPECTED_ACCESS
        exit 1
    fi
    echo VEUX_ANDROID_DAC_OK
    $bb umount /store
    [ "$($bb wc -c < "$alias_file")" -eq 0 ]
    $bb mount -t pstore pstore /store
    $bb cmp "$alias_file" "$record"
    $bb rm "$record"
    [ "$($bb wc -c < "$alias_file")" -eq 0 ]
    echo VEUX_ALIAS_REMOUNT_ERASE_OK
fi
echo VEUX_ALIAS_DONE
exec $bb sleep 180
