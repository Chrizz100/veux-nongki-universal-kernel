"""Cross-check the five scheduler startup calls with the shipped VEUX vmlinux code and the build object."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile

NAMES = ('init_clusters', 'walt_sched_init_rq', 'alloc_related_thread_groups', 'init_new_task_load', 'walt_init_sched_boost')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent/'tools'))
from memory_image import Code, mapped_symbols, stock_symbols
from fruehstart import unpack_boot, STOCK_BOOT, STOCK_IMAGE

def calls_in_image(image, symbols, tools, work):
    code = Code(image, symbols, tools, work)
    targets = {addr:name for addr,k,name in symbols if k.lower()=='t' and name in NAMES}
    calls = []
    for _,op,operand in code.instructions('sched_init'):
        if op in ('bl','b') and re.fullmatch('0x[0-9a-f]+',operand):
            dest = int(operand,16)
            if dest in targets:
                calls.append(targets[dest])
    return calls

def calls_in_object(path, tool, work):
    target = work/'core.ll'
    subprocess.run([tool,path,'-o',target],check=True)
    bodies = []
    for file in sorted(work.glob('core.ll*')):
        text = file.read_text()
        bodies.extend(re.findall(r'^define [^\n]*@sched_init\([^\n]*\)[^\n]*\n.*?^}',text,re.M|re.S))
    if len(bodies)!=1:
        raise ValueError('Expected exactly one definition of sched_init in ThinLTO object')
    return [name for name in re.findall(r'\bcall\b[^\n@]*@(\w+)\(',bodies[0]) if name in NAMES]

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stock',type=Path); p.add_argument('out',type=Path); p.add_argument('bin',type=Path)
    p.add_argument('proof',type=Path)
    p.add_argument('--object-only', action='store_true', help='Check the scheduler before the full kernel link')
    a=p.parse_args()
    stock = unpack_boot(a.stock,STOCK_BOOT,STOCK_IMAGE)
    with tempfile.TemporaryDirectory() as tmp:
        work=Path(tmp)
        original=calls_in_image(stock,stock_symbols(stock),a.bin,work)
        built=calls_in_object(a.out/'kernel/sched/core.o',a.bin/'llvm-dis',work)
        if original!=list(NAMES) or built!=original:
            raise ValueError(f'WALT startup calls differ. Xiaomi {original}, build object {built}')
        evidence=dict(function='sched_init',factory_image_sha256=STOCK_IMAGE,
                      factory_direct_calls=original,compiled_scheduler_object_calls=built)
        if not a.object_only:
            new = (a.out/'arch/arm64/boot/Image').read_bytes()
            evidence['candidate_image_sha256']=hashlib.sha256(new).hexdigest()
            evidence['candidate_direct_calls_after_ThinLTO']=calls_in_image(new,mapped_symbols(a.out/'System.map'),a.bin,work)
            if evidence['candidate_direct_calls_after_ThinLTO'] != original:
                raise ValueError('Linked scheduler initialization differs from Xiaomi')
    a.proof.write_text(json.dumps(evidence,indent=2)+'\n')
    print('PASS WALT scheduler startup order against shipped Xiaomi kernel')

if __name__=='__main__':
    main()
