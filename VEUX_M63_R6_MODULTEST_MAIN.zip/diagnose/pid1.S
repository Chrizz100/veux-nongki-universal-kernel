// SPDX-License-Identifier: MIT
.global _start
.section .text
_start:
    mov x8, #172                 // getpid
    svc #0
    cmp x0, #1
    b.ne wait
    mov x0, #1                   // stdout is the initial console
    adr x1, marker
    adr x2, marker_end
    sub x2, x2, x1
    mov x8, #64                  // write
    svc #0
wait:
    mov x0, #0
    mov x1, #0
    mov x2, #0
    mov x3, #0
    mov x4, #0
    mov x8, #73                  // ppoll with no fds and no timeout
    svc #0
    b wait
marker:
    .ascii "VEUX_WALT_PID1_OK\n"
marker_end:
