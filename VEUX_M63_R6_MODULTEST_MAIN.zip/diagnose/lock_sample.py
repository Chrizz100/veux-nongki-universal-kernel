"""LLDB helper loaded in the debugger's own Python interpreter."""
import json
import lldb


def sample(pcs, percpu, runqueues):
    frame = lldb.frame
    process = frame.GetThread().GetProcess()

    def read(addr, width):
        error = lldb.SBError()
        value = process.ReadUnsignedFromMemory(addr, width, error)
        if error.Fail():
            raise ValueError(str(error))
        return value

    pc = frame.GetPC()
    if pc not in pcs:
        raise ValueError('Debugger stopped outside the verified migration site: %#x' % pc)
    cpu = frame.FindRegister('x1').GetValueAsUnsigned()
    if cpu >= 8:
        raise ValueError('Invalid destination CPU: %d' % cpu)
    offset = read(percpu + 8 * cpu, 8)
    address = (runqueues + offset) & 0xffffffffffffffff
    word = read(address, 4)
    # arm64 queued_spinlock stores its locked byte at offset zero on little endian.
    print('VEUX_LOCK ' + json.dumps(dict(pc=hex(pc), cpu=cpu, address=hex(address),
                                        word=word, locked_byte=word & 0xff)))
