/* Userspace model of Netlink delivery; the exercised handler bodies come from the kernel tree. */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include "uapi/millet.h"
#define RET_OK 0
#define RET_ERR (-1)
#define GFP_ATOMIC 0
#define unlikely(x) (x)
#define pr_err(...) ((void)0)
#define pr_info(...) ((void)0)
#define NLMSG_SPACE(len) (16U+(unsigned)(len))
#define NLMSG_DATA(nlh) ((void *)((nlh)+1))
#define NETLINK_CB(skb) ((skb)->cb)
#define NETLINK_CREDS(skb) (&(skb)->cred)
#define MAX_REC_UID 64
typedef int atomic_t;
static int atomic_read(const atomic_t *p) { return *p; }
static void atomic_set(atomic_t *p,int v) { *p=v; }
static int uid_lock;
static void spin_lock_bh(int *p) { assert(!*p); *p = 1; }
static void spin_unlock_bh(int *p) { assert(*p); *p = 0; }

struct task_struct { int pid; };
static struct task_struct self;
#define current (&self)
struct nlmsghdr { uint32_t nlmsg_len; uint16_t type,flags; uint32_t seq,nlmsg_pid; };
struct sk_buff { struct { int portid; } cb; struct { struct { uid_t val; } uid; } cred; unsigned len; _Alignas(8) struct nlmsghdr header; unsigned char body[160]; };
struct timespec64 { long tv_sec,tv_nsec; };
struct millet_sock { atomic_t has_init; void *sock; struct { enum MILLET_TYPE monitor; atomic_t port; void (*recv_from)(void *, unsigned); } mod[MILLET_TYPES_NUM]; };
static struct millet_sock millet_sk;
static atomic_t uid_rec[MAX_REC_UID];
static int millet_debug;
static int output_port, deliveries, outstanding;
static struct millet_data last;
static struct nlmsghdr *nlmsg_hdr(struct sk_buff *b) { return &b->header; }
static int nlmsg_ok(struct nlmsghdr *h,unsigned n) { return n>=16 && h->nlmsg_len>=16 && h->nlmsg_len<=n; }
static unsigned nlmsg_len(struct nlmsghdr *h) { return h->nlmsg_len-16; }
static struct sk_buff *nlmsg_new(int n,int flags) { assert((size_t)n==sizeof(last) && !flags); outstanding++; return calloc(1,sizeof(struct sk_buff)); }
static struct nlmsghdr *nlmsg_put(struct sk_buff *b,int port,int seq,int type,int len,int flags) { (void)port;(void)seq;(void)type;(void)flags;b->header.nlmsg_len=len+16;return &b->header; }
static void *nlmsg_data(struct nlmsghdr *h) { return NLMSG_DATA(h); }
static void kfree_skb(struct sk_buff *b) { free(b); outstanding--; }
static void ktime_get_ts64(struct timespec64 *ts) { ts->tv_sec=123;ts->tv_nsec=456; }
static void dump_send_msg(void *p) { (void)p; }
static void dump_recv_msg(void *p) { (void)p; }
static int nlmsg_unicast(void *sock,struct sk_buff *b,int port) {
	(void)sock; assert(port && b->header.nlmsg_len==160); memcpy(&last,NLMSG_DATA(&b->header),sizeof(last)); deliveries++;output_port=port;kfree_skb(b);return 0;
}
static int millet_sendmsg(enum MILLET_TYPE type,struct task_struct *t,struct millet_data *d);
#include "millet-body.inc"
static int millet_sendmsg(enum MILLET_TYPE type,struct task_struct *t,struct millet_data *d)
{
	assert(type==HANDSHK_TYPE);return hs_sendmsg(t,d,&millet_sk);
}
static struct sk_buff packet(enum MILLET_TYPE owner,enum MSG_TYPE type,unsigned uid,int port)
{
	struct sk_buff b={};
	struct millet_userconf msg={.owner=owner,.msg_type=type,.src_port=MILLET_USER_ID,.dst_port=MILLET_KERNEL_ID};
	b.cb.portid=port;b.cred.uid.val=uid;b.len=b.header.nlmsg_len=NLMSG_SPACE(sizeof(msg));b.header.nlmsg_pid=port;
	memcpy(NLMSG_DATA(&b.header),&msg,sizeof(msg));return b;
}
static void inject(struct sk_buff *b) { recv_handler(b);assert(outstanding==0); }
int main(void)
{
	_Static_assert(sizeof(struct millet_data)==144 && sizeof(struct millet_userconf)==80,"VEUX ARM64 ABI");
	_Static_assert(NETLINK_MILLET==30 && MILLET_KERNEL_ID==0x12341234 && MILLET_USER_ID==0xabcddcba,"VEUX identifiers");
	(void)NAME_ARRAY;millet_sk.has_init=1;
	hs_init_millet(&millet_sk);millet_sk.mod[HANDSHK_TYPE].recv_from=hs_recv_hook;
	millet_sk.mod[PKG_TYPE].recv_from=pkg_recv_hook;
	struct sk_buff b=packet(SIG_TYPE,LOOPBACK_MSG,1000,42);
	inject(&b);assert(deliveries==1 && output_port==42 && last.owner==SIG_TYPE && last.msg_type==LOOPBACK_MSG);
	assert(last.dst_port==MILLET_USER_ID && last.src_port==MILLET_KERNEL_ID && last.tm.sec==123);
	b=packet(HANDSHK_TYPE,MSG_TO_KERN,1000,42);inject(&b);
	assert(deliveries==2 && output_port==42 && last.owner==HANDSHK_TYPE && last.monitor==SIG_TYPE);
	b=packet(SIG_TYPE,LOOPBACK_MSG,10001,73);inject(&b);assert(deliveries==2 && millet_sk.mod[SIG_TYPE].port==42);
	b=packet(SIG_TYPE,LOOPBACK_MSG,0,71);b.header.nlmsg_pid=123;inject(&b);assert(deliveries==3 && output_port==71);
	b=packet(SIG_TYPE,LOOPBACK_MSG,1000,42);((struct millet_userconf *)NLMSG_DATA(&b.header))->src_port=0;inject(&b);assert(deliveries==3);
	b=packet(O_TYPE,LOOPBACK_MSG,0,7);inject(&b);assert(deliveries==3);
	b=packet(SIG_TYPE,LOOPBACK_MSG,1000,42);b.len=b.header.nlmsg_len=20;inject(&b);assert(deliveries==3);
	b=packet(PKG_TYPE,MSG_TO_KERN,1000,42);
	struct millet_userconf *p=NLMSG_DATA(&b.header);p->mod.u_priv.pkg.uid=10123;
	p->mod.u_priv.pkg.cmd=ADD_UID;inject(&b);inject(&b);assert(find_and_clear_uid(10123)==1 && find_and_clear_uid(10123)==0);
	inject(&b);p->mod.u_priv.pkg.cmd=DEL_UID;inject(&b);assert(!find_and_clear_uid(10123));
	p->mod.u_priv.pkg.cmd=ADD_UID;inject(&b);p->mod.u_priv.pkg.cmd=CLEAR_ALL_UID;inject(&b);assert(!find_and_clear_uid(10123));
	struct millet_data d={.owner=BINDER_TYPE,.msg_type=MSG_TO_USER,.uid=10023};millet_sk.mod[BINDER_TYPE].port=50;
	d.mod.k_priv.binder.trans.src_task=&self;d.mod.k_priv.binder.trans.dst_task=&self;d.mod.k_priv.binder.trans.caller_uid=10024;
	assert(millet_sendto_user(&self,&d,&millet_sk)==0 && last.uid==10023 && last.mod.k_priv.binder.trans.caller_uid==10024);
	assert(!last.mod.k_priv.binder.trans.src_task && !last.mod.k_priv.binder.trans.dst_task);
	d.owner=BINDER_ST_TYPE;assert(millet_sendto_user(&self,&d,&millet_sk)<0 && outstanding==0);
	puts("PASS VEUX Netlink ABI, handshake, system sender, routing, package management and private fields");
}
