"""Run the actual compiled C callbacks with synthetic UFS descriptors and host events."""

import pathlib
import subprocess
import sys
import tempfile

src = (pathlib.Path(sys.argv[1]) / "drivers/scsi/ufs/mi-memory.c").read_text()
code = src[
    src.index("static DEFINE_SPINLOCK(diag_lock)") : src.index(
        "static DEVICE_ATTR_RO(dump_string_desc_serial)"
    )
]
with tempfile.TemporaryDirectory() as folder:
    tmp = pathlib.Path(folder)
    (tmp / "diag.inc").write_text(code)
    test = pathlib.Path(__file__).with_suffix(".c")
    exe = tmp / "diag"
    subprocess.run(
        [
            "cc",
            "-std=gnu11",
            "-O2",
            "-Wall",
            "-Werror",
            "-I",
            str(tmp),
            str(test),
            "-o",
            str(exe),
        ],
        check=True,
    )
    subprocess.run([str(exe)], check=True)
