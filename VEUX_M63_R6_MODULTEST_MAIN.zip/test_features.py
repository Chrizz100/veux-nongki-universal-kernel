"""Exercise the exact patched driver bodies with userspace fixtures."""
from pathlib import Path
import re
import subprocess
import sys
import tempfile
kit=Path(__file__).resolve().parent
src=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory() as folder:
    tmp=Path(folder)
    body=(src/'drivers/scsi/ufs/mi-ufs-health.c').read_text()
    (tmp/'health-body.inc').write_text(re.sub(r'^#include.*$','',body,flags=re.M))
    subprocess.run(['cc','-std=gnu11','-funsigned-char','-Wall','-Wextra','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all','-I',tmp,kit/'test_hr.c','-o',tmp/'hr'],check=True)
    subprocess.run([tmp/'hr'],check=True)
    millet=src/'drivers/mihw'
    blocks=[]
    for filename,names in [
        ('millet_core.c',['millet_sendto_user','recv_handler']),
        ('millet_hs.c',['hs_sendmsg','hs_recv_hook','hs_init_millet']),
        ('millet_pkg.c',['pkg_add_uid','find_and_clear_uid','pkg_del_uid','pkg_clear_all','pkg_recv_hook'])]:
        code=(millet/filename).read_text()
        for name in names:
            pat=r'^(?:static )?(?:int|void) '+name+r'\([^;{]*?\)\s*\{.*?^}'
            match=re.search(pat,code,re.M|re.S)
            if not match: raise ValueError(name)
            blocks.append(match.group())
    (tmp/'millet-body.inc').write_text('\n'.join(blocks))
    subprocess.run(['cc','-std=gnu11','-O1','-fno-strict-aliasing','-Wall','-Werror','-fsanitize=undefined','-fno-sanitize-recover=all','-I',tmp,'-I',millet,kit/'test_millet.c','-o',tmp/'millet'],check=True)
    subprocess.run([tmp/'millet'],check=True)
