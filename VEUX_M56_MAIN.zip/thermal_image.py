"""Check the isolation cooling callbacks and their linked ARM64 call targets."""
from pathlib import Path
import argparse,hashlib,json,re,struct,tempfile
from check import BOOT,STOCK_IMAGE,BASE_IMAGE,sha,require
from memory_image import Code,stock_symbols,mapped_symbols

def verify(image,syms,tc,mode):
    with tempfile.TemporaryDirectory() as tmp:
        code=Code(image,syms,tc,Path(tmp))
        callbacks=['cpu_isolate_probe','cpu_isolate_register_cdev','cpu_isolate_set_cur_state',
                   'cpu_isolate_get_max_state','cpu_isolate_get_cur_state','cpu_isolate_hp_online',
                   'cpu_isolate_hp_offline','cpu_isolate_pm_notify']
        if mode=='m55':
            require(all(n not in code.names for n in callbacks),'M55 baseline already contains CPU isolation cooling')
            return {'driver_present':False}
        require(all(n in code.names for n in callbacks),'Incomplete cooling driver')
        require(b'qcom,cpu-isolate\0' in image and b'cpu-isolate/cdev:online\0' in image,'Missing DT or hotplug registration names')
        names={}
        for a,t,n in syms:
            if t.lower() in ('t','w') and not n.startswith('$') and '.cfi_jt' not in n:
                names.setdefault(a,set()).add(n.split('$')[0].split('.llvm.')[0])
        # A direct call can land on a CFI jump-table slot. Accept the slot only
        # when its ARM64 B instruction resolves to the matching implementation.
        for addr,kind,name in syms:
            if kind.lower()!='t' or not name.endswith('.cfi_jt') or not 0<=addr<=len(image)-4:
                continue
            word,=struct.unpack_from('<I',image,addr)
            if word>>26!=5:
                continue
            imm=word&0x3ffffff
            target=addr+4*(imm-(1<<26) if imm&(1<<25) else imm)
            original=name[:-len('.cfi_jt')].split('$')[0].split('.llvm.')[0]
            if original in names.get(target,()):
                names.setdefault(addr,set()).add(original)
        def calls(function):
            result=set()
            for _,op,arg in code.instructions(function):
                if op in ('b','bl'):
                    result.update(names.get(int(arg,16),()))
            return result
        def path(function,targets,via=()):
            actual=calls(function)
            if actual.intersection(targets): return True
            return any(h in actual and h in code.names and calls(h).intersection(targets) for h in via)
        set_state=callbacks[2]; probe=callbacks[0]
        iso={'sched_isolate_cpu','sched_isolate_cpu_unlocked'}
        uniso={'sched_unisolate_cpu','sched_unisolate_cpu_unlocked'}
        rows={
          'register_hotplug':path(probe,{'__cpuhp_setup_state'}),
          'register_pm':path(probe,{'register_pm_notifier','blocking_notifier_chain_register'}),
          'register_cooling_device':path(callbacks[1],{'thermal_of_cooling_device_register','__thermal_cooling_device_register'}),
          'apply_scheduler_vote':path(set_state,iso,['update_vote']),
          'release_scheduler_vote':path(set_state,uniso,['update_vote']),
          'notify_thermal_level':path(set_state,{'blocking_notifier_call_chain'},['publish_level']),
          'queue_online_registration':path('cpu_isolate_hp_online',{'queue_work_on'}),
          'drop_offline_vote':path('cpu_isolate_hp_offline',uniso,['update_vote']),
          'reapply_after_resume':path('cpu_isolate_pm_notify',iso,['update_vote']),
        }
        if mode=='stock':
            rows['retry_online']=path(set_state,{'device_online'})
        else:
            rows['retry_online']=(path(set_state,{'queue_work_on'}) and path('cpu_isolate_restore_online',{'device_online'}))
        body=code.instructions('cpu_isolate_get_max_state')
        one={re.match(r'[wx](\d+), #1$',args)[1] for _,op,args in body if op=='mov' and re.match(r'[wx](\d+), #1$',args)}
        rows['maximum_level_one']=any(op=='str' and any(args=='x'+r+', [x1]' for r in one) for _,op,args in body)
        require(all(rows.values()),'Missing linked thermal behavior: '+repr([k for k,v in rows.items() if not v]))
        return {'driver_present':True,**rows}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['stock','m55','candidate'])
    for n in ('tc','image','output'):p.add_argument(n,type=Path)
    p.add_argument('--map',type=Path)
    a=p.parse_args()
    data=a.image.read_bytes()
    if a.mode=='stock':
        require(sha(a.image)==BOOT,'Stock boot image identity')
        data=data[4096:4096+struct.unpack_from('<I',data,8)[0]]
        require(hashlib.sha256(data).hexdigest()==STOCK_IMAGE,'Stock Image identity')
        syms=stock_symbols(data)
    else:
        if a.mode=='m55':require(sha(a.image)==BASE_IMAGE,'M55 artifact identity')
        syms=mapped_symbols(a.map)
    result=verify(data,syms,a.tc,a.mode)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(a.mode,result)
