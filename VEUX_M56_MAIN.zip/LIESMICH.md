# VEUX M56 – thermische CPU-Isolation

Gerät und Referenz sind der POCO X4 Pro 5G (veux) und Xiaomi V816.0.12.0.TKCMIXM. Die vorgesehene Kernelkennung lautet 5.4.274-qgki-g82179e362f33.

## Auf GitHub starten

1. VEUX_M56_MAIN.zip unentpackt ins Hauptverzeichnis des Repositorys hochladen.
2. VEUX_M56_THERMIK_NOFLASH.yml im selben Branch unter .github/workflows/ speichern.
3. In Actions „VEUX M56 – Thermische CPU-Isolation, QGKI 5.4.274“ auswählen und manuell starten.

Die YAML prüft die Prüfsumme der MAIN.zip. Sie lädt die M55-Quellen aus GitHub-Artefakt 14755176626 und Xiaomis Original aus M46-Artefakt 14706022228. Die Artefakte müssen noch verfügbar sein. Die äußeren Archive, der Quell-Tarball, die Stockdatei und die sechs vom Patch betroffenen Quelldateien werden mit festen SHA-256 geprüft. Der Workflow benötigt Lesezugriff auf Repository und Actions.

## Ergebnis von M55

Alle 13 Schritte des Jobs waren erfolgreich. Beide Archive wurden heruntergeladen und anhand der GitHub-SHA-256 und der ZIP-CRC geprüft. Sie enthalten 34 Nachweisdateien und vier Dateien zum Quellstand. Die kompilierte Konfiguration stimmt in Image und vmlinux mit dem archivierten Stand überein. Der SIGKILL-Speicherfreigabepfad, die OOM-Auswahl, der zRAM-Standard und die drei ARM64-Atomikpfade wurden am archivierten Image erneut mit Xiaomi verglichen. 3.148 Importverwendungen aus 37 Vendor-Modulen stimmen mit der erwarteten CRC und dem Anbieter überein. Das statische Bootlayout und die F2FS-Objektprüfungen wurden ebenfalls erneut ausgewertet. [M55-Lauf und Job](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45022019146/job/137206820958)

## Reparatur

Xiaomis Original-Image enthält den QTI-Kühltreiber mit seinen Aufrufen zur CPU-Isolation, zur Freigabe, zum CPU-Hotplug und zur Wiederaufnahme nach Standby. M55 hat die Scheduler-Funktionen und die Geräteknoten, ihm fehlt der verbindende Kühltreiber. Im gebauten VEUX-DTB sind alle acht CPU-Verweise aufgelöst. Auf die CPUs 0 bis 5 entfällt je eine aktive Kühlzuordnung, auf die CPUs 6 und 7 jeweils zwei. In allen zehn Zuordnungen wird Stufe 1 angefordert.

Der Patch bindet den Treiber für qcom,cpu-isolate fest in den Kernel ein. Stufe 1 fordert eine Isolationsstimme beim WALT-Scheduler an, Stufe 0 gibt die eigene Stimme wieder frei. Andere Scheduler-Clients behalten ihre Stimmen. Der vorhandene Schutz für die letzte verfügbare CPU bleibt im Scheduler. Bei CPU-Hotplug gibt der Treiber seine Stimme ab. Nach Standby fordert er eine weiterhin benötigte Isolierung erneut an. Die Thermik-Schwellen und der VEUX-Gerätebaum bleiben auf dem geprüften Ausgangsstand.

Die Vorlage ist die öffentliche Xiaomi-VEUX-Implementierung. M56 ergänzt die Serialisierung von Hotplug und Stimmverwaltung, Fehlerbehandlung, Referenzfreigabe und Aufräumen bei fehlgeschlagener Initialisierung. Eine wegen Kühlung abgewiesene CPU wird nach Abkühlung über einen separaten Arbeitsauftrag wieder online angefordert. Dabei hält der Treiber keine eigene Thermiksperre. Die ausstehende Anforderung bleibt bei einem fehlgeschlagenen Versuch für eine erneute Freigabe verfügbar. Die vorhandene Scheduler-Funktion behält ihren öffentlichen Aufrufweg. Eine interne Variante erlaubt dem Kühltreiber, Prüfung und Änderung innerhalb derselben CPU-Hotplug-Sperre auszuführen. [Xiaomi VEUX-Quelle](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/thermal/qcom/cpu_isolate.c)

## Prüfungen und Grenzen

Der C-Test führt die tatsächlichen Funktionen des Treibers mit simulierten Kernel-Schnittstellen aus. Er prüft acht CPU-Ziele, Stufe 0 und 1, unabhängige Isolationsstimmen, Registrierungsfehler, CPU-Hotplug, fehlgeschlagene Wiederherstellung, Suspend/Resume sowie parallel eintreffende Thermik- und Hotplug-Anforderungen. Der ARM64-Objekttest prüft die Callback-Tabellen und die Verweise auf die beiden Hotplug-Funktionen. Der Image-Test prüft die Registrierungen, Scheduler-Aufrufe, Benachrichtigungen und den Rückweg im gelinkten Kernel. Die vorhandenen Speicher-, Atomik-, ABI-, DTB-, F2FS- und Bootlayout-Prüfungen laufen mit.

Restkonfiguration.csv enthält alle 49 verbleibenden textlichen Konfigurationsunterschiede zu Xiaomi. M56 schließt eine Option und einen tatsächlich fehlenden Treiber. Für zwei LSE- und fünf zRAM-Einträge wurde das untersuchte Verhalten bereits im Image abgeglichen. Zu den offenen Funktionen gehört die MIUI-zRAM-Speicherstatistik. Boot, dm-verity, UFS, F2FS und die Thermik auf dem laufenden Kandidaten sowie die praktische Wiederherstellung stehen aus. Eine Flash-Freigabe bleibt offen.

## Lokaler Vollbau

Das Kernel-Image, vmlinux, die VEUX-DTB und alle vier Kernelmodule wurden aus dem mit M56 gepatchten Quellstand gebaut. Für das lokale Image wurde SHA-256 e39e63a9111ba84ce2db80c0df31dda0a85fe7939d2e2a3515e018ab920dc103 ermittelt. Alle elf geprüften Thermikmerkmale im verlinkten Image stimmen mit der Stock-Referenz überein. Ein zusätzlicher Negativtest mit einem unterbrochenen ARM64-Sprung bestätigt, dass die Prüfung einen defekten Registrierungsweg zurückweist. Auch die 3.148 Vendor-Importe, der Stock-Ramdisk-Abgleich, die eingebettete Konfiguration, der M55-Reaperpfad und die vorhandenen Regressionstests wurden erfolgreich geprüft. Lokal lief der F2FS-Hosttest mit deaktiviertem LeakSanitizer. Die ARM64-Atomiktests liefen unter QEMU. Die Nachweise für den lokalen Bau stehen im Verzeichnis Nachweise. Eine Messung von Temperaturverlauf und CPU-Isolation auf dem Telefon steht aus.
