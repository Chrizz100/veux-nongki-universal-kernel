"""Authenticate the M55 source and extract the matching Xiaomi reference image."""
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m55.zip') as archive:
    require(sha(work/'m55.zip')=='0f9c12045954dbb21bb8b258a6b1239beb90b6cd3a8e4e3ee6f3e9940e948a01', 'M55 artifact digest')
    manifest=json.loads(archive.read('M55_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M55 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M55 config identity')
    archive.extract('M55-kernel-source.tar.gz',work)
tar=work/'M55-kernel-source.tar.gz'
require(sha(tar)=='d4694e4e03e7e8ffcceec7bd3eec79601f6b3ab43486d426d26d33c49fdf7de7','M55 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'thermal.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-e','QTI_CPU_ISOLATE_COOLING_DEVICE'],check=True)
