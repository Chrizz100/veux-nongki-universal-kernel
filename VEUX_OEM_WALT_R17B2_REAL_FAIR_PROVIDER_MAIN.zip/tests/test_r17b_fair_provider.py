#!/usr/bin/env python3
"""Independent source scope, semantic and negative regressions for R17B1."""
from pathlib import Path
import copy, hashlib, json, os, subprocess, tempfile, unittest
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r17b_fair_provider as m

FAIR='''/* real P3 fair relevant fragments */
#include "sched.h"
static int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu, int sync)
{
/* Existing policy reads real energy model. */
	rcu_read_lock();
	pd = rcu_dereference(rd->pd);
 compute_energy(p, -1, pd);
 sd_asym_cpucapacity;
 return prev_cpu;
}

static int select_task_rq_fair(struct task_struct *p, int prev_cpu, int sync)
{
 int new_cpu;
 new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync);
 return new_cpu;
}

static int active_load_balance_cpu_stop(void *data);

/* Other real fairness code before the active balancer */
static int active_load_balance_cpu_stop(void *data)
{
 struct rq *busiest_rq = data;
 int busiest_cpu = cpu_of(busiest_rq);
 int target_cpu = busiest_rq->push_cpu;
 struct rq *target_rq = cpu_rq(target_cpu);
 struct sched_domain *sd;
 struct task_struct *p = NULL;
 struct rq_flags rf;

 rq_lock_irq(busiest_rq, &rf);
 if (!cpu_active(busiest_cpu) || !cpu_active(target_cpu))
     goto out_unlock;
 if (busiest_rq->nr_running <= 1)
     goto out_unlock;
 /* Search for an sd spanning us and the target CPU. */
 rcu_read_lock();
 for_each_domain(target_cpu, sd) {
     if (sd->flags & SD_LOAD_BALANCE)break;
 }
 struct lb_env env;
 p = detach_one_task(&env);
 rcu_read_unlock();
out_unlock:
 busiest_rq->active_balance = 0;
 rq_unlock(busiest_rq, &rf);

 if (p)
     attach_one_task(target_rq, p);
 local_irq_enable();
 return 0;
}

static DEFINE_SPINLOCK(balancing);
'''
FAIR=FAIR.replace(' struct rq_flags rf;','\tstruct rq_flags rf;').replace(' /* Search for an sd spanning us and the target CPU. */','\t/* Search for an sd spanning us and the target CPU. */').replace('out_unlock:\n busiest_rq->active_balance = 0;\n rq_unlock(busiest_rq, &rf);\n\n if (p)\n     attach_one_task(target_rq, p);\n','out_unlock:\n\tbusiest_rq->active_balance = 0;\n\trq_unlock(busiest_rq, &rf);\n\n\tif (p)\n\t\tattach_one_task(target_rq, p);\n')
SCHED='''/* already successfully compiled R17-A scheduler */
#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)
extern void init_sched_groups_capacity(int cpu, struct sched_domain *sd);
#endif
'''

class SourceTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.fa=m.patch_fair(FAIR)
  cls.sh=m.patch_sched(SCHED)
  cls.r11=json.loads((ROOT/'fixtures/R11_SOURCE_GATE_GITHUB.json').read_text())
  cls.r14=json.loads((ROOT/'fixtures/R14_SOURCE_GATE_GITHUB.json').read_text())
  cls.r17a=json.loads((ROOT/'fixtures/R17A_SOURCE_GATE_GITHUB.json').read_text())
  cls.result=json.loads((ROOT/'fixtures/R17A_COMPILER_RESULT_GITHUB.json').read_text())
 def test_01_two_paths(self):self.assertEqual(m.FILES,(m.FAIR,m.SCHED))
 def test_02_fair_real_github_sha(self):self.assertEqual(self.r11['after_sha256'][m.FAIR],m.R11_FAIR_SHA)
 def test_03_sched_github_sha(self):self.assertEqual(self.r17a['after_sha256'][m.SCHED],m.R17A_SCHED_SHA)
 def test_04_r17a_11_12(self):self.assertEqual(self.result['object_success_count'],11)
 def test_05_compiler_yes(self):self.assertTrue(self.result['real_arm64_make_attempted'])
 def test_06_qc_vas_failed(self):self.assertFalse(self.result['qc_vas_compiled'])
 def test_07_topology_success(self):self.assertTrue(self.result['topology_compiled'])
 def test_08_symbol_proof(self):self.assertTrue(self.result['symbol_evidence']['symbols_verified'])
 def test_09_document_gate_verified(self):m.validate_input(self.r17a,self.result,self.r11,self.r14)
 def test_10_fake_r17a_rejected(self):
  x=copy.deepcopy(self.result);x['object_success_count']=12
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,x,self.r11,self.r14)
 def test_11_fake_r17a_symbol_rejected(self):
  x=copy.deepcopy(self.result);x['symbol_evidence']['symbols_verified']=False
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,x,self.r11,self.r14)
 def test_12_forged_r11_sha_rejected(self):
  x=copy.deepcopy(self.r11);x['after_sha256'][m.FAIR]='0'*64
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,self.result,x,self.r14)
 def test_13_forged_r17a_sched_rejected(self):
  x=copy.deepcopy(self.r17a);x['after_sha256'][m.SCHED]='0'*64
  with self.assertRaises(m.StageError):m.validate_input(x,self.result,self.r11,self.r14)
 def test_14_fake_flash_rejected(self):
  x=copy.deepcopy(self.r17a);x['flash_allowed']=True
  with self.assertRaises(m.StageError):m.validate_input(x,self.result,self.r11,self.r14)
 def test_15_eas_provider_global(self):self.assertIn('int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu,',self.fa)
 def test_16_eas_off_static(self):self.assertIn('static int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu, int sync)',self.fa)
 def test_17_fourth_hint(self):self.assertIn('int sync, int sibling_count_hint)',self.fa)
 def test_18_real_threshold(self):self.assertIn('sibling_count_hint >= sysctl_sched_many_wakeup_threshold',self.fa)
 def test_19_prev_cpu_constrained(self):self.assertIn('cpumask_test_cpu(prev_cpu, p->cpus_ptr)',self.fa)
 def test_20_real_energy_kept(self):self.assertIn('compute_energy(p, -1, pd)',self.fa)
 def test_21_old_eas_call_preserved(self):self.assertIn('new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync);',self.fa)
 def test_22_walt_eas_call_updated(self):self.assertIn('new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync, 1);',self.fa)
 def test_23_balance_external_walt(self):self.assertIn('int active_load_balance_cpu_stop(void *data);',self.fa)
 def test_24_balance_static_off(self):self.assertIn('static int active_load_balance_cpu_stop(void *data);',self.fa)
 def test_25_balance_real_push_get(self):self.assertIn('push_task = busiest_rq->wrq.push_task',self.fa)
 def test_26_balance_is_task_running(self):self.assertIn('push_task->state == TASK_RUNNING',self.fa)
 def test_27_balance_real_detach(self):self.assertIn('detach_task(push_task, &walt_env)',self.fa)
 def test_28_balance_real_attach(self):self.assertIn('attach_one_task(target_rq, push_task)',self.fa)
 def test_29_balance_real_put(self):self.assertIn('put_task_struct(push_task)',self.fa)
 def test_30_balance_reserved_clear(self):self.assertIn('clear_reserved(target_cpu)',self.fa)
 def test_31_original_detach_kept(self):self.assertIn('p = detach_one_task(&env)',self.fa)
 def test_32_original_attach_kept(self):self.assertIn('attach_one_task(target_rq, p)',self.fa)
 def test_33_original_unlock_kept(self):self.assertIn('rq_unlock(busiest_rq, &rf)',self.fa)
 def test_34_duplicate_guard(self):
  with self.assertRaises(m.StageError):m.patch_fair(self.fa)
 def test_35_missing_original_eas_blocked(self):
  with self.assertRaises(m.StageError):m.patch_fair(FAIR.replace('sd_asym_cpucapacity','invalid'))
 def test_36_missing_original_balance_blocked(self):
  with self.assertRaises(m.StageError):m.patch_fair(FAIR.replace('p = detach_one_task(&env)','p = NULL'))
 def test_37_changed_call_blocked(self):
  with self.assertRaises(m.StageError):m.patch_fair(FAIR.replace('new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync);','new_cpu = 0;'))
 def test_38_changed_out_unlock_blocked(self):
  with self.assertRaises(m.StageError):m.patch_fair(FAIR.replace('out_unlock:\n','out_unlock: /* moved */\n'))
 def test_39_sched_external_decl(self):self.assertIn('extern int find_energy_efficient_cpu(',self.sh)
 def test_40_sched_active_decl(self):self.assertIn('extern int active_load_balance_cpu_stop(void *data);',self.sh)
 def test_41_sched_off_guard(self):self.assertIn('#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)',self.sh)
 def test_42_duplicate_sched_blocked(self):
  with self.assertRaises(m.StageError):m.patch_sched(self.sh)
 def test_43_sched_change_blocked(self):
  with self.assertRaises(m.StageError):m.patch_sched(SCHED.replace('extern void init_sched_groups_capacity','extern void orphaned_init_sched_groups_capacity'))
 def test_44_scope_not_root(self):self.assertTrue(all(s.startswith('kernel/sched/') for s in m.FILES))
 def test_45_no_compiler_claim_in_stage(self):self.assertIn('real_kernel_compile_proven',Path(m.__file__).read_text())
 def test_46_exact_previous_sha_length(self):self.assertEqual(len(m.R11_FAIR_SHA),64)
 def test_47_git_apply_roundtrip(self):
  import difflib
  with tempfile.TemporaryDirectory() as tmp:
   t=Path(tmp);subprocess.run(['git','init','-q',str(t)],check=True)
   for n,content in [(m.FAIR,FAIR),(m.SCHED,SCHED)]:
    p=t/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
   patch=''.join(''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n,old,new in [(m.FAIR,FAIR,self.fa),(m.SCHED,SCHED,self.sh)])
   p=subprocess.run(['git','-C',str(t),'apply','--check','-'],input=patch,text=True,capture_output=True)
   self.assertEqual(p.returncode,0,p.stderr)
   subprocess.run(['git','-C',str(t),'apply','-'],input=patch,text=True,check=True)
   self.assertEqual((t/m.FAIR).read_text(),self.fa)
   subprocess.run(['git','-C',str(t),'apply','--reverse','-'],input=patch,text=True,check=True)
   self.assertEqual((t/m.SCHED).read_text(),SCHED)
 def test_48_fail_closed_changed_preimage(self):
  with tempfile.TemporaryDirectory() as tmp:
   t=Path(tmp);(t/m.FAIR).parent.mkdir(parents=True);(t/m.FAIR).write_text(FAIR)
   (t/m.SCHED).write_text(SCHED)
   f=[t/'a.json',t/'b.json',t/'c.json',t/'r14.json'];[f[i].write_text(json.dumps(d)) for i,d in enumerate((self.r17a,self.result,self.r11,self.r14))]
   with self.assertRaises(m.StageError):m.stage(t,*f,t/'out')
 def test_49_walt_function_prototype_compiles(self):
  # Extract exactly the WALT-facing function declaration and hint branch;
  # test that Clang sees a global symbol only for CONFIG_SCHED_WALT=y.
  header=self.fa[self.fa.index('#ifdef CONFIG_SCHED_WALT'):self.fa.index('/* Existing policy reads real energy model. */')]
  hint=self.fa[self.fa.index('/* Genuine Xiaomi many-wakeup'):self.fa.index('\tpd = rcu_dereference(rd->pd);')]
  pos=hint.index('#endif')
  hint='#ifdef CONFIG_SCHED_WALT\n'+hint[:pos+len('#endif')]
  c='''typedef _Bool bool;
struct task_struct { int *cpus_ptr; };
extern unsigned int sysctl_sched_many_wakeup_threshold;
int smp_processor_id(void);
int cpumask_test_cpu(int cpu,int *mask);
'''+header+hint+"\n return 0; }\n"
  with tempfile.TemporaryDirectory() as tmp:
   t=Path(tmp)
   (t/'x.c').write_text(c)
   for enabled in (True,False):
    cmd=['clang','-std=gnu11','-Wall','-Werror','-c',str(t/'x.c'),'-o',str(t/('on.o' if enabled else 'off.o'))]
    if enabled:cmd.insert(1,'-DCONFIG_SCHED_WALT')
    else:cmd.insert(4,'-Wno-unused-function')
    p=subprocess.run(cmd,capture_output=True,text=True)
    self.assertEqual(p.returncode,0,p.stderr)
    nm=subprocess.run(['nm','-g',str(t/('on.o' if enabled else 'off.o'))],capture_output=True,text=True)
    self.assertEqual(nm.returncode,0)
    self.assertEqual(' T find_energy_efficient_cpu' in nm.stdout, enabled)
 def test_50_no_flash_paths(self):
  s=Path(m.__file__).read_text()
  for token in ('fastboot flash','magiskboot repack','mkbootimg','sudo dd '):self.assertNotIn(token,s)


 def test_51_r14_real_fair_hash(self):
  import gzip
  real=gzip.decompress((ROOT/'fixtures/R14_REAL_fair.c.gz').read_bytes()).decode()
  self.assertEqual(m.sha(real),m.R14_FAIR_SHA)
  self.assertEqual(self.r14['before_sha256'][m.FAIR],m.R11_FAIR_SHA)
  self.assertEqual(self.r14['after_sha256'][m.FAIR],m.R14_FAIR_SHA)
 def test_52_r17a_real_sched_hash(self):
  import gzip
  h=gzip.decompress((ROOT/'fixtures/R17A_REAL_sched.h.gz').read_bytes()).decode()
  self.assertEqual(m.sha(h),m.R17A_SCHED_SHA)
 def test_53_real_complete_file_patch_roundtrip(self):
  import gzip,difflib
  srcs={m.FAIR:gzip.decompress((ROOT/'fixtures/R14_REAL_fair.c.gz').read_bytes()).decode(),
        m.SCHED:gzip.decompress((ROOT/'fixtures/R17A_REAL_sched.h.gz').read_bytes()).decode()}
  updates={m.FAIR:m.patch_fair(srcs[m.FAIR]),m.SCHED:m.patch_sched(srcs[m.SCHED])}
  self.assertEqual(m.sha(updates[m.FAIR]),'45d27603b9b506c3872dbcec1703aa45b76504565fcebbab932611e3b8681994')
  with tempfile.TemporaryDirectory() as tmp:
   t=Path(tmp);subprocess.run(['git','init','-q',str(t)],check=True)
   for path,content in srcs.items():
    p=t/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
   patch=''.join(''.join(difflib.unified_diff(srcs[n].splitlines(keepends=True),updates[n].splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n in m.FILES)
   self.assertEqual(subprocess.run(['git','-C',str(t),'apply','--check','-'],input=patch,text=True,capture_output=True).returncode,0)
   self.assertEqual(subprocess.run(['git','-C',str(t),'apply','-'],input=patch,text=True,capture_output=True).returncode,0)
   for k,expected in updates.items():self.assertEqual((t/k).read_text(),expected)
   self.assertEqual(subprocess.run(['git','-C',str(t),'apply','--reverse','--check','-'],input=patch,text=True,capture_output=True).returncode,0)
   self.assertEqual(subprocess.run(['git','-C',str(t),'apply','--reverse','-'],input=patch,text=True,capture_output=True).returncode,0)
   for k,expected in srcs.items():self.assertEqual((t/k).read_text(),expected)
 def test_54_forged_r14_postimage_rejected(self):
  x=copy.deepcopy(self.r14);x['after_sha256'][m.FAIR]='0'*64
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,self.result,self.r11,x)
 def test_55_forged_r14_preimage_rejected(self):
  x=copy.deepcopy(self.r14);x['before_sha256'][m.FAIR]='0'*64
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,self.result,self.r11,x)
 def test_56_forged_r14_source_flag_rejected(self):
  x=copy.deepcopy(self.r14);x['source_r11_verified']=False
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,self.result,self.r11,x)
 def test_57_forged_r14_release_rejected(self):
  x=copy.deepcopy(self.r14);x['flash_allowed']=True
  with self.assertRaises(m.StageError):m.validate_input(self.r17a,self.result,self.r11,x)
 def test_58_original_r11_preserved_separately(self):
  self.assertNotEqual(m.R11_FAIR_SHA,m.R14_FAIR_SHA)
  self.assertEqual(self.r14['before_sha256'][m.FAIR],m.R11_FAIR_SHA)
if __name__=='__main__':unittest.main()
