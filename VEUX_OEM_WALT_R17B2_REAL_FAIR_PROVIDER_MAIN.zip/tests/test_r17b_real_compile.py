#!/usr/bin/env python3
"""R17B compiler adapter safety: authentic R17A and real LLVM symbol formats."""
from pathlib import Path
import hashlib, json, re, subprocess, sys, tempfile, unittest
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r17b_real_compile as m

class CompilerTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.prev=json.loads((ROOT/'fixtures/R17A_COMPILER_RESULT_GITHUB.json').read_text())
  cls.source=json.loads((ROOT/'fixtures/R17A_SOURCE_GATE_GITHUB.json').read_text())
  cls.r11=json.loads((ROOT/'fixtures/R11_SOURCE_GATE_GITHUB.json').read_text())
  cls.r14=json.loads((ROOT/'fixtures/R14_SOURCE_GATE_GITHUB.json').read_text())
  cls.adapter=(ROOT/'fixtures/r17a_real_object_compile.py').read_text()
 def test_01_count_prior(self):self.assertEqual(len(self.prev['objects']),12)
 def test_02_count_success(self):self.assertEqual(self.prev['object_success_count'],11)
 def test_03_exact_qc_failure(self):self.assertFalse(self.prev['objects']['kernel/sched/walt/qc_vas.o']['compiled'])
 def test_04_prev_fair(self):self.assertTrue(self.prev['objects']['kernel/sched/fair.o']['compiled'])
 def test_05_prev_core(self):self.assertTrue(self.prev['objects']['kernel/sched/core.o']['compiled'])
 def test_06_prev_topo(self):self.assertTrue(self.prev['objects']['kernel/sched/topology.o']['compiled'])
 def test_07_prev_cpu(self):self.assertTrue(self.prev['objects']['kernel/cpu.o']['compiled'])
 def test_08_prev_symbol_gate(self):self.assertTrue(self.prev['symbol_evidence']['symbols_verified'])
 def test_09_no_kernel(self):self.assertFalse(self.prev['kernel_image_built'])
 def test_10_no_abi(self):self.assertFalse(self.prev['vendor_abi_proven'])
 def test_11_no_vmlinux(self):self.assertFalse(self.prev['vmlinux_linked'])
 def test_12_no_flash(self):self.assertFalse(self.prev['flash_allowed'])
 def test_13_original_source_status(self):self.assertEqual(self.source['status'],'R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED')
 def test_14_original_source_post_sha(self):self.assertEqual(self.source['after_sha256'],self.prev['r17a_postimages'])
 def test_15_r11_fair_hash(self):self.assertEqual(self.r11['after_sha256']['kernel/sched/fair.c'],'f594f7286e068a7009a06e2cb8ae7ac6b10b95a8901580e79a67481a477a8ad3')
 def test_16_root_scope(self):self.assertEqual(m.FAIR,'kernel/sched/fair.c')
 def test_17_sched_scope(self):self.assertEqual(m.SCHED,'kernel/sched/sched.h')
 def test_18_both_symbols(self):self.assertEqual(m.SYMBOLS,('find_energy_efficient_cpu','active_load_balance_cpu_stop'))
 def test_19_count_symbol_spec(self):self.assertEqual(len(m.SYMBOLS),2)
 def test_20_adapter_sha(self):self.assertEqual(hashlib.sha256((ROOT/'fixtures/r17a_real_object_compile.py').read_bytes()).hexdigest(),m.KNOWN_R17A_SHA)
 def test_21_r9_pin_preserved(self):self.assertIn("R9_DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'",self.adapter)
 def test_22_driver_deletes_stale_objects(self):self.assertIn('stale.unlink()',self.adapter)
 def test_23_driver_true_obj_guard(self):self.assertIn("outcome.get('exit_code')==0",self.adapter)
 def test_24_driver_timeout_guard(self):self.assertIn("outcome.get('timed_out') is False",self.adapter)
 def test_25_driver_llvm_dashed(self):
  import importlib.util
  p=ROOT/'fixtures/r17a_real_object_compile.py'
  spec=importlib.util.spec_from_file_location('r17b_pinned_r17a_test',p)
  adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
  self.assertEqual(adapter.parse_nm('---------------- T find_energy_efficient_cpu\n'),
                   [('T','find_energy_efficient_cpu')])
 def test_26_no_release_gate(self):self.assertTrue({'vendor_abi_proven','kernel_image_built','vmlinux_linked','flash_allowed'}.issubset(m.NO_SUCCESS))
 def test_27_brene_guard(self):self.assertIn('brene_changed',m.NO_SUCCESS)
 def test_28_previous_safety_semantics(self):
  text=Path(m.__file__).read_text();self.assertIn('R17B_REQUIRED_WALT_CONFIG_MISSING',text)
 def test_29_prev_object_result_count_consistent(self):self.assertEqual(sum(o['compiled'] for o in self.prev['objects'].values()),11)
 def test_30_nm_real_5_provider_orig(self):
  self.assertCountEqual(sum([list(x['symbols']) for x in self.prev['symbol_evidence']['providers'].values()],[]),['__cpu_isolated_mask','migrate_swap','calc_load_migrate','proc_douintvec_capacity','init_sched_groups_capacity'])
 def test_31_real_fair_symbols_clang17(self):
  src='''int find_energy_efficient_cpu(void *p, int prev, int sync, int hint) { return hint ? prev : sync; }\nint active_load_balance_cpu_stop(void *p) { return p!=0; }\n'''
  with tempfile.TemporaryDirectory() as tmp:
   c=Path(tmp)/'src.c';o=Path(tmp)/'src.o';c.write_text(src)
   r=subprocess.run(['clang','-std=gnu11','-O0','-c',str(c),'-o',str(o)],capture_output=True,text=True)
   self.assertEqual(r.returncode,0,r.stderr)
   nm=subprocess.run(['nm','-g',str(o)],capture_output=True,text=True)
   self.assertEqual(nm.returncode,0)
   self.assertTrue(all(re.search(r'\bT\s+'+s+r'\b',nm.stdout) for s in m.SYMBOLS),nm.stdout)
 def test_32_flag_partial_never_success(self):
  s=Path(m.__file__).read_text();self.assertIn('count==12 and preserved==11 and fair_compiled',s)
 def test_33_flag_no_link(self):self.assertIn('No vmlinux, kernel image, ABI, CRC or device tests performed',Path(m.__file__).read_text())
 def test_34_no_pretend_flash(self):
  for p in (ROOT/'r17b_fair_provider.py',ROOT/'r17b_real_compile.py'):
   c=p.read_text();self.assertNotIn('fastboot flash',c);self.assertNotIn('flash.sh',c)
 def test_35_fail_if_output_exists(self):
  # A compiler report is never overwritten by new results.
  s=Path(m.__file__).read_text();self.assertIn("'OUTPUT_ALREADY_EXISTS'",s)
 def test_36_artifact_no_lto_false_pass(self):
  s=Path(m.__file__).read_text();self.assertIn("any(n==s and c=='T' for c,n in parsed)",s)
 def test_37_manifest_requires_adapter_hash(self):self.assertEqual(len(m.KNOWN_R17A_SHA),64)
 def test_38_script_python_syntax(self):
  import py_compile
  for name in ('r17b_fair_provider.py','r17b_real_compile.py'):
   py_compile.compile(str(ROOT/name),doraise=True)
 def test_39_prev_state_consistency(self):self.assertEqual(self.prev['status'],'R17A_OBJECT_OR_SYMBOL_DIAGNOSTICS_RECORDED')
 def test_40_qc_not_falsely_successful(self):self.assertEqual(self.prev['objects']['kernel/sched/walt/qc_vas.o']['object_bytes'],0)
 def test_41_compiler_r14_gate_is_mandatory(self):
  src=Path(m.__file__).read_text()
  self.assertIn('q.r14_source',src)
  self.assertIn('R14_FAIR_PREIMAGE_MISMATCH',src)
  self.assertIn("'r14-source'",src)
 def test_42_r14_hash_differs_r11_hash(self):
  self.assertEqual(self.r14['before_sha256'][m.FAIR],self.r11['after_sha256'][m.FAIR])
  self.assertNotEqual(self.r14['before_sha256'][m.FAIR],self.r14['after_sha256'][m.FAIR])
if __name__=='__main__':unittest.main()
