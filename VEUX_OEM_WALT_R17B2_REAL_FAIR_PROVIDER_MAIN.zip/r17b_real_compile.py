#!/usr/bin/env python3
"""R17B: genuinely rebuild 12 ARM64 objects after Xiaomi EAS+balance port.

Reuses the exact R17A historical Clang 12 Kbuild adapter. Results are independently
validated against the R17B fair/sched source hashes and two real fair.o providers.
No full link, image, ABI or flash claim. Errors remain recorded as diagnostics.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,os
from pathlib import Path
import subprocess,sys,re

KNOWN_R17A_SHA='a92e16e2ed3685b45db09d2603ff5696dbea25a8308f2c92a9d2f00cecd043c2'
FAIR='kernel/sched/fair.c';SCHED='kernel/sched/sched.h'
SYMBOLS=('find_energy_efficient_cpu','active_load_balance_cpu_stop')
NO_SUCCESS=('vendor_abi_proven','flash_allowed','kernel_image_built','vmlinux_linked','brene_changed','bakasusu_nomount_changed','runtime_tested')

class GateError(Exception):pass

def need(x,m):
    if not x:raise GateError(m)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())

def validate(q):
    for p in (q.snapshot,q.objout,q.toolchain,q.canonical,q.project):
        need(p.is_dir() and not p.is_symlink(),'INVALID_DIR:'+str(p))
    need(q.snapshot.resolve()!=q.project.resolve() and q.snapshot.resolve()!=q.canonical.resolve(),
         'ORIGINAL_SOURCE_MODIFICATION_FORBIDDEN')
    need(not q.output.exists() and not q.output.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    for p in (q.r17a_source,q.r17a_result,q.r16_source,q.r16_result,q.source_gate,
              q.config,q.r9_driver,q.r17a_adapter,q.r11_source,q.r14_source):
        need(p.is_file() and not p.is_symlink(),'UNSAFE_OR_MISSING_INPUT:'+str(p))
    source=read(q.source_gate);old=read(q.r17a_result)
    need(source.get('status')=='R17B_FAIR_OEM_SCHEDULER_APIS_STAGED_NOT_COMPILED',
         'R17B_SOURCE_NOT_STAGED')
    need(source.get('modified_files')==[FAIR,SCHED],'R17B_SCOPE_CHANGED')
    need(source.get('source_r17a_proven') is True,'R17B_PREVIOUS_SOURCE_UNVERIFIED')
    need(old.get('real_arm64_make_attempted') is True and old.get('object_success_count')==11 and
         old.get('qc_vas_compiled') is False and old.get('topology_compiled') is True and
         old.get('symbol_evidence',{}).get('symbols_verified') is True,
         'R17A_11_OF_12_OR_SYMBOLS_NOT_PROVEN')
    need(len(old.get('objects',{}))==12,'R17A_MISSING_OBJECTS')
    r11=read(q.r11_source);r14=read(q.r14_source)
    need(source.get('source_r14_verified') is True,'R17B_R14_SOURCE_NOT_VERIFIED')
    need(r14.get('status')=='R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED' and
         r14.get('source_r11_verified') is True,'R14_SOURCE_GATE_BAD')
    need(r14.get('before_sha256',{}).get(FAIR)==r11.get('after_sha256',{}).get(FAIR),
         'R11_TO_R14_PROVENANCE_DRIFT')
    need(source.get('before_sha256',{}).get(FAIR)==r14.get('after_sha256',{}).get(FAIR)==
         source.get('r14_fair_preimage_sha256')=='1768030ba2723f01568ec2aceb7b9dec044d25b16eea83181c42f79ccae37179',
         'R14_FAIR_PREIMAGE_MISMATCH')
    need(source.get('before_sha256',{}).get(SCHED)==
         read(q.r17a_source).get('after_sha256',{}).get(SCHED),'R17A_SCHED_PREIMAGE_MISMATCH')
    for path,h in source.get('after_sha256',{}).items():
        p=q.snapshot/path
        need(p.is_file() and not p.is_symlink() and sha(p)==h,'SOURCE_POSTIMAGE_CHANGED:'+path)
    for p in (source,old):
        for f in ('vendor_abi_proven','flash_allowed','kernel_image_built','vmlinux_linked',
                  'brene_changed','bakasusu_nomount_changed'):
            need(p.get(f) is False,'FALSE_RELEASE_OR_UNPROVEN_FLAG:'+f)
    config=q.config.read_text()
    for required in ('CONFIG_SCHED_WALT=y','CONFIG_SMP=y','CONFIG_HOTPLUG_CPU=y','CONFIG_QGKI=y'):
        need(re.search(r'(?m)^'+re.escape(required)+r'$',config) is not None,
             'R17B_REQUIRED_WALT_CONFIG_MISSING:'+required)
    need(sha(q.r17a_adapter)==KNOWN_R17A_SHA,'R17A_ADAPTER_MISMATCH')
    return source,old

def run(q):
    source,old=validate(q)
    spec=importlib.util.spec_from_file_location('r17b_pinned_r17a',q.r17a_adapter)
    need(spec and spec.loader,'R17A_ADAPTER_NOT_IMPORTABLE')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    q.output.mkdir(parents=True)
    # Start a machine-readable incomplete result before invoking any compiler.
    result={'status':'R17B_IN_PROGRESS','objects':{},'object_success_count':0,
            'source_r17b_verified':True,'prior_r17a_count':old['object_success_count'],
            **{k:False for k in NO_SUCCESS}}
    path=q.output/'R17B_COMPILER_RESULT.json';path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    # Genuine repeat of exactly the R17A historical Kbuild commands. The
    # old R17A main_run validates *old* sched.h and cannot be reused after
    # R17B modifies it. Its fresh_compile and symbol_audit are deliberately
    # reused while R17B performs the stronger replacement source gate.
    r9spec=importlib.util.spec_from_file_location('r17b_original_r9_kbuild',q.r9_driver)
    need(r9spec and r9spec.loader,'R9_KBUILD_DRIVER_NOT_LOADABLE')
    driver=importlib.util.module_from_spec(r9spec);r9spec.loader.exec_module(driver)
    need(sha(q.r9_driver)==mod.R9_DRIVER_SHA,'R9_COMPILER_DRIVER_NOT_PINNED')
    logs=q.output/'compiler_logs';logs.mkdir()
    compiled={'objects':{},'symbol_evidence':{},'real_arm64_make_attempted':False}
    env=os.environ.copy();env['PATH']=str(q.toolchain/'bin')+os.pathsep+env.get('PATH','')
    for target in mod.TARGETS:
        compiled['real_arm64_make_attempted']=True
        compiled['objects'][target]=mod.fresh_compile(q,driver,target,logs,env)
        result['objects']=compiled['objects']
        path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    compiled['symbol_evidence']=mod.symbol_audit(q,compiled['objects'])
    need(compiled.get('real_arm64_make_attempted') is True and len(compiled.get('objects',{}))==12,
         'R17B_KBUILD_ACTUALLY_NOT_DONE')
    count=sum(obj.get('compiled') is True for obj in compiled['objects'].values())
    preserved=sum(compiled['objects'][obj].get('compiled') is True for obj in old['objects']
                  if old['objects'][obj].get('compiled') is True)
    fair_compiled=compiled['objects'][FAIR[:-1]+'o']['compiled'] is True
    name=q.objout/(FAIR[:-1]+'o')
    record={'tool_invoked':False,'target':FAIR[:-1]+'o','symbols':{},'symbols_verified':False}
    if fair_compiled and name.is_file() and not name.is_symlink():
        nm=q.toolchain/'bin/llvm-nm'
        p=subprocess.run([str(nm),'--defined-only',str(name)],
                          capture_output=True,text=True,timeout=30)
        (q.output/'R17B_FAIR_DEFINED_SYMBOLS.nm.txt').write_text(p.stdout+p.stderr)
        record['tool_invoked']=True
        record['exit_code']=p.returncode
        parsed=mod.parse_nm(p.stdout) if p.returncode==0 else []
        record['symbols']={s:{'defined':any(n==s and c=='T' for c,n in parsed),
                               'kinds':[c for c,n in parsed if n==s]} for s in SYMBOLS}
        record['symbols_verified']=p.returncode==0 and all(
            v['defined'] for v in record['symbols'].values())
    else:
        record['symbols']={s:{'defined':False,'kinds':[]} for s in SYMBOLS}
    prior_providers=compiled['symbol_evidence']['symbols_verified'] is True
    full=(count==12 and preserved==11 and fair_compiled and prior_providers
          and record['symbols_verified'])
    result.update({'status':'R17B_TWELVE_OBJECTS_AND_SEVEN_PROVIDERS_COMPILED_NO_LINK' if full
                   else 'R17B_REAL_OBJECT_OR_PROVIDER_DIAGNOSTICS_RECORDED',
                   'objects':compiled['objects'],'object_success_count':count,
                   'previous_eleven_preserved':preserved,
                   'qc_vas_compiled':compiled['objects']['kernel/sched/walt/qc_vas.o']['compiled'],
                   'fair_symbols':record,'prior_five_provider_symbols':prior_providers,
                   'real_arm64_make_attempted':True,
                   'r17b_postimages':source['after_sha256'],
                   'kernel_version':'5.4.274','note':'No vmlinux, kernel image, ABI, CRC or device tests performed'})
    path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(f"R17B_REAL_ARM64={count}/12; PREVIOUS={preserved}/11; "
          f"FAIR_PROVIDERS={int(record['symbols_verified'])}; QC_VAS={int(result['qc_vas_compiled'])}; "
          f"STATUS={result['status']}; IMAGE=NO; ABI=OPEN; FLASH=NO")
    return result

def main(argv=None):
    ap=argparse.ArgumentParser()
    for k in ('snapshot','canonical','objout','toolchain','project','source-gate',
              'r17a-source','r17a-result','r16-source','r16-result','r11-source','r14-source',
              'r9-driver','r17a-adapter','config','output'):
        ap.add_argument('--'+k,type=Path,required=True)
    q=ap.parse_args(argv)
    try:run(q)
    except (GateError,OSError,ValueError,KeyError,UnicodeError,subprocess.TimeoutExpired) as e:
        print('R17B_REAL_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr)
        return 2
    return 0
if __name__=='__main__':sys.exit(main())
