# VEUX Stock 5.4.274 – R17: Hrtimer-Pinned-State-Quellkorrektur (NOFLASH)

Der echte R16-Compilerlog aus GitHub-Lauf 42103252284 bestätigt **genau einen** verbliebenen Quellfehler in `kernel/time/hrtimer.c`: `HRTIMER_STATE_PINNED` fehlt im 5.4.268-Spender-Header. Das Qualcomm-Quellstück der Timer-Migration setzt diesen Zustand voraus.

R17 ergänzt **im temporären Worktree** die beiden originalen Stock-5.4.274-Zustandsdefinitionen und die zugehörigen Zustandsübergänge anhand der fest gepinnten Qualcomm-5.4.61-Implementierung: Enqueue, Remove, Cancel, Start/Restart, Active. Der restliche 5.4.268-Kernel-Code wird nicht durch fremden Quellstand überschrieben. Keine Abschaltung von Funktionen, keine CRC-Fälschung.

GitHub kompiliert die bisherigen neun WALT-/Scheduler-Objekte plus die vier Anbieter-Objekte `sysctl`, `watchdog`, `hrtimer`, `timer` erneut. Diese sind **12 eindeutige Objektpfade**: `kernel/sysctl.o` war in den vorherigen Tabellen doppelt als WALT-Bestandteil und Anbieter gezählt worden. Kompilieren ersetzt weder Linking noch ABI-/Boot-/Runtime-Prüfungen.

Bündel enthält das originale R16-MAIN. Darin ist das originale R15-MAIN integriert; R14/R13/R12/R11 sind ebenfalls verschachtelt. Du lädst **nur R17-MAIN und R17-YAML** hoch.

## Sperren

- Immutable R6-Referenz und unveränderter Spender-Git-Checkout; nur isolierter Worktree wird bearbeitet.
- Alle echten Stock-/Qualcomm-Hashwerte und Quellanker werden geprüft.
- Compilerfehler markieren GitHub ROT, Fehlerlogs werden dennoch hochgeladen.
- Kein `boot.img`, kein AK3, kein Full-Link, keine `Module.symvers`-ABI-Freigabe, **FLASH=NO**.

Für den endgültigen VEUX-Stock-Kernel sind vollständige originale 5.4.274-Quellen und die OEM-Modul-ABI weiterhin notwendig; außerdem fehlt RTMM. WALT-Teilobjekte können das nicht beweisen.
