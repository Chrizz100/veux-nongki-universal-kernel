#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from unittest.mock import patch

SRC=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r17p', SRC/'r17_hrtimer_pin.py')
r17=importlib.util.module_from_spec(spec);spec.loader.exec_module(r17)
ROOT=SRC.parent
STOCK=(ROOT/'reference/stock_hrtimer.h').read_text()
DONOR_H='#define HRTIMER_STATE_INACTIVE\t0x00\n#define HRTIMER_STATE_ENQUEUED\t0x01\n\nstruct hrtimer { int state; };'
# Exact identifiable source blocks, not substituted in any real kernel source.
DONOR='''
static int enqueue_hrtimer(void) {
    WRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);
}
static void __remove_hrtimer(void) {
    WRITE_ONCE(timer->state, newstate);
}
static int remove_hrtimer(void) {
\t\t__remove_hrtimer(timer, base, state, reprogram);
\t\treturn 1;
}
static int __hrtimer_start_range_ns(void) {
\tfirst = enqueue_hrtimer(timer, new_base, mode);
}
bool hrtimer_active(void) {
\t\tif (timer->state != HRTIMER_STATE_INACTIVE ||
\t\t    base->running == timer)
\t\t\treturn true;
}
static void migrate_hrtimer_list(void) { is_pinned = timer->state & HRTIMER_STATE_PINNED; }
'''
UPSTREAM='''
WRITE_ONCE(timer->state, timer->state | HRTIMER_STATE_ENQUEUED);
WRITE_ONCE(timer->state, newstate | (timer->state & HRTIMER_STATE_PINNED));
timer->state &= ~HRTIMER_STATE_PINNED;
timer->state |= (!!(mode & HRTIMER_MODE_PINNED)) << HRTIMER_PINNED_SHIFT;
if (((timer->state & ~HRTIMER_STATE_PINNED) !=
'''

class R17Tests(unittest.TestCase):
    def test_01_main_manifest(self):self.assertEqual(r17.verify_main(ROOT)['schema'],r17.SCHEMA)
    def test_02_parent_original(self):self.assertEqual(r17.sha((ROOT/'reference/R16_MAIN_ORIGINAL.zip').read_bytes()),r17.R16_SHA)
    def test_03_original_stock_header(self):self.assertEqual(r17.sha(STOCK.encode()),r17.STOCK_HRTIMER_SHA)
    def test_04_nested_r16_not_replaced(self):
        with ZipFile(ROOT/'reference/R16_MAIN_ORIGINAL.zip') as z:
            self.assertIsNone(z.testzip());self.assertEqual(json.loads(z.read('MANIFEST_SHA256.json'))['schema'],'VEUX_STOCK_R16_HRTIMER_DIAGNOSTIC_NOFLASH')
    def test_05_original_stock_genuine_pinned(self):
        self.assertIn('#define HRTIMER_PINNED_SHIFT\t1',STOCK)
        self.assertIn('#define HRTIMER_STATE_PINNED\t(1 << HRTIMER_PINNED_SHIFT)',STOCK)
    def test_06_patched_header_exact(self):
        s=r17.patch_header(DONOR_H,STOCK)
        self.assertEqual(s.count('HRTIMER_STATE_PINNED'),1)
        self.assertEqual(s.count('HRTIMER_PINNED_SHIFT'),2)
    def test_07_header_missing_original_rejected(self):
        with self.assertRaises(ValueError):r17.patch_header(DONOR_H,STOCK.replace('#define HRTIMER_PINNED_SHIFT\t1','#define HRTIMER_PINNED_SHIFT\t0'))
    def test_08_header_already_modified_rejected(self):
        with self.assertRaises(ValueError):r17.patch_header(DONOR_H+'\n#define HRTIMER_STATE_PINNED 2',STOCK)
    def test_09_header_anchor_duplicate_rejected(self):
        with self.assertRaises(ValueError):r17.patch_header(DONOR_H+'\n#define HRTIMER_STATE_ENQUEUED\t0x01',STOCK)
    def test_10_source_lifecycle_all_anchors(self):
        s=r17.patch_source(DONOR,UPSTREAM)
        self.assertIn('WRITE_ONCE(timer->state, timer->state | HRTIMER_STATE_ENQUEUED)',s)
        self.assertIn('timer->state |= (!!(mode & HRTIMER_MODE_PINNED)) << HRTIMER_PINNED_SHIFT;',s)
        self.assertIn('timer->state &= ~HRTIMER_STATE_PINNED;',s)
        self.assertIn('~HRTIMER_STATE_PINNED',s)
    def test_11_source_preserves_existing_other_code(self):
        s=r17.patch_source(DONOR+'\n/* original donor branch-specific fixes */\n',UPSTREAM)
        self.assertIn('original donor branch-specific fixes',s)
    def test_12_source_rejects_missing_enqueue(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('WRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);',''),UPSTREAM)
    def test_13_source_rejects_duplicate_enqueue(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR+'\nWRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);',UPSTREAM)
    def test_14_source_rejects_missing_remove(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('WRITE_ONCE(timer->state, newstate);',''),UPSTREAM)
    def test_15_source_rejects_missing_cancel(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('return 1;','return 2;'),UPSTREAM)
    def test_16_source_rejects_missing_start(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('first = enqueue_hrtimer(timer, new_base, mode);','first = 0;'),UPSTREAM)
    def test_17_source_rejects_missing_active(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('timer->state != HRTIMER_STATE_INACTIVE','timer->state > HRTIMER_STATE_INACTIVE'),UPSTREAM)
    def test_18_source_missing_upstream_semantics_rejected(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR,UPSTREAM.replace('WRITE_ONCE(timer->state, newstate | (timer->state & HRTIMER_STATE_PINNED));',''))
    def test_19_source_already_patched_rejected(self):
        patched=r17.patch_source(DONOR,UPSTREAM)
        with self.assertRaises(ValueError):r17.patch_source(patched,UPSTREAM)
    def test_20_source_disallows_absent_qualsem_original(self):
        with self.assertRaises(ValueError):r17.patch_source(DONOR.replace('is_pinned = timer->state & HRTIMER_STATE_PINNED;',''),UPSTREAM)
    def test_21_header_1bit_is_not_mode_bit(self):
        p=r17.patch_header(DONOR_H,STOCK)
        self.assertNotIn('HRTIMER_MODE_PINNED\t0x01',p)
    def test_22_immutable_r6_r16_contract(self):
        m=r17.verify_main(ROOT)
        self.assertFalse(m['production_patch_approved']);self.assertFalse(m['flash_allowed']);self.assertFalse(m['oem_abi_verified'])
    def test_23_tamper_rejected(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp);shutil.copytree(ROOT,t/'x')
            (t/'x/README_ERST_LESEN.md').write_text('tampered')
            with self.assertRaises(ValueError):r17.verify_main(t/'x')
    def test_24_manifest_fail_closed(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp);shutil.copytree(ROOT,t/'x')
            p=t/'x/MANIFEST_SHA256.json';m=json.loads(p.read_text());m['flash_allowed']=True;p.write_text(json.dumps(m))
            with self.assertRaises(ValueError):r17.verify_main(t/'x')
    def test_25_summary_failure_never_green(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp);z=ZipFile(ROOT/'reference/R16_GITHUB_COMPILER_EVIDENCE.zip')
            for name in ('R15_TWELVE_OBJECTS_SUMMARY.json','R14_NINE_WALT_OBJECTS_SUMMARY.json'):(t/name).write_bytes(z.read(name))
            (t/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').write_text(json.dumps({'donor_original_clean':True,'stock_task_preserved':True}))
            o=r17.summary(t,t)
            self.assertFalse(o['r17_all_component_compilers_pass']);self.assertIn('HRTIMER',o['failures'])
    def test_26_no_flash_summary(self):
        import shutil
        with tempfile.TemporaryDirectory() as tmp:
            t=Path(tmp);z=ZipFile(ROOT/'reference/R16_GITHUB_COMPILER_EVIDENCE.zip')
            for name in ('R15_TWELVE_OBJECTS_SUMMARY.json','R14_NINE_WALT_OBJECTS_SUMMARY.json'):(t/name).write_bytes(z.read(name))
            (t/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').write_text(json.dumps({'donor_original_clean':True,'stock_task_preserved':True}))
            o=r17.summary(t,t)
            self.assertFalse(o['flash_allowed']);self.assertFalse(o['vmlinux_linked']);self.assertFalse(o['boot_verified'])

    def test_27_summary_true_only_with_all_real_objects(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with ZipFile(ROOT/'reference/R16_GITHUB_COMPILER_EVIDENCE.zip') as z:
                o=json.loads(z.read('R15_TWELVE_OBJECTS_SUMMARY.json'))
                base=json.loads(z.read('R14_NINE_WALT_OBJECTS_SUMMARY.json'))
            o['twelve_object_compilation_pass']=True
            o['provider_objects']['HRTIMER']['rc']=0
            o['provider_objects']['HRTIMER']['compiler_errors']=[]
            o['provider_objects']['HRTIMER']['exists']=True
            allobjs={**o['component_objects'],**o['provider_objects']}
            for val in allobjs.values():
                target=root/val['object'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'\x7fELF')
            (root/'R15_TWELVE_OBJECTS_SUMMARY.json').write_text(json.dumps(o))
            (root/'R14_NINE_WALT_OBJECTS_SUMMARY.json').write_text(json.dumps(base))
            (root/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').write_text(json.dumps({'donor_original_clean':True,'stock_task_preserved':True}))
            result=r17.summary(root,root)
            self.assertTrue(result['r17_all_component_compilers_pass'])
            self.assertEqual(result['r17_12_unique_object_files'],12)
            self.assertFalse(result['flash_allowed'])
            self.assertFalse(result['vmlinux_linked'])
    def test_28_summary_missing_one_real_binary_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            with ZipFile(ROOT/'reference/R16_GITHUB_COMPILER_EVIDENCE.zip') as z:
                o=json.loads(z.read('R15_TWELVE_OBJECTS_SUMMARY.json'))
                base=json.loads(z.read('R14_NINE_WALT_OBJECTS_SUMMARY.json'))
            o['twelve_object_compilation_pass']=True
            o['provider_objects']['HRTIMER']['rc']=0
            o['provider_objects']['HRTIMER']['compiler_errors']=[]
            o['provider_objects']['HRTIMER']['exists']=True
            allobjs={**o['component_objects'],**o['provider_objects']}
            for val in allobjs.values():
                if val['object']=='kernel/time/hrtimer.o':continue
                target=root/val['object'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'\x7fELF')
            (root/'R15_TWELVE_OBJECTS_SUMMARY.json').write_text(json.dumps(o))
            (root/'R14_NINE_WALT_OBJECTS_SUMMARY.json').write_text(json.dumps(base))
            (root/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').write_text(json.dumps({'donor_original_clean':True,'stock_task_preserved':True}))
            result=r17.summary(root,root)
            self.assertFalse(result['r17_all_component_compilers_pass'])
            self.assertIn('HRTIMER:missing_obj',result['failures'])

if __name__=='__main__':unittest.main()
