#!/usr/bin/env python3
"""VEUX R17: pinned-state HRTIMER lifecycle backport from verified OEM semantics.

All source edits occur in a disposable donor Git worktree. Never flash.
"""
import argparse
import hashlib
import json
import re
import subprocess
import zipfile
from pathlib import Path

SCHEMA='VEUX_R17_PINNED_HRTIMER_BACKPORT_NOFLASH'
R16_SHA='18263bfbe35f1a216e6d621b58fe9c3d787f1279a705a2f6239c0eb068f4d59c'
STOCK_HRTIMER_SHA='7e475d274a02aa790ab2375a138cb78f92c3e8fc64686d05e841871322a3e427'
STOCK_TASK_SHA='a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
DONOR_SHA='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
PAIR_SHA='01cb3a8824b7b4caf3e3540274e71abba5ade538'
PAIR_HRTIMER_BLOB='02f1ad059f58afceb8e0484001da28e0a5393b5e'
DONOR_HRTIMER_BLOB='8e3c9228aec97289fb7b937e034d7f7d2a56189f'
DONOR_HEADER_BLOB='1bb58485b2e246484b7599a74fe79b015fed2906'
R15_PRE_PATCH_C_SHA='d954291f3a64e71a6146d4aea8f9404022699350ba3970fbf78467f012a024a4'
R15_PRE_PATCH_H_SHA='7ee4eda5086c2a78b23dc914197a95187c4d057b2369c945b989b77a5020cd66'


def sha(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True,stderr=subprocess.PIPE).strip()
def single(s,a,b):
    n=s.count(a)
    if n!=1:raise ValueError(f'R17_ANCHOR_DRIFT:{n}:{a[:90]}')
    return s.replace(a,b,1)

def verify_main(root):
    root=Path(root)
    if not root.is_dir() or root.is_symlink():raise ValueError('R17_ROOT_INVALID')
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (m.get('schema')!=SCHEMA or m.get('r16_parent_sha256')!=R16_SHA or
        m.get('donor_commit')!=DONOR_SHA or m.get('pair_commit')!=PAIR_SHA or
        any(m.get(k) is not False for k in ('flash_allowed','kernel_built','vmlinux_linked','oem_abi_verified','boot_verified','production_patch_approved'))):
        raise ValueError('R17_SCHEMA_PIN_OR_NOFLASH_VIOLATION')
    files={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if any(p.is_symlink() for p in root.rglob('*')) or files!=set(m['files'])|{'MANIFEST_SHA256.json'}:
        raise ValueError('R17_FILESET_OR_SYMLINK')
    for rel,dig in m['files'].items():
        if sha((root/rel).read_bytes())!=dig:raise ValueError('R17_CONTENT_SHA:'+rel)
    if sha((root/'reference/R16_MAIN_ORIGINAL.zip').read_bytes())!=R16_SHA:
        raise ValueError('R17_PARENT_CHANGED')
    if sha((root/'reference/stock_hrtimer.h').read_bytes())!=STOCK_HRTIMER_SHA:
        raise ValueError('R17_STOCK_SOURCE_CHANGED')
    with zipfile.ZipFile(root/'reference/R16_MAIN_ORIGINAL.zip') as z:
        if z.testzip() or json.loads(z.read('MANIFEST_SHA256.json'))['schema']!='VEUX_STOCK_R16_HRTIMER_DIAGNOSTIC_NOFLASH':
            raise ValueError('R17_NESTED_R16_NOT_GENUINE')
    return m

def patch_header(old,stock):
    # Identical integer states copied from the *actual* Stock 5.4.274 kheaders.
    # Never confuse HRTIMER_MODE_PINNED with HRTIMER_STATE_PINNED.
    pinned='#define HRTIMER_PINNED_SHIFT\t1\n#define HRTIMER_STATE_PINNED\t(1 << HRTIMER_PINNED_SHIFT)'
    if stock.count(pinned)!=1 or 'HRTIMER_STATE_PINNED' in old or 'HRTIMER_PINNED_SHIFT' in old:
        raise ValueError('R17_NOT_AUTHENTIC_STOCK_PINNED_STATE')
    return single(old,'#define HRTIMER_STATE_ENQUEUED\t0x01',
                  '#define HRTIMER_STATE_ENQUEUED\t0x01\n'+pinned)

def patch_source(old,pair):
    """Port verified pinned-state transitions, retaining the donor's other fixes.

    The 5.4.61 Qualcomm source is used as provenance for each state operation;
    *not* a wholesale replacement of the 5.4.268 hrtimer runtime.
    """
    authentic=[
        'WRITE_ONCE(timer->state, timer->state | HRTIMER_STATE_ENQUEUED);',
        'WRITE_ONCE(timer->state, newstate | (timer->state & HRTIMER_STATE_PINNED));',
        'timer->state &= ~HRTIMER_STATE_PINNED;',
        'timer->state |= (!!(mode & HRTIMER_MODE_PINNED)) << HRTIMER_PINNED_SHIFT;',
        'if (((timer->state & ~HRTIMER_STATE_PINNED) !=',
    ]
    for x in authentic:
        if x not in pair:raise ValueError('R17_PINNED_STATE_NOT_IN_VERIFIED_QUALCOMM:'+x)
    if old.count('HRTIMER_STATE_PINNED')!=1:raise ValueError('R17_EXPECT_R15_QUALSEM_MIGRATION_ONLY')
    s=single(old,'WRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);', authentic[0])
    s=single(s,'WRITE_ONCE(timer->state, newstate);',authentic[1])
    # Keep older donor remove/restart locality semantics, adding the vendor's
    # clear-on-cancel behavior immediately after __remove_hrtimer().
    s=single(s,'\t\t__remove_hrtimer(timer, base, state, reprogram);\n\t\treturn 1;',
             '\t\t__remove_hrtimer(timer, base, state, reprogram);\n\t\ttimer->state &= ~HRTIMER_STATE_PINNED;\n\t\treturn 1;')
    # Start/restart must preserve actual pinning state, not only set a macro.
    s=single(s,'\tfirst = enqueue_hrtimer(timer, new_base, mode);',
             '\t/* Original Qualcomm pinned-state update when the timer starts. */\n'
             '\ttimer->state &= ~HRTIMER_STATE_PINNED;\n'
             '\ttimer->state |= (!!(mode & HRTIMER_MODE_PINNED)) << HRTIMER_PINNED_SHIFT;\n'
             '\tfirst = enqueue_hrtimer(timer, new_base, mode);')
    # The pinned state alone is not a running timer; matching upstream semantics.
    s=single(s,'\t\tif (timer->state != HRTIMER_STATE_INACTIVE ||\n\t\t    base->running == timer)',
             '\t\tif (((timer->state & ~HRTIMER_STATE_PINNED) !=\n'
             '\t\t      HRTIMER_STATE_INACTIVE) || base->running == timer)')
    assert s.count('HRTIMER_STATE_PINNED')==5, 'unexpected life cycle state count'
    assert s.count('HRTIMER_PINNED_SHIFT')==1
    return s

def stage(root,trial,pair,donor,reports):
    root,trial,pair,donor,reports=map(Path,(root,trial,pair,donor,reports))
    verify_main(root)
    if (git(trial,'rev-parse','HEAD')!=DONOR_SHA or git(donor,'rev-parse','HEAD')!=DONOR_SHA or
        git(pair,'rev-parse','HEAD')!=PAIR_SHA or git(donor,'status','--porcelain') or git(pair,'status','--porcelain')):
        raise ValueError('R17_GIT_PROVENANCE_OR_ORIGINAL_DIRTY')
    cpath=trial/'kernel/time/hrtimer.c';hpath=trial/'include/linux/hrtimer.h'
    u=pair/'kernel/time/hrtimer.c';task=trial/'include/linux/sched.h'
    if any(p.is_symlink() for p in (cpath,hpath,u,task)):
        raise ValueError('R17_SOURCE_SYMLINK')
    if (git(trial,'rev-parse','HEAD:kernel/time/hrtimer.c')!=DONOR_HRTIMER_BLOB or
        git(trial,'rev-parse','HEAD:include/linux/hrtimer.h')!=DONOR_HEADER_BLOB or
        git(pair,'rev-parse','HEAD:kernel/time/hrtimer.c')!=PAIR_HRTIMER_BLOB or
        gitblob(u.read_bytes())!=PAIR_HRTIMER_BLOB):
        raise ValueError('R17_SOURCE_BLOB_NOT_GENUINE')
    if sha(task.read_bytes())!=STOCK_TASK_SHA:
        raise ValueError('R17_STOCK_TASK_MODIFIED')
    cold,hold=cpath.read_bytes(),hpath.read_bytes()
    if sha(cold)!=R15_PRE_PATCH_C_SHA or sha(hold)!=R15_PRE_PATCH_H_SHA:
        raise ValueError('R17_NOT_EXACT_SUCCESSFUL_R15_TEST_SOURCE')
    # Assert the R16 actual compiler error can be reproduced against this source.
    if 'HRTIMER_STATE_PINNED' not in cold.decode() or 'HRTIMER_STATE_PINNED' in hold.decode():
        raise ValueError('R17_EXPECTED_BLOCKER_NOT_PRESENT')
    hnew=patch_header(hold.decode(),(root/'reference/stock_hrtimer.h').read_text())
    cnew=patch_source(cold.decode(),u.read_text())
    # Check all anchors in-memory before modifying either file.
    hpath.write_text(hnew); cpath.write_text(cnew)
    if git(donor,'status','--porcelain') or sha(task.read_bytes())!=STOCK_TASK_SHA:
        raise ValueError('R17_ORIGINAL_DONOR_OR_STOCK_TASK_MUTATION')
    d={'schema':SCHEMA,'source_sha':{'donor_commit':DONOR_SHA,'pair_commit':PAIR_SHA,
         'upstream_hrtimer_git_blob':PAIR_HRTIMER_BLOB,'stock_hrtimer_header_sha256':STOCK_HRTIMER_SHA},
       'runtime_changes':{'include/linux/hrtimer.h':{'before':sha(hold),'after':sha(hnew.encode())},
                          'kernel/time/hrtimer.c':{'before':sha(cold),'after':sha(cnew.encode())}},
       'stock_task_preserved':True,'donor_original_clean':True,'pinned_enqueue':True,
       'pinned_start_and_restart':True,'pinned_remove_and_cancel':True,
       'pinned_inactive_test':True,'kernel_built':False,'vmlinux_linked':False,
       'oem_abi_verified':False,'boot_verified':False,'flash_allowed':False}
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R17_AUTHENTIC_PINNED_HRTIMER_LIFECYCLE_STAGED':True,'R6_CLEAN':True,'FLASH':False}))
    return d

def summary(reports,build_dir):
    reports,build_dir=map(Path,(reports,build_dir))
    report=json.loads((reports/'R15_TWELVE_OBJECTS_SUMMARY.json').read_text())
    stage=json.loads((reports/'R17_PINNED_HRTIMER_SOURCE_STAGE.json').read_text())
    base=json.loads((reports/'R14_NINE_WALT_OBJECTS_SUMMARY.json').read_text())
    objs={**report['component_objects'],**report['provider_objects']}
    failures=[]
    for name,data in objs.items():
        compiled=(data.get('compiled_object_file_verified') if 'compiled_object_file_verified' in data else data.get('exists'))
        if (data.get('rc')!=0 or not compiled or data.get('compiler_error_count',0)!=0 or data.get('compiler_errors')):
            failures.append(name)
        if not (build_dir/data['object']).is_file(): failures.append(name+':missing_obj')
    allok=(not failures and report['twelve_object_compilation_pass'] and base['individual_compiled_objects_ok'] and
           stage['donor_original_clean'] and stage['stock_task_preserved'])
    out={'schema':SCHEMA,'r17_all_component_compilers_pass':bool(allok),
         'r17_12_unique_object_files':len({v['object'] for v in objs.values()}),
         'failures':failures,'hrtimer_rc':report['provider_objects']['HRTIMER']['rc'],
         'full_scheduler_hooks_ported':False,'stock_rtmm_implemented':False,
         'vmlinux_linked':False,'oem_abi_verified':False,'boot_verified':False,'flash_allowed':False,
         'note':'Component compilation only; no link, no physical boot and no OEM ABI approval.'}
    (reports/'R17_PINNED_HRTIMER_COMPILER_SUMMARY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R17_HRTIMER_RC':out['hrtimer_rc'],'R17_ALL_12_OBJECTS':allok,
                      'FAILURES':failures,'VMLINUX':False,'FLASH':False}))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['verify','stage','summary'])
    for s in ['root','trial','pair','donor','reports','build-dir']:p.add_argument('--'+s)
    a=p.parse_args()
    if a.mode=='verify':print(json.dumps({'schema':verify_main(a.root)['schema'],'NOFLASH':True}))
    elif a.mode=='stage':stage(a.root,a.trial,a.pair,a.donor,a.reports)
    else:summary(a.reports,a.build_dir)
if __name__=='__main__':main()
