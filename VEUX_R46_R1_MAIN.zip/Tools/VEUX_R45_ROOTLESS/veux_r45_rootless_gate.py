#!/usr/bin/env python3
"""VEUX R45: read-only rootless kernel stock comparison / evidence gate.

This tool never patches .config, source, boot, vendor modules or hardware.
A good report is NOT a stock/ABI/boot/flash pass.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import struct
from collections import defaultdict
from pathlib import Path

PINNED_STOCK_CONFIG_SHA = "334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868"
PINNED_R44_CONFIG_SHA = "7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe"
REQUIRED_ROOTLESS = {
    "CONFIG_SCHED_WALT": "y",
    "CONFIG_QGKI": "y",
    "CONFIG_MODULES": "y",
    "CONFIG_MODVERSIONS": "y",
    "CONFIG_ARCH_HOLI": "y",
    "CONFIG_CFI_CLANG": "y",
    "CONFIG_LTO_CLANG": "y",
    "CONFIG_NR_CPUS": "32",
}
FORBIDDEN_POSITIVE = (
    "CONFIG_KSU", "CONFIG_KSU_SUSFS", "CONFIG_SUSFS", "CONFIG_NOMOUNT",
    "CONFIG_SCHED_CASS", "CONFIG_BAKASU", "CONFIG_RESUKISU",
)
CHECK_FIRST = {
    "CONFIG_DM_VERITY_AVB", "CONFIG_FINGERPRINT", "CONFIG_FINGERPRINT_FPC",
    "CONFIG_FINGERPRINT_GOODIX_FOD", "CONFIG_FINGERPRINT_SILEAD", "CONFIG_MIHW",
    "CONFIG_MILLET", "CONFIG_MI_MEMORY_SYSFS", "CONFIG_MI_UFS_FFU", "CONFIG_UFS_WB",
    "CONFIG_QTI_CPU_ISOLATE_COOLING_DEVICE", "CONFIG_PROCESS_RECLAIM",
    "CONFIG_MIUI_ZRAM_MEMORY_TRACKING", "CONFIG_HARDWARE_INFO", "CONFIG_SIMTRAY_STATUS",
}
CONFIG_YES = re.compile(r"^(CONFIG_\w+)=(.*)$")
CONFIG_NO = re.compile(r"^# (CONFIG_\w+) is not set$")
CONFIG_DECL = re.compile(r"^\s*(?:config|menuconfig)\s+([A-Za-z0-9_]+)(?:\s|$)")
SOURCE_SUFFIXES = {".c", ".h", ".S", ".s", ".dts", ".dtsi", ".mk", ".config"}
CRITICAL_SOURCE_GLOBS = (
    "kernel/sched/walt/*", "kernel/sched/core.c", "kernel/sched/fair.c",
    "kernel/sched/sched.h", "kernel/sched/cpufreq_schedutil.c",
    "include/linux/sched/core_ctl.h", "include/trace/events/power.h",
    "fs/proc/internal.h", "drivers/input/fingerprint/**/*",
    "drivers/mihw/*", "drivers/misc/mi-memory/*", "drivers/scsi/ufs/*",
    "drivers/power/supply/qcom/*", "techpack/dataipa/drivers/platform/msm/ipa/ipa_v3/*",
    "arch/arm64/boot/dts/vendor/xiaomi/*", "techpack/datarmnet-ext/**/*",
)


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for data in iter(lambda: f.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def load_config(path: Path) -> dict[str, str]:
    cfg = {}
    for i, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        m = CONFIG_YES.fullmatch(line)
        if m:
            key, value = m.groups()
        else:
            m = CONFIG_NO.fullmatch(line)
            if not m:
                continue
            key, value = m.group(1), "n"
        if key in cfg:
            raise ValueError(f"CONFIG_DUPLICATE:{path.name}:{key}:line{i}")
        cfg[key] = value
    return cfg


def kconfig_declarations(root: Path) -> dict[str, list[str]]:
    mapping: dict[str, list[str]] = defaultdict(list)
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = [x for x in dirnames if x not in (".git", ".repo", "out", "build", "__pycache__")]
        for name in filenames:
            if not (name.startswith("Kconfig") or name.endswith(".Kconfig")):
                continue
            p = Path(dirpath) / name
            if p.is_symlink() or not p.is_file():
                continue
            try:
                lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
            except (PermissionError, OSError):
                continue
            for lineno, line in enumerate(lines, 1):
                m = CONFIG_DECL.match(line)
                if m:
                    mapping["CONFIG_" + m.group(1)].append(f"{p.relative_to(root).as_posix()}:{lineno}")
    return dict(mapping)


def compare(stock: dict[str, str], r44: dict[str, str], origin: dict[str, list[str]] | None = None) -> tuple[list[dict], dict]:
    origin = origin or {}
    rows = []
    counts = defaultdict(int)
    for symbol in sorted(stock.keys() | r44.keys()):
        if symbol not in r44:
            kind = "STOCK_ONLY"
        elif symbol not in stock:
            kind = "R44_ONLY"
        elif stock[symbol] != r44[symbol]:
            kind = "VALUE_DIFFERENT"
        else:
            kind = "SAME"
        counts[kind] += 1
        if kind == "SAME":
            continue
        decl = origin.get(symbol, [])
        rows.append({
            "symbol": symbol,
            "kind": kind,
            "stock": stock.get(symbol, "<MISSING>"),
            "r44": r44.get(symbol, "<MISSING>"),
            "priority": "P0_REVIEW" if symbol in CHECK_FIRST else "P1_REVIEW",
            "defined_in_source": "YES" if decl else "NO" if origin else "UNINSPECTED",
            "kconfig_locations": ";".join(decl),
            "interpretation": "Source presence is not proof of compiled functionality; no automatic enablement",
        })
    return rows, dict(counts)


def rootless_gate(r44: dict[str, str]) -> list[str]:
    errors = []
    for k, v in REQUIRED_ROOTLESS.items():
        if r44.get(k) != v:
            errors.append(f"REQUIRED_CONFIG:{k}:expected={v}:actual={r44.get(k)}")
    for k in FORBIDDEN_POSITIVE:
        if r44.get(k) in ("y", "m"):
            errors.append("FORBIDDEN_ROOT_COMPONENT:" + k)
    return errors


def source_inventory(root: Path) -> list[dict]:
    records = {}
    for pat in CRITICAL_SOURCE_GLOBS:
        for p in root.glob(pat):
            if p.is_file() and not p.is_symlink() and p.suffix in SOURCE_SUFFIXES | {""}:
                rel = p.relative_to(root).as_posix()
                if p.stat().st_size < 5_000_000:
                    records[rel] = {"path": rel, "sha256": sha(p), "size_bytes": p.stat().st_size}
    return [records[k] for k in sorted(records)]


def magic_status(output: Path) -> dict:
    image = output / "arch/arm64/boot/Image"
    elf = output / "vmlinux"
    dtb = output / "arch/arm64/boot/dts/vendor/xiaomi/veux.dtb"
    symvers = output / "Module.symvers"
    result = {}
    for name, path in (("Image", image), ("vmlinux", elf), ("veux.dtb", dtb), ("Module.symvers", symvers)):
        result[name] = {"present": path.is_file() and path.stat().st_size > 0}
        if result[name]["present"]:
            result[name]["sha256"] = sha(path)
            result[name]["bytes"] = path.stat().st_size
    if result["Image"]["present"]:
        with image.open("rb") as f:
            f.seek(0x38)
            result["Image"]["arm64_magic"] = f.read(4) == b"ARM\x64"
    if result["vmlinux"]["present"]:
        with elf.open("rb") as f:
            header = f.read(20)
        result["vmlinux"]["aarch64_elf"] = len(header) >= 20 and header[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", header, 18)[0] == 183
    if result["veux.dtb"]["present"]:
        with dtb.open("rb") as f:
            result["veux.dtb"]["fdt_magic"] = f.read(4) == b"\xd0\x0d\xfe\xed"
    modules = []
    if output.is_dir():
        for p in output.rglob("*.ko"):
            if not p.is_symlink() and p.is_file() and p.stat().st_size > 0:
                with p.open("rb") as f:
                    elf_head = f.read(20)
                elf_ok = len(elf_head) >= 20 and elf_head[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", elf_head, 18)[0] == 183
                modules.append({"path": p.relative_to(output).as_posix(), "sha256": sha(p), "bytes": p.stat().st_size, "aarch64_elf": elf_ok})
    result["modules"] = sorted(modules, key=lambda x: x["path"])
    return result


def write_csv(path: Path, items: list[dict], columns: list[str]):
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(items)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="VEUX R45 rootless stock/ABI evidence, NOFLASH")
    p.add_argument("--stock-config", type=Path, required=True)
    p.add_argument("--r44-config", type=Path, required=True)
    p.add_argument("--source", type=Path, help="fully assembled R44 kernel source, optional")
    p.add_argument("--objout", type=Path, help="same-run R44 kernel build directory, optional")
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--pin-known-config", action="store_true", help="Historical comparison: require both reference SHA hashes")
    p.add_argument("--pin-stock-only", action="store_true", help="New CI build: require authentic Stock SHA; hash new .config as evidence")
    args = p.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    stock_sha = sha(args.stock_config)
    r44_sha = sha(args.r44_config)
    st, r44 = load_config(args.stock_config), load_config(args.r44_config)
    locations = kconfig_declarations(args.source) if args.source else {}
    rows, counts = compare(st, r44, locations)
    issues = rootless_gate(r44)
    if args.pin_known_config and (stock_sha != PINNED_STOCK_CONFIG_SHA or r44_sha != PINNED_R44_CONFIG_SHA):
        issues.append("PINNED_REFERENCE_CONFIG_HASH_DIFFERENT")
    if args.pin_stock_only and stock_sha != PINNED_STOCK_CONFIG_SHA:
        issues.append("PINNED_STOCK_CONFIG_HASH_DIFFERENT")
    if args.source:
        if not args.source.is_dir() or not (args.source / "Makefile").is_file() or not (args.source / "kernel/sched/walt/walt.c").is_file():
            issues.append("INVALID_OR_MISSING_ASSEMBLED_WALT_SOURCE_TREE")
    inv = source_inventory(args.source) if args.source else []
    build = magic_status(args.objout) if args.objout else {"not_checked": True}
    if args.objout:
        for name in ("Image", "vmlinux", "veux.dtb", "Module.symvers"):
            if not build[name].get("present"):
                issues.append("MISSING_PRODUCT:" + name)
        for name, key in (("Image", "arm64_magic"), ("vmlinux", "aarch64_elf"), ("veux.dtb", "fdt_magic")):
            if not build[name].get(key):
                issues.append("PRODUCT_INVALID:" + name)
        symvers = args.objout / "Module.symvers"
        if symvers.is_file():
            with symvers.open(encoding="utf-8", errors="replace") as f:
                valid_symvers = sum(1 for line in f if len(line.strip().split()) >= 4)
            build["module_symvers_valid_entries"] = valid_symvers
            if valid_symvers < 100:
                issues.append("INVALID_OR_INCOMPLETE_MODULE_SYMVERS")
        if len(build["modules"]) < 6:
            issues.append("EXPECTED_R44_MODULE_COUNT_LT_6")
        for module in build["modules"]:
            if not module["aarch64_elf"]:
                issues.append("NOT_AARCH64_ELF_MODULE:" + module["path"])
        if not any(x["path"].endswith("rmnet_shs.ko") for x in build["modules"]):
            issues.append("RMNET_SHS_NOT_IN_OUTPUT")
        if not any(x["path"].endswith("rmnet_offload.ko") for x in build["modules"]):
            issues.append("RMNET_OFFLOAD_NOT_IN_OUTPUT")
    status = "STATIC_PARTIAL_PASS_NOFLASH" if not issues else "STATIC_BLOCKED_NOFLASH"
    res = {
        "schema": "VEUX_R45_ROOTLESS_EVIDENCE_V1",
        "status": status,
        "flash_allowed": False,
        "stock_source_identity_proven": False,
        "vendor_abi_proven": False,
        "device_boot_tested": False,
        "stock_config_sha256": stock_sha,
        "r44_config_sha256": r44_sha,
        "config_total_stock": len(st), "config_total_r44": len(r44),
        "config_comparison": counts,
        "tracked_source_files": len(inv),
        "source_provenance_scope": "one R44 assembled source snapshot only" if args.source else "NO_SOURCE_TREE_AVAILABLE",
        "build_product_gate": build,
        "blocking_errors": issues,
    }
    write_csv(args.out / "CONFIG_GAPS.csv", rows,
              ["symbol", "kind", "stock", "r44", "priority", "defined_in_source", "kconfig_locations", "interpretation"])
    if args.source:
        write_csv(args.out / "SOURCE_PINNED_SHA256.csv", inv, ["path", "sha256", "size_bytes"])
    (args.out / "R45_GATE_RESULT.json").write_text(json.dumps(res, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (args.out / "RELEASE_STATUS.txt").write_text(
        "ROOTLESS_R44_STATIC=" + status + "\nOEM_ABI=UNPROVEN\nDEVICE_BOOT=UNTESTED\nFLASH=NO\n", encoding="utf-8")
    manifest = []
    for entry in sorted(args.out.iterdir()):
        if entry.is_file() and entry.name != "SHA256SUMS.txt":
            manifest.append(f"{sha(entry)}  {entry.name}")
    (args.out / "SHA256SUMS.txt").write_text("\n".join(manifest) + "\n", encoding="utf-8")
    return 0 if not issues else 3


if __name__ == "__main__":
    raise SystemExit(main())
