# VEUX R46-R1 – gezielte Rootless-Reparatur, NOFLASH

**Stand:** 07.11.2026. Technische Grundlage: GitHub Run 42365165482,
Job 128381585380 (echter ARM64 Image/vmlinux/DTB/6 Module Build),
und originaler R44 Run 40168917960.

**Wirklich repariert im nächsten isolierten Build, noch nicht live kompiliert:**
1. `drivers/cpufreq/qcom-cpufreq-hw.c`: unbenutzte Variable in .remove() entfernen.
2. `drivers/power/supply/qcom/qpnp-smb5.c`: korrekt breiten Zwischencast fuer `const void*`-Matchdaten einsetzen.
3. `drivers/power/supply/qcom/smb1398-charger.c`: entsprechenden Pointer-Cast fuer Ladereglerrolle korrigieren.
4. `net/core/dev.c`: falsch `static` deklariertes, aber per `EXPORT_SYMBOL` exportiertes `embms_tm_multicast_recv` global machen.
5. `techpack/camera/drivers/cam_ope/ope_hw_mgr/ope_hw/ope_dev.c`: falsch `static` deklariertes, aber exportiertes `ope_soc_info` global machen.

Jede Quelle muss bytegenau mit ihrem Git-Blob aus Positron-Commit
`b2b7a3bbc36d120ee523ebc8d68e0f13a97df632` uebereinstimmen, sonst ABORT **vor** dem Kompilieren.
Die Quelle wird ausschließlich im isolierten `$R9_SNAPSHOT` geaendert, nicht im GitHub main, nicht im P13, nicht in historischen ZIPs.

**Determinismus-Vorbereitung:** `SOURCE_DATE_EPOCH=1794009600` und feste,
offene `KBUILD_BUILD_*`-CI-Metadaten (kein Stock-Versionsspoofing).
Ob damit zwei unabhaengige Image-Builds bytegleich sind, muss erst in zwei
neuen echten Runner-Laeufen geprueft werden.

**Wichtige Grenzen:** 72 Stock-Konfigurationsabweichungen inkl. 15 P0 bleiben
separate Quell-/ABI-Aufgaben. Weder Hersteller-ABI noch Geraete-Boot ist
nachgewiesen. Kein BakaSU, SUSFS oder NoMount. Kein AK3/boot.img. Kein Flash.

**Belege:** `References/R45_FIVE_ORIGINAL_WARNINGS.txt` enthaelt genau die
fuenf Warnzeilen aus originalem `make_logs/R20_Image_make.log` von Run
42365165482, Log-SHA256 `83c30adf48152670fc6c526a9079855bb46ab112044263b04feefb8a0a06295c`.

**Installation:** `VEUX_R46_R1_MAIN.zip` im GitHub `main` Root, YAML separat
unter `.github/workflows/` hochladen, Workflow `VEUX R46-R1 Rootless WALT Source Repairs + Stock Gate - NO FLASH` manuell starten.
Der komplette Build darf erst nach bestandenen SHA256/Bash/Actionlint/ShellCheck/
Python-Regressionen beginnen. Alte R45/R44-Workflows bleiben unangetastet.
