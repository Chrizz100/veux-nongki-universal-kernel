import hashlib
import json
import os
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

THIS = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(THIS / 'Tools'))
import veux_r46_repair as m


class SourcePatches(unittest.TestCase):
    def test_five_unique_paths_exact_pins(self):
        self.assertEqual(len(m.FIXES), 5)
        self.assertEqual(len({x['path'] for x in m.FIXES}), 5)
        for row in m.FIXES:
            self.assertRegex(row['git_blob'], r'^[0-9a-f]{40}$')
            self.assertTrue(row['old'])
            self.assertNotEqual(row['old'], row['new'])

    def test_exact_git_blob_hash(self):
        self.assertEqual(m.git_blob_sha1(b'test content\n'),
                         hashlib.sha1(b'blob 13\0test content\n').hexdigest())

    def test_five_replacements_do_not_hide_warnings(self):
        for row in m.FIXES:
            data = ('header\n' + row['old'] + '\nfooter\n').encode()
            result = m.prepare_fix(data, row, allow_test_pin=True)
            self.assertIn(row['new'].encode(), result)
            self.assertNotIn(row['old'].encode(), result)
            self.assertEqual(len(result), len(data) + len(row['new']) - len(row['old']))

    def test_reject_file_modified_from_pinned_blob(self):
        row = m.FIXES[0]
        with self.assertRaisesRegex(ValueError, 'SOURCE_BLOB_PIN_MISMATCH'):
            m.prepare_fix(row['old'].encode(), row)

    def test_reject_ambiguous_double_match(self):
        row = m.FIXES[1]
        data = (row['old'] + '\n' + row['old']).encode()
        with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_NOT_UNIQUE'):
            m.prepare_fix(data, row, allow_test_pin=True)

    def test_reject_previously_patched(self):
        row = m.FIXES[2]
        with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_NOT_UNIQUE'):
            m.prepare_fix(row['new'].encode(), row, allow_test_pin=True)

    def test_no_static_export_removal(self):
        for row in m.FIXES[-2:]:
            self.assertEqual(row['old'].count('EXPORT_SYMBOL('), 1)
            self.assertEqual(row['new'].count('EXPORT_SYMBOL('), 1)
            self.assertTrue(row['old'].startswith('static '))
            self.assertFalse(row['new'].startswith('static '))

    def test_two_pointer_casts_go_via_full_width_integer(self):
        for row in m.FIXES[1:3]:
            self.assertIn('(unsigned long)', row['new'])
            self.assertIn('of_device_get_match_data', row['new'])

    def test_reject_path_escape_and_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            p = pathlib.Path(d)
            (p/'good.c').write_text('foo')
            self.assertEqual(m.within(p, 'good.c'), p/'good.c')
            with self.assertRaises((ValueError, FileNotFoundError)):
                m.within(p, '../missing.c')
            (p/'link.c').symlink_to(p/'good.c')
            with self.assertRaisesRegex(ValueError, 'SOURCE_NOT_REGULAR'):
                m.within(p, 'link.c')

    def test_fixed_build_metadata_gate(self):
        values = {
            'SOURCE_DATE_EPOCH': '1794009600',
            'KBUILD_BUILD_TIMESTAMP': m.BUILD_STAMP,
            'KBUILD_BUILD_HOST': m.BUILD_HOST,
            'KBUILD_BUILD_USER': m.BUILD_USER,
            'KBUILD_BUILD_VERSION': '1',
        }
        self.assertEqual(m.validate_build_env(values), values)
        values['SOURCE_DATE_EPOCH'] = '0'
        with self.assertRaisesRegex(ValueError, 'NONDETERMINISTIC'):
            m.validate_build_env(values)

    def test_unified_diff_has_exact_file_count(self):
        records = [dict(path=x['path'], original=x['old'].encode()+b'\n',
                        patched=x['new'].encode()+b'\n') for x in m.FIXES]
        patch = m.make_patch(records)
        self.assertEqual(patch.count('--- a/'), 5)
        self.assertEqual(patch.count('+++ b/'), 5)
        self.assertNotIn('+++ b/arch/arm64/configs', patch)

    def build_fixtures(self, root):
        entries = []
        for j, row in enumerate(m.FIXES):
            p = root/row['path']
            p.parent.mkdir(parents=True, exist_ok=True)
            raw = ('fixture header ' + str(j) + '\n' + row['old'] + '\nfixture tail\n').encode()
            p.write_bytes(raw)
            entries.append({**row, 'git_blob': m.git_blob_sha1(raw)})
        return tuple(entries)

    def test_atomic_precheck_blocks_all_patches_if_one_wrong(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)/'src';out=pathlib.Path(d)/'out'
            root.mkdir()
            items=list(self.build_fixtures(root))
            original=(root/items[0]['path']).read_bytes()
            items[-1]['git_blob'] = '0' * 40
            with mock.patch.object(m, 'FIXES',tuple(items)), mock.patch.dict(os.environ,self.valid_env(),clear=True):
                with self.assertRaises(SystemExit):m.apply(root,out)
            self.assertEqual((root/items[0]['path']).read_bytes(),original)
            report=json.loads((out/'R46_SOURCE_FIX_RESULT.json').read_text())
            self.assertEqual(report['status'],'BLOCKED_NOFLASH')
            self.assertEqual(report['changes'],[])

    @staticmethod
    def valid_env():
        return {'SOURCE_DATE_EPOCH':str(m.BUILD_EPOCH),
                'KBUILD_BUILD_TIMESTAMP':m.BUILD_STAMP,
                'KBUILD_BUILD_HOST':m.BUILD_HOST,
                'KBUILD_BUILD_USER':m.BUILD_USER,
                'KBUILD_BUILD_VERSION':'1'}

    def test_full_five_fixture_repair_and_no_repeat(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)/'src';out=pathlib.Path(d)/'out'
            root.mkdir()
            fixes=self.build_fixtures(root)
            with mock.patch.object(m, 'FIXES',fixes), mock.patch.dict(os.environ,self.valid_env(),clear=True):
                proof=m.apply(root,out)
                self.assertEqual(len(proof['changes']),5)
                self.assertTrue((out/'R46_EXACT_FIVE_SOURCE_FIXES.patch').exists())
                with self.assertRaises(SystemExit):m.apply(root,out)
            self.assertEqual(json.loads((out/'R46_SOURCE_FIX_RESULT.json').read_text())['status'], 'BLOCKED_NOFLASH')

    def test_warning_patterns_match_original_log(self):
        log=(THIS/'References/R45_FIVE_ORIGINAL_WARNINGS.txt').read_text()
        for pat in m.WARNING_MARKERS:
            self.assertRegex(log, pat)

    def test_postbuild_verification_passes_only_with_zero_warnings(self):
        with tempfile.TemporaryDirectory() as d:
            base=pathlib.Path(d);root=base/'src';out=base/'out'
            root.mkdir();out.mkdir()
            changes=[]
            for row in m.FIXES:
                path=root/row['path'];path.parent.mkdir(parents=True,exist_ok=True)
                data=(row['new']+'\n').encode()
                path.write_bytes(data)
                changes.append({'path':row['path'],'new_sha256':m.sha256(data)})
            (out/'R46_SOURCE_FIX_RESULT.json').write_text(json.dumps({
                'status':'R46_FIVE_SOURCE_EDITS_APPLIED_UNVERIFIED_BUILD_NOFLASH',
                'changes':changes}))
            r45=base/'r45.json';r20=base/'r20.json';log=base/'image.log'
            r45.write_text(json.dumps({'status':'STATIC_PARTIAL_PASS_NOFLASH',
                'flash_allowed':False,'vendor_abi_proven':False,
                'stock_source_identity_proven':False,'device_boot_tested':False,
                'config_comparison':{'VALUE_DIFFERENT':3}}))
            r20.write_text(json.dumps({'full_image_proven':True,'flash_allowed':False,
                'vendor_abi_proven':False,'runtime_tested':False,
                'image':{'sha256':'a'*64},'module_symvers_sha256':'b'*64}))
            log.write_text('  CC drivers/example.o\n  LD vmlinux\n')
            v=m.verify_build(root,out,log,r45,r20)
            self.assertEqual(v['status'],'R46_FIVE_WARNINGS_FIXED_BUILD_PASS_NOFLASH')
            self.assertEqual(v['remaining_compiler_warning_lines'],[])
            log.write_text('some.c:55:8: warning: new unexpected problem\n')
            with self.assertRaises(SystemExit):m.verify_build(root,out,log,r45,r20)
            j=json.loads((out/'R46_POSTBUILD_RESULT.json').read_text())
            self.assertIn('R46_FULL_IMAGE_COMPILE_WARNINGS_REMAIN:1',j['blocking_errors'])

    def test_no_flash_codes_or_root_hooks(self):
        code=(THIS/'Tools/veux_r46_repair.py').read_text()
        for token in ('fastboot flash','adb reboot','ksu_init','susfs_init','nomount_init'):
            self.assertNotIn(token,code)


if __name__=='__main__':
    unittest.main()
