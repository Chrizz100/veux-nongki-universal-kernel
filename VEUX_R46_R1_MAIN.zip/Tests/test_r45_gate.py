import importlib.util
import json
import os
import pathlib
import struct
import subprocess
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r45', ROOT/'Tools'/'veux_r45_rootless_gate.py')
r45 = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r45)

class RootlessR45Test(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = pathlib.Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()
    def test_stock_config_count_and_pin(self):
        stock=ROOT/'References'/'STOCK_5.4.274_QGKI.config'
        self.assertEqual(r45.sha(stock),r45.PINNED_STOCK_CONFIG_SHA)
        self.assertEqual(len(r45.load_config(stock)),5315)
    def test_r44_config_count_and_pin(self):
        r44=ROOT/'References'/'R44_EFFECTIVE.config'
        self.assertEqual(r45.sha(r44),r45.PINNED_R44_CONFIG_SHA)
        self.assertEqual(len(r45.load_config(r44)),5292)
    def test_actual_72_gaps(self):
        s=r45.load_config(ROOT/'References'/'STOCK_5.4.274_QGKI.config')
        r=r45.load_config(ROOT/'References'/'R44_EFFECTIVE.config')
        rows,c=r45.compare(s,r)
        self.assertEqual(c, {'SAME':5266,'R44_ONLY':23,'STOCK_ONLY':46,'VALUE_DIFFERENT':3})
        self.assertEqual(len(rows),72)
    def test_all_rootless_required(self):
        r=r45.load_config(ROOT/'References'/'R44_EFFECTIVE.config')
        self.assertEqual(r45.rootless_gate(r),[])
    def test_fail_if_root_feature_enabled(self):
        r=r45.load_config(ROOT/'References'/'R44_EFFECTIVE.config')
        r['CONFIG_KSU']='y'
        self.assertTrue(any('CONFIG_KSU' in z for z in r45.rootless_gate(r)))
    def test_fail_if_walt_disabled(self):
        r=r45.load_config(ROOT/'References'/'R44_EFFECTIVE.config')
        r['CONFIG_SCHED_WALT']='n'
        self.assertTrue(any('CONFIG_SCHED_WALT' in z for z in r45.rootless_gate(r)))
    def test_no_duplicate_config(self):
        f=self.base/'config'
        f.write_text('CONFIG_X=y\n# CONFIG_X is not set\n')
        with self.assertRaisesRegex(ValueError,'CONFIG_DUPLICATE'):
            r45.load_config(f)
    def test_lowercase_config_symbols(self):
        f=self.base/'config'
        f.write_text('# CONFIG_LEDS_LM355x is not set\n')
        self.assertEqual(r45.load_config(f)['CONFIG_LEDS_LM355x'],'n')
    def test_kconfig_source_mapping(self):
        (self.base/'Kconfig').write_text('config MI_UFS_FFU\n bool "test"\nmenuconfig UFS_WB\n')
        self.assertEqual(len(r45.kconfig_declarations(self.base)),2)
    def test_source_skip_symlink(self):
        p=self.base/'drivers/scsi/ufs'
        p.mkdir(parents=True)
        q=p/'driver.c';q.write_text('original')
        (p/'other.c').symlink_to(q)
        inv=r45.source_inventory(self.base)
        self.assertEqual([x['path'] for x in inv],['drivers/scsi/ufs/driver.c'])
    def test_magic_positive(self):
        out=self.base
        for p in ['arch/arm64/boot/Image','arch/arm64/boot/dts/vendor/xiaomi/veux.dtb']:
            (out/p).parent.mkdir(parents=True,exist_ok=True)
        image=bytearray(0x40);image[0x38:0x3c]=b'ARM\x64'
        (out/'arch/arm64/boot/Image').write_bytes(image)
        elf=bytearray(32);elf[:6]=b'\x7fELF\x02\x01';struct.pack_into('<H',elf,18,183)
        (out/'vmlinux').write_bytes(elf)
        (out/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb').write_bytes(b'\xd0\x0d\xfe\xed')
        (out/'Module.symvers').write_text('stub')
        q=r45.magic_status(out)
        self.assertTrue(q['Image']['arm64_magic'])
        self.assertTrue(q['vmlinux']['aarch64_elf'])
        self.assertTrue(q['veux.dtb']['fdt_magic'])
    def test_magic_negative(self):
        (self.base/'arch/arm64/boot').mkdir(parents=True)
        (self.base/'arch/arm64/boot/Image').write_bytes(b'A'*80)
        self.assertFalse(r45.magic_status(self.base)['Image']['arm64_magic'])
    def test_cli_no_source_real_config(self):
        r=subprocess.run([sys.executable,str(ROOT/'Tools'/'veux_r45_rootless_gate.py'),
            '--stock-config',str(ROOT/'References'/'STOCK_5.4.274_QGKI.config'),
            '--r44-config',str(ROOT/'References'/'R44_EFFECTIVE.config'),
            '--out',str(self.base/'report'),'--pin-known-config'],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        m=json.loads((self.base/'report'/'R45_GATE_RESULT.json').read_text())
        self.assertEqual(m['status'],'STATIC_PARTIAL_PASS_NOFLASH')
        self.assertFalse(m['flash_allowed'])
    def test_cli_refuses_hash_change(self):
        rconf=self.base/'changed.config'
        rconf.write_bytes((ROOT/'References'/'R44_EFFECTIVE.config').read_bytes()+b'\n# something harmless\n')
        r=subprocess.run([sys.executable,str(ROOT/'Tools'/'veux_r45_rootless_gate.py'),
            '--stock-config',str(ROOT/'References'/'STOCK_5.4.274_QGKI.config'),
            '--r44-config',str(rconf),'--out',str(self.base/'report'),'--pin-known-config'],capture_output=True,text=True)
        self.assertEqual(r.returncode,3)
        m=json.loads((self.base/'report'/'R45_GATE_RESULT.json').read_text())
        self.assertIn('PINNED_REFERENCE_CONFIG_HASH_DIFFERENT',m['blocking_errors'])

if __name__=='__main__': unittest.main()
