import pathlib, sys, subprocess, tempfile, json, unittest, shutil
ROOT=pathlib.Path(__file__).resolve().parents[1]
TOOL=ROOT/'Tools'/'veux_r45_rootless_gate.py'
STOCK=ROOT/'References'/'STOCK_5.4.274_QGKI.config'
R44=ROOT/'References'/'R44_EFFECTIVE.config'
class R45R2Regression(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.base=pathlib.Path(self.t.name)
    def tearDown(self): self.t.cleanup()
    def run_gate(self, *args,config=R44):
        p=subprocess.run([sys.executable,str(TOOL),'--stock-config',str(STOCK),
            '--r44-config',str(config),'--out',str(self.base/'out'),*args],capture_output=True,text=True)
        j=json.loads((self.base/'out'/'R45_GATE_RESULT.json').read_text())
        return p.returncode,j
    def test_pin_stock_only_allows_reproducible_config_drift(self):
        c=self.base/'new.config'
        c.write_bytes(R44.read_bytes()+b'\n# build timestamp comment\n')
        code,r=self.run_gate('--pin-stock-only',config=c)
        self.assertEqual(code,0,r['blocking_errors'])
        self.assertEqual(r['status'],'STATIC_PARTIAL_PASS_NOFLASH')
        self.assertNotEqual(r['r44_config_sha256'],'7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe')
    def test_bad_source_tree_causes_block(self):
        code,r=self.run_gate('--source',str(self.base/'not_found'),'--pin-stock-only')
        self.assertEqual(code,3)
        self.assertIn('INVALID_OR_MISSING_ASSEMBLED_WALT_SOURCE_TREE',r['blocking_errors'])
    def test_incomplete_source_tree_causes_block(self):
        s=self.base/'src';s.mkdir();(s/'Makefile').write_text('VERSION=5\n')
        code,r=self.run_gate('--source',str(s))
        self.assertEqual(code,3)
        self.assertIn('INVALID_OR_MISSING_ASSEMBLED_WALT_SOURCE_TREE',r['blocking_errors'])
    def test_fake_symvers_and_missing_binary_block(self):
        out=self.base/'fake';out.mkdir();(out/'Module.symvers').write_text('nonsense')
        code,r=self.run_gate('--objout',str(out),'--pin-stock-only')
        self.assertEqual(code,3)
        self.assertIn('INVALID_OR_INCOMPLETE_MODULE_SYMVERS',r['blocking_errors'])
        self.assertIn('MISSING_PRODUCT:Image',r['blocking_errors'])
    def test_manifest_covers_status(self):
        code,r=self.run_gate('--pin-stock-only')
        self.assertEqual(code,0)
        checks=(self.base/'out'/'SHA256SUMS.txt').read_text()
        self.assertIn('RELEASE_STATUS.txt',checks)
        self.assertIn('R45_GATE_RESULT.json',checks)
        ck=subprocess.run(['sha256sum','-c','SHA256SUMS.txt'],cwd=self.base/'out',capture_output=True,text=True)
        self.assertEqual(ck.returncode,0,ck.stdout+ck.stderr)
    def test_main_source_file_byteidentical(self):
        self.assertEqual(TOOL.read_bytes(),(ROOT/'Tools/VEUX_R45_ROOTLESS/veux_r45_rootless_gate.py').read_bytes())
        self.assertEqual(STOCK.read_bytes(),(ROOT/'Tools/VEUX_R45_ROOTLESS/STOCK_5.4.274_QGKI.config').read_bytes())
if __name__=='__main__':unittest.main()
