"""Offline positive and tampering regressions for R30-R2; no network/device access."""
from pathlib import Path
import importlib.util
import json
import shutil
import re
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('r30_r2_crc_audit', ROOT/'r30_r2_crc_audit.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class VerifiedReadOnlyAudit(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.inputs = self.root/'inputs'
        shutil.copytree(ROOT/'inputs', self.inputs)
        self.out = self.root/'out'

    def tearDown(self):
        self.tmp.cleanup()

    def assert_fail_closed(self, expected_substring):
        with self.assertRaisesRegex(ValueError, expected_substring):
            mod.run(self.inputs, self.out)

    def test_01_positive_all_14648_imports(self):
        summary = mod.run(self.inputs, self.out)
        self.assertFalse(summary['flash_allowed'])
        self.assertFalse(summary['built_new_kernel'])
        self.assertEqual(summary['nine_device_modules_not_compatible_A'],9)

    def test_02_reject_fake_vendor_expected_crc(self):
        p=self.inputs/'OEM_PARTIAL_ABI.csv'
        txt=p.read_text()
        txt=txt.replace('0x90c76c28','0x00000001',1)
        p.write_text(txt)
        self.assert_fail_closed('R28_R30_OEM_CRC_DISAGREEMENT')

    def test_03_reject_altered_A_symvers(self):
        p=self.inputs/'A_STOCK_IPC_Module.symvers'
        txt=p.read_text()
        p.write_text(re.sub(r'0x[0-9a-fA-F]{8}', lambda m: m.group()[:-1] + ('0' if m.group()[-1] != '0' else '1'), txt, count=1))
        self.assert_fail_closed('R30_VARIANT_SYMVERS_HASH_MISMATCH')

    def test_04_reject_deleted_CASS_config(self):
        p=self.inputs/'A_STOCK_IPC_ACTUAL.config'
        text=p.read_text()
        self.assertIn('CONFIG_SCHED_CASS=y',text)
        p.write_text(text.replace('CONFIG_SCHED_CASS=y','# CONFIG_SCHED_CASS is not set',1))
        self.assert_fail_closed('R30_VARIANT_CONFIG_HASH_MISMATCH')

    def test_05_reject_flashable_provenance(self):
        p=self.inputs/'PROVENANCE.json'
        obj=json.loads(p.read_text())
        obj['flash_allowed']=True
        p.write_text(json.dumps(obj))
        self.assert_fail_closed('DANGEROUS_PROVENANCE')

    def test_06_reject_missing_oem_imports(self):
        p=self.inputs/'R28_OEM_R21_IMPORTS.csv'
        p.write_text('\n'.join(p.read_text().splitlines()[:-1])+'\n')
        self.assert_fail_closed('R28_OEM_IMPORT_FILE_COUNT_CHANGED')

    def test_07_reject_input_set_drift(self):
        (self.inputs/'unexpected.new').write_text('tamper')
        self.assert_fail_closed('INPUT_FILE_SET_DIFFERENT')

    def test_08_reject_false_success_build(self):
        p=self.inputs/'A_STOCK_IPC_RESULT.json'
        obj=json.loads(p.read_text())
        obj['status']='FLASH_READY'
        p.write_text(json.dumps(obj))
        self.assert_fail_closed('R30_VARIANT_NOT_ACTUALLY_BUILT')

if __name__=='__main__':
    unittest.main()
