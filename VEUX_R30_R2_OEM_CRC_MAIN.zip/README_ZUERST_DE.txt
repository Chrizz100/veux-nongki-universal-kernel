VEUX R30-R2 – OEM-QGKI CRC-Ursachenanalyse (READ-ONLY / NO FLASH)

Zweck
- Gewichtet jeden OEM-Import aus dem R28-Teilprofil gegen die echten R13-, R30-A- und R30-B-Module.symvers.
- Bewertet alle 218 OEM-Modulpfade sowie die neun priorisierten RMNET/IPA-Pfade.
- Misst die 836 QGKI/GKI-Zielkonflikte, Konfigunterschiede und module_layout-Abweichungen.
- Erstellt vollständige, unabhängige CSV-/JSON-Berichte. KEIN Kernelbau.

Quellen und Vertrauensgrenze
- GitHub-Run 41207776770, Job 124556288437 (erfolgreich), Commit 7fe4870fcaf84a3259a8acbdce69dc5bfe088425.
- Dessen Original-Artefakt SHA-256 d028c6454ba8993ea62d692052c23bcb0a295db4c5aa16a4c8bd2d150bd9f076.
- Zugehörige R30-MAIN-ZIP SHA-256 64a8a7dc17e6681d617474e494ef4017a312c46dadb85462826a06c4e9f196c4.
- R28 OEM_R21_IMPORTS-Importprofil, CRC-Evidenz und die neun priorisierten Pfade.
- Die Original-OEM-Module.symvers ist NICHT vorhanden. Diese importierte OEM-CRC-Liste ist ein Teilprofil und kein komplettes Ersatzabbild.

Repo-Anwendung
- VEUX_R30_R2_OEM_CRC_MAIN.zip unverändert nach Repository-Root hochladen.
- VEUX_R30_R2_OEM_CRC_NOFLASH.yml nach .github/workflows/ hochladen.
- In Actions "VEUX R30-R2 OEM CRC Detail Audit - NO FLASH" manuell starten.
- Unter Artifacts den detaillierten R30-R2-Bericht herunterladen.
- Keine Secrets, kein Installer, kein Flash, keine Root-Moduländerungen, keine Kernel-/Vendor-/ROM-Manipulationen.

Lokal (wenn die ZIP entpackt vorliegt)
    python3 -B r30_r2_crc_audit.py --selftest
    python3 -B r30_r2_crc_audit.py --input inputs --out reports

Ergebnis
- Erfolg heißt ausschließlich, dass das Teilprofil nachvollziehbar und unverändert ausgewertet wurde.
- Alle neun relevanten Module sind in R30-A NICHT vollständig import-ABI-kompatibel.
- Für R30-A, R30-B und R13 gilt: KEINE Flashfreigabe; Gerätefunktion ist hier NICHT getestet.
- Nächste Source-Aufgabe: echte Typ- und Prototypunterschiede (insbes. module_layout,
  kmalloc_caches, kmem_cache_alloc_trace, RMNET) gezielt an Stock-Referenzen verfolgen.
- Module.symvers/CRC niemals blind überschreiben oder manipulieren.
