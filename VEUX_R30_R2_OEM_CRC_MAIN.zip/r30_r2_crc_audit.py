#!/usr/bin/env python3
"""VEUX R30-R2: reproducible, read-only OEM imported CRC ABI audit.

Inputs are immutable snapshots extracted from the verified R28/R30 archives.
Never edits a kernel, vendor image, source tree or Module.symvers and never
promotes a research image as flashable.
"""
import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import io
import json
from pathlib import Path
import re

STAGES = ('R13', 'A', 'B')
COHORTS = ('QGKI', 'GKI')
STATUSES = ('MATCH', 'CRC_MISMATCH', 'NOT_EXPORTED')
INPUTS = {
    'OEM_PARTIAL_ABI.csv',
    'R28_OEM_R21_IMPORTS.csv',
    'R28_NEUN_DEVICE_MODULE_BLOCKERS.csv',
    'R28_ERGEBNIS.json',
    'R13_Module.symvers',
    'A_STOCK_IPC_Module.symvers',
    'B_STOCK_IPC_TRACE_Module.symvers',
    'R13_ACTUAL.config',
    'STOCK_5_4_274.config',
    'A_STOCK_IPC_ACTUAL.config',
    'B_STOCK_IPC_TRACE_ACTUAL.config',
    'R30_ABI_COMPARISON.json',
    'R30_AB_EXPERIMENT_SUMMARY.json',
    'A_STOCK_IPC_RESULT.json',
    'B_STOCK_IPC_TRACE_RESULT.json',
    'PROVENANCE.json',
}
EXPECTED_COUNTS = {
    'QGKI': {'R13': {'MATCH': 1303, 'CRC_MISMATCH': 1752, 'NOT_EXPORTED': 93},
             'A': {'MATCH': 1326, 'CRC_MISMATCH': 1792, 'NOT_EXPORTED': 30},
             'B': {'MATCH': 1326, 'CRC_MISMATCH': 1805, 'NOT_EXPORTED': 17}},
    'GKI': {'R13': {'MATCH': 4983, 'CRC_MISMATCH': 6075, 'NOT_EXPORTED': 442},
            'A': {'MATCH': 5061, 'CRC_MISMATCH': 6308, 'NOT_EXPORTED': 131},
            'B': {'MATCH': 5061, 'CRC_MISMATCH': 6373, 'NOT_EXPORTED': 66}},
}
EXPECTED_ROWS = {'QGKI': 3148, 'GKI': 11500}
EXPECTED_SYMBOLS = {'QGKI': 1423, 'GKI': 3078}
REQUIRED_NINE = {
    ('GKI', '/vendor/lib/modules/5.4-gki/ipa_fmwk.ko'),
    ('GKI', '/vendor/lib/modules/5.4-gki/rmnet_core.ko'),
    ('GKI', '/vendor/lib/modules/5.4-gki/rmnet_ctl.ko'),
    ('GKI', '/vendor/lib/modules/5.4-gki/rmnet_offload.ko'),
    ('GKI', '/vendor/lib/modules/5.4-gki/rmnet_shs.ko'),
    ('QGKI', '/vendor/lib/modules/rmnet_core.ko'),
    ('QGKI', '/vendor/lib/modules/rmnet_ctl.ko'),
    ('QGKI', '/vendor/lib/modules/rmnet_offload.ko'),
    ('QGKI', '/vendor/lib/modules/rmnet_shs.ko'),
}


def check(value, reason):
    if not value:
        raise ValueError('R30_R2_FAIL_CLOSED: ' + str(reason))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_csv(path):
    with path.open('r', encoding='utf-8', newline='') as f:
        return list(csv.DictReader(f))


def write_csv(path, rows, fields):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def normalize_crc(crc):
    check(bool(re.fullmatch(r'0x[0-9a-fA-F]{1,8}', crc)), 'MALFORMED_CRC')
    return f'0x{int(crc, 16):08x}'


def parse_symvers(path):
    out = {}
    content = path.read_text(encoding='utf-8')
    for line in content.splitlines():
        parts = line.split()
        check(len(parts) >= 4, 'BAD_SYMVERS_ROW:' + line[:80])
        crc, symbol = parts[:2]
        crc = normalize_crc(crc)
        check(symbol not in out or out[symbol] == crc, 'SYMVERS_DUPLICATE_CONFLICT:' + symbol)
        out[symbol] = crc
    check(len(out) > 1000, 'SYMVERS_TOO_SMALL:' + path.name)
    return out


def get_status(expected, actual):
    return 'NOT_EXPORTED' if actual is None else ('MATCH' if expected == actual else 'CRC_MISMATCH')


def parse_configs(path):
    values = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if re.fullmatch(r'CONFIG_[A-Za-z0-9_]+=.*', line):
            key, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            key = line[2:-11]
            value = 'n'
        else:
            continue
        check(key not in values, 'DUPLICATE_CONFIG_KEY:' + key)
        values[key] = value
    check(len(values) > 3000, 'CONFIG_TOO_SMALL:' + path.name)
    return values


def run(inp, out):
    check(inp.is_dir(), 'INPUT_DIRECTORY_NOT_FOUND')
    check({p.name for p in inp.iterdir() if p.is_file()} == INPUTS, 'INPUT_FILE_SET_DIFFERENT')
    src = read_json(inp / 'PROVENANCE.json')
    check(src['flash_allowed'] is False and src['device_test'] is False and src['no_kernel_build'] is True,
          'DANGEROUS_PROVENANCE')
    check(src['git_commit_source'] == '7fe4870fcaf84a3259a8acbdce69dc5bfe088425' and
          src['r30_github_run'] == 41207776770, 'WRONG_GITHUB_BUILD_REFERENCE')
    r28 = read_json(inp/'R28_ERGEBNIS.json')
    check(r28['source_status'].startswith('OFFICIAL_XIAOMI_5_4_134_ONLY'), 'MISREPRESENTED_STOCK_SOURCE')
    check(r28['stock_complete_Module_symvers_available'] is False, 'BAD_OEM_REPRESENTATION')
    check(r28['overlap_common_symbols'] == 1393 and r28['crc_different_common_symbols'] == 836,
          'R28_COHORT_REFERENCE_MISMATCH')
    sym = {
        'R13': parse_symvers(inp/'R13_Module.symvers'),
        'A': parse_symvers(inp/'A_STOCK_IPC_Module.symvers'),
        'B': parse_symvers(inp/'B_STOCK_IPC_TRACE_Module.symvers'),
    }
    exp = read_json(inp/'R30_ABI_COMPARISON.json')
    experiments = read_json(inp/'R30_AB_EXPERIMENT_SUMMARY.json')
    check(experiments['status'] == 'TWO_REAL_VARIANTS_BUILT_NO_FLASH' and experiments['device_test'] is False and experiments['flash_allowed'] is False,
          'R30_ARTIFACT_NOT_RESEARCH_PASS')
    check(experiments['baseline_symvers_sha256'] == sha((inp/'R13_Module.symvers').read_bytes()),
          'R13_BASELINE_HASH_MISMATCH')
    for stage, key in [('A','A_STOCK_IPC'),('B','B_STOCK_IPC_TRACE')]:
        result = read_json(inp/(key+'_RESULT.json'))
        check(result['status'] == 'ACTUALLY_COMPILED_NO_FLASH' and result['flash_allowed'] is False and result['device_test'] is False,
              'R30_VARIANT_NOT_ACTUALLY_BUILT:' + stage)
        check(result['module_symvers_sha256'] == sha((inp/(key+'_Module.symvers')).read_bytes()),
              'R30_VARIANT_SYMVERS_HASH_MISMATCH:' + stage)
        check(result['config_sha256'] == sha((inp/(key+'_ACTUAL.config')).read_bytes()),
              'R30_VARIANT_CONFIG_HASH_MISMATCH:' + stage)
        check(result['module_layout_crc'] == sym[stage]['module_layout'],
              'MODULE_LAYOUT_SELF_INCONSISTENT:' + stage)
    check(experiments['baseline_config_sha256'] == sha((inp/'R13_ACTUAL.config').read_bytes()),
          'R13_CONFIG_HASH_MISMATCH')
    partial = read_csv(inp/'OEM_PARTIAL_ABI.csv')
    check(len(partial) == sum(EXPECTED_SYMBOLS.values()), 'OEM_PARTIAL_SYMBOL_COUNT_DRIFT')
    expected = {}
    weights = {}
    for p in partial:
        check(set(p) == {'cohort','symbol','oem_import_expected_crc','importing_files'}, 'BAD_PARTIAL_HEADER')
        key = (p['cohort'], p['symbol'])
        check(p['cohort'] in COHORTS and key not in expected, 'DUPLICATE_OEM_SYMBOL')
        expected[key] = normalize_crc(p['oem_import_expected_crc'])
        weights[key] = int(p['importing_files'])
        check(weights[key] > 0, 'NONPOSITIVE_WEIGHT')
    raw = read_csv(inp/'R28_OEM_R21_IMPORTS.csv')
    check(len(raw) == 14648, 'R28_OEM_IMPORT_FILE_COUNT_CHANGED')
    bymodule = defaultdict(list)
    rawweights = Counter()
    seen = set()
    for p in raw:
        check(set(p) == {'path','symbol','module_crc','r20_crc','r20_provider','status'}, 'BAD_R28_OEM_HEADER')
        cohort = 'GKI' if p['path'].startswith('/vendor/lib/modules/5.4-gki/') else 'QGKI'
        check(p['path'].startswith('/vendor/lib/modules/') and p['path'].endswith('.ko'), 'MALFORMED_VENDOR_PATH')
        key = (cohort, p['symbol'])
        check((p['path'],p['symbol']) not in seen, 'REPEATED_MODULE_IMPORT')
        seen.add((p['path'],p['symbol']))
        check(key in expected and normalize_crc(p['module_crc']) == expected[key],
              'R28_R30_OEM_CRC_DISAGREEMENT:' + str(key))
        rawweights[key] += 1
        bymodule[(cohort, p['path'])].append(p)
    check(rawweights == weights, 'R28_R30_IMPORT_WEIGHTS_DIFFER')
    check({c:sum(v for (co,k),v in rawweights.items() if co==c) for c in COHORTS} == EXPECTED_ROWS,
          'IMPORT_COHORT_COUNT_MISMATCH')
    check({c:sum(1 for co,_ in expected if co==c) for c in COHORTS} == EXPECTED_SYMBOLS,
          'IMPORT_COHORT_SYMBOLS_MISMATCH')
    nine = read_csv(inp/'R28_NEUN_DEVICE_MODULE_BLOCKERS.csv')
    ninekeys = {(p['cohort'],p['module']) for p in nine}
    check(ninekeys == REQUIRED_NINE and len(nine) == 365, 'NINE_DEVICE_EVIDENCE_CHANGED')
    for p in nine:
        check((p['cohort'],p['symbol']) in expected and
              normalize_crc(p['oem_expected_crc']) == expected[(p['cohort'],p['symbol'])],
              'NINE_BLOCKER_EVIDENCE_INVALID')
    # Verify exact R30 binary-derived summary for every weighted import, not just high-priority samples.
    totals = {c:{s:Counter() for s in STAGES} for c in COHORTS}
    transitions = {c:Counter() for c in COHORTS}
    symbol_rows = []
    for (cohort, symbol), ecrc in sorted(expected.items()):
        count = weights[(cohort,symbol)]
        stages = {st:get_status(ecrc,sym[st].get(symbol)) for st in STAGES}
        for st in STAGES:totals[cohort][st][stages[st]] += count
        transitions[cohort][(stages['R13'],stages['A'],stages['B'])] += count
        symbol_rows.append({
            'cohort':cohort,'symbol':symbol,'import_occurrences':count,
            'stock_import_expected_crc':ecrc,
            **{st+'_crc':sym[st].get(symbol,'') for st in STAGES},
            **{st+'_status':stages[st] for st in STAGES},
            'A_vs_R13':stages['R13']+'->'+stages['A'],
            'B_vs_A':stages['A']+'->'+stages['B'],
        })
    for cohort in COHORTS:
        for st in STAGES:
            observed = {kind:totals[cohort][st][kind] for kind in STATUSES}
            check(observed == EXPECTED_COUNTS[cohort][st], 'EXPECTED_COHORT_COUNTS_MISMATCH:'+cohort+':'+st)
            ref = exp['baseline'][cohort] if st == 'R13' else exp['A_STOCK_IPC' if st=='A' else 'B_STOCK_IPC_TRACE']['abi'][cohort]
            check(ref['counts'] == observed, 'R30_REPORTED_COUNTS_DONT_REPRODUCE')
    # R28 formally demonstrated these 836 expected CRC conflicts across two alternative cohorts.
    gki={s:v for (c,s),v in expected.items() if c=='GKI'}
    qgki={s:v for (c,s),v in expected.items() if c=='QGKI'}
    both=set(gki)&set(qgki)
    check(len(both)==1393,'COHORT_OVERLAP_MISMATCH')
    conflicts=[{'symbol':s,'QGKI_expected_crc':qgki[s],'GKI_expected_crc':gki[s],
                'QGKI_import_occurrences':weights[('QGKI',s)],'GKI_import_occurrences':weights[('GKI',s)]}
               for s in sorted(both) if qgki[s]!=gki[s]]
    check(len(conflicts)==836, 'COHORT_CRC_CONFLICT_COUNT_MISMATCH')
    module_rows=[]
    module_import_rows=[]
    blockers=[]
    for (cohort, path), imports in sorted(bymodule.items()):
        c={st:Counter() for st in STAGES}
        nineflag=(cohort,path) in ninekeys
        for p in sorted(imports,key=lambda x:x['symbol']):
            symbol=p['symbol']; ecrc=expected[(cohort,symbol)]
            states={st:get_status(ecrc,sym[st].get(symbol)) for st in STAGES}
            for st in STAGES:c[st][states[st]]+=1
            row={'cohort':cohort,'module':path,'symbol':symbol,'expected_crc':ecrc,
                 **{st+'_crc':sym[st].get(symbol,'') for st in STAGES},
                 **{st+'_status':states[st] for st in STAGES}}
            if nineflag and states['A']!='MATCH':blockers.append(row)
            module_import_rows.append(row)
        m={'cohort':cohort,'module':path,'import_count':len(imports),'nine_device_module':'YES' if nineflag else 'NO'}
        for st in STAGES:
            m[st+'_MATCH']=c[st]['MATCH'];m[st+'_CRC_MISMATCH']=c[st]['CRC_MISMATCH'];m[st+'_NOT_EXPORTED']=c[st]['NOT_EXPORTED']
            m[st+'_full_import_compatible']='YES' if c[st]['MATCH']==len(imports) else 'NO'
        m['A_match_gain_vs_R13']=c['A']['MATCH']-c['R13']['MATCH']
        m['B_match_gain_vs_A']=c['B']['MATCH']-c['A']['MATCH']
        module_rows.append(m)
    check(len(bymodule)==218 and sum(int(m['import_count']) for m in module_rows)==14648,
          'PER_MODULE_TOTALS_CHANGED')
    check(sum(m['nine_device_module']=='YES' for m in module_rows)==9, 'NINE_DEVICE_MODULES_ABSENT')
    # Kconfig is not a proof of ABI compatibility: report deltas only, no mass enable or forced CRC.
    cfg = {st:parse_configs(inp/name) for st,name in {
        'STOCK':'STOCK_5_4_274.config','R13':'R13_ACTUAL.config',
        'A':'A_STOCK_IPC_ACTUAL.config','B':'B_STOCK_IPC_TRACE_ACTUAL.config'}.items()}
    cfg_rows=[]
    for k in sorted(set().union(*[set(x) for x in cfg.values()])):
        vals={s:cfg[s].get(k,'<UNSET>') for s in ('STOCK','R13','A','B')}
        if vals['STOCK'] != vals['R13'] or vals['R13']!=vals['A'] or vals['A']!=vals['B']:
            cfg_rows.append({'config_flag':k,**{s+'_value':vals[s] for s in ('STOCK','R13','A','B')},
                             'R13_vs_stock':'DIFFERENT' if vals['STOCK']!=vals['R13'] else 'SAME',
                             'A_vs_R13':'DIFFERENT' if vals['A']!=vals['R13'] else 'SAME',
                             'B_vs_A':'DIFFERENT' if vals['B']!=vals['A'] else 'SAME'})
    check(cfg['R13'].get('CONFIG_SCHED_CASS')=='y' and cfg['A'].get('CONFIG_SCHED_CASS')=='y'
          and cfg['B'].get('CONFIG_SCHED_CASS')=='y', 'CASS_CONFIG_NOT_PRESERVED')
    priorities=[]
    for srow in symbol_rows:
        if srow['A_status']!='MATCH':
            priorities.append({**srow,'nine_module_affected':sum(1 for row in blockers
                if row['cohort']==srow['cohort'] and row['symbol']==srow['symbol'])})
    priorities.sort(key=lambda r:(r['cohort']!='QGKI',-r['nine_module_affected'], -r['import_occurrences'],r['symbol']))
    summary={
        'schema':1,'status':'OFFLINE_CRC_DIAG_PASS__FULL_OEM_ABI_BLOCKED__NO_FLASH',
        'check_scope':'R28 OEM imported CRC partial profile against authentic R13 and R30 CI Module.symvers',
        'flash_allowed':False,'device_test':False,'built_new_kernel':False,'kernel_changed':False,
        'best_candidate_for_further_research':'A_STOCK_IPC',
        'source_identity':'R30 Github run 41207776770 commit 7fe4870fcaf84a3259a8acbdce69dc5bfe088425',
        'limitations':[
            'Original OEM Module.symvers and exact OEM 5.4.274 source tree are NOT available.',
            'QGKI and GKI are alternative module cohorts; do not merge conflicting CRC targets.',
            'A matching import CRC is necessary but not sufficient for safe module loading.',
            'No evidence of actual installed/loaded module paths or runtime cellular behavior.',
            'Never patch Module.symvers or force CRC values; diagnose source/config/toolchain ABI instead.',
        ],
        'expected_imports':EXPECTED_ROWS,
        'symbol_counts':EXPECTED_SYMBOLS,
        'vendor_module_paths_per_cohort':{c:sum(row['cohort']==c for row in module_rows) for c in COHORTS},
        'nine_device_modules':9,
        'nine_device_modules_not_compatible_A':sum(m['nine_device_module']=='YES' and m['A_full_import_compatible']=='NO' for m in module_rows),
        'cohort_conflicting_expected_crc_symbols':836,
        'reported_counts':{c:{st:dict(totals[c][st]) for st in STAGES} for c in COHORTS},
        'transitions':{c:[{'R13':x,'A':y,'B':z,'import_occurrences':num} for (x,y,z),num in sorted(transitions[c].items())] for c in COHORTS},
        'module_layout':{c:{'stock_import_expected_crc':expected[(c,'module_layout')],
                           'R13_crc':sym['R13']['module_layout'],
                           'A_crc':sym['A']['module_layout'],
                           'B_crc':sym['B']['module_layout'],
                           'module_import_occurrences':weights[(c,'module_layout')]}
                         for c in COHORTS},
        'config_difference_counts':{'stock_vs_R13':sum(r['R13_vs_stock']=='DIFFERENT' for r in cfg_rows),
                                    'R13_vs_A':sum(r['A_vs_R13']=='DIFFERENT' for r in cfg_rows),
                                    'A_vs_B':sum(r['B_vs_A']=='DIFFERENT' for r in cfg_rows)},
    }
    check(summary['nine_device_modules_not_compatible_A'] == 9, 'NINE_DEVICE_MODULES_COMPATIBILITY_UNEXPECTED')
    out.mkdir(parents=True,exist_ok=True)
    write_csv(out/'R30_R2_ALL_SYMBOLS.csv',symbol_rows,list(symbol_rows[0]))
    write_csv(out/'R30_R2_ALL_MODULES.csv',module_rows,list(module_rows[0]))
    write_csv(out/'R30_R2_NINE_DEVICE_MODULES.csv',
              [r for r in module_rows if r['nine_device_module']=='YES'],list(module_rows[0]))
    write_csv(out/'R30_R2_NINE_DEVICE_BLOCKERS.csv',blockers,list(blockers[0]))
    write_csv(out/'R30_R2_TOP_PRIORITY_SYMBOLS.csv',priorities[:160],
              list(priorities[0]))
    write_csv(out/'R30_R2_OEM_COHORT_CRC_CONFLICTS.csv',conflicts,list(conflicts[0]))
    write_csv(out/'R30_R2_CONFIG_DIFFERENCES.csv',cfg_rows,list(cfg_rows[0]))
    (out/'R30_R2_RESULTS.json').write_text(json.dumps(summary,sort_keys=True,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    d=['VEUX R30-R2: OEM-CRC-Ursachenanalyse (read-only, NO FLASH)',
       'Quellen: R28 OEM imports + R30 authentic R13/A/B Module.symvers. Kein neuer Build.',
       '', 'Beobachtung (gewichtete Importvorkommen):']
    for c in COHORTS:
        d.append('  '+c+': '+', '.join(st+' [M='+str(totals[c][st]['MATCH'])+', CRC='+str(totals[c][st]['CRC_MISMATCH'])+', fehlt='+str(totals[c][st]['NOT_EXPORTED'])+']' for st in STAGES))
    d.extend(['', 'module_layout ist in beiden OEM-Kohorten inkompatibel:',
              '  QGKI OEM '+expected[('QGKI','module_layout')] + ' vs A '+sym['A']['module_layout']+' (37 Modulimporte)',
              '  GKI  OEM '+expected[('GKI','module_layout')]+' vs A '+sym['A']['module_layout']+' (181 Modulimporte)',
              '', 'Neun RMNET-/IPA-Priority-Modulpfade: '+str(summary['nine_device_modules_not_compatible_A'])+'/9 sind in A NICHT import-ABI-kompatibel.',
              'R30-B: keine zusaetzlichen exakten Matches; weitere fehlende Symbole werden nur CRC-Mismatches.',
              'Die 836 OEM-CRC-Konflikte zwischen QGKI und GKI verbieten einen globalen kombinierten CRC-Zielwert.',
              '', 'Naechster technischer Schritt:',
              '1. QGKI als konkret zu bestaetigendes Zielprofil priorisieren; keine GKI-QGKI-CRC Mischung.',
              '2. Relevante Typ-/Struct-Unterschiede bei module_layout, kmalloc_caches, kmem_cache_alloc_trace sowie RMNET-Importen ursachenbezogen analysieren.',
              '3. Echte Xiaomi-Stock-Quellen, Header, Kernel-ABI und Compilerflags nach Provenienz vergleichen; keine CRC-Spiegelung.',
              '4. Erst danach minimalen isolierten Variant-A-Rebuild plus geschlossene OEM-ABI-Schranke planen.',
              '5. Solange auch nur ein fuer das Modul benoetigtes Symbol fehlt oder falsche CRC traegt: NO FLASH.',
              '', 'Hinweis: R13 bleibt unveraendert, BakaSU/SUSFS/NoMount werden nicht angefasst.\n'])
    (out/'R30_R2_PRUEFBERICHT_DE.txt').write_text('\n'.join(d),encoding='utf-8')
    print('R30_R2_DIAGNOSTIC_PASS__FULL_OEM_ABI_BLOCKED__NO_FLASH')
    for c in COHORTS:
        for st in STAGES:
            print(c,st,dict(totals[c][st]))
    print('9 priority modules blocked:',summary['nine_device_modules_not_compatible_A'])
    return summary


def selftest():
    assert get_status('0x00000003',None) == 'NOT_EXPORTED'
    assert get_status('0x00000003','0x00000003') == 'MATCH'
    assert get_status('0x00000003','0x00000002') == 'CRC_MISMATCH'
    assert normalize_crc('0xAb')=='0x000000ab'
    for v in ['nope','0x','0x112233445','0xgggg']:
        try:normalize_crc(v)
        except ValueError:pass
        else:raise AssertionError('INVALID_CRC_ACCEPTED')
    for v in ['',None,False]:
        try:check(v,'NEGATIVE_TEST')
        except ValueError:pass
        else:raise AssertionError('EMPTY_INPUT_ACCEPTED')
    print('R30_R2_PURE_FUNCTION_SELFTEST_PASS')

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--input',type=Path,default=Path(__file__).resolve().parent/'inputs')
    parser.add_argument('--out',type=Path,default=Path('r30_r2_reports'))
    parser.add_argument('--selftest',action='store_true')
    args=parser.parse_args()
    if args.selftest:selftest()
    else:run(args.input,args.out)
