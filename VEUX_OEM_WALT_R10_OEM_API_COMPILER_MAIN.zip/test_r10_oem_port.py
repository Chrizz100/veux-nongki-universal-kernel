import importlib.util, pathlib, tempfile, unittest, copy, hashlib
root=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('mod',root/'r10_oem_api_port.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class R10SourceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original={'include/linux/sched.h':(root/'fixtures/R6_linux_sched.h').read_text(),
                      'kernel/sched/sched.h':(root/'fixtures/R8_sched.h').read_text(),
                      'kernel/sched/core.c':'#include "sched.h"\n\n#include "pelt.h"\n#define CREATE_TRACE_POINTS\n'}
        cls.events=(root/'R10_OEM_EVENTS.inc').read_text()
    def test_01_source_hash(self):
        for p,h in m.PREIMAGE.items():self.assertEqual(hashlib.sha256(self.original[p].encode()).hexdigest(),h)
    def test_02_event_source(self):
        self.assertIn('TASK_UPDATE     = 4',self.events)
        self.assertIn('TASK_WAKE       = 2',self.events)
        self.assertIn('enum migrate_types {',self.events)
    def test_03_patch_all_three_only(self):
        x=m.patch(self.original,self.events);self.assertEqual(set(x),set(m.WHITELIST))
        self.assertTrue(all(x[k]!=self.original[k] for k in m.WHITELIST))
    def test_04_event_includes_and_values(self):
        x=m.patch(self.original,self.events)['include/linux/sched.h'];self.assertEqual(x.count('enum task_event {'),1)
        self.assertEqual(x.count('enum migrate_types {'),1)
    def test_05_cpu_callback_real(self):
        x=m.patch(self.original,self.events)['include/linux/sched.h'];self.assertIn('u64 (*get_cpu_cycle_counter)(int cpu);',x)
    def test_06_real_walt_rtg(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('u64 downmigrate_ts;',x)
        self.assertIn('raw_spinlock_t lock;',x)
    def test_07_cgroup_wtg_real(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('struct walt_task_group\twtg;',x)
    def test_08_idle_state_real(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('int\t\t\tidle_state_idx;',x)
    def test_09_real_load_not_stub(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('return p->wts.demand;',x)
        self.assertIn('return p->wts.demand_scaled;',x)
    def test_10_cpufreq_rtg_declarations(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('extern void sched_update_nr_prod',x)
        self.assertIn('extern int update_preferred_cluster',x)
    def test_11_no_fake_crc(self):
        x='\n'.join(m.patch(self.original,self.events).values());self.assertNotIn('0x945d02f2',x)
        self.assertNotIn('0xbff14f69',x)
    def test_12_real_walt_include(self):
        x=m.patch(self.original,self.events)['kernel/sched/core.c'];self.assertIn('#include "walt/walt.h"',x)
    def test_13_original_r8_reservation(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('clear_bit(CPU_RESERVED, &rq->wrq.walt_flags);',x)
    def test_14_preserve_sprd(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('#elif defined(CONFIG_SPRD_ROTATION_TASK)',x)
    def test_15_no_old_walt_api_duplicate(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertEqual(x.count('static inline unsigned int task_load('),1)
    def test_16_no_root_modifications(self):
        self.assertEqual(set(m.WHITELIST),{'include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c'})
    def test_17_wrong_linux_sched_rejected(self):
        y=copy.copy(self.original);y['include/linux/sched.h']+='enum task_event {'
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_18_wrong_core_rejected(self):
        y=copy.copy(self.original);y['kernel/sched/core.c']='int main(void){}'
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_19_dup_core_header_rejected(self):
        y=copy.copy(self.original);y['kernel/sched/core.c']+='#include "walt/walt.h"\n'
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_20_dup_sched_helpers_rejected(self):
        y=copy.copy(self.original);y['kernel/sched/sched.h']+='static inline unsigned int task_load('
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_21_dup_rtg_rejected(self):
        y=copy.copy(self.original);y['kernel/sched/sched.h']+='struct walt_related_thread_group {'
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_22_missing_event_rejected(self):
        with self.assertRaises(m.GateError):m.patch(self.original,'enum task_event {\n};\n')
    def test_23_scope_escape_rejected(self):
        y=copy.copy(self.original);y['fs/open.c']='x'
        with self.assertRaises(m.GateError):m.patch(y,self.events)
    def test_24_deteministic(self):
        self.assertEqual(m.patch(self.original,self.events),m.patch(self.original,self.events))
    def test_25_walt_reserved_helper_not_replaced(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertIn('test_and_set_bit(CPU_RESERVED',x)
    def test_26_abi_no_approval(self):
        self.assertIn("'vendor_abi_proven':False",(root/'r10_oem_api_port.py').read_text())
    def test_27_no_flash(self):
        self.assertIn("'flash_allowed':False",(root/'r10_oem_api_port.py').read_text())
    def test_28_no_silent_macro_redefinitions(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertEqual(x.count('#define CPU_RESERVED'),1)
    def test_29_no_duplicate_scheduled_clock(self):
        x=m.patch(self.original,self.events)['kernel/sched/sched.h'];self.assertEqual(x.count('u64 sched_ktime_clock(void);'),2)
    def test_30_compat_system_status(self):
        self.assertIn('R10_COMPILE_DIAGNOSTICS_RECORDED',(root/'r10_real_compile.py').read_text())
    def test_31_full_config_compare_code(self):
        t=(root/'r10_real_compile.py').read_text()
        self.assertIn('sorted(set(expected)|set(actual))',t)
        self.assertIn('ALL_CONFIG_SYMBOLS_NOT_JUST_EIGHT',t)
    def test_32_no_full_config_false_approval(self):
        t=(root/'r10_real_compile.py').read_text()
        self.assertIn("full_status=='COMPARED' and not full_config_diff",t)
    def test_33_eight_feature_gate_remains(self):
        t=(root/'r10_real_compile.py').read_text()
        self.assertIn("outcome.get('config_diff',{})",t)

if __name__=='__main__':unittest.main()
