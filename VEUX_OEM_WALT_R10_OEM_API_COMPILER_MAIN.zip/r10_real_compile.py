#!/usr/bin/env python3
"""R10 object-only compiler adapter, retaining the audited R9 Kbuild runner.

The adapter verifies R10's signed source postimage and original R9 stage,
then delegates the real ARM64 object compilation to the existing R9 driver.
It never claims success because a diagnostic workflow itself is green.
"""
import argparse, hashlib, importlib.util, json, sys
from pathlib import Path

class Failed(Exception):pass
def must(ok, message):
    if not ok:raise Failed(message)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def run(snapshot, outdir, reportdir, stock, toolchain, r9_source, timeout=300):
    gate=json.loads((outdir/'R10_SOURCE_GATE.json').read_text())
    stage=json.loads((reportdir/'R9_STAGE_REPORT.json').read_text())
    must(stage['status']=='R9_SOURCE_SNAPSHOT_STAGED','R9_PROVENANCE_NOT_STAGED')
    must(gate['status']=='R10_OEM_WALT_SOURCE_API_STAGED_NOT_COMPILED','R10_SOURCE_GATE_MISSING')
    must(stage['provenance']['r8_gate']=='PASS','R8_GATE_MISSING')
    must(gate['modified_files']==['include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c'],'R10_FILE_SCOPE')
    must(not any(gate[k] for k in ('flash_allowed','vendor_abi_proven','kernel_image_built','all_objects_compiled','brene_changed')),'FALSE_APPROVAL')
    for path,expected in gate['after_sha256'].items():
        p=snapshot/path
        must(p.is_file() and not p.is_symlink() and digest(p)==expected,'R10_SOURCE_HASH:'+path)
    spec=importlib.util.spec_from_file_location('r9_audited_compiler',r9_source)
    must(spec is not None and spec.loader is not None,'R9_RUNNER_UNAVAILABLE')
    r9=importlib.util.module_from_spec(spec);spec.loader.exec_module(r9)
    must(r9.R8_SCHED_HASH==gate['before_sha256']['kernel/sched/sched.h'],'R9_R8_PIN_DISAGREEMENT')
    # R10's authenticated postimage is the ONLY header change from R9.
    # Reuse identical R9 toolchain, config, Kbuild invocation and error capture.
    r9.R8_SCHED_HASH=gate['after_sha256']['kernel/sched/sched.h']
    outcome=r9.compile_objects(snapshot,objout=outdir.parent/'veux-r10-objout',
        reportdir=reportdir,stock=stock,toolchain=toolchain,limit=timeout,jobs=2)
    objects=outcome.get('objects',{})
    # R9 compared only eight FEATURE keys. Compare EVERY OEM config option here;
    # a zero in the eight-key report must never be mistaken for full OEM parity.
    full_config_diff={}
    effective=reportdir/'R9_EFFECTIVE_CONFIG.config'
    if effective.is_file() and not effective.is_symlink():
        expected=r9.config_values(stock.read_text())
        actual=r9.config_values(effective.read_text())
        for key in sorted(set(expected)|set(actual)):
            ov=expected.get(key,'ABSENT');av=actual.get(key,'ABSENT')
            if ov!=av:full_config_diff[key]={'oem':ov,'effective':av}
    full_status='COMPARED' if effective.is_file() and not effective.is_symlink() else 'NOT_GENERATED'
    (outdir/'R10_FULL_CONFIG_DIFF.json').write_text(json.dumps({
        'status':full_status,'differences':full_config_diff,
        'difference_count':len(full_config_diff),'scope':'ALL_CONFIG_SYMBOLS_NOT_JUST_EIGHT',
        'oem_abi_proven':False},indent=2,sort_keys=True)+'\n')
    objects=outcome.get('objects',{})
    ret={
        'status': 'R10_ALL_THREE_OBJECTS_COMPILED' if len(objects)==3 and all(x['compiled'] for x in objects.values())
                  else 'R10_COMPILE_DIAGNOSTICS_RECORDED',
        'r9_status':outcome['status'],
        'actual_object_make_attempted':outcome.get('object_make_attempted',False),
        'objects':objects, 'object_success_count':sum(x.get('compiled',False) for x in objects.values()),
        'source_r10_sha256':gate['after_sha256'],
        'kernel_image_built':False,'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
        'source_original_unchanged':True,
        'config_diff':outcome.get('config_diff',{}),
        'full_oem_config_difference_count':len(full_config_diff),
        'full_oem_config_comparison':full_status,
        'full_oem_config_parity_proven':full_status=='COMPARED' and not full_config_diff,
        'config_walt_y':outcome.get('config_walt_y',False),
        'clang_used':outcome.get('toolchain',{}).get('clang',{}).get('version','UNAVAILABLE')
    }
    (outdir/'R10_COMPILER_RESULT.json').write_text(json.dumps(ret,indent=2,sort_keys=True)+'\n')
    print('R10_REAL_OBJECTS='+str(len(objects))+'; COMPILED='+str(ret['object_success_count'])+
          '; STATUS='+ret['status']+'; FULL_CONFIG_DIFF='+str(len(full_config_diff))+'; IMAGE=NO; ABI=OPEN; FLASH=NO')
    return ret

def main():
    pa=argparse.ArgumentParser()
    for n in ('snapshot','output','report','stock','toolchain','r9-driver'):
        pa.add_argument('--'+n,required=True,type=Path)
    x=pa.parse_args()
    try:run(x.snapshot,x.output,x.report,x.stock,x.toolchain,x.r9_driver)
    except (Failed,OSError,ValueError,KeyError,AttributeError) as e:
        print('R10_COMPILER_ADAPTER_FAILED:'+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
