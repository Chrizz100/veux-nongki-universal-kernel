#!/usr/bin/env python3
"""R10 candidate: real Xiaomi WALT event/RTG/cluster API source port.

Source-only and fail closed. Does not construct flashable images, cannot prove ABI.
Intentionally only modifies three whitelisted paths in a disposable R9 snapshot.
The donor code is from MiCode/Xiaomi_Kernel_OpenSource (veux-r-oss, pinned
61397e524093d1ccb94769b5460825e2eaf8871e) and must be compiled on 5.4.274
before considering the patch finished.
"""
import argparse, difflib, hashlib, json, sys
from pathlib import Path

PREIMAGE = {
    'include/linux/sched.h':'3731e599cc85d378ff5b95340214d8de5913be3a0f53c48cec9f1879ee84c6cd',
    'kernel/sched/sched.h':'12f10b1be96b1868304dd0f5e85a8e4e421ae72383d8b76571a2dc91fd6d4f5d'
}
WHITELIST=('include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c')
class GateError(Exception):pass

def need(expr,msg):
    if not expr:raise GateError(msg)
def h(d):return hashlib.sha256(d).hexdigest()
def read(p,sha=None):
    need(p.is_file() and not p.is_symlink(),'MISSING_OR_SYMLINK:'+str(p))
    dat=p.read_bytes()
    if sha:need(h(dat)==sha,'PREIMAGE_SHA_MISMATCH:'+str(p))
    return dat.decode('utf-8')
def put(src,anchor,insertion,label):
    need(src.count(anchor)==1,'ANCHOR_NOT_UNIQUE:'+label+':'+str(src.count(anchor)))
    return src.replace(anchor,insertion,1)

def modify_sched_linux(src,event_section):
    need('enum task_event {' not in src and 'enum migrate_types {' not in src,'EVENTS_ALREADY_PRESENT')
    need('struct cpu_cycle_counter_cb {' not in src,'CPU_CB_ALREADY_PRESENT')
    need(event_section.count('enum task_event {')==1 and event_section.count('enum migrate_types {')==1,'INVALID_OEM_EVENTS')
    src=put(src,'#define TASK_COMM_LEN\t\t\t16\n', '#define TASK_COMM_LEN\t\t\t16\n\n'+event_section.rstrip()+'\n', 'OEM_EVENT_LOCATION')
    src=put(src,'#ifdef CONFIG_SCHED_WALT\nextern void walt_task_dead(struct task_struct *p);',
        '/* From the Xiaomi 5.4.274 embedded OEM sched.h (CPU cycle ABI). */\n'
        'struct cpu_cycle_counter_cb {\n\tu64 (*get_cpu_cycle_counter)(int cpu);\n};\n\n'
        '#ifdef CONFIG_SCHED_WALT\nextern void walt_task_dead(struct task_struct *p);','CPU_CYCLE_ABI')
    return src

API='''/* Xiaomi WALT scheduler API (MiCode/veux-r-oss, 5.4.134): source-only backport.
 * Preserve R8 reservation helpers below; do not add dummy implementations. */
#define WALT_MANY_WAKEUP_DEFAULT 1000
extern unsigned int sysctl_sched_many_wakeup_threshold;
extern unsigned int sched_boost_type;
extern enum sched_boost_policy boost_policy;
extern unsigned int max_possible_capacity;
extern unsigned int min_max_possible_capacity;
extern unsigned int __read_mostly sched_init_task_load_windows;
extern unsigned int __read_mostly sched_load_granule;
extern struct walt_sched_cluster *sched_cluster[NR_CPUS];
extern void sched_update_nr_prod(int cpu, long delta, bool inc);
extern int update_preferred_cluster(struct walt_related_thread_group *grp,
                   struct task_struct *p, u32 old_load, bool from_tick);
extern void set_preferred_cluster(struct walt_related_thread_group *grp);
extern void add_new_task_to_grp(struct task_struct *new);
extern int alloc_related_thread_groups(void);
extern void check_for_migration(struct rq *rq, struct task_struct *p);
extern int preferred_cluster(struct walt_sched_cluster *cluster,
                             struct task_struct *p);
extern struct walt_sched_cluster *rq_cluster(struct rq *rq);
extern unsigned long thermal_cap(int cpu);
extern void clear_walt_request(int cpu);
extern void sched_boost_parse_dt(void);
extern void clear_ed_task(struct task_struct *p, struct rq *rq);
extern bool early_detection_notify(struct rq *rq, u64 wallclock);
extern void note_task_waking(struct task_struct *p, u64 wallclock);

#define NO_BOOST 0
#define FULL_THROTTLE_BOOST 1
#define CONSERVATIVE_BOOST 2
#define RESTRAINED_BOOST 3
#define FULL_THROTTLE_BOOST_DISABLE -1
#define CONSERVATIVE_BOOST_DISABLE -2
#define RESTRAINED_BOOST_DISABLE -3
#define MAX_NUM_BOOST_TYPE (RESTRAINED_BOOST+1)

static inline bool walt_want_remote_wakeup(void)
{
    return sysctl_sched_many_wakeup_threshold < WALT_MANY_WAKEUP_DEFAULT;
}
static inline int cluster_first_cpu(struct walt_sched_cluster *cluster)
{
    return cpumask_first(&cluster->cpus);
}
static inline unsigned int cpu_max_possible_freq(int cpu)
{
    return cpu_rq(cpu)->wrq.cluster->max_possible_freq;
}
static inline bool hmp_capable(void)
{
    return max_possible_capacity != min_max_possible_capacity;
}
static inline int asym_cap_siblings(int cpu1, int cpu2)
{
    return cpumask_test_cpu(cpu1, &asym_cap_sibling_cpus) &&
           cpumask_test_cpu(cpu2, &asym_cap_sibling_cpus);
}
static inline bool is_max_capacity_cpu(int cpu)
{
    return arch_scale_cpu_capacity(cpu) == max_possible_capacity;
}
static inline unsigned long task_util(struct task_struct *p)
{
    return p->wts.demand_scaled;
}
static inline unsigned int task_load(struct task_struct *p)
{
    return p->wts.demand;
}
static inline unsigned int task_pl(struct task_struct *p)
{
    return p->wts.pred_demand;
}
static inline bool task_in_related_thread_group(struct task_struct *p)
{
    return (rcu_access_pointer(p->wts.grp) != NULL);
}
static inline bool task_rtg_high_prio(struct task_struct *p)
{
    return task_in_related_thread_group(p) &&
           (p->prio <= sysctl_walt_rtg_cfs_boost_prio);
}
static inline struct walt_related_thread_group *
task_related_thread_group(struct task_struct *p)
{
    return rcu_dereference(p->wts.grp);
}
static inline bool walt_low_latency_task(struct task_struct *p)
{
    return p->wts.low_latency &&
           (task_util(p) < sysctl_walt_low_latency_task_threshold);
}
static inline bool walt_binder_low_latency_task(struct task_struct *p)
{
    return (p->wts.low_latency & WALT_LOW_LATENCY_BINDER) &&
           (task_util(p) < sysctl_walt_low_latency_task_threshold);
}
static inline bool walt_procfs_low_latency_task(struct task_struct *p)
{
    return (p->wts.low_latency & WALT_LOW_LATENCY_PROCFS) &&
           (task_util(p) < sysctl_walt_low_latency_task_threshold);
}
static inline int same_freq_domain(int src_cpu, int dst_cpu)
{
    struct rq *rq = cpu_rq(src_cpu);
    if (src_cpu == dst_cpu) return 1;
    if (asym_cap_siblings(src_cpu, dst_cpu)) return 1;
    return cpumask_test_cpu(dst_cpu, &rq->wrq.freq_domain_cpumask);
}
static inline enum sched_boost_policy sched_boost_policy(void)
{
    return boost_policy;
}
static inline int sched_boost(void)
{
    return sched_boost_type;
}
static inline bool rt_boost_on_big(void)
{
    return sched_boost() == FULL_THROTTLE_BOOST ?
        (sched_boost_policy() == SCHED_BOOST_ON_BIG) : false;
}
static inline bool is_full_throttle_boost(void)
{
    return sched_boost() == FULL_THROTTLE_BOOST;
}
#ifdef CONFIG_UCLAMP_TASK_GROUP
static inline bool task_sched_boost(struct task_struct *p)
{
    struct cgroup_subsys_state *css;
    struct task_group *tg;
    bool enabled;
    rcu_read_lock();
    css = task_css(p, cpu_cgrp_id);
    if (!css) { rcu_read_unlock(); return false; }
    tg = container_of(css, struct task_group, css);
    enabled = tg->wtg.sched_boost_enabled;
    rcu_read_unlock();
    return enabled;
}
extern int sync_cgroup_colocation(struct task_struct *p, bool insert);
#else
static inline bool task_sched_boost(struct task_struct *p) { return true; }
#endif
static inline enum sched_boost_policy task_boost_policy(struct task_struct *p)
{
    enum sched_boost_policy policy;
    if (likely(sched_boost_policy() == SCHED_BOOST_NONE))
        return SCHED_BOOST_NONE;
    policy = task_sched_boost(p) ? sched_boost_policy() : SCHED_BOOST_NONE;
    if (policy == SCHED_BOOST_ON_BIG &&
        sched_boost() == CONSERVATIVE_BOOST &&
        task_util(p) <= sysctl_sched_min_task_util_for_boost)
        policy = SCHED_BOOST_NONE;
    return policy;
}
static inline bool task_placement_boost_enabled(struct task_struct *p)
{
    if (likely(sched_boost_policy() == SCHED_BOOST_NONE)) return false;
    return task_sched_boost(p);
}
static inline void walt_fixup_cum_window_demand(struct rq *rq, s64 delta)
{
    rq->wrq.cum_window_demand_scaled += delta;
    if (unlikely((s64)rq->wrq.cum_window_demand_scaled < 0))
        rq->wrq.cum_window_demand_scaled = 0;
}
static inline bool task_in_cum_window_demand(struct rq *rq, struct task_struct *p)
{
    return cpu_of(rq) == task_cpu(p) && (p->on_rq ||
           p->wts.last_sleep_ts >= rq->wrq.window_start);
}
'''

def modify_sched_internal(src):
    need('struct walt_related_thread_group {' not in src,'RTG_ALREADY_DEFINED')
    need('enum sched_boost_policy {' not in src,'BOOST_ENUM_ALREADY_DEFINED')
    need('static inline unsigned int task_load(' not in src,'TASK_LOAD_ALREADY_DEFINED')
    src=put(src,'extern cpumask_t asym_cap_sibling_cpus;\n#endif /* CONFIG_SCHED_WALT */',
        '''/* Original Xiaomi WALT related thread group fields. */
struct walt_related_thread_group {
    int id;
    raw_spinlock_t lock;
    struct list_head tasks;
    struct list_head list;
    bool skip_min;
    struct rcu_head rcu;
    u64 last_update;
    u64 downmigrate_ts;
    u64 start_ts;
};

extern cpumask_t asym_cap_sibling_cpus;
#endif /* CONFIG_SCHED_WALT */''','RTG_POSITION')
    src=put(src,'\tunsigned int\t\tlatency_sensitive;\n#endif',
        '\tunsigned int\t\tlatency_sensitive;\n#ifdef CONFIG_SCHED_WALT\n\tstruct walt_task_group\twtg;\n#endif\n#endif','TASK_GROUP_WTG')
    src=put(src,'\tstruct cpuidle_state\t*idle_state;\n#endif\n};',
        '\tstruct cpuidle_state\t*idle_state;\n#ifdef CONFIG_SCHED_WALT\n\tint\t\t\tidle_state_idx;\n#endif\n#endif\n};','IDLE_STATE')
    old='#ifdef CONFIG_SCHED_WALT\n/* Original Xiaomi WALT reservation interface (MiCode veux-r-oss). */'
    new='''enum sched_boost_policy {
    SCHED_BOOST_NONE,
    SCHED_BOOST_ON_BIG,
    SCHED_BOOST_ON_ALL,
};

#ifdef CONFIG_SCHED_WALT
'''+API+'\n/* Original Xiaomi WALT reservation interface (MiCode veux-r-oss). */'
    src=put(src,old,new,'WALT_API_POSITION')
    return src

def modify_core(src):
    need('#include "walt/walt.h"' not in src,'WALT_CORE_ALREADY_INCLUDED')
    return put(src,'#include "pelt.h"\n', '#include "pelt.h"\n#include "walt/walt.h"\n','CORE_WALT_INCLUDE')

def patch(inputs,events):
    need(set(inputs)==set(WHITELIST),'FILE_SCOPE_VIOLATION')
    out=dict(inputs)
    out['include/linux/sched.h']=modify_sched_linux(inputs['include/linux/sched.h'],events)
    out['kernel/sched/sched.h']=modify_sched_internal(inputs['kernel/sched/sched.h'])
    out['kernel/sched/core.c']=modify_core(inputs['kernel/sched/core.c'])
    for path in WHITELIST:need(out[path]!=inputs[path],'PATCH_DID_NOT_CHANGE:'+path)
    return out

def main(argv=None):
    pa=argparse.ArgumentParser()
    pa.add_argument('--snapshot',required=True,type=Path)
    pa.add_argument('--events',required=True,type=Path)
    pa.add_argument('--output',required=True,type=Path)
    args=pa.parse_args(argv)
    try:
        need(args.snapshot.is_dir() and not args.snapshot.is_symlink(),'SNAPSHOT_REQUIRED')
        need(not args.output.exists() and not args.output.is_symlink(),'OUTPUT_MUST_BE_FRESH')
        snap=args.snapshot.resolve(); dest=args.output.resolve()
        need(snap!=dest and snap not in dest.parents and dest not in snap.parents,'OUTPUT_SOURCE_OVERLAP')
        evt=read(args.events)
        inputs={p:read(args.snapshot/p,PREIMAGE.get(p)) for p in WHITELIST}
        patched=patch(inputs,evt)
        result={'status':'R10_OEM_WALT_SOURCE_API_STAGED_NOT_COMPILED',
                'source_pinned_r6_r8':True,'modified_files':list(WHITELIST),
                'before_sha256':{n:h(v.encode()) for n,v in inputs.items()},
                'after_sha256':{n:h(v.encode()) for n,v in patched.items()},
                'vendor_abi_proven':False,'all_objects_compiled':False,
                'kernel_image_built':False,'flash_allowed':False,'brene_changed':False,
                'bakasusu_nomount_changed':False,
                'source_original_unchanged':True}
        patches=[]
        for p in WHITELIST:
            patches+=list(difflib.unified_diff(inputs[p].splitlines(keepends=True),
                patched[p].splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
        need(patches,'EMPTY_PATCH')
        # Strictly validate all modifications in memory before touching any output.
        args.output.mkdir(parents=True)
        for p in WHITELIST:
            target=args.snapshot/p
            need(target.is_file() and not target.is_symlink(),'TARGET_UNSAFE:'+p)
            target.write_text(patched[p])
        (args.output/'R10_PORT.patch').write_text(''.join(patches))
        (args.output/'R10_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        print('R10_OEM_SOURCE_API_STAGED=YES; FILES=3; BUILD=NOT_RUN; ABI=OPEN; FLASH=NO')
        return 0
    except (GateError,OSError,ValueError) as e:
        print('R10_SOURCE_GATE_FAILED:'+str(e),file=sys.stderr)
        return 2

if __name__=='__main__':sys.exit(main())
