"""Verify the zRAM attribute group, permissions and callback targets in a linked ARM64 Image."""
import argparse
import hashlib
import json
import struct
from pathlib import Path

from check import BOOT, STOCK_IMAGE, require, sha
from memory_image import mapped_symbols, stock_symbols

BASE = 0xffffffc010080000
MODES = {'pages_life': 0o444, 'time_list': 0o644, 'avg_size': 0o444,
         'origin_pages_max': 0o444, 'wb_pages_max': 0o444}


def inspect(image, symbols, mode, full=False):
    names = {name: addr for addr, _, name in symbols}
    functions = {}
    for addr, kind, name in symbols:
        if kind.lower() == 't' and not name.startswith('$') and '.cfi_jt' not in name:
            functions.setdefault(addr, set()).add(name.split('$')[0].split('.llvm.')[0])
    reloc = {}
    if mode == 'stock':
        tag = struct.pack('<Q', 1027)  # R_AARCH64_RELATIVE (Elf64_Rela)
        offset = image.find(tag, 8)
        while offset >= 0:
            if offset % 8 == 0 and offset + 16 <= len(image):
                loc, _, target = struct.unpack_from('<QQQ', image, offset - 8)
                if 0 <= loc - BASE < len(image) and 0 <= target - BASE < len(image):
                    reloc[loc - BASE] = target - BASE
            offset = image.find(tag, offset + 1)

    def pointer(offset):
        value, = struct.unpack_from('<Q', image, offset)
        if value == 0:
            return reloc.get(offset)
        require(0 <= value - BASE < len(image), 'Pointer outside linked Image')
        return value - BASE

    def callback(offset, expected):
        require(offset is not None, 'Missing ' + expected)
        if expected in functions.get(offset, ()):
            return
        word, = struct.unpack_from('<I', image, offset)
        require(word >> 26 == 5, 'Expected ARM64 CFI branch to ' + expected)
        delta = word & 0x3ffffff
        dest = offset + 4 * (delta - (1 << 26) if delta & (1 << 25) else delta)
        require(expected in functions.get(dest, ()), 'Wrong callback target for ' + expected)

    group = names['zram_disk_attr_group']
    table = names['zram_disk_attrs']
    require(pointer(names['zram_disk_attr_groups']) == group and pointer(group + 24) == table,
            'zRAM disk attribute group linkage')
    attrs = {}
    for i in range(128):
        attr = pointer(table + 8 * i)
        if attr is None:
            break
        start = pointer(attr)
        require(start is not None, 'Unnamed sysfs attribute')
        name = image[start:image.index(0, start, start + 96)].decode('ascii')
        require(name not in attrs, 'Duplicate attribute ' + name)
        attrs[name] = attr
    else:
        raise ValueError('Unterminated zRAM attribute group')
    require({'disksize', 'mm_stat', 'reset'} <= attrs.keys(), 'Unexpected zRAM table')
    if full:
        report = {}
        needed = {'idle_stat', 'new', 'new_stat', 'low_compress_ratio'}
        require((not needed.intersection(attrs) and len(attrs) == 22) if mode == 'm57'
                else (needed <= attrs.keys() and len(attrs) == 26), 'Unexpected zRAM inventory')
        for name, addr in sorted(attrs.items()):
            perms = struct.unpack_from('<H', image, addr + 8)[0]
            entry = {'mode': format(perms, '04o')}
            for key, bit, off in (('show', 0o444, 16), ('store', 0o222, 24)):
                target = pointer(addr + off)
                entry[key] = None
                if perms & bit:
                    expected = name + '_' + key
                    callback(target, expected)
                    entry[key] = expected
                else:
                    require(target is None, 'Unexpected ' + key + ' for ' + name)
            report[name] = entry
        return report, sorted(attrs)
    selected = sorted(attrs.keys() & MODES.keys())
    if mode == 'm56':
        require(not selected, 'Unexpected M56 monitoring nodes')
    else:
        require(selected == sorted(MODES), 'Missing MIUI zRAM nodes: ' + str(set(MODES) - set(selected)))
        for name in selected:
            addr = attrs[name]
            require(addr == names['dev_attr_' + name], 'Wrong registered attribute ' + name)
            require(struct.unpack_from('<H', image, addr + 8)[0] == MODES[name], 'Wrong mode: ' + name)
            callback(pointer(addr + 16), name + '_show')
            if name == 'time_list':
                callback(pointer(addr + 24), name + '_store')
            else:
                require(pointer(addr + 24) is None, 'Unexpected store: ' + name)
    if mode == 'stock':
        require(struct.unpack_from('<5I', image, names['default_time_list']) == (60, 120, 180, 300, 600),
                'Unexpected Xiaomi time limits')
    return {name: dict(mode=format(MODES[name], '04o'), show=name + '_show',
                       store=name + '_store' if name == 'time_list' else None) for name in selected}, sorted(attrs)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode', choices=['stock','m56','m57','candidate'])
    for name in ['image','result']:
        p.add_argument(name, type=Path)
    p.add_argument('--map', type=Path)
    p.add_argument('--full',action='store_true')
    p.add_argument('--inventory', type=Path)
    args = p.parse_args()
    data = args.image.read_bytes()
    if args.mode == 'stock':
        require(sha(args.image) == BOOT, 'Wrong Xiaomi boot partition image')
        data = data[4096:4096 + struct.unpack_from('<I', data, 8)[0]]
        require(hashlib.sha256(data).hexdigest() == STOCK_IMAGE, 'Wrong stock kernel')
        symbols = stock_symbols(data)
    else:
        if args.mode == 'm56':
            require(sha(args.image) == '55ca5dad85e0fa4b6dadef26f5a10988eb135e0f0dbbae2210964504a3fac812', 'Wrong M56 Image')
        if args.mode == 'm57':
            require(sha(args.image) == '6b8c280ade412427edf986006ae982937b30e28333efb938ed581077bf11aa88' and args.full, 'Wrong M57 baseline')
        symbols = mapped_symbols(args.map)
    report, inventory = inspect(data, symbols, args.mode, args.full)
    args.result.write_text(json.dumps(report, indent=2) + '\n')
    if args.inventory:
        args.inventory.write_text('\n'.join(inventory) + '\n')
    print(args.mode, 'zRAM monitoring nodes:', len(report), 'registered disk attributes:', len(inventory))
