"""Match Xiaomi's UFS rules and payload fingerprints to the exact stock binary."""
import argparse
import hashlib
import json
import re
import struct
from pathlib import Path
from check import BOOT, STOCK_IMAGE, require, sha
from memory_image import stock_symbols

BASE = 0xffffffc010080000
RULE = struct.Struct('<9s17s5s5sQI')
BLOBS = {'SKhynix_A043': 'db411a7ca973539e09d6c0429f9055574a87387e',
         'MICRON_128GB_0102': 'ee59e61fbc33dbd5ccc7470adfcf3c9b1a9c2b8a',
         'SKhynix_A002': '54869bda5da4d1000cc29a11d2db67f098cbae6a'}
DRIVER = 'bf3d32532aa07a6ecc058a569af8d51bc0da4359'

def git_blob(path, expected):
    data = path.read_bytes()
    header = ('blob %d\0' % len(data)).encode()
    require(hashlib.sha1(header + data).hexdigest() == expected, 'Wrong Xiaomi source: ' + path.name)
    return data.decode('ascii')

def resolve(image, offset):
    tag = struct.pack('<QQ', BASE + offset, 1027)
    address = image.index(tag)
    require(address % 8 == 0 and image.find(tag, address + 1) < 0, 'Ambiguous stock pointer')
    return struct.unpack_from('<Q', image, address + 16)[0] - BASE

def ctext(raw):
    txt, pad = raw.split(b'\0', 1)
    require(not any(pad) and txt and txt.isascii(), 'Invalid stock inquiry text')
    return txt.decode('ascii')

def read_rules(image, names):
    start = names['need_update_k']
    end = min(addr for addr in names.values() if addr > start)
    require(end - start == 6 * RULE.size, 'Expected six complete stock rules')
    rows = []
    for off in range(start, end, RULE.size):
        vendor, model, before, after, placeholder, size = RULE.unpack_from(image, off)
        target = resolve(image, off + 36)
        symbol, = [name for name in BLOBS if names[name] == target]
        require(placeholder == 0 and 0 < size <= len(image) - target, 'Invalid stock payload bounds')
        rows.append({'vendor': ctext(vendor), 'model': ctext(model), 'from': ctext(before),
                     'to': ctext(after), 'payload': symbol, 'bytes': size,
                     'sha256': hashlib.sha256(image[target:target+size]).hexdigest()})
    return rows

def stock_table(boot):
    require(sha(boot) == BOOT, 'Wrong Xiaomi boot reference')
    raw = boot.read_bytes()
    image = raw[4096:4096+struct.unpack_from('<I', raw, 8)[0]]
    require(hashlib.sha256(image).hexdigest() == STOCK_IMAGE, 'Wrong stock kernel')
    names = {n: a for a, _, n in stock_symbols(image)}
    return read_rules(image, names)

def compare(boot, donor, output):
    rows = stock_table(boot)
    source = git_blob(donor/'ufs_ffu.c', DRIVER)
    source = re.sub(r'/\*.*?\*/', '', source, flags=re.S)
    table = source.split('need_update_k[] = {', 1)[1].split('};', 1)[0]
    active = re.findall(r'\{\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*"([^"]+)"\s*,\s*\(uint64_t\)(\w+)\s*,\s*sizeof\(\5\)\}', table)
    vendor_rows = [[value.removesuffix(r'\0') for value in row] for row in active]
    fields = ('vendor', 'model', 'from', 'to', 'payload')
    keys = [[r[k] for k in fields] for r in rows]
    require(len(vendor_rows) == 5 and vendor_rows == keys[:5] and keys[5] ==
            ['SKhynix', 'H9QT1G6DN6X132', 'A001', 'A002', 'SKhynix_A002'], 'Unexpected OEM rule table')
    for symbol, blob in BLOBS.items():
        header = git_blob(donor/(symbol+'.h'), blob)
        initializer = header.split('{', 1)[1].split('}', 1)[0]
        initializer = re.sub(r'/\*.*?\*/', '', initializer, flags=re.S)
        require(re.fullmatch(r'(?:\s|,|0x[\da-fA-F]{2})+', initializer) is not None, 'Unknown firmware encoding')
        data = bytes.fromhex(''.join(re.findall(r'0x([\da-fA-F]{2})', initializer)))
        relevant = [r for r in rows if r['payload'] == symbol]
        require(relevant and all(r['sha256'] == hashlib.sha256(data).hexdigest() and
                                 r['bytes'] == len(data) for r in relevant), 'OEM payload mismatch: '+symbol)
    output.write_text(json.dumps({'stock_image_sha256': STOCK_IMAGE, 'stock_rules': rows,
        'public_driver_git_blob': DRIVER, 'public_header_git_blobs': BLOBS, 'public_rules': len(active),
        'additional_partition_rules': 'device-specific'}, indent=2)+'\n')
    print('PASS six stock rules, five source rules, three complete matching firmware payloads')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    for key in ('boot','oem_dir','report'):
        p.add_argument(key, type=Path)
    p.add_argument('--verified-reference', action='store_true',
                   help='Compare stock with the previously verified OEM receipt supplied in the kit')
    a=p.parse_args()
    if a.verified_reference:
        report = json.loads(a.oem_dir.read_text())
        require(report['stock_image_sha256'] == STOCK_IMAGE and report['public_driver_git_blob'] == DRIVER and
                report['public_header_git_blobs'] == BLOBS and report['public_rules'] == 5,
                'Wrong offline Xiaomi reference')
        require(stock_table(a.boot) == report['stock_rules'], 'Stock rules or payloads differ')
        a.report.write_text(json.dumps(report, indent=2)+'\n')
        print('PASS six linked stock rules and their payload hashes against verified Xiaomi receipt')
    else:
        compare(a.boot, a.oem_dir, a.report)
