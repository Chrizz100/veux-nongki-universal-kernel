"""Compare linked PMIC register access and export CRCs with the Xiaomi reference."""
import argparse
import json
import struct
import tempfile
from pathlib import Path
from check import BOOT, require, sha
from memory_image import Code, mapped_symbols, stock_symbols
from ufs_reference import resolve

ENTRIES = ('qpnp_pon_uvlo_get', 'qpnp_pon_uvlo_set')

def stock_crcs(image, names):
    sym = names['__start___ksymtab']
    crc = names['__start___kcrctab']
    n, rem = divmod(names['__stop___kcrctab'] - crc, 4)
    require(n > 0 and not rem and names['__stop___ksymtab'] - sym == 24 * n,
            'Unexpected stock export-table layout')
    result = {}
    for name in ENTRIES:
        entry = names['__ksymtab_' + name]
        idx, rem = divmod(entry - sym, 24)
        require(0 <= idx < n and not rem, 'Invalid stock export index')
        addr = resolve(image, entry + 8)
        require(image.startswith(name.encode() + b'\0', addr), 'Wrong stock export name')
        result[name] = '0x%08x' % struct.unpack_from('<I', image, crc + 4 * idx)[0]
    return result

def read_crcs(path):
    result = {}
    for line in path.read_text().splitlines():
        crc, symbol, owner, kind, *_ = line.split()
        if symbol in ENTRIES:
            require(owner == 'vmlinux' and kind == 'EXPORT_SYMBOL' and symbol not in result,
                    'Wrong PMIC provider: ' + symbol)
            result[symbol] = crc.lower()
    require(set(result) == set(ENTRIES), 'Missing PMIC exports')
    return result

def access(image, rows, compiler):
    with tempfile.TemporaryDirectory() as work:
        code = Code(image, rows, compiler, Path(work))
        for name, api in zip(ENTRIES, ('regmap_read', 'regmap_update_bits_base')):
            body = code.instructions(name)
            direct = {int(args,16) for _, op, args in body if op in ('b','bl')}
            require(code.names[api] in direct, name + ' must access the register map')
            require(any(op == 'add' and args.endswith(', #142') for _,op,args in body),
                    name + ' must use base+0x8e')
            require(any(op == 'mov' and args.endswith(', #-19') for _,op,args in body),
                    name + ' ENODEV path')
            require(any(op in ('cbz','cbnz') for _,op,_ in body), name + ' missing conditional path')
            if name.endswith('_set'):
                require(any(op == 'cmp' and args in ('w1, #127', 'w1, #128') for _,op,args in body) and
                        any(op in ('b.gt','b.ge','b.lt','b.le') for _,op,_ in body),
                        'Setter must check the signed mask range')
            else:
                require(any(op == 'and' and args.count(', w') == 2 for _,op,args in body),
                        'Getter must mask the register value')
    return {'register_offset': 142, 'read_backend': 'regmap_read', 'write_backend': 'regmap_update_bits_base'}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('boot','image','map','symvers','compiler','report'):
        p.add_argument(key,type=Path)
    a=p.parse_args()
    require(sha(a.boot) == BOOT, 'Unexpected stock boot image')
    raw=a.boot.read_bytes()
    stock=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    rows=stock_symbols(stock)
    crcs=stock_crcs(stock,{n:o for o,_,n in rows})
    require(read_crcs(a.symvers) == crcs, 'PMIC export CRC differs from Stock')
    ref=access(stock,rows,a.compiler)
    candidate=a.image.read_bytes()
    mapped=mapped_symbols(a.map)
    names = {n for _,_,n in mapped}
    require(all('__ksymtab_' + n in names for n in ENTRIES), 'Missing linked export')
    require('ufs_ffu' not in names, 'Unexpected active firmware updater in this repair')
    require(access(candidate,mapped,a.compiler) == ref, 'PMIC image comparison')
    a.report.write_text(json.dumps({'crcs':crcs, **ref, 'active_ufs_updater':False},indent=2)+'\n')
    print('PASS Stock and linked candidate PMIC operations and CRCs', crcs)

if __name__ == '__main__':
    main()
