// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
typedef unsigned int uint;
struct qpnp_pon { uint16_t base; };
static struct qpnp_pon hardware = { .base = 0x4100 };
static struct qpnp_pon *sys_reset_dev;
static unsigned reg, reads, writes;
static int bus_error;

static int qpnp_pon_read(struct qpnp_pon *pon, uint16_t addr, unsigned *value)
{
    assert(pon == &hardware && addr == 0x418e);
    ++reads;
    if (bus_error)
        return bus_error;
    *value = reg;
    return 0;
}

static int qpnp_pon_masked_write(struct qpnp_pon *pon, uint16_t addr,
                                 uint8_t mask, uint8_t value)
{
    assert(pon == &hardware && addr == 0x418e);
    ++writes;
    if (bus_error)
        return bus_error;
    reg = (reg & ~mask) | (value & mask);
    return 0;
}

#define EXPORT_SYMBOL(name)
#include "entries.inc"

int main(void)
{
    assert(qpnp_pon_uvlo_get(64) == -ENODEV);
    assert(qpnp_pon_uvlo_set(64, 64) == -ENODEV);
    assert(!reads && !writes);
    sys_reset_dev = &hardware;
    for (int mask = 128; mask <= 255; ++mask)
        assert(qpnp_pon_uvlo_set(255, mask) == -ENODEV);
    assert(!writes);
    for (unsigned initial = 0; initial < 256; ++initial) {
        for (unsigned mask = 0; mask < 128; ++mask) {
            for (unsigned value = 0; value < 256; ++value) {
                reg = initial;
                assert(qpnp_pon_uvlo_set(value, mask) == 0);
                assert(reg == ((initial & ~mask) | (value & mask)));
                assert(qpnp_pon_uvlo_get(mask) == (int)(value & mask));
            }
        }
    }
    assert(writes == 8388608 && reads == writes);
    reg = 0xb5;
    bus_error = -EIO;
    assert(qpnp_pon_uvlo_get(0x40) == -EIO);
    assert(qpnp_pon_uvlo_set(0x40, 0x40) == -EIO && reg == 0xb5);
    puts("PASS 8388608 register/mask/value combinations, both absent-device paths, rejected masks and bus errors");
}
