// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t u32;
#define PAGE_SHIFT 12
#define PAGE_SIZE (1UL << PAGE_SHIFT)
#define BIT(n) (1UL << (n))
#define BITS_PER_LONG (sizeof(unsigned long) * 8)
#define BUILD_BUG_ON(c) _Static_assert(!(c), #c)
#define GFP_KERNEL 0
#define kstrndup(p, n, g) strndup(p, n)
#define kfree(p) free(p)
#define scnprintf snprintf
#define min_t(t, a, b) ((t)(a) < (t)(b) ? (t)(a) : (t)(b))
#define READ_ONCE(x) __atomic_load_n(&(x), __ATOMIC_RELAXED)
#define WRITE_ONCE(x, v) __atomic_store_n(&(x), (v), __ATOMIC_RELAXED)
#define atomic64_inc(p) (++*(p))
#define atomic64_dec(p) (--*(p))
#define cond_resched() ((void)0)
struct slot {
	unsigned long flags;
	pthread_mutex_t lock;
};
struct zram {
	struct slot table[8];
	unsigned long disksize;
	pthread_rwlock_t init_lock;
	struct {
		long low_pages;
	} stats;
};
struct device {
	struct zram *z;
};
struct device_attribute {
	int unused;
};
#define dev_to_zram(d) ((d)->z)
#define init_done(z) ((z)->disksize)
#define down_read(m) assert(!pthread_rwlock_rdlock(m))
#define up_read(m) assert(!pthread_rwlock_unlock(m))
#define zram_slot_lock(z, i) assert(!pthread_mutex_lock(&(z)->table[i].lock))
#define zram_slot_unlock(z, i)                                                 \
	assert(!pthread_mutex_unlock(&(z)->table[i].lock))
static bool sysfs_streq(const char *input, const char *want)
{
	size_t n = strlen(want);
	return !strncmp(input, want, n) &&
	       (!input[n] || !strcmp(input + n, "\n"));
}
static char *strim(char *s)
{
	while (isspace((unsigned char)*s))
		s++;
	size_t len = strlen(s);
	while (len && isspace((unsigned char)s[len - 1]))
		s[--len] = 0;
	return s;
}
static int kstrtoul(const char *s, int base, unsigned long *out)
{
	if (!s || !*s || *s == '-' || isspace((unsigned char)*s))
		return -EINVAL;
	char *end;
	errno = 0;
	unsigned long val = strtoul(s, &end, base);
	if (errno || end == s || (*end && strcmp(end, "\n")))
		return -EINVAL;
	*out = val;
	return 0;
}
static int kstrtouint(const char *s, int base, unsigned *out)
{
	unsigned long val;
	if (kstrtoul(s, base, &val) || val > UINT_MAX)
		return -EINVAL;
	*out = val;
	return 0;
}
#include "driver.inc"
static struct zram z = { .init_lock = PTHREAD_RWLOCK_INITIALIZER };
static struct device dev = { .z = &z };
static void *exercise(void *arg)
{
	char buf[PAGE_SIZE];
	for (unsigned int i = 0; i < 800; i++) {
		switch ((uintptr_t)arg) {
		case 0:
			assert(idle_store(&dev, NULL, "all", 3) == 3);
			break;
		case 1:
			assert(new_store(&dev, NULL, "all", 3) == 3);
			break;
		default:
			assert(idle_stat_show(&dev, NULL, buf) > 0);
			break;
		}
	}
	return NULL;
}
int main(void)
{
	char buf[PAGE_SIZE];
	unsigned long limit;
	unsigned int age;
	assert(low_compress_ratio_show(&dev, NULL, buf) == 3 &&
	       !strcmp(buf, "75\n"));
	assert(low_compress_ratio_store(&dev, NULL, "bad", 3) == -EINVAL);
	for (unsigned int threshold = 0; threshold <= 102; threshold++)
		for (unsigned int size = 0; size <= PAGE_SIZE; size++)
			assert(zram_below_ratio(size, threshold) ==
			       (((4096 - size) * 100 / 4096) < threshold));
	assert(idle_store(&dev, NULL, "all", 3) == -EINVAL &&
	       new_stat_show(&dev, NULL, buf) == -EINVAL);
	z.disksize = 8 * PAGE_SIZE;
	for (unsigned int i = 0; i < 8; i++)
		assert(!pthread_mutex_init(&z.table[i].lock, NULL));
	const unsigned sizes[] = { 1024, 1025, 4096, 4095, 2400, 3300, 0, 17 };
	for (unsigned int i = 0; i < 8; i++) {
		z.table[i].flags = sizes[i];
		if (sizes[i])
			classify(&z, i, sizes[i]);
	}
	assert(z.stats.low_pages == 5);
	zram_set_flag(&z, 2, ZRAM_HUGE);
	zram_set_flag(&z, 3, ZRAM_WB);
	zram_set_flag(&z, 4, ZRAM_UNDER_WB);
	zram_set_flag(&z, 6, ZRAM_SAME);
	assert(new_stat_show(&dev, NULL, buf) > 0 && !strcmp(buf, "3\n"));
	assert(new_store(&dev, NULL, "zero", 4) == -EINVAL);
	assert(low_compress_ratio_store(&dev, NULL, "0", 1) == 1);
	assert(z.stats.low_pages == 5 && !zram_below_ratio(4096, 0));
	assert(low_compress_ratio_store(&dev, NULL, "4294967295", 10) == 10);
	assert(zram_below_ratio(1, low_compress_ratio));
	assert(low_compress_ratio_store(&dev, NULL, "75\n", 3) == 3);
	for (unsigned int i = 0; i < 15; i++)
		assert(idle_store(&dev, NULL, "all\n", 4) == 4);
	assert(idle_stat_show(&dev, NULL, buf) > 0 &&
	       !strcmp(buf, "0 0 0 0 0 0 0 0 0 3\n"));
	assert(!zram_wb_eligible(&z, 0, IDLE_WRITEBACK, 0));
	assert(zram_wb_eligible(&z, 2, HUGE_WRITEBACK, 0));
	assert(zram_wb_eligible(&z, 1, IDLE_WRITEBACK, 10));
	assert(!zram_wb_eligible(&z, 1, HUGE_WRITEBACK, 0));
	assert(!zram_wb_eligible(&z, 3, IDLE_WRITEBACK, 0) &&
	       !zram_wb_eligible(&z, 4, IDLE_WRITEBACK, 0));
	zram_clear_idle(&z, 1);
	assert(!zram_wb_eligible(&z, 1, IDLE_WRITEBACK, 1) &&
	       zram_get_obj_size(&z, 1) == 1025);
	assert(new_stat_show(&dev, NULL, buf) > 0 && !strcmp(buf, "1\n"));
	discard(&z, 5);
	assert(z.stats.low_pages == 4 && !zram_low_page(&z, 5));
	assert(new_store(&dev, NULL, "all", 3) == 3 &&
	       zram_test_flag(&z, 2, ZRAM_HUGE));
	assert(new_stat_show(&dev, NULL, buf) > 0 && !strcmp(buf, "2\n"));
	assert(zram_wb_options("idle", 4, &limit, &age) == IDLE_WRITEBACK &&
	       limit == ULONG_MAX && age == 1);
	assert(zram_wb_options("idle 0 0", 8, &limit, &age) == IDLE_WRITEBACK &&
	       !limit && !age);
	assert(zram_wb_options("idle 23 999\n", 12, &limit, &age) ==
		       IDLE_WRITEBACK &&
	       limit == 23 && age == 10);
	assert(zram_wb_options("huge", 4, &limit, &age) == HUGE_WRITEBACK);
	assert(zram_wb_options("idle 1 2 3", 10, &limit, &age) == -EINVAL);
	pthread_t threads[3];
	for (uintptr_t i = 0; i < 3; i++)
		assert(!pthread_create(&threads[i], NULL, exercise, (void *)i));
	for (int i = 0; i < 3; i++)
		assert(!pthread_join(threads[i], NULL));
	assert(zram_idle_age(&z, 1) <= 10 && zram_get_obj_size(&z, 1) == 1025);
	puts("PASS 421991 size/threshold combinations, nine mm_stat fields wired, age classes 0..10, new/idle, writeback selection, concurrent marking and inspection");
	return 0;
}
