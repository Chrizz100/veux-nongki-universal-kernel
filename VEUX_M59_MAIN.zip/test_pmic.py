"""Compile the patched PMIC entry points with a simulated register interface."""
from pathlib import Path
import argparse
import re
import subprocess
import tempfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('source', type=Path)
args = p.parse_args()
driver = (args.source / 'drivers/input/misc/qpnp-power-on.c').read_text()
register, = re.findall(r'^#define QPNP_PON_XVDD_RB_SPARE\(pon\).*$', driver, re.M)
start = driver.index('int qpnp_pon_uvlo_get(int mask)')
end = driver.index('EXPORT_SYMBOL(qpnp_pon_uvlo_set);', start)
with tempfile.TemporaryDirectory() as workspace:
    tmp = Path(workspace)
    (tmp / 'entries.inc').write_text(register + '\n' + driver[start:end])
    exe = tmp / 'pmic-test'
    subprocess.run(['cc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Werror', '-I', tmp,
                    Path(__file__).with_suffix('.c'), '-o', exe], check=True)
    subprocess.run([exe], check=True)
