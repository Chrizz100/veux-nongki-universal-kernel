"""Compile the kernel's sysfs and slot functions in a userspace fixture."""
import re
import subprocess
import sys
import tempfile
from pathlib import Path

zram = Path(sys.argv[1]) / 'drivers/block/zram'
source = (zram / 'zram_drv.c').read_text()
header = (zram / 'zram_drv.h').read_text()


def function(name):
    start = re.search(r'^static [^{;]+?\b' + name + r'\([^;{]*\)\n\{', source, re.M)
    if not start:
        raise ValueError(name)
    return source[start.start():source.index('\n}', start.end()) + 2]


names = ['zram_get_obj_size', 'zram_test_flag', 'zram_set_flag', 'zram_clear_flag',
         'zram_idle_age', 'zram_clear_idle', 'zram_low_page', 'zram_below_ratio',
         'zram_age_page', 'zram_mark_slots', 'idle_store', 'new_store', 'zram_age_stat',
         'idle_stat_show', 'new_stat_show', 'low_compress_ratio_show', 'low_compress_ratio_store',
         'zram_wb_options', 'zram_wb_eligible']
constants = ['ZRAM_FLAG_SHIFT', 'ZRAM_AGE_SHIFT', 'ZRAM_MAX_AGE']
parts = [re.search('^#define '+n+' .*$', header, re.M)[0] for n in constants]
parts.append(re.search(r'enum zram_pageflags \{.*?\};', header, re.S)[0])
parts.append(re.search(r'static unsigned int low_compress_ratio = \d+;', source)[0])
parts.extend(re.search('^#define ' + name + ' .*$', source, re.M)[0]
             for name in ('HUGE_WRITEBACK', 'IDLE_WRITEBACK'))
parts.extend(map(function, names))
writer = function('__zram_bvec_write')
hook = writer.index('if (zram_below_ratio')
parts.append('static void classify(struct zram *zram,u32 index,unsigned int comp_len) {\n' +
             writer[hook:writer.index('\n\t\t}',hook)+4] + '\n}')
free = function('zram_free_page')
hook = free.index('zram_clear_idle(')
parts.append('static void discard(struct zram *zram,u32 index) {\n' +
             free[hook:free.index('\n\t}',hook)+3] + '\n}')
# Check linkage to the enclosing I/O functions as well as the extracted helpers.
for f, expected in [('zram_accessed','zram_clear_idle(zram, index);'),
                    ('writeback_store','zram_wb_eligible(zram, index, mode, min_age)'),
                    ('writeback_store','index < nr_pages && written < limit'),
                    ('writeback_store','written++;'), ('mm_stat_show','zram->stats.low_pages')]:
    if expected not in function(f):
        raise ValueError('Missing driver wiring in '+f)
with tempfile.TemporaryDirectory() as td:
    work = Path(td)
    (work/'driver.inc').write_text('\n\n'.join(parts) + '\n')
    subprocess.run(['gcc','-std=gnu11','-Wall','-Werror','-pthread','-O2',
                    '-fsanitize=undefined','-fno-sanitize-recover=all','-I',work,
                    Path(__file__).with_name('test_stock_zram.c'),'-o',work/'test'], check=True)
    subprocess.run([work/'test'],check=True)
