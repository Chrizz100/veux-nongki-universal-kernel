// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint32_t u32;
typedef unsigned long long u64;
typedef int64_t s64;
typedef int64_t ktime_t;
typedef _Atomic(s64) atomic64_t;
struct rcu_head {
	int unused;
};
struct zram_pages_life;
struct zram_table_entry {
	ktime_t ac_time;
};
struct zcomp {
	int unused;
};
struct zram {
	u64 disksize, limit_pages;
	struct zcomp *comp;
	struct {
		int counter;
	} stats;
	pthread_rwlock_t init_lock;
	pthread_mutex_t sample_lock;
	_Atomic(struct zram_pages_life *) pages_life;
	struct zram_table_entry table[8];
	s64 first_sample;
	atomic64_t sample_time, avg_pages, origin_pages_max, wb_pages_max;
	bool resetting;
};
struct device {
	struct zram *z;
};
struct device_attribute {
	int unused;
};
#define dev_to_zram(d) ((d)->z)
#define init_done(z) ((z)->disksize != 0)
#define PAGE_SIZE 4096
#define NSEC_PER_SEC 1000000000UL
#define NSEC_PER_MSEC 1000000L
#define GFP_KERNEL 0
#define __rcu
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define struct_size(p, member, n) (sizeof(*(p)) + (n) * sizeof(*(p)->member))
static atomic_int fail_alloc;
static void *kzalloc(size_t n, int flags)
{
	return atomic_exchange(&fail_alloc, 0) ? NULL : calloc(1, n);
}
#define kfree(p) free(p)
#define kstrndup(buf, n, gfp) strndup(buf, n)
#define atomic64_read(x) atomic_load(x)
#define atomic64_set(x, n) atomic_store(x, n)
#define atomic64_inc(x) ((void)atomic_fetch_add(x, 1))
static s64 atomic64_cmpxchg(atomic64_t *a, s64 old, s64 newval)
{
	atomic_compare_exchange_strong(a, &old, newval);
	return old;
}
#define fls64(v) (64 - __builtin_clzll(v))
#define check_mul_overflow(a, b, out) __builtin_mul_overflow((a), (b), (out))
#define div64_u64(a, b) ((a) / (b))
#define div_u64(a, b) ((a) / (b))
static _Thread_local ktime_t clock_ns;
#define ktime_get_boottime() clock_ns
#define spin_lock_irqsave(m, f)                                                \
	do {                                                                   \
		(f) = 0;                                                       \
		assert(!pthread_mutex_lock(m));                                \
	} while (0)
#define spin_unlock_irqrestore(m, f)                                           \
	do {                                                                   \
		(void)(f);                                                     \
		assert(!pthread_mutex_unlock(m));                              \
	} while (0)
static pthread_rwlock_t rcu = PTHREAD_RWLOCK_INITIALIZER;
#define rcu_read_lock() assert(!pthread_rwlock_rdlock(&rcu))
#define rcu_read_unlock() assert(!pthread_rwlock_unlock(&rcu))
#define rcu_dereference(p) atomic_load(&(p))
#define rcu_dereference_protected(p, c) atomic_load(&(p))
#define rcu_assign_pointer(p, newp) atomic_store(&(p), (newp))
#define kfree_rcu(p, member)                                                   \
	do {                                                                   \
		assert(!pthread_rwlock_wrlock(&rcu));                          \
		free(p);                                                       \
		assert(!pthread_rwlock_unlock(&rcu));                          \
	} while (0)
#define down_read(m) assert(!pthread_rwlock_rdlock(m))
#define up_read(m) assert(!pthread_rwlock_unlock(m))
#define down_write(m) assert(!pthread_rwlock_wrlock(m))
#define up_write(m) assert(!pthread_rwlock_unlock(m))
#define scnprintf snprintf
#define pr_warn_ratelimited(...) ((void)0)
#define DEVICE_ATTR_RO(n) int attr_##n __attribute__((unused))
#define DEVICE_ATTR_RW(n) int attr_##n __attribute__((unused))
static int kstrtouint(const char *s, int base, unsigned *v)
{
	char *end;
	if (!s || !*s || *s == '-')
		return -EINVAL;
	errno = 0;
	unsigned long x = strtoul(s, &end, base);
	if (errno || *end || x > UINT_MAX)
		return -EINVAL;
	*v = x;
	return 0;
}
#define set_capacity(d, n) ((void)0)
#define part_stat_set_all(d, n) ((void)0)
#define zcomp_destroy(p) ((void)(p))
#define reset_bdev(z) ((void)0)
#define zram_clear_flag(z, i, f) ((void)0)
static int teardowns;
static void zram_meta_free(struct zram *z, u64 size)
{
	assert(z->resetting && !z->disksize && !z->pages_life && size);
	teardowns++;
}
#define zram_clear_idle(z,i) ((void)0)
#include "driver.inc"
static struct zram z = { .init_lock = PTHREAD_RWLOCK_INITIALIZER,
			 .sample_lock = PTHREAD_MUTEX_INITIALIZER };
static struct device dev = { .z = &z };
static ssize_t put(const char *s)
{
	return time_list_store(&dev, NULL, s, strlen(s));
}
static void event(int index, int seconds)
{
	z.table[index].ac_time = 1;
	clock_ns = 1 + (s64)seconds * NSEC_PER_SEC;
	zram_accessed(&z, index);
	assert(z.table[index].ac_time == clock_ns);
}
static void *record(void *arg)
{
	int idx = (int)(intptr_t)arg;
	for (int i = 0; i < 8000; i++) {
		event(idx, 2);
		zram_update_peak(&z.origin_pages_max, idx * 8000 + i);
	}
	return NULL;
}
static void *replace(void *unused)
{
	for (int i = 0; i < 150; i++)
		assert(put("2 2 4") == 5);
	return NULL;
}
int main(void)
{
	char buf[PAGE_SIZE];
	unsigned long long counts[6];
	assert(pages_life_show(&dev, NULL, buf) == -EINVAL &&
	       put("1 3") == -EINVAL);
	z.disksize = 4096;
	fail_alloc = 1;
	init_stats(&z);
	assert(!z.pages_life);
	init_stats(&z);
	assert(time_list_show(&dev, NULL, buf) > 0 &&
	       !strcmp(buf, "60\t120\t180\t300\t600\t>600\n"));
	zram_life_access(&z, 0, 1);
	for (int i = 0; i < 5; i++)
		event(0, default_time_list[i]);
	event(0, 601);
	assert(pages_life_show(&dev, NULL, buf) > 0);
	assert(sscanf(strchr(buf, '\n') + 1, "%llu%llu%llu%llu%llu%llu",
		      &counts[0], &counts[1], &counts[2], &counts[3],
		      &counts[4], &counts[5]) == 6);
	for (int i = 0; i < 6; i++)
		assert(counts[i] == 1);
	struct zram_pages_life *old = z.pages_life;
	const char *bad[] = {
		"",	 "-1",	  "1",	  "999999 4", "2 2 2",
		"2 3 2", "1 3 4", "1 -1", "0 7",      "1 999999999999"
	};
	for (unsigned i = 0; i < ARRAY_SIZE(bad); i++)
		assert(put(bad[i]) == -EINVAL && old == z.pages_life);
	assert(put("0\n") == 2 && old == z.pages_life);
	fail_alloc = 1;
	assert(put("1 2") == -ENOMEM && old == z.pages_life);
	assert(put("2\t2 4\n") == 6);
	pthread_t workers[8], writer;
	for (int i = 0; i < 8; i++)
		assert(!pthread_create(&workers[i], NULL, record,
				       (void *)(intptr_t)i));
	for (int i = 0; i < 8; i++)
		assert(!pthread_join(workers[i], NULL));
	assert(atomic_load(&atomic_load(&z.pages_life)->bins[0].hits) == 64000);
	assert(origin_pages_max_show(&dev, NULL, buf) > 0 &&
	       strtol(buf, NULL, 10) == 63999);
	assert(!pthread_create(&writer, NULL, replace, NULL));
	for (int i = 0; i < 8; i++)
		assert(!pthread_create(&workers[i], NULL, record,
				       (void *)(intptr_t)i));
	for (int i = 0; i < 8; i++)
		assert(!pthread_join(workers[i], NULL));
	assert(!pthread_join(writer, NULL));
#ifdef CONFIG_ZRAM_WRITEBACK
	zram_update_peak(&z.wb_pages_max, 7);
	zram_update_peak(&z.wb_pages_max, 3);
	assert(wb_pages_max_show(&dev, NULL, buf) > 0 &&
	       strtol(buf, NULL, 10) == 7);
#endif
	clock_ns = 1;
	zram_sample_pages(&z, 10);
	clock_ns += 200 * NSEC_PER_MSEC;
	zram_sample_pages(&z, 30);
	assert(z.avg_pages == 10);
	clock_ns += NSEC_PER_MSEC;
	zram_sample_pages(&z, 30);
	assert(z.avg_pages == 30);
	clock_ns += 201 * NSEC_PER_MSEC;
	zram_sample_pages(&z, 9);
	assert(z.avg_pages == 19);
	assert(avg_size_show(&dev, NULL, buf) > 0 &&
	       strtol(buf, NULL, 10) == 19);
	clock_ns -= 2 * NSEC_PER_SEC;
	zram_sample_pages(&z, 77);
	assert(z.avg_pages == 19 && z.sample_time > clock_ns);
	u64 seed = 17;
	for (int i = 0; i < 20000; i++) {
		seed = seed * 6364136223846793005ULL + 1;
		u64 pages = seed >> 33;
		seed = seed * 6364136223846793005ULL + 1;
		u64 total = (seed >> 1) | 1;
		seed = seed * 6364136223846793005ULL + 1;
		u64 weight = seed % total;
		assert(zram_weighted_pages(pages, weight, total) ==
		       (u64)(((unsigned __int128)pages * weight) / total));
	}
	zram_reset_device(&z);
	assert(teardowns == 1 && !z.resetting && !z.pages_life &&
	       !z.avg_pages && !z.origin_pages_max);
	assert(!z.sample_time && !z.wb_pages_max &&
	       pages_life_show(&dev, NULL, buf) == -EINVAL);
	assert(put("1 3") == -EINVAL);
	zram_reset_device(&z);
	assert(teardowns == 1);
	z.disksize = 4096;
	init_stats(&z);
	clock_ns = 1;
	zram_sample_pages(&z, 5);
	assert(z.avg_pages == 5 && zram_life_show(&z, buf, true) > 0 &&
	       strstr(buf, "0\t0\t0\t0\t0\t0\n"));
	zram_reset_device(&z);
	assert(teardowns == 2);
	puts("PASS five default limits, overflow bucket, atomic counts, 64000 accesses, concurrent replacement, peaks, 200/201 ms and 20000 weighted averages, reset and reinitialization");
	return 0;
}
