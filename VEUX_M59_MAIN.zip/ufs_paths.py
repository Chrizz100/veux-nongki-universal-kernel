"""Verify the UFS control-flow landmarks for the pinned Xiaomi 5.4.274 build."""
import argparse
import json
import struct
import tempfile
from pathlib import Path
from check import BOOT, require, sha
from memory_image import Code, stock_symbols

def inspect(code, symbols):
    # Instruction addresses are offsets within the specific, SHA-pinned stock Image.
    functions = ('sd_probe', 'rescan_partitions', 'get_info_of_partition',
                 'early_parse_off_charge_flag', 'ufs_ffu')
    operations = {pc:(op,arg) for name in functions for pc,op,arg in code.instructions(name)}
    def instruction(pc, op, arg):
        require(operations.get(pc) == (op, arg), 'Unexpected stock instruction at ' + hex(pc))
    targets = {n:a for a,k,n in symbols if k.lower() in ('t','w')}
    def call(pc, name):
        instruction(pc, 'bl', hex(targets[name]))
    def literal(pc, reg, value):
        op,args = operations[pc]
        require(op == 'adrp' and args.split(', ')[0] == reg, 'Expected page for '+value)
        page=int(args.split(', ')[1],16)
        op,args=operations[pc+4]
        fields=args.split(', ')
        require(op == 'add' and fields[:2] == [reg,reg] and fields[2].startswith('#'), 'Expected literal')
        addr=page+int(fields[2][1:],0)
        require(code.image.startswith(value.encode()+b'\0',addr), 'Expected '+value)

    call(0x71c678, 'get_info_of_partition')
    call(0xa8bf38, 'strncmp')
    instruction(0xa8bf3c, 'cmp','w22, #8')
    require(code.image.startswith(b'sda\0',0x1d86000+3415), 'Stock partition disk')
    instruction(0xa8bf20,'adrp','x1, 0x1d86000')
    instruction(0xa8bf28,'add','x1, x1, #3415')
    instruction(0xa8e3d0,'ldr','x8, [x19, #136]')
    instruction(0xa8e3d4,'cbz','x8, 0xa8e424')
    call(0xa8e434, 'ufs_ffu')
    literal(0x254c8cc,'x1','charger')
    call(0x254c8d4, 'strcmp')
    instruction(0x254c8e4,'strb','w8, [x9, #3537]')
    instruction(0xa8bfbc,'ldrb','w8, [x9, #3537]')
    instruction(0xa8bfd0,'b.ne','0xa8bfe8')
    instruction(0xa8c010,'cbnz','w9, 0xa8c090')
    literal(0xa8c02c,'x21','ufshcd')
    call(0xa8c048,'strncmp')
    instruction(0xa8c118,'mov','w0, #64')
    call(0xa8c11c,'qpnp_pon_uvlo_get')
    instruction(0xa8c120,'cbz','w0, 0xa8c14c')
    instruction(0xa8c130,'mov','w1, #64')
    instruction(0xa8c134,'mov','w0, wzr')
    call(0xa8c138,'qpnp_pon_uvlo_set')
    instruction(0xa8c13c,'b','0xa8c050')
    instruction(0xa8c190,'mov','w3, #4096')
    call(0xa8c19c,'ufs_read')
    literal(0xa8c1b4,'x1','ffu')
    for pc,branch,target in [(0xa8c2d4,'cbnz','0xa8c368'), (0xa8c2f4,'cbnz','0xa8c368'),
                             (0xa8c334,'cbz','0xa8c3b8')]:
        call(pc,'strncmp')
        instruction(pc+4,branch,'w0, '+target)
    call(0xa8c3dc,'qpnp_pon_uvlo_set')
    for pc in (0xa8c7cc,0xa8c834):
        call(pc,'ufs_scsi_write_buf')
    for pc in (0xa8c898,0xa8caec):
        call(pc,'machine_restart')
    return {'scsi_probe_lun':0, 'host':'ufshcd', 'skip_charger_mode':True,
            'one_time_entry':True, 'skip_and_clear_prior_error_mask':'0x40',
            'inquiry_fields':['vendor','product','revision'], 'partition':'sda8',
            'partition_header_bytes':4096, 'callsites':{
                'rescan_to_partition':'0x71c678','probe_to_ffu':'0xa8e434',
                'vendor_product_from':['0xa8c2d4','0xa8c2f4','0xa8c334'],
                'firmware_write':['0xa8c7cc','0xa8c834'],'restart':['0xa8c898','0xa8caec']}}

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('boot','compiler','output'):
        p.add_argument(key,type=Path)
    a=p.parse_args()
    require(sha(a.boot)==BOOT, 'Unexpected boot.img')
    raw=a.boot.read_bytes()
    image=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    with tempfile.TemporaryDirectory() as work:
        symbols=stock_symbols(image)
        report=inspect(Code(image,symbols,a.compiler,Path(work)),symbols)
    a.output.write_text(json.dumps(report,indent=2)+'\n')
    print('PASS partition, LUN, boot mode, prior failure, rule match and conditional firmware path')
