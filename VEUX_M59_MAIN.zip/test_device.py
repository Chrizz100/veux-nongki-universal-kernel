"""Exercise the read-only metadata parser with regular files and the production shell code."""
import json
import struct
import subprocess
import tempfile
from pathlib import Path
from config_proof import require

script = Path(__file__).with_name('VEUX_M59_UFS_Lesen.sh')
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp)/'header'
    def run(data, *lines):
        path.write_bytes(data)
        result=subprocess.check_output(['sh', script, '--header-file', path], text=True)
        require(result.splitlines() == list(lines), result)
    data=bytearray(4096)
    run(data[:20], 'partitionstabelle=unvollstaendig')
    run(data, 'partitionstabelle=kein_ffu_header')
    data[:4]=b'ffu\0'
    run(data, 'zusaetzliche_regeln=0', 'partitionstabelle=kopf_gelesen')
    struct.pack_into('<I',data,32,16)
    run(data, 'zusaetzliche_regeln=16', 'partitionstabelle=anzahl_ausserhalb_des_headers')
    struct.pack_into('<I',data,32,15)
    for i in range(1,16):
        struct.pack_into('<9s17s5s5s',data,i*256,b'MICRON',b'MT128GAXAU2U227X',b'0101',b'0102')
    def rows():
        return [f'regel_{i}=MICRON|MT128GAXAU2U227X|0101|0102' for i in range(1,16)]
    run(data,'zusaetzliche_regeln=15',*rows(),'partitionstabelle=kopf_gelesen')
    for offset,length in ((0,9),(9,17),(26,5),(31,5)):
        damaged=data.copy()
        damaged[256+offset:256+offset+length]=b'X'*length
        expected=rows();expected[0]='regel_1=unlesbar'
        run(damaged,'zusaetzliche_regeln=15',*expected,'partitionstabelle=kopf_gelesen')
print('PASS header length, magic, rule-count limits, slot offsets and invalid fields')

def fixed(vendor,model,rev):
    return subprocess.check_output(['sh',script,'--identity',vendor,model,rev],text=True).strip()

receipt=json.loads((script.parent/'Nachweise/UFS-Stock.json').read_text())
for rule in receipt['stock_rules']:
    vendor,model,old,new = [rule[k] for k in ('vendor','model','from','to')]
    require(fixed(vendor,model,old)==f'feste_stock_regel=ausgangsrevision_passt_{old}_nach_{new}', model)
    require(fixed(vendor,model,new)=='feste_stock_regel=zielrevision_bereits_vorhanden', model)
    require(fixed(vendor,model,'0000')=='feste_stock_regel=andere_revision', model)
require(fixed('MICRON','unknown','0101')=='feste_stock_regel=kein_modelleintrag','Unknown model')
require(fixed('','unknown','0101')=='feste_stock_regel=identitaet_unvollstaendig','Missing identity')
print('PASS six built-in rules: source, target, other revision, other model and missing identity')
