# VEUX M59 · UFS und das Fehlermerkmal im PMIC

## Stand nach M58

Der GitHub-Job 137276168104 bestand 13 von 13 Schritten. Beide Archive, die SHA-256 der Archivdateien und sämtliche 67 enthaltenen Dateien wurden geprüft. Das GitHub-Image trägt die Kennung `5.4.274-qgki-g82179e362f33` und hat die SHA-256 `404e9222ee355e2202f34f3f9e47418a325cab4965b755a6795ed1a8fecb3300`. Das Archiv enthält 63 Nachweise, der Quellstand weitere vier Dateien. Größen und Prüfsummen stehen in `Nachweise/M58-Artefaktinventar.json`. [GitHub-Job](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45044544477/job/137276168104)

Der frühere lokale M58-Bau und das GitHub-Image haben dieselbe Länge und unterschiedliche SHA-256. Im Image sind unterschiedliche absolute Buildpfade und in den Linker-Karten verschobene Symboladressen sichtbar. M59 übernimmt den geprüften Quellstand aus dem GitHub-Artefakt. Eine bitgleiche Reproduktion über beide Buildumgebungen ist offen.

Im GitHub-Image stimmen alle 26 zRAM-Dateinamen, Zugriffsrechte und angebundenen Lese- und Schreibfunktionen mit Xiaomi überein. Der Test umfasst 421.991 Kombinationen aus Seitengröße und Kompressionsschwelle. Bei 3.148 Importverwendungen aus 37 Xiaomi-Vendormodulen stimmen Anbieter und Versionsprüfsummen. Der Bau erzeugte vier Kernelmodule. Das erneute statische Packen in Xiaomis Boot-Layout ergab 134.217.728 Bytes und den ursprünglichen Ramdisk-Hash. Der praktische Start des Kandidaten auf dem Telefon ist offen.

## Die Änderung in M59

Der Patch ergänzt im vorhandenen Qualcomm-Power-on-Treiber die beiden von Xiaomi exportierten Funktionen `qpnp_pon_uvlo_get` und `qpnp_pon_uvlo_set`. Sie lesen bzw. ändern Bits im PMIC-Register mit Offset 0x8e. Xiaomis UFS-Firmwarepflege verwendet Bit 0x40 als Fehlermerkmal über einen Neustart hinweg. Beide Funktionen fehlten im M58-Image. Ihr Quellcode stammt aus Xiaomis veröffentlichtem VEUX-Treiber. Der Patch fügt keine Aufrufe beim Gerätestart hinzu. Die Testimplementierung verwendet simulierte Registerzugriffe. [Xiaomi-PMIC-Treiber](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/input/misc/qpnp-power-on.c)

Der Hosttest deckt 8.388.608 Kombinationen aus Registerinhalt, zulässiger Byte-Maske und Wert ab, dazu ein fehlendes PMIC-Gerät, abgelehnte Masken und Busfehler. Der Image-Test vergleicht zusätzlich die gelinkten Registerzugriffe, den Fehlerpfad und beide Export-CRCs mit Xiaomis Stock-Image. Die erwarteten CRCs sind `0x88c08f25` für das Lesen und `0x8b546a97` für das Schreiben.

## UFS-Abgleich

Xiaomis Firmwarepflege beginnt im Stock-Kernel über `sd_probe` beim Erkennen der logischen Einheit 0. Der Qualcomm-UFS-Treiber und die Firmwarepflege sind zwei unterschiedliche Bestandteile. Stock prüft vor einem Update unter anderem Lademodus, einmaligen Eintritt, Host, früheren Fehler und Hersteller, Modell und Ausgangsrevision. Der Pfad kann beim passenden Gerät Firmware schreiben und neu starten. Die Partitionssuche registriert `sda8` für zusätzliche gerätespezifische Regeln. Das separat gesicherte `boot_a` gehört zum Rückweg für das Boot-Image. Ein Wechsel des Boot-Images stellt die Firmware des Speicherchips nicht wieder her. [Xiaomi-UFS-Treiber](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/scsi/ufs/ufs_ffu.c)

| Hersteller | Modell | Aktuelle Firmware laut Regel | Ziel |
| --- | --- | --- | --- |
| SKhynix | H9HQ54AECMMDAR | A002 | A043 |
| SKhynix | H9HQ15AECMBDAR | A002 | A043 |
| MICRON | MT128GAXAU2U227X | 0101 | 0102 |
| SKhynix | H9QT0GECN6X145 | A001 | A002 |
| SKhynix | H9QT0G6CN6X146 | A001 | A002 |
| SKhynix | H9QT1G6DN6X132 | A001 | A002 |

Der öffentliche VEUX-Quellstand enthält die ersten fünf Regeln. Die sechste steht im Stock-Image des Builds V816.0.12.0.TKCMIXM. Alle drei unterschiedlichen Firmwareinhalte wurden über aufgelöste ARM64-Relokationen, Größen und SHA-256 mit den drei offiziellen Xiaomi-Dateien verglichen. `Nachweise/UFS-Stock.json` enthält das Ergebnis. Der nächste GitHub-Lauf liest die sechs Regeln und die Firmware-Prüfsummen erneut aus dem Xiaomi-Image.

## GitHub und Telefon

1. `VEUX_M59_MAIN.zip` ins Wurzelverzeichnis des Repos und `VEUX_M59_UFS_PMIC_NOFLASH.yml` nach `.github/workflows/` hochladen. Der Workflow lässt sich manuell starten. Er verwendet den M58-Quellstand aus Run 45044544477 und die bisherige Xiaomi-Referenz. Für einen späteren Neuaufbau werden die beiden im Workflow genannten Eingangsartefakte benötigt.
2. Den separaten Gerätecheck im Downloadordner speichern und in Termux mit `sh ~/storage/downloads/VEUX_M59_UFS_Lesen.sh` aufrufen. Für den Lesezugriff auf die UFS-Geräteinformationen und die ersten 4 KiB von sda8 verwendet er die vorhandene Root-Berechtigung. Er gibt Hersteller, Modell und Revision der beiden SCSI-Einheiten sowie vorhandene Regelkennungen aus. Die Zeile `feste_stock_regel` wertet die Identität der UFS-Geräteeinheit gegen alle sechs eingebauten Regeln aus. Sie bewertet keine Firmwareinhalte aus der Partition. Er fasst keine Firmware oder Bootpartition schreibend an. Eine unlesbare Angabe bleibt offen.
3. Für die weitere UFS-Reparatur die Geräteausgabe mit den Stock-Regeln und gegebenenfalls den zusätzlichen Regeln des Telefons abgleichen. Bei aktiven Partitionsregeln sind auch deren Grenzen und Prüfsummen zu verifizieren. Die Firmwarepflege selbst ist in M59 weiterhin offen. Weiter zu prüfen sind insbesondere Xiaomis Speicherstatistik, Millet und die Treiber- und Dateisystemunterschiede aus den sieben Restgruppen. Die 48 textlichen Konfigurationsunterschiede entsprechen keiner Fehlerzahl.

Der Workflow baut ein neues Image und vier Module und prüft die bisherigen Kernel-, ABI- und statischen Boot-Eigenschaften. Ein Gerätestart des neu gebauten Kernels und seine Funktion unter Last stehen aus. Der vom Nutzer geklärte Rückweg verwendet PC und Fastboot. M59 ist für die Reparaturprüfung vorgesehen. Eine Flash-Freigabe steht aus.

## Lokales Ergebnis

Der Vollbau aus dem authentifizierten M58-Quellarchiv hat Image, vmlinux, VEUX-DTB und vier Module erzeugt. Die nachfolgende Prüfung des gelinkten Images bestand einschließlich beider PMIC-Exporte, aller 26 zRAM-Schnittstellen, der 3.148 Vendor-Importe und des statischen Boot-Layouts. Beide eingebetteten Konfigurationen entsprechen der Kbuild-Konfiguration. Die lokale M59-Image-SHA-256 ist `4c26e18b5083a6bb940d8a7e221ea77ba030feb9ec62281edded2ae9806f4e42`. Getrennte Negativtests erkannten eine geänderte sechste Modellregel, ein manipuliertes Firmwarebyte und eine falsche CRC für jeden der zwei PMIC-Exporte. Der GitHub-Lauf für M59 und der Gerätetest stehen aus.
