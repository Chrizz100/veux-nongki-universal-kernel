"""Verify the shared zRAM threshold and mm_stat format in the linked ARM64 driver."""
import argparse
import json
import re
import struct
import tempfile
from pathlib import Path
from check import BOOT, require, sha
from memory_image import Code, mapped_symbols, stock_symbols

FORMAT = b'%8llu %8llu %8llu %8lu %8ld %8llu %8lu %8llu %8llu\n\0'


def references(code, name):
    """Resolve PC-relative addresses within a basic block, invalidating overwritten registers."""
    registers = {}
    refs = []
    for pc, op, args in code.instructions(name):
        fields = args.split(', ')
        reg = fields[0]
        if op in ('adr', 'adrp'):
            registers[reg] = int(fields[1], 16)
        elif op == 'add' and fields[1] in registers and fields[2].startswith('#'):
            registers[reg] = registers[fields[1]] + int(fields[2][1:], 0)
        elif op in ('ldr', 'ldar', 'str', 'stlr'):
            match = re.fullmatch(r'[wx]\d+, \[(x\d+)(?:, #(\d+))?\]', args)
            if match and match[1] in registers:
                refs.append((op, registers[match[1]] + int(match[2] or 0), pc, reg))
            if op in ('ldr', 'ldar'):
                registers.pop('x' + reg[1:], None)
        elif op == 'bl':
            refs.append(('call', registers.get('x2'), pc, args))
            for i in range(19):
                registers.pop('x' + str(i), None)
        elif op in ('b', 'ret', 'blr'):
            registers.clear()
        elif re.fullmatch('[xw][0-9]+', reg) and op not in ('cmp', 'tst', 'cbz', 'cbnz', 'tbz', 'tbnz', 'stp'):
            registers.pop('x' + reg[1:], None)
    return refs


def classify_path(code, name, pc):
    """Trace the percentage comparison and the conditional setting of the low-compression bit."""
    rows = code.instructions(name)
    start, = [i for i, row in enumerate(rows) if row[0] == pc]
    reg = lambda token: re.sub('^[wx]', 'r', token)
    threshold = reg(rows[start][2].split(',')[0])
    values = {threshold: 'threshold'}
    # Trace the size stored into the low bits of the slot flags immediately before the read.
    window = rows[max(0, start-16):start]
    writes = [(i,args.split(', ')) for i,(_,op,args) in enumerate(window) if op=='orr']
    require(writes, 'Expected the slot size write before classification')
    i, update = writes[-1]
    require(len(update)==3 and any(op=='str' and reg(args.split(', ')[0])==reg(update[0])
                                    for _,op,args in window[i+1:]), 'Size must reach the slot flags')
    values[reg(update[2])] = 'size'
    target = None
    compared = False
    for row, (addr, op, args) in enumerate(rows[start+1:start+20], start+1):
        parts = args.split(', ')
        dst = reg(parts[0])
        if op == 'mov' and len(parts)==2 and parts[1].startswith('#'):
            values[dst] = int(parts[1][1:],0)
        elif op in ('sub','mul') and len(parts)==3:
            left, right = values.get(reg(parts[1])), values.get(reg(parts[2]))
            if op == 'sub' and (left, right)==(4096,'size'):
                values[dst]='saved'
            elif op=='mul' and {left,right}=={'saved',100}:
                values[dst]='scaled'
            else:
                values.pop(dst,None)
        elif op=='cmp':
            compared = (values.get(dst)=='threshold' and values.get(reg(parts[1]))=='scaled' and
                        parts[2:]==['lsr #12'])
        elif op=='b.ls' and compared:
            target = int(args,16)
            break
        elif op in ('ldr','ldur'):
            values.pop(dst,None)
        else:
            raise ValueError('Unexpected threshold calculation '+op+' '+args)
    require(target is not None, 'Expected strict threshold > floor((4096-size)*100/4096)')
    flagged = [(i, args.split(', ')) for i,(addr,op,args) in enumerate(rows)
               if rows[row][0] < addr < target and op=='orr' and args.endswith(', #0x40000')]
    require(len(flagged)==1,'Expected the bit for low compression between comparison and skip target')
    i, result = flagged[0]
    require(any(op=='str' and reg(args.split(', ')[0])==reg(result[0])
                for addr,op,args in rows[i+1:] if addr<target), 'Classification flag not stored')


def proof(image, syms, compiler, work, mode):
    code = Code(image, syms, compiler, work)
    show = references(code, 'low_compress_ratio_show')
    store = references(code, 'low_compress_ratio_store')
    reads = {addr for op, addr, _, reg in show if op in ('ldr', 'ldar') and reg.startswith('w')}
    writes = {addr for op, addr, _, reg in store if op in ('str', 'stlr') and reg.startswith('w')}
    require(len(reads & writes) == 1, 'Ratio show and store must use the same unsigned variable')
    addr, = reads & writes
    default, = struct.unpack_from('<I', image, addr)
    require(default == 75, 'Wrong initial percentage')
    require(any(op == 'bl' and int(args, 16) == code.names['kstrtouint'] for _, op, args in
                code.instructions('low_compress_ratio_store')), 'Missing unsigned threshold parser')
    functions = ['zram_bvec_rw']
    calls = {int(arg, 16) for _, op, arg in code.instructions('zram_bvec_rw') if op in ('bl','b')}
    for name in ('zram_bvec_write', '__zram_bvec_write'):
        if name in code.names and code.names[name] in calls:
            functions.append(name)
            calls.update(int(arg,16) for _,op,arg in code.instructions(name) if op in ('bl','b'))
    locations = [(name,pc) for name in functions for op,a,pc,r in references(code,name)
                 if op in ('ldr', 'ldar') and a == addr and r.startswith('w')]
    require(len(locations) == 1, 'Threshold must be read in the write path')
    require(any(op=='call' and target==hex(code.names['scnprintf']) and a is not None and
                image.startswith(FORMAT, a) for op,a,_,target in references(code, 'mm_stat_show')),
            'Expected nine-field format passed to scnprintf in mm_stat_show')
    classify_path(code, *locations[0])
    return dict(default_saved_percent=default, threshold_used_at_page_write=True,
                shared_with_sysfs=True, strict_saved_percent_comparison=True, mm_stat_fields=9)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['stock','candidate'])
    for arg in ('compiler','image','report'):
        parser.add_argument(arg, type=Path)
    parser.add_argument('--map', type=Path)
    a = parser.parse_args()
    data = a.image.read_bytes()
    if a.mode == 'stock':
        require(sha(a.image)==BOOT, 'Wrong Xiaomi boot.img')
        data = data[4096:4096+struct.unpack_from('<I', data, 8)[0]]
        sym = stock_symbols(data)
    else:
        sym = mapped_symbols(a.map)
    with tempfile.TemporaryDirectory() as tmp:
        result = proof(data, sym, a.compiler, Path(tmp), a.mode)
    a.report.write_text(json.dumps(result,indent=2)+'\n')
    print(a.mode, result)
