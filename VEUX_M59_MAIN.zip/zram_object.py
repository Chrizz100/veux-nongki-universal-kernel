"""Verify the linked zRAM attribute objects for one Kbuild configuration."""
import argparse
import json
import subprocess
from pathlib import Path

from config_proof import config_values, require
from zram_image import MODES

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('mode', choices=['stock-config','no-writeback','no-tracking'])
for argument in ('nm','config','object','result'):
    p.add_argument(argument, type=Path)
a = p.parse_args()
config = config_values(a.config.read_bytes())
tracking = a.mode != 'no-tracking'
writeback = a.mode != 'no-writeback'
require((config.get('CONFIG_MIUI_ZRAM_MEMORY_TRACKING') == 'y') == tracking, 'zRAM tracking variant')
require((config.get('CONFIG_ZRAM_WRITEBACK') == 'y') == writeback, 'zRAM writeback variant')
lines = subprocess.check_output([a.nm, '--defined-only', a.object], text=True).splitlines()
names = {line.split()[-1].split('$')[0].split('.llvm.')[0] for line in lines if line.split()}
require('zram_disk_attrs' in names and 'dev_attr_mm_stat' in names, 'Incomplete zRAM object')
nodes = sorted(n for n in MODES if 'dev_attr_' + n in names)
require(nodes == sorted(n for n in MODES if tracking and (writeback or n != 'wb_pages_max')),
        'Unexpected zRAM attribute set in ' + a.mode + ': ' + repr(nodes))
additional = ['idle_stat', 'low_compress_ratio', 'new', 'new_stat']
require(all('dev_attr_' + n in names for n in additional), 'Incomplete zRAM age and ratio interfaces')
a.result.write_text(json.dumps(dict(variant=a.mode, attributes=nodes, page_state_attributes=additional), indent=2) + '\n')
print(a.mode, nodes)
