#!/system/bin/sh
# SPDX-License-Identifier: GPL-2.0-only
# Only INQUIRY text and rule metadata are printed. All device access is read-only.
set -u
export LC_ALL=C

# Decode the first 4096 bytes only. A partition-supplied rule remains a
# candidate until its payload and the other OEM conditions are checked.
field() {
    bytes=$1
    shift
    result=
    closed=0
    while [ "$bytes" -gt 0 ]; do
        case "$1" in
            0) closed=1; break ;;
            *) if [ "$1" -lt 32 ] || [ "$1" -gt 126 ]; then return 1; fi ;;
        esac
        char=$(printf '%b' "\\$(printf '%03o' "$1")")
        case "$char" in [a-zA-Z0-9._-]|' ') result=$result$char ;; *) return 1 ;; esac
        shift
        bytes=$((bytes - 1))
    done
    [ "$closed" = 1 ] && [ -n "$result" ] && printf '%s' "$result"
}

header() {
    numbers=$(od -An -v -tu1 -N4096 "$1" 2>/dev/null) || {
        echo 'partitionstabelle=unlesbar'; return;
    }
    set -- $numbers
    if [ "$#" -ne 4096 ]; then echo 'partitionstabelle=unvollstaendig'; return; fi
    if [ "$1 $2 $3 $4" != '102 102 117 0' ]; then
        echo 'partitionstabelle=kein_ffu_header'; return
    fi
    shift 32
    count=$(($1 + 256 * $2 + 65536 * $3 + 16777216 * $4))
    printf 'zusaetzliche_regeln=%s\n' "$count"
    if [ "$count" -gt 15 ] || [ "$count" -lt 0 ]; then
        echo 'partitionstabelle=anzahl_ausserhalb_des_headers'; return
    fi
    shift 224
    row=0
    while [ "$row" -lt "$count" ]; do
        row=$((row + 1))
        vendor=$(field 9 "$@") || { echo "regel_$row=unlesbar"; shift 256; continue; }
        shift 9
        model=$(field 17 "$@") || { echo "regel_$row=unlesbar"; shift 247; continue; }
        shift 17
        before=$(field 5 "$@") || { echo "regel_$row=unlesbar"; shift 230; continue; }
        shift 5
        after=$(field 5 "$@") || { echo "regel_$row=unlesbar"; shift 225; continue; }
        printf 'regel_%s=%s|%s|%s|%s\n' "$row" "$vendor" "$model" "$before" "$after"
        shift 225
    done
    echo 'partitionstabelle=kopf_gelesen'
}

value() {
    if [ -r "$1" ]; then
        tr -d '\000\r\n' < "$1" | sed 's/^ *//;s/ *$//'
    fi
}

identity() {
    for name in vendor model rev; do
        val=$(value "$2/$name")
        printf '%s_%s=%s\n' "$1" "$name" "${val:-unbekannt}"
    done
}

fixed_rule() {
    if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]; then
        echo 'feste_stock_regel=identitaet_unvollstaendig'
        return
    fi
    case "$1/$2" in
        SKhynix*/H9HQ54AECMMDAR*|SKhynix*/H9HQ15AECMBDAR*) before=A002; after=A043 ;;
        MICRON*/MT128GAXAU2U227X*) before=0101; after=0102 ;;
        SKhynix*/H9QT0GECN6X145*|SKhynix*/H9QT0G6CN6X146*|SKhynix*/H9QT1G6DN6X132*)
            before=A001; after=A002 ;;
        *) echo 'feste_stock_regel=kein_modelleintrag'; return ;;
    esac
    case "$3" in
        "$before"*) printf 'feste_stock_regel=ausgangsrevision_passt_%s_nach_%s\n' "$before" "$after" ;;
        "$after"*) echo 'feste_stock_regel=zielrevision_bereits_vorhanden' ;;
        *) echo 'feste_stock_regel=andere_revision' ;;
    esac
}

if [ "${1:-}" = '--identity' ]; then
    [ "$#" = 4 ] || exit 2
    fixed_rule "$2" "$3" "$4"
    exit 0
fi

if [ "${1:-}" = '--header-file' ]; then
    [ "$#" = 2 ] && [ -f "$2" ] || exit 2
    header "$2"
    exit 0
fi

if [ "$(id -u)" != 0 ]; then
    exec su -c '/system/bin/sh -s' < "$0"
fi
device=$(getprop ro.product.device)
build=$(getprop ro.build.version.incremental)
printf 'geraet=%s\nbuild=%s\n' "$device" "$build"
[ "$device" = 'veux' ] || { echo 'auswertung=anderes_geraet'; exit 1; }
lun=$(readlink -f /sys/class/block/sda/device) || exit 1
address=${lun##*/}
host=${address%%:*}
case "$host" in ''|*[!0-9]*) echo 'lun0=unbekannt'; exit 1 ;; esac
[ "$address" = "$host:0:0:0" ] || { echo 'lun0=unbekannt'; exit 1; }
controller=$(value "/sys/class/scsi_host/host$host/proc_name")
printf 'scsi_treiber=%s\n' "${controller:-unbekannt}"
[ "$controller" = 'ufshcd' ] || { echo 'auswertung=ufs_host_unbestaetigt'; exit 1; }
identity lun0 "$lun"
ufs_device="/sys/class/scsi_device/$host:0:0:49488/device"
identity ufs_geraet "$ufs_device"
fixed_rule "$(value "$ufs_device/vendor")" "$(value "$ufs_device/model")" "$(value "$ufs_device/rev")"
case "$build" in
    V816.0.12.0.TKCMIXM|OS1.0.12.0.TKCMIXM) ;;
    *) echo 'partitionstabelle=anderer_softwarestand'; exit 0 ;;
esac
part=$(readlink -f /sys/class/block/sda8)
disk=$(readlink -f /sys/class/block/sda)
if [ "${part%/*}" = "$disk" ] && [ "$(value "$part/partition")" = 8 ] && [ -b /dev/block/sda8 ]; then
    header /dev/block/sda8
else
    echo 'partitionstabelle=zuordnung_unbekannt'
fi
