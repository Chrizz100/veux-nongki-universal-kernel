#!/usr/bin/env bash
# P12 R1: targeted WALT=y object-only compile, never emits boot.img, AK3, or install ZIP.
# A failed WALT compiler probe is recorded as diagnosis (not a build pass).
set -Eeuo pipefail
export LC_ALL=C TZ=UTC ARCH=arm64
: "${GITHUB_WORKSPACE:?}" "${RUNNER_TEMP:?}" "${P11_TOOLCHAIN_DIR:?}"
ROOT="$(realpath "$GITHUB_WORKSPACE")"
KERNEL="$ROOT/kernel"
EVIDENCE="$RUNNER_TEMP/VEUX_274_P12_EVIDENCE"
CANDIDATE="$RUNNER_TEMP/VEUX_274_P12_PORT"
OUT="$RUNNER_TEMP/veux-5.4.274-p12-walt-y-out"
mkdir -p "$EVIDENCE/logs"
REPORT="$EVIDENCE/P12_BUILD_STATUS.json"
# Trap builds a machine-readable fail-closed marker in fatal setup/config cases.
fatal_report() {
  rc=$?
  if ((rc != 0)); then
    python3 - "$REPORT" "$rc" <<'PY'
import json,pathlib,sys
p=pathlib.Path(sys.argv[1]);d={'kernel':'5.4.274','phase':'P12_R1',
'probe':'SETUP_OR_GATE_ERROR','exit_code':int(sys.argv[2]),
'walt_on_compilation':'NOT_PROVEN','vendor_abi':'NOT_CHECKED',
'device_test':'NOT_RUN','flashable':False}
p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
PY
  fi
}
trap fatal_report EXIT
[[ -d "$KERNEL/.git" && ! -L "$KERNEL" && -s "$CANDIDATE/P12_PREP_REPORT.json" ]] || exit 2
[[ "$(make -s -C "$KERNEL" kernelversion)" == '5.4.274' ]] || exit 2
[[ ! -e "$OUT" ]] || { echo 'REFUSE_EXISTING_BUILD_OUTPUT' >&2; exit 2; }
[[ -x "$P11_TOOLCHAIN_DIR/bin/clang" ]] || exit 2
export PATH="$P11_TOOLCHAIN_DIR/bin:$PATH"
clang --version | grep -Fq 'r416183b' || exit 2
python3 - "$CANDIDATE/P12_PREP_REPORT.json" "$CANDIDATE/P11_TO_P12_WALT_STRUCTS_ONLY.patch" <<'PY'
import hashlib,json,pathlib,sys
report=json.loads(pathlib.Path(sys.argv[1]).read_text())
p=pathlib.Path(sys.argv[2]); assert p.is_file() and p.stat().st_size < 50_000
assert report['input_tree']=='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
assert report['changed_paths']==['include/linux/sched.h','kernel/sched/sched.h']
assert report['original_xiaomi_walt_file_blobs']=='PRESERVED'
assert report['flashable'] is False
assert hashlib.sha256(p.read_bytes()).hexdigest()==report['candidate_patch_sha256']
PY
[[ "$(git -C "$KERNEL" rev-parse HEAD^{tree})" == '04e3831b70ed3ba19a7bd59e3054b7df5418941d' ]] || exit 2
[[ -z "$(git -C "$KERNEL" status --porcelain --untracked-files=all)" ]] || exit 2
PATCH="$CANDIDATE/P11_TO_P12_WALT_STRUCTS_ONLY.patch"
git -C "$KERNEL" apply --check "$PATCH"
git -C "$KERNEL" apply "$PATCH"
changed="$(git -C "$KERNEL" diff --name-only | LC_ALL=C sort)"
[[ "$changed" == $'include/linux/sched.h\nkernel/sched/sched.h' ]] || { echo 'UNEXPECTED_MUTATION_SET' >&2; exit 2; }
git -C "$KERNEL" diff --check
# An independent check that all 11 OEM files remain intact post patch.
python3 - "$KERNEL" <<'PY'
import pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1])
expected={
'Makefile':'8bf42cb669afabc17f69bc16cf74f17fcaf5cdd0',
'boost.c':'c37185e293d0ac7affe9b13124fcf76339fbce4e',
'core_ctl.c':'af838bd1c71e728d65dcdfee792b1379b07336e5',
'cpu-boost.c':'9b2363cf275afbeadbc57b112e89818d0e019320',
'qc_vas.c':'ce49eac6d5907108ed46aa48b7ead5146b49618e',
'qc_vas.h':'3b67a54946557d92b4582f990e3f015bceb3d0ae',
'sched_avg.c':'4a5efa4118b3c6605d74380ff028d66e9a24668b',
'trace.c':'7c06ce1fda642d026295ec87f190df55176c1cf9',
'trace.h':'5b01043d226142ac380d76f924542719ef863e9e',
'walt.c':'9d851c1dd315e2f4fb2385b5aa4a0c2749908b7d',
'walt.h':'9a678f0bbb68d92aa670991c8899a5253f51322e'}
for f,h in expected.items():
 q=subprocess.check_output(['git','-C',str(root),'hash-object',str(root/'kernel/sched/walt'/f)],text=True).strip()
 assert q==h,(f,q,h)
print('P12_OEM_11_BLOBS_UNCHANGED=PASS')
PY
mkdir -p "$OUT"
export KBUILD_BUILD_USER='veux-stock274' KBUILD_BUILD_HOST='p12-compile-probe'
export KBUILD_BUILD_TIMESTAMP='Thu Sep 03 00:00:00 UTC 2026'
export KBUILD_BUILD_VERSION=1 SOURCE_DATE_EPOCH=1788393600
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 veux_defconfig \
  2>&1 | tee "$EVIDENCE/logs/veux_defconfig.log"
"$KERNEL/scripts/config" --file "$OUT/.config" -e SCHED_WALT
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 olddefconfig \
  2>&1 | tee "$EVIDENCE/logs/olddefconfig.log"
grep -qx 'CONFIG_SCHED_WALT=y' "$OUT/.config" || { echo 'WALT_CANNOT_BE_ENABLED' >&2; exit 2; }
grep -qx 'CONFIG_UCLAMP_TASK_GROUP=y' "$OUT/.config" || { echo 'UCLAMP_GROUP_MISSING' >&2; exit 2; }
! grep -qE '^CONFIG_(KSU|KERNELSU|SUSFS|SCHED_CASS)=y$' "$OUT/.config" || exit 2
cp "$OUT/.config" "$EVIDENCE/veux_5.4.274_walt_y_probe.config"
sha256sum "$OUT/.config" > "$EVIDENCE/logs/config.sha256"
# Not a full kernel build. Failure is expected while porting upstream APIs.
# A completed compile is a targeted-object PASS only, never a release or ABI PASS.
set +e
timeout 1200 make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j3 \
  kernel/sched/core.o kernel/sched/fair.o \
  kernel/sched/cpufreq_schedutil.o kernel/sched/walt/walt.o \
  > "$EVIDENCE/logs/targeted_walt_objects.log" 2>&1
probe_rc=$?
set -e
python3 - "$REPORT" "$probe_rc" "$EVIDENCE/logs/targeted_walt_objects.log" <<'PY'
import json,pathlib,re,sys
p=pathlib.Path(sys.argv[1]);rc=int(sys.argv[2]); log=pathlib.Path(sys.argv[3]).read_text(errors='replace')
# The 124 exit code is timeout, not a valid compiler diagnostic.
kind='TARGETED_OBJECTS_PASS' if rc==0 else 'TARGETED_COMPILE_ERRORS' if rc not in (124,137) else 'PROBE_TIMEOUT_OR_OOM'
errors=[l.strip() for l in log.splitlines() if re.search(r'error:|undefined reference|No rule to make target|fatal error:',l)]
status={'kernel':'5.4.274','phase':'P12_R1',
  'probe':kind,'make_exit_code':rc,'error_excerpt_count':len(errors),
  'error_excerpts':errors[:80],
  'walt_on_target_objects':'PASS' if rc==0 else 'FAILED_OR_INCOMPLETE',
  'walt_on_full_kernel_build':'NOT_RUN',
  'vendor_abi':'NOT_CHECKED','device_test':'NOT_RUN',
  'boot_img':'NOT_CREATED','ak3':'NOT_CREATED','flashable':False}
p.write_text(json.dumps(status,indent=2,sort_keys=True)+'\n')
print('P12_OBJECT_PROBE='+kind+'; ERROR_LINES='+str(len(errors))+'; FLASH=NO')
PY
if ((probe_rc == 124 || probe_rc == 137)); then
  echo 'P12_PROBE_INFRA_TIMEOUT_OR_OOM' >&2; exit 3
fi
if ((probe_rc != 0)); then
  echo 'P12_COMPILER_DIAGNOSTIC_CAPTURED_WALT_NOT_BUILT' >> "$GITHUB_STEP_SUMMARY"
else
  echo 'P12_TARGETED_OBJECT_COMPILE_PASS_BUT_LINK_AND_ABI_UNPROVEN' >> "$GITHUB_STEP_SUMMARY"
fi
# A compiler diagnostic is successful *collection*, not successful compilation.
# This workflow is strictly labelled diagnostic and never starts a release build.
