#!/usr/bin/env python3
"""Local P12 source-transform fault-injection tests; synthetic fixtures only.
These tests cannot substitute for a real P11-tree WALT=y compile.
"""
import pathlib
import tempfile
import unittest
from prepare_p12_walt_structs import (prepare_after, donor_extract, make_patch,
                                      validate_fixture_roundtrip, oid, stage, P12_PATHS)

PUBLIC = '''struct cpu_cycle_counter_cb {
\tu64 (*get_cpu_cycle_counter)(int cpu);
};

#ifdef CONFIG_SCHED_WALT
extern void walt_task_dead(struct task_struct *p);
#define RAVG_HIST_SIZE_MAX 5
struct walt_task_struct {
\tbool\t\t\t\tiowaited;
};
#else
static inline void walt_task_dead(struct task_struct *p) { }
#endif /* CONFIG_SCHED_WALT */

struct sched_rt_entity {
};
'''
PRIVATE = '''struct walt_cpu_load {
  unsigned long nl;
};
#ifdef CONFIG_SCHED_WALT
struct walt_sched_stats { int nr_big_tasks; };
struct walt_task_group { bool colocate; };
struct walt_root_domain { int max_cap_orig_cpu; };
struct walt_rq { unsigned long window_start; };
struct walt_sched_cluster { int id; };
#endif /* CONFIG_SCHED_WALT */

/* task_struct::on_rq states: */
'''
TARGET_PUBLIC = '''#ifndef _LINUX_SCHED_H
#define _LINUX_SCHED_H
struct sched_rt_entity {
};
struct task_struct {
 struct sched_entity se;
\tstruct sched_rt_entity\t\trt;
 struct sched_dl_entity dl;
};
#endif
'''
TARGET_PRIVATE = '''#ifndef _KERNEL_SCHED_H
#define _KERNEL_SCHED_H
struct rq;
struct cpuidle_state;

/* task_struct::on_rq states: */
#define TASK_ON_RQ_QUEUED 1
struct task_group {
#ifdef CONFIG_UCLAMP_TASK_GROUP
\tunsigned int\t\tlatency_sensitive;
#endif
};
struct root_domain {
\tstruct perf_domain __rcu *pd;
};
struct rq {
\tu64 idle_stamp;
#ifdef CONFIG_IRQ_TIME_ACCOUNTING
\tu64\t\t\tprev_irq_time;
#endif
#ifdef CONFIG_CPU_IDLE
\tstruct cpuidle_state\t*idle_state;
#endif
};
#endif
'''


def fixture():
    before={P12_PATHS[0]:TARGET_PUBLIC.encode(),P12_PATHS[1]:TARGET_PRIVATE.encode()}
    donor={P12_PATHS[0]:PUBLIC.encode(),P12_PATHS[1]:PRIVATE.encode()}
    return before,donor

class P12WALTStructureTest(unittest.TestCase):
    def test_01_parse_donor_structure(self):
        a,b=donor_extract(PUBLIC,PRIVATE)
        self.assertIn('struct walt_task_struct {',a)
        self.assertIn('struct walt_rq {',b)
        self.assertIn('#else',a)

    def test_02_five_additions_and_two_files(self):
        a,b=fixture();after=prepare_after(a,b)
        self.assertEqual(set(after),set(P12_PATHS))
        self.assertIn('struct walt_task_struct\t\twts;',after[P12_PATHS[0]].decode())
        for x in ('struct walt_rq\t\twrq;', 'struct walt_task_group\twtg;',
                  'struct walt_root_domain\twrd;', 'idle_state_idx;'):
            self.assertIn(x,after[P12_PATHS[1]].decode())

    def test_03_patch_applies_and_reverses(self):
        before,donor=fixture();after=prepare_after(before,donor)
        patch=make_patch(before,after)
        validate_fixture_roundtrip(before,after,patch)
        self.assertEqual(patch.count('diff --git a/'),2)

    def test_04_no_walt_off_task_layout_changes(self):
        before,donor=fixture();after=prepare_after(before,donor)
        t=after[P12_PATHS[0]].decode(); p=after[P12_PATHS[1]].decode()
        self.assertIn('#ifdef CONFIG_SCHED_WALT\n\tstruct walt_task_struct\t\twts;',t)
        self.assertIn('#ifdef CONFIG_SCHED_WALT\n\tstruct walt_rq\t\twrq;',p)
        self.assertIn('#ifdef CONFIG_SCHED_WALT\n\tstruct walt_root_domain\twrd;',p)

    def test_05_source_immutable(self):
        before,donor=fixture();copies=dict(before)
        prepare_after(before,donor)
        self.assertEqual(before,copies)

    def test_06_duplicate_public_field_rejected(self):
        a,b=fixture();a[P12_PATHS[0]]+=b'struct walt_task_struct\t\twts;\n'
        with self.assertRaisesRegex(ValueError,'SOURCE_ALREADY_HAS_TASK_WALT'):
            prepare_after(a,b)

    def test_07_duplicate_private_field_rejected(self):
        a,b=fixture();a[P12_PATHS[1]]+=b'struct walt_rq\t\twrq;\n'
        with self.assertRaisesRegex(ValueError,'SOURCE_ALREADY_HAS_RQ_WALT'):
            prepare_after(a,b)

    def test_08_missing_anchor_fails_closed(self):
        a,b=fixture();a[P12_PATHS[1]]=a[P12_PATHS[1]].replace(b'latency_sensitive',b'changed_field')
        with self.assertRaisesRegex(ValueError,'ANCHOR_TASK_GROUP_WTG'):
            prepare_after(a,b)

    def test_09_donor_missing_walt_block_rejected(self):
        a,b=fixture();b[P12_PATHS[0]]=PUBLIC.replace('extern void walt_task_dead', 'extern void different').encode()
        with self.assertRaisesRegex(ValueError,'DONOR_TASK_STRUCT_SECTION_DRIFT'):
            prepare_after(a,b)

    def test_10_donor_missing_walt_group_rejected(self):
        a,b=fixture();b[P12_PATHS[1]]=PRIVATE.replace('struct walt_task_group {','struct other_group {').encode()
        with self.assertRaisesRegex(ValueError,'DONOR_WALT_BLOCK_INCOMPLETE'):
            prepare_after(a,b)

    def test_11_unexpected_path_fails_closed(self):
        a,b=fixture();a['kernel/evil.c']=b''
        with self.assertRaisesRegex(ValueError,'P12_FILE_SET_MISMATCH'):
            prepare_after(a,b)

    def test_12_patch_deterministic(self):
        a,b=fixture();first=make_patch(a,prepare_after(a,b));second=make_patch(a,prepare_after(a,b))
        self.assertEqual(first,second)
        self.assertTrue(all(oid(a[k])[:12] in first for k in P12_PATHS))

    def test_13_stage_rejects_unpinned_source(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)/'source';root.mkdir()
            (root/'.git').mkdir()
            with self.assertRaises(RuntimeError):
                stage(root,pathlib.Path(d)/'out')

    def test_14_truncated_donor_rq_rejected(self):
        a,b=fixture();b[P12_PATHS[1]]=PRIVATE.split('struct walt_rq')[0].encode()
        with self.assertRaisesRegex(ValueError,'DONOR_RQ_STRUCT_SECTION_DRIFT'):
            prepare_after(a,b)

if __name__=='__main__':unittest.main(verbosity=2)
