#!/usr/bin/env python3
"""P12 R1: fail-closed 5.4.274 VEUX WALT structure bridge candidate.

Expected P11-R4 post-build source tree, no flash. Imports structural definitions
from the *pinned* Xiaomi veux-r-oss commit; leaves all 11 OEM WALT files intact.
Outputs a reviewed candidate patch; never applies it to the provided kernel.
A WALT=y compile remains mandatory and is not implied by staging success.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import tempfile

P11_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
DONOR_COMMIT = '61397e524093d1ccb94769b5460825e2eaf8871e'
DONOR_BLOBS = {
    'include/linux/sched.h': '888b27fe998a2bd6200144bcf06285da0ebe1aed',
    'kernel/sched/sched.h': 'b5bdfa2df156cf40b368e73751eac8d71b99de55',
}
P12_PATHS = ('include/linux/sched.h', 'kernel/sched/sched.h')
OEM_WALT_BLOBS = {
    'Makefile': '8bf42cb669afabc17f69bc16cf74f17fcaf5cdd0',
    'boost.c': 'c37185e293d0ac7affe9b13124fcf76339fbce4e',
    'core_ctl.c': 'af838bd1c71e728d65dcdfee792b1379b07336e5',
    'cpu-boost.c': '9b2363cf275afbeadbc57b112e89818d0e019320',
    'qc_vas.c': 'ce49eac6d5907108ed46aa48b7ead5146b49618e',
    'qc_vas.h': '3b67a54946557d92b4582f990e3f015bceb3d0ae',
    'sched_avg.c': '4a5efa4118b3c6605d74380ff028d66e9a24668b',
    'trace.c': '7c06ce1fda642d026295ec87f190df55176c1cf9',
    'trace.h': '5b01043d226142ac380d76f924542719ef863e9e',
    'walt.c': '9d851c1dd315e2f4fb2385b5aa4a0c2749908b7d',
    'walt.h': '9a678f0bbb68d92aa670991c8899a5253f51322e',
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def oid(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def git(source: pathlib.Path, *args: str) -> str:
    p = subprocess.run(['git', '-C', str(source), *args], capture_output=True, timeout=50)
    if p.returncode:
        raise RuntimeError('GIT_COMMAND_FAIL ' + ' '.join(args[:2]) + ': ' + p.stderr.decode(errors='replace')[-270:])
    return p.stdout.decode('utf8')


def unique_replace(original: str, old: str, new: str, symbol: str) -> str:
    count = original.count(old)
    if count != 1:
        raise ValueError(f'UNEXPECTED_ANCHOR_{symbol}_COUNT={count}')
    return original.replace(old, new, 1)


def donor_extract(donor_sched: str, donor_int: str) -> tuple[str, str]:
    # One exact upstream OEM block is retained, including the vendor stubs for
    # CONFIG_SCHED_WALT=n. All section boundaries are anchored to OEM contexts.
    m = re.search(r'struct cpu_cycle_counter_cb \{\n[^{}]*\n\};\n', donor_sched)
    if not m or donor_sched.count('struct cpu_cycle_counter_cb {') != 1:
        raise ValueError('DONOR_MISSING_CPU_CYCLE_COUNTER')
    cpu_cb = m.group()
    block_start = '#ifdef CONFIG_SCHED_WALT\nextern void walt_task_dead(struct task_struct *p);\n'
    block_end = '#endif /* CONFIG_SCHED_WALT */\n\nstruct sched_rt_entity {'
    if donor_sched.count(block_start) != 1 or donor_sched.count(block_end) != 1:
        raise ValueError('DONOR_TASK_STRUCT_SECTION_DRIFT')
    start = donor_sched.index(block_start)
    end = donor_sched.index(block_end, start)
    public = cpu_cb + '\n' + donor_sched[start:end] + '#endif /* CONFIG_SCHED_WALT */\n'
    if public.count('struct walt_task_struct {') != 1 or 'bool\t\t\t\tiowaited;' not in public:
        raise ValueError('DONOR_WTS_INCOMPLETE')
    header_start = 'struct walt_cpu_load {\n'
    header_end = '#endif /* CONFIG_SCHED_WALT */\n\n/* task_struct::on_rq states: */'
    if donor_int.count(header_start) != 1 or donor_int.count(header_end) != 1:
        raise ValueError('DONOR_RQ_STRUCT_SECTION_DRIFT')
    start2 = donor_int.index(header_start)
    end2 = donor_int.index(header_end, start2)
    private = donor_int[start2:end2] + '#endif /* CONFIG_SCHED_WALT */\n'
    for marker in ('struct walt_rq {', 'struct walt_sched_cluster {',
                   'struct walt_root_domain {', 'struct walt_task_group {',
                   'struct walt_sched_stats {'):
        if private.count(marker) != 1:
            raise ValueError('DONOR_WALT_BLOCK_INCOMPLETE '+marker)
    return public, private


def prepare_after(before: dict[str, bytes], donor: dict[str, bytes]) -> dict[str, bytes]:
    if set(before) != set(P12_PATHS) or set(donor) != set(DONOR_BLOBS):
        raise ValueError('P12_FILE_SET_MISMATCH')
    public, private = donor_extract(donor['include/linux/sched.h'].decode('utf8'),
                                    donor['kernel/sched/sched.h'].decode('utf8'))
    task, intr = (before[name].decode('utf8') for name in P12_PATHS)
    if any(item in task for item in ('struct walt_task_struct {', 'struct walt_task_struct\t\twts;')):
        raise ValueError('SOURCE_ALREADY_HAS_TASK_WALT')
    if any(item in intr for item in ('struct walt_rq {', 'struct walt_rq\t\twrq;')):
        raise ValueError('SOURCE_ALREADY_HAS_RQ_WALT')
    task = unique_replace(task, '\nstruct sched_rt_entity {',
                          '\n' + public + '\nstruct sched_rt_entity {', 'PUBLIC_WALT_DEFINITIONS')
    task = unique_replace(task, '\tstruct sched_rt_entity\t\trt;\n',
                          '\tstruct sched_rt_entity\t\trt;\n'
                          '#ifdef CONFIG_SCHED_WALT\n'
                          '\tstruct walt_task_struct\t\twts;\n'
                          '#endif /* CONFIG_SCHED_WALT */\n', 'TASK_WTS')
    intr = unique_replace(intr, '\n/* task_struct::on_rq states: */',
                          '\n' + private + '\n/* task_struct::on_rq states: */', 'PRIVATE_WALT_DEFINITIONS')
    # Preserve matching layout scope from the Xiaomi scheduler; do not move
    # structs outside CONFIG guards and never patch the original WALT subtree.
    intr = unique_replace(intr, '\tunsigned int\t\tlatency_sensitive;\n#endif',
                          '\tunsigned int\t\tlatency_sensitive;\n'
                          '#ifdef CONFIG_SCHED_WALT\n'
                          '\tstruct walt_task_group\twtg;\n'
                          '#endif /* CONFIG_SCHED_WALT */\n#endif', 'TASK_GROUP_WTG')
    intr = unique_replace(intr, '\tstruct perf_domain __rcu *pd;\n};',
                          '\tstruct perf_domain __rcu *pd;\n'
                          '#ifdef CONFIG_SCHED_WALT\n'
                          '\tstruct walt_root_domain\twrd;\n'
                          '#endif /* CONFIG_SCHED_WALT */\n};', 'ROOT_DOMAIN_WRD')
    intr = unique_replace(intr, '\n#ifdef CONFIG_IRQ_TIME_ACCOUNTING\n\tu64\t\t\tprev_irq_time;',
                          '\n#ifdef CONFIG_SCHED_WALT\n'
                          '\tstruct walt_rq\t\twrq;\n'
                          '#endif /* CONFIG_SCHED_WALT */\n'
                          '\n#ifdef CONFIG_IRQ_TIME_ACCOUNTING\n\tu64\t\t\tprev_irq_time;', 'RUNQUEUE_WRQ')
    intr = unique_replace(intr, '\tstruct cpuidle_state\t*idle_state;\n#endif',
                          '\tstruct cpuidle_state\t*idle_state;\n'
                          '#ifdef CONFIG_SCHED_WALT\n'
                          '\tint\t\t\tidle_state_idx;\n'
                          '#endif /* CONFIG_SCHED_WALT */\n#endif', 'RQ_IDLE_STATE_IDX')
    if task.count('struct walt_task_struct\t\twts;') != 1 or intr.count('struct walt_rq\t\twrq;') != 1:
        raise ValueError('POSTIMAGE_FIELDS_MISSING')
    result = {P12_PATHS[0]: task.encode(), P12_PATHS[1]: intr.encode()}
    if any(result[x] == before[x] for x in P12_PATHS):
        raise ValueError('UNEXPECTED_UNCHANGED_SOURCE')
    return result


def make_patch(before: dict[str,bytes], after: dict[str,bytes]) -> str:
    out=[]
    for path in P12_PATHS:
        old=before[path]; new=after[path]
        desc=(f'diff --git a/{path} b/{path}\n'
              f'index {oid(old)[:12]}..{oid(new)[:12]} 100644\n')
        lines=difflib.unified_diff(old.decode().splitlines(keepends=True),
                                   new.decode().splitlines(keepends=True),
                                   fromfile='a/'+path,tofile='b/'+path,n=3)
        out.append(desc + ''.join(lines))
    return ''.join(out)


def validate_fixture_roundtrip(before: dict[str,bytes],after:dict[str,bytes],patch:str)->None:
    with tempfile.TemporaryDirectory(prefix='veux_p12_patchgate_') as td:
        root=pathlib.Path(td)/'work';root.mkdir()
        for name,data in before.items():
            f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
        q=pathlib.Path(td)/'candidate.patch';q.write_text(patch)
        for args in (('apply','--check',str(q)),('apply',str(q))):
            subprocess.run(['git',*args],cwd=root,capture_output=True,check=True,timeout=30)
        if any((root/name).read_bytes()!=data for name,data in after.items()):
            raise RuntimeError('P12_PATCH_POSTIMAGE_MISMATCH')
        for args in (('apply','--check','-R',str(q)),('apply','-R',str(q))):
            subprocess.run(['git',*args],cwd=root,capture_output=True,check=True,timeout=30)
        if any((root/name).read_bytes()!=data for name,data in before.items()):
            raise RuntimeError('P12_PATCH_NOT_REVERSIBLE')


def stage(source:pathlib.Path,output:pathlib.Path)->dict:
    source=source.resolve(strict=True)
    output=output.resolve()
    if output.exists() or output.is_relative_to(source):
        raise RuntimeError('UNSAFE_OR_EXISTING_OUTPUT_DIR')
    if not (source/'.git').is_dir():raise RuntimeError('SOURCE_GIT_MISSING')
    if git(source,'rev-parse','HEAD^{tree}').strip()!=P11_TREE:
        raise RuntimeError('NOT_PINNED_P11_R4_TREE')
    if git(source,'status','--porcelain','--untracked-files=all').strip():
        raise RuntimeError('DIRTY_WORKTREE')
    m=(source/'Makefile').read_text()
    for k,v in [('VERSION','5'),('PATCHLEVEL','4'),('SUBLEVEL','274')]:
        if not re.search(r'^'+k+r'\s*=\s*'+v+r'\s*$',m,re.M):
            raise RuntimeError('WRONG_KERNEL_VERSION_'+k)
    for f,expected in OEM_WALT_BLOBS.items():
        p='kernel/sched/walt/'+f
        if git(source,'rev-parse','HEAD:'+p).strip()!=expected:
            raise RuntimeError('WALT_OEM_BLOB_CHANGED '+p)
    before={}; donor={}
    for f in P12_PATHS:
        file=source/f
        if file.is_symlink() or not file.is_file() or not file.resolve().is_relative_to(source):
            raise RuntimeError('P12_NONREGULAR_FILE '+f)
        before[f]=file.read_bytes()
        actual=git(source,'rev-parse',DONOR_COMMIT+':'+f).strip()
        if actual!=DONOR_BLOBS[f]:raise RuntimeError('PINNED_DONOR_BLOB_CHANGED '+f)
        donor[f]=subprocess.check_output(['git','-C',str(source),'show',DONOR_COMMIT+':'+f],timeout=50)
        if oid(donor[f])!=actual:raise RuntimeError('DONOR_OBJECT_BYTES_MISMATCH '+f)
    after=prepare_after(before,donor)
    patch=make_patch(before,after)
    if len(patch)>50_000:raise RuntimeError('P12_PATCH_TOO_LARGE')
    validate_fixture_roundtrip(before,after,patch)
    with tempfile.TemporaryDirectory(prefix='p12_patch_check_') as tmp:
        p=pathlib.Path(tmp)/'test.patch';p.write_text(patch)
        subprocess.run(['git','-C',str(source),'apply','--check',str(p)],
                       capture_output=True,check=True,timeout=30)
    if git(source,'status','--porcelain','--untracked-files=all').strip():
        raise RuntimeError('STAGING_MODIFIED_SOURCE')
    output.mkdir(parents=True)
    patchfile=output/'P11_TO_P12_WALT_STRUCTS_ONLY.patch';patchfile.write_text(patch)
    report={'phase':'P12_R1_WALT_STRUCT_BRIDGE_SOURCE_ONLY',
            'kernel':'5.4.274','device':'veux','input_tree':P11_TREE,
            'donor_commit':DONOR_COMMIT,'donor_blobs':DONOR_BLOBS,
            'changed_paths':list(P12_PATHS),'candidate_patch_sha256':sha(patchfile.read_bytes()),
            'preimage_sha256':{k:sha(v) for k,v in before.items()},
            'postimage_sha256':{k:sha(v) for k,v in after.items()},
            'original_xiaomi_walt_file_count':len(OEM_WALT_BLOBS),
            'original_xiaomi_walt_file_blobs':'PRESERVED',
            'patch_apply_reverse':'PASS',
            'source_modified':False,'github_modified':False,
            'walt_on_kernel_build':'NOT_RUN', 'walt_runtime':'NOT_TESTED',
            'vendor_abi':'NOT_CHECKED','device_test':'NOT_RUN','flashable':False}
    (output/'P12_PREP_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    return report


def main()->int:
    a=argparse.ArgumentParser();a.add_argument('--source',required=True,type=pathlib.Path)
    a.add_argument('--output',required=True,type=pathlib.Path);args=a.parse_args()
    try:
        report=stage(args.source,args.output)
    except Exception as e:
        print('P12_FAIL_CLOSED: '+str(e),file=sys.stderr);return 2
    print('P12_STRUCTURE_PATCH=PASS; OEM=11/11; PATCH_ONLY; WALT_ON_NOT_PROVEN; FLASH=NO')
    return 0

if __name__=='__main__':raise SystemExit(main())
