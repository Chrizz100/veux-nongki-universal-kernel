#!/usr/bin/env python3
"""Audit the pinned R19 kernel and validate the previously proven VEUX boot path."""
import argparse
from collections import Counter
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import struct
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def profile():
    return json.loads((ROOT / 'References/PROFILE.json').read_text())


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def bytes_sha(data):
    return hashlib.sha256(data).hexdigest()


def verify_package():
    listed = set()
    for row in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        sha, name = row.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in listed,
                'UNSAFE_MANIFEST')
        require(not (ROOT / p).is_symlink() and digest(ROOT / p) == sha, 'PACKAGE_DRIFT:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == listed, 'MANIFEST_SCOPE_CHANGED')


def safe_zip(z):
    items = z.infolist()
    require(len(items) < 1000 and sum(x.file_size for x in items) < 3_000_000_000, 'ZIP_LIMIT')
    require(len(items) == len({x.filename for x in items}) and z.testzip() is None, 'ZIP_CRC_OR_DUPLICATE')
    for x in items:
        p = PurePosixPath(x.filename)
        require(not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename
                and not stat.S_ISLNK(x.external_attr >> 16), 'UNSAFE_ZIP_MEMBER')


def identity(image):
    require(len(image) >= 64 and image[56:60] == b'ARMd', 'NOT_ARM64_IMAGE')
    releases = set(x.decode('ascii') for x in re.findall(rb'Linux version (5\.[^\s\0]+) ', image))
    require(len(releases) == 1, 'AMBIGUOUS_KERNEL_RELEASE')
    release = next(iter(releases))
    require(release.startswith('5.4.274-qgki') and 'positron' not in release.lower(), 'WRONG_KERNEL_IDENTITY')
    return release


def read_candidate(archive):
    p = profile()
    require(Path(archive).stat().st_size == p['artifact_size'] and digest(archive) == p['artifact_sha256'],
            'CANDIDATE_ARCHIVE_NOT_AUTHENTIC')
    base = 'r46-r16-result/'
    with zipfile.ZipFile(archive) as z:
        safe_zip(z)
        report = json.loads(z.read(base + 'R19_RESULT.json'))
        require(report['status'] == 'R19_FULL_ARM64_BUILD_AND_RMNET_VENDOR_API_PROGRESS_PROVEN_NOFLASH'
                and report['kernel_compiled'] and report['r6_baseline_unchanged'], 'REAL_BUILD_NOT_PROVEN')
        hashes = report['kernel_product_hashes']
        for name, expected in hashes.items():
            require(name in ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux'), 'PRODUCT_SCOPE')
            h = hashlib.sha256()
            with z.open(base + 'candidate-out/' + name) as f:
                first = f.read(64)
                h.update(first)
                if name == 'vmlinux':
                    require(first[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', first, 18)[0] == 183,
                            'VMLINUX_NOT_AARCH64')
                for chunk in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(chunk)
            require(h.hexdigest() == expected, 'PRODUCT_HASH_MISMATCH:' + name)
        require(set(hashes) == {'.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux'}, 'PRODUCTS_MISSING')
        image = z.read(base + 'candidate-out/arch/arm64/boot/Image')
        release = identity(image)
        symvers = {}
        for line in z.read(base + 'candidate-out/Module.symvers').decode().splitlines():
            fields = line.split()
            require(len(fields) >= 4 and re.fullmatch(r'0x[0-9a-fA-F]{8}', fields[0]), 'INVALID_SYMVERS')
            require(fields[1] not in symvers, 'DUPLICATE_EXPORT')
            symvers[fields[1]] = fields[0].lower()
        expected = json.loads((ROOT / 'References/OEM_1423_CRC.json').read_text())
        require(len(expected) == 1423, 'OEM_COHORT_CHANGED')
        mismatches = [dict(symbol=n, oem_crc=crc, candidate_crc=symvers.get(n))
                      for n, crc in expected.items() if symvers.get(n) != crc]
        missing = sum(symvers.get(n) is None for n in expected)
        counts = {'MATCH': 1423 - len(mismatches), 'CRC_MISMATCH': len(mismatches) - missing,
                  'NOT_EXPORTED': missing}
        require(counts == report['qgki_counts'], 'INDEPENDENT_ABI_COUNT_DISAGREEMENT')
        require(symvers.get('module_layout') == '0x945d02f2', 'STOCK_MODULE_LAYOUT_LOST')
        modules = list(csv.DictReader(io.StringIO(z.read(base + 'QGKI_37_MODULE_RESULTS.csv').decode())))
        require(len(modules) == 37 and len({m['module'] for m in modules}) == 37, 'MODULE_COHORT_CHANGED')
        full = sum(m['fully_compatible'] == 'True' for m in modules)
        require(full == report['fully_matching_modules'], 'MODULE_REPORT_DISAGREEMENT')
        vermagic = {}
        for n in z.namelist():
            if n.startswith(base + 'candidate-out/') and n.endswith('.ko'):
                vals = set(x.decode() for x in re.findall(rb'vermagic=([^\0]+)\0', z.read(n)))
                require(len(vals) == 1, 'MODULE_VERMAGIC_AMBIGUOUS:' + n)
                vermagic[n.removeprefix(base + 'candidate-out/')] = next(iter(vals))
        require(len(vermagic) == 4, 'BUILT_MODULE_COHORT_CHANGED')
        reasons = []
        if mismatches:
            reasons.append('VENDOR_ABI_NOT_COMPLETE')
        if full != 37:
            reasons.append('ORIGINAL_WLAN_MODULE_CRC_NOT_COMPLETE')
        if release != p['expected_release']:
            reasons.append('ORIGINAL_KERNEL_RELEASE_NOT_RESTORED')
        if any(v.split()[0] != p['expected_release'] for v in vermagic.values()):
            reasons.append('BUILT_MODULE_VERMAGIC_NOT_ORIGINAL')
        return image, dict(source_run=p['source_run'], source_commit=p['source_commit'],
                           qgki_counts=counts, fully_matching_modules=full, remaining=mismatches,
                           actual_release=release, expected_release=p['expected_release'],
                           image_sha256=bytes_sha(image), image_bytes=len(image),
                           built_module_vermagic=vermagic, blocking_reasons=reasons,
                           packaging_input_ready=not reasons, device_pass=False, flash_allowed=False)


def validate_reference_ak3(path):
    p = profile()
    require(digest(path) == p['reference_ak3_sha256'], 'REFERENCE_AK3_CHANGED')
    with zipfile.ZipFile(path) as z:
        safe_zip(z)
        files = {x.filename: (z.read(x), (x.external_attr >> 16) & 0o777)
                 for x in z.infolist() if not x.is_dir()}
    require(set(files) == set(p['reference_files']), 'REFERENCE_AK3_FILESET_CHANGED')
    for name, (data, mode) in files.items():
        pin = p['reference_files'][name]
        require(bytes_sha(data) == pin['sha256'] and mode == pin['mode'], 'AK3_TEMPLATE_CHANGED:' + name)
    return files


def header_parts(data):
    require(len(data) >= 4096 and data[:8] == b'ANDROID!', 'NOT_ANDROID_BOOT')
    ks, rs, _, hs = struct.unpack_from('<4I', data, 8)
    require(struct.unpack_from('<I', data, 40)[0] == 3 and hs == 1580, 'NOT_PROVEN_BOOT_V3_HEADER')
    align = lambda n: (n + 4095) // 4096 * 4096
    rp = 4096 + align(ks)
    require(ks > 64 and rs > 0 and rp + rs <= len(data), 'BOOT_COMPONENT_BOUNDS')
    return data[:4096], data[4096:4096 + ks], data[rp:rp + rs]


def metadata(text):
    fields = {}
    for key in ('Algorithm', 'Partition Name', 'Hash Algorithm', 'Salt'):
        hits = re.findall(r'^\s*' + key + r':\s*(\S+)\s*$', text, re.M)
        require(len(hits) == 1, 'AMBIGUOUS_AVB:' + key)
        fields[key] = hits[0]
    props = re.findall(r"^\s*Prop:\s+(.+?)\s+->\s+'(.*)'\s*$", text, re.M)
    require(props and all(len({v for k, v in props if k == key}) == 1 for key in {k for k, _ in props}),
            'CONFLICTING_AVB_PROPERTIES')
    fields['props'] = sorted(props)
    require(fields['Algorithm'] == 'NONE' and fields['Partition Name'] == 'boot'
            and fields['Hash Algorithm'] == 'sha256' and re.fullmatch(r'[0-9a-f]+', fields['Salt']),
            'UNEXPECTED_AVB_POLICY')
    return fields


def run(command, cwd, log):
    result = subprocess.run([str(x) for x in command], cwd=cwd, text=True, capture_output=True, timeout=180)
    text = result.stdout + result.stderr
    Path(log).write_text(text)
    require(result.returncode == 0 and 'Traceback' not in text, 'OFFLINE_TOOL_FAILED:' + str(command[0]))
    return text


def construct_boot(image, reference, mb, work):
    p = profile()
    require(digest(reference) == p['reference_boot_sha256'], 'REFERENCE_BOOT_CHANGED')
    require(digest(mb) == p['host_magiskboot_sha256'], 'HOST_MAGISKBOOT_CHANGED')
    avb = ROOT / 'Tools/avbtool.py'
    require(digest(avb) == p['avb_source_sha256'], 'AVB_SOURCE_CHANGED')
    work = Path(work).resolve();work.mkdir(parents=True, exist_ok=False)
    original = Path(reference).read_bytes()
    require(len(original) == p['boot_partition_size'], 'BOOT_PARTITION_SIZE_CHANGED')
    header, old, ramdisk = header_parts(original)
    require(bytes_sha(old) == p['reference_image_sha256'] and bytes_sha(ramdisk) == p['raw_ramdisk_sha256'],
            'REFERENCE_KERNEL_OR_STOCK_RAMDISK_CHANGED')
    identity(image)
    meta = metadata(run([sys.executable, avb, 'info_image', '--image', Path(reference).resolve()], work, work/'base-avb.log'))
    align = lambda n: (n + 4095) // 4096 * 4096
    h = bytearray(header);struct.pack_into('<I', h, 8, len(image))
    data = h + image + b'\0' * (align(len(image)) - len(image)) + ramdisk + b'\0' * (align(len(ramdisk)) - len(ramdisk))
    require(len(data) + 65536 < p['boot_partition_size'], 'KERNEL_DOES_NOT_FIT_BOOT_PARTITION')
    boot = work / 'boot.img';boot.write_bytes(data)
    props = [arg for k, v in meta['props'] for arg in ('--prop', k + ':' + v)]
    run([sys.executable, avb, 'add_hash_footer', '--image', boot, '--partition_name', 'boot',
         '--partition_size', str(p['boot_partition_size']), '--hash_algorithm', 'sha256',
         '--algorithm', 'NONE', '--salt', meta['Salt'], *props], work, work/'add-avb.log')
    require(boot.stat().st_size == p['boot_partition_size'], 'FINAL_PARTITION_SIZE_CHANGED')
    require(metadata(run([sys.executable, avb, 'info_image', '--image', boot], work, work/'final-avb.log')) == meta,
            'AVB_PROPERTIES_OR_POLICY_CHANGED')
    verify = run([sys.executable, avb, 'verify_image', '--image', boot], work, work/'verify-avb.log')
    require('Successfully verified footer' in verify and 'Successfully verified sha256 hash' in verify,
            'AVB_HASH_VERIFICATION_MISSING')
    final_h, final_k, final_r = header_parts(boot.read_bytes())
    check = bytearray(final_h);check[8:12] = header[8:12]
    require(check == header and final_k == image and final_r == ramdisk, 'BOOT_PAYLOAD_OR_HEADER_CHANGED')
    for label, flags, expected in [('raw', ['-n', '-h'], p['raw_ramdisk_sha256']),
                                   ('decoded', ['-h'], p['decoded_ramdisk_sha256'])]:
        target = work / label;target.mkdir()
        run([Path(mb).resolve(), 'unpack', *flags, boot], target, work/(label+'.log'))
        require(digest(target/'kernel') == bytes_sha(image) and digest(target/'ramdisk.cpio') == expected,
                'MAGISKBOOT_ROUNDTRIP_MISMATCH:' + label)
    return boot, dict(boot_header_v3=True, only_kernel_size_header_field_changed=True,
                      raw_and_decoded_stock_ramdisks_unchanged=True, avb_hash_verified=True,
                      image_sha256=bytes_sha(image), boot_sha256=digest(boot), device_pass=False,
                      flash_allowed=False)


def construct_ak3(image, template, path):
    files = validate_reference_ak3(template)
    old_script = files['anykernel.sh'][0].decode()
    script, count = re.subn(r'(?m)^kernel.string=.*$',
                           'kernel.string=VEUX 5.4.274 QGKI Stock-Rebuild NOFLASH', old_script)
    require(count == 1, 'AK3_SCRIPT_IDENTITY_AMBIGUOUS')
    require(subprocess.run(['bash', '-n'], input=script, text=True, capture_output=True).returncode == 0,
            'AK3_SCRIPT_SYNTAX')
    files['anykernel.sh'] = (script.encode(), 0o755)
    files['Image'] = (image, 0o644)
    def write(target):
        with zipfile.ZipFile(target, 'w') as z:
            for name, (data, mode) in sorted(files.items()):
                info = zipfile.ZipInfo(name, (2024, 12, 5, 14, 48, 0));info.create_system = 3
                info.external_attr = (stat.S_IFREG | mode) << 16;info.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(info, data, compresslevel=9)
    write(path)
    with tempfile.TemporaryDirectory() as tmp:
        second = Path(tmp)/'repeat.zip';write(second)
        require(digest(path) == digest(second), 'NONDETERMINISTIC_AK3')
    with zipfile.ZipFile(path) as z:
        safe_zip(z)
        require(z.read('Image') == image and set(z.namelist()) == set(files), 'AK3_IMAGE_OR_FILESET_CHANGED')
        for n, (b, mode) in files.items():
            require(z.read(n) == b and ((z.getinfo(n).external_attr >> 16) & 0o777) == mode,
                    'AK3_BYTES_OR_MODE_CHANGED:' + n)
    return dict(ak3_commit=profile()['ak3_commit'], ak3_sha256=digest(path), image_sha256=bytes_sha(image),
                device_check=True, active_slot_only=True, image_only=True, deterministic=True,
                operational_installer_script_unchanged=True, device_pass=False, flash_allowed=False)


def execute(args):
    verify_package()
    out = Path(args.output).resolve();out.mkdir(parents=True, exist_ok=False)
    work = Path(args.work).resolve();work.mkdir(parents=True, exist_ok=False)
    image, report = read_candidate(args.candidate)
    files = validate_reference_ak3(args.reference_ak3)
    # This proves the packaging method against the old, authentic reference.
    # It never upgrades the new candidate's compile result to a boot pass.
    _, old_boot = construct_boot(files['Image'][0], args.reference_boot, args.magiskboot, work/'reference-boot')
    old_ak3 = construct_ak3(files['Image'][0], args.reference_ak3, work/'reference-only.zip')
    # Exercise the exact current payload in private files as well. A container
    # roundtrip cannot establish module ABI compatibility or a hardware boot.
    boot, proof = construct_boot(image, args.reference_boot, args.magiskboot, work/'candidate-container')
    package = work/'candidate-container-AK3.zip'
    package_proof = construct_ak3(image, args.reference_ak3, package)
    require(proof['image_sha256'] == package_proof['image_sha256'] == report['image_sha256'],
            'BOOT_AK3_PAIR_MISMATCH')
    report.update(reference_pair_static_boot_pass=True, reference_boot_proof=old_boot,
                  reference_ak3_proof=old_ak3, new_kernel_static_boot_pass=False,
                  current_kernel_container_repack_pass=True,
                  current_kernel_container_boot_proof=proof,
                  current_kernel_container_ak3_proof=package_proof,
                  candidate_artifacts_created=False, status='BLOCKED_BEFORE_CANDIDATE_PACKAGING')
    if report['packaging_input_ready']:
        # Publish only after both independently validated products exist.
        publish = work/'validated-pair';publish.mkdir()
        b = publish/'VEUX_5.4.274_QGKI_NOFLASH_boot.img'
        a = publish/'VEUX_5.4.274_QGKI_NOFLASH_AK3.zip'
        shutil.copyfile(boot, b);shutil.copyfile(package, a)
        require(digest(b) == proof['boot_sha256'] and digest(a) == package_proof['ak3_sha256'],
                'FINAL_DELIVERY_HASH_MISMATCH')
        publish.replace(out/'candidate-review')
        report.update(new_kernel_static_boot_pass=True, candidate_artifacts_created=True,
                      candidate_boot_proof=proof, candidate_ak3_proof=package_proof,
                      status='STATIC_BOOT_AND_AK3_REVIEW_ONLY_DEVICE_NOT_TESTED')
    (out/'R20_BOOT_AK3_RESULT.json').write_text(json.dumps(report, indent=2, sort_keys=True)+'\n')
    (out/'KURZSTATUS.txt').write_text('R20: '+report['status']+'\nKernel: '+report['actual_release']+'\n'
                                    +'DEVICE_PASS=NO\nFLASH_ALLOWED=NO\n'
                                    +'Offen: '+', '.join(report['blocking_reasons'])+'\n')
    print(report['status'], report['qgki_counts'], 'DEVICE_PASS=NO FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    r = sub.add_parser('run')
    for n in ('candidate', 'reference-ak3', 'reference-boot', 'magiskboot', 'output', 'work'):
        r.add_argument('--'+n, required=True)
    args = p.parse_args()
    if args.operation == 'run':
        execute(args)
    else:
        verify_package();print('R20_PACKAGE_VERIFIED; DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
