import importlib.util
import io
import os
from pathlib import Path
import stat
import struct
import tempfile
import unittest
from unittest.mock import patch
import zipfile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('boot_plan', ROOT/'Tools/boot_ak3_plan.py')
r = importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def image(release='5.4.274-qgki-g82179e362f33'):
    value = bytearray(128);value[56:60] = b'ARMd'
    return bytes(value) + ('Linux version '+release+' (fixture)\0').encode()


def boot():
    h = bytearray(4096);h[:8] = b'ANDROID!'
    struct.pack_into('<4I', h, 8, 128, 4, 0, 1580);struct.pack_into('<I', h, 40, 3)
    return h + bytearray(4096) + b'cpio'


class BootPlanTests(unittest.TestCase):
    def test_release_comes_from_the_real_image_and_wrong_brand_is_rejected(self):
        self.assertEqual(r.identity(image()), r.profile()['expected_release'])
        for data in (b'Image', image('5.4.274-Positron'), image('5.4.292-qgki'),
                     image()+b'Linux version 5.4.274-qgki-other (x)\0'):
            with self.assertRaises(ValueError):r.identity(data)

    def test_v3_header_and_bounds_are_checked_independently(self):
        data = boot();h,k,d = r.header_parts(data)
        self.assertEqual((len(h),len(k),d),(4096,128,b'cpio'))
        for offset,value in [(40,4),(20,999),(8,999999999),(12,999999999)]:
            changed = bytearray(data);struct.pack_into('<I',changed,offset,value)
            with self.assertRaises(ValueError):r.header_parts(changed)

    def metadata(self):
        return "Algorithm: NONE\nPartition Name: boot\nHash Algorithm: sha256\nSalt: abcdef\n    Prop: patch -> '2024-12-01'\n    Prop: patch -> '2024-12-01'\n"

    def test_duplicate_original_avb_properties_survive_but_conflicts_are_rejected(self):
        meta = r.metadata(self.metadata());self.assertEqual(len(meta['props']),2)
        with self.assertRaises(ValueError):r.metadata(self.metadata()+"Prop: patch -> '2025-01-01'\n")
        with self.assertRaises(ValueError):r.metadata(self.metadata().replace('NONE','SHA256_RSA2048'))

    def test_archive_paths_duplicates_and_links_cannot_escape(self):
        for name,link,duplicate in [('../outside',False,False),('/outside',False,False),
                                     ('tools/linked',True,False),('tools/a',False,True)]:
            buf = io.BytesIO()
            import warnings
            with warnings.catch_warnings():
                warnings.simplefilter('ignore',UserWarning)
                with zipfile.ZipFile(buf,'w') as z:
                    n = zipfile.ZipInfo(name);n.external_attr = ((stat.S_IFLNK if link else stat.S_IFREG)|0o755)<<16
                    z.writestr(n,b'bytes')
                    if duplicate:z.writestr(name,b'other')
            buf.seek(0)
            with zipfile.ZipFile(buf) as z:
                with self.assertRaises(ValueError):r.safe_zip(z)

    def reference(self):
        value = os.environ.get('R20_REFERENCE_AK3')
        self.assertTrue(value,'R20_REFERENCE_AK3 fixture is required')
        return Path(value)

    def test_exact_device_reference_and_active_slot_contract(self):
        files = r.validate_reference_ak3(self.reference());self.assertEqual(len(files),13)
        sh = files['anykernel.sh'][0].decode()
        for token in ('do.devicecheck=1','device.name1=veux','supported.versions=13','BLOCK=boot;',
                      'IS_SLOT_DEVICE=1;','SLOT_SELECT=active;','PATCH_VBMETA_FLAG=0;','do.modules=0'):
            self.assertIn(token,sh)

    def test_new_package_preserves_every_installer_byte_and_mode(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)/'candidate.zip';data=image();proof=r.construct_ak3(data,self.reference(),out)
            self.assertFalse(proof['device_pass']);self.assertTrue(proof['deterministic'])
            with zipfile.ZipFile(out) as z:
                self.assertEqual(z.read('Image'),data)
                old=r.validate_reference_ak3(self.reference())
                for name,(value,mode) in old.items():
                    if name not in ('Image','anykernel.sh'):
                        self.assertEqual(z.read(name),value)
                        self.assertEqual((z.getinfo(name).external_attr>>16)&0o777,mode)
                self.assertNotIn('boot.img',z.namelist())

    def test_a_fake_green_report_cannot_bypass_archive_authentication(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'fake.zip';p.write_bytes(b'{"kernel_compiled":true}')
            with self.assertRaisesRegex(ValueError,'ARCHIVE_NOT_AUTHENTIC'):r.read_candidate(p)

    def test_blocked_input_never_emits_a_candidate_image_or_ak3(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);args=SimpleNamespace(output=d/'out',work=d/'work',candidate=d/'unused',
                    reference_ak3=self.reference(),reference_boot=d/'unused-boot',magiskboot=d/'unused-tool')
            report={'actual_release':'5.4.274-qgki','packaging_input_ready':False,
                    'image_sha256':r.bytes_sha(image()),
                    'blocking_reasons':['VENDOR_ABI_NOT_COMPLETE'],'qgki_counts':{'MATCH':1420,'CRC_MISMATCH':3,'NOT_EXPORTED':0}}
            proof={'image_sha256':r.bytes_sha(image())}
            with patch.object(r,'verify_package'),patch.object(r,'read_candidate',return_value=(image(),report)),\
                 patch.object(r,'construct_boot',return_value=(d/'reference.img',proof)) as make_boot,\
                 patch.object(r,'construct_ak3',return_value=proof) as make_ak3:
                r.execute(args)
                self.assertEqual(make_boot.call_count,2);self.assertEqual(make_ak3.call_count,2)
            self.assertEqual({p.name for p in args.output.iterdir()},{'R20_BOOT_AK3_RESULT.json','KURZSTATUS.txt'})
            self.assertFalse(report['candidate_artifacts_created']);self.assertFalse(report['new_kernel_static_boot_pass'])


if __name__=='__main__':unittest.main()
