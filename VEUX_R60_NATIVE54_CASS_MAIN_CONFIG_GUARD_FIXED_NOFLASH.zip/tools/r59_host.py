#!/usr/bin/env python3
"""Fail-closed Linux 5.4 SELinux host wiring on a *separate* R58 candidate.

This is not a flashability statement. Only the in-memory / temp build source is
modified; R13 and the GitHub source checkout are protected by R58's checks.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = {
    'security/selinux/hooks.c': 'c30bdee06d992110fedb6a61f1c78e9d180a60af',
    'security/selinux/avc.c': 'f770ade87d83134e7174998dbdc36887127543eb',
    'security/selinux/selinuxfs.c': 'b5e8f527442a58ebc2dddd4bf39983556baaa062',
}

class GateError(RuntimeError): pass

def require(ok, message):
    if not ok: raise GateError(message)

def replace_one(text, a, b, name):
    require(text.count(a)==1, f'{name}:EXPECTED_EXACT_ANCHOR_ONE_FOUND_{text.count(a)}')
    return text.replace(a,b,1)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def gitblob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def port_hooks(text):
    require('ksu_selinux_hide_running' not in text,'HOOKS_ALREADY_MANUAL_OR_CHANGED')
    # This symbol also intentionally enables BakaSU's native SUSFS manual-hook
    # compatibility mode (tools/susfs_compat.mk). Without a functional handler,
    # BakaSU would stop installing its own LSM handler: do not split this patch.
    a='struct selinux_state selinux_state;\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       'extern bool ksu_selinux_hide_running;\n'
       'extern int my_setprocattr(const char *name, void *value, size_t size);\n'
       '#endif\n')
    text=replace_one(text,a,b,'HOOKS_DECL')
    anchor='\tLSM_HOOK_INIT(setprocattr, selinux_setprocattr),'
    text=replace_one(text,anchor,(
        '#ifdef CONFIG_KSU_SUSFS\n'
        '\tLSM_HOOK_INIT(setprocattr, r59_selinux_setprocattr),\n'
        '#else\n'+anchor+'\n'
        '#endif'), 'HOOKS_LSM')
    a='static int selinux_ismaclabel(const char *name)\n'
    wrapper=(
        '#ifdef CONFIG_KSU_SUSFS\n'
        '/* 5.4 policy/LSM ABI: BakaSU retains its native permission checks. */\n'
        'static int r59_selinux_setprocattr(const char *name, void *value, size_t size)\n'
        '{\n'
        '\tif (current_uid().val >= 10000 &&\n'
        '\t    READ_ONCE(ksu_selinux_hide_running) && !strcmp(name, "current"))\n'
        '\t\treturn my_setprocattr(name, value, size);\n'
        '\treturn selinux_setprocattr(name, value, size);\n'
        '}\n'
        '#endif\n\n')
    text=replace_one(text,a,wrapper+a,'HOOKS_WRAPPER')
    require(text.count('r59_selinux_setprocattr')==2,'HOOKS_WRAPPER_REFERENCE_COUNT')
    return text

def port_avc(text):
    require('r59_avc_context' not in text,'AVC_ALREADY_PORTED')
    a='#include "avc_ss.h"\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/jump_label.h>\n'
       'extern u32 susfs_ksu_sid, susfs_priv_app_sid;\n'
       'extern struct static_key_false susfs_is_avc_log_spoofing_enabled;\n'
       '#endif\n')
    text=replace_one(text,a,b,'AVC_INCLUDE')
    a=('\trc = security_sid_to_context(sad->state, sad->tsid, &scontext,\n'
       '\t\t\t\t     &scontext_len);\n'
       '\tif (rc)\n'
       '\t\taudit_log_format(ab, " tsid=%d", sad->tsid);\n'
       '\telse {\n'
       '\t\taudit_log_format(ab, " tcontext=%s", scontext);\n'
       '\t\tkfree(scontext);\n'
       '\t}\n')
    b=('\trc = security_sid_to_context(sad->state, sad->tsid, &scontext,\n'
       '\t\t\t\t     &scontext_len);\n'
       '#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Audit-only presentation; never alter the real access decision. */\n'
       '\tif (static_branch_unlikely(&susfs_is_avc_log_spoofing_enabled) &&\n'
       '\t    susfs_ksu_sid && susfs_priv_app_sid &&\n'
       '\t    sad->tsid == susfs_ksu_sid) {\n'
       '\t\tif (rc)\n'
       '\t\t\taudit_log_format(ab, " tsid=%u", susfs_priv_app_sid);\n'
       '\t\telse {\n'
       '\t\t\taudit_log_format(ab, " tcontext=%s",\n'
       '\t\t\t\t         "u:r:priv_app:s0:c512,c768");\n'
       '\t\t\tkfree(scontext);\n'
       '\t\t}\n'
       '\t} else\n'
       '#endif\n'
       '\tif (rc)\n'
       '\t\taudit_log_format(ab, " tsid=%d", sad->tsid);\n'
       '\telse {\n'
       '\t\taudit_log_format(ab, " tcontext=%s", scontext);\n'
       '\t\tkfree(scontext);\n'
       '\t}\n')
    text=replace_one(text,a,b,'AVC_AUDIT')
    require(text.count('susfs_is_avc_log_spoofing_enabled')==2,'AVC_FLAG_NOT_WIRED')
    return text

def port_selinuxfs(text):
    require('ksu_selinux_hide_running' not in text,'SELINUXFS_ALREADY_PORTED')
    a='#include "objsec.h"\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/cred.h>\n'
       'extern struct page *fake_status;\n'
       'extern bool ksu_selinux_hide_running;\n'
       '#endif\n')
    text=replace_one(text,a,b,'SELINUXFS_HEADERS')
    a=('\tstruct page    *status = selinux_kernel_status_page(fsi->state);\n\n'
       '\tif (!status)\n')
    b=('\tstruct page    *status = selinux_kernel_status_page(fsi->state);\n\n'
       '#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* BakaSU manual-hook mode: serve its allocated fake page only to apps. */\n'
       '\tif (current_uid().val >= 10000 &&\n'
       '\t    READ_ONCE(ksu_selinux_hide_running) && READ_ONCE(fake_status)) {\n'
       '\t\tfilp->private_data = READ_ONCE(fake_status);\n'
       '\t\treturn 0;\n'
       '\t}\n'
       '#endif\n'
       '\tif (!status)\n')
    text=replace_one(text,a,b,'SELINUXFS_PAGE')
    return text

def scope_services(text):
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/rcupdate.h>\n'
       'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/rcupdate.h>\n'
       '#include <linux/cred.h>\n'
       'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
       'extern bool ksu_selinux_hide_running;\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_DECL')
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Exact native-5.4 type check, without replacing the policy parser. */\n'
       '\trcu_read_lock();\n'
       '\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
       '\t\trcu_read_unlock();\n'
       '\t\tgoto out;\n'
       '\t}\n'
       '\trcu_read_unlock();\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Restrict only app-facing SELinux-hide requests, not the global parser. */\n'
       '\tif (current_uid().val >= 10000 && READ_ONCE(ksu_selinux_hide_running)) {\n'
       '\t\trcu_read_lock();\n'
       '\t\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
       '\t\t\trcu_read_unlock();\n'
       '\t\t\tgoto out;\n'
       '\t\t}\n'
       '\t\trcu_read_unlock();\n'
       '\t}\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_SCOPE')
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Called only after the real policy has computed the AVD. */\n'
       '\trcu_read_lock();\n'
       '\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
       '\t\t\t\t   tclass, &avd->allowed);\n'
       '\trcu_read_unlock();\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Preserve genuine policy decisions outside the app-hide path. */\n'
       '\tif (current_uid().val >= 10000 && READ_ONCE(ksu_selinux_hide_running)) {\n'
       '\t\trcu_read_lock();\n'
       '\t\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
       '\t\t\t\t\t   tclass, &avd->allowed);\n'
       '\t\trcu_read_unlock();\n'
       '\t}\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_AVD_SCOPE')
    return text

def install(kernel, report):
    root=Path(kernel).resolve(strict=True)
    orig={}
    edited={}
    transforms={
      'security/selinux/hooks.c':port_hooks,
      'security/selinux/avc.c':port_avc,
      'security/selinux/selinuxfs.c':port_selinuxfs,
      'security/selinux/ss/services.c':scope_services,
    }
    for rel,fn in transforms.items():
        path=root/rel
        require(path.is_file() and not path.is_symlink(),'SOURCE_MISSING_OR_SYMLINK:'+rel)
        raw=path.read_bytes()
        if rel in BASE:require(gitblob(raw)==BASE[rel],'PINNED_5_4_BLOB_CHANGED:'+rel)
        orig[rel]=sha256(raw)
        edited[rel]=fn(raw.decode('utf-8'))
        require(edited[rel]!=raw.decode('utf-8'),'EMPTY_HOST_PATCH:'+rel)
    compat=root/'KernelSU/kernel/tools/susfs_compat.mk'
    require(compat.is_file() and not compat.is_symlink(),'BAKASU_SUSFS_COMPAT_MISSING')
    compat_text=compat.read_text()
    require('ksu_selinux_hide_running' in compat_text and
            'KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE' in compat_text,
            'BAKASU_MANUAL_HOOK_SWITCH_NOT_PROVEN')
    baksu=root/'KernelSU/kernel/feature/selinux_hide.c'
    require(baksu.is_file() and '#define ksu_handle_selinux_setprocattr my_setprocattr' in baksu.read_text(),
            'BAKASU_MANUAL_HOOK_FUNCTION_MISSING')
    core=root/'KernelSU/kernel/selinux/selinux.c'
    require(core.is_file() and 'susfs_priv_app_sid' in core.read_text() and 'susfs_ksu_sid' in core.read_text(),
            'BAKASU_AVC_SID_PROVIDER_MISSING')
    for rel,content in edited.items():(root/rel).write_text(content)
    # No implicit source tree or GitHub commit mutation: only isolate candidate.
    summary={
       'schema':'VEUX_R59_NATIVE54_SELINUX_HOST_V1',
       'status':'FOUR_NATIVE54_SELINUX_HOST_FILES_STAGED_FOR_REAL_COMPILER',
       'updated_host_files':{rel:{'preimage_sha256':orig[rel],
                        'postimage_sha256':sha256((root/rel).read_bytes())} for rel in transforms},
       'manual_hook_ksu_compiler_switch':'KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE',
       'manual_setprocattr_func':'my_setprocattr',
       'native_54_policy_rwlock_preserved':True,
       'selinux_app_scoped_type_filter':True,
       'avc_audit_only':True,
       'kernel_compiled':False,
       'module_vendor_abi_proven':False,
       'flash_allowed':False,
    }
    report=Path(report)
    require(report.parent.exists() and not report.exists(),'REPORT_DIR_NOT_CLEAN')
    report.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(summary['status'])
    return summary

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--kernel',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    try:install(a.kernel,a.out);return 0
    except (OSError,ValueError,GateError) as e:
        print('R59_FAIL_CLOSED='+str(e),file=sys.stderr)
        return 3
if __name__=='__main__':raise SystemExit(main())
