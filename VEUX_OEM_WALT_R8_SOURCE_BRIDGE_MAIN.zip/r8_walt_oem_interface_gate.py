#!/usr/bin/env python3
"""VEUX R8 source-only exact R6/P3/P10 WALT interface bridge. NOT A KERNEL BUILD."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

R6_HEADER_HASH = 'ccd370feb3ef9252fc8cc72c3babe460bd47c89fb48fa1d8035f9fb334d14f64'
R8_HEADER_HASH = '12f10b1be96b1868304dd0f5e85a8e4e421ae72383d8b76571a2dc91fd6d4f5d'
PATCH_HASH = 'bab1ffea709e3ef60ed27607080472336210a83a36655cde02206f51df27e203'
STOCK_CONFIG_HASH = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
R6_STATUS='WALT_R6_REAL_P3_COMPATIBILITY_PRECOMPILE_STAGED'
R7_STATUS='R7_PRECOMPILE_AUDIT_COMPLETED__WALT_ON_BLOCKED'
P3_TREE='7f97dbbff432d61bbf11cae03de257a21f1d3c74'
P10_TREE='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
FILE='kernel/sched/sched.h'

class EvidenceError(Exception):
    pass


def ensure(ok, message):
    if not ok: raise EvidenceError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cmd(args, **kwargs):
    p=subprocess.run(args,capture_output=True,text=True,**kwargs)
    return p


def verify_inputs(r6, r7, stock, patch):
    h=r6/'source'/FILE
    ensure(h.is_file() and not h.is_symlink(),'R6_HEADER_REQUIRED')
    ensure(sha(h.read_bytes())==R6_HEADER_HASH,'R6_HEADER_SHA_DRIFT')
    ensure(patch.is_file() and not patch.is_symlink() and sha(patch.read_bytes())==PATCH_HASH,'R8_PATCH_SHA_DRIFT')
    ensure(stock.is_file() and not stock.is_symlink() and sha(stock.read_bytes())==STOCK_CONFIG_HASH,'OEM_CONFIG_SHA_DRIFT')
    c=stock.read_text()
    ensure('\nCONFIG_SCHED_WALT=y\n' in '\n'+c and 'CONFIG_SPRD_ROTATION_TASK=y' not in c,'OEM_CONFIG_NOT_WALT_ONLY')
    gate=json.loads((r6/'R6_SOURCE_GATE.json').read_text())
    diag=json.loads((r7/'R7_WALT_INTERFACE_AUDIT.json').read_text())
    ensure(gate['status']==R6_STATUS and gate.get('strict_real_source') is True,'R6_SOURCE_GATE_BAD_STATUS')
    ensure(gate['p3_tree']==P3_TREE and gate['p10_composed_tree']==P10_TREE,'R6_SOURCE_TREE_DRIFT')
    ensure(gate['source_after_sha256'].get(FILE)==R6_HEADER_HASH,'R6_GATE_HEADER_IDENTITY_DRIFT')
    ensure(not any(gate.get(k) for k in ('flash_allowed','final_kernel_built','walt_on_compile_proven','vendor_crc_fixed','brene_changed')),'R6_GATE_MISREPRESENTS_BUILD')
    ensure(diag['status']==R7_STATUS and diag.get('diagnostic_completed') is True and diag['confirmed_blocker_count']==2,'R7_DIAG_MISSING_BLOCKERS')
    ensure(set(f['id'] for f in diag['findings'])=={'WALT-R7-001','WALT-R7-002'},'R7_DIAG_UNEXPECTED_BLOCKERS')
    ensure(diag['p3_tree']==P3_TREE and diag['source_walt_tree']==P10_TREE,'R7_SOURCE_TREE_DRIFT')
    ensure(diag['r6_source_after_sha256'][FILE]==R6_HEADER_HASH,'R7_HEADER_HASH_DRIFT')
    ensure(diag['oem_config_sha256']==STOCK_CONFIG_HASH,'R7_CONFIG_MISMATCH')
    ensure(not any(diag.get(k) for k in ('flash_allowed','kernel_build_attempted','walt_on_compile_proven','vendor_abi_proven','brene_changed')),'R7_DIAG_MISREPRESENTS_BUILD')
    return h.read_bytes()


def apply_patch_exact(old, patch):
    with tempfile.TemporaryDirectory(prefix='veux-r8-gate-') as tmp:
        folder=Path(tmp)
        target=folder/FILE
        target.parent.mkdir(parents=True)
        target.write_bytes(old)
        ap=['git','apply','--whitespace=error','--check',str(patch)]
        r=cmd(ap,cwd=folder)
        ensure(r.returncode==0,'R8_GIT_APPLY_CHECK_FAILED: '+r.stderr)
        r=cmd(['git','apply','--whitespace=error',str(patch)],cwd=folder)
        ensure(r.returncode==0,'R8_GIT_APPLY_FAILED: '+r.stderr)
        new=target.read_bytes()
        ensure(sha(new)==R8_HEADER_HASH,'R8_POSTIMAGE_HASH_MISMATCH')
        r=cmd(['git','apply','--whitespace=error','--reverse','--check',str(patch)],cwd=folder)
        ensure(r.returncode==0,'R8_REVERSE_CHECK_FAILED: '+r.stderr)
        return new


def c_models(header, clang):
    # Compile only the exact guard block, extracted from the verified full header.
    start=header.index(b'#ifdef CONFIG_SCHED_WALT\n/* Original Xiaomi WALT reservation interface')
    stop=header.index(b'\n#endif\n',start)+len(b'\n#endif\n')
    block=header[start:stop].decode()
    prefix='''#include <stdbool.h>\n#include <stddef.h>\ntypedef unsigned long long u64;\nstruct walt_rq { unsigned long walt_flags; };\nstruct rq { struct walt_rq wrq; };\nstatic struct rq rq0;\nstatic struct rq *cpu_rq(int c) { (void)c; return &rq0; }\nstatic int test_bit(int b, unsigned long *p) { return !!(*p & (1ul<<b)); }\nstatic int test_and_set_bit(int b, unsigned long *p) { int v=test_bit(b,p); *p|=(1ul<<b); return v; }\nstatic void clear_bit(int b, unsigned long *p) { *p &= ~(1ul<<b); }\nstatic u64 sched_clock(void) { return 2; }\n#define DECLARE_PER_CPU_SHARED_ALIGNED(t,n) static t n[2]\n#define per_cpu(n,c) n[c]\n'''
    scenarios={
      'oem_walt_on_rotation_off':('#define CONFIG_SCHED_WALT 1\n', 'u64 sched_ktime_clock(void) { return 1; }\nvoid clear_walt_request(int c) { clear_reserved(c); }\nint main(void) { mark_reserved(0); clear_walt_request(0); return is_reserved(0); }\n'),
      'legacy_walt_off_rotation_on':('#define CONFIG_SPRD_ROTATION_TASK 1\n', 'void check_for_task_rotation(struct rq *r) { (void)r; }\nu64 sched_ktime_clock(void) { return 1; }\nint main(void) { mark_reserved(0); clear_reserved(0); return is_reserved(0); }\n'),
      'legacy_walt_off_rotation_off':('', 'int main(void) { return is_reserved(0) ? 1 : sched_ktime_clock()==0; }\n'),
    }
    results={}
    for key,(defines,tail) in scenarios.items():
        snippet=prefix+defines+block+'\n'+tail
        r=cmd([clang,'-std=gnu11','-x','c','-fsyntax-only','-Werror=implicit-function-declaration','-Werror=incompatible-pointer-types','-Werror','-'],input=snippet)
        ensure(r.returncode==0,'R8_C_MODEL_'+key+'_FAILED: '+r.stderr)
        results[key]={'status':'PASS','sha256':sha(snippet.encode()),'scope':'exact extracted R8 guard plus synthetic reduced C declarations; NOT a kernel object build'}
    return results


def run(r6,r7,stock,patch,out,clang='clang'):
    ensure(not out.exists() and not out.is_symlink(),'R8_OUTPUT_ALREADY_EXISTS')
    ensure(shutil.which(clang) is not None,'CLANG_REQUIRED')
    old=verify_inputs(r6,r7,stock,patch)
    new=apply_patch_exact(old,patch)
    models=c_models(new,clang)
    ensure(b'#define CPU_RESERVED    1' in new and b'test_and_set_bit(CPU_RESERVED, &rq->wrq.walt_flags)' in new and b'clear_bit(CPU_RESERVED, &rq->wrq.walt_flags)' in new, 'OEM_WALT_BIT_OPERATIONS_MISSING')
    # Must not shift task layout, rq layout, or three-header bridge outside one file.
    report={
     'status':'R8_EXACT_R6_WALT_INTERFACE_SOURCE_BRIDGE_STAGED',
     'r6_source_gate_verified':True,'r7_diagnosis_verified':True,
     'prior_diagnosed_blockers':['WALT-R7-001','WALT-R7-002'],
     'addressed_source_interface_contracts':['sched_ktime_clock_declaration_when_WALT_ON','clear_reserved_bit_operation_when_WALT_ON'],
     'modified_files':[FILE], 'r6_header_before_sha256':R6_HEADER_HASH,'r8_header_after_sha256':R8_HEADER_HASH,
     'r8_patch_sha256':PATCH_HASH,'oem_config_sha256':STOCK_CONFIG_HASH,'p3_tree':P3_TREE,'p10_composed_tree':P10_TREE,
     'clang_interface_models':models,
     'walt_and_rotation_both_enabled':'NOT_AUDITED',
     'walt_on_kernel_object_compiled':False,'kernel_build_attempted':False,'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
     'bakasusu_nomount_changed':False,
    }
    out.mkdir(parents=True)
    target=out/'source'/FILE
    target.parent.mkdir(parents=True)
    target.write_bytes(new)
    (out/'R8_SOURCE_GATE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    (out/'R8_ERGEBNIS_DE.txt').write_text('R8 source-only: 2 R7 Schnittstellenblocker auf exakter R6-Kopie gezielt über originale Xiaomi-WALT-Bitsemantik behoben.\n3 isolierte Clang-Schnittstellenmodelle grün, kein Kernelobjekt kompiliert, OEM-ABI ungeprüft, KEIN FLASH.\nBReNE/BakaSU/SUSFS/NoMount unverändert.\n')
    return report


def main():
    p=argparse.ArgumentParser()
    for flag in ('r6','r7','stock','patch','output'):
        p.add_argument('--'+flag,required=True,type=Path)
    p.add_argument('--clang',default='clang')
    args=p.parse_args()
    try: report=run(args.r6,args.r7,args.stock,args.patch,args.output,args.clang)
    except (EvidenceError,KeyError,ValueError,FileNotFoundError) as exc:
        p.exit(1,f'R8_SOURCE_GATE_BLOCKED: {exc}\n')
    print('R8_EXACT_R6_WALT_INTERFACE_GATE=PASS; CONTRACTS=2; C_MODELS=3; BUILD=NO; ABI=UNPROVEN; FLASH=NO')
    print('R8_GATE_FILE='+str(args.output/'R8_SOURCE_GATE.json'))

if __name__=='__main__': main()
