"""R8 source-only regression: fail-closed exact R6/R7 preimages and config branches."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import tempfile
import unittest

import r8_walt_oem_interface_gate as bridge

BASE=Path(__file__).resolve().parent
F=BASE/'fixtures'
STOCK=F/'OEM_VEUX_5_4_274.config'
PATCH=BASE/'R8_WALT_OEM_INTERFACE_BRIDGE.patch'


def create_fake_workspace(root):
    shutil.copytree(F/'r6',root/'r6')
    shutil.copytree(F/'r7',root/'r7')
    shutil.copy2(STOCK,root/'config')
    shutil.copy2(PATCH,root/'patch')
    return root/'r6',root/'r7',root/'config',root/'patch'

class R8GateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old=(F/'r6/source/kernel/sched/sched.h').read_bytes()
        cls.after=(BASE/'R8_AFTER_sched.h').read_bytes() if (BASE/'R8_AFTER_sched.h').exists() else None

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='veux-r8-unit-')
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.r6,self.r7,self.conf,self.patch=create_fake_workspace(self.base)
        self.output=self.base/'output'

    def go(self):
        return bridge.run(self.r6,self.r7,self.conf,self.patch,self.output,'clang')

    def test_01_pinned_source_header(self):
        self.assertEqual(bridge.sha(self.old),bridge.R6_HEADER_HASH)

    def test_02_pinned_stock_config(self):
        self.assertEqual(bridge.sha(self.conf.read_bytes()),bridge.STOCK_CONFIG_HASH)

    def test_03_pinned_r7_two_blockers(self):
        a=json.loads((self.r7/'R7_WALT_INTERFACE_AUDIT.json').read_text())
        self.assertEqual(set(z['id'] for z in a['findings']),{'WALT-R7-001','WALT-R7-002'})

    def test_04_source_changes_just_one_file(self):
        out=bridge.apply_patch_exact(self.old,self.patch)
        self.assertEqual(bridge.sha(out),bridge.R8_HEADER_HASH)
        self.assertEqual(out.count(b'CPU_RESERVED    1'),1)
        self.assertEqual(self.old.count(b'CPU_RESERVED    1'),0)

    def test_05_replacement_preserves_all_prefix_suffix(self):
        out=bridge.apply_patch_exact(self.old,self.patch)
        st=b'#ifdef CONFIG_SPRD_ROTATION_TASK\nDECLARE_PER_CPU_SHARED_ALIGNED'
        orig=self.old.index(st)
        self.assertEqual(out[:orig],self.old[:orig])
        marker=b'\n#endif\n'
        stop_old=self.old.index(marker,orig)+len(marker)
        idx_out=out.index(b'#ifdef CONFIG_SCHED_WALT\n/* Original Xiaomi WALT reservation interface')
        stop_new=out.index(marker,idx_out)+len(marker)
        self.assertEqual(out[stop_new:],self.old[stop_old:])

    def test_06_legacy_rotation_block_retained(self):
        out=bridge.apply_patch_exact(self.old,self.patch)
        legacy=self.old[self.old.index(b'DECLARE_PER_CPU_SHARED_ALIGNED(bool, cpu_reserved);'):self.old.index(b'#else\nstatic inline bool is_reserved',self.old.index(b'DECLARE_PER_CPU_SHARED_ALIGNED(bool, cpu_reserved);'))]
        self.assertIn(legacy,out)

    def test_07_source_gate_real_fixture(self):
        r=self.go()
        self.assertTrue(r['r6_source_gate_verified'] and r['r7_diagnosis_verified'])
        self.assertEqual(r['modified_files'],['kernel/sched/sched.h'])
        self.assertFalse(r['walt_on_kernel_object_compiled'])
        self.assertFalse(r['flash_allowed'])
        self.assertFalse(r['vendor_abi_proven'])
        self.assertEqual(len(r['clang_interface_models']),3)
        self.assertTrue((self.output/'R8_SOURCE_GATE.json').is_file())

    def test_08_replay_deterministic(self):
        a=self.go()
        self.output.rename(self.base/'first')
        b=self.go()
        self.assertEqual(a,b)

    def test_09_old_header_rejected_if_tampered(self):
        h=self.r6/'source/kernel/sched/sched.h'
        h.write_bytes(h.read_bytes()+b'\n')
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_HEADER_SHA_DRIFT'):self.go()

    def test_10_missing_header_rejected(self):
        (self.r6/'source/kernel/sched/sched.h').unlink()
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_HEADER_REQUIRED'):self.go()

    def test_11_symlink_header_rejected(self):
        h=self.r6/'source/kernel/sched/sched.h';h.unlink();h.symlink_to(self.conf)
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_HEADER_REQUIRED'):self.go()

    def test_12_wrong_p3_tree_rejected(self):
        x=self.r6/'R6_SOURCE_GATE.json'; d=json.loads(x.read_text()); d['p3_tree']='0'*40;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_SOURCE_TREE_DRIFT'):self.go()

    def test_13_wrong_p10_tree_rejected(self):
        x=self.r6/'R6_SOURCE_GATE.json'; d=json.loads(x.read_text()); d['p10_composed_tree']='0'*40;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_SOURCE_TREE_DRIFT'):self.go()

    def test_14_r6_flash_flag_rejected(self):
        x=self.r6/'R6_SOURCE_GATE.json'; d=json.loads(x.read_text()); d['flash_allowed']=True;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_GATE_MISREPRESENTS_BUILD'):self.go()

    def test_15_r6_status_rejected(self):
        x=self.r6/'R6_SOURCE_GATE.json'; d=json.loads(x.read_text()); d['status']='PASS_FAKE';x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R6_SOURCE_GATE_BAD_STATUS'):self.go()

    def test_16_r7_missing_blocker_rejected(self):
        x=self.r7/'R7_WALT_INTERFACE_AUDIT.json'; d=json.loads(x.read_text());d['findings']=[d['findings'][0]]; x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R7_DIAG_UNEXPECTED_BLOCKERS'):self.go()

    def test_17_r7_wrong_header_hash_rejected(self):
        x=self.r7/'R7_WALT_INTERFACE_AUDIT.json'; d=json.loads(x.read_text());d['r6_source_after_sha256'][bridge.FILE]='0'*64;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R7_HEADER_HASH_DRIFT'):self.go()

    def test_18_r7_wrong_tree_rejected(self):
        x=self.r7/'R7_WALT_INTERFACE_AUDIT.json'; d=json.loads(x.read_text());d['source_walt_tree']='0'*40;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R7_SOURCE_TREE_DRIFT'):self.go()

    def test_19_r7_false_flash_claim_rejected(self):
        x=self.r7/'R7_WALT_INTERFACE_AUDIT.json'; d=json.loads(x.read_text());d['flash_allowed']=True;x.write_text(json.dumps(d))
        with self.assertRaisesRegex(bridge.EvidenceError,'R7_DIAG_MISREPRESENTS_BUILD'):self.go()

    def test_20_wrong_stock_config_rejected(self):
        self.conf.write_bytes(self.conf.read_bytes()+b'\n#tamper\n')
        with self.assertRaisesRegex(bridge.EvidenceError,'OEM_CONFIG_SHA_DRIFT'):self.go()

    def test_21_wrong_patch_rejected(self):
        self.patch.write_bytes(self.patch.read_bytes()+b'\n')
        with self.assertRaisesRegex(bridge.EvidenceError,'R8_PATCH_SHA_DRIFT'):self.go()

    def test_22_output_not_overwritten(self):
        self.output.mkdir()
        with self.assertRaisesRegex(bridge.EvidenceError,'R8_OUTPUT_ALREADY_EXISTS'):self.go()

    def test_23_output_symlink_rejected(self):
        self.output.symlink_to(self.r6,target_is_directory=True)
        with self.assertRaisesRegex(bridge.EvidenceError,'R8_OUTPUT_ALREADY_EXISTS'):self.go()

    def test_24_missing_clang_rejected(self):
        with self.assertRaisesRegex(bridge.EvidenceError,'CLANG_REQUIRED'):
            bridge.run(self.r6,self.r7,self.conf,self.patch,self.output,'this-clang-binary-does-not-exist')

    def test_25_second_patch_not_applied(self):
        after=bridge.apply_patch_exact(self.old,self.patch)
        with self.assertRaisesRegex(bridge.EvidenceError,'R8_GIT_APPLY_CHECK_FAILED'):
            bridge.apply_patch_exact(after,self.patch)

    def test_26_walt_on_model_compiles(self):
        x=bridge.apply_patch_exact(self.old,self.patch)
        self.assertEqual(bridge.c_models(x,'clang')['oem_walt_on_rotation_off']['status'],'PASS')

    def test_27_legacy_rotation_model_compiles(self):
        x=bridge.apply_patch_exact(self.old,self.patch)
        self.assertEqual(bridge.c_models(x,'clang')['legacy_walt_off_rotation_on']['status'],'PASS')

    def test_28_legacy_off_model_compiles(self):
        x=bridge.apply_patch_exact(self.old,self.patch)
        self.assertEqual(bridge.c_models(x,'clang')['legacy_walt_off_rotation_off']['status'],'PASS')

    def test_29_c_model_rejects_old_header(self):
        # No source guard defined until after patch: run extracted R8 interface will not exist.
        with self.assertRaises(ValueError):bridge.c_models(self.old,'clang')

    def test_30_after_contains_donor_bit_semantics(self):
        x=bridge.apply_patch_exact(self.old,self.patch)
        self.assertIn(b'test_bit(CPU_RESERVED, &rq->wrq.walt_flags)',x)
        self.assertIn(b'test_and_set_bit(CPU_RESERVED, &rq->wrq.walt_flags)',x)
        self.assertIn(b'clear_bit(CPU_RESERVED, &rq->wrq.walt_flags)',x)
        self.assertIn(b'\n#elif defined(CONFIG_SPRD_ROTATION_TASK)\n',x)

if __name__ == '__main__':unittest.main(verbosity=2)
