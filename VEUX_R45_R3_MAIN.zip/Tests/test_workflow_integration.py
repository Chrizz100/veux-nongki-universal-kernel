import unittest, pathlib, subprocess, re, os
from collections import Counter
import yaml
R=pathlib.Path(__file__).resolve().parents[1]
D=pathlib.Path(os.environ.get('R45_WORKFLOW', str(R/'VEUX_R45_R3_ROOTLESS_STOCK_GATE_NOFLASH.yml')))
ORIG=R/'References'/'ORIGINAL_R44_R2_WORKFLOW.yml'
class WorkflowIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=D.read_text()
        cls.o=ORIG.read_text()
        cls.d=yaml.safe_load(cls.raw)
        cls.job=cls.d['jobs']['p11-exact-source']
        cls.steps=cls.job['steps']
    def test_dispatch_only_and_readonly(self):
        self.assertEqual(self.d['on'],{'workflow_dispatch':{}})
        self.assertEqual(self.d['permissions'],{'contents':'read'})
        self.assertEqual(len(self.d['jobs']),1)
    def test_r44_historical_original_not_replaced(self):
        self.assertIn('name: VEUX R44-R2 R20 WALT GPU AO symbol-count fix - NO FLASH',self.o[:150])
        self.assertNotIn('R45_OUT',self.o)
        self.assertNotEqual(self.raw,self.o)
    def test_original_r44_dependency_sha_pins_unchanged(self):
        defs=re.compile(r'^\s*([A-Z0-9_]*PACKAGE_NAME):\s*([^\n]+)$',re.M)
        q=lambda s: dict(defs.findall(s))
        self.assertEqual(q(self.o),{k:v for k,v in q(self.raw).items() if k!='R45_PACKAGE_NAME'})
        self.assertEqual(q(self.raw).get('R45_PACKAGE_NAME'),'VEUX_R45_R3_MAIN.zip')
        self.assertEqual(len(q(self.o)),26)
    def test_original_r44_yaml_is_linted_by_self_test_current_new_yaml(self):
        self.assertIn("wf=pathlib.Path('project/.github/workflows/VEUX_R45_R3_ROOTLESS_STOCK_GATE_NOFLASH.yml')",self.raw)
        self.assertIn("d.get('name')=='VEUX R45-R3 Rootless Stock + Actionlint ShellCheck - NO FLASH'",self.raw)
        self.assertEqual(self.d['name'],'VEUX R45-R3 Rootless Stock + Actionlint ShellCheck - NO FLASH')
    def test_all_step_names_unique_and_count(self):
        self.assertEqual(len(self.steps),105)
        self.assertEqual(len(set(x['name'] for x in self.steps)),len(self.steps))
    def test_r45_after_fullbuild_and_r44_gate_before_upload(self):
        names=[s['name'] for s in self.steps]
        self.assertLess(names.index('R44 require genuine patched Image vmlinux DTB modules and exact reference targets'),names.index('R45 audit rootfree built kernel against authentic Stock without patching source'))
        self.assertLess(names.index('R45 audit rootfree built kernel against authentic Stock without patching source'),names.index('R45 preserve source config and kernel evidence on failures'))
    def test_r45_checked_in_source_paths_present(self):
        s=next(x for x in self.steps if x['name'].startswith('R45 audit'))
        self.assertIn('$R45_TOOLS_DIR/Tools/VEUX_R45_ROOTLESS/veux_r45_rootless_gate.py',s['run'])
        self.assertIn('$R45_TOOLS_DIR/Tools/VEUX_R45_ROOTLESS/STOCK_5.4.274_QGKI.config',s['run'])
        self.assertTrue((R/'Tools/VEUX_R45_ROOTLESS/veux_r45_rootless_gate.py').is_file())
        self.assertTrue((R/'Tools/VEUX_R45_ROOTLESS/STOCK_5.4.274_QGKI.config').is_file())
        self.assertIn('--pin-stock-only',s['run'])
        self.assertNotIn('--pin-known-config',s['run'])
    def test_build_artifacts_30_days_and_always_when_needed(self):
        raw=next(s for s in self.steps if s['name'].startswith('R20 upload unverified non-flash'))
        self.assertIn("always()",raw['if'])
        self.assertEqual(raw['with']['retention-days'],30)
        self.assertIn('${{ env.R13_OBJOUT }}/.config',raw['with']['path'])
        self.assertIn('${{ env.R13_OBJOUT }}/System.map',raw['with']['path'])
        extra=next(s for s in self.steps if s['name'].startswith('R45 preserve source'))
        self.assertEqual(extra['if'],'${{ always() }}')
        self.assertEqual(extra['with']['retention-days'],30)
    def test_shell_syntax_all_70(self):
        runs=[s['run'] for s in self.steps if 'run' in s]
        self.assertEqual(len(runs),71)
        for i,r in enumerate(runs,1):
            with self.subTest(i=i):
                p=subprocess.run(['bash','-n'],input=r,text=True,capture_output=True)
                self.assertEqual(p.returncode,0,p.stderr[:1000])
    def test_preflight_before_compilation_and_mandatory(self):
        names=[s['name'] for s in self.steps]
        pname='R45-R3 SHA-pinned MAIN: actionlint ShellCheck 32 regression tests before compiler'
        self.assertIn(pname,names)
        self.assertLess(names.index(pname),names.index('R20 genuine WALT-ON ARM64 full Image DTBs and modules make with linked vmlinux'))
        s=self.steps[names.index(pname)]
        self.assertIn('shellcheck',s['run'])
        self.assertIn('actionlint',s['run'])
        self.assertIn('VEUX_R45_R3_MAIN.zip',self.raw)
        self.assertIn('MANIFEST_SHA256.txt',s['run'])
    def test_main_zip_outside_checkout_and_p13_preserved(self):
        s=next(z for z in self.steps if z['name'].startswith('R45-R3 SHA-pinned'))
        self.assertIn('$R45_TOOLS_DIR',s['run'])
        self.assertIn('test -z "$(git -C project status --porcelain',s['run'])
        self.assertNotIn('fastboot flash',self.raw)
    def test_no_new_flash_commands(self):
        self.assertNotRegex(self.raw,r'\bfastboot\s+flash\b')
        self.assertNotRegex(self.raw,r'\badb\s+(?:reboot|shell\s+reboot)\b')
if __name__=='__main__': unittest.main()
