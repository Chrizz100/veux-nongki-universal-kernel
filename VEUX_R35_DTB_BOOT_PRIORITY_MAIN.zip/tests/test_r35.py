#!/usr/bin/env python3
"""R35: independent crosschecks, adversarial inputs, and strict no-flash gates."""
import collections
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import unittest
import zipfile

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
import r34_gate
import r35_audit as r35


def read_artifact():
    return r35.evidence_zip((BASE/'evidence/R34_GITHUB_RESULT.zip').read_bytes())


def read_65():
    z=read_artifact()
    return [r for r in r35.matrix_rows(z['R34_DEVICE_TREE_MATRIX.csv'],{'device_node_path'})
            if r['stock_driver_bindings'] and r['any_r20_dtb_compatible_overlap']=='False']


class TestInputs(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.z=read_artifact()
        cls.dev=r34_gate.parse_new_device_zip((BASE/'evidence/R34_DEVICE_EVIDENCE.zip').read_bytes())

    def test_01_manifest(self): self.assertIn('files',r35.verified_bundle(BASE))
    def test_02_manifest_count(self): self.assertGreaterEqual(len(r35.verified_bundle(BASE)['files']),10)
    def test_03_orig_r34_artifact_sha(self):
        self.assertEqual(r35.sha((BASE/'evidence/R34_GITHUB_RESULT.zip').read_bytes()),r35.PINNED_ANCHORS['evidence/R34_GITHUB_RESULT.zip'])
    def test_04_orig_device_sha(self):
        self.assertEqual(r35.sha((BASE/'evidence/R34_DEVICE_EVIDENCE.zip').read_bytes()),r35.PINNED_ANCHORS['evidence/R34_DEVICE_EVIDENCE.zip'])
    def test_05_r20_dtb_sha(self):
        self.assertEqual(r35.sha((BASE/'evidence/R20_VEUX.dtb').read_bytes()),r35.PINNED_ANCHORS['evidence/R20_VEUX.dtb'])
    def test_06_r20_symvers_sha(self):
        self.assertEqual(r35.sha((BASE/'evidence/R20_Module.symvers').read_bytes()),r35.PINNED_ANCHORS['evidence/R20_Module.symvers'])
    def test_07_imports_sha(self):
        self.assertEqual(r35.sha((BASE/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes()),r35.PINNED_ANCHORS['evidence/R21_VENDOR_IMPORTS.csv'])
    def test_08_r34_artifact_five_files(self): self.assertEqual(set(self.z),r35.EXPECTED_REPORTS)
    def test_09_r34_status(self):
        self.assertEqual(json.loads(self.z['R34_RESULT.json'])['status'],'CURRENT_DEVICE_NODES_COMPARED_BOOT_BLOCKED')
    def test_10_r34_never_flash(self):
        j=json.loads(self.z['R34_RESULT.json']);self.assertFalse(j['flash_allowed']);self.assertFalse(j['boot_ready'])
    def test_11_device_schema(self):
        self.assertEqual(self.dev['schema'],'VEUX_R34_DEVICE_DRIVER_BINDINGS_V1')
    def test_12_stock_kernel_version(self):
        self.assertEqual(self.dev['kernel_release'],'5.4.274-qgki-g82179e362f33')
    def test_13_stock_nodes(self): self.assertEqual(len(self.dev['device_nodes']),754)
    def test_14_stock_loaded_only_two(self):
        self.assertEqual(sorted(self.dev['loaded_module_names']),['rmnet_offload','rmnet_shs'])
    def test_15_stock_bound_503(self):
        self.assertEqual(sum(bool(n['stock_bound_drivers']) for n in self.dev['device_nodes']),503)
    def test_16_r20_nodes_1829(self):
        self.assertEqual(len(r34_gate.fdt_nodes((BASE/'evidence/R20_VEUX.dtb').read_bytes())),1829)
    def test_17_matrix_reconstruction(self):
        rows,_,_=r35.compare_r34_matrix(BASE,self.z);self.assertEqual(len(rows),754)
    def test_18_abi_independent(self):
        rows,counts=r35.verify_abi(BASE,self.z)
        self.assertEqual(len(rows),218);self.assertEqual(sum(counts.values()),14648)
    def test_19_abi_values(self):
        _,v=r35.verify_abi(BASE,self.z)
        self.assertEqual([v['MATCH'],v['CRC_MISMATCH'],v['ABSENT_IN_R20_SYMVERS']],[6960,7653,35])
    def test_20_compatible_553(self):
        a=r35.matrix_rows(self.z['R34_DEVICE_TREE_MATRIX.csv'],{'device_node_path'})
        self.assertEqual(sum(x['any_r20_dtb_compatible_overlap']=='True' for x in a),553)
    def test_21_bound_no_overlap_65(self):self.assertEqual(len(read_65()),65)
    def test_22_same_path_5(self):
        self.assertEqual(sum(x['r20_dtb_path_also_present']=='True' for x in read_65()),5)
    def test_23_unmatched_no_path_60(self):
        self.assertEqual(sum(x['r20_dtb_path_also_present']=='False' for x in read_65()),60)
    def test_24_ufs_no_common_compatible(self):
        u=[n for n in read_65() if 'ufsphy_mem' in n['device_node_path']]
        self.assertEqual(len(u),1)
        self.assertEqual(u[0]['any_r20_dtb_compatible_overlap'],'False')
    def test_25_ufs_dtb_path_exists_but_empty_compatible(self):
        x={n['path']:n for n in r34_gate.fdt_nodes((BASE/'evidence/R20_VEUX.dtb').read_bytes())}
        self.assertEqual(x['/soc/ufsphy_mem@4807000']['compatible'],[])
    def test_26_r20_dtb_is_standalone_no_overlay_claim(self):
        self.assertNotIn('overlay_applied',json.loads(self.z['R34_RESULT.json']))

class TestClassification(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.nodes=read_65()
    def get(self,text):return next(r for r in self.nodes if text in r['device_node_path'])
    def test_27_ufs_first(self):
        self.assertEqual(r35.classify(self.get('/ufsphy_mem@'))[:2],('UFS_STORAGE_PHY','A'))
    def test_28_pmic_priority(self):
        self.assertEqual(r35.classify(self.get('/qcom,pm6125@0/pinctrl@c000'))[:2],('PMIC_REGULATOR','A'))
    def test_29_regulator_priority(self):
        self.assertEqual(r35.classify(self.get('/display_gpio_regulator@'))[:2],('PMIC_REGULATOR','A'))
    def test_30_charger_priority(self):
        self.assertEqual(r35.classify(self.get('sc8551-charger@66'))[:2],('CHARGING_USB_PD','B'))
    def test_31_touch_priority(self):
        self.assertEqual(r35.classify(self.get('goodix-gtx8@5d'))[:2],('DISPLAY_TOUCH','B'))
    def test_32_display_priority(self):
        self.assertEqual(r35.classify(self.get('/qcom,dsi-display-primary'))[:2],('DISPLAY_TOUCH','B'))
    def test_33_camera_not_boot_proof(self):
        self.assertEqual(r35.classify(self.get('/qcom,cam-res-mgr'))[:2],('CAMERA','C'))
    def test_34_audio_not_boot_proof(self):
        self.assertEqual(r35.classify(self.get('/rx-macro@'))[:2],('AUDIO','C'))
    def test_35_fingerprint_not_screen(self):
        self.assertEqual(r35.classify(self.get('/goodix_fp'))[:2],('FINGERPRINT','C'))
    def test_36_haptics_not_critical(self):
        self.assertEqual(r35.classify(self.get('/aw8624_haptic@'))[:2],('HAPTICS','C'))
    def test_37_65_all_classified(self):
        self.assertEqual(sum(1 for n in self.nodes if r35.classify(n)[0]),65)
    def test_38_synthetic_unknown_fails_to_optional(self):
        group,prior,_=r35.classify({'device_node_path':'/extra/example','device_compatibles':'unknown','stock_driver_bindings':'platform:foobar'})
        self.assertEqual((group,prior),('OTHER_PERIPHERAL','C'))

class TestAdversarial(unittest.TestCase):
    def test_39_missing_report_member_rejected(self):
        with zipfile.ZipFile(io.BytesIO(),'w') as _:pass
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('R34_RESULT.json','{}')
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_40_duplicate_report_member_rejected(self):
        b=io.BytesIO()
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(b,'w') as z:
                z.writestr('R34_RESULT.json','{}');z.writestr('R34_RESULT.json','{}')
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_41_traversal_member_rejected(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:z.writestr('../danger.txt','x')
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_42_zip_symlink_rejected(self):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            x=zipfile.ZipInfo('R34_RESULT.json');x.create_system=3;x.external_attr=((stat.S_IFLNK|0o777)<<16);z.writestr(x,'link')
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_43_bad_checksum_line_rejected(self):
        files=read_artifact();files['SHA256SUMS.txt']=b'not sha  R34_RESULT.json\n'
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for name,blob in files.items():z.writestr(name,blob)
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_44_corrupted_report_rejected(self):
        files=read_artifact();files['R34_RESULT.json']+=b'WRONG'
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for name,blob in files.items():z.writestr(name,blob)
        with self.assertRaises(ValueError):r35.evidence_zip(b.getvalue())
    def test_45_wrong_matrix_columns_rejected(self):
        with self.assertRaises(ValueError):r35.matrix_rows(b'hello\nworld\n',{'stock_node'})
    def test_46_mutated_754_matrix_rejected(self):
        z=read_artifact();lines=z['R34_DEVICE_TREE_MATRIX.csv'].decode().splitlines()
        # Alter one stock driver while preserving parseability
        rows=list(csv.DictReader(lines));rows[0]['device_node_path']='/forged_path'
        o=io.StringIO();w=csv.DictWriter(o,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        z['R34_DEVICE_TREE_MATRIX.csv']=o.getvalue().encode()
        with self.assertRaises(ValueError):r35.compare_r34_matrix(BASE,z)
    def test_47_mutated_vendor_crc_rejected(self):
        z=read_artifact();rows=list(csv.DictReader(z['R34_VENDOR_MATRIX.csv'].decode().splitlines()))
        rows[0]['historical_crc_matches']=int(rows[0]['historical_crc_matches'])+1
        o=io.StringIO();w=csv.DictWriter(o,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        z['R34_VENDOR_MATRIX.csv']=o.getvalue().encode()
        with self.assertRaises(ValueError):r35.verify_abi(BASE,z)
    def test_48_false_vendor_load_claim_rejected(self):
        z=read_artifact();rows=list(csv.DictReader(z['R34_VENDOR_MATRIX.csv'].decode().splitlines()))
        rows[0]['evidence_role']='ALWAYS_REQUIRED_AND_LOADED'
        o=io.StringIO();w=csv.DictWriter(o,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        z['R34_VENDOR_MATRIX.csv']=o.getvalue().encode()
        with self.assertRaises(ValueError):r35.verify_abi(BASE,z)
    def test_49_manifest_extra_file_rejected(self):
        # Uses symlink-free hardcopy for manifest guard, not actual project dir
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)
            shutil.copytree(BASE,target/'p')
            (target/'p'/'unexpected').write_text('x')
            with self.assertRaises(ValueError):r35.verified_bundle(target/'p')
    def test_50_manifest_bad_hash_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            target=Path(d)
            shutil.copytree(BASE,target/'p')
            (target/'p'/'README_ZUERST_DE.txt').write_text('TAMPER')
            with self.assertRaises(ValueError):r35.verified_bundle(target/'p')

class TestOutput(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.out=Path(cls.temp.name)/'out'
        cls.result=r35.audit(BASE,cls.out)
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_51_output_65(self):self.assertEqual(self.result['stock_bound_without_r20_compatible_overlap'],65)
    def test_52_output_5_and_60(self):self.assertEqual((self.result['unmatched_nodes_with_same_r20_path'],self.result['unmatched_nodes_without_r20_path']),(5,60))
    def test_53_critical_group_count(self):self.assertEqual(self.result['group_counts']['PMIC_REGULATOR'],25)
    def test_54_all_group_counts(self):self.assertEqual(sum(self.result['group_counts'].values()),65)
    def test_55_gate_boot_false(self):self.assertIs(self.result['boot_ready'],False)
    def test_56_gate_vendor_false(self):self.assertIs(self.result['vendor_abi_proven'],False)
    def test_57_gate_flash_false(self):self.assertIs(self.result['flash_allowed'],False)
    def test_58_gate_kernelbuild_false(self):self.assertIs(self.result['kernel_built'],False)
    def test_59_gate_brene_false(self):self.assertIs(self.result['brene_changed'],False)
    def test_60_gate_source_patch_false(self):self.assertIs(self.result['source_patch_created'],False)
    def test_61_report_set_only_text(self):self.assertEqual({p.name for p in self.out.iterdir()},set(r35.REPORT_NAMES))
    def test_62_report_hashes(self):
        for line in (self.out/'SHA256SUMS.txt').read_text().splitlines():
            h,name=line.split('  ')
            self.assertEqual(hashlib.sha256((self.out/name).read_bytes()).hexdigest(),h)
    def test_63_names_cannot_prove_load(self):
        rows=list(csv.DictReader((self.out/'R35_VENDOR_NAMENSKANDIDATEN.csv').read_text().splitlines()))
        self.assertTrue(rows)
        self.assertEqual({x['source_association_status'] for x in rows},{'NAME_ONLY_NOT_DRIVER_BINDING_OR_LOAD_PROOF'})
    def test_64_every_unknown_driver_flagged(self):
        rows=list(csv.DictReader((self.out/'R35_65_KNOTEN_PRIORITAET.csv').read_text().splitlines()))
        self.assertEqual({x['r20_driver_probed'] for x in rows},{'NOT_TESTED'})
    def test_65_ufs_only_one_priority(self):
        rows=list(csv.DictReader((self.out/'R35_65_KNOTEN_PRIORITAET.csv').read_text().splitlines()))
        self.assertEqual(len([x for x in rows if x['investigation_group']=='UFS_STORAGE_PHY']),1)

if __name__=='__main__':unittest.main(verbosity=2)
