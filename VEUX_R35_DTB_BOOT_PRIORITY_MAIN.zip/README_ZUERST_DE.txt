VEUX R35 – priorisierte DTB/DTBO- und Vendor-ABI-Quelluntersuchung

KEIN KERNELBUILD, KEIN FLASH, KEIN AK3, KEINE GERAETEAENDERUNG.

Dieses Paket enthält Originalnachweise aus R20/R21/R32/R33/R34, den R35-Auswerter,
39+ Sicherheits-/Regressionstests und actionlint 1.7.12. Die SHA-256 aller Dateien
stehen im MANIFEST_SHA256.json. Die R34-Originale sind zusaetzlich fest gepinnt.

Die 65 gebundenen Stock-Knoten ohne gemeinsame compatible zum einzelnen R20-DTB
sind keine nachgewiesenen Kerneldefekte! Die DTBO-Overlays, Quellen und eine
R20-Treiberbindung sind NICHT durch dieses Paket bewiesen.

Repo: Chrizz100/veux-nongki-universal-kernel
ROOT: VEUX_R35_DTB_BOOT_PRIORITY_MAIN.zip (unveraendert hochladen)
WORKFLOW: .github/workflows/VEUX_R35_DTB_BOOT_PRIORITY_GATE.yml

Unter GitHub Actions "VEUX R35" manuell starten. Das Ergebnis unter Artifacts
enthaelt NUR Berichte in JSON/CSV/TXT und ihre Pruefsummen; keine flashbaren Dateien.

R20-R11, BReNE, BakaSU, SUSFS und NoMount bleiben unveraendert.
