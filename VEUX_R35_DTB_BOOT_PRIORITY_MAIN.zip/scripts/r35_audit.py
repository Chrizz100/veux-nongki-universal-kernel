#!/usr/bin/env python3
"""VEUX R35: independent evidence-bound triage of R34 DT / Vendor ABI findings.

Read-only. This is a structured review queue, NOT a driver compatibility,
boot readiness, ABI acceptance, install, or flash test. Never manufactures patches.
"""
from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import io
import json
import pathlib
import re
import stat
import sys
import zipfile

import r34_gate

BASE_SCHEMA = 'VEUX_R35_DT_VENDOR_BOOT_TRIAGE_V1'
EXPECTED_REPORTS = frozenset({
    'R34_RESULT.json', 'R34_BERICHT_DE.txt', 'R34_DEVICE_TREE_MATRIX.csv',
    'R34_VENDOR_MATRIX.csv', 'SHA256SUMS.txt',
})
PINNED_ANCHORS = {
    'evidence/R34_GITHUB_RESULT.zip': '8a387c220e1937e1b567d569c192c3628d8d9db52c6b56aabec7e8d947b2d0d1',
    'evidence/R34_DEVICE_EVIDENCE.zip': 'b779f0352670aa1d2a3b41204b9a46fa5e597f3005f40c079e9d3a9fce657f0b',
    'evidence/R20_VEUX.dtb': '42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
    'evidence/R20_Module.symvers': '5131e75259d76acd00e08143d76d22d04d1ec86b18b0d70b84fa05b7e1e4049d',
    'evidence/R21_VENDOR_IMPORTS.csv': 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394',
}
REPORT_NAMES = (
    'R35_RESULT.json', 'R35_BERICHT_DE.txt', 'R35_65_KNOTEN_PRIORITAET.csv',
    'R35_GRUPPEN.csv', 'R35_VENDOR_NAMENSKANDIDATEN.csv', 'SHA256SUMS.txt',
)


def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def verified_bundle(base: pathlib.Path) -> dict:
    manifest = json.loads((base / 'MANIFEST_SHA256.json').read_bytes())
    if manifest.get('schema') != 'VEUX_R35_MANIFEST_V1':
        raise ValueError('R35_MANIFEST_SCHEMA_INVALID')
    mapping = manifest.get('files')
    if not isinstance(mapping, dict) or not set(PINNED_ANCHORS).issubset(mapping):
        raise ValueError('R35_MANIFEST_INCOMPLETE')
    actual = {p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
    if actual != set(mapping) | {'MANIFEST_SHA256.json'}:
        raise ValueError('R35_MANIFEST_FILE_SET_CHANGED')
    for rel, proof in mapping.items():
        path = pathlib.PurePosixPath(rel)
        if path.is_absolute() or '..' in path.parts or '\\' in rel:
            raise ValueError('R35_MANIFEST_UNSAFE_PATH')
        p = base.joinpath(*path.parts)
        if p.is_symlink() or not p.is_file():
            raise ValueError('R35_MANIFEST_MISSING_OR_SYMLINK')
        b = p.read_bytes()
        if not isinstance(proof,dict) or proof.get('bytes') != len(b) or proof.get('sha256') != sha(b):
            raise ValueError('R35_MANIFEST_HASH_MISMATCH:' + rel)
    for rel, expected in PINNED_ANCHORS.items():
        if mapping[rel]['sha256'] != expected:
            raise ValueError('R35_PINNED_ANCHOR_CHANGED:'+rel)
    return manifest


def evidence_zip(blob: bytes) -> dict[str,bytes]:
    result = r34_gate.read_zip_strict(blob, EXPECTED_REPORTS, 2_000_000)
    sums = result['SHA256SUMS.txt'].decode('utf-8')
    listed = {}
    for line in sums.splitlines():
        m = re.fullmatch(r'([0-9a-f]{64})  ([^/\\]+)', line)
        if not m or m[2] in listed:
            raise ValueError('R35_INVALID_REPORT_SUMS')
        listed[m[2]] = m[1]
    if set(listed) != EXPECTED_REPORTS - {'SHA256SUMS.txt'}:
        raise ValueError('R35_REPORT_SUMS_INCOMPLETE')
    for k, digest in listed.items():
        if sha(result[k]) != digest:
            raise ValueError('R35_REPORT_HASH_MISMATCH:'+k)
    return result


def matrix_rows(raw: bytes, must_columns: set[str]) -> list[dict]:
    records = list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    if not records or not must_columns <= set(records[0]):
        raise ValueError('R35_REPORT_MATRIX_COLUMNS_INVALID')
    return records


def compare_r34_matrix(base: pathlib.Path, z: dict[str,bytes]):
    # Independently reconstruct all 754 R34 matrix rows from the stock capture
    # and the original 1829-node R20 *standalone* DTB.
    device = r34_gate.parse_new_device_zip((base/'evidence/R34_DEVICE_EVIDENCE.zip').read_bytes())
    r20_nodes = r34_gate.fdt_nodes((base/'evidence/R20_VEUX.dtb').read_bytes())
    rows = matrix_rows(z['R34_DEVICE_TREE_MATRIX.csv'], {
        'device_node_path', 'device_compatibles', 'stock_status',
        'stock_driver_bindings', 'r20_dtb_path_also_present',
        'any_r20_dtb_compatible_overlap', 'common_compatible',
        'r20_driver_compiled_or_probed'})
    calculated = r34_gate.tree_matrix(r20_nodes, device)
    if len(device['device_nodes']) != 754 or len(r20_nodes) != 1829 or len(rows) != 754:
        raise ValueError('R35_DEVICE_OR_R20_NODE_COUNT_CHANGED')
    for i,(saved, recreated) in enumerate(zip(rows,calculated)):
        for key, value in recreated.items():
            if saved.get(key) != str(value):
                raise ValueError('R35_DEVICE_TREE_ROW_MISMATCH:'+str(i)+':'+key)
    if device.get('read_only') is not True or device.get('status') != 'CURRENT_NODES_ENUMERATED':
        raise ValueError('R35_DEVICE_CAPTURE_NOT_COMPLETE')
    if device.get('warnings') or device.get('tree_scan',{}).get('property_errors') != 0:
        raise ValueError('R35_DEVICE_CAPTURE_WARNINGS')
    if sorted(device.get('loaded_module_names',[])) != ['rmnet_offload','rmnet_shs']:
        raise ValueError('R35_LOADED_MODULES_DIFFER_FROM_R34')
    return rows,r20_nodes,device


def verify_abi(base: pathlib.Path, z: dict[str, bytes]):
    symvers = r34_gate.parse_symvers((base/'evidence/R20_Module.symvers').read_bytes())
    imports,counts = r34_gate.vendor_rows(
        (base/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes(),symvers)
    old = matrix_rows(z['R34_VENDOR_MATRIX.csv'],{
        'module_list','module_path','module','historical_imports',
        'historical_crc_matches','historical_crc_mismatches',
        'historical_exports_absent','evidence_role'})
    if len(old)!=218:
        raise ValueError('R35_VENDOR_LIST_CHANGED')
    for r in old:
        path=r['module_path']
        if not path.startswith('/vendor/lib/modules/') or path not in imports:
            raise ValueError('R35_VENDOR_PATH_NOT_IN_ORIGINAL_IMPORTS')
        expected=imports[path]
        for col,val in [
            ('historical_imports',sum(expected.values())),
            ('historical_crc_matches',expected['MATCH']),
            ('historical_crc_mismatches',expected['CRC_MISMATCH']),
            ('historical_exports_absent',expected['ABSENT_IN_R20_SYMVERS'])]:
            if int(r[col]) != val:
                raise ValueError('R35_VENDOR_MATRIX_TAMPER:'+path+':'+col)
        if r['evidence_role'] != 'LISTED_NOT_PROOF_OF_LOADED_OR_REQUIRED':
            raise ValueError('R35_VENDOR_ROLE_FALSE_CLAIM')
    return old,counts


# Transparent inspection order. These are NOT claims of missing drivers or proof
# of boot-criticality; they determine the next *manual source investigation*.
def classify(row: dict) -> tuple[str,str,str]:
    p=row['device_node_path'].lower()
    c=row['device_compatibles'].lower()
    d=row['stock_driver_bindings'].lower()
    both=' '.join((p,c,d))
    if 'ufsphy' in both or 'ufs-phy' in both:
        return 'UFS_STORAGE_PHY','A','Speicheranbindung zuerst untersuchen; kein nachgewiesener Ausfall'
    if ('qcom,spmi@' in p or 'pmic' in both or 'regulator' in both or 'power-on' in both
            or 'spmi-' in c or 'qpnp' in both or 'adc-tm' in both):
        return 'PMIC_REGULATOR','A','PMIC-/Regler- und Versorgungspfad quellenbasiert abgleichen'
    if any(w in both for w in ('sc8551','bq258','bq27','charger','pd_adapter','pd-manager','usb_type_c','wt_chg','rt1711')):
        return 'CHARGING_USB_PD','B','Laden und USB-PD inklusive Offline-Laden gesondert pruefen'
    if ('goodix_fp' in both or 'fpc1020' in both or 'fingerprint' in both or 'silead_fp' in both):
        return 'FINGERPRINT','C','Biometrie-Treiber spaeter aus zugehoeriger Quelle abgleichen'
    if ('aw8624' in both or 'haptic' in both):
        return 'HAPTICS','C','Haptik als Peripherie behandeln'
    if ('dsi-display' in both or 'display_' in both or 'display_gpio' in both
            or 'goodix,gt9896' in both or 'goodix,gtx' in both or 'gtx8' in both):
        return 'DISPLAY_TOUCH','B','Display/Touch-Quellen und aktives DTBO gemeinsam vergleichen'
    if ('/qcom,cci0/' in p or 'cam-' in both or 'camera' in both or 'eeprom' in both or 'actuator' in both):
        return 'CAMERA','C','Kamera-Treiber nach Boot-Kernpfaden isoliert untersuchen'
    if ('/qcom,msm-audio-apr/' in p or 'wcd937' in both or 'swr-' in both or 'aw882xx' in both):
        return 'AUDIO','C','Audio-Codecs/Makros und Vendor-Multimedia getrennt abgleichen'
    if 'gpio-keys' in both or 'gpio_keys' in both:
        return 'INPUT_KEYS','B','Hardwaretasten und Wakeup separat vergleichen'
    if 'fpc' in both or 'goodix' in both:
        return 'FINGERPRINT_OR_INPUT','C','Treiberidentitaet quellbasiert klaeren'
    return 'OTHER_PERIPHERAL','C','Treiber-/Overlay-Zuordnung bislang nicht bewiesen'


VENDOR_HINTS={
    # Filename indicators only. They are NOT bindings, loads or requirements.
    'UFS_STORAGE_PHY': ('ufs', 'phy'),
    'PMIC_REGULATOR': ('qpnp', 'spmi', 'regulator','pmic', 'smb5'),
    'CHARGING_USB_PD': ('charger','smb5','typec','usbpd','fuel','battery'),
    'DISPLAY_TOUCH': ('msm_drm','touch','goodix','focal','dsi'),
    'CAMERA': ('camera','cci'),
    'AUDIO': ('audio','wcd','macro','aw882','swr'),
    'INPUT_KEYS': ('gpio_keys',),
    'FINGERPRINT': ('fingerprint','fpc','goodix_fp'),
    'FINGERPRINT_OR_INPUT': ('fingerprint','goodix_fp','fpc'),
    'HAPTICS': ('aw8624','haptic'),
    'OTHER_PERIPHERAL': (),
}


def audit(base: pathlib.Path, output: pathlib.Path) -> dict:
    manifest=verified_bundle(base)
    artifact=evidence_zip((base/'evidence/R34_GITHUB_RESULT.zip').read_bytes())
    official=json.loads(artifact['R34_RESULT.json'])
    if not (official.get('schema')=='VEUX_R34_STATIC_VENDOR_DTB_ABI_GATE_V1'
        and official.get('status')=='CURRENT_DEVICE_NODES_COMPARED_BOOT_BLOCKED'
        and official.get('fresh_device_capture_present') is True
        and official.get('r20_six_modules_crc_matching')==307
        and official.get('vendor_abi_proven') is False
        and official.get('boot_ready') is False
        and official.get('flash_allowed') is False):
        raise ValueError('R35_R34_OFFICIAL_RESULT_UNTRUSTED')
    r32=json.loads((base/'evidence/R32_RESULT.json').read_bytes())
    r33=json.loads((base/'evidence/R33_RESULT.json').read_bytes())
    if (r32.get('r20_matching_imports')!=307 or r32.get('boot_ready') is not False
        or r33.get('status')!='DEVICE_CAPTURE_ANALYZED_WITH_BOOT_BLOCKERS'
        or r33.get('vendor_abi_proven') is not False):
        raise ValueError('R35_R32_R33_GATES_INVALID')
    rows,r20_nodes,device=compare_r34_matrix(base,artifact)
    vendors,crc=verify_abi(base,artifact)
    if (official.get('fresh_device_tree_nodes')!=754 or official.get('fresh_stock_driver_bound_nodes')!=503
        or official.get('fresh_nodes_sharing_any_r20_dtb_compatible')!=553
        or official.get('historical_vendor_imports')!=14648
        or official.get('historical_vendor_import_matches')!=6960
        or official.get('historical_vendor_import_crc_mismatches')!=7653
        or official.get('historical_vendor_import_missing_exports')!=35):
        raise ValueError('R35_CROSSREPORT_COUNT_WRONG')
    r20_by_path={r['path']:r for r in r20_nodes}
    unmatched=[]
    groupcounts=collections.Counter()
    samepath=0
    for row in rows:
        if not row['stock_driver_bindings'] or row['any_r20_dtb_compatible_overlap']!='False':
            continue
        group,priority,reason=classify(row)
        old=r20_by_path.get(row['device_node_path'])
        if old is not None:samepath+=1
        groupcounts[group]+=1
        unmatched.append({
            'stock_node':row['device_node_path'],
            'stock_compatible':row['device_compatibles'],
            'stock_bound_driver':row['stock_driver_bindings'],
            'r20_path_present':bool(old),
            'r20_same_path_compatible':' | '.join(old['compatible']) if old else '',
            'difference_kind':'R20_PATH_PRESENT_NO_COMMON_COMPATIBLE' if old else 'R20_STANDALONE_PATH_ABSENT',
            'investigation_group':group,'review_order':priority,
            'review_reason_not_driver_failure':reason,
            'r20_driver_probed':'NOT_TESTED',
        })
    if len(unmatched)!=65:
        raise ValueError('R35_UNRESOLVED_SET_NOT_65:'+str(len(unmatched)))
    if samepath!=5:
        raise ValueError('R35_R20_SAME_PATH_COUNT_CHANGED:'+str(samepath))
    if sum(x['review_order']=='A' for x in unmatched)==0:
        raise ValueError('R35_NO_BOOT_CHAIN_PRIORITY')
    # The heuristic candidate list is explicit, small, and never taken as proof.
    candidates=[]
    for group,hints in VENDOR_HINTS.items():
        for item in vendors:
            basename=item['module'].lower()
            hit=next((term for term in hints if term in basename),None)
            if hit is not None and group in groupcounts:
                candidates.append({
                    'investigation_group':group,'historical_vendor_module_path':item['module_path'],
                    'filename_indicator':hit,
                    'historical_crc_matches':int(item['historical_crc_matches']),
                    'historical_crc_mismatches':int(item['historical_crc_mismatches']),
                    'historical_missing_exports':int(item['historical_exports_absent']),
                    'source_association_status':'NAME_ONLY_NOT_DRIVER_BINDING_OR_LOAD_PROOF',
                })
    candidates=sorted(candidates,key=lambda x:(x['investigation_group'],x['historical_vendor_module_path']))
    groups=[]
    for g,n in sorted(groupcounts.items(),key=lambda kv:(min(x['review_order'] for x in unmatched if x['investigation_group']==kv[0]),-kv[1],kv[0])):
        subset=[x for x in unmatched if x['investigation_group']==g]
        groups.append({'group':g, 'nodes':n,
            'review_order':subset[0]['review_order'],
            'r20_same_path_nodes':sum(x['r20_path_present'] for x in subset),
            'historical_vendor_filename_candidates':sum(x['investigation_group']==g for x in candidates),
            'driver_failure_proven':False,
        })
    result={
        'schema':BASE_SCHEMA,'status':'R35_EVIDENCE_PROVEN_PRIORITY_ONLY_BOOT_BLOCKED',
        'r34_run':40069849993,'r34_commit':'9bdbf7973d7fd767046374d26eeadec80fe2a51d',
        'r34_device_capture_utc':device['captured_utc'],
        'r20_dtb_nodes':len(r20_nodes),'device_nodes':len(rows),
        'stock_driver_bound_nodes':503,'r20_dtb_compatible_overlap_nodes':553,
        'stock_bound_without_r20_compatible_overlap':len(unmatched),
        'unmatched_nodes_with_same_r20_path':samepath,
        'unmatched_nodes_without_r20_path':len(unmatched)-samepath,
        'group_counts':dict(groupcounts),
        'historical_vendor_imports':sum(crc.values()),
        'historical_vendor_crc_matches':crc['MATCH'],
        'historical_vendor_crc_mismatches':crc['CRC_MISMATCH'],
        'historical_vendor_missing_exports':crc['ABSENT_IN_R20_SYMVERS'],
        'r20_own_module_crc_matches':307,
        'currently_loaded_modules':device['loaded_module_names'],
        'historical_vendor_list_is_not_loaded_proof':True,
        'r20_compatible_overlap_is_not_driver_proof':True,
        'no_overlay_reconstruction_or_source_driver_probe':True,
        'next_proof_steps':[
            'R20 standalone-DTB gegen tatsaechliche VEUX-DTBO-Overlays und finale Laufzeit-Baumknoten abgleichen, ohne DTBO-Wahl zu erfinden.',
            'Fuer UFS-/PMIC-/Reglerknoten originale VEUX-Treiber und R20-Kconfig/Kbuild/OF-match Tabellen an gepinnten Quellcommits pruefen.',
            'Danach erst Vendor-Module fuer belegte benoetigte Treiber und exakt passende Moduldateien gegen R20-Module.symvers pruefen.',
            'Unveraenderten Stock-boot.img-Rueckfall und echten statischen Boot-/ABI-Test vor irgendeiner Flashfreigabe nachweisen.'
        ],
        'vendor_abi_proven':False,'r20_driver_bindings_proven':False,
        'boot_ready':False,'flash_allowed':False,'kernel_built':False,
        'source_patch_created':False,'device_modified':False,
        'brene_changed':False,'bakasusu_nomount_changed':False,
        'limitations':[
            'A/B/C kennzeichnet nur die Reihenfolge der Untersuchung, NICHT nachgewiesenes Ausfallrisiko.',
            'Der Vergleich nutzt ein einzelnes R20-DTB, nicht ein sicher rekonstruiertes aktives R20-DTB-plus-DTBO.',
            'Ein fehlendes compatible oder ein fehlender Pfad beweist keinen fehlenden Kerneltreiber.',
            'Stock-Treiberbindungen beweisen keinen R20-Treiberprobe.',
            'Vendor-Modulnamen belegen weder Ladequelle noch Boot-Pflicht.',
            'Kein aktueller R20-Boot, keine SELinux/VINTF/WALT/BakaSU/SUSFS/NoMount-Freigabe.'
        ],
    }
    output.mkdir(parents=True,exist_ok=True)
    (output/'R35_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
    def csvout(name, records, keys):
        with (output/name).open('w',encoding='utf8',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=keys,lineterminator='\n')
            writer.writeheader();writer.writerows(records)
    csvout('R35_65_KNOTEN_PRIORITAET.csv',unmatched,list(unmatched[0]))
    csvout('R35_GRUPPEN.csv',groups,list(groups[0]))
    csvout('R35_VENDOR_NAMENSKANDIDATEN.csv',candidates,list(candidates[0]) if candidates else [
        'investigation_group','historical_vendor_module_path','filename_indicator',
        'historical_crc_matches','historical_crc_mismatches','historical_missing_exports',
        'source_association_status'])
    text=[
        'VEUX R35 – Nachgewiesene Quellen und priorisierte Untersuchung, KEINE Boot-/Flashfreigabe',
        'GitHub-R34-Originalartefakt: Run 40069849993, SHA-256 '+PINNED_ANCHORS['evidence/R34_GITHUB_RESULT.zip'],
        'Aktuelle Geräteerfassung: '+device['captured_utc'],
        f'Stock-Laufzeitknoten: {len(rows)}, derzeit gebundene Stock-Treiberknoten: 503',
        f'Gemeinsame compatible zu R20-Einzel-DTB: 553, gebundene Knoten ohne solche Ueberschneidung: {len(unmatched)}',
        f'Davon {samepath} mit gleichem Pfad aber ohne common compatible und {len(unmatched)-samepath} ohne Pfad im R20-Einzel-DTB.',
        'Dieses Ergebnis beweist KEINE defekten / fehlenden Treiber: DTBO-Overlay und Kbuild/Probe fehlen.',
        f'Historische Vendor-Importe: {sum(crc.values())} = {crc["MATCH"]} passend + {crc["CRC_MISMATCH"]} verschieden + {crc["ABSENT_IN_R20_SYMVERS"]} fehlend.',
        'Der Vendor-Dateivergleich beweist weder das Laden noch die Notwendigkeit dieser Module.',
        'Auf R20 intern passend gebaute Module: 307/307 CRC-Importe (frueherer R32/R34-Nachweis).',
        '', 'Reihenfolge fuer naechste MANUELLE Quellpruefung (kein Risikobeweis):'
    ]
    for g in groups:
        text.append(f"  {g['review_order']} / {g['group']}: {g['nodes']} Knoten, davon {g['r20_same_path_nodes']} im R20-Einzel-DTB vorhanden")
    text.extend(['','Nachweisfolge:','  1) Stock-/R20-Device-Tree plus passende DTBO-Anwendung quellbasiert nachvollziehen.',
        '  2) UFS-, PMIC-, Regler- und Power-On-Treiber durch Kconfig/Kbuild und OF-Match beweisen.',
        '  3) Erst danach konkrete benoetigte Vendor-Module und komplette ABI pruefen.',
        '  4) Boot-Sperren danach erneut bewerten. Kein Flash, keine KSU-/BReNE-Aenderung.',
        '', 'R20-R11 nicht veraendert. NO BUILD / NO FLASH.'])
    (output/'R35_BERICHT_DE.txt').write_text('\n'.join(text)+'\n',encoding='utf8')
    with (output/'SHA256SUMS.txt').open('w',encoding='ascii') as f:
        for name in REPORT_NAMES[:-1]:
            f.write(sha((output/name).read_bytes())+'  '+name+'\n')
    return result


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--bundle',type=pathlib.Path,required=True)
    a.add_argument('--out',type=pathlib.Path,required=True)
    args=a.parse_args()
    r=audit(args.bundle,args.out)
    print('R35_AUDIT=PASS; STOCK_NODES='+str(r['device_nodes'])+
          '; NO_R20_STANDALONE_COMPATIBLE='+str(r['stock_bound_without_r20_compatible_overlap'])+
          '; R20_SAME_PATH='+str(r['unmatched_nodes_with_same_r20_path'])+
          '; ABI=UNPROVEN; BUILD=NO; FLASH=NO')

if __name__=='__main__':
    main()
