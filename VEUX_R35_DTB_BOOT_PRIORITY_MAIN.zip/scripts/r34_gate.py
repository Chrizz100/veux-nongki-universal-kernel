#!/usr/bin/env python3
"""R34 offline structural ABI and DT node comparison (never boot/flash approval).

Only SHA-pinned R20/R21/R31/R32/R33 evidence and OPTIONAL recent read-only
Termux device-node metadata are accepted. Module-load *lists* are NOT proof
of modules loaded. Device driver symlinks are STOCK-only observations.
"""
import argparse
import collections
import csv
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import struct
import sys
import zipfile

SCHEMA='VEUX_R34_STATIC_VENDOR_DTB_ABI_GATE_V1'
DEVICE_SCHEMA='VEUX_R34_DEVICE_DRIVER_BINDINGS_V1'
EXPECTED_EVIDENCE={'evidence/R20_VEUX.dtb','evidence/R32_RESULT.json',
 'evidence/R33_RESULT.json','evidence/R33_DEVICE_EVIDENCE.zip','evidence/R31_RESULT.json',
 'evidence/R21_VENDOR_IMPORTS.csv','evidence/R20_Module.symvers'}
EXPECTED_R20_DTB_SHA='42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37'
EXPECTED_R20_SYMVERS_SHA='5131e75259d76acd00e08143d76d22d04d1ec86b18b0d70b84fa05b7e1e4049d'
EXPECTED_R21_IMPORTS_SHA='bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394'
MAX_FDT=6*1024*1024
REPORTS=('R34_RESULT.json','R34_BERICHT_DE.txt','R34_VENDOR_MATRIX.csv',
         'R34_DEVICE_TREE_MATRIX.csv','SHA256SUMS.txt')


def digest(b):return hashlib.sha256(b).hexdigest()


def json_obj(b):
    x=json.loads(b)
    if not isinstance(x,dict):raise ValueError('JSON_TOP_LEVEL_NOT_OBJECT')
    return x


def read_zip_strict(source,expected=None,maximum=24_000_000):
    blob=source.read_bytes() if isinstance(source,Path) else source
    if not isinstance(blob,bytes) or len(blob)>maximum:raise ValueError('ZIP_INPUT_INVALID_OR_OVERSIZE')
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        names=[i.filename for i in z.infolist() if not i.is_dir()]
        if len(set(names))!=len(names):raise ValueError('ZIP_DUPLICATE_MEMBERS')
        if expected is not None and set(names)!=set(expected):raise ValueError('ZIP_MEMBERS_UNEXPECTED')
        files={}
        total=0
        for entry in z.infolist():
            name=entry.filename
            if name.startswith('/') or '\\' in name or '..' in Path(name).parts or stat.S_ISLNK(entry.external_attr>>16):
                raise ValueError('ZIP_UNSAFE_MEMBER')
            if entry.is_dir():continue
            if entry.file_size>10_000_000:raise ValueError('ZIP_MEMBER_OVERSIZE')
            total+=entry.file_size
            if total>30_000_000:raise ValueError('ZIP_UNCOMPRESSED_LIMIT')
            files[name]=z.read(entry)
    return files


def verify_manifest(base):
    manifest=json_obj((base/'MANIFEST_SHA256.json').read_bytes())
    want=manifest.get('files',{})
    if not isinstance(want,dict) or len(want)<10:raise ValueError('MANIFEST_COUNT_TOO_SMALL')
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if actual!=set(want)|{'MANIFEST_SHA256.json'}:raise ValueError('MANIFEST_FILE_SET_WRONG')
    if not EXPECTED_EVIDENCE<=actual:raise ValueError('MISSING_ORIGINAL_EVIDENCE')
    for rel,m in want.items():
        p=base/rel
        if p.is_symlink() or not p.is_file() or '..' in Path(rel).parts or Path(rel).is_absolute():
            raise ValueError('MANIFEST_UNSAFE_PATH')
        b=p.read_bytes()
        if not isinstance(m,dict) or len(b)!=m.get('bytes') or digest(b)!=m.get('sha256'):
            raise ValueError('MANIFEST_HASH_FAILED:'+rel)
    for name,expected in [('R20_VEUX.dtb',EXPECTED_R20_DTB_SHA),
                          ('R20_Module.symvers',EXPECTED_R20_SYMVERS_SHA),
                          ('R21_VENDOR_IMPORTS.csv',EXPECTED_R21_IMPORTS_SHA)]:
        if digest((base/'evidence'/name).read_bytes())!=expected:raise ValueError('EVIDENCE_ANCHOR_WRONG:'+name)
    return manifest


def fdt_nodes(blob):
    """Bounded FDT reader; emits only path / compatible / status metadata."""
    if len(blob)<40:raise ValueError('FDT_TOO_SMALL')
    hdr=struct.unpack_from('>10I',blob,0)
    magic,total,ofs,offs,offm,version,_last,_boot,szs,szst=hdr
    if magic!=0xd00dfeed or not 40<=total<=len(blob) or total>MAX_FDT:
        raise ValueError('FDT_HEADER_INVALID')
    if not (40<=ofs<total and 40<=offs<total and 40<=offm<total and szs<MAX_FDT and
            ofs+szst<=total and offs+szs<=total):
        raise ValueError('FDT_OFFSETS_INVALID')
    strings=blob[offs:offs+szs];end=ofs+szst
    pos=ofs;stack=[];nodes=[];final=False
    def align(v):return (v+3)&~3
    while pos+4<=end:
        kind=struct.unpack_from('>I',blob,pos)[0];pos+=4
        if kind==1:
            z=blob.find(b'\x00',pos,end)
            if z<0:raise ValueError('FDT_NODE_NAME_UNTERMINATED')
            name=blob[pos:z].decode('ascii','replace')
            if '/' in name or len(name)>120:raise ValueError('FDT_NODE_NAME_INVALID')
            pos=align(z+1)
            path=('/'+name if not stack else stack[-1]['path'].rstrip('/')+'/'+name)
            if not name and not stack:path='/'
            cur={'path':path,'compatible':[],'status':'okay (default)'}
            stack.append(cur);nodes.append(cur)
            if len(stack)>100 or len(nodes)>10000:raise ValueError('FDT_NODES_TOO_LARGE')
        elif kind==2:
            if not stack:raise ValueError('FDT_UNBALANCED_END_NODE')
            stack.pop()
        elif kind==3:
            if not stack or pos+8>end:raise ValueError('FDT_PROP_INVALID')
            length,no=struct.unpack_from('>II',blob,pos);pos+=8
            if no>=len(strings) or pos+length>end or length>MAX_FDT:raise ValueError('FDT_PROP_OUT_OF_BOUNDS')
            stop=strings.find(b'\x00',no)
            if stop<0:raise ValueError('FDT_PROP_NAME_BAD')
            pname=strings[no:stop].decode('ascii','replace')
            if pname in ('compatible','status') and length<=2048:
                props=[]
                for s in blob[pos:pos+length].split(b'\0'):
                    if not s:continue
                    v=s.decode('ascii','replace')
                    if len(v)<=180 and all(32<=ord(c)<=126 for c in v):props.append(v)
                    if len(props)>=18:break
                if pname=='compatible':stack[-1]['compatible']=props
                elif props:stack[-1]['status']=props[0]
            pos=align(pos+length)
        elif kind==4:pass
        elif kind==9:
            final=True;break
        else:raise ValueError('FDT_UNKNOWN_TOKEN')
    if not final or stack:raise ValueError('FDT_MISSING_END')
    return nodes


def parse_symvers(blob):
    result={}
    for line in blob.decode().splitlines():
        if not line:continue
        words=line.split('\t')
        if len(words)<4 or not re.fullmatch(r'0x[0-9a-fA-F]{8}',words[0]) or not words[1]:
            raise ValueError('SYMVERS_LINE_INVALID')
        if words[1] in result and result[words[1]]!=words[0].lower():
            raise ValueError('SYMVERS_DUPLICATE_CONFLICT')
        result[words[1]]=words[0].lower()
    if len(result)<10000:raise ValueError('SYMVERS_TOO_FEW')
    return result


def vendor_rows(blob,symvers):
    out={}
    matches=collections.Counter()
    count=0
    for r in csv.DictReader(io.StringIO(blob.decode())):
        path=r.get('path','')
        if not path.startswith('/vendor/lib/modules/') or not path.endswith('.ko'):
            raise ValueError('VENDOR_PATH_NOT_EXPECTED')
        sym=r['symbol'];ref=symvers.get(sym)
        status='ABSENT_IN_R20_SYMVERS' if ref is None else 'MATCH' if ref==r['module_crc'].lower() else 'CRC_MISMATCH'
        if status!=r['status'] or (ref or '') != r['r20_crc'].lower():
            raise ValueError('HISTORICAL_VENDOR_IMPORT_RESULT_INCONSISTENT')
        d=out.setdefault(path,collections.Counter())
        d[status]+=1
        count+=1;matches[status]+=1
    if count!=14648 or len(out)!=218 or matches!=collections.Counter({'MATCH':6960,'CRC_MISMATCH':7653,'ABSENT_IN_R20_SYMVERS':35}):
        raise ValueError('VENDOR_IMPORT_COUNTS_UNEXPECTED')
    return out,matches


def verify_r33(base):
    r33=json_obj((base/'evidence/R33_RESULT.json').read_bytes())
    r32=json_obj((base/'evidence/R32_RESULT.json').read_bytes())
    r31=json_obj((base/'evidence/R31_RESULT.json').read_bytes())
    if (r33.get('schema')!='VEUX_R33_DTB_VENDORBOOT_PROVENANCE_GATE_V1' or
        r33.get('status')!='DEVICE_CAPTURE_ANALYZED_WITH_BOOT_BLOCKERS' or
        r33.get('boot_ready') is not False or r33.get('flash_allowed') is not False or
        r33.get('r20_internal_six_modules_matching_imports')!=307 or
        r32.get('r20_matching_imports')!=307 or r32.get('flash_allowed') is not False or
        r31.get('r20_rebuilt_modules_matching_imports')!=140):
        raise ValueError('REFERENCE_R31_R32_R33_GATE_FAILED')
    members=read_zip_strict(base/'evidence/R33_DEVICE_EVIDENCE.zip',
                            ('R33_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'))
    if digest(members['R33_DEVICE_EVIDENCE.json']) not in members['SHA256SUMS.txt'].decode():
        raise ValueError('R33_DEVICE_ARCHIVE_SUM_MISMATCH')
    d=json_obj(members['R33_DEVICE_EVIDENCE.json'])
    if (d.get('schema')!='VEUX_R33_DEVICE_DTB_PROVENANCE_V1' or d.get('read_only') is not True
        or d.get('reported_active_slot')!='_a' or
        d.get('runtime_device_tree',{}).get('status')!='PARSED' or
        'qcom,blair' not in d['runtime_device_tree']['fdt']['root']['compatible'] or
        sorted(d.get('loaded_module_names',[]))!=['rmnet_offload','rmnet_shs']):
        raise ValueError('R33_DEVICE_GROUNDING_FAILED')
    return r31,r32,r33,d


def parse_new_device_zip(blob):
    files=read_zip_strict(blob,('R34_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'),5_000_000)
    if digest(files['R34_DEVICE_EVIDENCE.json']) not in files['SHA256SUMS.txt'].decode():
        raise ValueError('R34_DEVICE_HASH_INCORRECT')
    d=json_obj(files['R34_DEVICE_EVIDENCE.json'])
    if d.get('schema')!=DEVICE_SCHEMA or d.get('read_only') is not True:
        raise ValueError('R34_DEVICE_SCHEMA_OR_READONLY_INVALID')
    entries=d.get('device_nodes')
    if not isinstance(entries,list) or len(entries)>6000:raise ValueError('R34_INVALID_DEVICE_NODE_LIST')
    seen=set()
    for n in entries:
        if not isinstance(n,dict) or set(n)!={'path','compatible','status','stock_bound_drivers'}:
            raise ValueError('R34_UNEXPECTED_NODE_FIELDS')
        path=n['path']
        if not isinstance(path,str) or not path.startswith('/') or len(path)>256 or '\x00' in path or '\n' in path or '..' in path.split('/') or path in seen:
            raise ValueError('R34_NODE_PATH_INVALID_OR_DUPLICATE')
        seen.add(path)
        if not isinstance(n['compatible'],list) or len(n['compatible'])>18 or not all(isinstance(x,str) and 0<len(x)<181 for x in n['compatible']):
            raise ValueError('R34_COMPATIBLE_INVALID')
        if not isinstance(n['status'],str) or len(n['status'])>80:
            raise ValueError('R34_STATUS_INVALID')
        if not isinstance(n['stock_bound_drivers'],list) or len(n['stock_bound_drivers'])>10 or not all(isinstance(x,str) and 0<len(x)<180 for x in n['stock_bound_drivers']):
            raise ValueError('R34_BINDINGS_INVALID')
    if d.get('status') not in ('CURRENT_NODES_ENUMERATED','INCOMPLETE_DEVICE_CAPTURE'):
        raise ValueError('R34_CAPTURE_STATUS_INVALID')
    if d['status']=='CURRENT_NODES_ENUMERATED' and not entries:raise ValueError('R34_FALSE_DEVICE_COVERAGE')
    if not isinstance(d.get('loaded_module_names'),list) or len(d['loaded_module_names'])>500:
        raise ValueError('R34_MODULES_INVALID')
    return d


def list_vendor_inventory(d, vendor_imports,r32,newly_loaded=None):
    r20_names={x['name'] for x in r32['r20_modules']}
    loaded_now=set(d['loaded_module_names'] if newly_loaded is None else newly_loaded)
    output=[]
    for group in d['module_load_lists']:
        root=group['path']
        if root not in ('/vendor/lib/modules/modules.load','/vendor/lib/modules/5.4-gki/modules.load'):
            continue
        if group.get('truncated') is not False:raise ValueError('VENDOR_LIST_TRUNCATED')
        prefix=root.rsplit('/',1)[0]
        for name in sorted(set(group['module_names'])):
            if not re.fullmatch(r'[A-Za-z0-9_.-]+\.ko',name):raise ValueError('BAD_MODULE_LIST_MEMBER')
            path=prefix+'/'+name
            ct=vendor_imports.get(path,collections.Counter())
            module=name.removesuffix('.ko').replace('-','_')
            output.append({'module_list':root,'module_path':path,'module':name,
                'historical_imports':sum(ct.values()),'historical_crc_matches':ct['MATCH'],
                'historical_crc_mismatches':ct['CRC_MISMATCH'],
                'historical_exports_absent':ct['ABSENT_IN_R20_SYMVERS'],
                'module_basename_seen_loaded_in_snapshot':module in loaded_now,
                'candidate_file_loaded_from_this_path_proven':False,
                'r20_internal_build_name_matches':module in r20_names,
                'evidence_role':'LISTED_NOT_PROOF_OF_LOADED_OR_REQUIRED'})
    return output


def tree_matrix(r20_nodes, device_capture):
    if device_capture is None:return []
    # Compatible overlap is strictly a hardware-node overlap, not driver support.
    r20_compat={x for n in r20_nodes for x in n['compatible']}
    r20_paths={n['path']:n for n in r20_nodes}
    results=[]
    for n in device_capture['device_nodes']:
        same_path=r20_paths.get(n['path'])
        common=sorted(set(n['compatible'])&r20_compat)
        results.append({'device_node_path':n['path'],
            'device_compatibles':' | '.join(n['compatible']),
            'stock_status':n['status'],
            'stock_driver_bindings':' | '.join(n['stock_bound_drivers']),
            'r20_dtb_path_also_present':bool(same_path),
            'any_r20_dtb_compatible_overlap':bool(common),
            'common_compatible':' | '.join(common),
            'r20_driver_compiled_or_probed':'UNKNOWN_NOT_TESTED'})
    return results


def write_csv(path,fields,rows):
    with path.open('w',newline='',encoding='utf8') as f:
        writer=csv.DictWriter(f,fieldnames=fields,lineterminator='\n')
        writer.writeheader();writer.writerows(rows)


def audit(base,output,device_zip=None):
    verify_manifest(base)
    r31,r32,r33,historical=verify_r33(base)
    sb=(base/'evidence/R20_Module.symvers').read_bytes()
    symvers=parse_symvers(sb)
    vendors,totals=vendor_rows((base/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes(),symvers)
    r20=fdt_nodes((base/'evidence/R20_VEUX.dtb').read_bytes())
    if len(r20)!=r32['dtb']['nodes'] or 'qcom,blair' not in r20[0]['compatible']:
        raise ValueError('R20_DTB_DID_NOT_REPARSE')
    current=parse_new_device_zip(device_zip) if device_zip is not None else None
    node_rows=tree_matrix(r20,current)
    module_rows=list_vendor_inventory(historical,vendors,r32,
                                        current['loaded_module_names'] if current else None)
    counts=collections.Counter(x['module_list'] for x in module_rows)
    if counts['/vendor/lib/modules/modules.load']<35 or counts['/vendor/lib/modules/5.4-gki/modules.load']<175:
        raise ValueError('VENDOR_MODULE_LIST_INCOMPLETE')
    if current is None:status='HISTORICAL_MODULE_ABI_DONE_AWAIT_DEVICE_NODE_CAPTURE'
    elif current['status']!='CURRENT_NODES_ENUMERATED':status='CURRENT_DEVICE_NODE_CAPTURE_INCOMPLETE'
    else:status='CURRENT_DEVICE_NODES_COMPARED_BOOT_BLOCKED'
    count_matched=sum(bool(x['any_r20_dtb_compatible_overlap']) for x in node_rows)
    count_bound=sum(bool(x['stock_driver_bindings']) for x in node_rows)
    blocker=[
        'Keine R20-Treiberbindung oder Kernel-Probe nachgewiesen: R20-DTB-kompatible Knoten sind keine Treiberbeweise',
        'Vendor-Modulimporte stammen aus historischen Moduldateien, nicht aus garantiert aktuell geladenen Modulen',
        'R20-CASS/WALT/KABI und Kernelkennung weichen von der aktiven Firmware ab',
        'Aktive DTBO-Auswahl und kombinierter Laufzeit-Gerätebaum nicht fuer R20 verifiziert',
        'Alte 2EF0-RMNET-Laderdateien nicht auf R20 umgestellt oder auf dem Zielgeraet validiert',
        'Keine echte Boot-/SELinux-/VINTF-/BakaSU-/SUSFS-/NoMount-Freigabe']
    if current is None:blocker.insert(0,'Aktueller R34-Gerätebaum-/Treiber-Snapshot fehlt')
    result={'schema':SCHEMA,'status':status,'provenance_pass':True,
        'r20_dtb_nodes_parsed':len(r20),
        'r20_dtb_root_compatible':r20[0]['compatible'],
        'historical_vendor_imports':sum(totals.values()),
        'historical_vendor_import_matches':totals['MATCH'],
        'historical_vendor_import_crc_mismatches':totals['CRC_MISMATCH'],
        'historical_vendor_import_missing_exports':totals['ABSENT_IN_R20_SYMVERS'],
        'historical_vendor_module_files':len(vendors),
        'vendor_modules_load_list_counts_unique':dict(sorted(counts.items())),
        'vendor_listed_module_rows':len(module_rows),
        'module_loaded_snapshot_used':'R34_CURRENT' if current is not None else 'R33_HISTORICAL',
        'fresh_loaded_module_names':current['loaded_module_names'] if current else None,
        'actually_loaded_modules_at_R33_capture':historical['loaded_module_names'],
        'fresh_device_capture_present':bool(current),
        'fresh_device_tree_nodes':len(node_rows),
        'fresh_stock_driver_bound_nodes':count_bound,
        'fresh_nodes_sharing_any_r20_dtb_compatible':count_matched,
        'r20_six_modules_crc_matching':307,
        'r20_rmnet_modules_crc_matching':140,
        'r33_original_soc_compatible_overlap':r33['soc_compatible_overlap_observed'],
        'vendor_abi_proven':False,'r20_driver_probe_proven':False,
        'boot_ready':False,'flash_allowed':False,'kernel_built':False,'source_patch_created':False,
        'device_modified':False,'brene_changed':False,'nomount_changed':False,
        'blockers':blocker,
        'limitations':['Module-load lists do not establish currently loaded modules.',
            'Historical Vendor ABI comparison covers captured ELF candidates, not exact kernel boot population.',
            'Current driver bindings, if present, describe STOCK hardware probe, not R20.',
            'DTB compatible overlap is not equivalent to driver symbol, kernel config or ABI validation.',
            'No device binaries or raw partitions were collected in R34.']}
    output.mkdir(parents=True,exist_ok=True)
    (output/'R34_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
    write_csv(output/'R34_VENDOR_MATRIX.csv',[
        'module_list','module_path','module','historical_imports','historical_crc_matches',
        'historical_crc_mismatches','historical_exports_absent',
        'module_basename_seen_loaded_in_snapshot','candidate_file_loaded_from_this_path_proven',
        'r20_internal_build_name_matches','evidence_role'],module_rows)
    write_csv(output/'R34_DEVICE_TREE_MATRIX.csv',[
        'device_node_path','device_compatibles','stock_status','stock_driver_bindings',
        'r20_dtb_path_also_present','any_r20_dtb_compatible_overlap','common_compatible',
        'r20_driver_compiled_or_probed'],node_rows)
    lines=['VEUX R34 – Quell- und Vendor-ABI-Diagnose, kein Build/Flash',
        'Status: '+status,
        'R20-DTB-Knoten: '+str(len(r20)),
        'R33 tatsaechlich geladene Module: '+', '.join(historical['loaded_module_names']),
        'Historisch untersuchte Vendor-Importe: '+str(sum(totals.values())),
        'CRC gleich / verschieden / Export fehlt: '+str(totals['MATCH'])+' / '+str(totals['CRC_MISMATCH'])+' / '+str(totals['ABSENT_IN_R20_SYMVERS']),
        'Vendor-Kandidaten dateibezogen: '+str(len(vendors)),
        'modules.load Dateien: '+str(dict(counts)),
        'Aktuell neu erfasste DT-Knoten: '+str(len(node_rows)),
        'R34 Stock-Treiberbindungen: '+str(count_bound),
        'Knoten mit gemeinsamem R20-DTB compatible: '+str(count_matched),
        'WICHTIG: modules.load ist kein Beweis fuer tatsaechlich geladene oder benoetigte Module.',
        'WICHTIG: DTB-Knotenuebereinstimmung und Stock-Treiberbindung sind kein R20-Treiber-/Bootnachweis.',
        '', 'OFFENE SPERRGRUENDE:']
    lines.extend('- '+x for x in blocker)
    lines.extend(['','R20-R11 und BReNE unveraendert. NO FLASH.'])
    (output/'R34_BERICHT_DE.txt').write_text('\n'.join(lines)+'\n')
    sums=['%s  %s'%(digest((output/p).read_bytes()),p) for p in REPORTS if p!='SHA256SUMS.txt']
    (output/'SHA256SUMS.txt').write_text('\n'.join(sums)+'\n')
    print('R34_PROVENANCE=PASS; HISTORICAL_VENDOR_IMPORTS=14648; CURRENT_NODES='+str(len(node_rows))+
          '; STATUS='+status+'; BOOT=NO; FLASH=NO')
    return result


def main(argv=None):
    ap=argparse.ArgumentParser();ap.add_argument('--bundle',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True);ap.add_argument('--device-zip',type=Path)
    args=ap.parse_args(argv)
    audit(args.bundle,args.out,args.device_zip)

if __name__=='__main__':
    try:main()
    except (OSError,ValueError,AssertionError,KeyError,TypeError,zipfile.BadZipFile) as e:
        print('R34_AUDIT_FAILED: '+str(e),file=sys.stderr)
        sys.exit(1)
