#!/usr/bin/env python3
"""VEUX WALT-R7: classify EXACT P3/P10+R6 source-interface conflicts.

No mutation of the kernel tree; Clang compiles only minimal contract reproductions.
A zero exit code means the diagnostic completed and correctly reported BLOCKED,
NOT that the kernel compiled, WALT works, or the Xiaomi ABI matches.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

P3_TREE = '7f97dbbff432d61bbf11cae03de257a21f1d3c74'
P10_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
OEM_SHA = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
WALT_C_SHA = '03ebaf13151525db262f6d20809d69bbbcd5c4fcf378c061b04d661495c72646'
R6_SOURCE_HASHES = {
    'include/linux/sched.h':'3731e599cc85d378ff5b95340214d8de5913be3a0f53c48cec9f1879ee84c6cd',
    'include/linux/sched/sysctl.h':'c2646cb8d5455676d126aca83b5244c37efa648db1b66045bca0309a7f08fe63',
    'kernel/sched/sched.h':'ccd370feb3ef9252fc8cc72c3babe460bd47c89fb48fa1d8035f9fb334d14f64',
}

class EvidenceError(RuntimeError):
    pass


def require(condition:bool, message:str):
    if not condition:
        raise EvidenceError(message)


def digest(contents:bytes)->str:
    return hashlib.sha256(contents).hexdigest()


def read_regular(path:Path)->bytes:
    require(path.is_file() and not path.is_symlink(), 'UNSAFE_OR_MISSING_INPUT:'+str(path))
    return path.read_bytes()


def rotation_branch(sched_h:str)->tuple[str,str]:
    """Select only the exact documented SPRD branch near clock declaration."""
    candidates = re.findall(
        r'#ifdef CONFIG_SPRD_ROTATION_TASK\n(?P<on>.*?)\n#else\n(?P<off>.*?)\n#endif\b',
        sched_h, flags=re.S)
    selected = [(on, off) for on,off in candidates
                if 'sched_ktime_clock(' in on and 'sched_ktime_clock(' in off]
    require(len(selected) == 1, 'ROTATION_CLOCK_CONTRACT_NOT_UNIQUE')
    return selected[0]


def assess(sched_h:str,walt_c:str,config:str,core_c:str)->dict:
    require(re.search(r'^CONFIG_SCHED_WALT=y$',config,re.M) is not None,
            'OEM_WALT_NOT_ENABLED')
    require(re.search(r'^CONFIG_QGKI=y$',config,re.M) is not None, 'OEM_QGKI_NOT_ENABLED')
    require(re.search(r'^CONFIG_SPRD_ROTATION_TASK=y$',config,re.M) is None,
            'ROTATION_IS_ENABLED_REASSESS_CONTRACT')
    on,off=rotation_branch(sched_h)
    require(bool(re.search(r'\bu64\s+sched_ktime_clock\s*\(\s*void\s*\)',on)),
            'ROTATION_ON_CLOCK_PROTOTYPE_CHANGED')
    require(bool(re.search(r'static\s+inline\s+u64\s+sched_ktime_clock\s*\(\s*void\s*\)',off)),
            'ROTATION_OFF_CLOCK_DEFINITION_CHANGED')
    require('clear_reserved(' in on and 'clear_reserved(' not in off,
            'RESERVED_FUNCTION_ROTATION_CONTRACT_CHANGED')
    require(bool(re.search(r'(?m)^u64\s+sched_ktime_clock\s*\(\s*void\s*\)\s*\{', walt_c)),
            'WALT_GLOBAL_CLOCK_DEFINITION_CHANGED')
    require(bool(re.search(r'(?m)^void\s+clear_walt_request\s*\(\s*int cpu\s*\)',walt_c)),
            'WALT_CLEAR_WALT_REQUEST_CHANGED')
    body=walt_c.split('void clear_walt_request(int cpu)',1)[1].split('\n}\n',1)[0]
    require(len(re.findall(r'clear_reserved\s*\(',body))==2,
            'WALT_CLEAR_RESERVED_CALLS_CHANGED')
    require('walt_update_task_ravg(curr, rq, TASK_UPDATE' in core_c,
            'P10_CORE_TICK_NOT_PRESENT')
    require('try_to_wake_up(task, TASK_NORMAL, 0, head->count)' in core_c,
            'P10_CORE_WAKEUP_NOT_PRESENT')
    require('CONFIG_SCHED_WALT' in core_c,'P10_CORE_WALT_GUARD_NOT_PRESENT')
    return {
        'source_conditions': {
            'oem_walt_enabled':True,'oem_qgki_enabled':True,
            'oem_sprd_rotation_enabled':False,'p10_core_walt_tick_present':True,
            'p10_core_walt_wakeup_present':True,
            'r6_rotation_off_has_inline_sched_ktime_clock':True,
            'r6_rotation_off_has_clear_reserved':False,
            'official_walt_c_has_global_sched_ktime_clock':True,
            'official_walt_c_calls_clear_reserved_twice':True,
        },
        'findings': [
            {'id':'WALT-R7-001','severity':'BLOCKER',
             'problem':'CONFIG_SPRD_ROTATION_TASK=n: static-inline sched_ktime_clock() in R6 sched.h conflicts with global definition in pinned Xiaomi WALT walt.c',
             'evidence_files':['kernel/sched/sched.h','kernel/sched/walt/walt.c'],
             'provenance':'exact R6 output header SHA and official P10 WALT donor SHA'},
            {'id':'WALT-R7-002','severity':'BLOCKER',
             'problem':'CONFIG_SPRD_ROTATION_TASK=n: clear_reserved() absent from R6 sched.h branch but called twice in pinned Xiaomi WALT walt.c',
             'evidence_files':['kernel/sched/sched.h','kernel/sched/walt/walt.c'],
             'provenance':'exact branch and function signatures; isolated C diagnostic required'},
        ],
        'review_areas':['WALT headers/include chain in core/fair','CPUFreq schedutil callbacks','WALT RTG and energy interfaces','OEM runqueue and task layout','OEM vendor Module.symvers ABI'],
    }


def run_clang_diagnostics(clang:str)->dict:
    """C-signature reproduction; not a translation of any kernel object."""
    probes={
        'clock_redefinition': ('''typedef unsigned long long u64;\nu64 sched_clock(void);\nstatic inline u64 sched_ktime_clock(void) { return sched_clock(); }\nu64 sched_ktime_clock(void) { return 0; }\n''','redefinition'),
        'clear_reserved_undeclared':('''void clear_walt_request(int cpu) { clear_reserved(cpu); }\n''','undeclared function'),
    }
    results={}
    for name,(program,needle) in probes.items():
        proc=subprocess.run([clang,'-x','c','-fsyntax-only','-Werror','-'],
                            input=program,text=True,capture_output=True,timeout=20,check=False)
        require(proc.returncode != 0 and needle in proc.stderr.lower(),
                'CLANG_UNEXPECTED_RESULT:'+name+' '+proc.stderr[:400])
        results[name]={
            'result':'EXPECTED_COMPILER_ERROR',
            'diagnostic': '\n'.join(proc.stderr.strip().splitlines()[:8]),
            'probe_sha256':digest(program.encode()),
            'scope':'reduced C ABI/signature model; not a kernel object compile',
        }
    return results


def inspect(kernel:Path,r6:Path,stock:Path,clang:str)->dict:
    gate=json.loads(read_regular(r6/'R6_SOURCE_GATE.json'))
    require(gate.get('strict_real_source') is True and gate.get('method')=='GIT_APPLY',
            'R6_STRICT_GIT_APPLY_NOT_PROVEN')
    require(gate.get('p3_tree')==P3_TREE and gate.get('p10_composed_tree')==P10_TREE,
            'R6_TREE_MISMATCH')
    require(gate.get('status')=='WALT_R6_REAL_P3_COMPATIBILITY_PRECOMPILE_STAGED',
            'R6_STAGE_STATUS_MISMATCH')
    for key in ('final_kernel_built','walt_on_compile_proven','vendor_crc_fixed','flash_allowed','brene_changed'):
        require(gate.get(key) is False, 'UNEXPECTED_R6_FLAG:'+key)
    for name, expected in R6_SOURCE_HASHES.items():
        data=read_regular(r6/'source'/name)
        require(digest(data)==expected and gate.get('source_after_sha256',{}).get(name)==expected,
                'R6_OUTPUT_HEADER_HASH_MISMATCH:'+name)
    walt=read_regular(kernel/'kernel/sched/walt/walt.c')
    require(digest(walt)==WALT_C_SHA,'PINNED_WALT_C_SHA_MISMATCH')
    core=read_regular(kernel/'kernel/sched/core.c').decode('utf-8')
    sched=read_regular(r6/'source/kernel/sched/sched.h').decode('utf-8')
    oem=read_regular(stock)
    require(digest(oem)==OEM_SHA,'OEM_CONFIG_SHA_MISMATCH')
    reviewed=assess(sched,walt.decode('utf-8'),oem.decode('utf-8'),core)
    reviewed['minimal_compiler_probes']=run_clang_diagnostics(clang)
    return {
        'status':'R7_PRECOMPILE_AUDIT_COMPLETED__WALT_ON_BLOCKED',
        'diagnostic_completed':True,
        'r6_source_gate_verified':True,
        'source_walt_tree':P10_TREE,'p3_tree':P3_TREE,
        'oem_config_sha256':OEM_SHA,'xiaomi_walt_c_sha256':WALT_C_SHA,
        'r6_source_after_sha256':R6_SOURCE_HASHES,
        'confirmed_blocker_count':len(reviewed['findings']),
        'kernel_build_attempted':False, 'walt_on_compile_proven':False,
        'vendor_abi_proven':False, 'flash_allowed':False,'brene_changed':False,
        **reviewed
    }


def main():
    arg=argparse.ArgumentParser(description=__doc__)
    arg.add_argument('--kernel',type=Path,required=True)
    arg.add_argument('--r6',type=Path,required=True)
    arg.add_argument('--stock-config',type=Path,required=True)
    arg.add_argument('--output',type=Path,required=True)
    arg.add_argument('--clang',default='clang')
    a=arg.parse_args()
    try:
        require(a.kernel.is_dir() and not a.kernel.is_symlink(),'INVALID_KERNEL_TREE')
        require(a.r6.is_dir() and not a.r6.is_symlink(),'INVALID_R6_TREE')
        require(not a.output.exists() and not a.output.is_symlink(),'OUTPUT_ALREADY_EXISTS')
        result=inspect(a.kernel,a.r6,a.stock_config,a.clang)
        a.output.mkdir(parents=True)
        (a.output/'R7_WALT_INTERFACE_AUDIT.json').write_text(
            json.dumps(result,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
        findings='\n'.join(f"{f['id']}: {f['problem']}" for f in result['findings'])
        (a.output/'R7_ERGEBNIS_DE.txt').write_text(
            'R7 Diagnose erfolgreich; WALT-ON-Quellintegration BLOCKIERT.\n'
            'Keine Kernelkompilierung, kein ABI-Pass, kein Flash.\n'
            'Clang-Proben betreffen nur isolierte C-Schnittstellen.\n'+findings+'\n')
        print('R7_DIAGNOSTIC_CAPTURE=PASS; BLOCKERS=2; WALT_COMPILE=NOT_RUN; VENDOR_ABI=OPEN; FLASH=NO')
    except (EvidenceError,ValueError,OSError,subprocess.TimeoutExpired) as e:
        print('R7_DIAGNOSTIC_INVALID:'+str(e),file=__import__('sys').stderr)
        raise SystemExit(2)

if __name__=='__main__':
    main()
