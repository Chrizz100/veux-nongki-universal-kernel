"""R32 negative/positive tests of source provenance, ELF, Image, FDT, ZIP safety."""
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import sys
import tempfile
import unittest
import zipfile

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
import r32_gate as R


class R32Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base=BASE
        cls.image=(BASE/'evidence/R20/arch/arm64/boot/Image').read_bytes()
        cls.dtb=(BASE/'evidence/R20/arch/arm64/boot/dts/vendor/xiaomi/veux.dtb').read_bytes()
        cls.shs=(BASE/'evidence/R20/techpack/datarmnet-ext/shs/rmnet_shs.ko').read_bytes()
        cls.offload=(BASE/'evidence/R20/techpack/datarmnet-ext/offload/rmnet_offload.ko').read_bytes()
        cls.sym=(BASE/'evidence/R20/Module.symvers').read_bytes()
        cls.header=(BASE/'evidence/R22_HISTORIC_BOOT_A_HEADER_20261019.bin').read_bytes()

    def test_01_manifest_complete(self): self.assertEqual(R.verify_manifest(BASE)['schema'],R.SCHEMA)
    def test_02_expected_file_count(self): self.assertGreater(len(R.EXPECTED_FILES),25)
    def test_03_image_arm64_magic(self): self.assertEqual(self.image[0x38:0x3c],b'ARM\x64')
    def test_04_image_provenance(self): self.assertEqual(R.analyze_arm64_image(self.image)['sha256'],json.loads((BASE/'evidence/R20_RUN39910955809_BUILD_RESULT.json').read_text())['image']['sha256'])
    def test_05_image_banner(self): self.assertIn('Linux version 5.4.274~positron',R.analyze_arm64_image(self.image)['kernel_banner'])
    def test_06_image_short(self):
        with self.assertRaises(ValueError): R.analyze_arm64_image(self.image[:20])
    def test_07_image_bad_magic(self):
        b=bytearray(self.image[:512]);b[0x38]=0
        with self.assertRaises(ValueError): R.analyze_arm64_image(b)
    def test_08_image_bad_size(self):
        b=bytearray(self.image[:512]);struct.pack_into('<Q',b,16,0)
        with self.assertRaises(ValueError): R.analyze_arm64_image(b)
    def test_09_image_banner_missing(self):
        with self.assertRaises(ValueError): R.analyze_arm64_image(self.image[:512])
    def test_10_dtb_complete(self):
        d=R.analyze_dtb(self.dtb);self.assertFalse(d['device_match_verified']);self.assertIn('qcom,blair',d['root_compatible'])
    def test_11_dtb_short(self):
        with self.assertRaises(ValueError): R.analyze_dtb(self.dtb[:12])
    def test_12_dtb_invalid_magic(self):
        b=bytearray(self.dtb);b[0]=0
        with self.assertRaises(ValueError): R.analyze_dtb(b)
    def test_13_dtb_invalid_size(self):
        b=bytearray(self.dtb);struct.pack_into('>I',b,4,len(b)+1)
        with self.assertRaises(ValueError): R.analyze_dtb(b)
    def test_14_dtb_bad_struct_token(self):
        b=bytearray(self.dtb);b[56:60]=b'\xff\xff\xff\xff'
        with self.assertRaises(ValueError): R.analyze_dtb(b)
    def test_15_elf_shs_imports(self):
        m=R.parse_elf(self.shs);self.assertEqual(len(m['imports']),108);self.assertEqual(m['name'],'rmnet_shs')
    def test_16_elf_offload_imports(self):
        m=R.parse_elf(self.offload);self.assertEqual(len(m['imports']),32);self.assertEqual(m['name'],'rmnet_offload')
    def test_17_elf_unsupported_arch(self):
        b=bytearray(self.offload);struct.pack_into('<H',b,18,62)
        with self.assertRaises(ValueError): R.parse_elf(b)
    def test_18_elf_not_relocatable(self):
        b=bytearray(self.offload);struct.pack_into('<H',b,16,2)
        with self.assertRaises(ValueError): R.parse_elf(b)
    def test_19_elf_wrong_magic(self):
        with self.assertRaises(ValueError): R.parse_elf(b'012345')
    def test_20_elf_short_sections(self):
        b=bytearray(self.offload[:64]);struct.pack_into('<Q',b,40,9000000)
        with self.assertRaises(ValueError): R.parse_elf(b)
    def test_21_elf_note_corrupt(self):
        b=bytearray(self.offload); i=b.find(b'GNU\x00'); self.assertGreater(i,12);b[i:i+4]=b'NOPE'
        with self.assertRaises(ValueError): R.parse_elf(b)
    def test_22_symvers_count(self): self.assertEqual(len(R.parse_symvers(self.sym)),14260)
    def test_23_symvers_alternate_order_semantically_same(self):
        a=R.parse_symvers(self.sym)
        b=R.parse_symvers((BASE/'evidence/R20_RUN39774000774_Module.symvers').read_bytes())
        self.assertEqual(a,b);self.assertNotEqual(self.sym,(BASE/'evidence/R20_RUN39774000774_Module.symvers').read_bytes())
    def test_24_symvers_duplicate_crc(self):
        lines=self.sym.decode().splitlines();data=('\n'.join(lines+["0xffffffff\t"+lines[0].split('\t')[1]+"\tother\tEXPORT_SYMBOL"])+'\n').encode()
        with self.assertRaises(ValueError): R.parse_symvers(data)
    def test_25_symvers_truncated(self):
        with self.assertRaises(ValueError): R.parse_symvers(self.sym[:800])
    def test_26_symvers_bad_format(self):
        with self.assertRaises(ValueError): R.parse_symvers(b'0x1234 missing tabs')
    def test_27_historic_boot_v3(self): self.assertEqual(R.historic_boot_header(self.header,'old')['header_version'],3)
    def test_28_historic_boot_magic_corrupt(self):
        b=bytearray(self.header);b[0]=0
        with self.assertRaises(ValueError): R.historic_boot_header(b,'old')
    def test_29_historic_boot_version_corrupt(self):
        b=bytearray(self.header);struct.pack_into('<I',b,40,2)
        with self.assertRaises(ValueError): R.historic_boot_header(b,'old')
    def test_30_historic_boot_short(self):
        with self.assertRaises(ValueError): R.historic_boot_header(self.header[:100],'old')
    def test_31_config_flags(self):
        cfg=(BASE/'evidence/R20_CONFIG.config').read_text()
        self.assertEqual(R.read_config(cfg,'CONFIG_SCHED_WALT'),'y')
        self.assertEqual(R.read_config(cfg,'CONFIG_DEBUG_PREEMPT'),'n')
        self.assertEqual(R.read_config(cfg,'CONFIG_THIS_OPTION_IS_NOT_IN_CONFIG'),'not_recorded')
    def test_32_validated_device(self):
        d=R.validated_device_evidence(BASE);self.assertEqual(d['reported_active_slot'],'_a')
    def test_33_manifest_bad_sha(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp); (root/'MANIFEST_SHA256.json').write_text(json.dumps({'schema':R.SCHEMA,'files':{'invalid.txt':{'bytes':1,'sha256':'a'}}}))
            with self.assertRaises(ValueError): R.verify_manifest(root)
    def test_34_safe_extract_rejects_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            z=Path(tmp)/'test.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('../oops','x')
            with self.assertRaises(ValueError):R.safe_extract(z,Path(tmp)/'extract')
    def test_35_safe_extract_symlink_member(self):
        with tempfile.TemporaryDirectory() as tmp:
            z=Path(tmp)/'test.zip'; target='README_ZUERST_DE.txt'
            with zipfile.ZipFile(z,'w') as f:
                for n in sorted(R.EXPECTED_FILES):
                    i=zipfile.ZipInfo(n)
                    if n==target:
                        i.create_system=3;i.external_attr=(stat.S_IFLNK|0o777)<<16
                    f.writestr(i,b'x')
            with self.assertRaisesRegex(ValueError,'SYMLINK'):
                R.safe_extract(z,Path(tmp)/'extract')
    def test_36_safe_extract_size_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            z=Path(tmp)/'test.zip'
            with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as f:
                for n in sorted(R.EXPECTED_FILES):
                    f.writestr(n,b'x'*(R.MAX_ENTRY_BYTES+1) if n=='evidence/R20/arch/arm64/boot/Image' else b'x')
            with self.assertRaisesRegex(ValueError,'SIZE_LIMIT'):
                R.safe_extract(z,Path(tmp)/'extract')
    def test_37_pinned_good_r20_result(self):
        a=json.loads((BASE/'evidence/R20_RUN39910955809_BUILD_RESULT.json').read_text())
        self.assertEqual(a['status'],'R20_WALT_ON_VMLINUX_IMAGE_DTB_AND_MODULE_BUILD_PROVEN_NO_FLASH')
        self.assertIs(a['flash_allowed'],False)
    def test_38_older_image_hash_is_different(self):
        a=json.loads((BASE/'evidence/R20_RUN39910955809_BUILD_RESULT.json').read_text())
        b=json.loads((BASE/'evidence/R20_RUN39774000774_BUILD_RESULT.json').read_text())
        self.assertNotEqual(a['image']['sha256'],b['image']['sha256'])
    def test_39_zero_crc_mismatch_all_six(self):
        db=R.parse_symvers(self.sym)
        n=0
        for mod in R.SIX_MODULES:
            meta=R.parse_elf((BASE/('evidence/R20/'+mod)).read_bytes())
            self.assertTrue(all(db.get(name)==crc for name,crc in meta['imports'].items()))
            n+=len(meta['imports'])
        self.assertEqual(n,307)
    def test_40_rmnet_old_not_compatible(self):
        db=R.parse_symvers(self.sym)
        for name in ('rmnet_shs','rmnet_offload'):
            m=R.parse_elf((BASE/f'evidence/DEVICE_2EF0/{name}.ko').read_bytes())
            self.assertNotEqual(m['imports']['module_layout'],db['module_layout'])
    def test_41_result_nonflash(self):
        with tempfile.TemporaryDirectory() as t:
            result=R.run(BASE,t)
            self.assertEqual(result['r20_matching_imports'],307)
            self.assertEqual(result['audit_status'],'PASS_STATIC_PROVENANCE_WITH_BOOT_BLOCKERS')
            self.assertIs(result['boot_ready'],False)
            self.assertIs(result['flash_allowed'],False)
            self.assertFalse(result['other_vendor_modules_abi_proven'])
            self.assertEqual({p.name for p in Path(t).iterdir()}, {'R32_RESULT.json','R32_DTB_INSPECTION.json','R32_BOOT_COMPARISON.json','R32_MODULE_IMPORTS.csv','R32_BERICHT_DE.txt','SHA256SUMS.txt'})
    def test_42_missing_device_evidence_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);(root/'evidence').mkdir()
            (root/'evidence/R28_DEVICE_EVIDENCE.json').write_text('{}')
            with self.assertRaises(ValueError):R.validated_device_evidence(root)
    def test_43_device_unknown_slot_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);(root/'evidence').mkdir()
            d=json.loads((BASE/'evidence/R28_DEVICE_EVIDENCE.json').read_text());d['boot_active_slot_reported']='_x'
            (root/'evidence/R28_DEVICE_EVIDENCE.json').write_text(json.dumps(d))
            with self.assertRaises(ValueError):R.validated_device_evidence(root)
    def test_44_device_missing_hash_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);(root/'evidence').mkdir()
            d=json.loads((BASE/'evidence/R28_DEVICE_EVIDENCE.json').read_text());d['boot_kernels'][0]['kernel_sha256']=None
            (root/'evidence/R28_DEVICE_EVIDENCE.json').write_text(json.dumps(d))
            with self.assertRaises(ValueError):R.validated_device_evidence(root)
    def test_45_device_loaded_module_id_change_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);(root/'evidence').mkdir()
            d=json.loads((BASE/'evidence/R28_DEVICE_EVIDENCE.json').read_text());d['loaded_modules'][0]['build_id']='0'*16
            (root/'evidence/R28_DEVICE_EVIDENCE.json').write_text(json.dumps(d))
            with self.assertRaises(ValueError):R.validated_device_evidence(root)
    def test_46_missing_boot_approval_evidence(self):
        result=json.loads((BASE/'evidence/R31_RESULT.json').read_text())
        self.assertFalse(result['flash_allowed']);self.assertIn('not validated',result['blocking'][1])

if __name__=='__main__':unittest.main()
