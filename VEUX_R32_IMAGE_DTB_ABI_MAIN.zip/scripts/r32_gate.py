#!/usr/bin/env python3
"""R32: pinned, read-only, fail-closed VEUX Image/DTB/module ABI provenance.

This is a verification program, NOT a boot installer, kernel patch or flash utility.
Never infer operational/boot compatibility solely from symbol CRC equivalence.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import struct
import zipfile

SCHEMA = 'VEUX_R32_PINNED_BOOT_ABI_AUDIT_V1'
BASE = 'evidence/R20/'
SIX_MODULES = (
    'drivers/bluetooth/bt_fm_slim.ko',
    'drivers/bluetooth/btpower.ko',
    'drivers/char/rdbg.ko',
    'drivers/media/rc/ir-spi.ko',
    'techpack/datarmnet-ext/offload/rmnet_offload.ko',
    'techpack/datarmnet-ext/shs/rmnet_shs.ko',
)
OTHER_FILES = {
    'evidence/R20_RUN39910955809_BUILD_RESULT.json',
    'evidence/R20_RUN39774000774_BUILD_RESULT.json',
    'evidence/R20_RUN39774000774_Module.symvers',
    'evidence/R20_CONFIG.config',
    'evidence/R22_RUNNING_CONFIG.config',
    'evidence/R31_RESULT.json',
    'evidence/R28_DEVICE_EVIDENCE.json',
    'evidence/R30_RESULT.json',
    'evidence/R30_AKTIVE_GENERATION.txt',
    'evidence/R22_HISTORIC_BOOT_A_HEADER_20261019.bin',
    'evidence/HISTORIC_STOCK_BOOT_HEADER.bin',
    'evidence/DEVICE_2EF0/rmnet_shs.ko',
    'evidence/DEVICE_2EF0/rmnet_offload.ko',
    'scripts/r32_gate.py',
    'tests/test_r32.py',
    'tools/actionlint',
    'README_ZUERST_DE.txt',
}
EXPECTED_FILES = OTHER_FILES | {
    BASE+'arch/arm64/boot/Image',
    BASE+'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb',
    BASE+'Module.symvers',
} | {BASE+x for x in SIX_MODULES} | {'MANIFEST_SHA256.json'}
MAX_ENTRY_BYTES = 48_000_000
MAX_UNCOMPRESSED = 86_000_000


def checksum(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_extract(archive: Path | str, dest: Path | str) -> None:
    """Reject symlinks, unexpected members, truncated CRC, oversized files and traversal."""
    dest=Path(dest)
    with zipfile.ZipFile(archive) as z:
        entries=z.infolist()
        files=[m for m in entries if not m.is_dir()]
        names=[m.filename for m in files]
        if len(names)!=len(EXPECTED_FILES) or len(set(names))!=len(names) or set(names)!=EXPECTED_FILES:
            raise ValueError('R32_ZIP_UNEXPECTED_DUPLICATE_OR_MISSING_FILE')
        total=0
        for m in entries:
            n=PurePosixPath(m.filename)
            if (n.is_absolute() or not n.parts or any(x in ('.','..') for x in n.parts)
                or '\\' in m.filename or '//' in m.filename or stat.S_ISLNK(m.external_attr >> 16)):
                raise ValueError('R32_ZIP_PATH_TRAVERSAL_OR_SYMLINK')
            if m.is_dir():
                continue
            total+=m.file_size
            if m.file_size>MAX_ENTRY_BYTES or total>MAX_UNCOMPRESSED:
                raise ValueError('R32_ZIP_SIZE_LIMIT')
        for m in files:
            p=dest/m.filename
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(z.read(m))  # zipfile raises on CRC errors
    verify_manifest(dest)


def verify_manifest(bundle: Path | str) -> dict:
    bundle=Path(bundle)
    d=json.loads((bundle/'MANIFEST_SHA256.json').read_text('utf8'))
    if d.get('schema')!=SCHEMA or not isinstance(d.get('files'),dict):
        raise ValueError('R32_BAD_MANIFEST_SCHEMA')
    actual={f.relative_to(bundle).as_posix() for f in bundle.rglob('*') if f.is_file()}
    if actual!=EXPECTED_FILES or set(d['files'])!=EXPECTED_FILES-{'MANIFEST_SHA256.json'}:
        raise ValueError('R32_MANIFEST_MEMBER_SET_MISMATCH')
    for name,expected in d['files'].items():
        file=bundle/name
        if not file.is_file() or file.is_symlink():
            raise ValueError('R32_MISSING_OR_SYMLINK:'+name)
        raw=file.read_bytes()
        if len(raw)!=expected['bytes'] or checksum(raw)!=expected['sha256']:
            raise ValueError('R32_PINNED_HASH_MISMATCH:'+name)
    return d


def parse_elf(blob:bytes)->dict:
    """Parse little-endian AArch64 relocatable ELF (kernel modules), plus modversions."""
    if len(blob)<64 or blob[:4]!=b'\x7fELF' or blob[4]!=2 or blob[5]!=1:
        raise ValueError('R32_NOT_ELF64_LITTLE_ENDIAN')
    if struct.unpack_from('<H',blob,18)[0]!=183 or struct.unpack_from('<H',blob,16)[0]!=1:
        raise ValueError('R32_NOT_AARCH64_RELOCATABLE')
    shoff=struct.unpack_from('<Q',blob,40)[0]
    shentsize=struct.unpack_from('<H',blob,58)[0]
    shnum=struct.unpack_from('<H',blob,60)[0]
    shstrndx=struct.unpack_from('<H',blob,62)[0]
    if shentsize!=64 or not 1<shnum<3000 or not 0<=shstrndx<shnum or shoff+shnum*64>len(blob):
        raise ValueError('R32_BAD_ELF_SECTION_TABLE')
    entries=[]
    for i in range(shnum):
        rec=struct.unpack_from('<IIQQQQIIQQ',blob,shoff+i*64)
        nameidx,typ,flags,addr,offset,size,link,info,align,entsize=rec
        if typ!=8 and (offset>len(blob) or size>len(blob)-offset):
            raise ValueError('R32_OUT_OF_BOUNDS_ELF_SECTION')
        entries.append((nameidx,typ,offset,size))
    _,_,off,sz=entries[shstrndx]
    nametab=blob[off:off+sz]
    sections={}
    for idx,typ,off,size in entries:
        if idx>=len(nametab):raise ValueError('R32_BAD_ELF_SECTION_NAME')
        end=nametab.find(b'\0',idx)
        if end<0:raise ValueError('R32_BAD_ELF_SECTION_TERMINATOR')
        name=nametab[idx:end].decode('ascii','strict')
        if name in sections:raise ValueError('R32_DUPLICATE_ELF_SECTION')
        sections[name]=blob[off:off+size] if typ!=8 else b''
    for sec in ('__versions','.modinfo','.note.gnu.build-id'):
        if sec not in sections:raise ValueError('R32_REQUIRED_ELF_SECTION_MISSING:'+sec)
    version_data=sections['__versions']
    if not version_data or len(version_data)%64:
        raise ValueError('R32_BAD_MODVERSIONS')
    imports={}
    for i in range(0,len(version_data),64):
        slot=version_data[i:i+64]
        n=slot[8:].split(b'\0',1)[0].decode('ascii','strict')
        if not n or n in imports:raise ValueError('R32_DUPLICATE_MODULE_IMPORT')
        imports[n]=struct.unpack_from('<I',slot,0)[0]
    info={}
    for entry in sections['.modinfo'].split(b'\0'):
        if b'=' in entry:
            key,value=entry.split(b'=',1)
            info[key.decode('ascii','strict')]=value.decode('utf8','replace')
    note=sections['.note.gnu.build-id']
    if len(note)<16: raise ValueError('R32_SHORT_BUILD_ID_NOTE')
    namelen,dlen,t=struct.unpack_from('<III',note,0)
    desc=12+((namelen+3)//4)*4
    if not (note[12:12+namelen]==b'GNU\0' and t==3 and 4<=dlen<=64 and desc+dlen<=len(note)):
        raise ValueError('R32_INVALID_BUILD_ID')
    return {'name':info.get('name',''),'vermagic':info.get('vermagic',''),
            'build_id':note[desc:desc+dlen].hex(),'imports':imports}


def parse_symvers(raw:bytes)->dict:
    db={}
    for line in raw.decode('utf8').splitlines():
        fields=line.split('\t')
        if len(fields)<4:raise ValueError('R32_BAD_SYMVERS_LINE')
        val=int(fields[0],16); name=fields[1]
        if not name or (name in db and db[name]!=val):
            raise ValueError('R32_DUPLICATE_OR_INVALID_SYMVERS')
        db[name]=val
    if len(db)!=14260:raise ValueError('R32_UNEXPECTED_EXPORT_COUNT')
    return db


def analyze_arm64_image(blob:bytes)->dict:
    if len(blob)<64 or blob[0x38:0x3c]!=b'ARM\x64':
        raise ValueError('R32_BAD_ARM64_IMAGE_HEADER')
    text_offset,image_size,flags=struct.unpack_from('<QQQ',blob,8)
    if text_offset>=2**30 or not 0<image_size<2**30 or flags>=2**32:
        raise ValueError('R32_BAD_ARM64_IMAGE_FIELDS')
    pattern=re.search(rb'Linux version (5\.4\.274[^\x00\r\n]{0,400})',blob)
    if not pattern:raise ValueError('R32_IMAGE_LINUX_BANNER_MISSING')
    banner='Linux version '+pattern.group(1).decode('utf8','replace')
    return {'format':'arm64 Image','text_offset':text_offset,'image_size_memory':image_size,
            'flags':flags,'kernel_banner':banner,'bytes':len(blob),'sha256':checksum(blob)}


def analyze_dtb(blob:bytes)->dict:
    if len(blob)<40:raise ValueError('R32_TRUNCATED_FDT')
    magic,totalsize,off_struct,off_strings,off_mem,version,last,boot,size_strings,size_struct=struct.unpack_from('>10I',blob,0)
    if (magic!=0xd00dfeed or totalsize!=len(blob) or not 16<=last<=version<=18
        or off_struct<40 or off_struct+size_struct>totalsize
        or off_strings+size_strings>totalsize or off_mem<40):
        raise ValueError('R32_BAD_FDT_HEADER')
    strings=blob[off_strings:off_strings+size_strings]
    end_struct=off_struct+size_struct
    pos=off_struct; depth=0; count=0;root={};closed=False
    while pos+4<=end_struct:
        tok=struct.unpack_from('>I',blob,pos)[0]; pos+=4
        if tok==1:
            if pos>=end_struct:raise ValueError('R32_FDT_NODE_TRUNCATED')
            end=blob.find(b'\0',pos,end_struct)
            if end<0:raise ValueError('R32_FDT_NODE_NAME')
            pos=(end+4)&~3;depth+=1;count+=1
        elif tok==2:
            depth-=1
            if depth<0:raise ValueError('R32_FDT_NEGATIVE_DEPTH')
        elif tok==3:
            if pos+8>end_struct:raise ValueError('R32_FDT_PROPERTY_TRUNCATED')
            size,nameidx=struct.unpack_from('>II',blob,pos);pos+=8
            if nameidx>=len(strings) or pos+size>end_struct:raise ValueError('R32_FDT_PROPERTY_BOUNDS')
            nend=strings.find(b'\0',nameidx)
            if nend<0:raise ValueError('R32_FDT_BAD_PROPERTY_NAME')
            name=strings[nameidx:nend].decode('utf8','replace')
            value=blob[pos:pos+size];pos=(pos+size+3)&~3
            if depth==1 and name in ('model','compatible'):
                root[name]=[v.decode('utf8','replace') for v in value.split(b'\0') if v]
        elif tok==4:
            pass
        elif tok==9:
            closed=True;break
        else:raise ValueError('R32_UNKNOWN_FDT_TOKEN')
    if not closed or depth!=0 or not root.get('compatible') or count<100:
        raise ValueError('R32_FDT_MISSING_END_OR_ROOT')
    return {'format':'FDT','bytes':len(blob),'sha256':checksum(blob),'fdt_version':version,
            'root_model':root.get('model',[]),'root_compatible':root['compatible'],'nodes':count,
            'device_match_verified':False}


def historic_boot_header(blob:bytes, label:str)->dict:
    if len(blob)!=4096 or blob[:8]!=b'ANDROID!':raise ValueError('R32_BAD_HISTORICAL_BOOT_HEADER')
    size,ramdisk,osv,header_size=struct.unpack_from('<IIII',blob,8)
    version=struct.unpack_from('<I',blob,40)[0]
    if version not in (3,4) or not 0<size<64*1024*1024 or not 0<ramdisk<64*1024*1024 or not 1580<=header_size<=4096:
        raise ValueError('R32_UNEXPECTED_ANDROID_BOOT_V3_V4_HEADER')
    return {'reference':label,'header_version':version,'kernel_payload_bytes':size,
            'ramdisk_bytes':ramdisk,'header_size':header_size,
            'historical_reference_only':True,'active_device_boot_header_proven':False}


def read_config(config:str,key:str)->str:
    for line in config.splitlines():
        if line.startswith(key+'='):
            return line[len(key)+1:]
    return 'n' if f'# {key} is not set' in config else 'not_recorded'


def validated_device_evidence(root:Path)->dict:
    doc=json.loads((root/'evidence/R28_DEVICE_EVIDENCE.json').read_text('utf8'))
    if doc.get('schema')!='VEUX_R28_DEVICE_CAPTURE_V1' or doc.get('read_only') is not True or doc.get('warnings'):
        raise ValueError('R32_DEVICE_EVIDENCE_UNTRUSTED_OR_PARTIAL')
    if doc.get('kernel_release')!='5.4.274-qgki-g82179e362f33':
        raise ValueError('R32_DEVICE_KERNEL_RELEASE_CHANGED')
    boot={p['partition']:p for p in doc['boot_kernels']}
    if not {'boot_a','boot_b'}<=set(boot) or doc.get('boot_active_slot_reported')!='_a':
        raise ValueError('R32_DEVICE_SLOT_UNKNOWN')
    for x in boot.values():
        if x.get('read_status')!='READ_ONLY_KERNEL_HASH' or not re.fullmatch('[0-9a-f]{64}',str(x.get('kernel_sha256',''))):
            raise ValueError('R32_DEVICE_BOOT_HASH_UNAVAILABLE')
    modules={p['name']:p['build_id'] for p in doc['loaded_modules']}
    if modules!={'rmnet_offload':'3e7d408d3146fb8c','rmnet_shs':'52967b0490abea75'}:
        raise ValueError('R32_LOADED_MODULE_IDENTITY_CHANGED')
    return {'reported_active_slot':doc['boot_active_slot_reported'],
            'boot_kernel_hashes':{k:v['kernel_sha256'] for k,v in sorted(boot.items())},
            'boot_kernel_sizes':{k:v['kernel_size'] for k,v in sorted(boot.items())},
            'loaded_module_build_ids':modules,'kernel_release':doc['kernel_release']}


def run(bundle:Path|str, output:Path|str)->dict:
    root=Path(bundle);output=Path(output)
    verify_manifest(root)
    old=json.loads((root/'evidence/R20_RUN39774000774_BUILD_RESULT.json').read_text())
    current=json.loads((root/'evidence/R20_RUN39910955809_BUILD_RESULT.json').read_text())
    for data in (current,old):
        if (data.get('status')!='R20_WALT_ON_VMLINUX_IMAGE_DTB_AND_MODULE_BUILD_PROVEN_NO_FLASH'
            or not (data['vmlinux_linked'] and data['kernel_image_built'] and data['dtbs_built'] and data['modules_built'])
            or data['flash_allowed'] is not False or data['brene_changed'] is not False):
            raise ValueError('R32_R20_BUILD_ATTESTATION_FAILED')
    if current['image']['sha256']==old['image']['sha256']:
        raise ValueError('R32_DIFFERENT_RUN_IMAGETYPE_COLLAPSED')
    image=(root/(BASE+'arch/arm64/boot/Image')).read_bytes()
    if checksum(image)!=current['image']['sha256'] or len(image)!=current['image']['bytes']:
        raise ValueError('R32_R20_IMAGE_NOT_FROM_TARGET_RUN')
    img=analyze_arm64_image(image)
    if not img['kernel_banner'].startswith('Linux version 5.4.274~positron '):
        raise ValueError('R32_WRONG_KERNEL_VERSION_BANNER')
    dtb_blob=(root/(BASE+'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb')).read_bytes()
    if checksum(dtb_blob)!=current['dtb_files'][0]['sha256'] or len(dtb_blob)!=current['dtb_files'][0]['bytes']:
        raise ValueError('R32_R20_DTB_NOT_FROM_TARGET_RUN')
    dtb=analyze_dtb(dtb_blob)
    symvers=(root/(BASE+'Module.symvers')).read_bytes()
    old_symvers=(root/'evidence/R20_RUN39774000774_Module.symvers').read_bytes()
    if checksum(symvers)!=current['module_symvers_sha256'] or checksum(old_symvers)!=old['module_symvers_sha256']:
        raise ValueError('R32_SYMVERS_WRONG_RUN')
    db=parse_symvers(symvers); old_db=parse_symvers(old_symvers)
    if db!=old_db or checksum(symvers)==checksum(old_symvers):
        raise ValueError('R32_SYMVERS_SEMANTIC_EQUIVALENCE_NOT_PROVEN')
    config=(root/'evidence/R20_CONFIG.config').read_text('utf8')
    device_config=(root/'evidence/R22_RUNNING_CONFIG.config').read_text('utf8')
    if checksum(config.encode())!=current['provenance']['config_sha256'] or checksum(device_config.encode())!=old_config_SHA:
        raise ValueError('R32_CONFIG_PROVENANCE_BROKEN')
    flags=['CONFIG_SCHED_WALT','CONFIG_SCHED_CASS','CONFIG_NR_CPUS','CONFIG_DEBUG_PREEMPT',
           'CONFIG_ANDROID_KABI_RESERVE','CONFIG_ANDROID_VENDOR_OEM_DATA','CONFIG_MODVERSIONS',
           'CONFIG_MODULES','CONFIG_PREEMPTION']
    configuration={k:{'r20':read_config(config,k),'device':read_config(device_config,k)} for k in flags}
    if (configuration['CONFIG_SCHED_WALT']['r20']!='y' or
        configuration['CONFIG_SCHED_CASS']['device']!='y' or
        configuration['CONFIG_ANDROID_KABI_RESERVE']['r20']!='y' or
        configuration['CONFIG_ANDROID_KABI_RESERVE']['device']!='n' or
        configuration['CONFIG_MODVERSIONS']!={'r20':'y','device':'y'}):
        raise ValueError('R32_KERNEL_CONFIGURATION_GUARD_FAILED')
    baseline={m['path']:m for m in current['module_files']}
    old_baseline={m['path']:m for m in old['module_files']}
    if set(baseline)!=set(SIX_MODULES) or set(old_baseline)!=set(SIX_MODULES):
        raise ValueError('R32_NOT_SIX_ATTESTED_MODULES')
    module_details=[];all_imports=[]
    for path in SIX_MODULES:
        file=root/(BASE+path);blob=file.read_bytes()
        if checksum(blob)!=baseline[path]['sha256'] or len(blob)!=baseline[path]['bytes']:
            raise ValueError('R32_R20_MODULE_FILE_ATTESTATION_FAILED:'+path)
        if baseline[path]['sha256']!=old_baseline[path]['sha256']:
            raise ValueError('R32_CROSS_RUN_MODULE_BYTES_DIFFER:'+path)
        meta=parse_elf(blob)
        if (meta['name']!=Path(path).stem.replace('-', '_') or
            meta['vermagic']!='5.4.274~positron SMP preempt mod_unload modversions aarch64'):
            raise ValueError('R32_BAD_ATTESTED_MODULE_METADATA:'+path)
        for symbol,crc in sorted(meta['imports'].items()):
            match=db.get(symbol)==crc
            all_imports.append({'family':'R20','module':meta['name'],'symbol':symbol,
                         'module_crc':f'0x{crc:08x}',
                         'kernel_crc':f'0x{db[symbol]:08x}' if symbol in db else '',
                         'status':'matching_crc' if match else 'missing_export' if symbol not in db else 'crc_mismatch'})
            if not match:raise ValueError('R32_R20_MODULE_EXPORT_NOT_MATCHED:'+symbol)
        if meta['imports'].get('module_layout')!=db.get('module_layout'):
            raise ValueError('R32_MODULE_LAYOUT_MISMATCH:'+path)
        module_details.append({'path':path,'name':meta['name'],'build_id':meta['build_id'],
                              'vermagic':meta['vermagic'],'sha256':checksum(blob),
                              'import_count':len(meta['imports']),'matching_imports':len(meta['imports'])})
    if sum(x['import_count'] for x in module_details)!=307:
        raise ValueError('R32_UNEXPECTED_R20_MODULE_IMPORT_COUNT')
    source=json.loads((root/'evidence/R31_RESULT.json').read_text())
    if (source.get('status')!='SOURCE_BINARY_PAIR_CRC_PROVEN_NO_FLASH' or
        source.get('r20_rebuilt_modules_matching_imports')!=140 or
        source.get('r20_symvers_sha256')!=old['module_symvers_sha256'] or
        source.get('flash_allowed') is not False):
        raise ValueError('R32_R31_SOURCE_GATE_NOT_REPRODUCED')
    for name in ('rmnet_shs','rmnet_offload'):
        p=root/'evidence/DEVICE_2EF0'/(name+'.ko'); b=p.read_bytes();m=parse_elf(b)
        prior=source['modules'][name]['DEVICE_2EF0']
        if checksum(b)!=prior['file_sha256'] or m['build_id']!=prior['build_id']:
            raise ValueError('R32_LEGACY_MODULE_NOT_FROM_DEVICE_GENERATION')
        legacy_matches=0;legacy_mismatches=0;legacy_missing=0
        for symbol,crc in sorted(m['imports'].items()):
            k=db.get(symbol)
            s='missing_export' if k is None else ('matching_crc' if k==crc else 'crc_mismatch')
            all_imports.append({'family':'DEVICE_2EF0','module':name,'symbol':symbol,
                                'module_crc':f'0x{crc:08x}',
                                'kernel_crc':f'0x{k:08x}' if k is not None else '', 'status':s})
            legacy_matches+=s=='matching_crc';legacy_mismatches+=s=='crc_mismatch';legacy_missing+=s=='missing_export'
        if (legacy_matches,legacy_mismatches,legacy_missing)!=(prior['symbol_matches'],prior['crc_mismatches'],prior['missing_exports']):
            raise ValueError('R32_LEGACY_ABI_COMPARISON_DRIFT')
    device=validated_device_evidence(root)
    r30=json.loads((root/'evidence/R30_RESULT.json').read_text('utf8'))
    if (r30.get('read_only') is not True or
        r30.get('conclusion',{}).get('vendor_abi_proven') is not False or
        r30.get('kernel_release')!=device['kernel_release']):
        raise ValueError('R32_R30_ORIGIN_NOT_VERIFIED')
    notes=(root/'evidence/R30_AKTIVE_GENERATION.txt').read_text('utf8')
    if ('AKTIVE_GENERATION=e7dbc6f47b011428e80d1cba578d7c5b6cfd054bc0aad74e7058dc66f067dd06' not in notes or
        'rmnet_offload=LIVE' not in notes or 'rmnet_shs=LIVE' not in notes):
        raise ValueError('R32_R30_ACTIVE_GENERATION_MISSING')
    boot_ref=[historic_boot_header((root/('evidence/'+f)).read_bytes(),f) for f in
              ('R22_HISTORIC_BOOT_A_HEADER_20261019.bin','HISTORIC_STOCK_BOOT_HEADER.bin')]
    blockers=[
        'Keine aktuelle boot.img/vender_boot-DTB-Byteidentitaet mit dem R20-Image bzw. DTB nachgewiesen.',
        'R20 verwendet 5.4.274~positron; laufendes VEUX meldet 5.4.274-qgki-g82179e362f33.',
        'R20 WALT=y und Android KABI reserve=y; laufendes VEUX CASS=y und KABI reserve=n.',
        'Nur die sechs R20-internen Module wurden CRC-geprueft; restliche ROM/Vendor-ABI nicht freigegeben.',
        'R30-Lader nutzt weiterhin alte 2EF0-Module; kein validierter Wechsel zum R20-Modulpaar.',
        'DTB ist syntaktisch gueltig, passt aber noch nicht nachweislich zum aktiven Vendor-Boot/Board.',
        'Keine Boot-, SELinux-, VINTF-, BakaSU-, SUSFS- oder NoMount-Geratevalidierung.',
    ]
    report={
        'schema':'VEUX_R32_STATIC_IMAGE_DTB_MODULE_GATE_V1',
        'audit_status':'PASS_STATIC_PROVENANCE_WITH_BOOT_BLOCKERS',
        'kernel_run_used':39910955809,'historical_comparison_run':39774000774,
        'image':img,'dtb':dtb,'historical_boot_headers':boot_ref,
        'symvers':{'newer_sha256':checksum(symvers),'older_sha256':checksum(old_symvers),
                   'same_crc_map':True,'export_count':len(db),'byte_identical':False},
        'r20_modules':module_details,
        'r20_all_six_module_imports':len([r for r in all_imports if r['family']=='R20']),
        'r20_matching_imports':sum(r['status']=='matching_crc' for r in all_imports if r['family']=='R20'),
        'legacy_imports_compared':len([r for r in all_imports if r['family']=='DEVICE_2EF0']),
        'configuration':configuration,'device':device,'r30_device_module_loader_observed':True,
        'device_boot_partition_byte_match_proven':False,
        'vendor_boot_dtb_match_proven':False,'other_vendor_modules_abi_proven':False,
        'boot_ready':False,'flash_allowed':False,'kernel_built_in_r32':False,
        'module_installed':False,'brene_changed':False,'repo_mutated':False,
        'blockers':blockers,'next_safe_step':'Current vendor_boot DTB identity and remaining Vendor module ABI needs authenticated comparison before boot packing.'
    }
    if report['r20_matching_imports']!=307 or report['r20_all_six_module_imports']!=307:
        raise ValueError('R32_SEMANTIC_CRC_GATE_NOT_GREEN')
    output.mkdir(parents=True,exist_ok=True)
    (output/'R32_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True,ensure_ascii=False)+'\n','utf8')
    (output/'R32_DTB_INSPECTION.json').write_text(json.dumps(dtb,indent=2,sort_keys=True,ensure_ascii=False)+'\n','utf8')
    (output/'R32_BOOT_COMPARISON.json').write_text(json.dumps({'device':device,'historical_headers':boot_ref,
               'r20_image':{'size':img['bytes'],'sha256':img['sha256'],'banner':img['kernel_banner']},
               'r20_dtb':{'size':dtb['bytes'],'sha256':dtb['sha256']},
               'result':'NOT_PROVEN_COMPATIBLE','comparison_limitation':'Current device boot payload is compressed or packed; no raw R20-vs-device byte identity proof.'},
               indent=2,ensure_ascii=False)+'\n','utf8')
    with (output/'R32_MODULE_IMPORTS.csv').open('w',newline='',encoding='utf8') as f:
        wr=csv.DictWriter(f,fieldnames=['family','module','symbol','module_crc','kernel_crc','status']);wr.writeheader();wr.writerows(all_imports)
    lines=[
        'VEUX R32 - statischer Kernel-Image/DTB/RMNET-/Vendor-Befund (NO FLASH)',
        'Status: Originale R20-Image+DTB und 6 Module kryptografisch Run 39910955809 zugeordnet.',
        '6/6 AArch64-Module, 307/307 Modulimporte mit den 14.260 Kernel-Export-CRCs passend.',
        'Symboltabelle Run 39774000774 hat dieselben 14.260 CRCs, aber andere Dateireihenfolge.',
        'Kernel-Images der beiden R20-Runs haben unterschiedliche SHA256-Werte.',
        'DTB formal gueltig, root model/compatible: '+repr(dtb['root_model'])+'/'+repr(dtb['root_compatible']),
        'R20-Imagekennung: '+img['kernel_banner'][:110],
        'Geraetekennung: '+device['kernel_release'],
        'R32 ist kein Build, kein AK3, keine boot.img, keine Flashfreigabe.',
        '', 'OFFENE BOOT-SPERRGRUENDE:', *('- '+x for x in blockers),'',
        'WICHTIG: CRC- und ELF-Integritaet bestaetigen NICHT die Bootfaehigkeit oder Vendor-ABI.',
    ]
    (output/'R32_BERICHT_DE.txt').write_text('\n'.join(lines)+'\n','utf8')
    files=sorted(p for p in output.iterdir() if p.is_file())
    (output/'SHA256SUMS.txt').write_text(''.join(checksum(p.read_bytes())+'  '+p.name+'\n' for p in files),'utf8')
    return report


# R22 capture is a supplied original device config archived 23 Oct 2026.
old_config_SHA='405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'

def main()->None:
    ap=argparse.ArgumentParser()
    ap.add_argument('--bundle',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args()
    report=run(a.bundle,a.out)
    print('R32_STATIC_PROVENANCE=PASS; R20_ALL_SIX_IMPORTS='+str(report['r20_matching_imports'])+'/307; BOOT_READY=NO; VENDOR_ABI=UNPROVEN; FLASH=NO')

if __name__=='__main__':main()
