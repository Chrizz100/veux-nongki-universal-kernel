VEUX R32 – STATISCHER ORIGINAL-IMAGE/DTB/MODULE-NACHWEIS, KEIN FLASH
23. Oktober 2026

Repository: Chrizz100/veux-nongki-universal-kernel
1) VEUX_R32_IMAGE_DTB_ABI_MAIN.zip UNENTPACKT in das Hauptverzeichnis von main hochladen.
2) VEUX_R32_IMAGE_DTB_ABI_GATE.yml nach .github/workflows/ laden.
3) GitHub Actions: "VEUX R32 - Pinned Image DTB and Six Module Static Gate" manuell starten.
4) Das generierte Diagnoseartefakt zum Vergleich bereitstellen.

Das ZIP enthält ein echtes, UNVERÄNDERTES, NICHT FLASHBARES Linux Image,
DTB, 6 Module und Beweise als Eingabedateien. Es ist KEIN Installationspaket,
kein AnyKernel3 und enthält keine fertige boot.img. NICHT flashen/entpacken auf
Gerät. R32 schreibt keine Kernelquellen, verändert BReNE nicht, verwendet
keine Gerätezugriffe und erstellt keine Installation.

Anker:
  Run 39910955809: vollständiger R20-Build, Image / DTB / Module.symvers und 6 Module
  Run 39774000774: originaler älterer R20-Build, getrennte Attestationen;
                   anderes Image/Symvers SHA, aber gleiche 14260 Symbol-CRCs
  Run 40010709414: R31 140/140 RMNET-ABI-Beweis
  R28/R30: aktuelles Gerät / aktive Modul-Generation – nur archivierte Metadaten

Bewertung: Selbst ein komplett grüner R32-Test beweist KEIN kompatibles boot.img.
Verbleibende Sperren: Vendor-ABI gesamt, tatsächliches DTB zum Gerät, Kernel-
Kennung, CASS/WALT-Strukturen, Loader-Integration, Boot und Runtime-Tests.
