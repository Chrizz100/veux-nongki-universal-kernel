VEUX M39 - Spaete Provider-Bindung und leere IIO-Spezifikationen - NOFLASH
Basis: gruener M38-Lauf 43870025146, Commit 0a7cf011c6817aef9c729daa5d669199ec0a0626.

UPLOAD AM SMARTPHONE
1. VEUX_M39_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M39_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M38 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256 und komplette ZIP-CRC geprueft:
1.348 Dateien, 1.253 Textdateien, 345 JSON-Dateien, 40.065.648 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M38 unabhaengig geprueft:
echte Quellen, LLVM-Objekt/CFI-Kommando, 13 verlinkte Schnittstellen und sechs
neue Fehlerzweige, 40 erfolgreiche make-Aufrufe, eingebettete Konfiguration
in Image/vmlinux und unveraenderte komplette Exporttabelle.
Import-CRCs unabhaengig neu berechnet: 1.423 passend, keine CRC-Abweichung,
kein fehlender Export und 37 passende Module der bekannten Stock-Vendor-Kohorte.
Boot.img und AK3 byteidentisch aus gepinnten Referenzen rekonstruiert;
AVB und Stock-Ramdisk/Paar geprueft. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M38. Reports/RUN43870025146_32_ARTEFAKTE.zip und
Reports/M38_INDEPENDENT_VERIFICATION.json enthalten die aktuelle Auswertung.
Historische Berichte und alte CLI-Kommandokopien bleiben in den unveraenderten,
gepinnten Vorgaengerpaketen. Dieses Paket fuehrt nur die aktuellen Kommandoreferenzen.
Static Boot Pass ist kein Device Pass.

M39 REPARATUR AUS DER RESTLISTE
P1, spaete Bindung: Ein beim Probe noch fehlender Batterie- oder USB-Provider
wird beim naechsten benoetigten Zugriff erneut ueber seinen bisherigen Namen
gesucht. Ein vorhandener Cache benoetigt keine neue Lookup-Referenz.
Das Veroeffentlichen des Caches erfolgt atomar; Leser uebernehmen den Pointer
mit Acquire-Semantik. Von parallelen Nachsuchen behaelt genau eine Referenz den
Cacheplatz. Jede uebrige erfolgreiche Lookup-Referenz wird sofort freigegeben.
Nach gesetztem Stoppzustand beginnt keine neue Nachsuche. Eine bereits laufende
Nachsuche bleibt Teil ihres IIO-/Worker-Aufrufs; der unveraenderte Shutdown wartet
auf diese Aufrufe und gibt anschliessend die gehaltenen Cache-Referenzen frei.
USB-Benachrichtigungen verwenden den spaet gefundenen Provider und bleiben bei
weiterhin fehlendem Provider aus. Batterie-Zugriffe in Adapter, Monitor und IIO-
Writer verwenden dieselbe Nachsuche. Bisherige Missing-Battery-Fallbacks und
numerische Strom-/Spannungs-/Temperaturregeln bleiben erhalten. Wenn weiter kein
Provider existiert, erfindet M39 keinen Messwert und keine neue Abschaltpolitik.
Eine Warnung dokumentiert den fehlenden Provider; Property-Fehler bleiben in
den bereits geprueften jeweiligen M38-Pfaden behandelt.

P3, IIO-Laenge: Die BQ-Uebersetzung weist Laengen kleiner als eins ab, bevor
args[0] gelesen wird. Alle 14 bisherigen Kanal-IDs und das Verhalten bei positiven
Argumentzahlen bleiben gleich. Insbesondere wird keine neue Genau-ein-Argument-
Regel eingefuehrt: Der generische IIO-Core erlaubt fuer andere Provider auch null
Argumente; dieser BQ-Translator benoetigt fuer seine bisherige Auswahl args[0].

Geaendert sind vier reine Provider-Aufrufstellenfunktionen, der IIO-Translator
und zwei neue Lookup-/Benachrichtigungshelfer. Ausser den exakt erlaubten
Aufrufstellen und dem Laengenguard bleiben alle bisherigen Treiberbytes gleich.
Registerschutz, DPDM/ICO, Hard-IRQ-Deferral, Remove/Shutdown und die Lade-Regeln
bleiben erhalten. Keine Defconfig-, Header- oder Export-Aenderung.
bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-Zeilenumbruch.

API-GRUNDLAGE UND GRENZEN
References/PROVIDER_API_CONTEXT.json nennt die exakt gepinnten Quellen und Hashes.
power_supply_get_by_name liefert NULL oder eine gezaehlte Lookup-Referenz.
power_supply_put gibt diese frei und darf schlafen. Alle neuen Lookup-/Put-Pfade
liegen in Work-/IIO-Kontext; der harte IRQ bleibt unveraendert.
power_supply_unregister erwartet bereits abgegebene Nutzerreferenzen. M39 loest
kein beliebiges Hot-Unregister oder Ersetzen eines bereits gecachten Providers.
Diese Lebensdauer-/Teardown-Reihenfolge muss anhand der tatsaechlichen Geraete-
und Konsumentenbeziehungen geklaert werden. Auch erfolgt die spaete Nachsuche
beim naechsten Zugriff und ist kein neuer Registrierungs-Notifier.

LOKALE PRUEFUNGEN
48 M39-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Neuer nativer Test: 5.501 C-Assertions, vier Bindungs-/Stoppablaeufe, 96 parallele
Cache-Szenarien mit bis zu 64 echten Threads, 16 Nichtverfuegbarkeitsabfragen und
295 IIO-Spezifikationsfaelle. Alle 14 realen Kanal-IDs stammen aus dem mitgebauten
Binding-Header; dessen Hash ist in References/BOUND_IIO_CHANNEL_IDS.json enthalten.
Geprueft sind fehlend -> verfuegbar, wiederholte Cache-Nutzung ohne weitere Gets,
verlorene CAS-Kandidaten mit passendem Put, beide Provider gleichzeitig, USB-
Benachrichtigungen, Stopp vor Lookup sowie ein bereits laufender Lookup bei Stopp.
Die Mock-Referenzen zaehlen Lookup-Referenzen, nicht die Registrierungsreferenz.
Ein alter M38-Translator akzeptiert eine leere Spezifikation mit passendem stale
args[0]; das ist reproduziert. Der negative Kontrolllauf haelt die neuen Lookup-
Helfer fest und fuehrt gezielt den alten Translator aus: Er scheitert am Guard.
Die Tests der bisherigen Register-/Lade-Erfolgs- und Fehlerpfade laufen auf M39
weiter unveraendert. Alle aktuellen nativen Tests: 145.081 C-Assertions, dazu
156 Assertions des unveraenderten alten Probetests auf der M31-Referenz.
Der komplette Treiber kompiliert fuer ARM64 mit gepinntem AOSP Clang 12.0.5,
CFI/ThinLTO und den Headern des aktuellen M38-Laufs. Kein voller lokaler M39-Kernelbau.

AKTUALISIERTES INVENTAR UND FESTE RESTLISTE
67 aktive BQ-Funktionen sind inventarisiert: sieben M39-Funktionen, 21 zu bisherigen
nativen Regressionen zugeordnet und 39 als reine Quellpruefung klassifiziert.
Das ist kein eigener Fehlertest fuer jede Funktion oder fuer den ganzen Kernel.
Reports/M39_BQ_FUNCTION_INVENTORY.json und .csv enthalten alle Eintraege.
P1: Spaete Bindung repariert; Hot-Unregister und tatsaechliche Provider-/Geraete-
    Teardown-Reihenfolge bleiben offen. Bisherige Fallback-Politik bleibt erhalten.
P2: Reihenfolge kompletter Adapter-/Monitor-/IIO-Ablaufe bleibt offen. Register-RMWs
    sind geschuetzt; mehrstufige Workflows sind nicht als Ganzes serialisiert.
P3: Leere Spezifikation abgesichert; Konsumentenvertraege, numerische Bereiche,
    Einheiten und GPIO-/DT-Zuordnung bleiben vor weiteren Aenderungen zu belegen.
D1: Reales Booten, Laden/OTG, Temperatur, Suspend, Abziehen und Entfernen/Rebind.
K1: Historische ueber 7.100 Ganzkernel-Quellabweichungen sind nicht vollstaendig
    durch dieses BQ-Inventar abgedeckt; kein universeller GKI-Nachweis.

CI UND NAECHSTER MEILENSTEIN
Alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue Schicht nutzt den authentischen M28-R2-Baukern mit allen Konfigurations-,
WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M39 muss echte Quellen, LLVM-Objekt,
CFI-Kommando, 14 verlinkte Schnittstellen und zwei neue Zweige in Image UND vmlinux
nachweisen. Konfiguration und komplette Exporttabelle bleiben Pflicht.
Boot.img/AK3 werden erst nach diesen Gates erstellt.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M39-GitHub-Bau und alle Artefakte sowie die benannten
Restpunkte. Device Pass NEIN. Flashfreigabe NEIN.
