"""No device. Isolated negative and happy-path checks for R8 variant tooling."""
import sys,unittest, tempfile, pathlib, csv, json, hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'Tools'))
import abi_variant as a

ROOT=Path(__file__).resolve().parents[1]

class AbiTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.c,cls.s,cls.expected,cls.original,cls.imports=a.profile(ROOT/'Evidence')
  cls.r46=ROOT/'Evidence'/'QGKI_R46_ORIGINAL_VERIFIED_SYMBOL_CRC.csv'
 def test_stock_knowledge(self):
  self.assertEqual(self.s['CONFIG_NR_CPUS'],'32')
  self.assertEqual(self.c['CONFIG_NR_CPUS'],'32')
  self.assertEqual(self.s['CONFIG_ARM64_LSE_ATOMICS'],'n')
  self.assertEqual(self.c['CONFIG_ARM64_LSE_ATOMICS'],'y')
 def test_expected_original_module_layout(self):
  self.assertEqual(self.expected['module_layout'],'0x945d02f2')
  self.assertEqual(self.original['module_layout'],'0x0bcef28c')
 def test_37_modules_and_3148_imports(self):
  self.assertEqual(len(self.imports),3148)
  self.assertEqual(len(set(x['module'] for x in self.imports)),37)
 def test_1423_symbols_and_missing_four(self):
  self.assertEqual(len(self.expected),1423)
  self.assertEqual(sorted(k for k,v in self.original.items() if not v),
                   ['cpumask_next','hardwareinfo_set_prop','nr_cpu_ids','smartpa_type'])
 def test_crc_baseline_count_578_841_4(self):
  syms={k:v for k,v in self.original.items() if v}
  rows,mods,counts=a.compare_symbols(syms,self.expected,self.imports)
  self.assertEqual(dict(counts),a.EXPECTED_ORIGINAL_COUNTS)
  self.assertEqual(sum(x['fully_compatible'] for x in mods),0)
 def test_one_symbol_improvement_does_not_confer_abi_green(self):
  syms={k:v for k,v in self.original.items() if v}
  syms['module_layout']=self.expected['module_layout']
  _,mods,counts=a.compare_symbols(syms,self.expected,self.imports)
  self.assertEqual(counts['MATCH'],579)
  self.assertLess(sum(x['fully_compatible'] for x in mods),37)
 def test_exclusion_of_gki_cohort(self):
  rows=a.readcsv(self.r46)
  self.assertTrue(any(x['cohort']=='GKI' for x in rows))
  self.assertEqual(len([x for x in rows if x['cohort']=='QGKI']),1423)
 def test_reject_duplicate_config(self):
  with self.assertRaisesRegex(a.GateError,'CONFIG_DUPLICATE'):
   a.parse_config('CONFIG_A=y\nCONFIG_A=n\n'+''.join('CONFIG_Z%d=y\n'%i for i in range(150)))
 def test_config_parser_represents_not_set_as_n(self):
  c=a.parse_config('# CONFIG_BLA is not set\n'+''.join('CONFIG_Z%d=y\n'%i for i in range(150)))
  self.assertEqual(c['CONFIG_BLA'],'n')
 def test_symbol_table_rejects_bad_crc(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'sym';p.write_text('0xZZAABBCC\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n')
   with self.assertRaisesRegex(a.GateError,'SYMVERS_CRC_INVALID'):
    a.parse_symvers(p)
 def test_symbol_table_rejects_duplicates(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t)/'sym';p.write_text('0x12345678\tname\tvmlinux\tEXPORT_SYMBOL\n'*2)
   with self.assertRaisesRegex(a.GateError,'SYMVERS_DUPLICATE'):
    a.parse_symvers(p)
 def test_reject_altered_oem_crc_evidence(self):
  with tempfile.TemporaryDirectory() as d:
   q=Path(d)
   for p in (ROOT/'Evidence').iterdir(): (q/p.name).write_bytes(p.read_bytes())
   path=q/'QGKI_37_ORIGINAL_MODULE_IMPORTS.csv'
   t=path.read_text();self.assertIn('0x95de35b9',t)
   path.write_text(t.replace('0x95de35b9','0x00000000',1))
   with self.assertRaisesRegex(a.GateError,'QGKI_IMPORT_CRC_REFERENCE_CHANGED'):a.profile(q)
 def test_reject_config_source_drift(self):
  with tempfile.TemporaryDirectory() as d:
   q=Path(d)
   for p in (ROOT/'Evidence').iterdir(): (q/p.name).write_bytes(p.read_bytes())
   (q/'R46_EFFECTIVE_BUILD.config').write_text('CONFIG_ARM64_LSE_ATOMICS=n\n')
   with self.assertRaisesRegex(a.GateError,'CANDIDATE_CONFIG_SOURCE_DRIFT'):a.profile(q)
 def test_no_fake_stock_commit_or_vendor_crc_write(self):
  code=(ROOT/'Tools'/'abi_variant.py').read_text()
  self.assertNotIn('echo 0x945d02f2',code)
  self.assertNotIn('modprobe',code)
  self.assertNotIn('fastboot',code)
  self.assertNotIn('setprop',code)


 def test_lse_parent_in_donor_not_in_stock(self):
  self.assertEqual(self.c[a.PARENT_KEY], 'y')
  self.assertNotIn(a.PARENT_KEY,self.s)
  self.assertEqual(a.SOURCE_KEY,'CONFIG_ARM64_LSE_ATOMICS')

 def test_requested_is_exactly_one_parent_switch(self):
  changed=dict(self.c); changed[a.PARENT_KEY]='n'
  self.assertEqual(a.expected_lse_deltas(self.c,changed,'requested'),{a.PARENT_KEY:('y','n')})

 def test_accept_exact_parent_and_derived_after_kconfig(self):
  changed=dict(self.c); changed[a.PARENT_KEY]='n';changed[a.SOURCE_KEY]='n'
  self.assertEqual(a.expected_lse_deltas(self.c,changed,'resolved'),{a.PARENT_KEY:('y','n'),a.SOURCE_KEY:('y','n')})

 def test_reject_hidden_only_after_kconfig(self):
  changed=dict(self.c); changed[a.SOURCE_KEY]='n'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_extra_config_setting_after_kconfig(self):
  changed=dict(self.c);changed[a.PARENT_KEY]='n';changed[a.SOURCE_KEY]='n';changed['CONFIG_NR_CPUS']='8'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_parent_switch_not_reflected_in_hidden_lse(self):
  changed=dict(self.c);changed[a.PARENT_KEY]='n'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')


 def test_accept_real_run_42487597953_hidden_kconfig_omission(self):
  # The actual R8-R3 run ended with ('y', None) for the hidden LSE symbol.
  changed=dict(self.c);changed[a.PARENT_KEY]='n';changed.pop(a.SOURCE_KEY)
  self.assertEqual(a.expected_lse_deltas(self.c,changed,'resolved'),
                   {a.PARENT_KEY:('y','n'),a.SOURCE_KEY:('y',None)})

 def test_reject_omitted_parent_and_hidden(self):
  changed=dict(self.c);changed.pop(a.PARENT_KEY);changed.pop(a.SOURCE_KEY)
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_hidden_omission_with_extra_config_change(self):
  changed=dict(self.c);changed[a.PARENT_KEY]='n';changed.pop(a.SOURCE_KEY);changed['CONFIG_NR_CPUS']='8'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_hidden_omission_without_parent_disabled(self):
  changed=dict(self.c);changed.pop(a.SOURCE_KEY)
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_hidden_still_enabled(self):
  changed=dict(self.c);changed[a.PARENT_KEY]='n'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_reject_hidden_m_after_kconfig(self):
  changed=dict(self.c);changed[a.PARENT_KEY]='n';changed[a.SOURCE_KEY]='m'
  with self.assertRaisesRegex(a.GateError,'LSE_NOT_EXACT_DERIVED_DELTA_RESOLVED'):
   a.expected_lse_deltas(self.c,changed,'resolved')

 def test_static_kconfig_parent_guard(self):
  text='config ARM64_LSE_ATOMICS\n\tbool\n\tdefault ARM64_USE_LSE_ATOMICS\n\tdepends on X\n\nconfig ARM64_USE_LSE_ATOMICS\n\tbool "Atomic instructions"\n\tdepends on Y\n'
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'arch/arm64';path.mkdir(parents=True);(path/'Kconfig').write_text(text)
   self.assertTrue(a.kconfig_dependency_proven(Path(d)))
   (path/'Kconfig').write_text(text.replace('default ARM64_USE_LSE_ATOMICS','default y'))
   with self.assertRaisesRegex(a.GateError,'LSE_KCONFIG_PARENT_SEMANTICS_CHANGED'):
    a.kconfig_dependency_proven(Path(d))

 def test_script_uses_visible_parent_not_hidden_config_override(self):
  code=(ROOT/'Tools'/'abi_variant.py').read_text()
  self.assertIn("'-d','ARM64_USE_LSE_ATOMICS'",code)
  self.assertNotIn("'-d','ARM64_LSE_ATOMICS'",code)

if __name__=='__main__': unittest.main()
