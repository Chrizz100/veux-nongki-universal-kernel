"""Conservative workflow invariants: verify old R46 steps unmodified; two additions only."""
import os
from pathlib import Path
import re
import subprocess
import unittest
import yaml

BASENAME='VEUX_R46_R6_CONFIG_RELEASE_VENDOR_ABI_NOFLASH.yml'
BASE_OLD='VEUX_R46_R2_WALT_SOURCE_PROVENANCE_FIX_NOFLASH.yml'
OLD_SHA='861533c64839ca1cfa9f23efc4d137bbb163278840b28520f1c8f970415c04d9'
PRE='R47-R13 SHA-pinned historical built-in patch actionlint ShellCheck regression gate'
NEW='R47-R13 rebuild actual ARM64 WALT Image DTB modules with both RMNET built-ins'
UP='R47-R13 preserve separate text-only build evidence on failures'

class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.new_path=Path(os.environ['R47_WORKFLOW'])
        cls.old_path=Path(os.environ['R47_R46_WORKFLOW'])
        cls.new=yaml.safe_load(cls.new_path.read_text())
        cls.old=yaml.safe_load(cls.old_path.read_text())
        cls.newsteps=cls.new['jobs']['p11-exact-source']['steps']
        cls.oldsteps=cls.old['jobs']['p11-exact-source']['steps']
        cls.names=[x['name'] for x in cls.newsteps]
        cls.raw=cls.new_path.read_text()
    def test_34_old_workflow_sha_unchanged(self):
        import hashlib
        self.assertEqual(hashlib.sha256(self.old_path.read_bytes()).hexdigest(),OLD_SHA)
    def test_35_exact_original_r46_steps_preserved(self):
        # Guarded compatibility exception for the *single* 504-proof actionlint replacement.
        # Every other historical R46 step must still compare identically, including run bodies.
        import hashlib
        kept=[s for s in self.newsteps if s['name'] not in {PRE,NEW,UP}]
        self.assertEqual(len(kept),len(self.oldsteps))
        old_step_name='Pin actionlint 1.7.12 and validate R6 YAML before replay'
        new_step_name='Reuse SHA-pinned local actionlint 1.7.12 and validate both YAMLs before replay'
        old_hits=[i for i,s in enumerate(self.oldsteps) if s.get('name')==old_step_name]
        new_hits=[i for i,s in enumerate(kept) if s.get('name')==new_step_name]
        self.assertEqual(old_hits,[3]); self.assertEqual(new_hits,[3])
        old_run=self.oldsteps[3]['run']; new_run=kept[3]['run']
        self.assertEqual(hashlib.sha256(old_run.encode()).hexdigest(),'aa5a3cb8900ee1bb23c75bca071ba20a1144562c66f7fc9e46dc1ef79b67e8a4')
        self.assertEqual(hashlib.sha256(new_run.encode()).hexdigest(),'7ff69c335572504d648f9fca80b3fe234b186c1ecb5feb5209de12af17cd48cc')
        self.assertNotIn('curl ',new_run)
        self.assertIn('sha256sum -c --strict',new_run)
        self.assertIn('VEUX_R39_R2_MEMORY_ABI_MAIN.zip',new_run)
        self.assertIn('R47_WORKFLOW',new_run)
        kept[3]=self.oldsteps[3]
        self.assertEqual(kept,self.oldsteps)
    def test_36_extra_steps_exact_three(self):
        self.assertEqual(len(self.newsteps),len(self.oldsteps)+3)
        self.assertEqual(len(set(self.names)),len(self.names))
    def test_37_new_preflight_before_original_build(self):
        self.assertLess(self.names.index(PRE),self.names.index('R20 genuine WALT-ON ARM64 full Image DTBs and modules make with linked vmlinux'))
    def test_38_new_build_after_original_R46_artifact_archived(self):
        self.assertLess(self.names.index('R20 upload unverified non-flash link products ONLY after true full-build result'),self.names.index(NEW))
        self.assertLess(self.names.index('R44 preserve patch, reference-semantic audit and full-build proof (no image)'),self.names.index(NEW))
        self.assertLess(self.names.index(NEW),self.names.index(UP))
    def test_39_last_step_repo_guard_preserved(self):
        self.assertEqual(self.newsteps[-1]['name'],'Assert repository unchanged; R20 full-build diagnostic only; NO FLASH')
    def test_40_dispatch_only(self):
        self.assertEqual(self.new['on'],{'workflow_dispatch':{}})
        self.assertEqual(self.new['permissions'],{'contents':'read'})
    def test_41_refuses_flash(self):
        self.assertNotRegex(self.raw,r'\bfastboot\s+flash\b|\b(?:dd\s+if=|flash_image\b)')
        self.assertNotIn('git push',self.raw)
    def test_42_original_kernel_release_no_fake(self):
        self.assertNotIn('localversion\n',self.raw)
        self.assertNotIn('sed -i',self.raw)
    def test_43_valid_bash_blocks(self):
        for n,s in enumerate(self.newsteps,1):
            if not isinstance(s.get('run'),str):continue
            with self.subTest(n=n):
                r=subprocess.run(['bash','-n'],input=s['run'],text=True,capture_output=True)
                self.assertEqual(r.returncode,0,r.stderr[-1500:])
    def test_44_new_stage_pinned_script(self):
        s=self.newsteps[self.names.index(NEW)]
        self.assertIn('veux_r47_r13_on_r46.py',s['run'])
        self.assertIn('--source "$R9_SNAPSHOT"',s['run'])
        self.assertIn('--objout "$R13_OBJOUT"',s['run'])
        self.assertIn('R46_POSTBUILD_RESULT.json',s['run'])
    def test_45_new_r47_output_separate_old_r46(self):
        env=self.new['jobs']['p11-exact-source']['env']
        self.assertNotEqual(env['R47_REPORT_DIR'],env['R20_OUT'])
        self.assertNotEqual(env['R47_REPORT_DIR'],env['R46_OUT'])
    def test_46_r46_name_ref_is_not_changed(self):
        self.assertEqual(self.old['name'],'VEUX R46-R2 Rootless WALT Provenance Repair + Stock Gate - NO FLASH')
        self.assertIn('R46-R6',self.new['name'])
        self.assertIn('R46-R8-R3',self.new['name'])
    def test_47_job_strict_failure_if_new_build_fails(self):
        self.assertNotIn('continue-on-error',self.newsteps[self.names.index(NEW)])
        self.assertNotIn('|| true',self.newsteps[self.names.index(NEW)]['run'])
    def test_48_no_flashable_binary_in_r47_artifact(self):
        s=self.newsteps[self.names.index(UP)]
        self.assertEqual(s['with']['path'],'${{ env.R47_REPORT_DIR }}/')
        self.assertNotIn('Image',s['with']['path'])
        self.assertEqual(s['with']['retention-days'],30)
    def test_49_r47_preflight_actionlint_shellcheck(self):
        s=self.newsteps[self.names.index(PRE)]['run']
        for k in ('actionlint','shellcheck','MANIFEST_SHA256.txt','unittest','sha256sum'):
            self.assertIn(k,s)
        self.assertNotIn('|| true',s)
    def test_50_original_configs_and_toolchain_pinned(self):
        env=self.new['jobs']['p11-exact-source']['env']
        o=self.old['jobs']['p11-exact-source']['env']
        for k,v in o.items():self.assertEqual(env.get(k),v)

if __name__=='__main__':unittest.main()
