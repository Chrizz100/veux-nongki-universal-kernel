#!/usr/bin/env python3
"""VEUX R9: run real, bounded ARM64 Linux 5.4.274 WALT-ON make targets.

Stages only an independent copy of P3/P10 with authenticated R6/R8 headers.
Unlike R6-R8, this driver invokes the genuine kernel Kbuild compiler.
Never builds Image/modules/AK3, writes to checked-out repo or flashes device.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time

P3_TREE = '7f97dbbff432d61bbf11cae03de257a21f1d3c74'
P10_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
P10_PATCH = '5c9603350966ec06ebb6dcdb8f9b154a3715388b759b6afc12bf41a2c41a403e'
OEM_CONFIG_HASH = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
P10_WALT_C_HASH = '03ebaf13151525db262f6d20809d69bbbcd5c4fcf378c061b04d661495c72646'
R8_SCHED_HASH = '12f10b1be96b1868304dd0f5e85a8e4e421ae72383d8b76571a2dc91fd6d4f5d'
R6_FILES = ('include/linux/sched.h', 'include/linux/sched/sysctl.h', 'kernel/sched/sched.h')
OBJECTS = ('kernel/sched/walt/walt.o','kernel/sched/core.o','kernel/sched/fair.o')
FEATURES = ('CONFIG_SCHED_WALT','CONFIG_ARCH_HOLI','CONFIG_QGKI','CONFIG_MEMCG',
            'CONFIG_NR_CPUS','CONFIG_MODVERSIONS','CONFIG_LTO_CLANG','CONFIG_CFI_CLANG')
SAFE_PREP = ('Makefile','Kconfig','arch/arm64/Makefile','kernel/sched/walt/walt.c')

class AuditError(Exception):
    pass

def require(condition, reason):
    if not condition: raise AuditError(reason)

def sha(b): return hashlib.sha256(b).hexdigest()

def check_file(p:Path, expected=None):
    require(p.is_file() and not p.is_symlink(), 'UNSAFE_OR_MISSING_FILE:'+str(p))
    data=p.read_bytes()
    if expected is not None: require(sha(data)==expected,'SOURCE_SHA_MISMATCH:'+str(p))
    return data

def read_report(path):
    return json.loads(check_file(path).decode('utf-8'))

def path_outside(path:Path, others):
    p=path.resolve()
    for other in others:
        a=other.resolve()
        require(p != a and not a in p.parents and not p in a.parents,
                'MUST_USE_SEPARATE_OUTPUT_SOURCE:'+str(path))

def source_provenance(source, r6, r8, p3_file, p11_file, stock_config):
    require(source.is_dir() and not source.is_symlink(),'SOURCE_ROOT_REQUIRED')
    require(not r6.is_symlink() and r6.is_dir() and not r8.is_symlink() and r8.is_dir(),'EVIDENCE_DIR_REQUIRED')
    for name in SAFE_PREP:check_file(source/name)
    p3=read_report(p3_file); p11=read_report(p11_file)
    gate6=read_report(r6/'R6_SOURCE_GATE.json')
    gate8=read_report(r8/'R8_SOURCE_GATE.json')
    require(p3['p3_cass_free_tree']==P3_TREE and p3['kernel']=='5.4.274','P3_PIN_DRIFT')
    require(p11['source_p3_tree']==P3_TREE and p11['source_p11_composed_tree']==P10_TREE
            and p11['combined_patch_sha256']==P10_PATCH and p11['source_gate']=='PASS', 'P10_PIN_DRIFT')
    require(gate6['p3_tree']==P3_TREE and gate6['p10_composed_tree']==P10_TREE and
            gate6['strict_real_source'] is True and gate6['method']=='GIT_APPLY' and
            gate6['status']=='WALT_R6_REAL_P3_COMPATIBILITY_PRECOMPILE_STAGED', 'R6_GATE_DRIFT')
    require(gate8['status']=='R8_EXACT_R6_WALT_INTERFACE_SOURCE_BRIDGE_STAGED' and
            gate8['p3_tree']==P3_TREE and gate8['p10_composed_tree']==P10_TREE and
            gate8['modified_files']==['kernel/sched/sched.h'] and
            gate8['r8_header_after_sha256']==R8_SCHED_HASH, 'R8_GATE_DRIFT')
    for g in (gate6,gate8):
        require(not any(g.get(k) for k in ('flash_allowed','vendor_abi_proven','brene_changed','final_kernel_built')),
                'UNTRUSTWORTHY_OLD_GATE')
    check_file(stock_config,OEM_CONFIG_HASH)
    check_file(source/'kernel/sched/walt/walt.c',P10_WALT_C_HASH)
    for name in R6_FILES:
        # P10 source is still untouched by the R6/R8 staged modifications.
        check_file(source/name,gate6['source_before_sha256'][name])
        check_file(r6/'source'/name,gate6['source_after_sha256'][name])
    check_file(r8/'source/kernel/sched/sched.h',R8_SCHED_HASH)
    require(gate8['r6_header_before_sha256']==gate6['source_after_sha256']['kernel/sched/sched.h'],
            'R6_R8_CHAIN_BREAK')
    return {'p3_tree':P3_TREE,'p10_tree':P10_TREE,'r6_gate':'PASS','r8_gate':'PASS',
            'p10_walt_c_sha256':P10_WALT_C_HASH,'source_before':gate6['source_before_sha256'],
            'source_after_r6':gate6['source_after_sha256'],
            'source_after_r8_sched_h':R8_SCHED_HASH,'oem_config_sha256':OEM_CONFIG_HASH}

def config_values(s):
    result={}
    for line in s.splitlines():
        match=re.fullmatch(r'(CONFIG_[A-Z0-9_]+)=(.+)',line)
        unset=re.fullmatch(r'# (CONFIG_[A-Z0-9_]+) is not set',line)
        if not match and not unset: continue
        key=match.group(1) if match else unset.group(1)
        require(key not in result,'DUPLICATE_KCONFIG:'+key)
        result[key]=match.group(2) if match else 'n'
    return result

def stage(source, r6, r8, p3, p11, stock, snapshot, output):
    require(not snapshot.exists() and not snapshot.is_symlink(), 'SNAPSHOT_ALREADY_EXISTS')
    require(not output.exists() and not output.is_symlink(), 'AUDIT_OUTPUT_ALREADY_EXISTS')
    path_outside(snapshot,(source,r6,r8,stock.parent))
    path_outside(output,(source,r6,r8,snapshot,stock.parent))
    provenance=source_provenance(source,r6,r8,p3,p11,stock)
    # The original P10 source may contain tracked and untracked WALT files.
    # Copy the whole source, excluding Git metadata, without a source mutation.
    require(shutil.which('rsync') is not None,'RSYNC_MISSING')
    snapshot.mkdir(parents=True)
    result=subprocess.run(['rsync','-a','--exclude=.git/','--',str(source)+'/',str(snapshot)+'/'],
                          text=True,capture_output=True)
    require(result.returncode==0,'SOURCE_RSYNC_FAILED:'+result.stderr[-1000:])
    for name in SAFE_PREP:check_file(snapshot/name)
    check_file(snapshot/'kernel/sched/walt/walt.c',P10_WALT_C_HASH)
    for name in R6_FILES:check_file(snapshot/name,provenance['source_before'][name])
    for name in R6_FILES:
        replacement = (r8/'source'/name) if name=='kernel/sched/sched.h' else (r6/'source'/name)
        p=snapshot/name
        # Security: do not overwrite a symlink or add a header outside scope.
        require(p.is_file() and not p.is_symlink(),'UNSAFE_PATCH_TARGET:'+name)
        p.write_bytes(check_file(replacement))
    for name in R6_FILES:
        expected=R8_SCHED_HASH if name=='kernel/sched/sched.h' else provenance['source_after_r6'][name]
        check_file(snapshot/name,expected)
    report={'status':'R9_SOURCE_SNAPSHOT_STAGED','provenance':provenance,
            'replacements':list(R6_FILES),'objects_planned':list(OBJECTS),
            'snapshot':str(snapshot),'flash_allowed':False,'vendor_abi_proven':False,
            'kernel_image_built':False,'kernel_objects_compiled':False,'brene_changed':False}
    output.mkdir(parents=True)
    write_json(output/'R9_STAGE_REPORT.json',report)
    print('R9_SOURCE_STAGE=PASS; P3_P10_R6_R8_PINNED=YES; SOURCE_ORIGINAL=UNCHANGED; NO_BUILD_YET')
    return report

def write_json(p, obj):
    temp=p.with_suffix(p.suffix+'.part')
    temp.write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
    os.replace(temp,p)

def run_cmd(args, log, timeout_seconds, env=None, cwd=None):
    log.parent.mkdir(parents=True, exist_ok=True)
    start=time.monotonic()
    rc=None; timedout=False
    with log.open('w',encoding='utf-8') as f:
        f.write('# argv: '+json.dumps(args)+'\n')
        f.write('# timeout_seconds: '+str(timeout_seconds)+'\n')
        f.flush()
        proc=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,env=env,cwd=cwd,
                              start_new_session=True)
        try: rc=proc.wait(timeout=timeout_seconds)
        except subprocess.TimeoutExpired:
            timedout=True
            try:os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError: pass
            try:proc.wait(timeout=4)
            except subprocess.TimeoutExpired:
                try:os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                proc.wait()
            rc=124
        f.write(f'\n# R9_CHILD_RESULT: rc={rc} timeout={timedout}\n')
    duration=round(time.monotonic()-start,2)
    return {'exit_code':rc,'timed_out':timedout,'duration_s':duration,
            'log':str(log),'log_sha256':sha(log.read_bytes())}

def versions(toolchain, output):
    bin_dir=toolchain/'bin'
    require(bin_dir.is_dir() and not bin_dir.is_symlink(),'TOOLCHAIN_DIRECTORY_REQUIRED')
    names=('clang','ld.lld','llvm-ar','llvm-nm','llvm-objcopy','llvm-objdump','llvm-strip')
    ret={}
    for n in names:
        p=bin_dir/n
        require(p.is_file() and os.access(p,os.X_OK),'TOOLCHAIN_BINARY_MISSING:'+n)
        v=subprocess.run([str(p),'--version'],capture_output=True,text=True,timeout=15)
        require(v.returncode==0,'TOOLCHAIN_VERSION_FAILED:'+n)
        ret[n]={'version':v.stdout.splitlines()[0] if v.stdout else v.stderr.splitlines()[0],
                'binary_sha256':sha(p.read_bytes())}
    require('r416183b' in ret['clang']['version'],'ANDROID_CLANG_REVISION_DRIFT')
    require('12.0.5' in ret['clang']['version'],'ANDROID_CLANG_VERSION_DRIFT')
    (output/'R9_TOOLCHAIN_VERSIONS.txt').write_text('\n'.join(n+': '+d['version']+' sha256='+d['binary_sha256'] for n,d in ret.items())+'\n')
    return ret

def make_argv(snapshot, objout, toolchain, target, jobs=2):
    tool=toolchain/'bin'
    return ['make','--no-print-directory','-C',str(snapshot),'O='+str(objout),
        'ARCH=arm64','LLVM=1','LLVM_IAS=1','HOSTCC=gcc','HOSTCXX=g++',
        'CC='+str(tool/'clang'),'LD='+str(tool/'ld.lld'),
        'AR='+str(tool/'llvm-ar'),'NM='+str(tool/'llvm-nm'),
        'OBJCOPY='+str(tool/'llvm-objcopy'),'OBJDUMP='+str(tool/'llvm-objdump'),
        'STRIP='+str(tool/'llvm-strip'), '-j'+str(jobs),target]

def compile_objects(snapshot, objout, reportdir, stock, toolchain, limit=300, jobs=2):
    stage_report=read_report(reportdir/'R9_STAGE_REPORT.json')
    require(stage_report['status']=='R9_SOURCE_SNAPSHOT_STAGED','R9_NOT_STAGED')
    require(Path(stage_report['snapshot']).resolve()==snapshot.resolve(),'SNAPSHOT_PATH_MISMATCH')
    require(not objout.exists() and not objout.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    path_outside(objout,(snapshot,stock.parent,toolchain,reportdir))
    require(not snapshot.is_symlink() and snapshot.is_dir(),'SNAPSHOT_DIRECTORY_REQUIRED')
    check_file(stock,OEM_CONFIG_HASH)
    check_file(snapshot/'kernel/sched/sched.h',R8_SCHED_HASH)
    check_file(snapshot/'kernel/sched/walt/walt.c',P10_WALT_C_HASH)
    require(shutil.which('make') is not None,'MAKE_REQUIRED')
    require(shutil.which('gcc') is not None,'HOST_GCC_REQUIRED')
    objout.mkdir(parents=True)
    logs=reportdir/'compiler_logs';logs.mkdir(parents=True,exist_ok=True)
    report={'status':'R9_STARTED','snapshot_verified':True,'kernelversion_expected':'5.4.274',
        'toolchain_verified':False,'requested_objects':list(OBJECTS),'kernel_image_built':False,
        'module_symvers_valid':False,'vendor_abi_proven':False,'flash_allowed':False,
        'brene_changed':False,'source_original_unchanged':True,'object_make_attempted':False,
        'objects':{},'steps':{},'config_diff':{},'config_walt_y':False}
    write_json(reportdir/'R9_COMPILER_RESULT.json',report)
    # Always record the actual toolchain used, including SHA256 of binaries.
    try:
        report['toolchain']=versions(toolchain,reportdir)
        report['toolchain_verified']=True
    except AuditError as e:
        report['status']='R9_TOOLCHAIN_UNAVAILABLE';report['blocker']=str(e)
        write_json(reportdir/'R9_COMPILER_RESULT.json',report)
        print('R9_TOOLCHAIN_UNAVAILABLE: '+str(e));return report
    obj_env=os.environ.copy()
    obj_env['PATH']=str(toolchain/'bin')+os.pathsep+obj_env.get('PATH','')
    # Genuine kernelversion is evaluated from this exact source, not a preset string.
    version=run_cmd(make_argv(snapshot,objout,toolchain,'kernelversion',jobs),logs/'00_kernelversion.log',90,env=obj_env)
    report['steps']['kernelversion']=version
    if version['exit_code']!=0:
        report['status']='R9_KERNELVERSION_COMMAND_FAILED';write_json(reportdir/'R9_COMPILER_RESULT.json',report);return report
    vlog=(logs/'00_kernelversion.log').read_text(errors='replace')
    require(re.search(r'(?m)^5\.4\.274\s*$',vlog) is not None,'SOURCE_KERNEL_VERSION_NOT_5_4_274')
    (objout/'.config').write_bytes(check_file(stock,OEM_CONFIG_HASH))
    cfg=run_cmd(make_argv(snapshot,objout,toolchain,'olddefconfig',jobs),logs/'01_olddefconfig.log',limit,env=obj_env)
    report['steps']['olddefconfig']=cfg
    if cfg['exit_code']!=0:
        report['status']='R9_KCONFIG_FAILED';write_json(reportdir/'R9_COMPILER_RESULT.json',report)
        print('R9_DIAGNOSIS=KCONFIG_FAILED; compiler object NOT attempted');return report
    config=check_file(objout/'.config').decode('utf-8',errors='replace')
    expected=config_values(check_file(stock,OEM_CONFIG_HASH).decode())
    actual=config_values(config)
    report['config_sha256']=sha(config.encode())
    report['config_diff']={k:{'oem':expected.get(k,'ABSENT'),'actual':actual.get(k,'ABSENT')}
                           for k in FEATURES if actual.get(k,'ABSENT')!=expected.get(k,'ABSENT')}
    report['config_walt_y']=actual.get('CONFIG_SCHED_WALT')=='y'
    (reportdir/'R9_CONFIG_DIFF.json').write_text(json.dumps(report['config_diff'],indent=2,sort_keys=True)+'\n')
    # Capture generated config without claiming OEM parity.
    shutil.copy2(objout/'.config',reportdir/'R9_EFFECTIVE_CONFIG.config')
    if not report['config_walt_y']:
        report['status']='R9_WALT_NOT_ENABLED_BY_KCONFIG';write_json(reportdir/'R9_COMPILER_RESULT.json',report)
        print('R9_WALT_DISABLED_AFTER_OLDDEFCONFIG; COMPILE_NOT_ATTEMPTED');return report
    prep=run_cmd(make_argv(snapshot,objout,toolchain,'prepare',jobs),logs/'02_prepare.log',limit,env=obj_env)
    report['steps']['prepare']=prep
    if prep['exit_code']!=0:
        report['status']='R9_PREPARE_FAILED';write_json(reportdir/'R9_COMPILER_RESULT.json',report)
        print('R9_PREPARE_FAILED; OBJECT_COMPILE_NOT_ATTEMPTED');return report
    # Actual compiler object requests. A failed make IS A REAL DIAGNOSTIC, not a green object.
    for i,target in enumerate(OBJECTS,1):
        log=logs/f'{i+2:02d}_{target.replace("/","_")}.log'
        entry=run_cmd(make_argv(snapshot,objout,toolchain,target,jobs),log,limit,env=obj_env)
        obj=objout/target
        size=obj.stat().st_size if obj.is_file() and not obj.is_symlink() else 0
        entry['object_file_present']=size>0
        entry['object_bytes']=size
        entry['compiled']=entry['exit_code']==0 and size>0
        if entry['compiled']:
            entry['object_sha256']=sha(obj.read_bytes())
        report['objects'][target]=entry
        report['object_make_attempted']=True
        write_json(reportdir/'R9_COMPILER_RESULT.json',report)
    success=all(v['compiled'] for v in report['objects'].values())
    report['status']= ('R9_ALL_THREE_OBJECTS_COMPILED' if success else 'R9_COMPILER_ERRORS_RECORDED')
    report['all_objects_compiled']=success
    # No complete kernel, no link/modpost and therefore NO vendor ABI proof.
    write_json(reportdir/'R9_COMPILER_RESULT.json',report)
    print('R9_REAL_WALT_ON_KBUILD_ATTEMPTED=YES; OBJECTS='+str(len(report['objects']))+
          '; SUCCEEDED='+str(sum(v['compiled'] for v in report['objects'].values()))+
          '; OEM_CONFIG_DIFFERENCES='+str(len(report['config_diff']))+'; IMAGE=NO; ABI=UNPROVEN; FLASH=NO')
    return report

def main():
    parser=argparse.ArgumentParser()
    sub=parser.add_subparsers(dest='action',required=True)
    s=sub.add_parser('stage')
    for n in ('source','r6','r8','p3','p11','stock','snapshot','reportdir'):
        s.add_argument('--'+n,required=True,type=Path)
    c=sub.add_parser('compile')
    for n in ('snapshot','objout','reportdir','stock','toolchain'):
        c.add_argument('--'+n,required=True,type=Path)
    c.add_argument('--timeout',type=int,default=300)
    args=parser.parse_args()
    try:
        if args.action=='stage':
            stage(args.source,args.r6,args.r8,args.p3,args.p11,args.stock,args.snapshot,args.reportdir)
        else:
            require(30<=args.timeout<=450,'COMPILE_TIMEOUT_INVALID')
            compile_objects(args.snapshot,args.objout,args.reportdir,args.stock,args.toolchain,args.timeout)
    except (AuditError,OSError,KeyError,ValueError,subprocess.SubprocessError) as e:
        print('R9_GATE_INVALID:'+str(e),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':sys.exit(main())
