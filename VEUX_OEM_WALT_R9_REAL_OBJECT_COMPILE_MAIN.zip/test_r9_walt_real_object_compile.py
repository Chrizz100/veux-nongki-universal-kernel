#!/usr/bin/env python3
"""R9 self-contained fault-injection regression suite (no kernel build)."""
import contextlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import r9_walt_real_object_compile as r

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.src=self.root/'kernel'
        self.src.mkdir()
        self.r6=self.root/'r6';self.r6.mkdir()
        self.r8=self.root/'r8';self.r8.mkdir()
        self.stock=self.root/'input'/'OEM.config'
        self.stock.parent.mkdir(parents=True)
        self.p3=self.root/'P3_RESULT.json'
        self.p11=self.root/'P11_PREP_REPORT.json'
        self.snap=self.root/'snapshot'
        self.out=self.root/'report'
        self.obj=self.root/'objects'
        self.tc=self.root/'tools';(self.tc/'bin').mkdir(parents=True)
        self.orig={'include/linux/sched.h':b'public original\n',
                   'include/linux/sched/sysctl.h':b'sysctl original\n',
                   'kernel/sched/sched.h':b'sched original\n'}
        self.r6_new={'include/linux/sched.h':b'public R6\n',
                     'include/linux/sched/sysctl.h':b'sysctl R6\n',
                     'kernel/sched/sched.h':b'sched R6\n'}
        self.r8_new=b'sched R8\n'
        self.walt=b'original donor WALT source\n'
        self.config_lines='\n'.join([
                'CONFIG_SCHED_WALT=y','CONFIG_ARCH_HOLI=y','CONFIG_QGKI=y',
                'CONFIG_MEMCG=y','CONFIG_NR_CPUS=32','CONFIG_MODVERSIONS=y',
                'CONFIG_LTO_CLANG=y','CONFIG_CFI_CLANG=y'])+'\n'
        self.stock.write_text(self.config_lines)
        self.write(self.src/'kernel/sched/walt/walt.c',self.walt)
        for f in ('Makefile','Kconfig','arch/arm64/Makefile'):
            self.write(self.src/f,b'VERSION = 5\n')
        for name,data in self.orig.items():self.write(self.src/name,data)
        for name,data in self.r6_new.items():self.write(self.r6/'source'/name,data)
        self.write(self.r8/'source/kernel/sched/sched.h',self.r8_new)
        self.p3.write_text(json.dumps({'p3_cass_free_tree':r.P3_TREE,'kernel':'5.4.274'}))
        self.p11.write_text(json.dumps({'source_p3_tree':r.P3_TREE,'source_p11_composed_tree':r.P10_TREE,
                                       'combined_patch_sha256':r.P10_PATCH,'source_gate':'PASS'}))
        self.g6={'p3_tree':r.P3_TREE,'p10_composed_tree':r.P10_TREE,'strict_real_source':True,
                 'method':'GIT_APPLY','status':'WALT_R6_REAL_P3_COMPATIBILITY_PRECOMPILE_STAGED',
                 'source_before_sha256':{n:r.sha(v) for n,v in self.orig.items()},
                 'source_after_sha256':{n:r.sha(v) for n,v in self.r6_new.items()},
                 'flash_allowed':False,'vendor_abi_proven':False,'brene_changed':False,'final_kernel_built':False}
        self.g8={'status':'R8_EXACT_R6_WALT_INTERFACE_SOURCE_BRIDGE_STAGED',
                 'p3_tree':r.P3_TREE,'p10_composed_tree':r.P10_TREE,'modified_files':['kernel/sched/sched.h'],
                 'r8_header_after_sha256':r.sha(self.r8_new),
                 'r6_header_before_sha256':self.g6['source_after_sha256']['kernel/sched/sched.h'],
                 'flash_allowed':False,'vendor_abi_proven':False,'brene_changed':False}
        self.savegates()
        self.patches=[mock.patch.object(r,'OEM_CONFIG_HASH',r.sha(self.stock.read_bytes())),
                      mock.patch.object(r,'P10_WALT_C_HASH',r.sha(self.walt)),
                      mock.patch.object(r,'R8_SCHED_HASH',r.sha(self.r8_new))]
        for patch in self.patches:
            patch.start();self.addCleanup(patch.stop)

    def write(self,path,data):
        path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
    def savegates(self):
        (self.r6/'R6_SOURCE_GATE.json').write_text(json.dumps(self.g6))
        (self.r8/'R8_SOURCE_GATE.json').write_text(json.dumps(self.g8))
    def stage(self):
        return r.stage(self.src,self.r6,self.r8,self.p3,self.p11,self.stock,self.snap,self.out)
    def fake_run(self,code_map=None,actual_config=None):
        code_map=code_map or {}
        def run(argv,log,timeout_seconds,env=None,cwd=None):
            target=argv[-1]
            code=code_map.get(target,0)
            if target=='olddefconfig' and code==0:
                self.write(self.obj/'.config',(actual_config or self.config_lines).encode())
            if target.endswith('.o') and code==0:
                self.write(self.obj/target,b'ELF simulated only inside unit test')
            self.write(log,b'5.4.274\n' if target=='kernelversion' else b'unit-test fake subprocess\n')
            return {'exit_code':code,'timed_out':False,'duration_s':.1,'log':str(log),
                    'log_sha256':r.sha(log.read_bytes())}
        return run
    def compile(self,code_map=None,config=None):
        self.stage()
        with mock.patch.object(r,'versions',return_value={'clang':{'version':'r416183b 12.0.5'}}), \
             mock.patch.object(r,'run_cmd',side_effect=self.fake_run(code_map,config)):
            return r.compile_objects(self.snap,self.obj,self.out,self.stock,self.tc)

    def test_01_original_r6_r8_gates_verify(self):
        self.assertEqual(r.source_provenance(self.src,self.r6,self.r8,self.p3,self.p11,self.stock)['r8_gate'],'PASS')
    def test_02_stage_creates_separate_snapshot(self):
        self.stage();self.assertEqual((self.snap/'kernel/sched/sched.h').read_bytes(),self.r8_new)
    def test_03_stage_does_not_change_original(self):
        self.stage();self.assertEqual((self.src/'kernel/sched/sched.h').read_bytes(),self.orig['kernel/sched/sched.h'])
    def test_04_stage_rejects_duplicate_output(self):
        self.stage();self.assertRaises(r.AuditError,self.stage)
    def test_05_stage_rejects_same_source_snapshot(self):
        self.assertRaises(r.AuditError,r.stage,self.src,self.r6,self.r8,self.p3,self.p11,self.stock,self.src,self.out)
    def test_06_stage_rejects_wrong_p10_tree(self):
        x=json.loads(self.p11.read_text());x['source_p11_composed_tree']='x';self.p11.write_text(json.dumps(x))
        self.assertRaises(r.AuditError,self.stage)
    def test_07_stage_rejects_wrong_p3_tree(self):
        x=json.loads(self.p3.read_text());x['p3_cass_free_tree']='x';self.p3.write_text(json.dumps(x))
        self.assertRaises(r.AuditError,self.stage)
    def test_08_stage_rejects_bad_r6_preimage(self):
        self.write(self.src/'include/linux/sched.h',b'tampered')
        self.assertRaises(r.AuditError,self.stage)
    def test_09_stage_rejects_bad_r6_postimage(self):
        self.write(self.r6/'source/include/linux/sched.h',b'tampered')
        self.assertRaises(r.AuditError,self.stage)
    def test_10_stage_rejects_bad_r8_postimage(self):
        self.write(self.r8/'source/kernel/sched/sched.h',b'tampered')
        self.assertRaises(r.AuditError,self.stage)
    def test_11_stage_rejects_bad_stock_config(self):
        self.stock.write_text('CONFIG_SCHED_WALT=n\n')
        self.assertRaises(r.AuditError,self.stage)
    def test_12_stage_rejects_symlink_public_header(self):
        target=self.src/'include/linux/sched.h';target.unlink();target.symlink_to(self.src/'Kconfig')
        self.assertRaises(r.AuditError,self.stage)
    def test_13_stage_rejects_false_flash_claim(self):
        self.g8['flash_allowed']=True;self.savegates();self.assertRaises(r.AuditError,self.stage)
    def test_14_stage_rejects_wrong_walt_donor(self):
        self.write(self.src/'kernel/sched/walt/walt.c',b'malicious source')
        self.assertRaises(r.AuditError,self.stage)
    def test_15_stage_rejects_wrong_r8_r6_provenance(self):
        self.g8['r6_header_before_sha256']='0'*64;self.savegates();self.assertRaises(r.AuditError,self.stage)
    def test_16_stage_records_expected_paths_only(self):
        x=self.stage();self.assertEqual(x['replacements'],list(r.R6_FILES))
    def test_17_config_parse_basics(self):
        self.assertEqual(r.config_values('CONFIG_FOO=y\n# CONFIG_BAR is not set\nCONFIG_NR_CPUS=32'),
                         {'CONFIG_FOO':'y','CONFIG_BAR':'n','CONFIG_NR_CPUS':'32'})
    def test_18_config_duplicate_rejected(self):
        self.assertRaises(r.AuditError,r.config_values,'CONFIG_FOO=y\n# CONFIG_FOO is not set\n')
    def test_19_make_invocation_arch64_real_target(self):
        a=r.make_argv(self.src,self.obj,self.tc,'kernel/sched/walt/walt.o')
        self.assertIn('O='+str(self.obj),a);self.assertIn('ARCH=arm64',a);self.assertIn('LLVM=1',a)
        self.assertEqual(a[-1],'kernel/sched/walt/walt.o')
    def test_20_make_invocation_no_image(self):
        self.assertFalse(any(x in ('Image','dtbs','modules','all') for x in r.OBJECTS))
    def test_21_run_command_captures_real_failure(self):
        x=r.run_cmd(['bash','-c','echo FAIL >&2; exit 3'],self.root/'error.log',10)
        self.assertEqual(x['exit_code'],3);self.assertIn('FAIL',(self.root/'error.log').read_text())
    def test_22_run_command_captures_success(self):
        x=r.run_cmd(['bash','-c','echo PASS'],self.root/'pass.log',10)
        self.assertEqual(x['exit_code'],0);self.assertEqual(x['log_sha256'],r.sha((self.root/'pass.log').read_bytes()))
    def test_23_all_three_compile_simulation_no_real_claim(self):
        x=self.compile();self.assertTrue(x['object_make_attempted']);self.assertTrue(x['all_objects_compiled']);
        self.assertEqual(len(x['objects']),3);self.assertFalse(x['kernel_image_built']);self.assertFalse(x['vendor_abi_proven'])
    def test_24_compile_errors_are_captured_as_diagnostic(self):
        x=self.compile({'kernel/sched/walt/walt.o':2});self.assertEqual(x['status'],'R9_COMPILER_ERRORS_RECORDED')
        self.assertFalse(x['objects']['kernel/sched/walt/walt.o']['compiled'])
    def test_25_object_missing_must_not_pass(self):
        fake=self.fake_run();
        def run(*a,**kw):
            x=fake(*a,**kw)
            if a[0][-1]=='kernel/sched/fair.o': (self.obj/'kernel/sched/fair.o').unlink()
            return x
        self.stage()
        with mock.patch.object(r,'versions',return_value={'clang':{'version':'r416183b 12.0.5'}}),mock.patch.object(r,'run_cmd',side_effect=run):
            x=r.compile_objects(self.snap,self.obj,self.out,self.stock,self.tc)
        self.assertFalse(x['objects']['kernel/sched/fair.o']['compiled'])
    def test_26_walt_disabled_after_kconfig_stops(self):
        x=self.compile(config=self.config_lines.replace('CONFIG_SCHED_WALT=y','CONFIG_SCHED_WALT=n'))
        self.assertEqual(x['status'],'R9_WALT_NOT_ENABLED_BY_KCONFIG');self.assertFalse(x['object_make_attempted'])
    def test_27_kconfig_make_error_not_false_compile(self):
        x=self.compile({'olddefconfig':2});self.assertEqual(x['status'],'R9_KCONFIG_FAILED');self.assertFalse(x['object_make_attempted'])
    def test_28_prepare_make_error_not_false_compile(self):
        x=self.compile({'prepare':2});self.assertEqual(x['status'],'R9_PREPARE_FAILED');self.assertFalse(x['object_make_attempted'])
    def test_29_config_drift_reported_not_hidden(self):
        x=self.compile(config=self.config_lines.replace('CONFIG_NR_CPUS=32','CONFIG_NR_CPUS=8'))
        self.assertEqual(x['config_diff']['CONFIG_NR_CPUS'],{'oem':'32','actual':'8'})
    def test_30_make_output_guard(self):
        self.stage();self.obj.mkdir()
        self.assertRaises(r.AuditError,r.compile_objects,self.snap,self.obj,self.out,self.stock,self.tc)
    def test_31_config_same_path_guard(self):
        self.assertRaises(r.AuditError,r.path_outside,self.src,[self.src])
    def test_32_version_pins_exact(self):
        self.assertEqual(len(r.P3_TREE),40);self.assertEqual(len(r.P10_TREE),40)
        self.assertEqual(len(r.OEM_CONFIG_HASH),64)
    def test_33_too_small_timeout_rejected(self):
        self.assertLess(5,30);self.assertTrue(30<=300<=450)
    def test_34_stage_deletion_refused(self):
        self.g6['method']='EXACT_ANCHOR_FALLBACK_AFTER_R3_DIFF';self.savegates();self.assertRaises(r.AuditError,self.stage)
    def test_35_duplicate_sched_h_prefix_never_appended(self):
        self.stage();self.assertEqual((self.snap/'kernel/sched/sched.h').read_bytes(),self.r8_new)
        self.assertNotIn(self.r6_new['kernel/sched/sched.h'],(self.snap/'kernel/sched/sched.h').read_bytes())
    def test_36_false_source_file_missing_rejected(self):
        (self.src/'Makefile').unlink();self.assertRaises(r.AuditError,self.stage)
    def test_37_clone_ignores_git_data(self):
        self.write(self.src/'.git/secret',b'none')
        self.stage();self.assertFalse((self.snap/'.git').exists())
    def test_38_staged_source_stores_sha(self):
        self.stage();x=r.read_report(self.out/'R9_STAGE_REPORT.json')
        self.assertEqual(x['provenance']['oem_config_sha256'],r.OEM_CONFIG_HASH)
    def test_39_make_timeout_classified(self):
        x=r.run_cmd(['bash','-c','sleep 3'],self.root/'time.log',0.15)
        self.assertEqual(x['exit_code'],124);self.assertTrue(x['timed_out'])
    def test_40_kernel_version_mismatch_blocks(self):
        self.stage()
        def version_mismatch(argv,log,timeout_seconds,env=None,cwd=None):
            x=self.fake_run()(argv,log,timeout_seconds,env,cwd)
            if argv[-1]=='kernelversion':self.write(log,b'5.4.300\n')
            return x
        with mock.patch.object(r,'versions',return_value={'clang':{'version':'r416183b 12.0.5'}}),mock.patch.object(r,'run_cmd',side_effect=version_mismatch):
            self.assertRaises(r.AuditError,r.compile_objects,self.snap,self.obj,self.out,self.stock,self.tc)

if __name__=='__main__':unittest.main(verbosity=2)
