#!/usr/bin/env python3
"""R17-A source-only regression/negative contract tests. No real kernel build."""
import hashlib
import importlib.util
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r17a',ROOT/'r17a_scheduler_source.py')
port=importlib.util.module_from_spec(spec);spec.loader.exec_module(port)

CORE='''/* kernel/sched/core.c source-model – not original full kernel */
#ifdef CONFIG_HOTPLUG_CPU
static void calc_load_migrate(struct rq *rq)
{
	long delta = calc_load_fold_active(rq, 1);
	if (delta)
		atomic_long_add(delta, &calc_load_tasks);
}
static void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf)
{
  /* real migration still pending R17B */
}
#endif
'''
SCHED='''/* kernel/sched/sched.h source-model – not original full kernel */
struct rq;
struct sched_domain;
struct sched_avg_stats {
 int nr;
 int nr_misfit;
 int nr_max;
 int nr_scaled;
};
extern void sched_get_nr_running_avg(struct sched_avg_stats *stats);
'''
TOPO='''/* kernel/sched/topology.c source-model – not original full kernel */
static void init_sched_groups_capacity(int cpu, struct sched_domain *sd)
{
	struct sched_group *sg = sd->groups;

	WARN_ON(!sg);
	do {
		int cpu, max_cpu = -1;
		sg->group_weight = cpumask_weight(sched_group_span(sg));
		if (!(sd->flags & SD_ASYM_PACKING))
			goto next;
		for_each_cpu(cpu, sched_group_span(sg)) {
			if (max_cpu < 0)
				max_cpu = cpu;
			else if (sched_asym_prefer(cpu, max_cpu))
				max_cpu = cpu;
		}
		sg->asym_prefer_cpu = max_cpu;
next:
		sg = sg->next;
	} while (sg != sd->groups);
	if (cpu != group_balance_cpu(sg))
		return;
	update_group_capacity(sd, cpu);
}
'''

def sha(s): return hashlib.sha256(s.encode()).hexdigest()

def fake_gates():
    b={'kernel/sched/core.c':sha(CORE),'kernel/sched/sched.h':sha(SCHED)}
    g={'status':port.R16_SOURCE_STATUS,'source_r15_verified':True,
       'after_sha256':b,'modified_files':[
       'include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c',
       'include/linux/sysctl.h','kernel/sysctl.c']}
    cmp={'status':'R16_COMPILER_ERRORS_OR_PROVIDER_SYMBOL_GAPS_RECORDED',
         'real_arm64_make_attempted':True,'source_r16_verified':True,
         'previous_eight_compiled':8,'object_success_count':10,
         'source_postimages':dict(b),'objects':{
             **{p:{'compiled':True} for p in port.BASELINE},
             'kernel/sched/walt/core_ctl.o':{'compiled':True},
             'kernel/cpu.o':{'compiled':True},
             'kernel/sched/walt/qc_vas.o':{'compiled':False}}}
    for data in (g,cmp):
       for key in port.FORBIDDEN:data[key]=False
    return g,cmp

class Unit(unittest.TestCase):
    def test_01_scoped_files(self): self.assertEqual(set(port.FILES),set(port.TRANSFORMS))
    def test_02_original_oem_reference_fixed(self): self.assertIn('61397e5240',port.DONOR)
    def test_03_p10_tree_immutable(self): self.assertEqual(len(port.P10_TREE),40)
    def test_04_core_function_body_retained(self):
        a=port.patch_core(CORE);self.assertIn('calc_load_fold_active(rq, 1)',a)
    def test_05_core_global_on(self): self.assertIn('#ifdef CONFIG_SCHED_WALT\nvoid\n#else\nstatic void\n#endif',port.patch_core(CORE))
    def test_06_core_no_dummy(self): self.assertIn('atomic_long_add(delta, &calc_load_tasks)',port.patch_core(CORE))
    def test_07_core_wrong_anchor(self):
        with self.assertRaises(port.GateError):port.patch_core(CORE.replace('static void calc_load_migrate','void calc_load_migrate'))
    def test_08_core_double_declaration(self):
        with self.assertRaises(port.GateError):port.patch_core(CORE+CORE)
    def test_09_core_empty_body_rejected(self):
        with self.assertRaises(port.GateError):port.patch_core(CORE.replace('calc_load_fold_active(rq, 1)','calc_load_fold_active(rq, 2)'))
    def test_10_core_reapply_rejected(self):
        with self.assertRaises(port.GateError):port.patch_core(port.patch_core(CORE))
    def test_11_topology_macro_separate(self):
        a=port.patch_topology(TOPO);self.assertIn('#ifdef CONFIG_SCHED_WALT\nvoid\n#else\nstatic void\n#endif',a)
    def test_12_topology_real_walt_isolation_mask(self):self.assertIn('cpumask_andnot(&avail_mask, sched_group_span(sg),',port.patch_topology(TOPO))
    def test_13_topology_nonwalt_original(self):self.assertIn('#else\n\t\tsg->group_weight = cpumask_weight(sched_group_span(sg));\n#endif',port.patch_topology(TOPO))
    def test_14_topology_preserve_capacity_update(self):self.assertIn('update_group_capacity(sd, cpu);',port.patch_topology(TOPO))
    def test_15_topology_real_available_weight(self):self.assertIn('cpumask_weight(&avail_mask)',port.patch_topology(TOPO))
    def test_16_topology_no_dummy(self):self.assertNotIn('return 0;',port.patch_topology(TOPO))
    def test_17_topology_no_original(self):
        with self.assertRaises(port.GateError):port.patch_topology(TOPO.replace('static void init_sched_groups_capacity','void init_sched_groups_capacity'))
    def test_18_topology_missing_group_anchor(self):
        with self.assertRaises(port.GateError):port.patch_topology(TOPO.replace('struct sched_group *sg = sd->groups;','struct sched_group *sg = NULL;'))
    def test_19_topology_wrong_weight(self):
        with self.assertRaises(port.GateError):port.patch_topology(TOPO.replace('sg->group_weight = cpumask_weight(sched_group_span(sg));','sg->group_weight=0;'))
    def test_20_topology_reapply(self):
        with self.assertRaises(port.GateError):port.patch_topology(port.patch_topology(TOPO))
    def test_21_sched_true_extern(self):self.assertIn('extern void calc_load_migrate(struct rq *rq)',port.patch_sched(SCHED))
    def test_22_sched_topology_extern(self):self.assertIn('extern void init_sched_groups_capacity',port.patch_sched(SCHED))
    def test_23_sched_hotplug_conditional(self):self.assertIn('defined(CONFIG_SCHED_WALT) && defined(CONFIG_HOTPLUG_CPU)',port.patch_sched(SCHED))
    def test_24_sched_smp_conditional(self):self.assertIn('defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)',port.patch_sched(SCHED))
    def test_25_sched_guard_no_active_walt_stub(self):self.assertNotIn('static inline void calc_load_migrate',port.patch_sched(SCHED))
    def test_26_sched_no_anchor(self):
        with self.assertRaises(port.GateError):port.patch_sched(SCHED.replace('extern void sched_get_nr_running_avg','extern void something_else'))
    def test_27_sched_reapply(self):
        with self.assertRaises(port.GateError):port.patch_sched(port.patch_sched(SCHED))
    def test_28_fake_gate_accept(self):
        g,c=fake_gates();port.validate_input(g,c)
    def test_29_wrong_source_status(self):
        g,c=fake_gates();g['status']='UNPROVEN'
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_30_bad_compiler_status(self):
        g,c=fake_gates();c['status']='R16_IN_PROGRESS'
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_31_compiler_not_real(self):
        g,c=fake_gates();c['real_arm64_make_attempted']=False
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_32_false_compiler_count(self):
        g,c=fake_gates();c['object_success_count']=11
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_33_loss_of_eight(self):
        g,c=fake_gates();c['objects']['kernel/sched/fair.o']['compiled']=False;c['object_success_count']=9
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_34_unproven_source_sha(self):
        g,c=fake_gates();g['after_sha256']['kernel/sched/core.c']='b'*64
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_35_unsafe_abi_claim(self):
        g,c=fake_gates();c['vendor_abi_proven']=True
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_36_unsafe_brene_claim(self):
        g,c=fake_gates();g['brene_changed']=True
        with self.assertRaises(port.GateError):port.validate_input(g,c)
    def test_37_unpinned_p10(self):
        self.assertTrue(port.P10_TREE.startswith('04e3831b'))
    def test_38_exact_patch_only_three(self):
        import difflib
        patch=''.join(''.join(difflib.unified_diff(x.splitlines(keepends=True),port.TRANSFORMS[k](x).splitlines(keepends=True),fromfile='a/'+k,tofile='b/'+k)) for k,x in [('kernel/sched/core.c',CORE),('kernel/sched/sched.h',SCHED),('kernel/sched/topology.c',TOPO)])
        self.assertEqual(patch.count('--- a/'),3)
    def test_39_policy_off_matches_original_aggregate(self):
        # Smoke semantic check for actual CPU mask logic: 0b1111 & ~0b0100 =>3.
        self.assertEqual((0b1111 & ~0b0100).bit_count(),3)
    def test_40_policy_on_keeps_walt_separate(self):
        self.assertIn('#ifdef CONFIG_SCHED_WALT',port.patch_topology(TOPO))

class Staging(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        p=pathlib.Path(self.tmp.name)
        self.canonical=p/'canonical';self.snapshot=p/'snapshot';self.output=p/'out'
        for folder in (self.canonical,self.snapshot):
            for name,t in [('kernel/sched/topology.c',TOPO),('kernel/sched/core.c',CORE),('kernel/sched/sched.h',SCHED)]:
                path=folder/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(t)
        subprocess.run(['git','init','-q',str(self.canonical)],check=True)
        subprocess.run(['git','-C',str(self.canonical),'add','.'],check=True)
        tree=subprocess.check_output(['git','-C',str(self.canonical),'write-tree'],text=True).strip()
        self.oldtree=port.P10_TREE;port.P10_TREE=tree
        self.gate=self.snapshot/'gate.json';self.compiler=self.snapshot/'compiler.json'
        g,c=fake_gates()
        self.gate.write_text(json.dumps(g));self.compiler.write_text(json.dumps(c))
        subprocess.run(['git','init','-q',str(self.snapshot)],check=True)
    def tearDown(self):
        port.P10_TREE=self.oldtree
        self.tmp.cleanup()
    def stage(self):return port.prepare(self.snapshot,self.canonical,self.gate,self.compiler,self.output)
    def test_41_positive_apply_and_real_diff(self):
        r=self.stage();self.assertEqual(r['modified_files'],list(port.FILES))
        self.assertTrue((self.output/'R17A_ORIGINAL_SCHEDULER_PROVIDERS.patch').is_file())
    def test_42_source_gate_never_compile_success(self):
        r=self.stage();self.assertEqual(r['compiled_kernel_objects'],0)
    def test_43_after_hash_verification(self):
        r=self.stage()
        for k,h in r['after_sha256'].items():
            self.assertEqual(port.sha((self.snapshot/k).read_bytes()),h)
    def test_44_git_apply_reverse_gate(self):
        self.stage()
        x=subprocess.run(['git','-C',str(self.snapshot),'apply','--reverse','--check',str(self.output/'R17A_ORIGINAL_SCHEDULER_PROVIDERS.patch')],capture_output=True,text=True)
        self.assertEqual(x.returncode,0,x.stderr)
    def test_45_wrong_topology_rejected(self):
        f=self.snapshot/'kernel/sched/topology.c';f.write_text(f.read_text().replace('WARN_ON(!sg);','WARN_ON(sg);'))
        with self.assertRaises(port.GateError):self.stage()
    def test_46_wrong_core_rejected(self):
        f=self.snapshot/'kernel/sched/core.c';f.write_text(f.read_text()+'\n')
        with self.assertRaises(port.GateError):self.stage()
    def test_47_wrong_sched_rejected(self):
        f=self.snapshot/'kernel/sched/sched.h';f.write_text(f.read_text()+'\n')
        with self.assertRaises(port.GateError):self.stage()
    def test_48_no_double_stage(self):
        self.stage()
        with self.assertRaises(port.GateError):self.stage()
    def test_49_symlink_source_rejected(self):
        f=self.snapshot/'kernel/sched/topology.c';f.unlink();f.symlink_to(self.canonical/'kernel/sched/topology.c')
        with self.assertRaises(port.GateError):self.stage()
    def test_50_canonical_same_as_snapshot(self):
        with self.assertRaises(port.GateError):port.prepare(self.snapshot,self.snapshot,self.gate,self.compiler,self.output)
    def test_51_mismatched_tree_rejected(self):
        port.P10_TREE='0'*40
        with self.assertRaises(port.GateError):self.stage()
    def test_52_bad_compiler_provenance(self):
        c=json.loads(self.compiler.read_text());c['source_postimages']['kernel/sched/core.c']='f'*64
        self.compiler.write_text(json.dumps(c))
        with self.assertRaises(port.GateError):self.stage()
    def test_53_source_unchanged_on_validation_failure(self):
        f=self.snapshot/'kernel/sched/core.c';orig=f.read_bytes();f.write_bytes(orig+b'bad')
        with self.assertRaises(port.GateError):self.stage()
        self.assertEqual(f.read_bytes(),orig+b'bad')
    def test_54_positive_prepatch_contains_real_function(self):
        self.stage();self.assertIn('atomic_long_add', (self.snapshot/'kernel/sched/core.c').read_text())
    def test_55_xiaomi_group_weight_is_mask_based(self):
        self.stage();self.assertIn('cpumask_andnot(&avail_mask', (self.snapshot/'kernel/sched/topology.c').read_text())
    def test_56_no_compile_image_flash_claims(self):
        r=self.stage()
        for k in ('vmlinux_linked','kernel_image_built','flash_allowed','vendor_abi_proven','qc_vas_runtime_proven','brene_changed'):
            self.assertIs(r[k],False)
    def test_57_bad_source_flags_are_blocked(self):
        g=json.loads(self.gate.read_text());g['flash_allowed']=True;self.gate.write_text(json.dumps(g))
        with self.assertRaises(port.GateError):self.stage()
    def test_58_reapplying_patch_to_modified_sources_fails(self):
        self.stage();source=self.snapshot/'kernel/sched/core.c'
        self.assertTrue('static void calc_load_migrate' not in source.read_text())
        with self.assertRaises(port.GateError):port.patch_core(source.read_text())

if __name__=='__main__': unittest.main(verbosity=2)

class CCompilerModels(unittest.TestCase):
    def _cc(self,code,defines=(),run=False):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            p=root/'test.c';p.write_text(code)
            exe=root/'test.bin';obj=root/'test.o'
            cmd=['clang','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-variable','-Wno-unused-function','-O0',*(f'-D{val}' for val in defines)]
            if run:
                x=subprocess.run(cmd+[str(p),'-o',str(exe)],capture_output=True,text=True)
                self.assertEqual(x.returncode,0,x.stderr)
                t=subprocess.run([str(exe)],capture_output=True,text=True)
                self.assertEqual(t.returncode,0,t.stdout+t.stderr)
                return t.stdout.strip()
            x=subprocess.run(cmd+['-Wno-unused-function','-c',str(p),'-o',str(obj)],capture_output=True,text=True)
            self.assertEqual(x.returncode,0,x.stderr)
            n=subprocess.run(['nm',str(obj)],capture_output=True,text=True)
            self.assertEqual(n.returncode,0,n.stderr)
            return n.stdout
    def test_59_real_calc_load_visibility_walt_on_off(self):
        out=port.patch_core(CORE)
        fragment=out[out.index('#ifdef CONFIG_SCHED_WALT'):out.index('static void migrate_tasks')]
        head='''struct rq {int n;};
long calc_load_tasks;
long calc_load_fold_active(struct rq *rq, int n) {return rq->n-n;}
void atomic_long_add(long a, long *b) {*b+=a;}
'''
        code=head+fragment+'\nvoid test_call(void) {struct rq rq={3};calc_load_migrate(&rq);}\n'
        self.assertIn(' T calc_load_migrate',self._cc(code,defines=('CONFIG_SCHED_WALT=1',)))
        self.assertIn(' t calc_load_migrate',self._cc(code))
    def test_60_real_mask_semantics_walt_on_off(self):
        out=port.patch_topology(TOPO)
        beg=out.index('#ifdef CONFIG_SCHED_WALT\n\t\tcpumask_andnot(')
        end=out.index('\n\t\tif (!(sd->flags',beg)
        snippet=out[beg:end]
        code='''#include <stdio.h>
typedef unsigned long cpumask_t;
struct sched_group {unsigned int group_weight;};
static cpumask_t isolated_mask=4;
#define cpu_isolated_mask (&isolated_mask)
static void cpumask_andnot(cpumask_t *dst, const cpumask_t *a, const cpumask_t *b){*dst=*a&~*b;}
static unsigned int cpumask_weight(const cpumask_t *a){return __builtin_popcountl(*a);}
static const cpumask_t *sched_group_span(struct sched_group *sg) {(void)sg;static cpumask_t s=15;return &s;}
int main(void){struct sched_group g;struct sched_group *sg=&g;
#ifdef CONFIG_SCHED_WALT
cpumask_t avail_mask;
#endif
'''+snippet+'''\nprintf("%u\\n",sg->group_weight);return 0;}
'''
        self.assertEqual(self._cc(code,defines=('CONFIG_SCHED_WALT=1',),run=True),'3')
        self.assertEqual(self._cc(code,run=True),'4')

class RealPinnedHeader(unittest.TestCase):
    def test_61_actual_r14_r16_header_sha_and_r17a_patch(self):
        h=ROOT/'fixtures/R14_sched.h'
        self.assertEqual(port.sha(h.read_bytes()),'fe9743bb8d6f7e5be6b2a8df563924c59e6c7a84739181bb91d39047cd2673c6')
        src=h.read_text()
        module=ROOT/'fixtures/r16_walt_api_foundation.py'
        spec16=importlib.util.spec_from_file_location('pinned_r16',module)
        r16=importlib.util.module_from_spec(spec16);spec16.loader.exec_module(r16)
        self.assertEqual(r16.PINS['kernel/sched/sched.h'],port.sha(src))
        r16header=r16.patch_sched_h(src)
        self.assertEqual(port.sha(r16header),'5229986425daba7f4ed84d90f3a5229b3501f6b3b232f19990e24c6ad54bd162')
        x=port.patch_sched(r16header)
        self.assertIn('extern void init_sched_groups_capacity(',x)
        self.assertIn('extern void calc_load_migrate(',x)
    def test_62_r17a_does_not_redefine_r16_migration_guard(self):
        h=(ROOT/'fixtures/R14_sched.h').read_text()
        spec16=importlib.util.spec_from_file_location('pinned_r16',ROOT/'fixtures/r16_walt_api_foundation.py')
        r16=importlib.util.module_from_spec(spec16);spec16.loader.exec_module(r16)
        r16header=r16.patch_sched_h(h)
        r17a=port.patch_sched(r16header)
        self.assertEqual(r17a.count(r16.NEW_GUARD),r16header.count(r16.NEW_GUARD))
