#!/usr/bin/env python3
"""R17-A 12-object compiler honesty and dash-llvm-nm regression tests."""
import importlib.util
from pathlib import Path
import json
import hashlib
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('r17a_real',ROOT/'r17a_real_object_compile.py')
mod=importlib.util.module_from_spec(s);s.loader.exec_module(mod)

class RealAdapterTests(unittest.TestCase):
    def test_01_twelve_targets(self):self.assertEqual(len(mod.TARGETS),12)
    def test_02_every_target_distinct(self):self.assertEqual(len(set(mod.TARGETS)),12)
    def test_03_preserved_ten(self):self.assertEqual(len(mod.PRESERVED),10)
    def test_04_isolated_new_topology(self):self.assertIn('kernel/sched/topology.o',mod.TARGETS)
    def test_05_real_qc_vas_must_be_tested(self):self.assertIn('kernel/sched/walt/qc_vas.o',mod.TARGETS)
    def test_06_guards_abi_flash(self):
        self.assertTrue({'vendor_abi_proven','vmlinux_linked','flash_allowed','runtime_tested'}.issubset(mod.NO_SUCCESS))
    def test_07_nm_plain_defined(self):
        self.assertEqual(mod.parse_nm('0000000000000000 T migrate_swap\n'),[('T','migrate_swap')])
    def test_08_nm_llvm_lto_dashed(self):
        self.assertEqual(mod.parse_nm('---------------- T migrate_swap\n'),[('T','migrate_swap')])
    def test_09_nm_unsigned_symbol(self):
        self.assertEqual(mod.parse_nm('                 U __cpu_isolated_mask\n'),[('U','__cpu_isolated_mask')])
    def test_10_nm_reject_narrative(self):
        self.assertEqual(mod.parse_nm('FOUND: migrate_swap\nSTATUS: PASS\n'),[])
    def test_11_nm_reject_source_line(self):
        self.assertEqual(mod.parse_nm('kernel/cpu.o: error: something\n'),[])
    def test_12_nm_provider_original_real(self):
        for file,needed in [('kernel_cpu.o.nm.txt','__cpu_isolated_mask'),
                            ('kernel_sched_core.o.nm.txt','migrate_swap'),
                            ('kernel_sysctl.o.nm.txt','proc_douintvec_capacity')]:
            content=(ROOT/'fixtures'/file).read_text()
            self.assertTrue(any(name==needed and kind in 'BCDRSGT' for kind,name in mod.parse_nm(content)),file)
    def test_13_nm_real_original_not_false_zero(self):
        symbols=mod.parse_nm((ROOT/'fixtures/kernel_sched_core.o.nm.txt').read_text())
        self.assertGreater(len(symbols),10)
    def test_14_nm_migrating_new_symbol_NOT_PROVEN_R16(self):
        symbols=mod.parse_nm((ROOT/'fixtures/kernel_sched_core.o.nm.txt').read_text())
        self.assertFalse(any(s=='calc_load_migrate' and k=='T' for k,s in symbols))
    def test_15_result_10_11_genuine(self):
        x=json.loads((ROOT/'fixtures/R16_COMPILER_RESULT_GITHUB.json').read_text())
        self.assertEqual((x['object_success_count'],x['previous_eight_compiled']), (10,8))
        self.assertTrue(x['real_arm64_make_attempted'])
    def test_16_source_github_compiler_sha_chain(self):
        g=json.loads((ROOT/'fixtures/R16_SOURCE_GATE_GITHUB.json').read_text())
        r=json.loads((ROOT/'fixtures/R16_COMPILER_RESULT_GITHUB.json').read_text())
        self.assertEqual(g['after_sha256'],r['source_postimages'])
    def test_17_all_five_provider_symbols_specified(self):
        self.assertEqual(sum(map(len,mod.PROVIDERS.values())),5)
    def test_18_no_empty_provider_symbols(self):
        self.assertTrue(all(names for names in mod.PROVIDERS.values()))
    def test_19_previous_eight_present(self):
        self.assertTrue('kernel/sched/fair.o' in mod.PRESERVED)
    def test_20_fresh_delete_stale_objects(self):
        import inspect
        body=inspect.getsource(mod.fresh_compile)
        self.assertIn('stale.unlink()',body)
        self.assertIn("outcome.get('exit_code')==0",body)
    def test_21_fail_if_mismatched_r9_sha(self):
        self.assertEqual(mod.R9_DRIVER_SHA,'3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66')
    def test_22_source_py_compiles(self):
        import py_compile
        py_compile.compile(str(ROOT/'r17a_scheduler_source.py'),doraise=True)
    def test_23_original_r16_github_log_sha(self):
        p=ROOT/'fixtures/R16_COMPILER_RESULT_GITHUB.json'
        self.assertEqual(len(hashlib.sha256(p.read_bytes()).hexdigest()),64)
    def test_24_stateless_nongki_only(self):
        import inspect
        text=inspect.getsource(mod)
        self.assertNotIn('flash.sh',text)
        self.assertNotIn('fastboot',text)
    def test_25_real_provider_no_placeholder(self):
        import inspect
        self.assertIn("'calc_load_migrate'",inspect.getsource(mod))
        self.assertIn("'init_sched_groups_capacity'",inspect.getsource(mod))
    def test_26_preserve_r16_error_status(self):
        self.assertEqual(mod.R16_COMPILER_STATUS,'R16_COMPILER_ERRORS_OR_PROVIDER_SYMBOL_GAPS_RECORDED')
    def test_27_fresh_compile_requires_true_file(self):
        import inspect
        self.assertIn('MISSING_REAL_C_SOURCE',inspect.getsource(mod.fresh_compile))
    def test_28_nonzero_is_not_success(self):
        import inspect
        self.assertIn("outcome.get('timed_out') is False",inspect.getsource(mod.fresh_compile))
    def test_29_no_undocumented_kbuild_walt_off(self):
        self.assertIn('kernel/sched/walt/walt.o',mod.TARGETS)
    def test_30_symbol_stages_no_vmlinux_claim(self):
        import inspect
        self.assertIn("'not_vmlinux_link':True",inspect.getsource(mod.symbol_audit))
if __name__=='__main__':unittest.main()
