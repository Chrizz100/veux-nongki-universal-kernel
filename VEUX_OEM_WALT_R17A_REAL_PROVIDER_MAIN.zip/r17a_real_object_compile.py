#!/usr/bin/env python3
"""R17-A: authenticated WALT-on ARM64 Kbuild, 12 real object compiles.

Diagnostics only: compiler failures are retained and never counted as success.
Use llvm-nm for actual symbol providers, including LTO's dashed addresses.
No vmlinux, Image, DTB, ABI/CRC or flashable release is produced.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

R9_DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
R17A_SOURCE_STATUS='R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED'
R16_COMPILER_STATUS='R16_COMPILER_ERRORS_OR_PROVIDER_SYMBOL_GAPS_RECORDED'
TARGETS=(
'kernel/sched/walt/walt.o', 'kernel/sched/core.o','kernel/sched/fair.o',
'kernel/sysctl.o','kernel/sched/walt/boost.o','kernel/sched/walt/sched_avg.o',
'kernel/sched/walt/qc_vas.o','kernel/sched/walt/core_ctl.o',
'kernel/sched/walt/trace.o','kernel/sched/walt/cpu-boost.o','kernel/cpu.o',
'kernel/sched/topology.o')
PRESERVED=tuple(x for x in TARGETS if x not in ('kernel/sched/walt/qc_vas.o','kernel/sched/topology.o'))
PROVIDERS={
'kernel/cpu.o':('__cpu_isolated_mask',),
'kernel/sched/core.o':('migrate_swap','calc_load_migrate'),
'kernel/sysctl.o':('proc_douintvec_capacity',),
'kernel/sched/topology.o':('init_sched_groups_capacity',),
}
NO_SUCCESS=('vendor_abi_proven','kernel_image_built','vmlinux_linked','flash_allowed',
            'brene_changed','bakasusu_nomount_changed','runtime_tested')
class GateError(Exception):pass

def need(x,code):
    if not x:raise GateError(code)

def sha_file(f):return hashlib.sha256(Path(f).read_bytes()).hexdigest()
def read_json(f):return json.loads(Path(f).read_text())

def parse_nm(txt):
    """Supports LLVM LTO '---------------- T symbol' as well as hex-address forms."""
    result=[]
    for line in txt.splitlines():
        m=re.fullmatch(r'\s*(?:(?:[a-fA-F0-9]+|-+)\s+)?([A-Za-z])\s+([_A-Za-z][\w.$@]*)\s*',line)
        if m: result.append((m.group(1),m.group(2)))
    return result

def validate(q):
    for d in (q.snapshot,q.canonical,q.objout,q.toolchain,q.project):
        need(d.is_dir() and not d.is_symlink(),'UNSAFE_OR_MISSING_DIR:'+str(d))
    need(q.snapshot.resolve()!=q.canonical.resolve() and q.snapshot.resolve()!=q.project.resolve(), 'MUTATING_CANONICAL_SOURCE_FORBIDDEN')
    need(not q.output.exists() and not q.output.is_symlink(),'R17A_OUTPUT_ALREADY_EXISTS')
    for f in (q.source_gate,q.r16_gate,q.r16_result,q.config,q.driver):
        need(f.is_file() and not f.is_symlink(),'UNSAFE_OR_MISSING_INPUT:'+str(f))
    need(sha_file(q.driver)==R9_DRIVER_SHA,'R9_DRIVER_SHA_CHANGED')
    for name in ('clang','llvm-nm','ld.lld'):
        need((q.toolchain/'bin'/name).is_file(),'PINNED_TOOLCHAIN_MISSING:'+name)
    source=read_json(q.source_gate);r16gate=read_json(q.r16_gate); r16=read_json(q.r16_result)
    need(source.get('status')==R17A_SOURCE_STATUS and source.get('modified_files')==[
        'kernel/sched/core.c','kernel/sched/sched.h','kernel/sched/topology.c'], 'R17A_SOURCE_GATE_INVALID')
    need(r16gate.get('status')=='R16_OEM_BOUNDED_API_STAGE_NOT_KERNEL_COMPILED','R16_SOURCE_NOT_AUTHENTICATED')
    need(r16.get('status') in (R16_COMPILER_STATUS,'R16_ALL_ELEVEN_OBJECTS_AND_PROVIDER_SYMBOLS_COMPILED_NO_LINK'), 'R16_COMPILER_NOT_REAL')
    need(r16.get('real_arm64_make_attempted') is True and len(r16.get('objects',{}))==11,'R16_OBJECTS_NOT_REAL')
    need(r16.get('object_success_count')==10 and r16.get('previous_eight_compiled')==8,'R16_EXPECTED_10_OF_11_NOT_REPRODUCED')
    need(r16.get('source_postimages')==r16gate.get('after_sha256'),'R16_SOURCE_HASH_CHAIN_BROKEN')
    for data in (source,r16gate,r16):
        for k in ('vendor_abi_proven','kernel_image_built','vmlinux_linked','flash_allowed','brene_changed','bakasusu_nomount_changed'):
            need(data.get(k) is False,'UNSAFE_PROVENANCE:'+k)
    need(source.get('compiled_kernel_objects')==0 and source.get('requires_actual_arm64_compile') is True,
         'R17A_FALSE_SOURCE_BUILD_CLAIM')
    for path,digest in source.get('after_sha256',{}).items():
        p=q.snapshot/path
        need(p.is_file() and not p.is_symlink() and sha_file(p)==digest,'R17A_CHANGED_POSTIMAGE:'+path)
    for path in ('kernel/sched/core.c','kernel/sched/sched.h'):
        need(source.get('before_sha256',{}).get(path)==r16gate.get('after_sha256',{}).get(path),
             'R17A_BAD_R16_PREIMAGE:'+path)
    config=q.config.read_text()
    for key in ('CONFIG_SCHED_WALT=y','CONFIG_SMP=y','CONFIG_HOTPLUG_CPU=y','CONFIG_QGKI=y'):
        need(re.search(r'(?m)^'+re.escape(key)+r'$',config) is not None,'KCONFIG_REQUIRED:'+key)
    for k in ('CONFIG_NUMA_BALANCING=y','CONFIG_SPRD_ROTATION_TASK=y'):
        need(re.search(r'(?m)^'+re.escape(k)+r'$',config) is None,'BAD_MIGRATION_CONFIG:'+k)
    return source,r16

def fresh_compile(q,driver,target,logs,env):
    need(target in TARGETS,'TARGET_NOT_ALLOWED')
    obj=q.objout/target
    src=q.snapshot/(target[:-1]+'c')
    log=logs/(target.replace('/','_')+'.log')
    if not src.is_file() or src.is_symlink():
        log.write_text('MISSING_REAL_C_SOURCE:'+str(src)+'\n')
        return {'compiled':False,'exit_code':None,'object_bytes':0,'log':str(log),'log_sha256':sha_file(log),'failure':'SOURCE_MISSING'}
    need(obj.parent.is_dir() and not obj.parent.is_symlink(),'MISSING_BUILD_OUTPUT_DIR:'+target)
    for stale in (obj,obj.parent/('.'+obj.name+'.cmd')):
        need(not stale.is_symlink() and (not stale.exists() or stale.is_file()),'UNSAFE_STALE_OBJ:'+str(stale))
        if stale.exists():stale.unlink()
    outcome=driver.run_cmd(driver.make_argv(q.snapshot,q.objout,q.toolchain,target,2),log,300,env=env)
    present=obj.is_file() and not obj.is_symlink() and obj.stat().st_size>0
    ok=bool(outcome.get('exit_code')==0 and outcome.get('timed_out') is False and present)
    return {**outcome,'compiled':ok,'object_present':bool(present),'object_bytes':obj.stat().st_size if present else 0,
            **({'object_sha256':sha_file(obj)} if present else {})}

def symbol_audit(q,results):
    report={'tool_invoked':False,'providers':{},'symbols_verified':False,'not_vmlinux_link':True}
    nm=q.toolchain/'bin/llvm-nm';found=[]
    for target,symbols in PROVIDERS.items():
        record={'compiled':results[target]['compiled'],'symbols':{}}
        obj=q.objout/target
        if record['compiled']:
            p=subprocess.run([str(nm),'--defined-only',str(obj)],capture_output=True,text=True,timeout=30)
            report['tool_invoked']=True
            (q.output/(target.replace('/','_')+'.nm.txt')).write_text(p.stdout+p.stderr)
            parsed=parse_nm(p.stdout) if p.returncode==0 else []
            for symbol in symbols:
                m=[kind for kind,name in parsed if name==symbol and kind in 'BCDRSGT']
                record['symbols'][symbol]={'defined':bool(m),'kind':m[0] if m else None,'exit_code':p.returncode}
                found.append(bool(m))
        else:
            for symbol in symbols:record['symbols'][symbol]={'defined':False,'kind':None,'exit_code':None};found.append(False)
        report['providers'][target]=record
    report['symbols_verified']=len(found)==5 and all(found)
    qc=q.objout/'kernel/sched/walt/qc_vas.o'
    if results['kernel/sched/walt/qc_vas.o']['compiled'] and qc.is_file():
        p=subprocess.run([str(nm),'--undefined-only',str(qc)],capture_output=True,text=True,timeout=30)
        report['tool_invoked']=True
        report['qc_vas_undefined']=[s for k,s in parse_nm(p.stdout) if k=='U'] if p.returncode==0 else []
        report['qc_vas_nm_exit_code']=p.returncode
        (q.output/'R17A_QC_VAS_UNDEFINED.nm.txt').write_text(p.stdout+p.stderr)
    return report

def main_run(q):
    source,r16=validate(q)
    spec=importlib.util.spec_from_file_location('r17a_pinned_r9',q.driver)
    need(spec and spec.loader,'R9_DRIVER_IMPORT_MISSING')
    driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
    q.output.mkdir(parents=True); logs=q.output/'compiler_logs';logs.mkdir()
    result={'status':'R17A_IN_PROGRESS','objects':{},'real_arm64_make_attempted':False,
            'r16_input_object_count':r16['object_success_count'],'source_r17a_verified':True,
            'targets':list(TARGETS),'object_success_count':0,'kernel_version':'5.4.274',
            **{k:False for k in NO_SUCCESS},'r17a_postimages':source['after_sha256']}
    report=q.output/'R17A_COMPILER_RESULT.json';report.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    env=os.environ.copy();env['PATH']=str(q.toolchain/'bin')+os.pathsep+env.get('PATH','')
    for target in TARGETS:
        result['real_arm64_make_attempted']=True
        result['objects'][target]=fresh_compile(q,driver,target,logs,env)
        report.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    count=sum(v['compiled'] is True for v in result['objects'].values())
    preserved=sum(result['objects'][t]['compiled'] is True for t in PRESERVED)
    symbols=symbol_audit(q,result['objects'])
    success=bool(count==12 and preserved==10 and symbols['symbols_verified'])
    result.update({'status':'R17A_TWELVE_REAL_OBJECTS_AND_PROVIDERS_COMPILED_NO_LINK' if success
                   else 'R17A_OBJECT_OR_SYMBOL_DIAGNOSTICS_RECORDED',
                   'object_success_count':count,'r16_proven_ten_retained':preserved,
                   'qc_vas_compiled':result['objects']['kernel/sched/walt/qc_vas.o']['compiled'],
                   'topology_compiled':result['objects']['kernel/sched/topology.o']['compiled'],
                   'symbol_evidence':symbols})
    report.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(f"R17A_ARM64_OBJECTS={count}/12; R16_PRESERVED={preserved}/10; "
          f"QC_VAS={int(result['qc_vas_compiled'])}; TOPOLOGY={int(result['topology_compiled'])}; "
          f"PROVIDERS={int(symbols['symbols_verified'])}; STATUS={result['status']}; "
          'IMAGE=NO; ABI=OPEN; FLASH=NO')
    return result

def main():
    p=argparse.ArgumentParser()
    for key in ('snapshot','canonical','objout','toolchain','project','source-gate','r16-gate','r16-result','driver','config','output'):
        p.add_argument('--'+key,required=True,type=Path)
    q=p.parse_args()
    try:main_run(q)
    except (GateError,OSError,ValueError,KeyError,subprocess.TimeoutExpired) as e:
        print('R17A_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
