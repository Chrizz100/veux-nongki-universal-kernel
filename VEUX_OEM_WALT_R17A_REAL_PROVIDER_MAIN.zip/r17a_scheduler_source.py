#!/usr/bin/env python3
"""R17-A: original scheduler provider visibility + Xiaomi isolated CPU group weights.

Explicitly source-only preparation. Does NOT build or link a kernel and does NOT
implement missing qc_vas dependencies for timers, watchdog or task migration.
R16 genuine GitHub object report and source SHA gate are mandatory.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import sys

DONOR='MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'
P10_TREE='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
R16_SOURCE_STATUS='R16_OEM_BOUNDED_API_STAGE_NOT_KERNEL_COMPILED'
R16_STATES={
 'R16_COMPILER_ERRORS_OR_PROVIDER_SYMBOL_GAPS_RECORDED',
 'R16_ALL_ELEVEN_OBJECTS_AND_PROVIDER_SYMBOLS_COMPILED_NO_LINK',
}
FILES=('kernel/sched/core.c','kernel/sched/sched.h','kernel/sched/topology.c')
R16_KNOWN=('kernel/sched/core.c','kernel/sched/sched.h')
BASELINE=('kernel/sched/walt/walt.o','kernel/sched/core.o','kernel/sched/fair.o',
          'kernel/sysctl.o','kernel/sched/walt/boost.o','kernel/sched/walt/sched_avg.o',
          'kernel/sched/walt/trace.o','kernel/sched/walt/cpu-boost.o')
FORBIDDEN=('flash_allowed','vendor_abi_proven','kernel_image_built',
           'vmlinux_linked','brene_changed','bakasusu_nomount_changed')

class GateError(Exception): pass

def need(ok,msg):
    if not ok: raise GateError(msg)

def sha(b):
    return hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()

def git(canonical,*args):
    p=subprocess.run(['git','-C',str(canonical),*args],capture_output=True)
    need(p.returncode==0,'GIT_LOOKUP_FAILED:'+p.stderr.decode(errors='replace')[:130])
    return p.stdout

def validate_input(gate,compiled):
    need(gate.get('status')==R16_SOURCE_STATUS,'R16_SOURCE_STATUS_UNVERIFIED')
    need(gate.get('source_r15_verified') is True,'R16_SOURCE_NOT_FROM_R15')
    need(gate.get('modified_files')==[
       'include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c',
       'include/linux/sysctl.h','kernel/sysctl.c'],'R16_SOURCE_SCOPE_INVALID')
    need(compiled.get('status') in R16_STATES,'R16_REAL_COMPILER_NOT_COMPLETED')
    need(compiled.get('real_arm64_make_attempted') is True,'R16_REAL_MAKE_NOT_ATTEMPTED')
    need(compiled.get('source_r16_verified') is True,'R16_COMPILER_INPUT_UNVERIFIED')
    need(compiled.get('previous_eight_compiled')==8,'R16_EIGHT_OBJECT_REGRESSION')
    need(compiled.get('object_success_count')==sum(
        v.get('compiled') is True for v in compiled.get('objects',{}).values()),'R16_OBJECT_COUNT_FALSE')
    need(len(compiled.get('objects',{}))==11,'R16_MISSING_OBJECT_RESULTS')
    for key in BASELINE:
        need(compiled['objects'].get(key,{}).get('compiled') is True,'R16_PREVIOUS_BASELINE_FAILED:'+key)
    for doc in (gate,compiled):
        for key in FORBIDDEN:
            need(doc.get(key) is False,'R16_UNSAFE_OR_MISSING_FLAG:'+key)
    for key in R16_KNOWN:
        h=gate.get('after_sha256',{}).get(key)
        need(isinstance(h,str) and re.fullmatch(r'[0-9a-f]{64}',h) is not None,'R16_SOURCE_HASH_NOT_PINNED:'+key)
        need(compiled.get('source_postimages',{}).get(key)==h,'R16_COMPILER_SOURCE_HASH_DRIFT:'+key)

def one(text,old,new,tag):
    need(text.count(old)==1,tag+':EXPECTED_ONE_GOT_'+str(text.count(old)))
    return text.replace(old,new,1)

def patch_core(src):
    old='static void calc_load_migrate(struct rq *rq)\n'
    need('calc_load_fold_active(rq, 1)' in src and 'atomic_long_add(delta, &calc_load_tasks)' in src,
         'CORE_REAL_LOAD_MIGRATION_IMPL_MISSING')
    new=('''#ifdef CONFIG_SCHED_WALT
void
#else
static void
#endif
calc_load_migrate(struct rq *rq)
''')
    return one(src,old,new,'CORE_LOAD_MIGRATE_VISIBILITY')

def patch_topology(src):
    signature='static void init_sched_groups_capacity(int cpu, struct sched_domain *sd)\n'
    need('update_group_capacity(sd, cpu);' in src and 'sg->group_weight = cpumask_weight(' in src,
         'TOPOLOGY_REAL_SCHED_CAPACITY_MISSING')
    src=one(src,signature,('''#ifdef CONFIG_SCHED_WALT
void
#else
static void
#endif
init_sched_groups_capacity(int cpu, struct sched_domain *sd)
'''),'OEM_TOPOLOGY_VISIBILITY')
    # Match the *function* body region, not an unrelated declaration. Keep
    # the existing group loop, and change only group capacity accounting.
    sig='init_sched_groups_capacity(int cpu, struct sched_domain *sd)\n{\n\tstruct sched_group *sg = sd->groups;\n'
    src=one(src,sig,sig+'''#ifdef CONFIG_SCHED_WALT
	cpumask_t avail_mask;
#endif
''','OEM_TOPOLOGY_GROUP_MASK_DECLARE')
    orig='\t\tsg->group_weight = cpumask_weight(sched_group_span(sg));\n'
    updated='''#ifdef CONFIG_SCHED_WALT
		cpumask_andnot(&avail_mask, sched_group_span(sg),
							cpu_isolated_mask);
		sg->group_weight = cpumask_weight(&avail_mask);
#else
		sg->group_weight = cpumask_weight(sched_group_span(sg));
#endif
'''
    return one(src,orig,updated,'OEM_TOPOLOGY_REAL_ISOLATED_WEIGHTS')

def patch_sched(src):
    token='extern void sched_get_nr_running_avg(struct sched_avg_stats *stats);\n'
    need('struct sched_avg_stats {' in src,'R14_AVG_HEADER_NOT_PRESENT')
    need('extern void calc_load_migrate(' not in src and 'extern void init_sched_groups_capacity(' not in src,
         'R17A_PROTOTYPES_ALREADY_PRESENT')
    addition='''
#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_HOTPLUG_CPU)
extern void calc_load_migrate(struct rq *rq);
#endif
#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)
extern void init_sched_groups_capacity(int cpu, struct sched_domain *sd);
#endif
'''
    return one(src,token,token+addition,'R17A_SCHED_EXTERNAL_API_DECL')

TRANSFORMS={'kernel/sched/core.c':patch_core,'kernel/sched/sched.h':patch_sched,'kernel/sched/topology.c':patch_topology}

def prepare(snapshot,canonical,r16_source,r16_compiler,output):
    for folder in (snapshot,canonical):
        need(folder.is_dir() and not folder.is_symlink(),'SOURCE_DIR_INVALID:'+str(folder))
    need(snapshot.resolve()!=canonical.resolve(),'SNAPSHOT_IS_CANONICAL_REPOSITORY')
    need(not output.exists() and not output.is_symlink(),'OUTPUT_DIR_ALREADY_EXISTS')
    for p in (r16_source,r16_compiler):
        need(p.is_file() and not p.is_symlink(),'INPUT_GATE_FILE_MISSING')
    gate=json.loads(r16_source.read_text());cmp=json.loads(r16_compiler.read_text())
    validate_input(gate,cmp)
    before={}
    expected={}
    for name in FILES:
        p=snapshot/name
        need(p.is_file() and not p.is_symlink(),'UNSAFE_OR_MISSING_SOURCE:'+name)
        before[name]=p.read_bytes()
    for name in R16_KNOWN:
        need(sha(before[name])==gate['after_sha256'][name],'R16_ACTUAL_PREIMAGE_DRIFT:'+name)
        expected[name]=gate['after_sha256'][name]
    # Use the immutable P10 Git tree, NOT the historical Positron file hash.
    # P3/P10 reconstruction must already have stored this tree in .git.
    obj=f'{P10_TREE}:kernel/sched/topology.c'
    proof=git(canonical,'cat-file','-p',obj)
    need(before['kernel/sched/topology.c']==proof,'TOPOLOGY_NOT_EXACT_P10_TREE')
    tree=git(canonical,'rev-parse',f'{P10_TREE}^{{tree}}').decode().strip()
    need(tree==P10_TREE,'P10_TREE_NOT_AUTHENTICATED')
    expected['kernel/sched/topology.c']=sha(proof)
    source={k:before[k].decode('utf-8') for k in FILES}
    updated={k:TRANSFORMS[k](source[k]) for k in FILES}
    need(all(updated[k]!=source[k] for k in FILES),'R17A_NO_SOURCE_MODIFICATION')
    patch=''.join(''.join(difflib.unified_diff(source[k].splitlines(keepends=True),
          updated[k].splitlines(keepends=True),fromfile='a/'+k,tofile='b/'+k)) for k in FILES)
    need(patch.count('--- a/')==3 and patch.count('+++ b/')==3,'R17A_PATCH_SCOPE_INVALID')
    r=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=patch,
                     capture_output=True,text=True)
    need(r.returncode==0,'R17A_PATCH_GIT_APPLY_CHECK_FAILED:'+r.stderr[:280])
    # All checks finished; only disposable snapshot is modified.
    for name in FILES: (snapshot/name).write_text(updated[name])
    post={name:sha(updated[name]) for name in FILES}
    for name in FILES:
        need(sha((snapshot/name).read_bytes())==post[name],'R17A_POSTIMAGE_CHANGED:'+name)
    output.mkdir(parents=True)
    (output/'R17A_ORIGINAL_SCHEDULER_PROVIDERS.patch').write_text(patch)
    result={'status':'R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED',
            'modified_files':list(FILES),'before_sha256':expected,'after_sha256':post,
            'patch_sha256':sha(patch),'provenance':{'p10_tree':P10_TREE,'donor':DONOR,
                   'r16_run_gate':cmp.get('status')},
            'compiled_kernel_objects':0,'vmlinux_linked':False,
            'kernel_image_built':False,'vendor_abi_proven':False,
            'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False,
            'qc_vas_runtime_proven':False,
            'requires_actual_arm64_compile':True}
    (output/'R17A_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result

def main(argv=None):
    ap=argparse.ArgumentParser()
    for name in ('snapshot','canonical-repo','r16-source','r16-compiler','output'):
        ap.add_argument('--'+name,required=True,type=pathlib.Path)
    args=ap.parse_args(argv)
    try:
        res=prepare(args.snapshot,args.canonical_repo,args.r16_source,args.r16_compiler,args.output)
    except (GateError,KeyError,ValueError,OSError,UnicodeError) as e:
        print('R17A_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr)
        return 2
    print('R17A_REAL_SCHEDULER_SOURCE_STAGED=PASS; FILES=3; REAL_OBJECT_BUILD=NO; ABI=OPEN; FLASH=NO')
    return 0

if __name__=='__main__': sys.exit(main())
