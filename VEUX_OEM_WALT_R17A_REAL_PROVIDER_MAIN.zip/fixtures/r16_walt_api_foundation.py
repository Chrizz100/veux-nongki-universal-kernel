#!/usr/bin/env python3
"""R16: authentic Xiaomi WALT bounded CPU migration + wake-up + sysctl API port.

Only five exact known files may be changed, only on disposable P3/P10/R15
source copies. Runtime functionality, complete qc_vas.o and ABI stay UNPROVEN.
MiCode donor: 61397e524093d1ccb94769b5460825e2eaf8871e.
"""
import argparse
import difflib
import hashlib
import json
import pathlib
import re
import subprocess
import sys

P10_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
DONOR = 'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'
PINS = {
    'include/linux/sched.h': '96b87376273bc39bc2e2cbac33a50688e9c40c9b40ccbcfafcb5010622534659',
    'kernel/sched/sched.h': 'fe9743bb8d6f7e5be6b2a8df563924c59e6c7a84739181bb91d39047cd2673c6',
    'kernel/sched/core.c': 'fe11a5c1f8db62d1d50449d35b0e1a1b4af3e6b23c24dfeeef226870061aed0a',
    'include/linux/sysctl.h': '0f2f59f5d8665d0a6e8b03a3e4f6cc33e4d66bb2a053cae19cdd87ebb87b683d',
    'kernel/sysctl.c': '2faaf4794c66f8629fcf4fb3da0c046ca060a2e13e58e60f549ffde6a9fde370',
}
ORDER = tuple(PINS)
R15_STATUS = 'R15_OEM_CPU_ISOLATION_FOUNDATION_STAGED_NOT_COMPILED'
R15_COMPILER_STATUS = 'R15_GENUINE_CPU_ISOLATION_COMPILER_DIAGNOSTICS'
R12_STATUS = 'R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED'
R14_STATUS = 'R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED'
R14_SHA = PINS['kernel/sched/sched.h']

class GateError(Exception):
    pass

def need(yes, reason):
    if not yes:
        raise GateError(reason)

def sha(data):
    return hashlib.sha256(data if isinstance(data, bytes) else data.encode()).hexdigest()

def replace_one(src, old, new, tag):
    cnt = src.count(old)
    need(cnt == 1, f'{tag}_ANCHOR_COUNT_{cnt}')
    return src.replace(old, new, 1)

# Exact active WALT getters/setters from Xiaomi include/linux/sched.h:2214-2231.
WALT_WAKE='''#ifdef CONFIG_SCHED_WALT
/* Original Xiaomi WALT wake-up-idle task policy, real per-task field. */
#define PF_WAKE_UP_IDLE 1
static inline u32 sched_get_wake_up_idle(struct task_struct *p)
{
	return p->wts.wake_up_idle;
}

static inline int sched_set_wake_up_idle(struct task_struct *p,
						int wake_up_idle)
{
	p->wts.wake_up_idle = !!wake_up_idle;
	return 0;
}

static inline void set_wake_up_idle(bool enabled)
{
	current->wts.wake_up_idle = enabled;
}
#else
/* OEM WALT-OFF compatibility only: no active WALT runtime is emulated. */
static inline u32 sched_get_wake_up_idle(struct task_struct *p)
{
	return 0;
}

static inline int sched_set_wake_up_idle(struct task_struct *p,
						int wake_up_idle)
{
	return 0;
}

static inline void set_wake_up_idle(bool enabled) {}
#endif

'''

# Real Xiaomi sysctl capacity percent converter, NOT a raw integer handler.
CAPACITY_IMPL='''/* Original Xiaomi scheduler up/down migration percentage conversion. */
static int do_proc_douintvec_capacity_conv(bool *negp, unsigned long *lvalp,
					int *valp, int write, void *data)
{
	if (write) {
		if (*negp || *lvalp == 0 || *lvalp > 100)
			return -EINVAL;
		*valp = SCHED_FIXEDPOINT_SCALE * 100 / *lvalp;
	} else {
		*negp = false;
		*lvalp = SCHED_FIXEDPOINT_SCALE * 100 / *valp;
	}

	return 0;
}

int proc_douintvec_capacity(struct ctl_table *table, int write,
				void __user *buffer, size_t *lenp, loff_t *ppos)
{
	return do_proc_dointvec(table, write, buffer, lenp, ppos,
				do_proc_douintvec_capacity_conv, NULL);
}

'''
CAPACITY_PROTO='''extern int proc_douintvec_capacity(struct ctl_table *table, int write,
				void __user *buffer, size_t *lenp,
				loff_t *ppos);
'''
CAPACITY_NO_PROC='''int proc_douintvec_capacity(struct ctl_table *table, int write,
			    void __user *buffer, size_t *lenp, loff_t *ppos)
{
	return -ENOSYS;
}

'''

OLD_GUARD='#if defined(CONFIG_NUMA_BALANCING) || defined(CONFIG_SPRD_ROTATION_TASK)'
NEW_GUARD='#if defined(CONFIG_NUMA_BALANCING) || defined(CONFIG_SPRD_ROTATION_TASK) || defined(CONFIG_SCHED_WALT)'

def patch_linux_sched(s):
    need('bool\t\t\t\twake_up_idle;' in s or 'wake_up_idle;' in s,'REAL_WALT_TASK_FIELD_MISSING')
    need('sched_get_wake_up_idle(' not in s and 'sched_set_wake_up_idle(' not in s,'WAKE_IDLE_API_ALREADY_PRESENT')
    # End section is downstream of the complete task_struct, unlike early enums.
    anchor='const struct cpumask *sched_trace_rd_span(struct root_domain *rd);\n\n'
    return replace_one(s, anchor, anchor + WALT_WAKE, 'OEM_WAKE_IDLE_AFTER_TASK_STRUCT')

def extend_migrate_guard(s, tag):
    # Full-line anchor prevents treating an already extended guard as the old
    # string prefix (a regression caught by real negative tests).
    old = re.compile(r'(?m)^'+re.escape(OLD_GUARD)+r'(?=\n|$)')
    need(len(old.findall(s)) == 1, tag+'_EXACT_OLD_GUARD_REQUIRED')
    need(s.count(NEW_GUARD) == 0, tag+'_ALREADY_ENABLED')
    return old.sub(NEW_GUARD, s, count=1)

def patch_sched_h(s):
    need('extern int migrate_swap(' in s, 'MIGRATE_SWAP_PROTOTYPE_ABSENT')
    return extend_migrate_guard(s, 'OEM_MIGRATE_SWAP_DECL_GUARD')

def patch_core(s):
    need('int migrate_swap(struct task_struct *cur' in s, 'REAL_MIGRATE_SWAP_PROVIDER_MISSING')
    need('trace_sched_swap_numa(cur' in s, 'MIGRATE_SWAP_TRACE_PATH_MISSING')
    need('static void __migrate_swap_task(' in s, 'MIGRATE_SWAP_BODY_MISSING')
    return extend_migrate_guard(s, 'OEM_MIGRATE_SWAP_BUILD_GUARD')

def patch_sysctl_header(s):
    need('proc_douintvec_capacity' not in s, 'CAPACITY_PROTO_ALREADY_PRESENT')
    anchor='extern int proc_douintvec_ravg_window(struct ctl_table *table, int write,\n'
    m=re.search(r'(?m)^extern int proc_douintvec_ravg_window\([^;]*;\n',s)
    need(m is not None and s.count(anchor)==1, 'OEM_RAVG_PROC_PROTO_MISSING')
    return s[:m.end()]+CAPACITY_PROTO+s[m.end():]

def patch_sysctl(s):
    need('proc_douintvec_capacity' not in s, 'CAPACITY_HANDLER_ALREADY_PRESENT')
    need('int proc_douintvec_ravg_window(' in s, 'R12_RAVG_HANDLER_MISSING')
    need('static int do_proc_dointvec(' in s, 'REAL_SYSCTL_PERCENT_CONVERTER_UNAVAILABLE')
    # Must remain inside CONFIG_PROC_SYSCTL's active branch.
    anchor='static int do_proc_douintvec_rwin('
    s=replace_one(s,anchor,CAPACITY_IMPL+anchor,'OEM_CAPACITY_BEFORE_RAVG_HANDLER')
    fallback='int proc_douintvec_ravg_window(struct ctl_table *table, int write,\n'
    need(s.count(fallback)==2, 'R12_TWO_RAVG_BRANCHES_REQUIRED')
    stop=s.find('#else /* CONFIG_PROC_SYSCTL */')
    need(stop>=0, 'MISSING_PROC_SYSCTL_FALLBACK')
    before,after=s[:stop],s[stop:]
    anchor='#endif /* CONFIG_PROC_SYSCTL */\n'
    after=replace_one(after,anchor,CAPACITY_NO_PROC+anchor,'OEM_CAPACITY_PROC_DISABLED')
    return before+after

TRANSFORM={'include/linux/sched.h':patch_linux_sched,
           'kernel/sched/sched.h':patch_sched_h,
           'kernel/sched/core.c':patch_core,
           'include/linux/sysctl.h':patch_sysctl_header,
           'kernel/sysctl.c':patch_sysctl}

def validate_gates(g15,c15,g12,g14):
    need(g15.get('status')==R15_STATUS,'R15_SOURCE_GATE_INVALID')
    need(g15.get('after_sha256',{}).get('include/linux/sched.h')==PINS['include/linux/sched.h'],'R15_LINUX_SCHED_HASH_DRIFT')
    need(c15.get('status')==R15_COMPILER_STATUS,'R15_COMPILER_STATUS_CHANGED')
    need(c15.get('object_success_count')==10 and c15.get('actual_arm64_make_attempted') is True,'R15_REAL_TEN_OBJECTS_NOT_PROVEN')
    need(c15.get('objects',{}).get('kernel/sched/walt/qc_vas.o',{}).get('compiled') is False,'QC_VAS_FAILURE_NOT_PROVEN')
    need(g12.get('status')==R12_STATUS,'R12_SOURCE_STATUS_INVALID')
    need(g12.get('canonical_p10_tree')==P10_TREE,'R12_P10_TREE_NOT_AUTHENTICATED')
    for name in ('include/linux/sysctl.h','kernel/sysctl.c'):
        need(g12.get('after_sha256',{}).get(name)==PINS[name],'R12_SYSCTL_PROVENANCE_DRIFT:'+name)
    need(g14.get('status')==R14_STATUS and g14.get('after_sha256',{}).get('kernel/sched/sched.h')==R14_SHA,'R14_SCHED_NOT_PROVEN')
    for g in (g15,c15,g12,g14):
        for k in ('flash_allowed','vendor_abi_proven','kernel_image_built','brene_changed','bakasusu_nomount_changed'):
            need(g.get(k) is False,'FALSE_SUCCESS_OR_UNSAFE_CHANGE:'+k)


def stage(snapshot,r15gate,r15compiler,r12gate,r14gate,output):
    need(snapshot.is_dir() and not snapshot.is_symlink(),'INVALID_SNAPSHOT')
    need(not output.exists() and not output.is_symlink(),'OUTPUT_EXISTS')
    for f in (r15gate,r15compiler,r12gate,r14gate):
        need(f.is_file() and not f.is_symlink(),'GATE_FILE_MISSING:'+str(f))
    validate_gates(*[json.loads(f.read_text()) for f in (r15gate,r15compiler,r12gate,r14gate)])
    src={}
    for name in ORDER:
        p=snapshot/name
        need(p.is_file() and not p.is_symlink(),'SOURCE_MISSING_OR_SYMLINK:'+name)
        b=p.read_bytes()
        need(sha(b)==PINS[name],'EXACT_R15_SOURCE_SHA_DRIFT:'+name)
        src[name]=b.decode('utf-8')
    after={name:TRANSFORM[name](src[name]) for name in ORDER}
    need(all(after[n]!=src[n] for n in ORDER),'R16_NO_SOURCE_CHANGE')
    patch=''.join(''.join(difflib.unified_diff(src[n].splitlines(keepends=True),after[n].splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n in ORDER)
    need(patch.count('--- a/')==len(ORDER) and patch.count('+++ b/')==len(ORDER),'PATCH_SCOPE_BAD')
    ck=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=patch,text=True,capture_output=True)
    need(ck.returncode==0,'R16_GIT_APPLY_CHECK_FAILED:'+ck.stderr[:250])
    for name in ORDER: (snapshot/name).write_text(after[name])
    post={n:sha(after[n]) for n in ORDER}
    need(all(sha((snapshot/n).read_bytes())==post[n] for n in ORDER),'POSTIMAGE_CHANGED')
    output.mkdir(parents=True)
    (output/'R16_GENUINE_OEM_FOCUSED_APIS.patch').write_text(patch)
    result={'status':'R16_OEM_BOUNDED_API_STAGE_NOT_KERNEL_COMPILED',
       'before_sha256':PINS,'after_sha256':post,'modified_files':list(ORDER),
       'patch_sha256':sha(patch),'donor_ref':DONOR,'source_r15_verified':True,
       'real_r15_ten_of_eleven_proven':True,'scope':'walt_wake_idle_migrate_swap_ravg_capacity_only',
       'remaining_apis_not_ported':['find_energy_efficient_cpu','active_load_balance_cpu_stop',
         'migrate_tasks','watchdog_enable','watchdog_disable','watchdog_configured',
         'init_sched_groups_capacity','timer_quiesce_cpu','hrtimer_quiesce_cpu','calc_load_migrate'],
       'kernel_image_built':False,'vmlinux_linked':False,'vendor_abi_proven':False,
       'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False,
       'qc_vas_compiled':False,'runtime_tested':False}
    (output/'R16_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R16_FOCUSED_OEM_SCHED_AND_SYSCTL_APIS=STAGED; FILES=5; COMPILE_PENDING; LINK=NO; FLASH=NO')
    return result

def main():
    p=argparse.ArgumentParser()
    for key in ('snapshot','r15-gate','r15-compiler','r12-gate','r14-gate','output'):
        p.add_argument('--'+key,required=True,type=pathlib.Path)
    q=p.parse_args()
    try:
        stage(q.snapshot,q.r15_gate,q.r15_compiler,q.r12_gate,q.r14_gate,q.output)
    except (GateError,ValueError,OSError,KeyError) as exc:
        print('R16_SOURCE_GATE_ERROR:'+str(exc),file=sys.stderr)
        return 2
    return 0
if __name__=='__main__':sys.exit(main())
