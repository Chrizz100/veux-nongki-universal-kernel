VEUX M36 - Monitor: gueltige Messwerte und Wiederholung fehlgeschlagener Stromkonfiguration - NOFLASH
Basis: gruener M35-Lauf 43798107838, Commit 6800cde3b2378c50af718eb26160b9f6784338b4.

UPLOAD AM SMARTPHONE
1. VEUX_M36_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M36_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M35 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256 und komplette ZIP-CRC geprueft:
1.082 Dateien, 997 Textdateien, 277 JSON-Dateien, 37.400.929 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M35 unabhaengig geprueft:
echte Quellen, LLVM-Objekt/CFI-Kommando, acht verlinkte Schnittstellen und neue
Adapter-Fehlerzweige, 40 erfolgreiche make-Aufrufe, eingebettete Konfiguration
in Image/vmlinux und unveraenderte komplette Exporttabelle.
Import-CRCs unabhaengig neu berechnet: 1.423 passend, keine CRC-Abweichung,
kein fehlender Export und 37 passende Module der bekannten Stock-Vendor-Kohorte.
Boot.img und AK3 byteidentisch aus gepinnten Referenzen rekonstruiert;
AVB und Stock-Ramdisk/Paar geprueft. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M35. Reports/RUN43798107838_32_ARTEFAKTE.zip und
Reports/M35_INDEPENDENT_VERIFICATION.json enthalten die Auswertung.
Static Boot Pass ist kein Device Pass.

M36 REPARATUR
Ausschliesslich bq2589x_monitor_workfunc ist gegenueber M35 veraendert.
Die Stromkonfiguration prueft jetzt Register-Setter und gegebenenfalls beide
GPIO-Umschaltungen. Nach dem ersten Konfigurationsfehler folgen keine davon
abhaengigen Konfigurationsschritte. curr_flag wird nur nach vollstaendigem Erfolg
gesetzt. Der naechste Monitorzyklus kann eine gescheiterte Konfiguration erneut
versuchen. Bereits ausgefuehrte Hardware-Schritte werden nicht zurueckgerollt.
Die unabhaengige Temperatur-/Spannungspruefung laeuft auch nach Konfigurationsfehlern.
Nur erfolgreich gelesene Temperaturen steuern temperaturabhaengige Registerwerte.
Fehlender Batterie-Provider oder Fehler des Temperaturabrufs werden protokolliert;
weder Initialwert 0 noch ein vom fehlgeschlagenen Getter hinterlassener Wert
gilt dann als Temperaturmessung. Der periodische Monitor bleibt aktiv.
Bei hoher gueltiger Temperatur wird die Batteriespannung geprueft. Ein Fehler
wird nicht als Messwert verwendet. Die bestehende Abschaltung erfolgt weiterhin
nur bei erfolgreich gelesener Temperatur und Spannung jenseits der alten Grenzen.
Schreibfehler der Temperaturkorrekturen oder Abschaltung werden gemeldet.
Die unabhaengige zweite Temperaturkorrektur und der naechste Monitorzyklus bleiben
erhalten. Eine fehlgeschlagene Abschaltung wird nicht als Erfolg markiert.
Kein neuer Ersatzwert, keine neue Abschaltstrategie bei unbekannten Messwerten.
Alle bisherigen erfolgreichen Hardware-Reihenfolgen, Strom-/Spannungsvorgaben,
Temperaturgrenzen und das 10-Sekunden-Intervall bleiben gleich.
Keine Defconfig-Aenderung; alle bisherigen Reparaturen und beide Header bleiben
erhalten. bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-Zeilenumbruch.

BEWUSSTE GRENZEN
ADC-, VINDPM-/HIZ-Zweig und SDP-VINDPM-Helfer bleiben in ihrer bisherigen Logik.
Deren zusaetzliche Fehlerbehandlung ist nicht Teil dieses Monitor-Pakets.
Insbesondere wird bei ungueltigen Messwerten keine neue Hardware-Sicherheitsregel
erfunden. Auch normale parallele Adapter-/Monitorarbeiten werden nicht neu
serialisiert. Provider-Bindung, HIZ-Wiederherstellung und echte Geraeteablaeufe
muessen weiter geprueft werden. Keine atomare Hardware-Wiederherstellung behauptet.

LOKALE PRUEFUNGEN
37 M36-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Neuer nativer Test mit echter Monitorfunktion und echten Register-/GPIO-Helfern:
19.057 C-Assertions, 2.560 byte-/ereignisgleiche Erfolgsablaeufe und 2.484 Fehlerfaelle.
Geprueft sind beide Chips, acht Adaptertypen, die bisherigen Grenzwerte, bereits
konfigurierte/nicht konfigurierte Zustaende, GPIO-Fehler, Register-Lese-/Schreibfehler,
fehlender Provider, Fehler plus verfalschte Property-Ausgabewerte, erfolgreiche
Wiederholung im naechsten Zyklus und die unabhaengige Temperaturabschaltung.
Drei alte M35-Fehler wurden reproduziert; die neue Fehlererwartung weist M35 ab.
Alle aktuellen nativen Tests zusammen: 85.710 C-Assertions; dazu 156 Assertions
des unveraenderten Probetests auf der M31-Referenz.
Der komplette Treiber kompiliert fuer ARM64 mit gepinntem AOSP Clang 12.0.5,
CFI/ThinLTO und den Headern des aktuellen M35-Laufs. Die Defines des mitgelieferten
kheaders-Archivs stimmen mit dem generierten autoconf.h ueberein; das Archiv
entfernt lediglich Kommentare. Kein vollstaendiger lokaler M36-Kernelbau.

CI UND OFFENE ARBEIT
Alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue Schicht nutzt den authentischen M28-R2-Baukern mit allen Konfigurations-,
WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M36 muss neue Quellen, LLVM-Objekt,
CFI-Kommando, neun verlinkte Schnittstellen und fuenf neue Monitor-Fehlerzweige
in Image UND vmlinux nachweisen. Konfiguration und komplette Exporttabelle muessen
unveraendert bleiben. Boot.img/AK3 erst nach diesen Gates.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M36-GitHub-Bau und alle Artefakte, danach HIZ/VINDPM und
Provider-/Versorgungspfade. Kein Vollvergleich aller historischen ueber 7.100
Quellabweichungen und kein universeller GKI-Nachweis.
Geraeteboot, Laden, OTG, Suspend, Shutdown und Wiederherstellung bleiben ungetestet.
Device Pass NEIN. Flashfreigabe NEIN.
