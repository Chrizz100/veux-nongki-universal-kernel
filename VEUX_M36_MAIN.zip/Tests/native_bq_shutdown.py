#!/usr/bin/env python3
"""Execute the real shutdown, callbacks and workers; interleave active IIO/sysfs threads."""
import argparse
from pathlib import Path
import re,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
D='drivers/power/supply/qcom/bq2589x_charger.c'
def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args();source=a.source.read_text();base=(ROOT/'References/M32_PROVEN_BQ.c').read_text()
 reg=(ROOT/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text();defines='\n'.join(x for x in reg.splitlines()if x.startswith('#define BQ2589X_'))
 defines+='\n'+'\n'.join(re.findall(r'^#define\s+BQ2589X_STATUS_.*',source,re.M))
 channels=list(dict.fromkeys(re.findall(r'\bPSY_IIO_[A-Z_]+',source)));constants='\n'.join('#define '+n+' '+str(i)for i,n in enumerate(channels))
 constants+='''
#define IIO_VAL_INT 1
#define POWER_SUPPLY_TYPE_UNKNOWN 0
#define POWER_SUPPLY_TYPE_USB 1
#define POWER_SUPPLY_TYPE_USB_CDP 2
#define POWER_SUPPLY_TYPE_USB_DCP 3
#define POWER_SUPPLY_TYPE_USB_FLOAT 4
#define POWER_SUPPLY_TYPE_USB_HVDCP 5
#define POWER_SUPPLY_CHARGE_TYPE_NONE 0
#define POWER_SUPPLY_CHARGE_TYPE_FAST 1
#define POWER_SUPPLY_CHARGE_TYPE_TRICKLE 2
#define POWER_SUPPLY_CHARGE_TYPE_UNKNOWN 3
#define POWER_SUPPLY_PROP_CAPACITY 1
#define POWER_SUPPLY_PROP_TEMP 2
#define POWER_SUPPLY_PROP_VOLTAGE_NOW 3
#define HZ 100
'''
 enum=source[source.index('enum bq2589x_vbus_type {'):source.index('enum bq2589x_part_no {')]
 names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_get_vbus_type','bq2589x_get_chg_type',
 'bq2589x_enable_otg','bq2589x_disable_otg','bq2589x_set_otg_volt','bq2589x_set_otg_current',
 'bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_adc_start','bq2589x_adc_stop',
 'bq2589x_adc_read_battery_volt','bq2589x_adc_read_vbus_volt','bq2589x_read_vindpm_volt','bq2589x_adc_read_charge_current',
 'bq2589x_set_charge_current','bq2589x_set_term_current','bq2589x_set_chargevoltage','bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit',
 'bq2589x_is_dpdm_done','bq2589x_force_dpdm','bq2589x_force_dpdm_done','bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode','bq2589x_get_hiz_mode',
 'bq2589x_force_ico','bq2589x_check_force_ico_done','bq2589x_enable_term','bq2589x_is_charge_done','bq2589x_charge_status',
 'bq2589x_use_absolute_vindpm','bq2589x_reset_chip','bq2589x_adjust_absolute_vindpm',
 'bq2589x_adapter_in_workfunc','bq2589x_adapter_out_workfunc','bq2589x_ico_workfunc','bq2589x_force_workfunc','bq2589x_monitor_workfunc',
 'bq2589x_charger_irq_workfunc','bq2589x_charger_interrupt','bq_iio_read_raw_unlocked','bq_iio_read_raw',
 'bq_iio_write_raw_unlocked','bq_iio_write_raw','bq2589x_show_registers','bq2589x_charger_shutdown']
 body='\n\n'.join(function(source,n)for n in names)
 refs=['bq_iio_read_raw','bq2589x_charger_shutdown','bq2589x_adapter_in_workfunc','bq2589x_adapter_out_workfunc','bq2589x_charger_irq_workfunc','bq2589x_charger_interrupt']
 reference='\n\n'.join(function(base,n).replace(n+'(',n+'_reference(',1)for n in refs)
 tests=r'''
static struct bq2589x bq;
static struct i2c_client client;
static struct iio_dev iio;
static atomic_int assertions;
static bool initialized;
static struct event_record bus_saved[1024];
static int bus_used,thread_kind;
#define CHECK(x) do{atomic_fetch_add(&assertions,1);if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);abort();}}while(0)
static void reset(int chip){
 if(initialized)pthread_mutex_destroy(&bq.io_lock.value);
 memset(&bq,0,sizeof(bq));memset(&client,0,sizeof(client));memset(registers,0,sizeof(registers));memset(events,0,sizeof(events));
 mutex_init(&bq.io_lock);initialized=true;bq.startup_ready=true;bq.is_bq25890h=chip;
 current_bq=&bq;g_bq=&bq;client.data=&bq;client.dev.data=&bq;client.irq=10;bq.client=&client;bq.dev=&client.dev;iio.data=&bq;
 bq.wt_ws=&client;bq.batt_psy=&bq;bq.usb_psy=&iio;bq.wakeup_flag=1;bq.irq_wake_enabled=true;bq.cfg.otg_status=true;bq.curr_flag=1;
 bq.irq_work.id=1;bq.adapter_in_work.id=2;bq.adapter_out_work.id=3;bq.force_work.work.id=4;bq.ico_work.work.id=5;bq.monitor_work.work.id=6;
 fail_read=fail_write=read_calls=write_calls=event_count=shutdown_phase=drain_count=fail_from_call=0;fail_count=fail_reg=-1;
 free_irqs=free_gpios=unregister_ws=put_psys=disable_wakes=final_bus_calls=late_checks=0;first_bus_phase=-1;compat_mode=stop_on_sleep=false;
 atomic_store(&hold_read,0);atomic_store(&read_entered,0);atomic_store(&release_read,0);atomic_store(&shutdown_requested,0);atomic_store(&lock_attempt_seen,0);
}
static void check_stopped_workers(void){
 int before=event_count;
 bq2589x_adapter_in_workfunc(&bq.adapter_in_work);bq2589x_adapter_out_workfunc(&bq.adapter_out_work);
 bq2589x_ico_workfunc(&bq.ico_work.work);bq2589x_force_workfunc(&bq.force_work.work);bq2589x_monitor_workfunc(&bq.monitor_work.work);
 bq2589x_charger_irq_workfunc(&bq.irq_work);CHECK(bq2589x_charger_interrupt(client.irq,&bq)==IRQ_HANDLED);bq2589x_force_dpdm_done(&bq);
 CHECK(event_count==before);
}
static void check_final_bus_access(void){
 if(compat_mode)return;
 struct iio_chan_spec ch={PSY_IIO_MAIN_INPUT_VOLTAGE_SETTLED};int value=12345,other=0;char buf[PAGE_SIZE];int before=event_count;
 CHECK(drain_count==6&&READ_ONCE(bq.stopping));
 CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==-ESHUTDOWN);CHECK(value==12345);
 CHECK(bq_iio_write_raw(&iio,&ch,8500,0,0)==-ESHUTDOWN);
 CHECK(bq2589x_show_registers(bq.dev,NULL,buf)==-ESHUTDOWN);CHECK(event_count==before);check_stopped_workers();late_checks++;
}
static int copy_bus(struct event_record *out){int n=0;for(int i=0;i<event_count;i++)if(events[i].kind==1||events[i].kind==2)out[n++]=events[i];return n;}
static void check_cleanup(int has_psys,int has_ws,int wake){
 CHECK(drain_count==6&&free_irqs==1&&free_gpios==1);CHECK(put_psys==has_psys&&unregister_ws==has_ws&&disable_wakes==wake);
 CHECK(bq.stopping&&client.data==NULL&&g_bq==NULL&&bq.wt_ws==NULL&&bq.batt_psy==NULL&&bq.usb_psy==NULL);
 int before=event_count;bq2589x_charger_shutdown(&client);CHECK(event_count==before);
 struct iio_chan_spec ch={PSY_IIO_SC_BUS_VOLTAGE};int value=12345,other=0;
 CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==-ESHUTDOWN);CHECK(value==12345);CHECK(bq_iio_write_raw(&iio,&ch,9000,0,0)==-ESHUTDOWN);CHECK(event_count==before);
 check_stopped_workers();
}
static void *external_thread(void *unused){
 struct iio_chan_spec ch={PSY_IIO_SC_BUS_VOLTAGE};int value=-123,other=0;char buf[PAGE_SIZE];
 if(thread_kind==0){CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==IIO_VAL_INT);CHECK(value==2600);}
 else if(thread_kind==1){ch.channel=PSY_IIO_MAIN_CHAGER_CURRENT;CHECK(bq_iio_write_raw(&iio,&ch,1500,0,0)==0);}
 else CHECK(bq2589x_show_registers(bq.dev,NULL,buf)>0);
 return NULL;
}
static void *shutdown_thread(void *unused){shutdown_tid=pthread_self();atomic_store(&shutdown_requested,1);bq2589x_charger_shutdown(&client);return NULL;}
int main(void){
 struct iio_chan_spec ch={PSY_IIO_SC_BUS_VOLTAGE};int value=-123,other=0;
 reset(0);compat_mode=true;bq2589x_charger_shutdown_reference(&client);CHECK(first_bus_phase==0);CHECK(!bq.stopping);
 puts("BQ_M32_FINAL_WRITES_BEFORE_IRQ_AND_WORK_DRAIN=REPRODUCED");
 int before=read_calls;CHECK(bq_iio_read_raw_reference(&iio,&ch,&value,&other,0)==IIO_VAL_INT);CHECK(read_calls>before);
 puts("BQ_M32_IIO_BUS_ACCESS_AFTER_SHUTDOWN=REPRODUCED");
 reset(0);compat_mode=true;bq2589x_charger_shutdown_reference(&client);bus_used=copy_bus(bus_saved);
 for(int chip=0;chip<2;chip++){
  reset(chip);bq2589x_charger_shutdown(&client);struct event_record actual[1024];int n=copy_bus(actual);
  CHECK(n==bus_used&&!memcmp(actual,bus_saved,(size_t)n*sizeof(actual[0])));CHECK(first_bus_phase==1&&late_checks>0);check_cleanup(2,1,1);
  for(int mode=0;mode<4;mode++){
   reset(chip);if(mode==1)fail_read=-EREMOTEIO;if(mode==2)fail_write=-EIO;if(mode==3){bq.usb_psy=NULL;bq.batt_psy=NULL;bq.wt_ws=NULL;bq.wakeup_flag=0;bq.irq_wake_enabled=false;}
   bq2589x_charger_shutdown(&client);CHECK(first_bus_phase==1&&late_checks>0);check_cleanup(mode==3?0:2,mode==3?0:1,mode==3?0:1);
  }
  for(thread_kind=0;thread_kind<3;thread_kind++){
   reset(chip);atomic_store(&hold_read,1);pthread_t reader,shutdown;
   CHECK(!pthread_create(&reader,NULL,external_thread,NULL));while(!atomic_load(&read_entered))sched_yield();
   CHECK(!pthread_create(&shutdown,NULL,shutdown_thread,NULL));while(!atomic_load(&lock_attempt_seen))sched_yield();
   CHECK(!READ_ONCE(bq.stopping));CHECK(shutdown_phase==0&&drain_count==0&&free_irqs==0);
   atomic_store(&release_read,1);CHECK(!pthread_join(reader,NULL));CHECK(!pthread_join(shutdown,NULL));check_cleanup(2,1,1);
  }
 }
 /* Requeue checks must see stopping even when shutdown starts during a wait. */
 reset(0);stop_on_sleep=true;bq2589x_force_dpdm_done(&bq);CHECK(bq.stopping);CHECK(read_calls==2);CHECK(write_calls==1);
 /* Nominal adapter/IRQ operation order and parameters remain unchanged. */
 for(int chip=0;chip<2;chip++)for(int type=0;type<7;type++)for(int worker=0;worker<4;worker++){
  reset(chip);bq.vbus_type=type;bq.curr_flag=0;registers[BQ2589X_REG_0B]=(u8)(type<<BQ2589X_VBUS_STAT_SHIFT);
  switch(worker){case 0:bq2589x_adapter_in_workfunc_reference(&bq.adapter_in_work);break;case 1:bq2589x_adapter_out_workfunc_reference(&bq.adapter_out_work);break;case 2:bq2589x_charger_irq_workfunc_reference(&bq.irq_work);break;default:bq2589x_charger_interrupt_reference(client.irq,&bq);}
  int used=event_count;memcpy(saved_events,events,sizeof(events));
  reset(chip);bq.vbus_type=type;bq.curr_flag=0;registers[BQ2589X_REG_0B]=(u8)(type<<BQ2589X_VBUS_STAT_SHIFT);
  switch(worker){case 0:bq2589x_adapter_in_workfunc(&bq.adapter_in_work);break;case 1:bq2589x_adapter_out_workfunc(&bq.adapter_out_work);break;case 2:bq2589x_charger_irq_workfunc(&bq.irq_work);break;default:bq2589x_charger_interrupt(client.irq,&bq);}
  CHECK(event_count==used&&!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));
 }
 printf("BQ_SHUTDOWN_HOST_TESTS=PASS; assertions=%d; concurrent_external_cases=6; nominal_worker_cases=56; producer drain, late access and final bus traces\n",atomic_load(&assertions));
 return 0;
}
'''
 with tempfile.TemporaryDirectory(prefix='m33-bq-shutdown-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(constants+'\n'+(ROOT/'References/native_bq_shutdown_stubs.h').read_text()+'\n'+enum+'\n'+defines+'\n'+body+'\n'+reference+'\n'+tests)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-Wno-pointer-sign','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True,timeout=25)
if __name__=='__main__':main()
