#!/usr/bin/env python3
"""Execute both complete probe functions with allocation/registration fault injection."""
import argparse
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/bq2589x_charger.c'


def function(source):
    start = source.index('static int bq2589x_charger_probe(')
    end = source.index('\n}', start) + 2
    return source[start:end]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    args = p.parse_args()
    before = (ROOT / 'Before' / DRIVER).read_text()
    source = args.source.read_text()
    enum = before[before.index('enum bq2589x_part_no {'):before.index('enum bq2589x_part_no {') +
                  before[before.index('enum bq2589x_part_no {'):].index('};') + 2]
    prefix = r'''
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <setjmp.h>
struct device { void *of_node; struct { int unused; } kobj; };
struct bq2589x;
struct i2c_client { struct device dev; int irq; struct bq2589x *data; };
struct i2c_device_id { int unused; };
struct iio_dev { struct bq2589x *data; };
struct work_struct { int id; };
struct delayed_work { struct work_struct work; };
struct bq2589x {
 struct iio_dev *indio_dev;
 struct device *dev;
 struct i2c_client *client;
 bool usb_switch_flag, force_exit_flag, hz_flag, is_bq25890h;
 int status, revision, part_no, charge_type, irq_gpio;
 void *wt_ws, *batt_psy, *usb_psy;
 struct work_struct irq_work, adapter_in_work, adapter_out_work;
 struct delayed_work monitor_work, ico_work, force_work;
};
struct attribute_group { int unused; };
static const struct attribute_group bq2589x_attr_group = {0};
#define BQ2589X_STATUS_EXIST 1
#define IRQF_TRIGGER_FALLING 1
#define IRQF_ONESHOT 2
#define dev_err(...) ((void)0)
#define dev_info(...) ((void)0)
#define pr_err(...) ((void)0)
enum {ALLOC=1,PRIV,CLIENTDATA,DETECT,IIO_INIT,WAKEUP,PSY_BATTERY,PSY_USB,
 PARSE_DT,INIT_DEVICE,GPIO_REQUEST,GPIO_TO_IRQ,INIT_WORK_ITEM,SYSFS_CREATE,
 REQUEST_IRQ,ENABLE_WAKE,USB_SWITCH,FORCE_DPDM,CANCEL_WORK,CANCEL_DELAYED};
struct event { int id, arg; };
static struct event trace[128], saved[128];
static int used, fail_event, fail_code, chip, alloc_fail, null_priv, assertions;
static struct bq2589x state, *g_bq;
static struct iio_dev iio;
static struct i2c_client client;
static jmp_buf null_trap;
static bool trap_enabled;
static int event(int id, int arg) {
 if (used >= 128) abort();
 trace[used++] = (struct event){id,arg};
 return id == fail_event ? fail_code : 0;
}
static struct iio_dev *devm_iio_device_alloc(struct device *dev, size_t bytes) {
 event(ALLOC,(int)bytes); return alloc_fail ? NULL : &iio;
}
static void *iio_priv(struct iio_dev *dev) {
 event(PRIV,0);
 if (!dev) { null_priv++; if (trap_enabled) longjmp(null_trap,1); abort(); }
 return dev->data;
}
static void i2c_set_clientdata(struct i2c_client *c, struct bq2589x *s) {
 event(CLIENTDATA,0); c->data=s;
}
static int bq2589x_detect_device(struct bq2589x *bq) {
 int rc=event(DETECT,0); if (!rc) { bq->part_no=chip; bq->revision=2; } return rc;
}
static int bq_init_iio_psy(struct bq2589x *bq) { return event(IIO_INIT,0); }
static void *wakeup_source_register(struct device *dev,const char *name) { event(WAKEUP,0); return &state; }
static void wakeup_source_unregister(void *p) { abort(); }
static void *power_supply_get_by_name(const char *name) { event(!strcmp(name,"battery")?PSY_BATTERY:PSY_USB,0); return &state; }
static int bq2589x_parse_dt(struct device *dev,struct bq2589x *bq) { return event(PARSE_DT,0); }
static int bq2589x_init_device(struct bq2589x *bq) { return event(INIT_DEVICE,0); }
static int gpio_request(int gpio,const char *name) { return event(GPIO_REQUEST,gpio); }
static int gpio_to_irq(int gpio) { int rc=event(GPIO_TO_IRQ,gpio); return rc ? rc : 17; }
static void bq2589x_charger_irq_workfunc(struct work_struct *w) {}
static void bq2589x_adapter_in_workfunc(struct work_struct *w) {}
static void bq2589x_adapter_out_workfunc(struct work_struct *w) {}
static void bq2589x_monitor_workfunc(struct work_struct *w) {}
static void bq2589x_ico_workfunc(struct work_struct *w) {}
static void bq2589x_force_workfunc(struct work_struct *w) {}
static void init_work_item(struct work_struct *w,void (*fn)(struct work_struct *)) { event(INIT_WORK_ITEM,w->id); }
#define INIT_WORK(w,fn) init_work_item(w,fn)
#define INIT_DELAYED_WORK(w,fn) init_work_item(&(w)->work,fn)
static int sysfs_create_group(void *kobj,const struct attribute_group *group) { return event(SYSFS_CREATE,0); }
static int bq2589x_charger_interrupt(int irq,void *data) { return 0; }
static int request_irq(int irq,int (*fn)(int,void *),int flags,const char *name,void *data) { return event(REQUEST_IRQ,irq); }
static int enable_irq_wake(int irq) { return event(ENABLE_WAKE,irq); }
static int bq2589x_usb_switch(struct bq2589x *bq,bool on) { return event(USB_SWITCH,on); }
static void bq2589x_force_dpdm_done(struct bq2589x *bq) { event(FORCE_DPDM,0); }
static void cancel_work_sync(struct work_struct *w) { event(CANCEL_WORK,w->id); }
static void cancel_delayed_work_sync(struct delayed_work *w) { event(CANCEL_DELAYED,w->work.id); }
static void reset(int part, bool dt) {
 memset(&state,0,sizeof(state)); memset(&iio,0,sizeof(iio)); memset(&client,0,sizeof(client));
 memset(trace,0,sizeof(trace)); used=fail_event=alloc_fail=null_priv=0; fail_code=-EIO; chip=part;
 trap_enabled=false; g_bq=NULL; iio.data=&state; client.dev.of_node=dt?&state:NULL;
 state.irq_gpio=7; state.irq_work.id=1; state.adapter_in_work.id=2; state.adapter_out_work.id=3;
 state.monitor_work.work.id=4; state.ico_work.work.id=5; state.force_work.work.id=6;
}
static int count(int id) { int n=0; for(int i=0;i<used;i++) if(trace[i].id==id)n++; return n; }
#define CHECK(x) do { assertions++; if(!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while(0)
'''
    tests = r'''
int main(void) {
 int saved_count, expected;
 // Original allocation handling reaches iio_priv(NULL) before checking memory.
 reset(BQ25890,true); alloc_fail=1; trap_enabled=true;
 if (setjmp(null_trap)==0) { bq2589x_charger_probe_reference(&client,NULL); CHECK(0); }
 CHECK(null_priv==1); CHECK(count(PRIV)==1); CHECK(count(DETECT)==0);
 puts("BQ_ORIGINAL_NULL_PRIV=REPRODUCED");
 // Original IIO-registration error is ignored and reaches IRQ activation.
 reset(BQ25890,true); fail_event=IIO_INIT; fail_code=-517;
 CHECK(bq2589x_charger_probe_reference(&client,NULL)==0);
 CHECK(count(WAKEUP)==1 && count(REQUEST_IRQ)==1 && count(FORCE_DPDM)==1);
 puts("BQ_ORIGINAL_IIO_FAILURE_CONTINUES=REPRODUCED");
 reset(BQ25890,true); alloc_fail=1; trap_enabled=true;
 if (setjmp(null_trap)!=0) { fprintf(stderr,"FAIL fixed probe reached iio_priv(NULL)\n"); return 1; }
 CHECK(bq2589x_charger_probe(&client,NULL)==-ENOMEM);
 CHECK(used==1 && count(ALLOC)==1 && count(PRIV)==0 && null_priv==0);
 CHECK(g_bq==NULL && client.data==NULL);
 int parts[]={BQ25890,SYV690};
 int errors[]={-EIO,-ENOMEM,-517,-EINVAL,-EREMOTEIO};
 for(int c=0;c<2;c++)for(int dt=0;dt<2;dt++)for(int e=0;e<5;e++) {
  reset(parts[c],dt); fail_event=IIO_INIT; fail_code=errors[e];
  CHECK(bq2589x_charger_probe(&client,NULL)==errors[e]);
  CHECK(used==5 && trace[4].id==IIO_INIT);
  CHECK(count(WAKEUP)==0 && count(PSY_BATTERY)==0 && count(GPIO_REQUEST)==0);
  CHECK(count(INIT_DEVICE)==0 && count(INIT_WORK_ITEM)==0 && count(REQUEST_IRQ)==0);
  CHECK(count(SYSFS_CREATE)==0 && count(FORCE_DPDM)==0 && g_bq==NULL);
 }
 // Every nominal operation, argument and order remains identical for both chips.
 for(int c=0;c<2;c++)for(int dt=0;dt<2;dt++) {
  reset(parts[c],dt); CHECK(bq2589x_charger_probe_reference(&client,NULL)==0);
  saved_count=used; memcpy(saved,trace,sizeof(trace));
  reset(parts[c],dt); CHECK(bq2589x_charger_probe(&client,NULL)==0);
  CHECK(used==saved_count && !memcmp(trace,saved,(size_t)used*sizeof(trace[0])));
  CHECK(count(INIT_WORK_ITEM)==6 && count(REQUEST_IRQ)==1 && count(FORCE_DPDM)==1);
  CHECK(g_bq==&state && state.is_bq25890h==(c==0)); CHECK(client.irq==17);
 }
 // Existing detection and later initialization failures retain their old behavior.
 int later[]={DETECT,INIT_DEVICE,GPIO_REQUEST,GPIO_TO_IRQ,SYSFS_CREATE,REQUEST_IRQ};
 for(int c=0;c<2;c++)for(int e=0;e<6;e++) {
  reset(parts[c],true); fail_event=later[e]; expected=bq2589x_charger_probe_reference(&client,NULL);
  saved_count=used; memcpy(saved,trace,sizeof(trace));
  reset(parts[c],true); fail_event=later[e]; CHECK(bq2589x_charger_probe(&client,NULL)==expected);
  CHECK(used==saved_count && !memcmp(trace,saved,(size_t)used*sizeof(trace[0])));
 }
 printf("BQ_PROBE_HOST_TESTS=PASS; assertions=%d; allocation, registration, deferred probe and unchanged full success traces\n",assertions);
 return 0;
}
'''
    baseline = function(before).replace('bq2589x_charger_probe(', 'bq2589x_charger_probe_reference(', 1)
    with tempfile.TemporaryDirectory(prefix='m29-bq-probe-') as temp:
        root = Path(temp);c = root / 'test.c';binary = root / 'test'
        c.write_text(prefix + '\n' + enum + '\n' + baseline + '\n' + function(source) + '\n' + tests)
        subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter',
                        '-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(binary)],check=True)
        subprocess.run([str(binary)],check=True,timeout=20)


if __name__ == '__main__':
    main()
