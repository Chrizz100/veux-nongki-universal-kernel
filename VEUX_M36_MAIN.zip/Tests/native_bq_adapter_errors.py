#!/usr/bin/env python3
"""Run actual adapter workers, setters, GPIO switch and independent unplug resets."""
import argparse
from pathlib import Path
import re,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1];D='drivers/power/supply/qcom/bq2589x_charger.c'
def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args();src=a.source.read_text();base=(ROOT/'References/M34_PROVEN_BQ.c').read_text()
 defs='\n'.join(x for x in(ROOT/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()if x.startswith('#define BQ2589X_'))
 const='''
#define BQ2589X_STATUS_CHARGE_ENABLE 4
#define POWER_SUPPLY_PROP_CAPACITY 1
#define POWER_SUPPLY_PROP_TEMP 2
#define HZ 100
'''
 enum=src[src.index('enum bq2589x_vbus_type {'):src.index('enum bq2589x_part_no {')]
 names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_adc_start','bq2589x_adc_read_vbus_volt','bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit','bq2589x_set_charge_current','bq2589x_set_chargevoltage','bq2589x_usb_switch','bq2589x_adjust_absolute_vindpm','bq2589x_adapter_in_workfunc','bq2589x_adapter_out_workfunc']
 body='\n\n'.join(function(src,n)for n in names)
 ref='\n\n'.join(function(base,n).replace(n+'(',n+'_reference(',1)for n in ['bq2589x_adapter_in_workfunc','bq2589x_adapter_out_workfunc'])
 tests=r'''
static struct bq2589x bq;static struct device dev;static struct i2c_client client;
static int assertions,success_cases,fault_cases;static unsigned char saved_regs[256];
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void reset(int chip,int type,int full,int battery){
 memset(&bq,0,sizeof(bq));memset(registers,0,sizeof(registers));memset(events,0,sizeof(events));
 bq.dev=&dev;bq.client=&client;g_bq=&bq;bq.is_bq25890h=chip;bq.vbus_type=type;bq.batt_psy=battery?&bq:NULL;bq.usb_psy=&client;bq.cfg.charge_current=2000;bq.usb_switch1=31;bq.usb_switch2=32;bq.usb_swtich_status=1;
 bq.monitor_work.work.id=1;bq.ico_work.work.id=2;registers[BQ2589X_REG_11]=25;
 failure_event=-1;capacity=full?100:50;fail_read=fail_write=fail_from_call=fail_write_at=read_calls=write_calls=event_count=fail_gpio_at=gpio_calls=fail_gpio=fail_property=property_calls=last_error=shutdown_phase=drain_count=0;fail_count=fail_reg=-1;stop_on_sleep=stop_on_notify=false;
 atomic_store(&hold_read,0);atomic_store(&read_entered,0);atomic_store(&release_read,0);
}
static int count(int kind,int id){int n=0;for(int i=0;i<event_count;i++)if(events[i].kind==kind&&(id<0||events[i].a==id))n++;return n;}
static int footer(void){return count(15,1)==1&&count(6,1)==1&&count(4,1)==1;}
static int no_hardware_after_error(void){int i=failure_event+1;if(failure_event<0)return 0;for(;i<event_count;i++)if(events[i].kind!=9&&events[i].kind!=15&&events[i].kind!=6&&!(events[i].kind==4&&events[i].a==1))return 0;return 1;}
int main(void){
 reset(0,BQ2589X_VBUS_MAXC,0,1);fail_read=-EIO;fail_count=3;fail_from_call=1;bq2589x_adapter_in_workfunc_reference(&bq.adapter_in_work);CHECK(write_calls>0);
 puts("BQ_M34_FAILED_ADC_STILL_CONFIGURES_ADAPTER=REPRODUCED");
 reset(0,BQ2589X_VBUS_USB_CDP,0,1);fail_property=-EREMOTEIO;bq2589x_adapter_in_workfunc_reference(&bq.adapter_in_work);CHECK(gpio_calls==2&&write_calls==3);
 puts("BQ_M34_FAILED_CAPACITY_STILL_PROGRAMS_CURRENT=REPRODUCED");
 int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};
 for(int chip=0;chip<2;chip++)for(int type=0;type<8;type++)for(int full=0;full<2;full++)for(int battery=0;battery<2;battery++){
  reset(chip,type,full,battery);bq2589x_adapter_in_workfunc_reference(&bq.adapter_in_work);int used=event_count,reads=read_calls,writes=write_calls,gpios=gpio_calls,props=property_calls;memcpy(saved_events,events,sizeof(events));memcpy(saved_regs,registers,sizeof(registers));
  reset(chip,type,full,battery);bq2589x_adapter_in_workfunc(&bq.adapter_in_work);CHECK(event_count==used&&!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));CHECK(!memcmp(registers,saved_regs,sizeof(registers)));CHECK(last_error==0&&footer());success_cases++;
  /* The unchanged SDP VINDPM helper has its own recovery/error handling. */
  if(type==BQ2589X_VBUS_USB_SDP){reads=4;writes=3;}
  for(int kind=1;kind<=2;kind++)for(int at=1;at<=(kind==1?reads:writes);at++)for(int e=0;e<5;e++){
   reset(chip,type,full,battery);if(kind==1){fail_read=errors[e];fail_from_call=at;fail_count=3;}else{fail_write=errors[e];fail_write_at=at;}
   bq2589x_adapter_in_workfunc(&bq.adapter_in_work);CHECK(last_error==errors[e]);CHECK(footer());CHECK(no_hardware_after_error());
   CHECK(kind==1?read_calls==at+2:write_calls==at);fault_cases++;
  }
  for(int at=1;at<=gpios;at++)for(int e=0;e<5;e++){
   reset(chip,type,full,battery);fail_gpio=errors[e];fail_gpio_at=at;bq2589x_adapter_in_workfunc(&bq.adapter_in_work);
   CHECK(last_error==errors[e]&&gpio_calls==at);CHECK(footer()&&no_hardware_after_error());fault_cases++;
  }
  if(props)for(int e=0;e<5;e++){
   reset(chip,type,full,battery);fail_property=errors[e];bq2589x_adapter_in_workfunc(&bq.adapter_in_work);
   CHECK(last_error==errors[e]&&property_calls==1);CHECK(gpio_calls==0&&write_calls==2);CHECK(footer()&&no_hardware_after_error());fault_cases++;
  }
  reset(chip,type,full,battery);bq.usb_psy=NULL;bq2589x_adapter_in_workfunc(&bq.adapter_in_work);CHECK(count(15,-1)==0&&count(4,1)==1);success_cases++;
 }
 for(int chip=0;chip<2;chip++){
  reset(chip,0,0,1);bq2589x_adapter_out_workfunc_reference(&bq.adapter_out_work);int used=event_count;memcpy(saved_events,events,sizeof(events));
  reset(chip,0,0,1);bq2589x_adapter_out_workfunc(&bq.adapter_out_work);CHECK(event_count==used&&!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));success_cases++;
  for(int kind=1;kind<=2;kind++)for(int at=1;at<=2;at++)for(int e=0;e<5;e++){
   reset(chip,0,0,1);if(kind==1){fail_read=errors[e];fail_from_call=at;fail_count=3;}else{fail_write=errors[e];fail_write_at=at;}
   bq2589x_adapter_out_workfunc(&bq.adapter_out_work);CHECK(last_error==errors[e]);CHECK(read_calls==(kind==1?4:2));CHECK(write_calls==(kind==1?1:2));CHECK(count(1,BQ2589X_REG_0D)>0);fault_cases++;
  }
  reset(chip,0,0,1);fail_read=-EIO;fail_from_call=1;fail_count=3;fail_write=-EREMOTEIO;fail_write_at=1;bq2589x_adapter_out_workfunc(&bq.adapter_out_work);CHECK(last_error==-EIO);CHECK(count(1,BQ2589X_REG_0D)==1);fault_cases++;
  reset(chip,0,0,1);bq.stopping=true;bq2589x_adapter_in_workfunc(&bq.adapter_in_work);bq2589x_adapter_out_workfunc(&bq.adapter_out_work);CHECK(event_count==0);
  reset(chip,0,0,1);stop_on_notify=true;bq2589x_adapter_in_workfunc(&bq.adapter_in_work);CHECK(bq.stopping&&count(6,1)==1&&count(4,1)==0);
 }
 printf("BQ_ADAPTER_ERROR_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; exact nominal traces, first error and independent unplug resets\n",assertions,success_cases,fault_cases);return 0;
}
'''
 with tempfile.TemporaryDirectory(prefix='m35-bq-adapter-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(const+'\n'+(ROOT/'References/native_bq_adapter_stubs.h').read_text()+'\n'+enum+'\n'+defs+'\n'+body+'\n'+ref+'\n'+tests)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True,timeout=25)
if __name__=='__main__':main()
