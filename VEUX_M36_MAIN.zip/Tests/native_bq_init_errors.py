#!/usr/bin/env python3
"""Execute real BQ init and IRQ recovery with a fault at every bus stage."""
import argparse
from pathlib import Path
import re,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1];D='drivers/power/supply/qcom/bq2589x_charger.c'
def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args();src=a.source.read_text();before=(ROOT/'References/M33_PROVEN_BQ.c').read_text()
 defs='\n'.join(x for x in (ROOT/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()if x.startswith('#define BQ2589X_'))
 defs+='\n'+'\n'.join(re.findall(r'^#define\s+BQ2589X_STATUS_.*',src,re.M))
 const='''
#define POWER_SUPPLY_TYPE_UNKNOWN 0
#define POWER_SUPPLY_TYPE_USB 1
#define POWER_SUPPLY_TYPE_USB_CDP 2
#define POWER_SUPPLY_TYPE_USB_DCP 3
#define POWER_SUPPLY_TYPE_USB_FLOAT 4
#define POWER_SUPPLY_TYPE_USB_HVDCP 5
#define POWER_SUPPLY_CHARGE_TYPE_NONE 0
#define POWER_SUPPLY_CHARGE_TYPE_FAST 1
#define POWER_SUPPLY_CHARGE_TYPE_TRICKLE 2
#define POWER_SUPPLY_CHARGE_TYPE_UNKNOWN 3
#define POWER_SUPPLY_PROP_CAPACITY 1
#define POWER_SUPPLY_PROP_TEMP 2
#define HZ 100
'''
 enum=src[src.index('enum bq2589x_vbus_type {'):src.index('enum bq2589x_part_no {')]
 names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_get_vbus_type','bq2589x_get_chg_type',
 'bq2589x_enable_otg','bq2589x_disable_otg','bq2589x_set_otg_volt','bq2589x_set_otg_current','bq2589x_enable_charger','bq2589x_disable_charger',
 'bq2589x_adc_start','bq2589x_adc_stop','bq2589x_set_charge_current','bq2589x_set_term_current','bq2589x_set_chargevoltage',
 'bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit','bq2589x_set_vindpm_offset','bq2589x_disable_watchdog_timer',
 'bq2589x_enable_auto_dpdm','bq2589x_enable_term','bq2589x_enable_ico','bq2589x_use_absolute_vindpm','bq2589x_reset_chip',
 'bq2589x_init_device','bq2589x_charger_irq_workfunc']
 body='\n\n'.join(function(src,n)for n in names)
 ref=function(before,'bq2589x_init_device').replace('bq2589x_init_device(', 'bq2589x_init_device_reference(',1)
 ref+='\n'+function(before,'bq2589x_charger_irq_workfunc').replace('bq2589x_charger_irq_workfunc(', 'bq2589x_charger_irq_workfunc_reference(',1).replace('bq2589x_init_device(', 'bq2589x_init_device_reference(')
 test=r'''
static struct bq2589x bq;static struct device dev;static struct i2c_client client;
static int assertions,success_cases,fault_cases;
static unsigned char saved_registers[256];static struct bq2589x_config saved_cfg;
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void reset(int chip,int automatic,int term){
 memset(&bq,0,sizeof(bq));memset(registers,0x25,sizeof(registers));memset(events,0,sizeof(events));
 bq.dev=&dev;bq.client=&client;g_bq=&bq;bq.is_bq25890h=chip;bq.startup_ready=true;
 bq.cfg.enable_auto_dpdm=automatic;bq.cfg.enable_term=term;bq.cfg.enable_ico=true;bq.cfg.use_absolute_vindpm=true;
 bq.cfg.otg_vol=5300;bq.cfg.otg_current=1800;bq.cfg.charge_voltage=4450;bq.cfg.charge_current=2000;bq.cfg.term_current=256;
 bq.curr_flag=77;bq.charge_type=99;bq.irq_work.id=1;bq.adapter_in_work.id=2;bq.adapter_out_work.id=3;bq.force_work.work.id=4;
 fail_read=fail_write=read_calls=write_calls=event_count=fail_from_call=fail_write_at=shutdown_phase=drain_count=0;fail_count=fail_reg=-1;stop_on_sleep=false;
 atomic_store(&hold_read,0);atomic_store(&read_entered,0);atomic_store(&release_read,0);
}
static void fault(int kind,int at,int error){if(kind==1){fail_read=error;fail_from_call=at;fail_count=3;}else{fail_write=error;fail_write_at=at;}}
static void irq_setup(int chip,int faults){reset(chip,0,1);registers[BQ2589X_REG_0B]=BQ2589X_VBUS_OTG<<BQ2589X_VBUS_STAT_SHIFT;registers[BQ2589X_REG_0C]=faults;}
int main(void){
 reset(0,0,1);fault(2,1,-EIO);CHECK(bq2589x_init_device_reference(&bq)==0);CHECK(write_calls==15);
 puts("BQ_M33_INIT_WRITE_ERROR_RETURNS_SUCCESS=REPRODUCED");
 irq_setup(0,0x40);fault(2,1,-EIO);bq2589x_charger_irq_workfunc_reference(&bq.irq_work);CHECK(write_calls>1);
 puts("BQ_M33_FAILED_RESET_STILL_REINITIALIZES=REPRODUCED");
 int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};
 for(int chip=0;chip<2;chip++)for(int automatic=0;automatic<2;automatic++)for(int term=0;term<2;term++){
  reset(chip,automatic,term);CHECK(bq2589x_init_device_reference(&bq)==0);CHECK(read_calls==15&&write_calls==15);
  int used=event_count;memcpy(saved_events,events,sizeof(events));memcpy(saved_registers,registers,sizeof(registers));saved_cfg=bq.cfg;int saved_status=bq.status;
  reset(chip,automatic,term);CHECK(bq2589x_init_device(&bq)==0);
  CHECK(event_count==used&&!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));CHECK(!memcmp(registers,saved_registers,sizeof(registers)));CHECK(!memcmp(&bq.cfg,&saved_cfg,sizeof(saved_cfg)));CHECK(bq.status==(unsigned)saved_status&&bq.curr_flag==0);success_cases++;
  for(int kind=1;kind<=2;kind++)for(int at=1;at<=15;at++)for(int e=0;e<5;e++){
   reset(chip,automatic,term);fault(kind,at,errors[e]);CHECK(bq2589x_init_device(&bq)==errors[e]);
   CHECK(read_calls==at+(kind==1?2:0));CHECK(write_calls==at-(kind==1?1:0));
   CHECK(event_count==2*(at-1)+(kind==1?3:2));CHECK(bq.curr_flag==(at>(chip?11:12)?0:77));fault_cases++;
  }
 }
 int faults[]={0x40,0x80,0xc0};
 for(int chip=0;chip<2;chip++)for(int f=0;f<3;f++){
  irq_setup(chip,faults[f]);bq2589x_charger_irq_workfunc_reference(&bq.irq_work);int used=event_count;memcpy(saved_events,events,sizeof(events));memcpy(saved_registers,registers,sizeof(registers));
  irq_setup(chip,faults[f]);bq2589x_charger_irq_workfunc(&bq.irq_work);CHECK(event_count==used&&!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));CHECK(!memcmp(registers,saved_registers,sizeof(registers)));success_cases++;
  for(int kind=1;kind<=2;kind++)for(int e=0;e<5;e++){
   irq_setup(chip,faults[f]);fault(kind,kind==1?3:1,errors[e]);bq2589x_charger_irq_workfunc(&bq.irq_work);
   CHECK(read_calls==(kind==1?5:3));CHECK(write_calls==(kind==1?0:1));CHECK(bq.curr_flag==77&&bq.charge_type==99);fault_cases++;
  }
  for(int kind=1;kind<=2;kind++)for(int at=1;at<=15;at++)for(int e=0;e<5;e++){
   irq_setup(chip,faults[f]);fault(kind,at+(kind==1?3:1),errors[e]);bq2589x_charger_irq_workfunc(&bq.irq_work);
   CHECK(read_calls==at+(kind==1?5:3));CHECK(write_calls==at+(kind==1?0:1));CHECK(bq.charge_type==99);fault_cases++;
  }
  irq_setup(chip,faults[f]);stop_on_sleep=true;bq2589x_charger_irq_workfunc(&bq.irq_work);CHECK(bq.stopping&&read_calls==3&&write_calls==1);CHECK(bq.curr_flag==77);
 }
 printf("BQ_INIT_ERROR_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; all 15 init stages, reset recovery and unchanged hardware traces\n",assertions,success_cases,fault_cases);return 0;
}
'''
 with tempfile.TemporaryDirectory(prefix='m34-bq-init-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(const+'\n'+(ROOT/'References/native_bq_init_stubs.h').read_text()+'\n'+enum+'\n'+defs+'\n'+body+'\n'+ref+'\n'+test)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True,timeout=25)
if __name__=='__main__':main()
