#!/usr/bin/env python3
"""Execute the actual BQ read paths, error consumers and successful work sequences."""
import argparse
from pathlib import Path
import re
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[1]
DRIVER='drivers/power/supply/qcom/bq2589x_charger.c'


def function(source,name):
    m=re.search(r'^(?:static\s+)?[^\n;]+\b'+name+r'\([^;]+?\n\{',source,re.M)
    if not m:raise ValueError(name)
    return source[m.start():source.index('\n}',m.end())+2]


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args()
    source=a.source.read_text();baseline=(ROOT/'References/M29_PROVEN_BQ.c').read_text()
    reg=(ROOT/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text()
    definitions='\n'.join(s for s in reg.splitlines() if s.startswith('#define BQ2589X_'))
    channels=list(dict.fromkeys(re.findall(r'\bPSY_IIO_[A-Z_]+',source)))
    constants='\n'.join('#define '+n+' '+str(i) for i,n in enumerate(channels))
    constants+='''
#define IIO_VAL_INT 1
#define POWER_SUPPLY_TYPE_UNKNOWN 0
#define POWER_SUPPLY_TYPE_USB 1
#define POWER_SUPPLY_TYPE_USB_CDP 2
#define POWER_SUPPLY_TYPE_USB_DCP 3
#define POWER_SUPPLY_TYPE_USB_FLOAT 4
#define POWER_SUPPLY_TYPE_USB_HVDCP 5
#define POWER_SUPPLY_CHARGE_TYPE_NONE 0
#define POWER_SUPPLY_CHARGE_TYPE_FAST 1
#define POWER_SUPPLY_CHARGE_TYPE_TRICKLE 2
#define POWER_SUPPLY_CHARGE_TYPE_UNKNOWN 3
#define POWER_SUPPLY_PROP_CAPACITY 1
#define POWER_SUPPLY_PROP_TEMP 2
#define POWER_SUPPLY_PROP_VOLTAGE_NOW 3
#define BQ2589X_STATUS_CHARGE_ENABLE 4
#define HZ 100
'''
    enum=source[source.index('enum bq2589x_vbus_type {'):source.index('enum bq2589x_part_no {')]
    names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_get_vbus_type','bq2589x_get_chg_type',
           'bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_adc_start','bq2589x_adc_stop',
           'bq2589x_adc_read_battery_volt','bq2589x_adc_read_vbus_volt','bq2589x_read_vindpm_volt','bq2589x_adc_read_charge_current',
           'bq2589x_set_charge_current','bq2589x_set_chargevoltage','bq2589x_set_input_volt_limit','bq2589x_is_dpdm_done',
           'bq2589x_force_dpdm','bq2589x_force_dpdm_done','bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode','bq2589x_get_hiz_mode',
           'bq2589x_force_ico','bq2589x_check_force_ico_done','bq2589x_ico_workfunc','bq2589x_is_charge_done','bq2589x_charge_status',
           'bq_iio_read_raw_unlocked','bq_iio_read_raw','bq2589x_adjust_absolute_vindpm','bq2589x_force_workfunc','bq2589x_monitor_workfunc']
    body='\n\n'.join(function(source,n) for n in names)
    refs=['bq2589x_read_byte','bq2589x_get_chg_type','bq_iio_read_raw','bq2589x_adjust_absolute_vindpm','bq2589x_force_workfunc','bq2589x_monitor_workfunc']
    ref_bodies=[]
    for name in refs:
        text=function(baseline,name).replace(name+'(',name+'_reference(',1)
        if name=='bq2589x_adjust_absolute_vindpm':
            # The old driver assigns this variable solely for commented-out code.
            text=text[:-2]+'\n\t(void)vbus_volt;\n}'
        ref_bodies.append(text)
    reference='\n\n'.join(ref_bodies)
    tests=r'''
static struct bq2589x bq;
static struct device dev;
static struct i2c_client client;
static struct iio_dev iio;
static int assertions;
static void reset(void) {
 memset(&bq,0,sizeof(bq)); memset(registers,0,sizeof(registers)); memset(events,0,sizeof(events));
 event_count=read_calls=write_calls=fail_read=fail_write=shutdown_phase=fail_from_call=0; fail_count=fail_reg=-1;
 bq.startup_ready=true;bq.dev=&dev; bq.client=&client; iio.data=&bq; mutex_init(&bq.io_lock);
 bq.batt_psy=&bq; bq.usb_psy=&bq; bq.curr_flag=1;
 bq.vbus_volt=7777;bq.vbat_volt=4444;bq.charge_type=99;
 bq.ico_work.work.id=1;bq.monitor_work.work.id=2;
}
#define CHECK(x) do { assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;} } while(0)
int main(void) {
 u8 out;int value,other,done,saved_count;
 reset();bq.startup_ready=false;value=12345;struct iio_chan_spec early={PSY_IIO_SC_BUS_VOLTAGE};
 CHECK(bq_iio_read_raw(&iio,&early,&value,&other,0)==-EPROBE_DEFER);CHECK(value==12345);CHECK(event_count==0);
 reset();bq.stopping=true;value=12345;CHECK(bq_iio_read_raw(&iio,&early,&value,&other,0)==-ESHUTDOWN);CHECK(value==12345);CHECK(event_count==0);
 reset();fail_read=-EIO;out=0xa5;
 CHECK(bq2589x_read_byte_reference(&bq,&out,0)==0);CHECK(out==(u8)-EIO);CHECK(read_calls==3);
 puts("BQ_ORIGINAL_READ_FALSE_SUCCESS=REPRODUCED");
 reset();fail_read=-EREMOTEIO;value=12345;struct iio_chan_spec ch={PSY_IIO_SC_BUS_VOLTAGE};
 CHECK(bq_iio_read_raw_reference(&iio,&ch,&value,&other,0)==IIO_VAL_INT);CHECK(value<0);
 puts("BQ_ORIGINAL_IIO_ERROR_AS_VALUE=REPRODUCED");
 int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};
 for(int e=0;e<5;e++) {
  reset();fail_read=errors[e];out=0xa5;
  CHECK(bq2589x_read_byte(&bq,&out,0)==errors[e]);CHECK(out==0xa5);CHECK(read_calls==3);CHECK(write_calls==0);
  CHECK(bq2589x_update_bits(&bq,0,0xff,1)==errors[e]);CHECK(write_calls==0);
  CHECK(bq2589x_get_vbus_type(&bq)==errors[e]);
  for(int chip=0;chip<2;chip++){bq.is_bq25890h=chip;CHECK(bq2589x_get_chg_type(&bq)==errors[e]);CHECK(bq.charge_type==99);}
  CHECK(bq2589x_is_charge_done(&bq)==errors[e]);CHECK(bq2589x_charge_status(&bq)==errors[e]);
  CHECK(bq2589x_adc_read_battery_volt(&bq)==errors[e]);CHECK(bq2589x_adc_read_vbus_volt(&bq)==errors[e]);
  CHECK(bq2589x_adc_read_charge_current(&bq)==errors[e]);
  done=123;CHECK(bq2589x_is_dpdm_done(&bq,&done)==errors[e]);CHECK(done==123);
  int reads[]={PSY_IIO_CHARGE_DONE,PSY_IIO_MAIN_CHAGER_HZ,PSY_IIO_MAIN_CHAGER_CURRENT,PSY_IIO_CHARGING_ENABLED,
               PSY_IIO_SC_BUS_VOLTAGE,PSY_IIO_SC_BATTERY_VOLTAGE,PSY_IIO_CHARGER_STATUS,PSY_IIO_CHARGE_TYPE};
  for(unsigned i=0;i<sizeof(reads)/sizeof(reads[0]);i++){ch.channel=reads[i];value=12345;
   CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==errors[e]);CHECK(value==12345);}
 }
 for(int val=0;val<256;val++) {
  reset();registers[0x0b]=val;out=0;
  CHECK(bq2589x_read_byte(&bq,&out,0x0b)==0);CHECK(out==val);CHECK(read_calls==1);
  reset();registers[0x0b]=val;fail_read=-EIO;fail_count=2;out=0;
  CHECK(bq2589x_read_byte(&bq,&out,0x0b)==0);CHECK(out==val);CHECK(read_calls==3);
  reset();registers[0x11]=val;ch.channel=PSY_IIO_SC_BUS_VOLTAGE;value=-1;
  CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==IIO_VAL_INT);
  CHECK(value==BQ2589X_VBUSV_BASE+(val&BQ2589X_VBUSV_MASK)*BQ2589X_VBUSV_LSB);
 }
 for(int chip=0;chip<2;chip++)for(int type=0;type<8;type++) {
  reset();bq.is_bq25890h=chip;bq.old_type=BQ2589X_VBUS_UNKNOWN;registers[BQ2589X_REG_0B]=type<<BQ2589X_VBUS_STAT_SHIFT;
  int expected_type=bq2589x_get_chg_type_reference(&bq);
  reset();bq.is_bq25890h=chip;bq.old_type=BQ2589X_VBUS_UNKNOWN;registers[BQ2589X_REG_0B]=type<<BQ2589X_VBUS_STAT_SHIFT;
  CHECK(bq2589x_get_chg_type(&bq)==expected_type);CHECK(bq.charge_type==expected_type);
 }
 reset();ch.channel=9999;value=42;CHECK(bq_iio_read_raw(&iio,&ch,&value,&other,0)==-EINVAL);CHECK(value==42);
 reset();fail_read=-EIO;bq2589x_force_dpdm_done(&bq);CHECK(read_calls==3);CHECK(write_calls==0);
 reset();fail_write=-EIO;bq2589x_force_dpdm_done(&bq);CHECK(read_calls==1);CHECK(write_calls==1);
 reset();fail_read=-EIO;fail_from_call=2;bq2589x_force_dpdm_done(&bq);CHECK(read_calls==4);CHECK(write_calls==1);
 reset();bq2589x_ico_workfunc(&bq.ico_work.work);int previous=read_calls;
 fail_read=-EIO;bq2589x_ico_workfunc(&bq.ico_work.work);CHECK(read_calls-previous==3);
 reset();fail_read=-EIO;bq.force_exit_flag=false;bq2589x_force_workfunc(&bq.force_work.work);
 CHECK(!bq.force_exit_flag);CHECK(bq.old_type==0);CHECK(write_calls==0);
 reset();fail_read=-EIO;bq2589x_monitor_workfunc(&bq.monitor_work.work);
 CHECK(bq.vbus_volt==7777);CHECK(bq.vbat_volt==4444);
 int hiz_writes=0;for(int i=0;i<event_count;i++)if(events[i].kind==2&&events[i].a==BQ2589X_REG_00)hiz_writes++;
 CHECK(hiz_writes==0);
 reset();fail_read=-EIO;fail_reg=BQ2589X_REG_11;registers[BQ2589X_REG_0D]=0x7f;
 bq2589x_monitor_workfunc(&bq.monitor_work.work);CHECK(bq.vbus_volt==7777);
 hiz_writes=0;for(int i=0;i<event_count;i++)if(events[i].kind==2&&events[i].a==BQ2589X_REG_00)hiz_writes++;
 CHECK(hiz_writes==0);
 reset();fail_read=-EIO;fail_reg=BQ2589X_REG_11;bq2589x_adjust_absolute_vindpm(&bq);
 int voltage_writes=0;for(int i=0;i<event_count;i++)if(events[i].kind==2&&events[i].a==BQ2589X_REG_0D)voltage_writes++;
 CHECK(voltage_writes==0);
 for(int t=0;t<8;t++) {
  reset();registers[BQ2589X_REG_0B]=t<<BQ2589X_VBUS_STAT_SHIFT;
  bq2589x_force_workfunc_reference(&bq.force_work.work);saved_count=event_count;memcpy(saved_events,events,sizeof(events));
  reset();registers[BQ2589X_REG_0B]=t<<BQ2589X_VBUS_STAT_SHIFT;bq2589x_force_workfunc(&bq.force_work.work);
  CHECK(!bq.force_exit_flag);CHECK(event_count==saved_count);
  CHECK(!memcmp(events,saved_events,(size_t)event_count*sizeof(events[0])));
 }
 // All normal work sequences use identical register operations and scheduling.
 int types[]={BQ2589X_VBUS_USB_SDP,BQ2589X_VBUS_USB_DCP,BQ2589X_VBUS_MAXC};
 for(int t=0;t<3;t++)for(int high=0;high<2;high++)for(int active=0;active<2;active++) {
  reset();bq.curr_flag=active;bq.vbus_type=types[t];registers[0x11]=high?64:25;registers[0x0e]=17;
  bq2589x_monitor_workfunc_reference(&bq.monitor_work.work);saved_count=event_count;memcpy(saved_events,events,sizeof(events));
  reset();bq.curr_flag=active;bq.vbus_type=types[t];registers[0x11]=high?64:25;registers[0x0e]=17;
  bq2589x_monitor_workfunc(&bq.monitor_work.work);
  CHECK(event_count==saved_count);CHECK(!memcmp(events,saved_events,(size_t)event_count*sizeof(events[0])));
 }
 for(int t=0;t<3;t++) {
  reset();bq.vbus_type=types[t];registers[0x11]=25;
  bq2589x_adjust_absolute_vindpm_reference(&bq);saved_count=event_count;memcpy(saved_events,events,sizeof(events));
  reset();bq.vbus_type=types[t];registers[0x11]=25;bq2589x_adjust_absolute_vindpm(&bq);
  CHECK(event_count==saved_count);CHECK(!memcmp(events,saved_events,(size_t)event_count*sizeof(events[0])));
 }
 printf("BQ_READ_ERROR_HOST_TESTS=PASS; assertions=%d; retries, output integrity, IIO errors and unchanged success traces\n",assertions);
 return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='m30-bq-reads-') as tmp:
        root=Path(tmp);c=root/'test.c';exe=root/'test'
        c.write_text(constants+'\n'+(ROOT/'References/native_bq_read_stubs.h').read_text()+'\n'+enum+'\n'+definitions+'\n'+body+'\n'+reference+'\n'+tests)
        subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function',
                        '-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True,timeout=20)


if __name__=='__main__':main()
