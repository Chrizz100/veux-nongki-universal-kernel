#!/usr/bin/env python3
"""VEUX R16: immutable R15 diagnostic continuation. No new kernel patch."""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path

SCHEMA = 'VEUX_STOCK_R16_HRTIMER_DIAGNOSTIC_NOFLASH'
EXPECTED_R15_SHA = '2840878243c67d6a0724b1cc24a4f435d69ea83a1bee38f7ec2103bedfdfd331'
EXPECTED_STOCK_HRTIMER_SHA = '7e475d274a02aa790ab2375a138cb78f92c3e8fc64686d05e841871322a3e427'
PAIR_HRTIMER_GIT_SHA = '02f1ad059f58afceb8e0484001da28e0a5393b5e'
DONOR_HRTIMER_GIT_SHA = '8e3c9228aec97289fb7b937e034d7f7d2a56189f'
RC_PATTERN = re.compile(r'^\s*(?:[^:\n]*:)?(?:\d+:\d+:)?\s*(?:fatal\s+)?error:\s*|\bmake(?:\[\d+\])?: \*\*\*|^LLVM ERROR:', re.I)

def sha(b): return hashlib.sha256(b).hexdigest()

def verify_main(root):
    root = Path(root)
    if not root.is_dir() or root.is_symlink():
        raise ValueError('R16_INVALID_ROOT')
    mf = root / 'MANIFEST_SHA256.json'
    obj = json.loads(mf.read_text())
    if obj.get('schema') != SCHEMA or obj.get('parent_r15_sha256') != EXPECTED_R15_SHA:
        raise ValueError('R16_SCHEMA_OR_PARENT_PIN')
    if any(obj.get(k) is not False for k in ('flash_allowed', 'new_kernel_build', 'source_patch', 'boot_verified', 'abi_verified')):
        raise ValueError('R16_UNSAFE_CLAIMS')
    fs = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if any(p.is_symlink() for p in root.rglob('*')) or fs != set(obj['files']) | {'MANIFEST_SHA256.json'}:
        raise ValueError('R16_UNEXPECTED_PATHS')
    for rel, digest in obj['files'].items():
        if sha((root / rel).read_bytes()) != digest: raise ValueError('R16_CONTENT_SHA:'+rel)
    if sha((root / 'reference/R15_MAIN_ORIGINAL.zip').read_bytes()) != EXPECTED_R15_SHA:
        raise ValueError('R16_R15_PARENT_CHANGED')
    if sha((root / 'reference/stock_hrtimer.h').read_bytes()) != EXPECTED_STOCK_HRTIMER_SHA:
        raise ValueError('R16_STOCK_HEADER_CHANGED')
    with zipfile.ZipFile(root / 'reference/R15_MAIN_ORIGINAL.zip') as z:
        if z.testzip() or json.loads(z.read('MANIFEST_SHA256.json'))['schema']!='VEUX_R15_AUTHENTIC_WALT_RUNTIME_PROVIDERS_NOFLASH':
            raise ValueError('R16_R15_CORRUPTED')
    return obj

def collect_errors(log, limit=70):
    errors = []
    for line in log.splitlines():
        if RC_PATTERN.search(line):
            errors.append(line.strip()[:450])
    return errors[:limit]

def summarize(main, reports, trial, pair, output):
    verify_main(main)
    reports, trial, pair, output = map(Path, (reports,trial,pair,output))
    log = reports / 'R15_HRTIMER_BUILD.log'
    rc_file = reports / 'R15_HRTIMER_RC.txt'
    rc = None
    if rc_file.is_file():
        try:rc = int(rc_file.read_text().strip())
        except ValueError:pass
    raw = log.read_text(errors='replace') if log.is_file() else ''
    original = (main / 'reference/stock_hrtimer.h').read_text()
    donor_header = (trial / 'include/linux/hrtimer.h').read_text() if (trial / 'include/linux/hrtimer.h').is_file() else ''
    trial_source = (trial / 'kernel/time/hrtimer.c').read_text() if (trial / 'kernel/time/hrtimer.c').is_file() else ''
    pinned_source = (pair / 'kernel/time/hrtimer.c').read_text() if (pair / 'kernel/time/hrtimer.c').is_file() else ''
    facts = {
      'stock_pinned_state_defined': '#define HRTIMER_STATE_PINNED' in original,
      'trial_pinned_state_defined': '#define HRTIMER_STATE_PINNED' in donor_header,
      'trial_source_uses_pinned_state': 'HRTIMER_STATE_PINNED' in trial_source,
      'upstream_source_uses_pinned_state': 'HRTIMER_STATE_PINNED' in pinned_source,
      'pinned_state_source_blobs': {'pair':PAIR_HRTIMER_GIT_SHA,'donor':DONOR_HRTIMER_GIT_SHA},
    }
    out = {
      'schema':SCHEMA,'r15_compiler_rc':rc,'r15_log_present':bool(raw),
      'r15_compiler_error_lines':collect_errors(raw),'hrtimer_source_differences':facts,
      'confirmed_error_from_log':bool(collect_errors(raw)),
      'note':'Pinned-state structural mismatch is a source finding; do not equate it with the actual compiler error without log evidence.',
      'preserve_original_donor':True,'new_kernel_build':False,'source_patch':False,
      'abi_verified':False,'boot_verified':False,'flash_allowed':False,
    }
    output.mkdir(parents=True,exist_ok=True)
    (output/'R16_HRTIMER_DIAGNOSTIC.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    prose = [f'R16 HRTIMER DIAG: build exit code={rc}; log present={bool(raw)};',
             f'Stock HRTIMER_STATE_PINNED={facts["stock_pinned_state_defined"]}; donor header has bit={facts["trial_pinned_state_defined"]};',
             'Verified compile lines (from R15_HRTIMER_BUILD.log):']
    prose += [f'  {line}' for line in out['r15_compiler_error_lines']] or ['  NO ACTUAL COMPILER ERROR LINES AVAILABLE']
    prose += ['This is a diagnostic, NOT a code fix or a safe-to-flash kernel.']
    (output/'R16_HRTIMER_DIAGNOSTIC_DE.txt').write_text('\n'.join(prose)+'\n')
    print('\n'.join(prose))
    return out

def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode',choices=('verify','summarize'))
    for k in ('main','reports','trial','pair','output'):p.add_argument('--'+k)
    a=p.parse_args()
    if a.mode=='verify': print(json.dumps({'schema':verify_main(a.main)['schema'],'NOFLASH':True}))
    else: summarize(Path(a.main),a.reports,a.trial,a.pair,a.output)
if __name__=='__main__':main()
