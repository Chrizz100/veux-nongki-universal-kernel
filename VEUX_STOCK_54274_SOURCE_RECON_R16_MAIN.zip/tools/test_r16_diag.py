import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import r16_diag as m

ROOT=Path(__file__).resolve().parent.parent

class R16Tests(unittest.TestCase):
    def test_01_genuine_parent(self): self.assertEqual(m.verify_main(ROOT)['schema'],m.SCHEMA)
    def test_02_not_flashable(self):
        d=m.verify_main(ROOT)
        for x in ('flash_allowed','source_patch','boot_verified','abi_verified','new_kernel_build'): self.assertIs(d[x],False)
    def test_03_r15_blob(self):self.assertEqual(m.sha((ROOT/'reference/R15_MAIN_ORIGINAL.zip').read_bytes()),m.EXPECTED_R15_SHA)
    def test_04_stock_blob(self):self.assertEqual(m.sha((ROOT/'reference/stock_hrtimer.h').read_bytes()),m.EXPECTED_STOCK_HRTIMER_SHA)
    def test_05_parent_archive(self):
        import zipfile
        with zipfile.ZipFile(ROOT/'reference/R15_MAIN_ORIGINAL.zip') as z:self.assertEqual(json.loads(z.read('MANIFEST_SHA256.json'))['schema'],'VEUX_R15_AUTHENTIC_WALT_RUNTIME_PROVIDERS_NOFLASH')
    def test_06_error_parser(self):self.assertIn('a.c:10:3: error: bad',m.collect_errors('note\na.c:10:3: error: bad\n'))
    def test_07_fatal_parser(self):self.assertEqual(len(m.collect_errors('fatal error: missing\n')),1)
    def test_08_make_parser(self):self.assertEqual(len(m.collect_errors('make[1]: *** [target] Error 2\n')),1)
    def test_09_ordinary_warning_not_failure(self):self.assertEqual(m.collect_errors('warning: cosmetic\n'),[])
    def test_10_empty_parser(self):self.assertEqual(m.collect_errors(''),[])
    def test_11_outputs_never_approve(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);(t/'reports').mkdir();(t/'trial/include/linux').mkdir(parents=True);(t/'trial/kernel/time').mkdir(parents=True);(t/'pair/kernel/time').mkdir(parents=True)
            (t/'reports/R15_HRTIMER_RC.txt').write_text('2\n')
            (t/'reports/R15_HRTIMER_BUILD.log').write_text('a.c:32:4: error: HRTIMER_STATE_PINNED undeclared\n')
            (t/'trial/include/linux/hrtimer.h').write_text('#define HRTIMER_STATE_ENQUEUED 1\n')
            (t/'trial/kernel/time/hrtimer.c').write_text('HRTIMER_STATE_PINNED')
            (t/'pair/kernel/time/hrtimer.c').write_text('HRTIMER_STATE_PINNED')
            r=m.summarize(ROOT,t/'reports',t/'trial',t/'pair',t/'out')
            self.assertEqual(r['r15_compiler_rc'],2);self.assertFalse(r['flash_allowed']);self.assertFalse(r['abi_verified'])
            self.assertTrue((t/'out/R16_HRTIMER_DIAGNOSTIC_DE.txt').is_file())
    def test_12_missing_log_never_claims_proof(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);(t/'reports').mkdir()
            r=m.summarize(ROOT,t/'reports',t/'trial',t/'pair',t/'out')
            self.assertFalse(r['confirmed_error_from_log']);self.assertFalse(r['flash_allowed'])
    def test_13_digest_tamper_rejected(self):
        with patch.object(m,'EXPECTED_R15_SHA','0'*64):
            with self.assertRaises(ValueError):m.verify_main(ROOT)
    def test_14_manifest_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            import shutil
            t=Path(t);shutil.copytree(ROOT,t/'x')
            p=t/'x/MANIFEST_SHA256.json';d=json.loads(p.read_text());d['flash_allowed']=True;p.write_text(json.dumps(d))
            with self.assertRaises(ValueError):m.verify_main(t/'x')
    def test_15_source_bit_is_not_proof(self):
        with tempfile.TemporaryDirectory() as t:
            t=Path(t);(t/'reports').mkdir()
            r=m.summarize(ROOT,t/'reports',t/'trial',t/'pair',t/'out')
            self.assertIn('not equate',r['note']);self.assertIs(r['confirmed_error_from_log'],False)

if __name__=='__main__': unittest.main()
