#!/system/bin/sh
# VEUX M49. Liest Eigenschaften, sysfs-Verknüpfungen und nur den aktiven Boot-Slot.
# Ohne Argument mit den vorhandenen Rechten ausführen. --root bittet um Root-Leserechte.
if [ "${1-}" = "--root" ] && [ "$(id -u)" != 0 ]; then
    command -v su >/dev/null 2>&1 || { echo 'su fehlt. Den Check ohne --root ausführen.' >&2; exit 1; }
    exec su -c '/system/bin/sh -s' < "$0"
fi
command -v getprop >/dev/null 2>&1 || { echo 'Dieser Check benötigt das laufende Android.' >&2; exit 1; }
export LC_ALL=C
prop() { getprop "$1" 2>/dev/null; }
value() {
    case "$2" in ''|*[!A-Za-z0-9._+-]*) printf '%s=unbekannt\n' "$1";; *) printf '%s=%s\n' "$1" "$2";; esac
}
# Nur die zwei benötigten Parameter auslesen. Keine komplette Kernel-Kommandozeile ausgeben.
arg_in() {
    case "$1" in
        cmdline) tr ' ' '\n' < /proc/cmdline | awk -v k="$2=" 'index($0,k)==1 {print substr($0,length(k)+1); exit}' ;;
        bootconfig) awk -v k="$2" '$1==k && $2=="=" { v=$3; gsub(/^"|"$/,"",v); print v; exit }' /proc/bootconfig ;;
    esac
}
driver_at() {
    found=
    for dev in /sys/bus/platform/devices/*; do
        [ -L "$dev/of_node" ] || continue
        node=$(readlink -f "$dev/of_node") || continue
        address=${node##*@}
        case "$address" in "$1"|"0$1") ;; *) continue;; esac
        [ -L "$dev/driver" ] || continue
        target=$(readlink -f "$dev/driver") || continue
        label=${target##*/}
        if [ -n "$found" ] && [ "$found" != "$label" ]; then printf 'mehrdeutig'; return; fi
        found=$label
    done
    printf '%s' "$found"
}
by_name() {
    for path in "/dev/block/by-name/$1" "/dev/block/bootdevice/by-name/$1" /dev/block/platform/*/by-name/"$1" /dev/block/platform/*/*/by-name/"$1"; do
        if [ -b "$path" ]; then readlink -f "$path"; return; fi
    done
}
resolve_param() {
    case "$1" in
        PARTUUID=*)
            uuid=${1#PARTUUID=}
            case "$uuid" in ''|*[!a-fA-F0-9-]*) return;; esac
            uuid=$(printf '%s' "$uuid" | tr 'A-F' 'a-f')
            for link in "/dev/block/by-partuuid/$uuid" "/dev/disk/by-partuuid/$uuid"; do
                if [ -b "$link" ]; then readlink -f "$link"; return; fi
            done
            for entry in /sys/class/block/*/uevent; do
                [ -r "$entry" ] || continue
                match=$(sed -n 's/^PARTUUID=//p' "$entry" | tr 'A-F' 'a-f')
                [ "$match" = "$uuid" ] || continue
                entry=${entry%/uevent}
                readlink -f "/dev/block/${entry##*/}"; return
            done ;;
        /dev/*)
            if [ -b "$1" ]; then readlink -f "$1"; return; fi
            leaf=${1#/dev/}
            case "$leaf" in ''|*/*|*[!a-zA-Z0-9_-]*) return;; esac
            [ -b "/dev/block/$leaf" ] && readlink -f "/dev/block/$leaf" ;;
        *:*)
            case "$1" in *[!0-9:]*|:*|*:|*:*:*) return;; esac
            [ -L "/sys/dev/block/$1" ] || return
            path=$(readlink -f "/sys/dev/block/$1") || return
            readlink -f "/dev/block/${path##*/}" ;;
    esac
}
printf 'format=M49\n'
value uid "$(id -u)"
value geraet "$(prop ro.product.device)"
value build "$(prop ro.build.version.incremental)"
value kernel "$(uname -r)"
slot=$(prop ro.boot.slot_suffix)
value slot "$slot"
value verifiedbootstate "$(prop ro.boot.verifiedbootstate)"
value bootloaderstatus "$(prop ro.boot.vbmeta.device_state)"
value veritymode "$(prop ro.boot.veritymode)"
value ufs_controller "$(driver_at 4804000 2>/dev/null)"
value ufs_phy "$(driver_at 4807000 2>/dev/null)"
for key in invalidate_on_error device; do
    a=$(arg_in cmdline "androidboot.vbmeta.$key" 2>/dev/null)
    b=$(arg_in bootconfig "androidboot.vbmeta.$key" 2>/dev/null)
    c=$(prop "ro.boot.vbmeta.$key")
    conflicting=no
    for x in "$a" "$b" "$c"; do
        [ -n "$x" ] || continue
        for y in "$a" "$b" "$c"; do [ -z "$y" ] || [ "$x" = "$y" ] || conflicting=yes; done
    done
    if [ -n "$a" ]; then raw=$a; source=cmdline
    elif [ -n "$b" ]; then raw=$b; source=bootconfig
    elif [ -n "$c" ]; then raw=$c; source=property
    else raw=; source=unbekannt; fi
    value "${key}_quelle" "$source"
    value "${key}_widerspruch" "$conflicting"
    if [ "$key" = invalidate_on_error ]; then
        case "$raw" in yes|no) value invalidierung "$raw";; *) value invalidierung '';; esac
    else
        case "$raw" in PARTUUID=*) typ=PARTUUID;; /dev/*) typ=devnode;; *:*) typ=devnum;; '') typ=unbekannt;; *) typ=andere;; esac
        value vbmeta_parametertyp "$typ"
        label=
        target=$(resolve_param "$raw" 2>/dev/null)
        if [ "$conflicting" = no ] && [ -n "$target" ] && [ -b "$target" ]; then
            for name in vbmeta_a vbmeta_b vbmeta vbmeta_system_a vbmeta_system_b vbmeta_vendor_a vbmeta_vendor_b boot_a boot_b; do
                alias=$(by_name "$name" 2>/dev/null)
                [ "$target" = "$alias" ] && { label=$name; break; }
            done
        fi
        value vbmeta_partitionsname "$label"
    fi
done
boot_hash=
case "$slot" in
    _a|_b) boot=$(by_name "boot$slot" 2>/dev/null)
        if [ -n "$boot" ] && [ -b "$boot" ] && [ -r "$boot" ]; then
            hashed=$(sha256sum "$boot" 2>/dev/null) && boot_hash=${hashed%% *}
        fi;;
esac
value boot_sha256 "$boot_hash"
printf 'ende=M49\n'
