# VEUX M49 – Geräteabgleich für den grünen M48-R2-Kernel

Der Quelllauf 44919059919 hat den Kernel 5.4.274-qgki-g82179e362f33, boot.img und die Prüf-AK3 gebaut. M49 verwendet genau die drei gespeicherten Archive anhand ihrer GitHub-IDs und SHA-256-Werte. Ein weiterer Kernelbau ist dafür entbehrlich.

## Auf dem laufenden POCO

VEUX_M49_Geraetecheck.sh unter Download ablegen. In Termux ausführen:

    sh ~/storage/downloads/VEUX_M49_Geraetecheck.sh --root | tee ~/storage/downloads/M49-Geraetestand.txt

Der vorhandene Root-Zugang ermöglicht unter anderem das Lesen der aktiven Boot-Partition. Ohne Root kann das Skript ohne das Argument --root gestartet werden. Fehlende bzw. gesperrte Daten werden als unbekannt ausgegeben. Eine vollständige Datei beginnt mit format=M49 und endet mit ende=M49. Es wird nur der aktive Boot-Slot gehasht. Das Skript liest Gerätebaum-/Treiberbindungen und gleicht die beiden AVB-Parameter aus Kernel-Kommandozeile, Bootconfig und Android-Eigenschaften ab. Die Quelle des beobachteten Werts wird angegeben. Die Ausgabe enthält weder die vollständige Kernel-Kommandozeile noch Partitions-UUIDs oder Geräteseriennummern. Termux speichert den kurzen Textbericht. Keine Partition wird beschrieben.

Für die Auswertung genügt es, den Bericht im Chat zu teilen. Der vor dem Umbau gesicherte boot_a-Hash und der Xiaomi-Stock-Hash werden im Auswerter getrennt geführt. Ein fehlender oder nur als Android-Eigenschaft sichtbarer Verity-Zielparameter bleibt offen.

## Optional auf GitHub reproduzieren

VEUX_M49_MAIN.zip im Repo-Stamm und VEUX_M49_ABGLEICH_NOFLASH.yml in .github/workflows/ auf main ablegen. Der manuelle Workflow prüft den bestehenden Bau. Für einen freiwilligen Abgleich auf GitHub kann der Bericht als M49-Geraetestand.txt im Repo-Stamm abgelegt werden. Ohne Bericht liefert der Workflow nur die statische Auswertung. Wer die Geräteangaben privat halten möchte, kann sie direkt im Chat teilen.

Der Auswerter kontrolliert alle drei Archivprüfsummen, OEM-CRCs, Modulimporte, die eingebettete Konfiguration in Image und vmlinux, den Kernel in boot.img und AK3, die Stock-Ramdisk und den durch den Xiaomi-Deskriptor vorgegebenen Boot-Hash. Die simulierten Slots werden aus dem authentifizierten M48-Bericht übernommen. Ein Gerätebericht erteilt keine Flash-Freigabe. Boot des Kandidaten, Wirkung der AVB-Kette am Gerät und ein bestätigter Wiederherstellungsweg per PC sind separate Nachweise.
