"""Verify the published M48 R2 bytes and compare an optional read-only M49 device report."""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import zipfile
import zlib

RUN = 44919059919
ARCHIVES = {
    "evidence": "02ac22e34e15617c8cfabe5a64bcd694fbe16bc84821bc47c37d24985843e197",
    "pair": "6da469efe6ffd86b9516d617b0ae46c0831f406f43b7ef754350b449ca2c439e",
    "checkpoint": "0f9bfb8a56ab0e12e7149133823520350658b7b76fccd32b59747fb4d4582602",
}
STOCK = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
BACKUP = "c6ed9ad7a90adf9d670a48da9b9edd9a2276e51598ffc7e2e4a6676434138ff6"
RELEASE = "5.4.274-qgki-g82179e362f33"
PREFIX = "_temp/m48-result/evidence/"


def need(ok, reason):
    if not ok:
        raise ValueError(reason)


def hash_bytes(data):
    return hashlib.sha256(data).hexdigest()


def hash_file(path):
    with path.open("rb") as stream:
        digest = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1 << 20), b""):
            digest.update(chunk)
        return digest.hexdigest()


def align(size):
    return (size + 4095) // 4096 * 4096


def check_product(z, name, config, expected):
    """Read the complete binary and check its embedded IKCONFIG without retaining vmlinux."""
    signature = b"IKCFG_ST\x1f\x8b"
    carry = b""
    decoded = 0
    digest = hashlib.sha256()
    with z.open(name) as stream:
        for block in iter(lambda: stream.read(4 << 20), b""):
            digest.update(block)
            data = carry + block
            # Keep enough overlap for an entire config plus marker and gzip overhead.
            overlap = len(config) + 256
            cut = max(0, len(data) - overlap)
            decoded += scan(data, cut, signature, config)
            carry = data[cut:]
    decoded += scan(carry, len(carry), signature, config)
    need(decoded == 1 and digest.hexdigest() == expected, "IKCONFIG/product: " + name)


def scan(data, stop, marker, config):
    pos = data.find(marker)
    valid = 0
    while 0 <= pos < stop:
        decoder = zlib.decompressobj(31)
        payload = decoder.decompress(data[pos+8:pos+len(config)+256], len(config)+1)
        if decoder.eof and payload == config and decoder.unused_data.startswith(b"IKCFG_ED"):
            valid += 1
        pos = data.find(marker, pos+1)
    return valid


def csv_rows(archive, name):
    return list(csv.DictReader(io.StringIO(archive.read(PREFIX + name).decode())))


def check_files(folder):
    for name, digest in ARCHIVES.items():
        need(hash_file(folder / (name + ".zip")) == digest, "Archive SHA-256: " + name)
    with (zipfile.ZipFile(folder / "evidence.zip") as ev,
          zipfile.ZipFile(folder / "checkpoint.zip") as cp,
          zipfile.ZipFile(folder / "pair.zip") as pack):
        proof_raw = ev.read(PREFIX + "M48_BUILD.json")
        need(proof_raw == cp.read("M48_BUILD.json"), "Different kernel reports")
        proof = json.loads(proof_raw)
        report = json.loads(pack.read("M48_RESULT.json"))
        meta = report["pair"]
        cfg = ev.read(PREFIX + "kernel.config")
        need(proof["release"] == report["kernel_release"] == RELEASE, "Release")
        need(proof["config_delta"] == {"CONFIG_DM_VERITY_AVB": [None, "y"]}
             and b"CONFIG_DM_VERITY_AVB=y" in cfg.splitlines(), "Verity config")
        embedded = proof["embedded_config_proof"]
        need(hash_bytes(cfg) == embedded["build_config_sha256"], "config SHA")
        for item in ("Image", "vmlinux"):
            check_product(ev, PREFIX + item, cfg, embedded[item.lower()+"_sha256"])
        syms = ev.read(PREFIX+"Module.symvers")
        need(hash_bytes(syms) == embedded["full_symvers_sha256"], "symvers digest")
        exports = {r[1]:r[0] for line in syms.decode().splitlines() if len(r:=line.split()) >= 2}
        symbols = csv_rows(ev, "M48_QGKI_SYMBOLS.csv")
        modules = csv_rows(ev, "M48_QGKI_MODULES.csv")
        need(len(symbols) == len({r["symbol"] for r in symbols}) == 1423 and all(
            r["status"] == "MATCH" and exports.get(r["symbol"]) == r["candidate_crc"] == r["oem_crc"]
            for r in symbols), "Vendor CRC")
        need(len(modules) == len({r["module"] for r in modules}) == 37 and all(
            r["imports"] == r["match"] and int(r["missing"]) == int(r["crc_mismatch"]) == 0 and r["fully_compatible"]=="True"
            for r in modules) and sum(int(r["imports"]) for r in modules) == 3148, "Vendor imports")
        stock = cp.read("m48-stock.img")
        boot = pack.read("VEUX_M48_NOFLASH_boot.img")
        need(hash_bytes(stock) == STOCK and len(boot) == len(stock) == 134217728, "partition size/stock")
        need(boot[:8] == stock[:8] == b"ANDROID!" and struct.unpack_from("<I",boot,40)[0] == 3, "header v3")
        ksize, rsize = struct.unpack_from("<II",boot,8)
        ss, sr = struct.unpack_from("<II",stock,8)
        start = 4096 + align(ksize)
        stock_start = 4096 + align(ss)
        rd = boot[start:start+rsize]
        need(rd == stock[stock_start:stock_start+sr] and hash_bytes(rd) == meta["stock_ramdisk_sha256"], "ramdisk")
        kernel = boot[4096:4096+ksize]
        ak3 = pack.read("VEUX_M48_NOFLASH_AK3.zip")
        with zipfile.ZipFile(io.BytesIO(ak3)) as ak:
            need(ak.testzip() is None and ak.namelist().count("Image")==1 and ak.read("Image")==kernel, "AK3 payload")
        need(kernel == cp.read("Image") and hash_bytes(kernel)==embedded["image_sha256"]==meta["kernel_sha256"], "Image mismatch")
        need(hash_bytes(boot)==meta["boot_sha256"] and hash_bytes(ak3)==meta["ak3_sha256"], "Published pair")
        with zipfile.ZipFile(io.BytesIO(cp.read("VEUX_M48_R2_MAIN.zip"))) as main:
            with zipfile.ZipFile(io.BytesIO(main.read("m45-base.zip"))) as base:
                vbmeta = base.read("stock-vbmeta.bin")
        # AVB hash descriptors. Match the exact boot payload extent and salt declared by Xiaomi.
        need(vbmeta[:4]==b"AVB0", "OEM vbmeta header")
        auth_size, aux_size = struct.unpack_from(">QQ",vbmeta,12)
        offset, total = struct.unpack_from(">QQ",vbmeta,96)
        index = 256 + auth_size + offset
        limit = index + total
        need(limit <= 256+auth_size+aux_size <= len(vbmeta), "OEM descriptors outside vbmeta")
        matches = []
        while index < limit:
            tag, body_size = struct.unpack_from(">QQ",vbmeta,index)
            end = index + 16+body_size
            need(end<=limit, "Invalid AVB descriptor size")
            if tag == 2:
                size = struct.unpack_from(">Q",vbmeta,index+16)[0]
                algo = vbmeta[index+24:index+56].split(b"\0",1)[0]
                pn, sn, dn = struct.unpack_from(">III",vbmeta,index+56)
                ptr = index+132
                need(ptr+pn+sn+dn<=end, "Invalid AVB hash descriptor")
                if vbmeta[ptr:ptr+pn]==b"boot":
                    need(algo==b"sha256" and dn==32 and 0<size<=len(stock), "Unsupported stock digest")
                    salt=vbmeta[ptr+pn:ptr+pn+sn]
                    declared=vbmeta[ptr+pn+sn:ptr+pn+sn+dn].hex()
                    actual=hash_bytes(salt+boot[:size])
                    need(hash_bytes(salt+stock[:size]) == declared == meta["oem_expected_digest"] and
                         actual == meta["candidate_digest_for_oem_descriptor"],"Stock descriptor mismatch")
                    matches.append(actual==declared)
            index=end
        need(matches == [False] and meta["oem_signed_boot_descriptor_matches"] is False,"OEM digest finding changed")
        need(meta["simulated_stock_slots"] == ["_a","_b"] and meta["static_boot_pass"] is True
             and meta["rejected_inputs"]==3 and report["device_pass"] is False
             and report["flash_allowed"] is False, "M48 device/slot report")
        return {"m48_run":RUN, "release":RELEASE,"abi_symbols":len(symbols),"vendor_modules":len(modules),
                "module_imports":3148,"device_tree":sorted(proof["m44_identical_dtbs"]),
                "config_image_vmlinux_equal":True, "kernel_sha256":hash_bytes(kernel),"boot_sha256":hash_bytes(boot),
                "boot_bytes":len(boot),"ak3_sha256":hash_bytes(ak3),"stock_ramdisk_equal":True,
                "static_boot_pass":True, "simulated_slots":meta["simulated_stock_slots"], "oem_digest_matches":False,
                "device_pass":False,"pc_recovery_tested":False,"flash_allowed":False}


def compare_device(text, candidate):
    fields = {}
    keys = set("format uid geraet build kernel slot verifiedbootstate bootloaderstatus veritymode ufs_controller ufs_phy invalidate_on_error_quelle invalidate_on_error_widerspruch invalidierung device_quelle device_widerspruch vbmeta_parametertyp vbmeta_partitionsname boot_sha256 ende".split())
    for line in text.splitlines():
        k, sep, v = line.partition("=")
        need(sep and k in keys and k not in fields and re.fullmatch(r"[\w.+-]{1,128}", v, flags=re.ASCII), "Invalid device report")
        fields[k] = v
    need(set(fields)==keys and fields["format"]==fields["ende"]=="M49", "Incomplete device report")
    checksum = fields["boot_sha256"]
    need(checksum=="unbekannt" or re.fullmatch("[a-f0-9]{64}",checksum), "Invalid slot hash")
    identification = {candidate:"M48 R2",STOCK:"Xiaomi-Stock",BACKUP:"gesichertes boot_a","unbekannt":"unbekannt"}.get(checksum,"anderes Abbild")
    return {"angaben_vom_laufenden_system":fields,"aktives_boot_abbild":identification,
            "geraet_und_version_passend":fields["geraet"]=="veux" and fields["kernel"]==RELEASE,
            "hinweis":"Die Kennung allein identifiziert den laufenden Kernel nicht. Eine Treiberbindung oder ein Partitionsname gilt nur für das untersuchte System.",
            "device_pass":False,"flash_allowed":False}


if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--archive",type=Path,required=True)
    cli.add_argument("--geraet",type=Path)
    cli.add_argument("--ausgabe",type=Path,required=True)
    args=cli.parse_args()
    result=check_files(args.archive)
    if args.geraet:
        need(args.geraet.stat().st_size <= 8192,"Report too large")
        result["geraeteabgleich"]=compare_device(args.geraet.read_text(),result["boot_sha256"])
    args.ausgabe.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n")
    print(json.dumps(result,indent=2,ensure_ascii=False))
