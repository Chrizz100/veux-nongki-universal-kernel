# VEUX STOCK 5.4.274 — R20 R6 only source compatibility / NOFLASH

This is the source-coherent R20-R5 experiment with **one additional original donor macro** in isolated `kernel/sched/sched.h`:

```c
#define SCHED_DL_FLAGS (SCHED_FLAG_RECLAIM | SCHED_FLAG_DL_OVERRUN | SCHED_FLAG_SUGOV)
```

The Qualcomm SM8350 M11 header at git commit `01cb3a8824b7b4caf3e3540274e71abba5ade538` lacks the macro; the source-pinned SM6375 donor header at `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632` contains it exactly. This fixes the three *R20-R5 compiler errors* at `deadline.c` lines 2654/2667/2743 without rewriting the callbacks, task structures, WALT or functional scheduler code. This is a **hypothesis confirmed by original source evidence, not a compiler success claim**.

- Reuse the previously hash-pinned R19 and R20-R5 archives, untouched.
- Run original R19 foundation and twelve genuine R17 objects, then stage R20 R6 only in disposable trial.
- Compile eight genuine affected objects, then twelve R17 regression objects, then attempt full `Image dtbs` link and OEM ABI **only if all objects passed**.
- No kernel images, boot files, root modules, or installable ZIP artifacts are emitted. **NOFLASH**.
- All compilers and ABI checks require a new GitHub Actions run; offline static checks do not replace them.

R20-R5 original GitHub logs and MAIN are included as separate byte-identical references for continuity. No earlier successful sources are overwritten in `main`.
