VEUX M30 – BQ-I2C-Lesefehler und ihre Aufrufer – NOFLASH
Basis: erfolgreicher M29-R2-Lauf 43700944668, Commit 79d311b97f5809a0d03ee7b99fc5c55d67867842.

UPLOAD AM SMARTPHONE
1. VEUX_M30_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   Die MAIN nicht entpacken. Ein angehaengtes (1) im Namen entfernen.
2. VEUX_M30_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach den Workflow manuell starten.
   Die benoetigten historischen Pakete werden aus festen Commit-Referenzen geladen.

BESTAETIGTER M29-R2-STAND
Alle 32 Artefakte heruntergeladen und geprueft: 715 Dateien, 657 Textdateien,
148 JSON-Dateien, 34.360.509 dekodierte Textbytes. Archiv-SHA-256 und ZIP-CRC passen.
Finaler Kernel unabhaengig geprueft: BQ-Startkorrekturen, WT, SC8551, RPM,
eingebettete Konfiguration/Image/vmlinux, 1.423 passende QGKI-Import-CRCs,
37 passende Module und unveraenderte komplette Exporttabelle. Boot.img und AK3
aus gepinnten Referenzen byteidentisch rekonstruiert. Die Git-Checkout-Pruefung
einschliesslich des 1.763-Byte-BQ-Headers ist im aktuellen CI bestanden.
Bericht: Reports/RUN43700944668_32_ARTEFAKTE.zip.
Tiefe Binaer-/ABI-/Boot-Pruefungen beziehen sich auf den finalen M29-R2.

M30-REPARATURGRUPPE
Der BQ-Treiber meldet nach drei gescheiterten I2C-Leseversuchen bisher Erfolg
und behandelt den negativen Fehlercode als Registerwert. M30 korrigiert diesen
Fehler gemeinsam mit den Aufrufern: signed Fehlerweitergabe, ADC-/Ladestatus,
DPDM-Abbruch bei Fehlern, ICO-Ergebnispruefung und IIO-Fehler statt Messwerten.
Monitorwerte werden nur nach erfolgreicher Messung aktualisiert; abhaengige
VBUS-Aktionen verwenden einen frischen erfolgreichen Messwert.
Genau zwoelf Funktionen sind erweitert; Liste und Diff liegen in References.
Alle anderen Treiberbytes bleiben zum bestaetigten M29-Stand identisch.
Die M29-Probe-Funktion mit Speicher-/IIO-Registrierungspruefung ist byteidentisch
erhalten. Ladestrom-/Spannungsvorgaben und die IIO-Schreibfunktion bleiben gleich.
Es wird keine zusaetzliche 5-V-VINDPM-Regel eingefuehrt.

BUILD UND PRUEFUNGEN
M30 fuehrt die BQ-Schicht auf dem weiterhin authentifizierten M28-R2-Buildkern
fort. Saemtliche Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates
bleiben aktiv. Die historische M29-R2-Schicht und ihre Regressionen werden
unveraendert geladen; ihr ganzer alter BQ-Dateihash wird durch die streng
begrenzte M30-Dateiversion mit erhaltener Probe-Funktion ersetzt.
Der unveraenderte native M29-Probe-Test umfasst 156 C-Assertions. Weitere
2.327 C-Assertions pruefen echte Lesefunktionen, Fehlercodes, drei Retries,
unveraenderte Ausgabewerte bei Fehlern und unveraenderte erfolgreiche Ablaeufe.
Getestet mit GCC 11.4 und GCC 14 sowie UBSan; ganzer Treiber fuer ARM64 mit
Clang 12.0.5 und CFI/ThinLTO kompiliert. Kein vollstaendiger lokaler M30-Kernelbau.
Der volle CI-Bau muss zusaetzlich Quellen, LLVM-Objekt, Kommando und BQ-Interfaces
sowie den neuen I2C-Fehlerzweig in Image UND vmlinux nachweisen. Konfiguration
und komplette Exporttabelle bleiben auf dem bestaetigten Stand.
Die echte Git-Checkout-Pruefung und die strikten Header-/Blob-Pins bleiben aktiv.
Kernelkennung: 5.4.274-qgki-g82179e362f33.

OFFEN
Vollstaendiger M30-CI-Lauf. Danach weitere BQ-Schreibfehlerpfade, spaetere
Probe-Ressourcenaufraeumung und Shutdown-Synchronisation sowie weitere offene
Quellpunkte pruefen. Geraeteboot, Laden, Suspend und Wiederherstellung sind
noch ungetestet. Kein universeller GKI-/Vollvergleich aller historischen
Quellabweichungen. Device Pass NEIN. Flashfreigabe NEIN. Alle Pakete NOFLASH.
