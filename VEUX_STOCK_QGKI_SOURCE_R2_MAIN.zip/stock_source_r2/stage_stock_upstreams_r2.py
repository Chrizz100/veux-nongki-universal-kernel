#!/usr/bin/env python3
"""Source-only VEUX stock QGKI upstream bridge; never compiles/patches/installs."""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, subprocess, sys, tempfile
from datetime import datetime, timezone

PINNED={
 'susfs': {'version':'2.3.0', 'commit':'5326e21a7eb232f9e21debdd5164e99bee3d1e2f','ref':'refs/heads/gki-android13-5.10', 'url':'https://gitlab.com/simonpunk/susfs4ksu.git'},
 'nomount': {'version':'20','commit':'c5fad9d8f97c5a207f7342fd91789449915ea047','ref':'refs/heads/master','url':'https://github.com/maxsteeel/nomount.git'},
 'resukisu': {'version':'35203','commit':'8770c7e324a22895703c4916b8a16520e0b81c79','ref':'refs/heads/main','url':'https://github.com/ReSukiSU/ReSukiSU.git'}
}
STOCK_IMAGE_SHA='6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
CURRENT_REFERENCE_SHA='f25157822979c464ad857aeab9472d799f122b807d7be58f9d18a8e64b092eea'
LATEST=(
 ('bakasu','https://github.com/Baka-SU/BakaSU.git','main',('kernel',)),
 ('susfs','https://gitlab.com/simonpunk/susfs4ksu.git','gki-android13-5.10',('kernel_patches',)),
 ('nomount','https://github.com/maxsteeel/nomount.git','master',('kernel',)),
)
SHA40=re.compile('[0-9a-f]{40}\\Z')
class Blocked(RuntimeError): pass

def require(test,what):
 if not test: raise Blocked(what)
def sha(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def run(args,cwd=None,timeout=240):
 try: p=subprocess.run(args,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=False,env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GIT_CONFIG_NOSYSTEM':'1'})
 except (OSError,subprocess.TimeoutExpired) as e: raise Blocked('COMMAND_FAILED '+str(e)) from e
 require(p.returncode==0, 'COMMAND_EXIT_'+str(p.returncode)+' '+str(args[:3])+' '+p.stderr[-700:])
 return p.stdout.strip()
def pins(repo):
 require((repo/'common/update/current/5.4.274/overlay.json').is_file(),'V4_OVERLAY_MISSING')
 overlay=json.loads((repo/'common/update/current/5.4.274/overlay.json').read_text())
 require(overlay.get('kernel')=='5.4.274','V4_KERNEL_DRIFT')
 require(len(overlay.get('edits',{}))>=50,'V4_OVERLAY_UNEXPECTED')
 declared=overlay['targets']; out={}
 for name,values in PINNED.items():
  doc=json.loads((repo/f'common/upstream/{name}/current.json').read_text())
  require(all(doc.get(k)==v for k,v in values.items()),'UPDATER_PIN_DRIFT '+name)
  require(all(declared[name].get(k)==v for k,v in values.items()),'UPDATER_OVERLAY_TARGET_DRIFT '+name)
  require(SHA40.fullmatch(doc['commit']),'UPDATER_COMMIT_INVALID '+name)
  out[name]={'source':'repo_updater_pin','path':f'common/upstream/{name}/current.json','declared':doc}
 # Static integrity of mirrored source paths; these are not claimed to match a fresh upstream head.
 s=(repo/'third_party/current/susfs/kernel_patches/include/linux/susfs.h').read_text()
 require(re.search(r'#define\s+SUSFS_VERSION\s+"v2\.3\.0"',s)!=None,'SUSFS_PIN_VERSION_INVALID')
 require((repo/'third_party/current/susfs/kernel_patches/KernelSU/10_enable_susfs_for_ksu.patch').is_file(),'SUSFS_REAL_KERNELSU_SUBDIR_MISSING')
 n=(repo/'third_party/current/nomount/kernel/src/nomount.h').read_text()
 require(re.search(r'#define\s+NOMOUNT_VERSION\s+"20"',n)!=None,'NOMOUNT_PIN_VERSION_INVALID')
 k=(repo/'third_party/current/resukisu/kernel/Kconfig').read_text()
 require('config KSU_MANUAL_HOOK' in k and 'config KSU_SUSFS' in k,'RESUKISU_PIN_LAYOUT_INVALID')
 c=json.loads((repo/'common/contracts/CURRENT_BUILD.json').read_text())
 reference=c['lineages']['5.4.274']['image_sha256']
 require(reference==CURRENT_REFERENCE_SHA and reference!=STOCK_IMAGE_SHA,'STOCK_CUSTOM_KERNEL_REFERENCE_DRIFT')
 require(c['targets']==declared,'CURRENT_TARGETS_INCONSISTENT')
 return {'saved_updater':out,'kernel':'5.4.274','updater_overlay_edits':len(overlay['edits']),
         'updater_custom_kernel_image_sha256':reference,'uploaded_stock_image_sha256':STOCK_IMAGE_SHA,
         'same_image':False,'original_updater_variants':['resukisu','susfs','nomount'],
         'bakasu_present_in_original_updater':False,'matching_complete_stock_kernel_sources':False}

def archive_repo_snapshot(repo,out,component):
 path=f'third_party/current/{component}'
 require((repo/path).is_dir(),'SNAPSHOT_DIRECTORY_MISSING '+path)
 fn=out/(f'veux_updater_{component}_pinned_sources.tar.gz')
 run(['git','-C',str(repo),'archive','--format=tar.gz','-o',str(fn),'HEAD',path],timeout=120)
 require(fn.stat().st_size>200,'SNAPSHOT_ARCHIVE_EMPTY '+component)
 return {'name':component,'source':'existing_github_updater','declared_pin':PINNED[component],
   'archive':fn.name,'sha256':sha(fn),'compile':'NOT_RUN','kernel_applied':False}

def remote_head(text,branch):
 rows=[line.split('\t',1) for line in text.splitlines() if '\t' in line]
 hits=[h for h,ref in rows if ref=='refs/heads/'+branch]
 require(len(hits)==1 and SHA40.fullmatch(hits[0]),'UPSTREAM_HEAD_UNVERIFIED '+branch)
 return hits[0]
def source_layout(name,tree):
 if name=='bakasu':
  data=(tree/'kernel/Kconfig').read_text(errors='replace')
  require('config KSU_MANUAL_HOOK' in data,'BAKASU_MANUAL_HOOK_UNSUPPORTED')
  return {'legacy_5_4_hook_declared':True}
 if name=='susfs':
  base=tree/'kernel_patches'
  require(base.is_dir(),'SUSFS_KERNEL_PATCHES_MISSING')
  require((base/'KernelSU').is_dir(),'SUSFS_KERNELSU_PATH_MISSING')
  fs=base/'include/linux/susfs.h'
  require(fs.is_file(),'SUSFS_HEADER_MISSING')
  require(re.search(r'SUSFS_VERSION\s+"v?2\.3\.0"',fs.read_text(errors='replace')) is not None,'SUSFS_2_3_VERSION_UNPROVEN')
  return {'version':'2.3.0','correct_ksu_patch_path':'kernel_patches/KernelSU'}
 if name=='nomount':
  h=(tree/'kernel/src/nomount.h').read_text(errors='replace')
  m=re.search(r'#define\s+NOMOUNT_BASE_VERSION\s+"([0-9]+)"',h)
  require(bool(m),'NOMOUNT_LATEST_VERSION_UNPROVEN')
  return {'wire_version':m.group(1)}
 raise Blocked('UNKNOWN_SOURCE')
def stage_one(source,out):
 name,url,branch,paths=source
 h=remote_head(run(['git','ls-remote','--exit-code',url,'refs/heads/'+branch],timeout=120),branch)
 with tempfile.TemporaryDirectory(prefix='veux-stock-upstream-') as tmp:
  target=pathlib.Path(tmp)/'repo'
  run(['git','-c','core.hooksPath=/dev/null','clone','--quiet','--depth=1','--single-branch','--branch',branch,'--',url,str(target)],timeout=300)
  local=run(['git','-C',str(target),'rev-parse','HEAD'])
  require(local==h,'UPSTREAM_HEAD_CHANGED_DURING_CHECKOUT '+name)
  details=source_layout(name,target)
  for p in paths: require((target/p).is_dir(),'UPSTREAM_REQUIRED_PATH_MISSING '+name+'/'+p)
  outfile=out/(f'fresh_{name}_source_{local[:12]}.tar.gz')
  run(['git','-C',str(target),'archive','--format=tar.gz','-o',str(outfile),'HEAD',*paths],timeout=120)
  require(outfile.stat().st_size>1000,'UPSTREAM_ARCHIVE_EMPTY '+name)
  return {'name':name,'source':'official_upstream_head_at_run','repository':url,'branch':branch,
          'head':local,'layout':details,'archive':outfile.name,'sha256':sha(outfile),
          'kernel_5_4_port_complete':False,'compile':'NOT_RUN','kernel_applied':False}
def stage(repo,out,fetch_live):
 repo=repo.resolve();out=out.resolve()
 require(repo.is_dir(),'REPO_ROOT_MISSING');require(not out.exists() or not any(out.iterdir()),'OUTPUT_NOT_EMPTY')
 info=pins(repo)
 out.mkdir(parents=True,exist_ok=True)
 report={'stage':'STOCK_QGKI_SOURCE_BRIDGE_R2','kernel_release':'5.4.274-qgki-g82179e362f33',
         'time_utc':datetime.now(timezone.utc).isoformat(),'repo_validation':info,
         'saved_repository_sources':[],'fresh_official_sources':[], 'fresh_requested':fetch_live,
         'only_archived_sources':True,'stock_binary_modified':False,'flash_approval':False,
         'build_tested':False,'susfs_5_4_port_tested':False,
         'status':'REPO_PINS_VERIFIED_ONLY'}
 try:
  for component in ('susfs','nomount','resukisu'):
   report['saved_repository_sources'].append(archive_repo_snapshot(repo,out,component))
  (out/'STOCK_R2_PIN_REPORT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
  if fetch_live:
   for source in LATEST:
    report['fresh_official_sources'].append(stage_one(source,out))
   report['status']='CURRENT_UPSTREAM_SOURCES_STAGED'
  (out/'STOCK_R2_PIN_REPORT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
  return report
 except Exception:
  report['status']='LIVE_DOWNLOAD_FAILED_OR_PIN_DRIFT'
  (out/'STOCK_R2_PIN_REPORT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
  raise

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--repo',required=True);ap.add_argument('--output',required=True)
 ap.add_argument('--latest',action='store_true');a=ap.parse_args()
 info=stage(pathlib.Path(a.repo),pathlib.Path(a.output),a.latest)
 print('STOCK_SOURCE_R2_STAGE='+info['status']+'; FLASH=NO')
if __name__=='__main__':
 try:main()
 except (Blocked,OSError,ValueError,KeyError,subprocess.SubprocessError) as e:
  print('STOCK_SOURCE_R2_BLOCKED: '+str(e),file=sys.stderr);sys.exit(2)
