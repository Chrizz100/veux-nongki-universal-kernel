VEUX STOCK QGKI 5.4.274 – SOURCE BRIDGE R2 (NO KERNEL BUILD)

1) Dieses R2-Paket liest vorhandene, fixierte Quellstände der VEUX-V4-Updater-Dateien in der GitHub-Repo:
   common/upstream/{resukisu,susfs,nomount}/current.json
   common/update/current/5.4.274/overlay.json
   third_party/current/{resukisu,susfs,nomount}/
2) Pin-Konformität, tatsächliche Dateistrukturen und Unterschied zwischen altem Custom-Image
   und dem hochgeladenen Stock-QGKI-Image werden zwingend überprüft.
3) Daraus werden prüfbare Quellarchiv-Snapshots, kein buildbares oder flashbares Image.
4) Bei fetch_latest_official=true werden BaKaSU, SUSFS 2.3 und NoMount frisch vom
   jeweils offiziellen Zweig geladen und auf genaue Commit-Hashes fixiert.
   SUSFS nutzt kernel_patches/KernelSU (NICHT den nicht vorhandenen ksu_patches-Ordner).
5) Der ältere Updater enthält ReSukiSU 35203, nicht BaKaSU. BaKaSU wird separat
   aus Baka-SU/BakaSU bezogen. Keine automatische Substitution.
6) Die alte Overlay-Patchsammlung wird NICHT auf das hochgeladene Stock-Image angewendet.
   ABI/Module.symvers/vollständige passende Stock-Quellen fehlen; kein Kernel-Build.
7) Kein GitHub-Schreibzugriff, kein boot.img, AK3, Flash oder Module-Installation.

Dateien hochladen:
- VEUX_STOCK_QGKI_SOURCE_R2_MAIN.zip -> GitHub main / Wurzel
- VEUX_STOCK_QGKI_SOURCE_R2.yml -> .github/workflows/
Dann Actions -> VEUX Stock QGKI Source Bridge R2 (NO BUILD) -> Run workflow.
Die Option fetch_latest_official ist standardmäßig true. Zum reinen lokalen
Updater-Pin-Check kann sie auf false gesetzt werden. Wenn die aktuellsten Quellen
nicht verifiziert beschafft werden können, ist der Lauf ROT (fail closed), obwohl
alte Pins geprüft und als separate Referenzarchivdateien gesichert wurden.
