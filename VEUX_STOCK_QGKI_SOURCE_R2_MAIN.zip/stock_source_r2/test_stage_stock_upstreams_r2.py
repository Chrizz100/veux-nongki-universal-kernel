import hashlib,importlib.util,json,pathlib,subprocess,tempfile,unittest
S=pathlib.Path(__file__).with_name('stage_stock_upstreams_r2.py')
spec=importlib.util.spec_from_file_location('stage_stock_upstreams_r2',S)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class SourceTests(unittest.TestCase):
 def make_fixture(self):
  tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);root=pathlib.Path(tmp.name)/'repo';root.mkdir()
  for name,pin in m.PINNED.items():
   self.write(root/f'common/upstream/{name}/current.json',json.dumps(pin))
  overlay={'kernel':'5.4.274','targets':m.PINNED,'edits':{f'test/{i}':{'before':1,'after':2} for i in range(51)}}
  self.write(root/'common/update/current/5.4.274/overlay.json',json.dumps(overlay))
  build={'lineages':{'5.4.274':{'image_sha256':m.CURRENT_REFERENCE_SHA}},'targets':m.PINNED}
  self.write(root/'common/contracts/CURRENT_BUILD.json',json.dumps(build))
  self.write(root/'third_party/current/susfs/kernel_patches/include/linux/susfs.h','#define SUSFS_VERSION "v2.3.0"\n')
  self.write(root/'third_party/current/susfs/kernel_patches/KernelSU/10_enable_susfs_for_ksu.patch','example patch')
  self.write(root/'third_party/current/nomount/kernel/src/nomount.h','#define NOMOUNT_VERSION "20"\n')
  self.write(root/'third_party/current/resukisu/kernel/Kconfig','config KSU_MANUAL_HOOK\nconfig KSU_SUSFS\n')
  subprocess.run(['git','init','-q',str(root)],check=True)
  subprocess.run(['git','-C',str(root),'add','.'],check=True)
  subprocess.run(['git','-C',str(root),'-c','user.name=Test','-c','user.email=test@invalid','commit','-qm','fixture'],check=True)
  return root
 def write(self,path,data):path.parent.mkdir(parents=True,exist_ok=True);path.write_text(data)
 def test_01_pinned_keys_exact(self): self.assertEqual(set(m.PINNED),{'susfs','resukisu','nomount'})
 def test_02_latest_names(self):self.assertEqual([x[0] for x in m.LATEST],['bakasu','susfs','nomount'])
 def test_03_reject_old_susfs_path(self):self.assertNotIn('ksu_patches',str(m.LATEST))
 def test_04_correct_susfs_branch(self):self.assertEqual(m.LATEST[1][2],'gki-android13-5.10')
 def test_05_parse_remote_head(self):
  h='a'*40;self.assertEqual(m.remote_head(h+'\trefs/heads/main\n','main'),h)
 def test_06_reject_remote_head_short(self):
  with self.assertRaises(m.Blocked):m.remote_head('a'*39+'\trefs/heads/main','main')
 def test_07_reject_ambiguous_remote_head(self):
  with self.assertRaises(m.Blocked):m.remote_head(('b'*40+'\trefs/heads/main\n')*2,'main')
 def test_08_reject_branch_mismatch(self):
  with self.assertRaises(m.Blocked):m.remote_head('a'*40+'\trefs/heads/dev','main')
 def test_09_layout_bakasu(self):
  with tempfile.TemporaryDirectory() as t:
   self.write(pathlib.Path(t)/'kernel/Kconfig','config KSU_MANUAL_HOOK\n');self.assertTrue(m.source_layout('bakasu',pathlib.Path(t))['legacy_5_4_hook_declared'])
 def test_10_reject_no_bakasu_hook(self):
  with tempfile.TemporaryDirectory() as t:
   self.write(pathlib.Path(t)/'kernel/Kconfig','config KSU\n')
   with self.assertRaises(m.Blocked):m.source_layout('bakasu',pathlib.Path(t))
 def test_11_layout_susfs(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);self.write(p/'kernel_patches/include/linux/susfs.h','#define SUSFS_VERSION "v2.3.0"')
   self.write(p/'kernel_patches/KernelSU/example.patch','foo');self.assertEqual(m.source_layout('susfs',p)['version'],'2.3.0')
 def test_12_reject_susfs_wrong_layout(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);self.write(p/'kernel_patches/include/linux/susfs.h','#define SUSFS_VERSION "v2.3.0"')
   with self.assertRaises(m.Blocked):m.source_layout('susfs',p)
 def test_13_reject_susfs_old_version(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);self.write(p/'kernel_patches/include/linux/susfs.h','#define SUSFS_VERSION "v2.2.0"')
   self.write(p/'kernel_patches/KernelSU/example.patch','foo')
   with self.assertRaises(m.Blocked):m.source_layout('susfs',p)
 def test_14_layout_nomount_21(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);self.write(p/'kernel/src/nomount.h','#define NOMOUNT_BASE_VERSION "21"')
   self.assertEqual(m.source_layout('nomount',p)['wire_version'],'21')
 def test_15_reject_missing_nomount_version(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);self.write(p/'kernel/src/nomount.h','#define A 21')
   with self.assertRaises(m.Blocked):m.source_layout('nomount',p)
 def test_16_fixture_pin_read(self):
  r=self.make_fixture();p=m.pins(r);self.assertFalse(p['same_image']);self.assertEqual(p['updater_overlay_edits'],51)
 def test_17_build_input_must_be_different(self):
  self.assertNotEqual(m.CURRENT_REFERENCE_SHA,m.STOCK_IMAGE_SHA)
 def test_18_wrong_susfs_pin(self):
  r=self.make_fixture();p=r/'common/upstream/susfs/current.json';j=json.loads(p.read_text());j['commit']='f'*40;p.write_text(json.dumps(j))
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_19_wrong_overlay_pin(self):
  r=self.make_fixture();p=r/'common/update/current/5.4.274/overlay.json';j=json.loads(p.read_text());j['targets']['nomount']['version']='21';p.write_text(json.dumps(j))
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_20_reject_unproven_susfs_source(self):
  r=self.make_fixture();(r/'third_party/current/susfs/kernel_patches/include/linux/susfs.h').write_text('#define SUSFS_VERSION "v2.2.0"')
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_21_reject_missing_susfs_ksu_patch(self):
  r=self.make_fixture();(r/'third_party/current/susfs/kernel_patches/KernelSU/10_enable_susfs_for_ksu.patch').unlink()
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_22_reject_old_nomount_pin_invalid(self):
  r=self.make_fixture();(r/'third_party/current/nomount/kernel/src/nomount.h').write_text('#define NOMOUNT_VERSION "21"')
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_23_reject_wrong_stock_reference(self):
  r=self.make_fixture();p=r/'common/contracts/CURRENT_BUILD.json';j=json.loads(p.read_text());j['lineages']['5.4.274']['image_sha256']=m.STOCK_IMAGE_SHA;p.write_text(json.dumps(j))
  with self.assertRaises(m.Blocked):m.pins(r)
 def test_24_git_archive_snapshots(self):
  r=self.make_fixture();d=r.parent/'out';d.mkdir();x=m.archive_repo_snapshot(r,d,'susfs');self.assertTrue((d/x['archive']).is_file());self.assertEqual(x['sha256'],m.sha(d/x['archive']))
 def test_25_do_not_claim_bakasu_in_updater(self):
  r=self.make_fixture();self.assertFalse(m.pins(r)['bakasu_present_in_original_updater'])
 def test_26_source_only_staging(self):
  r=self.make_fixture();d=r.parent/'out';x=m.stage(r,d,False);self.assertEqual(x['status'],'REPO_PINS_VERIFIED_ONLY');self.assertFalse(x['stock_binary_modified']);self.assertFalse(x['flash_approval']);self.assertEqual(len(x['saved_repository_sources']),3)
 def test_27_reject_nonempty_output(self):
  r=self.make_fixture();d=r.parent/'out';d.mkdir();(d/'keep').write_text('x')
  with self.assertRaises(m.Blocked):m.stage(r,d,False)
 def test_28_latest_selection_required(self):
  r=self.make_fixture();d=r.parent/'out';x=m.stage(r,d,False);self.assertEqual(x['fresh_official_sources'],[])
 def test_29_no_kernel_patch(self):
  s=S.read_text();self.assertNotIn('patch -p1',s);self.assertNotIn('flash_image',s)
 def test_30_latest_sources_are_official(self):
  for _,url,_,_ in m.LATEST:self.assertIn(url.split('/')[2],('github.com','gitlab.com'))
 def make_git_upstream(self,component,version_ok=True):
  t=tempfile.TemporaryDirectory();self.addCleanup(t.cleanup);root=pathlib.Path(t.name)/'upstream';root.mkdir()
  if component=='bakasu':
   self.write(root/'kernel/Kconfig','config KSU_MANUAL_HOOK\n' if version_ok else 'config KSU_TRACEPOINT_HOOK\n')
   branch='main';folders=('kernel',)
  elif component=='susfs':
   self.write(root/'kernel_patches/KernelSU/10_enable_susfs_for_ksu.patch','test patch')
   self.write(root/'kernel_patches/include/linux/susfs.h','#define SUSFS_VERSION "v2.3.0"\n' if version_ok else '#define SUSFS_VERSION "v2.2.0"\n')
   branch='gki-android13-5.10';folders=('kernel_patches',)
  else:
   self.write(root/'kernel/src/nomount.h','#define NOMOUNT_BASE_VERSION "21"\n' if version_ok else '#define A 20\n')
   branch='master';folders=('kernel',)
  self.write(root/folders[0]/'TEST_PADDING.txt',''.join(hashlib.sha256(str(i).encode()).hexdigest() for i in range(150)))
  subprocess.run(['git','init','-q','-b',branch,str(root)],check=True)
  subprocess.run(['git','-C',str(root),'add','.'],check=True)
  subprocess.run(['git','-C',str(root),'-c','user.name=Test','-c','user.email=test@invalid','commit','-qm','fixture'],check=True)
  return (component,str(root),branch,folders)
 def test_31_reallocal_git_bakasu(self):
  src=self.make_git_upstream('bakasu');d=pathlib.Path(src[1]).parent/'out';d.mkdir();j=m.stage_one(src,d);self.assertTrue((d/j['archive']).is_file());self.assertEqual(len(j['head']),40)
 def test_32_reallocal_git_susfs(self):
  src=self.make_git_upstream('susfs');d=pathlib.Path(src[1]).parent/'out';d.mkdir();j=m.stage_one(src,d);self.assertEqual(j['layout']['correct_ksu_patch_path'],'kernel_patches/KernelSU')
 def test_33_reallocal_git_nomount(self):
  src=self.make_git_upstream('nomount');d=pathlib.Path(src[1]).parent/'out';d.mkdir();j=m.stage_one(src,d);self.assertEqual(j['layout']['wire_version'],'21')
 def test_34_bad_live_bakasu_refused(self):
  src=self.make_git_upstream('bakasu',False);d=pathlib.Path(src[1]).parent/'out';d.mkdir()
  with self.assertRaises(m.Blocked):m.stage_one(src,d)
 def test_35_bad_live_susfs_refused(self):
  src=self.make_git_upstream('susfs',False);d=pathlib.Path(src[1]).parent/'out';d.mkdir()
  with self.assertRaises(m.Blocked):m.stage_one(src,d)
 def test_36_bad_live_nomount_refused(self):
  src=self.make_git_upstream('nomount',False);d=pathlib.Path(src[1]).parent/'out';d.mkdir()
  with self.assertRaises(m.Blocked):m.stage_one(src,d)
 def test_37_reallocal_git_archive_hash(self):
  src=self.make_git_upstream('bakasu');d=pathlib.Path(src[1]).parent/'out';d.mkdir();j=m.stage_one(src,d);self.assertEqual(j['sha256'],m.sha(d/j['archive']))
 def test_38_source_pin_archive_must_not_claim_build(self):
  r=self.make_fixture();d=r.parent/'out';j=m.stage(r,d,False)
  self.assertFalse(j['build_tested']);self.assertFalse(j['susfs_5_4_port_tested']);self.assertFalse(j['flash_approval'])

if __name__=='__main__': unittest.main(verbosity=2)
