# VEUX Stock 5.4.274 R19 – Qualcomm source compatibility trial (NOFLASH)

Ausgangspunkt: R18-Github-Lauf 42113642166; 12 Einzelobjekte erfolgreich,
Gesamtbuild wegen mm/vmscan und kernel/sched/core fehlgeschlagen.

R19 versucht **unveränderte gepinnte Quell-Dateien** aus
`shandongtlb/kernel_xiaomi_sm8350_M11` (5.4.61) ausschließlich im temporären
5.4.268-Spender-Worktree:

- `kernel/sched/core.c`
- `kernel/sched/pelt.h`
- `mm/vmscan.c`

Diese Quellen sind KEIN Nachweis, dass sie zum VEUX Stock 5.4.274 passen.
Keine einzelne künstliche Sperren-Deklaration, keine CRC-Manipulation und keine
verfälschten Erfolgswerte. Bestehende R6/R17/R18-Referenzen bleiben unverändert.

Zuerst werden die Quellobjekte `core.o`, `rt.o`, `fair.o`, `vmscan.o` einzeln
kompiliert. Nur wenn sie tatsächlich erfolgreich sind, läuft der R18
Image/dtbs-Gesamtbuild mit ABI-Vergleich weiter. Wenn sie scheitern,
sind die vollständigen Compiler-Logs das Ergebnis; GitHub meldet Rot.

**NOFLASH** – der experimentelle Austausch großer 5.4.61-Dateien ist keine
produktive WALT-Portierung und darf keinesfalls geflasht werden.
