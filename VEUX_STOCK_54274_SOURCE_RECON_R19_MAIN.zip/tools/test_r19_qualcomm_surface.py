import hashlib,io,json,tempfile,unittest,zipfile
from pathlib import Path
from unittest.mock import patch
import r19_qualcomm_surface as a

BASE=Path(__file__).resolve().parents[1]
class R19Tests(unittest.TestCase):
 def test_01_inputs_authenticated(self):self.assertEqual(a.verify(BASE)['schema'],a.SCHEMA)
 def test_02_r18_original_sha(self):self.assertEqual(a.sha((BASE/'reference/R18_MAIN_ORIGINAL.zip').read_bytes()),a.R18_SHA)
 def test_03_parent_genuine_manifest(self):
  with zipfile.ZipFile(BASE/'reference/R18_MAIN_ORIGINAL.zip') as z:
   self.assertEqual(json.loads(z.read('MANIFEST_SHA256.json'))['r17_parent_sha256'],'511dc8744b4f6b06f837bba9a92e32cf2510eb383224d27bd342b44a4991e4a6')
 def test_04_r18_is_real_failure(self):self.assertEqual(json.loads((BASE/'reference/R18_GITHUB_FAIL_EVIDENCE.json').read_text())['build_rc'],2)
 def test_05_r18_has_shrinker_error(self):self.assertTrue(any('shrinker_rwsem' in e for e in json.loads((BASE/'reference/R18_GITHUB_FAIL_EVIDENCE.json').read_text())['compiler_errors_first']))
 def test_06_r18_has_select_task_rq_error(self):self.assertTrue(any('too few arguments to function call' in e for e in json.loads((BASE/'reference/R18_GITHUB_FAIL_EVIDENCE.json').read_text())['compiler_errors_first']))
 def test_07_source_file_set(self):self.assertEqual(set(a.SOURCE),{'mm/vmscan.c','kernel/sched/core.c','kernel/sched/pelt.h'})
 def test_08_git_blob_format(self):self.assertEqual(a.gitblob(b'test'),'30d74d258442c7c65512eafab474568dd706c430')
 def test_09_no_run_time_claim(self):self.assertFalse(a.verify(BASE)['flash_allowed'])
 def test_10_no_boot_claim(self):self.assertFalse(a.verify(BASE)['boot_verified'])
 def test_11_no_abi_claim(self):self.assertFalse(a.verify(BASE)['abi_verified'])
 def test_12_metadata_source_pin(self):self.assertEqual(a.verify(BASE)['pair_commit'],a.PAIR_SHA)
 def test_13_prohibited_source_double(self):self.assertEqual(len(a.SOURCE),len(set(a.SOURCE)))
 def test_14_source_blobs_exact(self):self.assertTrue(all(len(x['donor'])==40 and len(x['pair'])==40 for x in a.SOURCE.values()))
 def test_15_r18_reference_immutable(self):self.assertNotIn('write_bytes',a.verify.__code__.co_names)
 def test_16_cpp_no_flash(self):self.assertNotIn('fastboot',Path(a.__file__).read_text())
 def test_17_partial_copy_atomic_on_blob_error(self):
  with tempfile.TemporaryDirectory() as t:
   r=Path(t);src=r/'src';dst=r/'dst';src.mkdir();dst.mkdir()
   files={'aa.c':{'pair':a.gitblob(b'xx'),'donor':a.gitblob(b'old')},'bb.c':{'pair':a.gitblob(b'yy'),'donor':a.gitblob(b'prev')}}
   for n,data in [('aa.c',b'xx'),('bb.c',b'mismatch')]: (src/n).write_bytes(data)
   for n,data in [('aa.c',b'old'),('bb.c',b'prev')]: (dst/n).write_bytes(data)
   with patch.object(a,'SOURCE',files):
    with self.assertRaisesRegex(ValueError,'WRONG_OR_DRIFTING_GIT_BLOB'):a.copy_verified_whole_files(src,dst)
    self.assertEqual((dst/'aa.c').read_bytes(),b'old')
 def test_18_verified_original_copy(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'src').mkdir();(p/'dst').mkdir()
   (p/'src'/'s.c').write_bytes(b'full upstream');(p/'dst'/'s.c').write_bytes(b'full donor')
   with patch.object(a,'SOURCE',{'s.c':{'pair':a.gitblob(b'full upstream'),'donor':a.gitblob(b'full donor')}}):
    proof=a.copy_verified_whole_files(p/'src',p/'dst')
   self.assertEqual((p/'dst'/'s.c').read_bytes(),b'full upstream');self.assertEqual(proof['s.c']['replacement_bytes'],len(b'full upstream'))
 def test_19_unchanged_upstream_in_copy(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'src').mkdir();(p/'dst').mkdir();(p/'src'/'s.c').write_bytes(b'source');(p/'dst'/'s.c').write_bytes(b'donor')
   with patch.object(a,'SOURCE',{'s.c':{'pair':a.gitblob(b'source'),'donor':a.gitblob(b'donor')}}):a.copy_verified_whole_files(p/'src',p/'dst')
   self.assertEqual((p/'src'/'s.c').read_bytes(),b'source')
 def test_20_source_symlink_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'src').mkdir();(p/'dst').mkdir();(p/'dst'/'file.c').write_bytes(b'donor');(p/'src'/'file.c').symlink_to(p/'dst'/'file.c')
   with patch.object(a,'SOURCE',{'file.c':{'pair':a.gitblob(b'donor'),'donor':a.gitblob(b'donor')}}):
    with self.assertRaises(ValueError):a.copy_verified_whole_files(p/'src',p/'dst')
 def test_21_summary_missing_rc_red(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'r').mkdir();(p/'b').mkdir()
   (p/'r'/'R19_SOURCE_PROVENANCE.json').write_text(json.dumps({'original_repositories_clean':True}))
   d=a.summary(p/'r',p/'b');self.assertFalse(d['target_object_compilation_pass']);self.assertEqual(len(d['failures']),len(a.OBJECTS))
 def test_22_summary_all_objects_real(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'r').mkdir();(p/'b').mkdir()
   (p/'r'/'R19_SOURCE_PROVENANCE.json').write_text(json.dumps({'original_repositories_clean':True}))
   for k,n in a.OBJECTS.items():
    (p/'r'/('R19_'+k+'_RC.txt')).write_text('0\n');(p/'r'/('R19_'+k+'_BUILD.log')).write_text('CC '+n+'\n')
    o=p/'b'/n;o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(b'ELF test stand-in')
   d=a.summary(p/'r',p/'b');self.assertTrue(d['target_object_compilation_pass']);self.assertFalse(d['boot_verified'])
 def test_23_summary_nonzero_makes_red(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'r').mkdir();(p/'b').mkdir()
   (p/'r'/'R19_SOURCE_PROVENANCE.json').write_text(json.dumps({'original_repositories_clean':True}))
   for k,n in a.OBJECTS.items():
    (p/'r'/('R19_'+k+'_RC.txt')).write_text('2\n' if k=='CORE' else '0\n');(p/'r'/('R19_'+k+'_BUILD.log')).write_text('CC '+n+'\n')
    o=p/'b'/n;o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(b'ELF test stand-in')
   d=a.summary(p/'r',p/'b');self.assertFalse(d['target_object_compilation_pass']);self.assertIn('CORE',d['failures'])
 def test_24_summary_error_with_zero_rc_red(self):
  with tempfile.TemporaryDirectory() as t:
   p=Path(t);(p/'r').mkdir();(p/'b').mkdir()
   (p/'r'/'R19_SOURCE_PROVENANCE.json').write_text(json.dumps({'original_repositories_clean':True}))
   for k,n in a.OBJECTS.items():
    (p/'r'/('R19_'+k+'_RC.txt')).write_text('0\n');(p/'r'/('R19_'+k+'_BUILD.log')).write_text('error: wrong C call\n' if k=='RT' else 'CC '+n+'\n')
    o=p/'b'/n;o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(b'ELF test stand-in')
   d=a.summary(p/'r',p/'b');self.assertFalse(d['target_object_compilation_pass']);self.assertIn('RT',d['failures'])
 def test_25_r18_abi_baseline_exists(self):
  with zipfile.ZipFile(BASE/'reference/R18_MAIN_ORIGINAL.zip') as z:self.assertIn('reference/R6_QGKI_IMPORT_ABI.csv',z.namelist())

if __name__=='__main__':unittest.main()
