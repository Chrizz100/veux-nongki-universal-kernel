#!/usr/bin/env python3
"""R19 genuine 5.4.61 Qualcomm whole-source compatibility experiment (NOFLASH).

This is a disposable test only, not an approved VEUX 5.4.274 port. Existing
source trees, vendor files, CRCs and boot partitions are never changed.
"""
from __future__ import annotations
import argparse,hashlib,json,os,re,shutil,subprocess,zipfile
from pathlib import Path, PurePosixPath

R18_SHA='1831afc6cd9b9b9458dd7a2baf0558b0538100265699f6cfd0a25b3bb5099d69'
DONOR_SHA='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
PAIR_SHA='01cb3a8824b7b4caf3e3540274e71abba5ade538'
STOCK_TASK_SHA='a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
SCHEMA='VEUX_R19_PINNED_QUALCOMM_SOURCE_SURFACE_NOFLASH'
# Pinned Linux 5.4.61 source files, kept whole rather than mixing incompatible
# halves of functions between 5.4.61 and 5.4.268.
SOURCE={
 'kernel/sched/core.c':{'pair':'a1cd9d8754abaa392566d10b4b9b1507e1722080','donor':'15bf194dfa64654c213b73ba304adcc5fec98ea4'},
 'kernel/sched/pelt.h':{'pair':'afff644da06500b4b817925e8f35824b8b69d0c5','donor':'0052b8c3a6949d693074ac28685694bd42d5e61c'},
 'mm/vmscan.c':{'pair':'d81fc723be0c1a127d4acb7079cad23a2ee0a543','donor':'fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa'},
}
OBJECTS={
 'CORE':'kernel/sched/core.o',
 'RT':'kernel/sched/rt.o',
 'FAIR':'kernel/sched/fair.o',
 'VMSCAN':'mm/vmscan.o',
}
ERR=re.compile(r'(?i)(?:\berror:|fatal error:|undefined reference|make\[\d+\]: \*\*\*|make: \*\*\*)')

def sha(data: bytes)->str:return hashlib.sha256(data).hexdigest()
def gitblob(data:bytes)->str:return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def git(root:Path,*args)->str:return subprocess.check_output(['git','-C',str(root),*args],text=True,stderr=subprocess.PIPE,timeout=30).strip()
def no_symlink(root:Path):
 if root.is_symlink():raise ValueError('SYMLINK_ROOT')
 for p in root.rglob('*'):
  if p.is_symlink():raise ValueError('SYMLINK_MEMBER:'+str(p))

def verify(root:Path):
 root=Path(root)
 if not root.is_dir() or root.is_symlink():raise ValueError('R19_ROOT')
 no_symlink(root)
 m=json.loads((root/'MANIFEST_SHA256.json').read_text())
 if m.get('schema')!=SCHEMA or m.get('r18_parent_sha256')!=R18_SHA or m.get('pair_commit')!=PAIR_SHA or m.get('donor_commit')!=DONOR_SHA:
  raise ValueError('R19_MANIFEST_OR_PIN')
 if any(m.get(k) is not False for k in ('flash_allowed','production_patch_approved','boot_verified','abi_verified','kernel_built')):
  raise ValueError('R19_UNSAFE_MANIFEST')
 names={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}-{'MANIFEST_SHA256.json'}
 if names!=set(m['files']):raise ValueError('R19_UNEXPECTED_FILESET')
 for n,h in m['files'].items():
  if sha((root/n).read_bytes())!=h:raise ValueError('R19_BAD_SHA:'+n)
 if sha((root/'reference/R18_MAIN_ORIGINAL.zip').read_bytes())!=R18_SHA:raise ValueError('R19_PARENT_DIFFERENT')
 with zipfile.ZipFile(root/'reference/R18_MAIN_ORIGINAL.zip') as z:
  if z.testzip() or json.loads(z.read('MANIFEST_SHA256.json')).get('schema')!='VEUX_R18_WALT_FULL_IMAGE_LINK_ABI_DIAGNOSTIC_NOFLASH':
   raise ValueError('R19_PARENT_NOT_GENUINE')
 previous=json.loads((root/'reference/R18_GITHUB_FAIL_EVIDENCE.json').read_text())
 if previous['build_rc']!=2 or previous['linked_image_and_vmlinux'] or previous['vendor_module_abi'] is not None:
  raise ValueError('R19_FALSE_R18_BASELINE')
 errorlines=previous['compiler_errors_first']
 if (not any('shrinker_rwsem' in x for x in errorlines) or
     not any('UTIL_AVG_UNCHANGED' in x for x in errorlines) or
     not any('too few arguments to function call' in x for x in errorlines)):
  raise ValueError('R19_R18_COMPILER_EVIDENCE_MISSING')
 return m

def copy_verified_whole_files(src:Path,dst:Path):
 """Copy complete pinned Git files only; reject symlinks and bad Git blobs."""
 if any(x.is_symlink() for x in (src,dst)) or not src.is_dir() or not dst.is_dir():raise ValueError('BAD_SOURCE_ROOT')
 plan={}
 for path,blobs in SOURCE.items():
  a,b=src/path,dst/path
  if a.is_symlink() or b.is_symlink() or not a.is_file() or not b.is_file():raise ValueError('SYMLINK_OR_MISSING:'+path)
  payload=a.read_bytes(); old=b.read_bytes()
  if gitblob(payload)!=blobs['pair'] or gitblob(old)!=blobs['donor']:
   raise ValueError('WRONG_OR_DRIFTING_GIT_BLOB:'+path)
  if not payload or not old:raise ValueError('EMPTY_GIT_SOURCE:'+path)
  plan[path]={'donor_git_blob':blobs['donor'],'qualcomm_git_blob':blobs['pair'],
              'donor_sha256':sha(old),'replacement_sha256':sha(payload),
              'replacement_bytes':len(payload)}
 # Validate *all* inputs before touching even one file.
 for path in SOURCE: (dst/path).write_bytes((src/path).read_bytes())
 return plan

def stage(root:Path,donor:Path,pair:Path,trial:Path,reports:Path):
 root,donor,pair,trial,reports=map(Path,(root,donor,pair,trial,reports))
 verify(root)
 if (git(donor,'rev-parse','HEAD')!=DONOR_SHA or git(trial,'rev-parse','HEAD')!=DONOR_SHA or
     git(pair,'rev-parse','HEAD')!=PAIR_SHA or git(donor,'status','--porcelain') or git(pair,'status','--porcelain')):
  raise ValueError('R19_ORIGINAL_REPO_COMMIT_OR_CLEAN_GUARD')
 task=trial/'include/linux/sched.h'
 if task.is_symlink() or sha(task.read_bytes())!=STOCK_TASK_SHA:
  raise ValueError('R19_ORIGINAL_STOCK_TASK_CHANGED')
 for path,spec in SOURCE.items():
  if git(pair,'rev-parse',f'HEAD:{path}')!=spec['pair'] or git(donor,'rev-parse',f'HEAD:{path}')!=spec['donor']:
   raise ValueError('R19_NOT_AN_ACTUAL_GIT_BLOB:'+path)
 # R11 staged internal sched.h comes from same paired source.
 inner=trial/'kernel/sched/sched.h'
 if inner.is_symlink() or gitblob(inner.read_bytes())!='79b175a65e0ebda59a5ccc13691b454b347e7701':
  raise ValueError('R19_DIFFERENT_INTERNAL_SCHEDULER_ABI')
 plan=copy_verified_whole_files(pair,trial)
 if (git(donor,'status','--porcelain') or git(pair,'status','--porcelain') or sha(task.read_bytes())!=STOCK_TASK_SHA):
  raise ValueError('R19_READONLY_SOURCE_OR_STOCK_GUARD')
 report={'schema':SCHEMA,'policy':'EXPERIMENT_NOT_5_4_274_STOCK_PORT',
         'pair_commit':PAIR_SHA,'donor_commit':DONOR_SHA,'changed_test_worktree_files':plan,
         'exact_source_blob_files':len(plan),'original_repositories_clean':True,
         'stock_task_struct_preserved':True,'flash_allowed':False,
         'production_patch_approved':False,'walt_runtime_verified':False,
         'stock_rtmm_implemented':False,'boot_verified':False,'oem_abi_verified':False}
 reports.mkdir(parents=True,exist_ok=True)
 (reports/'R19_SOURCE_PROVENANCE.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
 print('R19_WHOLE_UPSTREAM_FILES_PINNED_AND_STAGED=PASS; NOFLASH=YES')
 return report

def summary(reports:Path,build:Path):
 reports,build=map(Path,(reports,build))
 inputs=json.loads((reports/'R19_SOURCE_PROVENANCE.json').read_text())
 out={};fail=[]
 for k,path in OBJECTS.items():
  rc_file=reports/f'R19_{k}_RC.txt'; log=reports/f'R19_{k}_BUILD.log'
  if not rc_file.is_file() or not log.is_file():
   code=None;errors=['MISSING_LOG_OR_RC'];exists=False
  else:
   try:code=int(rc_file.read_text().strip())
   except:code=None
   errors=[x[:500] for x in log.read_text(errors='replace').splitlines() if ERR.search(x)][:45]
   exists=(build/path).is_file() and (build/path).stat().st_size>0
  out[k]={'object':path,'return_code':code,'output_exists':exists,'errors':errors,'error_count':len(errors)}
  if code!=0 or not exists or errors:fail.append(k)
 report={'schema':SCHEMA,'target_object_compilation_pass':not fail,
         'source_stage_verified':inputs['original_repositories_clean'],
         'failures':fail,'components':out,
         'flash_allowed':False,'boot_verified':False,'oem_abi_verified':False,
         'full_image_link_verified':False,'stock_rtmm_implemented':False,
         'walt_runtime_verified':False,
         'note':'Whole 5.4.61 Qualcomm source comparison on disposable 5.4.268 donor. NOT an approved 5.4.274 backport.'}
 (reports/'R19_COMPILER_SUMMARY.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 parts=[f'{k}={v["return_code"]}({"built" if v["output_exists"] else "absent"})' for k,v in out.items()]
 (reports/'R19_STATUS_DE.txt').write_text('R19 SOURCE TRIAL; NOFLASH; COMPILER_PASS='+str(not fail)+'\n'+' '.join(parts)+'\n\n'+'\n'.join(x for x in out.values() for x in x['errors'])+'\n')
 print('R19_OBJECT_SOURCE_TRIAL='+('PASS' if not fail else 'FAIL')+'; '+', '.join(parts)+'; NOFLASH=YES')
 return report

def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='action',required=True)
 v=sub.add_parser('verify');v.add_argument('--root',required=True,type=Path)
 s=sub.add_parser('stage');s.add_argument('--root',required=True,type=Path);s.add_argument('--donor',required=True,type=Path);s.add_argument('--pair',required=True,type=Path);s.add_argument('--trial',required=True,type=Path);s.add_argument('--reports',required=True,type=Path)
 c=sub.add_parser('summary');c.add_argument('--reports',required=True,type=Path);c.add_argument('--build',required=True,type=Path)
 a=p.parse_args()
 if a.action=='verify':verify(a.root);print('R19_ORIGINAL_INPUTS=PASS')
 elif a.action=='stage':stage(a.root,a.donor,a.pair,a.trial,a.reports)
 else:summary(a.reports,a.build)
if __name__=='__main__':main()
