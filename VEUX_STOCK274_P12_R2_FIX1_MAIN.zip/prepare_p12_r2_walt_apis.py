#!/usr/bin/env python3
"""VEUX P12 R2 API bridge: stage deterministic patch, never flash or write upstream.

Reads the frozen P11 R4 source, verifies the P12 R1 patch and authenticates donor
files from the pinned Xiaomi kernel commit. R2 patch applies AFTER R1 patch.
No unreviewed source override, no changes in kernel/sched/walt/.
"""
from __future__ import annotations
import argparse, difflib, hashlib, json, pathlib, re, subprocess, sys, tempfile

P11_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
DONOR_COMMIT = '61397e524093d1ccb94769b5460825e2eaf8871e'
DONOR_BLOBS = {
 'include/linux/sched.h':'888b27fe998a2bd6200144bcf06285da0ebe1aed',
 'include/linux/sched/sysctl.h':'b6fdfd97a8f37837a599405b6d9583a3e2697ac0',
 'include/linux/sched/stat.h':'60cf021ddff66b511fe17edae1d4f241b10781d3',
 'kernel/sched/sched.h':'b5bdfa2df156cf40b368e73751eac8d71b99de55'
}
R1_PATHS=('include/linux/sched.h','kernel/sched/sched.h')
R2_PATHS=('include/linux/sched.h','include/linux/sched/stat.h',
 'include/linux/sched/sysctl.h','kernel/sched/core.c','kernel/sched/deadline.c',
 'kernel/sched/fair.c','kernel/sched/rt.c','kernel/sched/sched.h',
 'kernel/sched/stop_task.c')
OEM_BLOBS={
 'Makefile':'8bf42cb669afabc17f69bc16cf74f17fcaf5cdd0',
 'boost.c':'c37185e293d0ac7affe9b13124fcf76339fbce4e',
 'core_ctl.c':'af838bd1c71e728d65dcdfee792b1379b07336e5',
 'cpu-boost.c':'9b2363cf275afbeadbc57b112e89818d0e019320',
 'qc_vas.c':'ce49eac6d5907108ed46aa48b7ead5146b49618e',
 'qc_vas.h':'3b67a54946557d92b4582f990e3f015bceb3d0ae',
 'sched_avg.c':'4a5efa4118b3c6605d74380ff028d66e9a24668b',
 'trace.c':'7c06ce1fda642d026295ec87f190df55176c1cf9',
 'trace.h':'5b01043d226142ac380d76f924542719ef863e9e',
 'walt.c':'9d851c1dd315e2f4fb2385b5aa4a0c2749908b7d',
 'walt.h':'9a678f0bbb68d92aa670991c8899a5253f51322e'
}


EXPECTED_OEM_NAMES=frozenset((
 'Makefile','boost.c','core_ctl.c','cpu-boost.c','qc_vas.c','qc_vas.h',
 'sched_avg.c','trace.c','trace.h','walt.c','walt.h'))

def validate_oem_pins():
 if len(OEM_BLOBS)!=11 or set(OEM_BLOBS)!=EXPECTED_OEM_NAMES:
  raise ValueError('OEM_BLOB_PIN_SCOPE_INVALID')
 for name, pin in OEM_BLOBS.items():
  if not re.fullmatch(r'[0-9a-f]{40}',pin):
   raise ValueError('OEM_BLOB_PIN_FORMAT_INVALID '+name)


def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def call(cmd,cwd=None,timeout=60):
 r=subprocess.run(cmd,cwd=cwd,capture_output=True,timeout=timeout)
 if r.returncode: raise RuntimeError('COMMAND_FAIL '+str(cmd[:3])+' '+r.stderr.decode(errors='replace')[-300:])
 return r.stdout.decode('utf-8')
def replace_once(s,old,new,tag):
 if s.count(old)!=1:raise ValueError('ANCHOR_DRIFT_'+tag+'='+str(s.count(old)))
 return s.replace(old,new,1)
def between(s,start,end,tag):
 if s.count(start)!=1 or s.count(end)!=1:raise ValueError('DONOR_DRIFT_'+tag)
 a=s.index(start);b=s.index(end,a)
 return s[a:b]

def donor_pieces(d):
 public=d['include/linux/sched.h'].decode()
 enums=between(public,'enum task_event {','\n#if defined(CONFIG_HOTPLUG_CPU)', 'PUBLIC_EVENTS').rstrip()+ '\n'
 if 'IRQ_UPDATE' not in enums or 'GROUP_TO_RQ' not in enums:raise ValueError('EVENT_DEFS_WRONG')
 donor_sys=d['include/linux/sched/sysctl.h'].decode()
 capacity=between(donor_sys,'#define MAX_CLUSTERS 3\n','\nextern unsigned int sysctl_sched_latency;', 'CAPACITY_MACROS')
 if 'MAX_MARGIN_LEVELS (MAX_CLUSTERS - 1)' not in capacity:raise ValueError('MARGIN_MACRO_WRONG')
 donor_stat=d['include/linux/sched/stat.h'].decode()
 stat=between(donor_stat,'#ifdef CONFIG_SCHED_WALT\nextern void sched_update_nr_prod', '\nstatic inline int sched_info_on', 'WALT_STAT_APIS')
 if 'sched_get_cpu_util' not in stat or 'sched_update_nr_prod' not in stat:raise ValueError('WALT_STAT_INCOMPLETE')
 donor_sched=d['kernel/sched/sched.h'].decode()
 helpers=between(donor_sched,'enum sched_boost_policy {','\n#else   /* CONFIG_SCHED_WALT */','SCHED_HELPERS')
 if not all(x in helpers for x in ('struct walt_related_thread_group {','task_related_thread_group','task_load','walt_fixup_cum_window_demand','task_rtg_high_prio','early_detection_notify','clear_reserved','check_for_migration')):
  raise ValueError('MISSING_HELPER_INTERFACE')
 return {'enums':enums,'capacity':capacity,'stat':stat,'helpers':helpers}

def fix_pos_tail(s):
 key='#ifdef CONFIG_SPRD_ROTATION_TASK\nDECLARE_PER_CPU_SHARED_ALIGNED(bool, cpu_reserved);'
 if s.count(key)!=1:raise ValueError('SPRD_TAIL_NOT_FOUND')
 before=s[:s.index(key)]; end=s[s.index(key):]
 if 'static inline u64 sched_ktime_clock(void)' not in end:raise ValueError('SPRD_STUBS_DRIFT')
 if end.count('#else\nstatic inline bool is_reserved(int cpu)')!=1:raise ValueError('SPRD_ELSE_DRIFT')
 if not end.rstrip().endswith('#endif'):raise ValueError('SPRD_TAIL_END_DRIFT')
 end=end.replace('#else\nstatic inline bool is_reserved(int cpu)', '#else\n#ifndef CONFIG_SCHED_WALT\nstatic inline bool is_reserved(int cpu)',1)
 end=end.rstrip()[:-len('#endif')].rstrip()+'\n#endif /* !CONFIG_SCHED_WALT */\n#endif /* CONFIG_SPRD_ROTATION_TASK */\n'
 # Fail closed on a combination that can create duplicate rotation functions.
 guard='#if defined(CONFIG_SPRD_ROTATION_TASK) && defined(CONFIG_SCHED_WALT)\n#error "P12: incompatible SPRD_ROTATION_TASK and SCHED_WALT configs"\n#endif\n'
 return before+guard+end

def create_after(before,donor):
 if set(before)!=set(R2_PATHS):raise ValueError('INPUT_SCOPE_DRIFT')
 parts=donor_pieces(donor)
 s={k:v.decode('utf-8') for k,v in before.items()}
 a='include/linux/sched.h'
 if 'enum task_event {' in s[a]:raise ValueError('EVENT_ALREADY_EXISTS')
 marker='#define TASK_COMM_LEN\t\t\t16\n'
 s[a]=replace_once(s[a],marker,marker+'\n#ifdef CONFIG_SCHED_WALT\n'+parts['enums']+'#endif /* CONFIG_SCHED_WALT */\n','TASK_ENUM')
 a='include/linux/sched/sysctl.h'
 if '#define MAX_MARGIN_LEVELS' in s[a] or '#define MAX_CLUSTERS' in s[a]:raise ValueError('MARGINS_ALREADY_DEFINED')
 marker='#ifdef CONFIG_SCHED_WALT\nextern unsigned int sysctl_sched_capacity_margin_up'
 s[a]=replace_once(s[a],marker,'#ifdef CONFIG_SCHED_WALT\n'+parts['capacity']+'\nextern unsigned int sysctl_sched_capacity_margin_up','CAPACITY')
 a='include/linux/sched/stat.h'
 if 'sched_update_nr_prod' in s[a]:raise ValueError('SCHED_STAT_ALREADY_ADDED')
 marker='extern unsigned long nr_iowait_cpu(int cpu);\n'
 s[a]=replace_once(s[a],marker,marker+'\n'+parts['stat']+'\n','SCHED_STAT')
 a='kernel/sched/sched.h'
 if 'struct walt_related_thread_group {' in s[a] or 'enum sched_boost_policy' in s[a]:raise ValueError('SCHED_HELPERS_ALREADY_ADDED')
 s[a]=fix_pos_tail(s[a])
 if 'static inline u64 sched_ktime_clock(void)' not in s[a]:raise ValueError('SPRD_STUB_REMOVED_WRONGLY')
 # R2 must preserve WALT OFF behavior. Only new Xiaomi helpers compiled WALT ON.
 addition=('\n#ifdef CONFIG_SCHED_WALT\n'
           'extern u64 sched_ktime_clock(void);\n'
           'extern unsigned long cpu_util_freq_walt(int cpu, struct walt_cpu_load *walt_load);\n'
           +replace_once(parts['helpers'],'\n#ifdef CONFIG_SCHED_WALT\n','\n','REMOVE_NESTED_WALT_GUARD')+'\n#endif /* CONFIG_SCHED_WALT */\n')
 s[a]=s[a].rstrip('\n')+'\n'+addition
 # Add only direct upstream includes required to resolve WALT helper prototypes.
 placements={
   'kernel/sched/core.c': '#include "pelt.h"\n',
   'kernel/sched/fair.c':'#include <trace/hooks/sched.h>\n',
   'kernel/sched/rt.c':'#include "pelt.h"\n',
   'kernel/sched/deadline.c':'#include "pelt.h"\n',
   'kernel/sched/stop_task.c':'#include "sched.h"\n'}
 for name,marker in placements.items():
  if '#include "walt/walt.h"' in s[name]:raise ValueError('WALT_INCLUDE_ALREADY_PRESENT '+name)
  s[name]=replace_once(s[name],marker,marker+'#include "walt/walt.h"\n',name)
 assert set(s)==set(R2_PATHS)
 result={k:v.encode('utf-8') for k,v in s.items()}
 for name in R2_PATHS:
  if result[name]==before[name]:raise ValueError('NO_CHANGE '+name)
 for name in R2_PATHS:
  if name.startswith('kernel/sched/walt/'):raise ValueError('OEM_MUTATION')
 return result

def patch_between(before,after):
 chunks=[]
 for name in R2_PATHS:
  orig=before[name];new=after[name]
  prefix=f'diff --git a/{name} b/{name}\nindex {oid(orig)[:12]}..{oid(new)[:12]} 100644\n'
  s=''.join(difflib.unified_diff(orig.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name,n=3))
  if not s:raise ValueError('EMPTY_PATCH '+name)
  chunks.append(prefix+s)
 return ''.join(chunks)

def simulate_r1(before0,r1patch):
 with tempfile.TemporaryDirectory(prefix='p12_r2_r1_sim_') as temp:
  root=pathlib.Path(temp)
  for name,b in before0.items():
   f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  p=root/'r1.patch';p.write_bytes(r1patch)
  call(['git','apply','--check',str(p)],root)
  call(['git','apply',str(p)],root)
  result={name:(root/name).read_bytes() for name in before0}
  call(['git','apply','--check','-R',str(p)],root)
  call(['git','apply','-R',str(p)],root)
  if any((root/name).read_bytes()!=v for name,v in before0.items()):raise ValueError('R1_REVERSE_FAILED')
  return result

def roundtrip(before,after,patch):
 with tempfile.TemporaryDirectory(prefix='p12_r2_patchcheck_') as temp:
  root=pathlib.Path(temp)
  for name,v in before.items():
   f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(v)
  f=root/'r2.patch';f.write_bytes(patch.encode() if isinstance(patch,str) else patch)
  call(['git','apply','--check',str(f)],root)
  call(['git','apply',str(f)],root)
  if any((root/n).read_bytes()!=v for n,v in after.items()):raise ValueError('R2_POSTIMAGE_DIFF')
  call(['git','apply','--check','-R',str(f)],root)
  call(['git','apply','-R',str(f)],root)
  if any((root/n).read_bytes()!=v for n,v in before.items()):raise ValueError('R2_REVERSE_FAILED')

def stage(source,r1report_path,r1patch_path,output):
 source=source.resolve(strict=True);output=output.resolve()
 if not (source/'.git').is_dir() or output.exists() or output.is_relative_to(source):raise ValueError('INVALID_PATHS')
 if call(['git','-C',str(source),'rev-parse','HEAD^{tree}']).strip()!=P11_TREE:raise ValueError('SOURCE_TREE_DRIFT')
 if call(['git','-C',str(source),'status','--porcelain','--untracked-files=all']).strip():raise ValueError('SOURCE_DIRTY')
 if not all((source/'Makefile').read_text().find(v)>=0 for v in ('VERSION = 5','PATCHLEVEL = 4','SUBLEVEL = 274')):raise ValueError('WRONG_KERNEL')
 report=json.loads(r1report_path.read_text());r1patch=r1patch_path.read_bytes()
 if report['input_tree']!=P11_TREE or report['changed_paths']!=list(R1_PATHS) or report['candidate_patch_sha256']!=sha(r1patch) or report['original_xiaomi_walt_file_blobs']!='PRESERVED':raise ValueError('UNVERIFIED_R1')
 validate_oem_pins()
 for name,blob in OEM_BLOBS.items():
  p='kernel/sched/walt/'+name
  if call(['git','-C',str(source),'rev-parse','HEAD:'+p]).strip()!=blob:raise ValueError('OEM_BLOB_DRIFT '+name)
 before0={name:(source/name).read_bytes() for name in R2_PATHS}
 for name,digest in report['preimage_sha256'].items():
  if sha(before0[name])!=digest:raise ValueError('R1_PREIMAGE_MISMATCH '+name)
 before=simulate_r1(before0,r1patch)
 for name,digest in report['postimage_sha256'].items():
  if sha(before[name])!=digest:raise ValueError('R1_POSTIMAGE_MISMATCH '+name)
 donor={}
 for name,digest in DONOR_BLOBS.items():
  ref=DONOR_COMMIT+':'+name
  if call(['git','-C',str(source),'rev-parse',ref]).strip()!=digest:raise ValueError('DONOR_BLOB_DRIFT '+name)
  raw=subprocess.check_output(['git','-C',str(source),'show',ref],timeout=45)
  if oid(raw)!=digest:raise ValueError('DONOR_BYTES_DRIFT '+name)
  donor[name]=raw
 after=create_after(before,donor);patch=patch_between(before,after)
 if len(patch)>85000:raise ValueError('R2_PATCH_TOO_LARGE')
 roundtrip(before,after,patch)
 # Check R1 -> R2 on exactly the immutable P11 source files; upstream remains clean.
 if call(['git','-C',str(source),'status','--porcelain','--untracked-files=all']).strip():raise ValueError('SOURCE_MUTATED')
 output.mkdir(parents=True)
 p=output/'P12_R1_TO_R2_WALT_API_BRIDGE.patch';p.write_bytes(patch.encode())
 o={'phase':'P12_R2_SOURCE_STAGING','kernel':'5.4.274','source_tree':P11_TREE,
  'donor_commit':DONOR_COMMIT,'donor_blobs':DONOR_BLOBS,'r1_patch_sha256':sha(r1patch),
  'r2_patch_sha256':sha(p.read_bytes()),'changed_paths':list(R2_PATHS),
  'r1_postimage_sha256':{k:sha(v) for k,v in before.items()},
  'r2_postimage_sha256':{k:sha(v) for k,v in after.items()},
  'oem_original_blobs_preserved':True,'flashable':False,
  'walt_y_targeted_compilation':'NOT_RUN','full_kernel':'NOT_RUN',
  'vendor_abi':'NOT_CHECKED','device_test':'NOT_RUN','remote_write':False}
 (output/'P12_R2_PREP_REPORT.json').write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
 return o

def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=pathlib.Path,required=True)
 p.add_argument('--r1-report',type=pathlib.Path,required=True)
 p.add_argument('--r1-patch',type=pathlib.Path,required=True)
 p.add_argument('--output',type=pathlib.Path,required=True)
 a=p.parse_args()
 try:stage(a.source,a.r1_report,a.r1_patch,a.output)
 except Exception as e:
  print('P12_R2_FAIL_CLOSED:',e,file=sys.stderr);return 2
 print('P12_R2_BRIDGE_STAGED=PASS; 9_PATHS; OEM_WALT=11/11; FLASH=NO')
 return 0
if __name__=='__main__':raise SystemExit(main())
