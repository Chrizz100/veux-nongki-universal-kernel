# VEUX Stock Linux 5.4.274 – Source/ABI-R2 (NOFLASH)

Dieses Paket ist eine **nachvollziehbare Fortsetzung** des erfolgreich dokumentierten
R1-Laufs [41982846589](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/41982846589).

## Installation in GitHub – genau zwei Dateien

* `VEUX_STOCK_54274_SOURCE_RECON_R2_MAIN.zip` in den **Repository-Hauptordner**.
* `VEUX_STOCK_54274_SOURCE_RECON_R2_NOFLASH.yml` in `.github/workflows/`.

Voraussetzung: Das bereits hochgeladene `VEUX_STOCK_54274_SOURCE_RECON_R1_MAIN.zip`
muss unverändert im Hauptordner liegen (feste SHA-256
`04a8bc015abd2a8b9c5adf17b63f97f75e9cd06fb038480d695ff0263e758789`).
Damit sind Stock-Konfiguration und 7717 Original-Header exakt referenziert,
ohne sie doppelt in GitHub abzulegen. Die R1-Stock-Provenienz wird verifiziert.

## Zielsetzung und Unterschiede zu R1

1. **Exakter Stock-Compiler**: Android clang 11.0.2, Build 6877366,
   `clang-r383902b1`, AOSP Tree-SHA
   `1c7dcc2e7095197f7a05dff22a875b6b02ed7117` (GitHub Runner lädt
   die amtlichen Android-Clang-Binärdateien). Keine stille GCC-Ersatzprobe.
2. Der vollständig gepinnte Spender-Quellbaum `dereference23/kernel_xiaomi_sm6375`
   Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632` ist **5.4.268**.
   Er ist eine Vergleichs- und Portierungsbasis, nicht die exakte Xiaomi-5.4.274-Quelle.
3. 7.717 Stock-Header werden gegen den gepinnten Spender verglichen.
   In R1 waren 2.052 als fehlend gemeldet, davon 2.040 erwartete generierte
   Kbuild-Header und **12 tatsächlich fehlende Quellheader**. Eine Änderung
   bei diesen fixen R1-Referenzen führt zu einem Prüfblocker.
4. `olddefconfig` wird mit originalem Clang (statt GCC) in einem isolierten
   Buildverzeichnis wiederholt; das Ergebnis wird anhand der tatsächlichen
   `.config` unabhängig erneut mit dem Stock verglichen. Priorisiert werden
   `SCHED_WALT`, QGKI, CFI/LTO, Vendor Hooks, IPC_LOGGING, TRACING und Modul-ABI.
5. Es gibt eine getrennte, optional anforderbare **Compiler-Sondierung**
   (`compile_probe`) des gepinnten 5.4.268-Donors; ihre Ergebnisse bleiben
   Diagnosedaten und KEIN 5.4.274-Stock- oder Flash-Kernel. Standard: AUS.
6. Ergebnisse werden als CSV/JSON/Markdown in GitHub-Actions-Artefakt gespeichert;
   **keine** Kernel-Images, `boot.img` oder AK3 werden veröffentlicht.

## Sicherheit und Geltungsgrenzen

* OEM 5.4.274 proprietäre `.c`-Quellen lassen sich aus dem Stock-Binary nicht
  verlustfrei rekonstruieren. Die eingebetteten 7717 Header sind **nicht** der
  vollständige Kernelquellbaum. `Module.symvers` des Originalstocks fehlt.
* Der aus R28/R60 bekannte 37-QGKI- und 181-GKI-Modulbestand darf nicht
  gemeinsam als ein einziges zu erfüllendes ABI-Profil behandelt werden.
  Die tatsächlich genutzte Modul-Kohorte ist bislang nicht verifiziert.
* Die in R31 erkannten Importfallen (`module_layout`, `kmem_cache_alloc_trace`,
  `cpumask_next`, `nr_cpu_ids`) werden zuerst über korrekte `CONFIG_`-,
  Header- und Source-Ursprünge erklärt, **nicht** durch künstliche CRCs.
* Keine Änderungen an deinem installierten Kernel, CASS, BakaSU, SUSFS,
  NoMount, Modulen, OEM-Partitionen, Bootslot oder SELinux. **KEIN FLASH**.
* Für die spätere Flashprüfung sind echte `Image`/`Module.symvers`/DTB/DTBO,
  Modulladepfad, AVB und Boot-Validierung erforderlich.

## Hinweise

Der exakte AOSP-Clang-Download kann auf GitHub zeit-/speicherintensiv sein.
Wenn Google-Checkout oder die Git-Tree-Prüfung fehlschlägt, wird die Diagnose
als Fehler dokumentiert und **kein falscher** Vergleich unter GCC als Erfolg
gewertet. Der Workflow lädt auch bei Fehlern die bis dahin entstandenen Logs hoch.

Alle Ergebnisse sind im jeweiligen GitHub-Lauf datiert und SHA-256-auditierbar.
