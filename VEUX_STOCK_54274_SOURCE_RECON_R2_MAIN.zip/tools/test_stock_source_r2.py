#!/usr/bin/env python3
"""Local and CI smoke/negative tests for deterministic R2 source audit."""
import csv
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import stock_source_r2 as r

class R2Tests(unittest.TestCase):
    def test_expected_missing_source_header_count(self):
        self.assertEqual(len(r.EXPECTED_MISSING_SOURCE_HEADERS),12)
    def test_stock_version(self):self.assertEqual(r.STOCK_VERSION,'5.4.274-qgki-g82179e362f33')
    def test_donor_commit(self):self.assertEqual(len(r.PINNED_DONOR_SHA),40)
    def test_clang_tree(self):self.assertEqual(len(r.STOCK_CLANG_TREE),40)
    def test_clang_exact_banner(self):
        x=r.parse_clang('Android (6877366 based on r383902b1) clang version 11.0.2 (source)\nTarget: x86_64')
        self.assertTrue(x['fingerprint_matches_stock'])
    def test_wrong_gcc_rejected(self):self.assertFalse(r.parse_clang('gcc (Ubuntu 13.3.0)')['fingerprint_matches_stock'])
    def test_wrong_llvm18_rejected(self):self.assertFalse(r.parse_clang('clang version 18.0.0')['fingerprint_matches_stock'])
    def test_wrong_bld_rejected(self):self.assertFalse(r.parse_clang('Android (6877367 based on r383902b1) clang version 11.0.2')['fingerprint_matches_stock'])
    def test_bad_version_rejected(self):self.assertFalse(r.parse_clang('Android (6877366 based on r383902b1) clang version 11.0.3')['fingerprint_matches_stock'])
    def test_wrong_branch_rejected(self):self.assertFalse(r.parse_clang('Android (6877366 based on r383902b) clang version 11.0.2')['fingerprint_matches_stock'])
    def test_config_gcc_requires_rejection_by_audit(self):
        import inspect
        source=inspect.getsource(r.audit)
        self.assertIn('DONOR_CONFIG_NOT_RESOLVED_WITH_EXACT_CLANG11',source)
    def test_generated_config(self):self.assertTrue(r.generated('include/config/foo.h'))
    def test_generated_arm(self):self.assertTrue(r.generated('arch/arm64/include/generated/asm/a.h'))
    def test_generated_include(self):self.assertTrue(r.generated('include/generated/autoconf.h'))
    def test_source_header_not_generated(self):self.assertFalse(r.generated('include/linux/rtmm.h'))
    def test_missing_source_class(self):
        t=r.classify_header('include/linux/sched/core_ctl.h','missing')
        self.assertEqual(t['class'],'MISSING_NON_GENERATED_SOURCE_HEADER')
        self.assertEqual(t['priority'],'P0_REVIEW_FOR_OEM_DEPENDENCY')
    def test_generated_not_source_gap(self):
        self.assertEqual(r.classify_header('include/config/auto.conf','missing')['class'],'GENERATED_BUILD_PRODUCT')
    def test_missing_rejected_status(self):
        with self.assertRaises(ValueError):r.classify_header('include/linux/sched.h','lost')
    def test_absolute_rejected(self):
        with self.assertRaises(ValueError):r.classify_header('/etc/passwd','missing')
    def test_traversal_rejected(self):
        with self.assertRaises(ValueError):r.classify_header('../etc/passwd','missing')
    def test_backslash_rejected(self):
        with self.assertRaises(ValueError):r.classify_header('include\\linux\\foo.h','missing')
    def test_critical_walt(self):self.assertEqual(r.classify_config('CONFIG_SCHED_WALT','y','(not present)'),'P0_ABI_KCONFIG_DIFFERENCE')
    def test_critical_tracing(self):self.assertEqual(r.classify_config('CONFIG_TRACING','y','n'),'P0_ABI_KCONFIG_DIFFERENCE')
    def test_oem_option(self):self.assertEqual(r.classify_config('CONFIG_FINGERPRINT_GOODIX_FOD','y','(not present)'),'P0_OEM_SOURCE_OR_KCONFIG_GAP')
    def test_compiler_option(self):self.assertEqual(r.classify_config('CONFIG_CC_IS_CLANG','y','n'),'TOOLCHAIN_PROBE_OR_BUILD_ENV')
    def test_parse_off_flags(self):
        v=r.parse_config(b'CONFIG_FOO=y\n# CONFIG_BAR is not set\nCONFIG_NR_CPUS=32\n')
        self.assertEqual(v,{'CONFIG_FOO':'y','CONFIG_BAR':'n','CONFIG_NR_CPUS':'32'})
    def test_csv_roundtrip(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'test.csv';r.write_csv(p,('a','b'),[{'a':'one','b':'two'}]); self.assertEqual(r.read_csv(p),[{'a':'one','b':'two'}])
    def test_no_automatic_source_patch(self):
        import inspect
        s=inspect.getsource(r.audit)
        for bad in ('copyfile(', 'shutil.copy', 'os.system(', 'subprocess.run(', '0x945d02f2', '0x1e5b7ab7'):
            self.assertNotIn(bad,s)

if __name__=='__main__':unittest.main()
