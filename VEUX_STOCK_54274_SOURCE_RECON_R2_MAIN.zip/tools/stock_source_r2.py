#!/usr/bin/env python3
"""VEUX stock-kernel reconstruction R2: audited source/config/ABI planning ONLY.

Does NOT recover proprietary C sources from a binary, change symbol CRCs,
patch donors, create a boot image, or authorize flashing.

Inputs: immutable R1 MAIN and an independently verified pinned donor checkout;
R1's CSVs must be regenerated from the current donor checkout, not copied from
old report summaries. A stock-toolchain fingerprint is required.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

EXPECTED_MISSING_SOURCE_HEADERS = frozenset({
    'arch/arm64/include/asm/bootinfo.h',
    'include/drm/drm_notifier.h',
    'include/dum/ktrace.h',
    'include/dum/rtmm.h',
    'include/linux/hardware_info.h',
    'include/linux/rtmm.h',
    'include/linux/sched/core_ctl.h',
    'include/linux/units.h',
    'include/linux/wakeup_reason.h',
    'include/trace/events/dcvsh.h',
    'include/trace/events/pagefault.h',
    'include/trace/hooks/restricted_preemptirq.h',
})
GENERATED_PREFIXES = ('include/config/', 'include/generated/',
                      'arch/arm64/include/generated/')
CRITICAL_FLAGS = frozenset({
    'CONFIG_QGKI', 'CONFIG_SCHED_WALT', 'CONFIG_NR_CPUS', 'CONFIG_MODULES',
    'CONFIG_MODVERSIONS', 'CONFIG_CFI_CLANG', 'CONFIG_LTO_CLANG',
    'CONFIG_THINLTO', 'CONFIG_ANDROID_VENDOR_HOOKS', 'CONFIG_IPC_LOGGING',
    'CONFIG_TRACING', 'CONFIG_TRACEPOINTS', 'CONFIG_EVENT_TRACING',
    'CONFIG_KPROBES', 'CONFIG_BPF_EVENTS', 'CONFIG_SHADOW_CALL_STACK',
    'CONFIG_CC_IS_CLANG', 'CONFIG_CLANG_VERSION', 'CONFIG_LD_IS_LLD',
    'CONFIG_LOCALVERSION', 'CONFIG_LOCALVERSION_AUTO',
})
STOCK_VERSION = '5.4.274-qgki-g82179e362f33'
STOCK_CLANG_BUILD = '6877366'
STOCK_CLANG_VERSION = '11.0.2'
STOCK_CLANG_SOURCE = 'r383902b1'
STOCK_CLANG_TREE = '1c7dcc2e7095197f7a05dff22a875b6b02ed7117'
PINNED_DONOR_SHA = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def dump(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + '\n', encoding='utf-8')


def read_csv(path: Path) -> list[dict[str,str]]:
    with path.open('r', newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, cols: tuple[str, ...], rows: list[dict[str,str]]) -> None:
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
        w.writeheader(); w.writerows(rows)


def generated(path: str) -> bool:
    return path.startswith(GENERATED_PREFIXES)


def classify_header(path: str, status: str) -> dict[str,str]:
    if not path or path.startswith('/') or '\\' in path or '..' in path.split('/'):
        raise ValueError('INVALID_HEADER_PATH')
    if status not in ('missing','identical','different'):
        raise ValueError('UNKNOWN_HEADER_STATUS')
    kind = ('GENERATED_BUILD_PRODUCT' if generated(path)
            else ('MISSING_NON_GENERATED_SOURCE_HEADER' if status=='missing'
                  else 'SOURCE_OR_API_DIFFERENCE' if status=='different'
                  else 'BYTE_IDENTICAL'))
    if path in EXPECTED_MISSING_SOURCE_HEADERS:
        priority='P0_REVIEW_FOR_OEM_DEPENDENCY'
    elif path.startswith(('include/linux/sched/', 'include/trace/hooks/', 'include/soc/', 'include/linux/qcom/', 'include/linux/module', 'include/linux/slab', 'include/linux/cpumask', 'include/linux/trace')):
        priority='P1_ABI_SENSITIVE'
    elif path.startswith(('arch/arm64/', 'include/asm-generic/', 'include/linux/')):
        priority='P2_CORE_ABI'
    else: priority='P3_REFERENCE_ONLY'
    return {'class':kind, 'priority':priority}


def parse_config(raw: bytes) -> dict[str,str]:
    opts={}
    for line in raw.decode('utf-8').splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            k,v=line.split('=',1); opts[k]=v
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            opts[line[2:-11]]='n'
    return opts


def classify_config(flag: str, stock: str, actual: str) -> str:
    if flag.startswith(('CONFIG_CC_', 'CONFIG_CLANG_', 'CONFIG_GCC_', 'CONFIG_LD_', 'CONFIG_BROKEN_GAS_', 'CONFIG_HAVE_ARCH_PREL32_')):
        return 'TOOLCHAIN_PROBE_OR_BUILD_ENV'
    if flag in CRITICAL_FLAGS:
        return 'P0_ABI_KCONFIG_DIFFERENCE'
    if any(k in flag for k in ('FINGERPRINT', 'MIUI', 'MI_', 'QTI_', 'RTMM', 'QGKI', 'WALT', 'MILLET', 'HARDWARE_INFO', 'CORE_CTL')):
        return 'P0_OEM_SOURCE_OR_KCONFIG_GAP'
    if stock=='(not present)' or actual=='(not present)':
        return 'KCONFIG_SOURCE_TREE_DIFFERENCE'
    return 'CONFIG_VALUE_DIFFERENCE'


def parse_clang(version: str) -> dict:
    valid=(('clang version 11.0.2' in version)
           and ('6877366' in version)
           and ('r383902b1' in version))
    return {'target_version':STOCK_CLANG_VERSION,
            'target_build':STOCK_CLANG_BUILD,
            'target_branch':STOCK_CLANG_SOURCE,
            'pinned_git_tree':STOCK_CLANG_TREE,
            'observed_banner':version.strip().splitlines()[0] if version.strip() else '',
            'fingerprint_matches_stock':bool(valid)}


def audit(r1_main: Path, r1_reports: Path, clang_file: Path, out: Path) -> dict:
    r1_main, r1_reports, clang_file, out = map(Path, (r1_main,r1_reports,clang_file,out))
    out.mkdir(parents=True,exist_ok=True)
    meta=json.loads((r1_main/'reference/stock_provenance.json').read_text(encoding='utf-8'))
    assert meta['schema']=='VEUX_STOCK_54274_SOURCE_REFERENCE_R1'
    assert meta['donor_commit']==PINNED_DONOR_SHA
    assert meta['release']==STOCK_VERSION
    assert meta['source_tree_original_complete'] is False
    original=(r1_main/'reference/stock.config').read_bytes()
    assert sha(original)==meta['stock_config_sha256'], 'STOCK_CONFIG_SHA_DRIFT'
    stock=parse_config(original)
    toolchain=parse_clang(clang_file.read_text(encoding='utf-8'))
    if not toolchain['fingerprint_matches_stock']:
        raise ValueError('WRONG_STOCK_CLANG_FINGERPRINT: '+toolchain['observed_banner'])

    r1=json.loads((r1_reports/'STOCK_SOURCE_REPRO_REPORT.json').read_text())
    if not r1.get('stock_reference_verified') or r1.get('donor_commit')!=PINNED_DONOR_SHA:
        raise ValueError('R1_REPORT_PROVENANCE_FAILED')
    if r1.get('reference_header_files')!=7717:
        raise ValueError('R1_WRONG_HEADER_COUNT')
    headers=read_csv(r1_reports/'ALL_7717_Stock_vs_Donor_headers.csv')
    if len(headers)!=7717 or len({x['path'] for x in headers})!=7717:
        raise ValueError('HEADER_CSV_INVALID')
    results=[]
    for row in headers:
        tag=classify_header(row['path'],row['status'])
        results.append({**row, **tag})
    tally=Counter((x['status'],x['class']) for x in results)
    known=[x['path'] for x in results if x['class']=='MISSING_NON_GENERATED_SOURCE_HEADER']
    if frozenset(known) != EXPECTED_MISSING_SOURCE_HEADERS:
        raise ValueError('NON_GENERATED_MISSING_HEADER_SET_CHANGED')
    if sum(x['class']=='GENERATED_BUILD_PRODUCT' and x['status']=='missing' for x in results)!=2040:
        raise ValueError('GENERATED_MISSING_COUNT_CHANGED')
    write_csv(out/'R2_7717_HEADERS_CLASSIFIED.csv',
              ('path','status','class','priority','stock_sha256','donor_sha256','stock_size','donor_size'),results)
    write_csv(out/'R2_12_MISSING_SOURCE_HEADERS.csv',
              ('path','status','class','priority','stock_sha256','donor_sha256','stock_size','donor_size'),
              [x for x in results if x['class']=='MISSING_NON_GENERATED_SOURCE_HEADER'])
    source_sensitive=[x for x in results if x['class']=='SOURCE_OR_API_DIFFERENCE' and x['priority'] in ('P1_ABI_SENSITIVE','P2_CORE_ABI')]
    write_csv(out/'R2_ABI_SENSITIVE_DIFFERENT_HEADERS.csv',
              ('path','status','class','priority','stock_sha256','donor_sha256','stock_size','donor_size'),source_sensitive)

    old=read_csv(r1_reports/'Stock_vs_Donor_olddefconfig.csv')
    new_config=(r1_reports/'Donor_olddefconfig.config').read_bytes()
    donor_opts=parse_config(new_config)
    if donor_opts.get('CONFIG_CC_IS_CLANG')!='y' or donor_opts.get('CONFIG_CLANG_VERSION')!='110002':
        raise ValueError('DONOR_CONFIG_NOT_RESOLVED_WITH_EXACT_CLANG11')
    if len({x['option'] for x in old})!=len(old):
        raise ValueError('R1_OLDDEFCONFIG_CSV_INVALID')
    real_diffs=[{'option':key,'stock':stock.get(key,'(not present)'),
                 'donor_olddefconfig':donor_opts.get(key,'(not present)')}
                for key in sorted(set(stock)|set(donor_opts))
                if stock.get(key)!=donor_opts.get(key)]
    if [(r['option'],r['stock'],r['donor_olddefconfig']) for r in real_diffs] != \
       [(r['option'],r['stock'],r['donor_olddefconfig']) for r in old]:
        raise ValueError('R1_CONFIG_DIFF_CSV_AND_CONFIG_DISAGREE')
    for row in real_diffs:
        row['class']=classify_config(row['option'],row['stock'],row['donor_olddefconfig'])
    write_csv(out/'R2_CLANG11_CONFIG_DIFFERENCES.csv',
              ('option','stock','donor_olddefconfig','class'), real_diffs)
    critical=[x for x in real_diffs if x['class'] in ('P0_ABI_KCONFIG_DIFFERENCE','P0_OEM_SOURCE_OR_KCONFIG_GAP')]
    write_csv(out/'R2_CRITICAL_CONFIG_BLOCKERS.csv',
              ('option','stock','donor_olddefconfig','class'),critical)
    critical_expected={k:v for k,v in stock.items() if k in CRITICAL_FLAGS}
    changed_critical={k:{'stock':v, 'donor':donor_opts.get(k,'(not present)')}
                      for k,v in critical_expected.items() if donor_opts.get(k)!=v}
    write_csv(out/'R2_CRITICAL_ABI_CONFIG_STOCK.csv',
              ('option','stock'),[{'option':k,'stock':v} for k,v in sorted(critical_expected.items())])
    r2={
      'schema':'VEUX_STOCK_54274_SOURCE_R2_DIAGNOSTIC',
      'stock_reference_validated':True,
      'pinned_donor_validated_by_r1':True,
      'stock_release':STOCK_VERSION,
      'stock_config_sha256':meta['stock_config_sha256'],
      'compiler':toolchain,
      'headers_total':len(headers),
      'headers_missing_total':sum(x['status']=='missing' for x in results),
      'headers_missing_generated':2040,
      'headers_missing_source':len(known),
      'headers_missing_source_paths':sorted(known),
      'headers_different':sum(x['status']=='different' for x in results),
      'headers_identical':sum(x['status']=='identical' for x in results),
      'abi_sensitive_header_differences':len(source_sensitive),
      'stock_config_vs_clang11_donor_olddefconfig_differences':len(real_diffs),
      'critical_config_difference_count':len(critical),
      'critical_abi_config_mismatches':changed_critical,
      'oem_module_cohort_confirmed':False,
      'stock_kernel_source_reproduced':False,
      'stock_compiled_image_reproduced':False,
      'stock_module_symvers_available':False,
      'oem_vendor_abi_green':False,
      'flash_allowed':False,
      'status':'R2_EXACT_TOOLCHAIN_AND_SOURCE_GAPS_DIAGNOSTIC_ONLY'
    }
    dump(out/'R2_ANALYSIS.json',r2)
    gate={
      'STOCK_REFERENCE_PROVENANCE':True,
      'DONOR_SOURCE_GIT_PIN':True,
      'STOCK_CLANG_11_0_2_FINGERPRINT':toolchain['fingerprint_matches_stock'],
      'STOCK_CONFIG_EXACT':not real_diffs,
      'STOCK_SOURCE_GAPS_CLOSED':not known and not source_sensitive,
      'VERIFIED_STOCK_5_4_274_COMPILATION':False,
      'MATCHED_LOADED_VENDOR_MODULE_COHORT':False,
      'OEM_CRC_AND_EXPORTS_GREEN':False,
      'DTB_DTBO_BOOT_AK3_DEVICE_PROVEN':False,
      'FLASH_ALLOWED':False
    }
    dump(out/'R2_RELEASE_GATE.json',gate)
    human=[
        '# VEUX R2: Stock-Referenz zu Source-Kandidat (NOFLASH)', '',
        f'- Original-Boot-Header-Referenz: {len(headers)} Header (belegt durch R1-SHA und erneute Auswertung).',
        f'- Fehlende Header insgesamt: {r2["headers_missing_total"]}. Davon 2040 GENERATED, 12 echte Quellheader.',
        f'- Abweichende Originalheader: {r2["headers_different"]}, exakt gleiche: {r2["headers_identical"]}.',
        f'- ABI-sensitive geänderte Header (Heuristik): {len(source_sensitive)}; KEIN Nachweis, welche CRCs dadurch entstehen.',
        f'- Clang11-verifizierter Kconfig-Drift: {len(real_diffs)} Optionen; Kritische OEM/KABI-Flags: {len(critical)}.',
        '- Prüftakt: Quelllücken / Scheduler WALT / QGKI / Vendor-Exports / RMNET priorisieren.',
        '- R1 war GCC; R2 fordert exakt Android Clang 11.0.2 (6877366), gepinnter AOSP Git-Tree.',
        '- Weder fehlende Header noch CRC-Felder werden automatisch eingefügt. Kein Boot-/Flash-Artefakt.',
        '- Die historischen 218 Module aus GKI/QGKI sind NICHT als gleichzeitig zu ladende Kohorten bewiesen.',
        '- BEVOR ABI-GREEN: aktive Kohorte durch Boot-Laderegeln belegbar machen; passende original .ko importieren;',
        '  echtes Module.symvers des finalen gebauten Kandidaten vergleichen; vollständige exports/CRC je benötigtem Modul.',
        '', '## Fehlende nichtgenerierte Header',
    ]+['- `'+n+'`' for n in sorted(known)]+[
       '', '## Kritische Konfigurationsabweichungen (max. 50)',
    ]+['- `'+x['option']+'`: stock='+x['stock']+' vs donor='+x['donor_olddefconfig'] for x in critical[:50]]+[
       '', 'STATUS: NOFLASH. Der echte OEM-Quellcode ist nicht durch das Stock-Binary rekonstruiert.',
    ]
    (out/'R2_PLAN_DE.md').write_text('\n'.join(human)+'\n',encoding='utf-8')
    print(json.dumps({'R2_STATUS':r2['status'],'SOURCE_MISSING':len(known),'GENERATED_MISSING':2040,
                      'OLDDEFCONFIG_DIFF':len(real_diffs),'FLASH_ALLOWED':False},ensure_ascii=False,sort_keys=True))
    return r2


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--r1-main',type=Path,required=True)
    p.add_argument('--r1-reports',type=Path,required=True)
    p.add_argument('--clang-version-file',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    x=p.parse_args()
    audit(x.r1_main,x.r1_reports,x.clang_version_file,x.out)

if __name__=='__main__':main()
