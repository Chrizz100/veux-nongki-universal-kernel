# VEUX M48 · vollständiger QGKI-Kernelbau mit Verity-Patch

Die MAIN.zip wird im Stamm von Chrizz100/veux-nongki-universal-kernel abgelegt, die VEUX_M48_FULL_KERNEL_NOFLASH.yml unter .github/workflows/. Der Workflow startet manuell auf main. Alle Vorgänge laufen auf dem GitHub-Runner. Er schreibt keine Partition und stellt keine Flash-Freigabe aus.

## Eingaben und Herkunft

- M44, Lauf 44879323567, Commit c6422396319d302feab5dd6c506b489a5ae29847: Vollbau mit den bisherigen Reparaturen, Original-AK3-Rahmen und Referenz für die Vendor-ABI.
- M45, Lauf 44885785447: lesender AK3-Einstieg mit dem mitgelieferten ARM-magiskboot. Die Vorlage ist als SHA-geprüfte Original-ZIP beigefügt.
- M46, Lauf 44901355794: Stock-boot.img mit der auf dem POCO bestätigten Prüfsumme und UFS-Referenz für Overlay 0.
- M47, Lauf 44902841859: 90 bestandene RAM-Tests und relocatierbarer Verity-Treiber. In M48 wird der zugehörige Quellpatch neu mit dem Kernel kompiliert. Das M47-Objekt dient als Prüfnachweis.

## Ablauf

1. M44-Rezept am belegten Commit rekonstruieren und den M44-Kontrollkernel auf demselben Runner prüfen. Die bisherigen Compiler- und Quellprüfungen werden übernommen. Der Workflow fasst die Ausgaben für M48 zusammen.
2. Die geprüften Vorversionen der Verity-Dateien abgleichen, M47 anwenden und über scripts/config und olddefconfig die eine Option CONFIG_DM_VERITY_AVB aktivieren.
3. Im vollständigen M44-Quell- und Objektbaum die regulären Kbuild-Ziele Image, dtbs und modules mit denselben Compilerargumenten ausführen. Kbuild kann vorhandene Objekte verwenden. M48 verlangt die tatsächliche Übersetzung des neuen Treibers und einen neuen Link des Kernels.
4. .config, Autoconf, das eingebettete IKCONFIG in vmlinux und Image, die Kernelkennung, den Handler, UFS, DTBs, frühere Ladetreiber-Reparaturen und die Module prüfen. Die Vendor-CRC-Prüfung liest die neu erzeugte Module.symvers und bewertet 1.423 verschiedene Symbole sowie 3.148 Importe aus 37 Stock-Modulen.
5. Aus Stock-Header und Stock-Ramdisk ein Boot-Abbild mit dem neuen Image erzeugen. Den M45-AK3-Einstieg mit dessen echtem ARM-Werkzeug und simulierten Boot-Dateien für Slot A und B ausführen. Beide Ergebnisse müssen bytegenau mit dem unabhängig erzeugten Abbild übereinstimmen. Drei ungeeignete Eingaben müssen scheitern. Die externe Xiaomi-vbmeta wird ausschließlich als signierte Referenz gelesen.

Ein erfolgreicher Lauf liefert den Nachweis und ein Boot/AK3-Prüfpaar. Die AK3 erstellt auf einer geprüften Stock-Basis eine Vergleichsdatei. Die auf dem POCO tatsächlich gebundenen UFS-Treiber, das Ziel des Verity-Fehlerpfads, der Start des Kandidaten und ein unabhängiger Rückweg ohne PC sind getrennt offen. Die Quelldatei des M47-Patches dokumentiert die begrenzte Wartezeit im Fehlerpfad. Es gibt keine Flash-Funktion im Prüf-Einstieg.

## Prüfstand der Vorbereitung

Der Paketweg wurde lokal mit dem M44-Kernel, der authentischen Stock-Datei und dem ARM-magiskboot geprüft. Das Boot-Abbild stimmt bytegenau mit dem bereits geprüften M44-Abbild überein. Dieser Kontrollversuch und der Test einer über eine Seitengrenze geänderten Image-Größe sind Vorabtests. Das Ergebnis des M48-Vollbaus entsteht erst beim Workflow-Lauf.
