"""Integrate the M47 source into the verified, live M44 kernel build tree."""

import argparse
import hashlib
import importlib.util
import io
import json
import mmap
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

import m25_config as cfg
from package_pair import create_pair, need

ROOT = Path(__file__).resolve().parent
REL = "5.4.274-qgki-g82179e362f33"
M46 = "e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164"
M47 = "922c39b00993bf89bd5813e52ca2b0a27a8e9ca82e96748bfe2fe977334ca0e0"
STOCK = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
AK3 = "b02bbd3a093371f1019fe26c7213de11c2bcfe063dc93b5b0fc4506697df175f"
ABI_ENGINE = "d9951a9909ffdda8dd92baa181d268a35c480443edd9ad0d8e52c2ed9dff741d"
R6_ENGINE = "561d4b147d3752996b2d715084fd65dc3c53e34ef876c571fcb858d675083003"
PATCH_SHA = "60e9211b887bb0128cda287af50bec61572477dc845d2b2a173a41f96ff7b5fa"
CFG_SHA = "c6f842ddf24f496cea367803d2916a17896f221288932e0947de65b66941439a"
IMAGE = "arch/arm64/boot/Image"


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def load(path, digest):
    need(sha(path) == digest, "Upstream engine changed: " + str(path))
    spec = importlib.util.spec_from_file_location(Path(path).stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_inputs(m46, m47, stock):
    need(sha(m47) == M47 and sha(m46) == M46, "Wrong M46 or M47 artifact")
    with zipfile.ZipFile(m47) as z:
        report = json.loads(z.read("M47_RESULT.json"))
        obj = z.read("dm-verity-arm64-relocatable.o")
        need(
            report["kernel_release"] == REL
            and report["m47_with_handler"]["avb_call"]
            and report["native_test"] == "90 mock cases passed"
            and hashlib.sha256(obj).hexdigest()
            == report["m47_with_handler"]["arm64_driver_sha256"],
            "M47 CI proof missing",
        )
    with zipfile.ZipFile(m46) as z:
        result = json.loads(z.read("M46_ERGEBNIS.json"))
        need(
            result["ufs"]["matching_overlay_indices"] == [0]
            and result["ufs"]["matching_historical_nodes"] == 27
            and result["stock"] == STOCK,
            "Wrong M46 reference",
        )
        with (
            zipfile.ZipFile(
                io.BytesIO(z.read("VEUX_M46_Stock_und_Geraetecheck.zip"))
            ) as nested,
            nested.open("boot.img") as src,
            stock.open("xb") as dest,
        ):
            shutil.copyfileobj(src, dest)
    need(sha(stock) == STOCK, "Invalid stock boot image")


def patch_source(source):
    pins = json.loads((ROOT / "sources.json").read_text())
    need(
        all(
            sha(source / "drivers/md" / name) == digest for name, digest in pins.items()
        ),
        "Verity source differs from M47 preimages",
    )
    need(
        not (source / "drivers/md/dm-verity-avb.c").exists(),
        "AVB handler already exists",
    )
    patch = ROOT / "M47-stock-verity.patch"
    need(sha(patch) == PATCH_SHA, "M47 patch mismatch")
    cmd = ["patch", "--batch", "--forward", "--fuzz=0", "-p1", "-i", str(patch)]
    for flag in (["--dry-run"], []):
        subprocess.run(cmd + flag, cwd=source, check=True)


def tree_dtbs(out):
    base = out / "arch/arm64/boot/dts"
    return {
        str(f.relative_to(base)): sha(f)
        for f in sorted(base.rglob("*.dtb*"))
        if f.suffix in {".dtb", ".dtbo"} and f.is_file()
    }


def config_delta(before, after):
    old = cfg.config_values(before)
    new = cfg.config_values(after)
    changes = {
        k: (old.get(k), new.get(k))
        for k in old.keys() | new.keys()
        if old.get(k) != new.get(k)
    }
    need(
        changes == {"CONFIG_DM_VERITY_AVB": (None, "y")},
        "Unexpected effective config delta: " + str(changes),
    )
    return changes


def check_abi(tool, symvers, evidence):
    abi = load(tool, ABI_ENGINE)
    expected, imports = abi.references()
    rows, modules, counts = abi.compare(abi.parse_symvers(symvers), expected, imports)
    abi.save_csv(evidence / "M48_QGKI_SYMBOLS.csv", rows)
    abi.save_csv(evidence / "M48_QGKI_MODULES.csv", modules)
    matched = sum(row["fully_compatible"] for row in modules)
    need(
        counts == {"MATCH": 1423, "CRC_MISMATCH": 0, "NOT_EXPORTED": 0}
        and len(modules) == matched == 37
        and len(imports) == 3148,
        "M48 vendor ABI mismatch; see both CSV reports",
    )
    return {
        "matched_symbols": 1423,
        "module_imports_checked": len(imports),
        "matched_vendor_modules": matched,
    }


def kbuild(commands, src, out, runner, logs):
    for target in ("olddefconfig", "Image", "dtbs", "modules"):
        cmd = commands[target]
        need(
            cmd[0] == "make"
            and cmd.count("-C") == 1
            and cmd[cmd.index("-C") + 1] == str(src)
            and cmd.count("O=" + str(out)) == 1
            and cmd[-1] == target,
            "M44 build invocation changed",
        )
        print("Kbuild", target, flush=True)
        path = logs / (target + ".log")
        with path.open("w") as f:
            ret = subprocess.run(
                cmd,
                env=runner.pinned_llvm_tool_env(cmd),
                stdout=f,
                stderr=subprocess.STDOUT,
            )
        if ret.returncode:
            print(path.read_text(errors="replace")[-6500:], flush=True)
            ret.check_returncode()
        if target == "olddefconfig":
            config_delta(
                (logs / "baseline.config").read_bytes(), (out / ".config").read_bytes()
            )
    log = (logs / "Image.log").read_text(errors="replace")
    need(
        "drivers/md/dm-verity-avb.o" in log
        and "vmlinux" in log
        and "arch/arm64/boot/Image" in log,
        "Missing actual ARM64 compilation or link traces",
    )
    need(
        "ld.lld: warning:" not in log and "llvm-nm: not found" not in log,
        "Unexpected link/toolchain warning",
    )


def product_proof(build, out, commands, original, dtbs):
    config = (out / ".config").read_bytes()
    delta = config_delta(original, config)
    proof = cfg.audit_build(build, strict=False)
    need(
        (out / "include/config/kernel.release").read_text().strip() == REL
        and (out / "include/generated/utsrelease.h").read_text().split('"')[1] == REL,
        "QGKI release mismatch",
    )
    nm = next(x[3:] for x in commands["Image"] if x.startswith("NM="))
    for obj, kind in [("dm-verity-target.o", "U"), ("dm-verity-avb.o", "T")]:
        symbols = subprocess.check_output(
            [nm, str(out / "drivers/md" / obj)], text=True
        )
        need(
            any(
                row.split()[-2:] == [kind, "dm_verity_avb_error_handler"]
                for row in symbols.splitlines()
            ),
            "Missing real Kbuild reference/definition: " + obj,
        )
    for name in [IMAGE, "vmlinux"]:
        with (
            (out / name).open("rb") as f,
            mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as blob,
        ):
            for marker in [
                b"androidboot.vbmeta.invalidate_on_error\0",
                b"androidboot.vbmeta.device\0",
                b"AVB error handler called for",
                b"qcom,ufshc\0",
                b"qcom,ufs-phy-qmp-v4-yupik\0",
                b"bq2589x: fault settings restore failed",
                b"bq2589x: monitor hiz snapshot failed",
                b"bq2589x: monitor hiz restore superseded",
                ("Linux version " + REL + " (").encode(),
            ]:
                need(
                    blob.find(marker) >= 0,
                    "Missing marker in " + name + ": " + repr(marker),
                )
    need(
        dtbs and tree_dtbs(out) == dtbs,
        "M48 DTB set/content diverges from its M44 control",
    )
    return {
        "release": REL,
        "config_delta": delta,
        "embedded_config_proof": proof,
        "m44_identical_dtbs": dtbs,
        "m47_handler_in_full_kernel": True,
    }


def perform(args):
    build = args.build.resolve()
    src = build / "candidate-source"
    out = build / "candidate-out"
    result = args.result.resolve()
    evidence = result / "evidence"
    evidence.mkdir(parents=True)
    stock = args.stock.resolve()
    old = json.loads((build / "M44_RESULT.json").read_text())
    need(
        old["kernel_compiled"]
        and old["fully_matching_modules"] == 37
        and old["release"]["verified_release"] == REL
        and not old["flash_allowed"],
        "Live M44 control failed",
    )
    need(
        all(
            sha(out / name) == digest
            for name, digest in old["kernel_product_hashes"].items()
        ),
        "Live control products changed",
    )
    need(
        sha(out / ".config") == CFG_SHA and sha(stock) == STOCK,
        "Wrong control config or stock file",
    )
    baseline = (out / ".config").read_bytes()
    (evidence / "baseline.config").write_bytes(baseline)
    dtbs = tree_dtbs(out)
    commands = {
        r["target"]: r["invocation"]
        for r in json.loads((build / "R16_RESULT.json").read_text())["make_results"]
    }
    runner = load(args.r6, R6_ENGINE)
    patch_source(src)
    fragment = (ROOT / "veux-m47.config").read_text()
    need(fragment == "CONFIG_DM_VERITY_AVB=y\n", "Invalid fragment")
    # scripts/config keeps the full live configuration as its base.
    subprocess.run(
        [
            "bash",
            src / "scripts/config",
            "--file",
            out / ".config",
            "-e",
            "DM_VERITY_AVB",
        ],
        check=True,
    )
    kbuild(commands, src, out, runner, evidence)
    proof = product_proof(build, out, commands, baseline, dtbs)
    need(
        sha(out / IMAGE) != old["kernel_product_hashes"][IMAGE]
        and sha(out / "vmlinux") != old["kernel_product_hashes"]["vmlinux"],
        "Stale M44 binary",
    )
    proof.update(check_abi(args.abi, out / "Module.symvers", evidence))
    for module in old["release"]["artifacts"]:
        if module["file"].endswith(".ko"):
            need(
                ("vermagic=" + REL + " ").encode()
                in (out / module["file"]).read_bytes(),
                "Module vermagic mismatch: " + module["file"],
            )
    for name in [".config", "Module.symvers", "System.map", "vmlinux", IMAGE]:
        shutil.copyfile(
            out / name,
            evidence / ("kernel.config" if name == ".config" else Path(name).name),
        )
    (evidence / "M48_BUILD.json").write_text(json.dumps(proof, indent=2) + "\n")
    # Use the authenticated review framework, independent of boot timestamps on this runner.
    original = args.template.read_bytes()
    need(hashlib.sha256(original).hexdigest() == AK3, "Wrong frozen AK3")
    with tempfile.TemporaryDirectory(dir=result) as tmp:
        pair = Path(tmp) / "pair"
        pair_proof = create_pair(
            (out / IMAGE).read_bytes(), original, stock, args.qemu, pair
        )
        report = {
            "M47_run": 44902841859,
            "full_kernel": True,
            "ABI": {
                k: proof[k]
                for k in (
                    "matched_symbols",
                    "module_imports_checked",
                    "matched_vendor_modules",
                )
            },
            "kernel_release": REL,
            "pair": pair_proof,
            "ufs_probe_on_phone": False,
            "physical_verity_target_known": False,
            "independent_pc_free_rollback": False,
            "device_pass": False,
            "flash_allowed": False,
        }
        (pair / "M48_RESULT.json").write_text(json.dumps(report, indent=2) + "\n")
        os.rename(pair, result / "review")
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    subs = cli.add_subparsers(dest="action", required=True)
    verify = subs.add_parser("inputs")
    for key in ("m46", "m47", "stock"):
        verify.add_argument("--" + key, type=Path, required=True)
    build = subs.add_parser("build")
    for key in ("build", "r6", "abi", "result", "stock", "template", "qemu"):
        build.add_argument("--" + key, type=Path, required=True)
    args = cli.parse_args()
    if args.action == "inputs":
        read_inputs(args.m46, args.m47, args.stock)
    else:
        perform(args)
