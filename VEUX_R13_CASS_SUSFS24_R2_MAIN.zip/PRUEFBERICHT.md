# VEUX R13-CASS · SUSFS 2.4 R2

26. November 2026 · POCO X4 Pro 5G · HyperOS Global OS1.0.12.0.TKCMIXM

**Gerätestatus.** R13-CASS hat den Gerätepass. Für R2 sind der lokale ARM64-Bau und die statischen Nachweise abgeschlossen. Gerätepass und Flash-Freigabe für R2 stehen aus. Der Hänger an der PIN wurde an späteren Testbuilds beobachtet.

## Nachgewiesener Fehler und Korrektur

Die SUSFS-Statusabfrage übernahm den bisherigen Benutzerpuffer in die Antwort. Ein wiederverwendeter Puffer konnte nach der letzten gültigen Zeile noch alte Bytes enthalten. Die korrigierte Funktion baut die Antwort aus dem nullinitialisierten Kernelpuffer auf. Der Nachtest erhält die zehn erwarteten Zeilen und prüft auch den Fehler bei fehlendem Speicher. Die frühere 9-von-10-Anzeige gehört zum SUSFS-2.3-Stand.

LLDB bestätigte am neuen Image alle zehn Statuseinträge sowie den Ausgabeaufruf. Die Negativkontrolle am echten GitHub-Artefakt erkennt den bisherigen Eingabekopierpfad. Der korrigierte Quellbaum ändert ausschließlich die Antwort in `fs/susfs.c`. Der Bau nutzt die gepinnte R13-Basis mit BakaSU 35254 und NoMount Kernel-API 22. [GitHub-Lauf 45850370375](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45850370375/job/140014859598)

## 5.4-Quellenabgleich

Die Referenzen von JackA1ltman und cyberc3dr führen denselben 5.4-Patch mit 21 Dateipfaden und Git-Blob `21a0bfee96231d890d5dd667fee908df13a417e4`. Im R13-Port stimmen die Patchkontexte zweier Dateien wörtlich überein. Andere Kontexte können dieselbe Funktion anders umsetzen. Die R13-Variante nutzt den QGKI-5.4-Stand von Midori `7a82d707` mit Anpassungen für den vorhandenen R13-Quellbaum. Beide GitHub-Prüfbauten liefern dasselbe Image, dieselbe Konfiguration und denselben Gerätebaum. [JackA1ltman](https://github.com/JackA1ltman/NonGKI_Kernel_Build_2nd/tree/ec069a4e34f992d602a6b40d2e211df2516e2865) · [cyberc3dr](https://github.com/cyberc3dr/nGKI_Kernel_Build/tree/1ae6e01ac7df095942985fa79223aaa3b5f81174) · [Midori QGKI-5.4](https://github.com/midori01/susfs4ksu/tree/7a82d7073222f88b256b30e90e9db2db4c5df56d)

Der separate Upstream-Steuerbefehl für SUS_PATH-UIDs hat im verwendeten BakaSU-Stand keinen Aufrufpfad. Der Code ist im R13-Quellbaum und im gelinkten ELF vorhanden. Der zehnte Statuseintrag gehört zum Prioritäts-UID-Filter. Vollständige Upstream-Abdeckung steht offen. [Upstream-Änderung](https://github.com/midori01/susfs4ksu/commit/571a73e451372ff7f10d2f0236ef8dc057ec70b2)

## Bau, LLDB und Stockabgleich

- Der lokale Bau erzeugte `Image`, Debug-ELF und DTB. Die eingebettete Konfiguration stimmt bytegenau mit der Baukonfiguration überein. Die bekannte Ausgabe von Modpost zu zwei statisch exportierten Symbolen steht im Bauprotokoll.
- LLDB hat 5.868.864 ARM64-Wörter in allen fünf dateigestützten ausführbaren Abschnitten gegen das Image geprüft. In 21 Funktionen wurden 2.055 Wörter gezielt abgeglichen. Dazu gehören Kernelstart, Goodix-Touch, DSI-Display, Wakeup und der Dateiwächter. Der Test des Dateiwächters deckt acht Einrichtungsfehler, Wiederholung und gleichzeitiges Aufräumen ab.
- Alle 12.947 Einträge der Modulschnittstelle und der komplette Gerätebaum entsprechen R13. In der Bootlayout-Gegenprobe blieben R13-Ramdisk, Kommandozeile und OS-Felder bytegleich. Die Prüfsummen von Stock-`boot` und `vendor_boot` entsprechen den Metadaten der originalen VEUX-Global-OTA.
- Bei den 3.148 Importzeilen der 37 Xiaomi-Originalmodule ergibt der statische Stockabgleich für R13 und R2 dieselben Zahlen. 1.303 Kernel-CRCs stimmen überein, 1.752 weichen ab und 93 Symbole fehlen in der Kernel-Exportliste.

| Referenz | Verglichene ARM64-Wörter | Abweichende Wörter an gleicher Abschnittsposition | Bytegleiche gemeinsame Textbereiche |
| --- | ---: | ---: | ---: |
| Xiaomi Stock / Global-OTA | 5.698.918 | 5.687.177 | 3.342 / 46.789 |
| Gerätebestätigter R13-CASS | 5.817.056 | 5.707.046 | 16.156 / 62.986 |
| Gerätebestätigter ConfigDiag10 | 5.810.769 | 5.783.165 | 14.275 / 62.560 |
| GitHub 45850370375 | 5.868.864 | 4.405.413 | 19.257 / 63.006 |

Bei GitHub 45850370375 und R2 sind die fünf ausführbaren Abschnitte gleich groß und `.head.text` ist bytegleich. 48.138 gemeinsame Symbolnamen liegen nach dem erneuten Linken an einer anderen Adresse. Layout, Ausrichtung und Adressoperanden beeinflussen den Positionsvergleich. Laufzeitfehler lassen sich aus diesem Zähler allein nicht ableiten.

**SHA-256 des lokalen R2-Images** `9bd258697e501e3c4aab2054b5393ba42daf2ee2cd7a4bcb52614f8af12447d3`
