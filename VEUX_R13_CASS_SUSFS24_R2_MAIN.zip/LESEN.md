# R13-CASS · SUSFS 2.4 R2

Lege `VEUX_R13_CASS_SUSFS24_R2_MAIN.zip` in den obersten Ordner des Repositories und `VEUX_R13_CASS_SUSFS24_R2_NOFLASH.yml` unter `.github/workflows/`. Die Dateien gehören zusammen.

Der manuelle Workflow **VEUX R13 CASS · SUSFS 2.4 R2 Statusprüfung · NOFLASH** holt die Basis aus dem Commit des geprüften GitHub-Laufs und verifiziert beide Archivprüfsummen. Er testet die Statuskorrektur, baut damit den ARM64-Kernel und veröffentlicht die Prüfnachweise.

Der [Prüfbericht](PRUEFBERICHT.md) enthält den lokalen Bau, die Quellabweichungen sowie den LLDB- und Stockabgleich. Gerätepass und Flash-Freigabe für R2 stehen aus.
