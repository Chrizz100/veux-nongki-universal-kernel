#!/usr/bin/env bash
# VEUX / Linux 5.4.274 P11: first source-only, WALT=n baseline compiler gate.
# NEVER makes boot.img or AK3; NEVER writes GitHub, flashes, or loads modules.
set -Eeuo pipefail
export LC_ALL=C TZ=UTC ARCH=arm64
: "${GITHUB_WORKSPACE:?}" "${RUNNER_TEMP:?}" "${P11_TOOLCHAIN_DIR:?}"
ROOT="$(realpath "$GITHUB_WORKSPACE")"
KERNEL="$ROOT/kernel"
OUT="$RUNNER_TEMP/veux-p11-274-out"
EVIDENCE="$RUNNER_TEMP/VEUX_274_P11_EVIDENCE"
REPORT="$EVIDENCE/P11_BUILD_STATUS.json"
mkdir -p "$EVIDENCE/logs"
fail_status() {
    local rc=$?
    if (( rc != 0 )); then
        printf '{"kernel":"5.4.274","WALT":"OFF","compile":"FAIL","exit_code":%d,"flashable":false}\n' "$rc" > "$REPORT"
    fi
}
trap fail_status EXIT
[[ "$KERNEL" == "$ROOT/kernel" ]] || exit 2
[[ -d "$KERNEL/.git" ]] || { echo 'SOURCE_NOT_A_GIT_TREE' >&2; exit 2; }
[[ ! -e "$OUT" ]] || { echo 'REFUSE_EXISTING_OUT' >&2; exit 2; }
[[ -d "$P11_TOOLCHAIN_DIR/bin" ]] || { echo 'MISSING_PINNED_CLANG' >&2; exit 2; }
export PATH="$P11_TOOLCHAIN_DIR/bin:$PATH"
clang --version | tee "$EVIDENCE/logs/clang.txt"
clang --version | grep -Fq 'r416183b' || { echo 'CLANG_NOT_PINNED' >&2; exit 2; }
ld.lld --version | tee -a "$EVIDENCE/logs/clang.txt"
[[ "$(make -s -C "$KERNEL" kernelversion)" == '5.4.274' ]] || { echo 'KERNEL_NOT_5.4.274' >&2; exit 2; }
python3 - "$RUNNER_TEMP/VEUX_274_P11_PREP/P11_PREP_REPORT.json" "$KERNEL" <<'PY'
import json,pathlib,subprocess,sys
report=json.loads(pathlib.Path(sys.argv[1]).read_text())
expected=report['source_p11_composed_tree']
actual=subprocess.check_output(['git','-C',sys.argv[2],'rev-parse','HEAD^{tree}'],text=True).strip()
assert expected==actual, (expected,actual)
assert report['walt_enabled'] is False
assert report['flashable'] is False
assert report['changed_path_count']==24
PY
mkdir -p "$OUT"
export KBUILD_BUILD_USER='veux-stock274' KBUILD_BUILD_HOST='p11-baseline'
export KBUILD_BUILD_TIMESTAMP='Thu Sep 03 00:00:00 UTC 2026'
export KBUILD_BUILD_VERSION=1 SOURCE_DATE_EPOCH=1788393600
printf '=== CONFIGURE VEUX 5.4.274 WALT OFF ===\n'
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 veux_defconfig \
  2>&1 | tee "$EVIDENCE/logs/veux_defconfig.log"
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 olddefconfig \
  2>&1 | tee "$EVIDENCE/logs/olddefconfig.log"
CONFIG="$OUT/.config"
[[ -s "$CONFIG" ]] || { echo 'NO_RESOLVED_CONFIG' >&2; exit 2; }
grep -qx '# CONFIG_SCHED_WALT is not set' "$CONFIG" || { echo 'WALT_NOT_OFF' >&2; exit 2; }
! grep -qE '^CONFIG_(SCHED_CASS|KSU|SUSFS|KERNELSU)=y$' "$CONFIG" || { echo 'ROOT_OR_CASS_ENABLED' >&2; exit 2; }
cp "$CONFIG" "$EVIDENCE/veux_5.4.274_walt_off.config"
sha256sum "$CONFIG" | tee "$EVIDENCE/logs/config.sha256"

printf '=== COMPILING IMAGE AND DTBS (NOT FLASHABLE) ===\n'
# Moderate parallelism avoids memory exhaustion on hosted runners.
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j3 Image dtbs \
  2>&1 | tee "$EVIDENCE/logs/make_image_dtbs.log"
IMAGE="$OUT/arch/arm64/boot/Image"
[[ -s "$IMAGE" ]] || { echo 'IMAGE_MISSING_AFTER_COMPILE' >&2; exit 2; }
cp "$IMAGE" "$EVIDENCE/Image.5.4.274.WALT_OFF.UNFLASHABLE"
[[ -s "$OUT/System.map" ]] || { echo 'SYSTEM_MAP_MISSING' >&2; exit 2; }
cp "$OUT/System.map" "$EVIDENCE/System.map"
[[ -s "$OUT/vmlinux" ]] || { echo 'VMLINUX_MISSING' >&2; exit 2; }
# Only preserve file identity, not huge debug vmlinux binary.
sha256sum "$OUT/vmlinux" > "$EVIDENCE/logs/vmlinux.sha256"
[[ -d "$OUT/arch/arm64/boot/dts" ]] || { echo 'NO_DTB_AFTER_COMPILE (directory missing)' >&2; exit 2; }
find "$OUT/arch/arm64/boot/dts" -type f -name '*.dtb' -print0 \
   | xargs -0 -r sha256sum > "$EVIDENCE/logs/dtbs.sha256"
[[ -s "$EVIDENCE/logs/dtbs.sha256" ]] || { echo 'NO_DTB_AFTER_COMPILE' >&2; exit 2; }
# Do not report success for non-ARM64 outputs or corrupt Flattened Device Trees.
# This verifies file formats only, never bootability or stock ABI compatibility.
python3 - "$IMAGE" "$OUT/vmlinux" "$OUT/arch/arm64/boot/dts" <<'PYFORMATS'
from pathlib import Path
import struct,sys
image,vmlinux,dtbs=map(Path,sys.argv[1:])
with image.open('rb') as f: arm64=f.read(64)
if len(arm64)<64 or arm64[56:60]!=b'ARM\x64':
    raise SystemExit('NOT_AN_ARM64_IMAGE')
with vmlinux.open('rb') as f: elf=f.read(20)
if len(elf)<20 or elf[:4]!=b'\x7fELF' or elf[4]!=2 or struct.unpack_from('<H',elf,18)[0]!=183:
    raise SystemExit('NOT_AN_ARM64_VMLINUX')
count=0
for dtb in sorted(dtbs.rglob('*.dtb')):
    with dtb.open('rb') as f: header=f.read(40)
    if len(header)<40 or header[:4]!=b'\xd0\x0d\xfe\xed':
        raise SystemExit('INVALID_FDT_DTB '+str(dtb))
    count+=1
if not count:raise SystemExit('NO_DTB_AFTER_COMPILE')
print('P11_IMAGE_ARCH_ARM64=PASS; VMLINUX_ELF_AARCH64=PASS; DTB_FDT_HEADERS=PASS')
PYFORMATS
sha256sum "$IMAGE" "$OUT/System.map" > "$EVIDENCE/logs/image_systemmap.sha256"
python3 - "$REPORT" "$IMAGE" "$EVIDENCE/logs/dtbs.sha256" <<'PY'
import hashlib,json,pathlib,sys
out=pathlib.Path(sys.argv[1]);image=pathlib.Path(sys.argv[2]);dtbs=pathlib.Path(sys.argv[3])
state={'kernel':'5.4.274','build':'PASS','config_walt':'n','image_size':image.stat().st_size,
       'image_sha256':hashlib.sha256(image.read_bytes()).hexdigest(),
       'dtb_count':len(dtbs.read_text().splitlines()),'root':'ABSENT',
       'walt_runtime':'NOT_BUILT','vendor_abi':'NOT_CHECKED','device_test':'NOT_RUN',
       'flashable':False,'AK3':'NOT_CREATED','boot_img':'NOT_CREATED'}
out.write_text(json.dumps(state,sort_keys=True,indent=2)+'\n')
print('P11_WALT_OFF_FULL_COMPILE=PASS; NO_FLASH_IMAGE')
PY
