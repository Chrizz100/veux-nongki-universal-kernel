#!/usr/bin/env python3
"""Offline command-path tests for P11's bash build runner.

The fake make/clang shims never compile a kernel; this only validates the
actual shell runner's observable success and fail-closed behaviour.
"""
from __future__ import annotations
import json, os, pathlib, shutil, subprocess, tempfile, unittest

HERE=pathlib.Path(__file__).resolve().parent
RUNNER=HERE/'p11_build_walt_off.sh'

FAKE_MAKE=r'''#!/usr/bin/env python3
import os, pathlib, sys
args=sys.argv[1:]
if 'kernelversion' in args:
    print(os.getenv('FAKE_KVER','5.4.274'))
    sys.exit(0)
outs=[a[2:] for a in args if a.startswith('O=')]
if not outs:sys.exit(98)
out=pathlib.Path(outs[0]);out.mkdir(parents=True,exist_ok=True)
if 'veux_defconfig' in args or 'olddefconfig' in args:
    if os.getenv('FAKE_MISSING_CONFIG')!='1':
        walt='# CONFIG_SCHED_WALT is not set' if os.getenv('FAKE_WALT_ON')!='1' else 'CONFIG_SCHED_WALT=y'
        (out/'.config').write_text(walt+'\n# CONFIG_SCHED_CASS is not set\n# CONFIG_KSU is not set\n')
    sys.exit(0)
if 'Image' in args and 'dtbs' in args:
    if os.getenv('FAKE_BUILD_FAIL')=='1':sys.exit(27)
    if os.getenv('FAKE_NO_IMAGE')!='1':
        im=out/'arch/arm64/boot/Image';im.parent.mkdir(parents=True,exist_ok=True);im.write_bytes(b'\0'*56+(b'WRNG' if os.getenv('FAKE_BAD_IMAGE_MAGIC')=='1' else b'ARM\x64')+b'\0'*64)
    if os.getenv('FAKE_NO_DTB')!='1':
        dt=out/'arch/arm64/boot/dts/qcom/veux.dtb';dt.parent.mkdir(parents=True,exist_ok=True);dt.write_bytes((b'BAD!' if os.getenv('FAKE_BAD_DTB_MAGIC')=='1' else b'\xd0\x0d\xfe\xed')+b'\0'*36)
    if os.getenv('FAKE_NO_MAP')!='1':(out/'System.map').write_text('DUMMY-SYSTEM-MAP')
    if os.getenv('FAKE_NO_VMLINUX')!='1':(out/'vmlinux').write_bytes(b'\x7fELF'+bytes([2,1])+b'\0'*12+b'\xb7\0'+b'\0'*60)
    sys.exit(0)
sys.exit(97)
'''

class P11BuildDryRun(unittest.TestCase):
    def run_fake(self,**env_extra):
        with tempfile.TemporaryDirectory(prefix='p11_build_fake_') as d:
            root=pathlib.Path(d);workspace=root/'work';workspace.mkdir();kernel=workspace/'kernel';kernel.mkdir()
            subprocess.run(['git','init','-q'],cwd=kernel,check=True,stdout=subprocess.DEVNULL)
            (kernel/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n')
            subprocess.run(['git','add','Makefile'],cwd=kernel,check=True)
            subprocess.run(['git','-c','user.email=p11@example.invalid','-c','user.name=P11','commit','-qm','dummy source'],cwd=kernel,check=True)
            expected=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=kernel,text=True).strip()
            runner_temp=root/'temp';runner_temp.mkdir()
            report_dir=runner_temp/'VEUX_274_P11_PREP';report_dir.mkdir()
            data={'source_p11_composed_tree':expected if env_extra.get('FAKE_BAD_TREE')!='1' else '0'*40,
                  'walt_enabled':False,'flashable':False,'changed_path_count':24}
            (report_dir/'P11_PREP_REPORT.json').write_text(json.dumps(data))
            toolchain=root/'toolchain';toolbin=toolchain/'bin';toolbin.mkdir(parents=True)
            (toolbin/'make').write_text(FAKE_MAKE)
            (toolbin/'clang').write_text('#!/bin/sh\nprintf "Android (r416183b) clang version 11.0.2\\n"\n')
            (toolbin/'ld.lld').write_text('#!/bin/sh\nprintf "LLD 11.0.2\\n"\n')
            for n in ('make','clang','ld.lld'):(toolbin/n).chmod(0o755)
            env=dict(os.environ, GITHUB_WORKSPACE=str(workspace),RUNNER_TEMP=str(runner_temp),
                     P11_TOOLCHAIN_DIR=str(toolchain),PATH=f'{toolbin}:{os.environ["PATH"]}')
            env.update(env_extra)
            p=subprocess.run(['bash',str(RUNNER)],env=env,text=True,capture_output=True,timeout=60)
            artifact=runner_temp/'VEUX_274_P11_EVIDENCE'
            status=artifact/'P11_BUILD_STATUS.json'
            values=json.loads(status.read_text()) if status.exists() else None
            files=sorted(str(q.relative_to(artifact)) for q in artifact.rglob('*') if q.is_file())
            return p,values,files
    def test_01_success_walt_off_unflashable(self):
        p,state,files=self.run_fake()
        self.assertEqual(p.returncode,0,p.stderr[-400:]);self.assertEqual(state['build'],'PASS')
        self.assertFalse(state['flashable']);self.assertEqual(state['config_walt'],'n')
        self.assertEqual(state['dtb_count'],1);self.assertEqual(state['vendor_abi'],'NOT_CHECKED')
        self.assertIn('Image.5.4.274.WALT_OFF.UNFLASHABLE',files)
    def test_02_wrong_kernel_fails(self):
        p,s,_=self.run_fake(FAKE_KVER='5.4.302');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('KERNEL_NOT_5.4.274',p.stderr)
    def test_03_walt_enabled_fails(self):
        p,s,_=self.run_fake(FAKE_WALT_ON='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('WALT_NOT_OFF',p.stderr)
    def test_04_mismatched_source_tree_fails(self):
        p,s,_=self.run_fake(FAKE_BAD_TREE='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
    def test_05_compiler_failure_fails(self):
        p,s,_=self.run_fake(FAKE_BUILD_FAIL='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
    def test_06_no_image_fails(self):
        p,s,_=self.run_fake(FAKE_NO_IMAGE='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('IMAGE_MISSING_AFTER_COMPILE',p.stderr)
    def test_07_no_dtb_fails(self):
        p,s,_=self.run_fake(FAKE_NO_DTB='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('NO_DTB_AFTER_COMPILE',p.stderr)
    def test_08_no_system_map_fails(self):
        p,s,_=self.run_fake(FAKE_NO_MAP='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('SYSTEM_MAP_MISSING',p.stderr)
    def test_09_no_vmlinux_fails(self):
        p,s,_=self.run_fake(FAKE_NO_VMLINUX='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('VMLINUX_MISSING',p.stderr)
    def test_10_no_config_fails(self):
        p,s,_=self.run_fake(FAKE_MISSING_CONFIG='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('NO_RESOLVED_CONFIG',p.stderr)
    def test_11_wrong_arm64_image_header_fails(self):
        p,s,_=self.run_fake(FAKE_BAD_IMAGE_MAGIC='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('NOT_AN_ARM64_IMAGE',p.stderr)
    def test_12_wrong_fdt_dtb_header_fails(self):
        p,s,_=self.run_fake(FAKE_BAD_DTB_MAGIC='1');self.assertNotEqual(p.returncode,0);self.assertEqual(s['compile'],'FAIL')
        self.assertIn('INVALID_FDT_DTB',p.stderr)

if __name__=='__main__':unittest.main(verbosity=2)
