#!/usr/bin/env python3
"""P11 static source gate negatives; no actual 5.4.274 clone is claimed."""
import hashlib,json,os,pathlib,subprocess,tempfile,unittest
import p11_source_gate as m
from unittest.mock import patch

HERE=pathlib.Path(__file__).resolve().parent
BASE={'kernel':'5.4.274','p2_tree':m.P2_TREE,'p3_cass_free_tree':m.P3_TREE,
      'p4_dormant_walt_source_tree':m.P4_DORMANT_TREE,
      'cass_removal_applied_in_temporary_source':True,'flashable':False}

class SourceGateTests(unittest.TestCase):
    def test_01_frozen_kernel_version(self): self.assertEqual(BASE['kernel'],'5.4.274')
    def test_02_p3_authoritative_tree(self): self.assertEqual(len(m.P3_TREE),40)
    def test_03_p4_frozen_tree(self): self.assertNotEqual(m.P4_DORMANT_TREE,m.P3_TREE)
    def test_04_p10_bundle_digest(self):
        p=pathlib.Path(os.environ.get('P11_BUNDLES_DIR','/mnt/data'))/'VEUX_5_4_274_P10_WALT_KOMBI_PATCH_SAMMELPAKET.zip'
        self.assertTrue(p.is_file(),str(p))
        self.assertEqual(m.sha(p.read_bytes()),m.P10_ZIP_SHA)
    def test_05_r4_bundle_digest(self):
        p=pathlib.Path(os.environ.get('P11_BUNDLES_DIR','/mnt/data'))/'VEUX_STOCK274_P3_GATE_R4.zip'
        self.assertTrue(p.is_file(),str(p))
        self.assertEqual(m.sha(p.read_bytes()),m.R4_ZIP_SHA)
    def _validate(self,change=None):
        a=dict(BASE)
        if change:a.update(change)
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'report.json';path.write_text(json.dumps(a))
            return m.read_report(path)
    def test_06_authentic_report(self): self.assertEqual(self._validate()['p3_cass_free_tree'],m.P3_TREE)
    def test_07_wrong_kernel_rejected(self):
        with self.assertRaisesRegex(AssertionError,'WRONG_KERNEL'):self._validate({'kernel':'5.4.302'})
    def test_08_wrong_p2_rejected(self):
        with self.assertRaisesRegex(AssertionError,'WRONG_P2_TREE'):self._validate({'p2_tree':'0'*40})
    def test_09_wrong_p3_rejected(self):
        with self.assertRaisesRegex(AssertionError,'WRONG_P3_TREE'):self._validate({'p3_cass_free_tree':'0'*40})
    def test_10_wrong_donor_rejected(self):
        with self.assertRaisesRegex(AssertionError,'WRONG_DORMANT_TREE'):self._validate({'p4_dormant_walt_source_tree':'0'*40})
    def test_11_cass_not_removed_rejected(self):
        with self.assertRaisesRegex(AssertionError,'CASS_NOT_REMOVED'):self._validate({'cass_removal_applied_in_temporary_source':False})
    def test_12_flashable_rejected(self):
        with self.assertRaisesRegex(AssertionError,'UNEXPECTED_FLASH'):self._validate({'flashable':True})
    def test_13_fake_kernel_checkout_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            workspace=pathlib.Path(d);(workspace/'kernel').mkdir()
            with self.assertRaisesRegex(RuntimeError,'MISSING_KERNEL'):m.check_checkout(workspace/'kernel',workspace)
    def test_14_wrong_tree_ancestry_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            workspace=pathlib.Path(d);kernel=workspace/'kernel';kernel.mkdir()
            subprocess.run(['git','init','-q'],cwd=kernel,check=True)
            (kernel/'Makefile').write_text('VERSION=5\nPATCHLEVEL=4\nSUBLEVEL=274\n')
            subprocess.run(['git','add','-A'],cwd=kernel,check=True)
            subprocess.run(['git','-c','user.email=test@invalid','-c','user.name=Fixture','commit','-qm','fixture'],cwd=kernel,check=True)
            (kernel/'other').write_text('stuff')
            subprocess.run(['git','add','-A'],cwd=kernel,check=True)
            subprocess.run(['git','-c','user.email=test@invalid','-c','user.name=Fixture','commit','-qm','donor'],cwd=kernel,check=True)
            with self.assertRaisesRegex(RuntimeError,'UNEXPECTED_P3_P4_ANCESTRY'):m.check_checkout(kernel,workspace)
    def test_15_sha256_standard(self):self.assertEqual(m.sha(b'abc'),hashlib.sha256(b'abc').hexdigest())
    def test_16_whitespace_exception_exact(self):self.assertEqual(m.TRACE_WARNING,'kernel/sched/walt/trace.c:82: new blank line at EOF.\n')
    def test_17_no_forbidden_external_repo_writes(self):
        code=(HERE/'p11_source_gate.py').read_text()
        self.assertNotIn('git push',code)
        self.assertIn("'user_repo_changed':False",code)
    def test_18_build_script_source_not_flash(self):
        code=(HERE/'p11_build_walt_off.sh').read_text()
        for forbidden in ('fastboot flash','adb reboot bootloader','AnyKernel3','ak3.zip'):
            self.assertNotIn(forbidden,code)
    def test_19_build_enforces_walt_off(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertIn("grep -qx '# CONFIG_SCHED_WALT is not set'",s)
    def test_20_build_checks_kernelversion(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertIn('kernelversion',s)
    def test_21_build_rejects_root(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertIn('SCHED_CASS|KSU|SUSFS|KERNELSU',s)
    def test_22_build_does_not_enable_walt(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertNotIn('scripts/config --enable SCHED_WALT',s)
    def test_23_no_fake_device_test(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertIn("'device_test':'NOT_RUN'",s)
    def test_24_no_fake_abi(self):
        s=(HERE/'p11_build_walt_off.sh').read_text();self.assertIn("'vendor_abi':'NOT_CHECKED'",s)
    def test_25_needs_real_kernel_runner(self):
        self.assertEqual(m.ALLOWED_SOURCE_DIRNAME,'kernel')

if __name__=='__main__':unittest.main(verbosity=2)
