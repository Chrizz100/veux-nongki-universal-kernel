import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r3_normal_ipa', ROOT / 'Tools/restore_memory_network.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class NormalIpaBuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source, self.obj, self.logs = [self.root / n for n in ('source', 'out', 'logs')]
        shutil.copytree(ROOT / 'Original_R15', self.source)
        r.apply_source(self.source)
        self.logs.mkdir()
        self.object = self.obj / r.IPA_OBJECT
        self.object.parent.mkdir(parents=True)
        # Synthetic gate fixtures only. The LLVM parser is mocked in these unit
        # tests; they are never presented as compiled kernel objects.
        self.object.write_bytes(b'BC\xc0\xde' + bytes(2044))
        self.command = self.object.parent / ('.' + self.object.name + '.cmd')
        self.command.write_text('cmd_' + r.IPA_OBJECT + ' := clang -c -o ' + r.IPA_OBJECT
                                + ' ' + str(self.source / r.IPA_SOURCE) + '\n')
        (self.logs / 'Image.log').write_text('  CC      ' + r.IPA_OBJECT + '\n')
        self.nm = self.root / 'llvm-nm'
        self.nm.write_text('test parser placeholder\n')
        self.args = (self.source, self.obj, self.logs, ['make', 'NM=' + str(self.nm)], {})
        self.symbols = '-------- T ipa3_copy_ul_filter_rule_to_ipa\n-------- T ipa3_wwan_set_modem_perf_profile\n'

    def tearDown(self):
        self.temp.cleanup()

    def test_normal_targets_keep_all_full_builds_and_reject_unsupported_leaf(self):
        self.assertEqual(r.planned_targets(['kernel/module.o', 'mm/vmscan.o']),
                         ['olddefconfig', 'kernel/module.o', 'mm/vmscan.o', 'Image', 'dtbs', 'modules'])
        with self.assertRaisesRegex(ValueError, 'IPA_LEAF_MUST_USE_NORMAL_COMPOSITE_BUILD'):
            r.planned_targets([r.IPA_OBJECT])
        original = json.loads((ROOT / 'Reports/RUN43401998840_ORIGINAL_RESULT.json').read_text())
        old_units = [row['target'] for row in original['make_results'] if row['target'].endswith('.o')]
        with self.assertRaisesRegex(ValueError, 'IPA_LEAF_MUST_USE_NORMAL_COMPOSITE_BUILD'):
            r.planned_targets(old_units)
        fixed_units = [target for target in old_units if target != r.IPA_OBJECT]
        self.assertEqual(len(fixed_units), 36)
        targets = r.planned_targets(fixed_units)
        self.assertEqual(targets[-3:], ['Image', 'dtbs', 'modules'])
        self.assertEqual(len(targets), 40)

    def test_no_proof_when_normal_build_has_not_created_ipa(self):
        self.object.unlink()
        with self.assertRaisesRegex(ValueError, 'OBJECT_OR_COMMAND_MISSING'):
            r.prove_ipa_object(*self.args)

    def test_missing_normal_compile_log_or_unparseable_object_cannot_pass(self):
        (self.logs / 'Image.log').write_text('  CC unrelated.o\n')
        with self.assertRaisesRegex(ValueError, 'NOT_COMPILED_IN_NORMAL_BUILD_LOGS'):
            r.prove_ipa_object(*self.args)
        (self.logs / 'Image.log').write_text('  CC [M]  ' + r.IPA_OBJECT + '\n')
        with patch.object(r.subprocess, 'run', return_value=subprocess.CompletedProcess([], 1, '', 'invalid bitcode')):
            with self.assertRaisesRegex(ValueError, 'NOT_READABLE_BY_PINNED_LLVM_NM'):
                r.prove_ipa_object(*self.args)

    def test_valid_metadata_requires_real_symbols_and_the_unchanged_source(self):
        with patch.object(r.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0, self.symbols, '')):
            result = r.prove_ipa_object(*self.args)
            self.assertFalse(result['standalone_leaf_requested'])
            self.assertFalse(result['device_functionality_tested'])
            self.assertEqual(result['normal_build_logs'], ['Image.log'])
            p = self.source / r.IPA_SOURCE
            p.write_text(p.read_text() + '\nint source_changed_after_compile;\n')
            with self.assertRaisesRegex(ValueError, 'SOURCE_CHANGED_DURING_BUILD'):
                r.prove_ipa_object(*self.args)


if __name__ == '__main__':
    unittest.main()
