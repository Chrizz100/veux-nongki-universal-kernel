# SPDX-License-Identifier: GPL-2.0-only

obj-$(CONFIG_IPA3_MHI_PRIME_MANAGER) += ipampmm.o
ipampmm-objs := ipa_mpm.o
