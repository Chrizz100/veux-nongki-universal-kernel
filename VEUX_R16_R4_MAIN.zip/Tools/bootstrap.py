#!/usr/bin/env python3
"""Reconstruct pinned source fixtures; all downloads are immutable and hashed."""
import concurrent.futures
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PARENT_SHA = '450a607af4378ae6ffb97604b131a10cc65b94f2848f0699375b6435a6f398fb'
DONOR = 'https://raw.githubusercontent.com/dereference23/kernel_xiaomi_sm6375/b2b7a3bbc36d120ee523ebc8d68e0f13a97df632/'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parent():
    archive = ROOT / 'Dependencies/R15_R2_MAIN.zip'
    require(sha(archive) == PARENT_SHA, 'R15_R2_DEPENDENCY_CHANGED')
    dest = ROOT / 'runtime-r15'
    if not dest.exists():
        with zipfile.ZipFile(archive) as z:
            members = z.infolist()
            require(z.testzip() is None and len(members) < 100
                    and len(members) == len({m.filename for m in members})
                    and sum(m.file_size for m in members) < 1_000_000,
                    'BAD_R15_R2_ARCHIVE')
            for m in members:
                p = Path(m.filename)
                require(not p.is_absolute() and '..' not in p.parts
                        and '\\' not in m.filename and not m.is_dir()
                        and (m.external_attr >> 16 & 0o170000) != 0o120000,
                        'UNSAFE_R15_R2_ARCHIVE')
            z.extractall(dest)
        subprocess.run(['python3', '-B', str(dest / 'Tools/bootstrap.py')], check=True)
    repair = load(dest / 'Tools/restore_layout.py', 'r16_parent')
    repair.verify_package()
    return repair


def patch(source, path):
    for opts in (['--check'], []):
        run = subprocess.run(['git', 'apply', '--whitespace=error', *opts, str(path)],
                             cwd=source, text=True, capture_output=True)
        require(run.returncode == 0, 'BOOTSTRAP_PATCH_FAILED:' + run.stderr)


def main():
    require(not (ROOT / 'Original_R15').exists(), 'R16_FIXTURE_ALREADY_EXISTS')
    r15 = parent()
    r14 = r15.dependency()
    _, r12, _ = r14.dependency()
    pins = json.loads((ROOT / 'References/FILE_PINS.json').read_text())
    donor_pins = json.loads((ROOT / 'References/DONOR_FILE_SHA256.json').read_text())
    require(len(pins) == 19 and set(pins) == set(donor_pins), 'WRONG_R16_SOURCE_SCOPE')
    with tempfile.TemporaryDirectory(prefix='r16-bootstrap-') as tmp:
        source = Path(tmp) / 'source'
        def download(item):
            name, digest = item
            req = urllib.request.Request(DONOR + name, headers={'User-Agent': 'VEUX-R16'})
            with urllib.request.urlopen(req, timeout=60) as response:
                data = response.read(600_001)
            require(len(data) <= 600_000 and hashlib.sha256(data).hexdigest() == digest,
                    'DONOR_DOWNLOAD_CHANGED:' + name)
            path = source / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            list(pool.map(download, donor_pins.items()))
        patch(source, ROOT / 'References/UPSTREAM_268_TO_274.patch')
        patch(source, ROOT / 'References/PRESERVE_R46_MULTICAST_EXPORT.patch')
        spf = Path(tmp) / 'spf'
        shutil.copytree(r12.ROOT / 'Original_R11', spf)
        r12.apply_source(spf)
        for name, pin in pins.items():
            for earlier in (spf, r15.ROOT / 'Candidate_R15'):
                if (earlier / name).is_file():
                    shutil.copyfile(earlier / name, source / name)
            require(sha(source / name) == pin['before_sha256'],
                    'R16_ORIGINAL_FIXTURE_NOT_REPRODUCED:' + name)
        shutil.copytree(source, ROOT / 'Original_R15')
    load(ROOT / 'Tools/restore_memory_network.py', 'r16_bootstrap_check').verify_package()
    print('R16_PARENT_R15_R2_AND_19_SOURCE_FIXTURES_AUTHENTICATED; KERNEL_NOT_BUILT; FLASH=NO')


if __name__ == '__main__':
    main()
