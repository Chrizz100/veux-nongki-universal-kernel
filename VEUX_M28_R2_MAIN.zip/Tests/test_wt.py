import argparse
import contextlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('m28_tested',ROOT/'Tools/m28_wt_reporting.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class ReportingSourceTests(unittest.TestCase):
    def test_historical_fix_plus_initialization_changes_only_wt_driver(self):
        with tempfile.TemporaryDirectory() as temp:
            shutil.copytree(ROOT/'Before',temp,dirs_exist_ok=True)
            before=m.source_check(temp);after=m.apply_source(temp)
            self.assertEqual({n for n in before if before[n]!=after[n]},{m.DRIVER})
            self.assertEqual(after[m.DRIVER],'f324d9bbc630c1ced1048fa2bc196c3139867ce375c8cffdee70a2d250ee6bd0')

    def test_last_header_drift_blocks_all_writes(self):
        with tempfile.TemporaryDirectory() as temp:
            source=Path(temp);shutil.copytree(ROOT/'Before',source,dirs_exist_ok=True)
            p=source/'include/linux/qti_power_supply.h';p.write_bytes(p.read_bytes()+b'/* drift */')
            before=(source/m.DRIVER).read_bytes()
            with self.assertRaisesRegex(ValueError,'SOURCE_CONTEXT_CHANGED'):m.apply_source(source)
            self.assertEqual((source/m.DRIVER).read_bytes(),before)

    def test_already_fixed_source_rejected(self):
        with self.assertRaisesRegex(ValueError,'SOURCE_CONTEXT_CHANGED'):m.source_check(ROOT/'After')

    def test_symlink_cannot_redirect_driver_write(self):
        with tempfile.TemporaryDirectory() as temp:
            s=Path(temp)/'source';shutil.copytree(ROOT/'Before',s)
            p=s/m.DRIVER;t=Path(temp)/'elsewhere';p.rename(t);p.symlink_to(t)
            with self.assertRaisesRegex(ValueError,'NOT_REGULAR'):m.apply_source(s)

    def native(self,name,source,*extra):
        script = ROOT/'Tests/Native/test_battery_voltage_r2.py' if name == 'test_battery_voltage.py' else ROOT/'References/HISTORICAL'/name
        r=subprocess.run([sys.executable,'-B',str(script),str(source),*extra],capture_output=True,text=True,timeout=30)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        self.assertNotIn('runtime error:',r.stderr)
        return r.stdout

    def test_native_usb_voltage_117_assertions(self):
        self.assertIn('assertions=117;',self.native('test_usb_voltage.py',ROOT/'After'/m.DRIVER))

    def test_native_usb_type_261_assertions(self):
        self.assertIn('assertions=261;',self.native('test_usb_type.py',ROOT/'After'/m.DRIVER))

    def test_native_battery_voltage_468_assertions(self):
        self.assertIn('assertions=468;',self.native('test_battery_voltage.py',ROOT/'After'/m.DRIVER))

    def test_original_battery_error_and_overwrite_reproduced(self):
        # Historical battery runner expects the previous USB reporting repair present.
        old=(ROOT/'Before'/m.DRIVER).read_text();fixed=(ROOT/'After'/m.DRIVER).read_text()
        def block(s):
            a=s.index('\tcase POWER_SUPPLY_PROP_VOLTAGE_NOW:',s.index('static int batt_psy_get_prop('))
            b=s.index('\tcase POWER_SUPPLY_PROP_VOLTAGE_MAX:',a)
            return a,b
        a,b=block(fixed);c,d=block(old)
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'battery-before.c';p.write_text(fixed[:a]+old[c:d]+fixed[b:])
            output=self.native('test_battery_voltage.py',p,'--baseline')
        self.assertIn('REPRO_COLD_OVERWRITE=CONFIRMED',output)
        self.assertIn('REPRO_IGNORED_BMS_ERROR=CONFIRMED',output)

    def test_original_usb_voltage_fails_fixed_expectations(self):
        r=subprocess.run([sys.executable,'-B',str(ROOT/'References/HISTORICAL/test_usb_voltage.py'),str(ROOT/'Before'/m.DRIVER)],text=True,capture_output=True,timeout=30)
        self.assertNotEqual(r.returncode,0)
        self.assertIn('FAIL line',r.stderr)

    def test_native_enums_and_formatter_bound_to_six_real_definitions(self):
        proof=m.native_reference_proof(ROOT/'After')
        self.assertEqual(proof['definition_blocks_checked'],6)

    def test_native_context_drift_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            s=Path(temp);shutil.copytree(ROOT/'After',s,dirs_exist_ok=True)
            p=s/'drivers/power/supply/power_supply_sysfs.c'
            p.write_text(p.read_text().replace('"PD_PPS"','"WRONG_PPS"'))
            with self.assertRaisesRegex(ValueError,'NATIVE_ENUM_OR_SYSFS_CONTEXT_CHANGED'):m.native_reference_proof(s)

    def test_authentic_parent_callbacks_preserve_rpm_and_adc_while_adding_wt(self):
        p27=Path(os.environ.get('M27_DIR',str(ROOT.parent/'m27-main')))
        p26=Path(os.environ.get('M26_DIR',str(ROOT.parent/'m26-main')))
        parent=m.load_parent(p27/'Tools/m27_sc8551.py');grand=parent.load_parent(p26/'Tools/m26_rpm_sleep.py')
        original=parent.apply_source
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);source=root/'candidate-source'
            for path in [p26,p27,ROOT]:shutil.copytree(path/'Before',source,dirs_exist_ok=True)
            cfg=root/'.config';cfg.write_bytes(b'CONFIG_TEST_SENTINEL=y\n')
            def stop(args):
                self.assertEqual(grand.apply_source(source),grand.source_check(source,after=True))
                parent.source_check(source,after=True);m.source_check(source,after=True)
                self.assertEqual(cfg.read_bytes(),b'CONFIG_TEST_SENTINEL=y\n')
                raise RuntimeError('AUTHENTIC_RPM_ADC_WT_CALLBACK_PASS_BEFORE_COMPILATION')
            with patch.object(m,'load_parent',return_value=parent),patch.object(parent,'load_parent',return_value=grand),patch.object(grand,'build',side_effect=stop):
                with self.assertRaisesRegex(RuntimeError,'CALLBACK_PASS'):
                    m.build(argparse.Namespace(m27_tool='fixture',m26_tool='fixture',output=str(root)))
            self.assertIs(parent.apply_source,original)
            result=json.loads((root/'M28_RESULT.json').read_text())
            self.assertFalse(result['kernel_compiled']);self.assertFalse(result['flash_allowed'])
            self.assertIn('applied_wt_source_hashes',result)

    def test_four_linked_interfaces_required_with_lto_suffixes(self):
        lines=['ffffffc010000000 t batt_chg_probe.llvm.123','ffffffc010000008 t batt_psy_get_prop$123.cfi_jt','ffffffc010000010 t usb_psy_get_prop$123','ffffffc010000018 d __initcall_192_3562_batt_chg_init6']
        self.assertEqual(len(m.linked_proof('\n'.join(lines))),4)
        for i in range(4):
            with self.subTest(i=i),self.assertRaisesRegex(ValueError,'NOT_LINKED'):m.linked_proof('\n'.join(lines[:i]+lines[i+1:]))

    def test_old_green_report_cannot_satisfy_new_wt_gate(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp)/'M28_RESULT.json').write_text(json.dumps({'status':'M27_GREEN','kernel_compiled':True}))
            with self.assertRaisesRegex(ValueError,'FRESH_M28_R2_FULL_REPORTING_BUILD_REQUIRED'):m.verify_fresh(temp,argparse.Namespace(),'fixture','fixture')

    def test_package_failure_reported_and_unverified_pair_quarantined(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp);(out/'review').mkdir();(out/'review/unverified.img').write_bytes(b'UNIT FIXTURE')
            def fail(args):raise RuntimeError('PARENT_PACKAGE_FAILED')
            with patch.object(m,'verify_package'),patch.object(m,'load_parent',return_value=argparse.Namespace(package=fail)),patch.object(m,'verify_fresh',return_value={}):
                with self.assertRaisesRegex(RuntimeError,'PARENT_PACKAGE_FAILED'):m.package(argparse.Namespace(m27_tool='fixture',m26_tool='fixture',m25_tool='fixture',build='fixture',output=temp))
            r=json.loads((out/'M28_PACKAGE_RESULT.json').read_text())
            self.assertFalse(r['static_boot_path_pass']);self.assertFalse(r['device_pass']);self.assertFalse(r['flash_allowed'])
            self.assertFalse((out/'review').exists());self.assertTrue((out/'unverified-review/unverified.img').is_file())


class ProductTests(unittest.TestCase):
    def fixture(self,build):
        shutil.copytree(ROOT/'After',build/'candidate-source');out=build/'candidate-out';out.mkdir()
        (out/'.config').write_text('CONFIG_WT_CHG=y\n');(out/'Module.symvers').write_text('SYNTHETIC UNIT FIXTURE\n')
        obj=out/(m.UNIT+'.o');obj.parent.mkdir(parents=True);obj.write_bytes(b'BC\xc0\xdeSYNTHETIC UNIT FIXTURE')
        (obj.parent/('.'+obj.name+'.cmd')).write_text(m.DRIVER+' -flto=thin -fsanitize=cfi')
        (out/'vmlinux').write_bytes(b'SYNTHETIC UNIT FIXTURE')
        (out/'System.map').write_text('ffffffc010000000 t batt_chg_probe\nffffffc010000008 t batt_psy_get_prop\nffffffc010000010 t usb_psy_get_prop\nffffffc010000018 d __initcall_192_3562_batt_chg_init6\n')
        p=dict(m.profile(),baseline_config_sha256=m.sha(out/'.config'),full_symvers_sha256=m.sha(out/'Module.symvers'))
        return out,p

    def test_complete_source_object_cfi_and_callback_proof(self):
        with tempfile.TemporaryDirectory() as temp:
            out,p=self.fixture(Path(temp))
            with patch.object(m,'profile',return_value=p):proof=m.reporting_proof(temp)
            self.assertEqual(len(proof['wt_source_hashes']),5);self.assertEqual(len(proof['linked_wt_interfaces']),4)
            self.assertEqual(proof['new_config_values_requested'],[])

    def test_wrong_config_object_cfi_symbol_or_export_table_blocks_gate(self):
        for n in ['.config','Module.symvers',m.UNIT+'.o',str(Path(m.UNIT).parent/('.'+Path(m.UNIT).name+'.o.cmd')),'System.map']:
            with self.subTest(name=n),tempfile.TemporaryDirectory() as temp:
                out,p=self.fixture(Path(temp));(out/n).write_bytes(b'wrong or old product')
                with patch.object(m,'profile',return_value=p),self.assertRaises(ValueError):m.reporting_proof(temp)

    def test_fresh_green_kernel_rechecked_before_packaging(self):
        with tempfile.TemporaryDirectory() as temp:
            build=Path(temp);out,p=self.fixture(build)
            with patch.object(m,'profile',return_value=p):
                result=dict(m.reporting_proof(build),status=m.STATUS,kernel_compiled=True,wt_reporting_source_compiled_and_linked=True,runtime_charging_tested=False,device_pass=False,flash_allowed=False,kernel_product_hashes={'vmlinux':m.sha(out/'vmlinux')})
                (build/'M28_RESULT.json').write_text(json.dumps(result));parent=argparse.Namespace(verify_fresh=lambda *a:None,load_parent=lambda p:None)
                self.assertEqual(m.verify_fresh(build,parent,'fixture','fixture')['status'],m.STATUS)
                (out/'vmlinux').write_bytes(b'changed after build')
                with self.assertRaisesRegex(ValueError,'FRESH_KERNEL_PRODUCT_CHANGED'):m.verify_fresh(build,parent,'fixture','fixture')


class WorkflowTests(unittest.TestCase):
    def command(self, op):
        expected = (ROOT / ('References/M28_' + op.upper() + '_COMMAND.sh')).read_text()
        if 'M28_WORKFLOW' not in os.environ:
            return expected
        rows = Path(os.environ['M28_WORKFLOW']).read_text().splitlines()
        found = []
        for i, row in enumerate(rows):
            if row.strip() != 'run: |':
                continue
            indent = len(row) - len(row.lstrip())
            body = []
            for line in rows[i + 1:]:
                if line.strip() and len(line) - len(line.lstrip()) <= indent:
                    break
                body.append(line)
            script = textwrap.dedent('\n'.join(body)) + '\n'
            if 'python3 -B "$M28_DIR/Tools/m28_wt_reporting.py" ' + op in script:
                found.append(script)
        self.assertEqual(found, [expected])
        return found[0]

    def capture(self, op, broken=False):
        with tempfile.TemporaryDirectory(prefix='m28 argv spaces ') as temp:
            root = Path(temp)
            bindir = root / 'bin'
            bindir.mkdir()
            shim = bindir / 'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M28_CAPTURE"\n')
            shim.chmod(0o755)
            keys = ['M27_DIR', 'M26_DIR', 'M25_DIR', 'R25_DIR', 'R24_DIR', 'R23_DIR', 'R21_SCHED_DIR', 'R19_RMNET_DIR',
                    'R18_IRQ_DIR', 'R17_CACHE_DIR', 'R16_REPAIR_DIR', 'R9_SNAPSHOT', 'R13_OBJOUT',
                    'R47_REPORT_DIR', 'R47_TOOLS_DIR', 'GITHUB_WORKSPACE', 'R16_REPAIR_OUTPUT',
                    'R21_PACK_DIR', 'R21_PACKAGE_OUTPUT']
            env = {k: str(root / (k + ' spaces')) for k in keys}
            env['M28_DIR'] = str(ROOT)
            command = self.command(op)
            if broken:
                command = command.replace(' ' + op + ' \\\n', ' ' + op + ' \\\n  + \\\n', 1)
            result = subprocess.run(['bash', '-c', command], env=dict(os.environ, **env,
                                    PATH=str(bindir) + os.pathsep + os.environ['PATH'], M28_CAPTURE=str(root / 'argv')),
                                    text=True, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            argv = (root / 'argv').read_bytes().decode().split('\0')
            self.assertEqual(argv.pop(), '')
            self.assertEqual(argv[:2], ['-B', str(ROOT / 'Tools/m28_wt_reporting.py')])
            return argv[1:], env

    def invoke(self, op, count):
        argv, env = self.capture(op)
        with patch.object(sys, 'argv', argv), patch.object(m, 'verify_package'), patch.object(m, op) as called:
            m.main()
        parsed = vars(called.call_args.args[0])
        self.assertEqual(len(parsed), count + 1)
        self.assertEqual(parsed['op'], op)
        self.assertEqual(parsed['m27_tool'], env['M27_DIR'] + '/Tools/m27_sc8551.py')
        self.assertEqual(parsed['m26_tool'], env['M26_DIR'] + '/Tools/m26_rpm_sleep.py')
        self.assertEqual(parsed['m25_tool'], env['M25_DIR'] + '/Tools/m25_config.py')
        self.assertEqual(parsed['r25_tool'], env['R25_DIR'] + '/Tools/r25_tzlog.py')
        self.assertEqual(parsed['output'], env['R16_REPAIR_OUTPUT'] if op == 'build' else env['R21_PACKAGE_OUTPUT'])
        return parsed, env

    def test_delivered_build_command_passes_real_parser_with_all_seventeen_paths(self):
        parsed, env = self.invoke('build', 17)
        self.assertEqual(parsed['source'], env['R9_SNAPSHOT'])
        self.assertEqual(parsed['project'], env['GITHUB_WORKSPACE'] + '/project')

    def test_delivered_package_command_passes_real_parser_with_all_eleven_paths(self):
        parsed, env = self.invoke('package', 11)
        self.assertEqual(parsed['build'], env['R16_REPAIR_OUTPUT'])
        self.assertEqual(parsed['work'], env['GITHUB_WORKSPACE'] + '/r46-m28-pack-work')

    def test_original_plus_typo_is_rejected_before_either_operation(self):
        for op in ['build', 'package']:
            argv, _ = self.capture(op, broken=True)
            with self.subTest(op=op), patch.object(sys, 'argv', argv), patch.object(m, op) as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    m.main()
            self.assertEqual(error.exception.code, 2)
            called.assert_not_called()


if __name__ == '__main__':
    unittest.main()
