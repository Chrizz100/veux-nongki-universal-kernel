#!/usr/bin/env python3
"""Repair WT voltage and USB type reporting; retain authentic M27 and all prior gates."""
import argparse
import hashlib
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/wt_chg.c'
UNIT = DRIVER[:-2]
STATUS = 'M28_R2_FULL_WT_REPORTING_M27_ADC_RPM_CONFIG_1423_CRCS_37_MODULES_PASS_NOFLASH'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()


def profile():
    return json.loads((ROOT / 'References/PROFILE.json').read_text())


def pins():
    return json.loads((ROOT / 'References/SOURCE_PINS.json').read_text())


def native_reference_proof(source):
    """Bind the native enum and sysfs harness to the actual pinned kernel definitions."""
    source = Path(source)
    ref = (ROOT / 'References/HISTORICAL/usb_type_reference.h').read_text()
    header = (source / 'include/linux/power_supply.h').read_text()
    qti = (source / 'include/linux/qti_power_supply.h').read_text()
    sysfs = (source / 'drivers/power/supply/power_supply_sysfs.c').read_text()
    patterns = [(header, r'enum power_supply_' + n + r'\s*\{.*?\n\};')
                for n in ['property', 'type', 'usb_type']]
    patterns += [(qti, r'enum\s*\{\s*QTI_POWER_SUPPLY_PD_INACTIVE.*?\n\};'),
                 (sysfs, r'static const char \* const POWER_SUPPLY_USB_TYPE_TEXT\[\] = \{.*?\n\};'),
                 (sysfs, r'static ssize_t power_supply_show_usb_type\(.*?\n\}')]
    def normalized(text):
        return re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S))
    for actual, pattern in patterns:
        a, b = re.search(pattern, actual, re.S), re.search(pattern, ref, re.S)
        require(a is not None and b is not None and normalized(a[0]) == normalized(b[0]),
                'NATIVE_ENUM_OR_SYSFS_CONTEXT_CHANGED:' + pattern)
    return {'native_enum_and_sysfs_definitions_match': True, 'definition_blocks_checked': len(patterns)}


def verify_package():
    names = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in names, 'UNSAFE_MANIFEST')
        require(not (ROOT / path).is_symlink() and sha(ROOT / path) == digest, 'PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names and len(pins()) == 5, 'PACKAGE_SCOPE_CHANGED')
    for name, pin in pins().items():
        for side in ['Before', 'After']:
            require(sha(ROOT / side / name) == pin[side.lower() + '_sha256'], 'SOURCE_FIXTURE_CHANGED:' + name)
    historic = json.loads((ROOT / 'References/HISTORICAL/manifest.json').read_text())
    entry = next(r for r in historic['files'] if r['source'] == DRIVER)
    historical = (ROOT / 'References/HISTORICAL/wt_chg.diag08.after.c').read_bytes()
    require(pins()[DRIVER]['before_sha256'] == entry['before_sha256']
            and hashlib.sha256(historical).hexdigest() == entry['after_sha256'], 'EXACT_HISTORICAL_WT_FIX_REQUIRED')
    require(historical.count(b'\tint vbus_mv;\n') == 1, 'UNIQUE_VBUS_INITIALIZATION_CONTEXT_REQUIRED')
    fixed = historical.replace(b'\tint vbus_mv;\n', b'\tint vbus_mv = 0;\n', 1)
    require((ROOT / 'After' / DRIVER).read_bytes() == fixed
            and hashlib.sha256(fixed).hexdigest() == profile()['wt_initialized_after_sha256'],
            'ONLY_ONE_VBUS_INITIALIZATION_EXTENSION_ALLOWED')
    original_test = (ROOT / 'References/HISTORICAL/test_battery_voltage.py').read_text()
    old_scope = '7fc68aabcf7b62d4b4319c8c10f38a154283b6af6042d3a152c35c4465fae3ff'
    require(original_test.count(old_scope) == 1
            and (ROOT / 'Tests/Native/test_battery_voltage_r2.py').read_text()
            == original_test.replace(old_scope, profile()['battery_scope_sha256_r2'], 1),
            'NATIVE_BATTERY_TEST_BODY_MUST_REMAIN_UNCHANGED')
    require({n for n, p in pins().items() if p['before_sha256'] != p['after_sha256']} == {DRIVER},
            'ONLY_WT_REPORTING_DRIVER_MAY_CHANGE')
    for name, digest in profile()['historical_assets_sha256'].items():
        require(sha(ROOT / 'References/HISTORICAL' / name) == digest, 'HISTORICAL_ASSET_CHANGED:' + name)
    native_reference_proof(ROOT / 'After')


def source_check(source, after=False):
    source = Path(source).resolve(strict=True)
    result = {}
    for name, pin in pins().items():
        path = source / name
        require(path.is_file() and all(not p.is_symlink() for p in [path, *path.parents]
                if p.is_relative_to(source)), 'SOURCE_NOT_REGULAR:' + name)
        result[name] = sha(path)
        expected = pin['after_sha256' if after else 'before_sha256']
        require(result[name] == expected,
                'WT_SOURCE_CONTEXT_CHANGED:' + name + ':expected=' + expected + ':actual=' + result[name])
    return result


def apply_source(source):
    source = Path(source).resolve(strict=True)
    source_check(source)
    for name, pin in pins().items():
        if pin['before_sha256'] != pin['after_sha256']:
            (source / name).write_bytes((ROOT / 'After' / name).read_bytes())
    return source_check(source, after=True)


def linked_proof(text):
    patterns = {'wt_probe': r'batt_chg_probe(?:[.$]\S+)?',
                'battery_getter': r'batt_psy_get_prop(?:[.$]\S+)?',
                'usb_getter': r'usb_psy_get_prop(?:[.$]\S+)?',
                'wt_initcall': r'__initcall_\S*batt_chg_init6(?:\.llvm\.\S+)?'}
    result = {}
    for key, pattern in patterns.items():
        found = re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(' + pattern + r')$', text)
        require(found, 'WT_REPORTING_INTERFACE_NOT_LINKED:' + key)
        result[key] = sorted(set(found))
    return result


def reporting_proof(build):
    build = Path(build).resolve(strict=True)
    out = build / 'candidate-out'
    sources = source_check(build / 'candidate-source', after=True)
    reference = native_reference_proof(build / 'candidate-source')
    require(sha(out / '.config') == profile()['baseline_config_sha256'], 'ACTUAL_M27_CONFIG_CHANGED')
    require(sha(out / 'Module.symvers') == profile()['full_symvers_sha256'], 'FULL_M27_EXPORT_TABLE_CHANGED')
    require(re.search(r'(?m)^CONFIG_WT_CHG=y$', (out / '.config').read_text()), 'BUILTIN_WT_CHG_REQUIRED')
    obj = out / (UNIT + '.o')
    cmd = obj.parent / ('.' + obj.name + '.cmd')
    with obj.open('rb') as f:
        require(f.read(4) in [b'BC\xc0\xde', b'\xde\xc0\x17\x0b'], 'WT_OBJECT_NOT_LLVM_BITCODE')
    command = cmd.read_text()
    require(DRIVER in command and '-flto=thin' in command and '-fsanitize=cfi' in command,
            'ACTUAL_WT_CFI_COMMAND_REQUIRED')
    return {'wt_source_hashes': sources, 'wt_object_sha256': sha(obj), 'wt_command_sha256': sha(cmd),
            'linked_wt_interfaces': linked_proof((out / 'System.map').read_text()),
            'native_reference_context': reference, 'new_config_values_requested': [],
            'actual_config_sha256': sha(out / '.config'), 'full_symvers_sha256': sha(out / 'Module.symvers')}


def load_parent(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['m27_tool_sha256'], 'AUTHENTIC_M27_TOOL_CHANGED')
    spec = importlib.util.spec_from_file_location('m28_original_m27', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def write_result(out, name, result):
    if out.is_dir():
        (out / name).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def build(args):
    verify_package()
    parent = load_parent(args.m27_tool)
    original = parent.apply_source
    out = Path(args.output).resolve()
    result = {'status': 'M28_R2_BUILD_PENDING', 'kernel_compiled': False,
              'device_pass': False, 'flash_allowed': False, 'runtime_charging_tested': False,
              'baseline_run': profile()['baseline_run'], 'new_config_values_requested': []}

    def overlay(source):
        result['wt_preflight'] = source_check(source)
        prior = original(source)
        result['applied_wt_source_hashes'] = apply_source(source)
        return prior

    parent.apply_source = overlay
    try:
        parent.build(args)
        prior = parent.verify_fresh(out, parent.load_parent(args.m26_tool), args.m25_tool)
        require(prior['status'] == parent.STATUS and prior['kernel_compiled'] is True
                and prior['sc8551_adc_source_compiled_and_linked'] is True, 'FULL_M27_ADC_RPM_BUILD_REQUIRED')
        result.update(reporting_proof(out))
        require(result['wt_source_hashes'] == result['applied_wt_source_hashes'], 'WT_SOURCE_CHANGED_DURING_BUILD')
        require(prior['fully_matching_modules'] == 37 and prior['qgki_counts'] ==
                {'MATCH': 1423, 'CRC_MISMATCH': 0, 'NOT_EXPORTED': 0}, 'COMPLETE_QGKI_COHORT_REQUIRED')
        result.update(status=STATUS, kernel_compiled=True, wt_reporting_source_compiled_and_linked=True,
                      fully_matching_modules=37, qgki_counts=prior['qgki_counts'],
                      kernel_product_hashes=prior['kernel_product_hashes'], release=prior['release'])
    except Exception as error:
        result.update(status='M28_R2_BUILD_OR_WT_REPORTING_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.apply_source = original
        write_result(out, 'M28_RESULT.json', result)
    print(result['status'], 'DEVICE_PASS=NO FLASH=NO')


def verify_fresh(build, parent, m26_tool, m25_tool):
    build = Path(build).resolve(strict=True)
    result = json.loads((build / 'M28_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('wt_reporting_source_compiled_and_linked') is True
            and result.get('runtime_charging_tested') is False
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_M28_R2_FULL_REPORTING_BUILD_REQUIRED')
    parent.verify_fresh(build, parent.load_parent(m26_tool), m25_tool)
    proof = reporting_proof(build)
    require(all(result.get(k) == v for k, v in proof.items()), 'FRESH_WT_PROOF_CHANGED')
    for name, digest in result['kernel_product_hashes'].items():
        require(sha(build / 'candidate-out' / name) == digest, 'FRESH_KERNEL_PRODUCT_CHANGED:' + name)
    return result


def package(args):
    verify_package()
    parent = load_parent(args.m27_tool)
    result = verify_fresh(args.build, parent, args.m26_tool, args.m25_tool)
    out = Path(args.output).resolve()
    package_result = {'status': 'M28_R2_PACKAGE_PENDING', 'static_boot_path_pass': False,
                      'device_pass': False, 'flash_allowed': False}
    try:
        parent.package(args)
        prior = json.loads((out / 'M27_PACKAGE_RESULT.json').read_text())
        require(prior['static_boot_path_pass'] is True and prior['device_pass'] is False, 'M27_STATIC_PACKAGE_GATES_REQUIRED')
        for path in sorted((out / 'review').iterdir()):
            require(path.is_file() and path.name.startswith('VEUX_M27_'), 'UNEXPECTED_REVIEW_FILE')
            target = path.with_name(path.name.replace('VEUX_M27_', 'VEUX_M28_R2_', 1))
            require(not target.exists(), 'REVIEW_TARGET_EXISTS')
            path.rename(target)
        pair = parent.load_parent(args.m26_tool).load_parent(args.m25_tool).audit_pair(args.build, out)
        verify_fresh(args.build, parent, args.m26_tool, args.m25_tool)
        package_result.update(status='M28_R2_WT_REPORTING_ADC_RPM_CONFIG_BOOT_AK3_PAIR_PASS_NOFLASH',
                              static_boot_path_pass=True, review_pair_sha256=pair,
                              kernel_release=result['release']['verified_release'])
    except Exception as error:
        package_result.update(status='M28_R2_PACKAGE_GATE_FAILED_NOFLASH', error=str(error))
        review = out / 'review'
        if review.exists():
            review.rename(out / 'unverified-review')
        raise
    finally:
        write_result(out, 'M28_PACKAGE_RESULT.json', package_result)
    print('M28_R2_WT_REPORTING_ADC_RPM_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='op', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    b = sub.add_parser('build')
    for name in ('m27-tool', 'm26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-tool', 'r19-tool',
                 'r18-tool', 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + name, required=True)
    a = sub.add_parser('package')
    for name in ('m27-tool', 'm26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-package-tool',
                 'build', 'packager-tool', 'work', 'output'):
        a.add_argument('--' + name, required=True)
    args = p.parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'check-source':
        print(json.dumps(source_check(args.source), sort_keys=True))
    else:
        print('M28_R2_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
