VEUX M28 R2 – WT-Spannungs- und USB-Typ-Anzeige – NOFLASH
Basis: erfolgreicher M27-Lauf 43678211891, Commit 2cc223f97e52f9e8a77e0ebebabf5a01c9e83454.

UPLOAD AM SMARTPHONE
1. VEUX_M28_R2_MAIN.zip unveraendert in das Hauptverzeichnis der GitHub-Repo hochladen.
   Kein Entpacken der MAIN. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M28_R2_YAML.zip entpacken. Die darin enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml ersetzt dort
   die bisherige Workflow-Datei. Danach den Workflow manuell starten.
3. VEUX_R25_MAIN.zip muss wie bisher im Hauptverzeichnis bleiben.
   M25-R2/M26/M27 werden automatisch aus unveraenderlichen Commit-Referenzen geladen.

REPARATUR
Genau ein geaenderter Treiber: drivers/power/supply/qcom/wt_chg.c.
- Kalte Batterie: die CP-Spannung wird nicht mehr durch den zweiten if/else-Zweig ersetzt.
- Fehlerhafte IIO-Lesungen und ungueltige/ueberlaufende mV-Werte werden abgefangen.
- USB VOLTAGE_NOW liefert die VBUS-Spannung statt Batteriedaten und rechnet mV in uV um.
- USB_TYPE verwendet das richtige Enum, registriert die Typen und ruft keine Ladepolicy auf.
Historischer Patch aus charger-diag08 plus genau eine Initialisierung:
int vbus_mv = 0. Historischer Quellstand und Testkoerper bleiben separat erhalten;
der Batteriescope-Hash wird nur fuer diese belegte Ein-Zeilen-Erweiterung aktualisiert.
Vier unveraenderte Abhaengigkeiten werden mitgeprueft. Sechs echte Enum-/Sysfs-
Definitionen binden den nativen Test an den gepinnten Kernelquellstand.
Keine Konfigurationsaenderung, Kennung bleibt 5.4.274-qgki-g82179e362f33.
M27-ADC-, M26-RPM-, M25-Konfigurations- und alle vorherigen Build-/ABI-Gates bleiben aktiv.

PRUEFUNGEN UND GRENZEN
846 native C-Assertions mit UBSan fuer USB-/Batteriespannung und USB-Typ.
Originale Fehler reproduziert. Ganzer geaenderter Treiber lokal fuer ARM64 mit
Clang 12.0.5, CFI und ThinLTO kompiliert. Kein vollstaendiger lokaler M28-Kernelbau.
Der neue CI-Lauf muss den kompletten Kernel, eingebettete Konfiguration/vmlinux,
1.423 QGKI-Import-CRCs, 37 Module, komplette Exporttabelle, WT-Objekt und die
verlinkten Callbacks bestaetigen. Anschliessend erfolgen Boot-/AK3-Containerpruefungen.
Nur das gemeinsam validierte Paar wird im review-Verzeichnis ausgegeben.

Alle 32 Artefakte von M27 wurden geprueft; der detaillierte Bericht liegt unter
Reports/RUN43678211891_32_ARTEFAKTE.zip. Historische Compilerfehler sind dort den
spaeteren erfolgreichen Objektpruefungen zugeordnet. Alte Teilpruefungen sind
keine erneuten Fehler des finalen M27 und keine eigenstaendige Flashfreigabe.

OFFEN
Vollstaendiger M28-CI-Lauf. Danach weitere noch offene Quellkorrekturen und
gezielte Lade-/Suspendpruefungen. Kein bisheriger Bericht ersetzt einen Test am
konkreten Telefon oder einen geprueften Rueckweg. Es gibt keinen Device Pass.
Device Pass: NEIN. Flashfreigabe: NEIN. Boot.img und AK3 bleiben NOFLASH.

R2 behebt den Compiler-Abbruch des Laufs 43689432626 vor dem Kernelbau.
Der urspruengliche Fehler wurde mit GCC 11.4 aus Ubuntu 22.04 reproduziert.
Die strikten -Werror-/UBSan-Pruefungen bleiben aktiv. Kein automatisches Flashen.
