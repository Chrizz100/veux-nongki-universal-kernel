VEUX M33 – BQ-Shutdown: IIO/Sysfs sperren, IRQ/Works stoppen, Ressourcen freigeben – NOFLASH
Basis: gruener M32-Lauf 43730138552 / Commit 27d0e8a9b08be776d20a53b0673c6ac6f7cc0805.

UPLOAD AM SMARTPHONE
1. VEUX_M33_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M33_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Workflow anschliessend manuell starten.
   Historische Pakete werden aus festen Commits geladen und authentifiziert.

M32 AUSGEWERTET
Alle 32 Artefakte heruntergeladen und auf SHA-256 und ZIP-CRC geprueft:
854 Dateien, 787 Textdateien, 199 JSON-Dateien, 35.503.649 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; die sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M32 unabhaengig geprueft:
40 erfolgreiche make-Aufrufe, BQ-Start-/Lese-/Schreibzweige, eingebettete
Konfiguration in Image/vmlinux, 1.423 passende Import-CRCs, 37 passende Module,
unveraenderte komplette Exporttabelle und Originalkennung. Boot.img und AK3
aus den gepinnten Referenzen byteidentisch rekonstruiert. Alle Archivberichte
sind ausgewertet; tiefe Kernel-/ABI-/Boot-Pruefungen betreffen den finalen M32.
Berichte: Reports/RUN43730138552_32_ARTEFAKTE.zip und M32_INDEPENDENT_VERIFICATION.json.

M33 REPARATUR
M32 schreibt beim Shutdown die letzten Chipwerte, bevor IRQ und Hintergrundarbeit
gestoppt sind. Zudem koennen seine IIO-Callbacks danach weiter den Bus benutzen.
M33 laesst aktive IIO-/Sysfs-Aufrufe unter einem privaten Mutex abschliessen,
setzt stopping und weist weitere Zugriffe mit -ESHUTDOWN ab. Der Mutex ist
vor Registrierung der Schnittstelle initialisiert. Er wird vor disable_irq,
Sysfs-Entfernung und dem synchronen Abbruch aller sechs Works freigegeben;
so wird nicht unter diesem Mutex auf einen Callback gewartet.
Der Hard-IRQ-Handler verwendet keinen schlafenden Mutex. Alle Work-/IRQ-Einstiege
pruefen stopping; neue Einplanungen und die DPDM-Warteschleife beachten es ebenfalls.
Danach folgen exakt die bisherigen fuenf abschliessenden Hardwareoperationen in
der bisherigen Reihenfolge. Ihre Fehler werden protokolliert; es gibt kein
blindes Hardware-Rollback und keinen behaupteten Erfolg eines fehlgeschlagenen Buszugriffs.
IRQ-Wakeup wird nur bei zuvor erfolgreicher Aktivierung deaktiviert. IRQ, GPIO,
Wakeup-Quelle und vorhandene Power-Supply-Referenzen werden danach freigegeben.
Ein erneuter Shutdown raeumt dieselben Ressourcen nicht nochmals auf.
Sysfs liest den zum Geraet gehoerenden Treiber statt des globalen Zeigers.
Die Gegenpruefung mit GCC 11 deckte auch eine falsche Pufferlaengenangabe der
Registeranzeige auf. snprintf verwendet dort nun sizeof(tmpbuf) statt PAGE_SIZE-idx.

Die M32-IIO-Funktionskoerper einschliesslich Ready-Gate sind unveraendert in
Mutex-Wrapper verschoben. Bei den Workern duerfen ausschliesslich Stop-Pruefungen
und bedingte Einplanungen abweichen. Andere Treiberbytes ausser dem abgegrenzten
Shutdown-/Sysfs-/Probe-Bereich und privaten Mutex/Flags bleiben identisch.
Keine Strom-/Spannungsvorgabe und keine erfolgreiche Hardware-Ablaufspur geaendert.
Keine zusaetzliche 5-V-VINDPM-Regel und keine Defconfig-Aenderung. Beide Header
bleiben byteidentisch, insbesondere 1.763 Bytes ohne EOF-LF fuer bq2589x_iio.h.

PRUEFUNGEN
30 M33-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Neue Shutdown-Tests fuehren die echten Callbacks/Shutdown-/Workerfunktionen aus:
1.751 C-Assertions, sechs gezielt gleichzeitig aktive IIO-Lese-/IIO-Schreib-/
Sysfs-Faelle fuer beide Chips und 56 unveraenderte Adapter-/IRQ-Erfolgsablaeufe.
Es werden auch Busfehler, spate Callback-/Work-Aufrufe, NULL-Referenzen,
Wiederholungsaufrufe, Abbruch waehrend DPDM und die letzten Registerspuren geprueft.
Die beiden alten Shutdown-Fehler werden mit der authentischen M32-Funktion
reproduziert. Ihr Rueckport in den neuen Treiber wird vom neuen Test abgewiesen.
Weitere aktuelle native Assertions: 2.333 Lesen, 37.577 Schreiben, 6.901 Start/DT.
Der unveraenderte 156-Assertion-Probetest laeuft zusaetzlich auf der M31-Referenz.
Der gesamte geaenderte Treiber kompiliert fuer ARM64 mit Clang 12.0.5/CFI/ThinLTO.
Host-Mutex-/Threadtests und modellierte IRQ-/Work-Abbrueche sind kein Nachweis
des echten Linux-Workqueue-/IRQ-Verhaltens am Geraet. Kein lokaler Vollkernelbau.

CI UND OFFENE ARBEIT
Alle historischen Pakete bleiben authentifiziert, einschliesslich M32 und dessen
Regressionen. Die neue BQ-Schicht verwendet weiter den authentischen M28-R2-Baukern
mit allen Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates.
M33 muss tatsaechliche Quellen, LLVM-Objekt, CFI-Kommando, den verlinkten Shutdown-
Callback und den neuen Shutdown-Zweig in Image UND vmlinux nachweisen.
Konfiguration und komplette Exporttabelle muessen unveraendert bleiben.
Kernelkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M33-GitHub-Bau und dessen Artefakte; weitere ignorierte
Schreibfehler in init_device/Adapterpfaden und die korrekten Power-Supply-
Abhaengigkeiten. Kein Vollvergleich aller historischen ueber 7.100 Quellabweichungen,
keine universelle GKI-Freigabe. Geraeteboot, Laden, OTG, Suspend, Shutdown und
Wiederherstellung sind weiterhin ungetestet. Device Pass NEIN. Flashfreigabe NEIN.
