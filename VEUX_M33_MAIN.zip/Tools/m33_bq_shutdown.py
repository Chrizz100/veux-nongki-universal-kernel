#!/usr/bin/env python3
"""Serialize BQ shutdown with external callbacks and stop IRQ/work producers before final writes."""
import argparse
import hashlib
import importlib.util
import json
import mmap
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/bq2589x_charger.c'
UNIT = DRIVER[:-2]
STATUS = 'M33_FULL_BQ_SHUTDOWN_STARTUP_WRITE_READ_ERRORS_PROBE_WT_ADC_RPM_CONFIG_1423_CRCS_37_MODULES_PASS_NOFLASH'
ERROR_MARKER = b'bq2589x: exhausted I2C read retries'
WRITE_ERROR_MARKER = b'bq2589x: IIO write failed'
STARTUP_ERROR_MARKER = b'bq2589x: probe resource unwind'
SHUTDOWN_MARKER = b'bq2589x: shutdown synchronized'
DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
DONOR_BLOBS = {
    'drivers/power/supply/qcom/bq2589x_charger.c': 'f94dadf5eec151380d05e85392aea2ecd52a2c79',
    'drivers/power/supply/qcom/bq2589x_iio.h': '326eb2e810d7446ce1f8ef17317868947ec350cc',
    'drivers/power/supply/qcom/bq2589x_reg.h': 'a7cf81b3e239c066df96db624554e85f09c1b9ef',
}



def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()


def profile():
    return json.loads((ROOT / 'References/PROFILE.json').read_text())


def pins():
    return json.loads((ROOT / 'References/SOURCE_PINS.json').read_text())


def check_donor_blobs(source):
    source = Path(source).resolve(strict=True)
    result = {}
    for name, expected in DONOR_BLOBS.items():
        data = (source / name).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()
        require(blob == expected, 'PINNED_DONOR_BLOB_CHANGED:' + name)
        result[name] = {'git_blob_sha': blob, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return result


def check_git_source(source):
    source = Path(source).resolve(strict=True)
    def git(*args):
        result = subprocess.run(['git', '-C', str(source), *args], text=True,
                                capture_output=True, timeout=30)
        require(result.returncode == 0, 'REAL_DONOR_GIT_CHECKOUT_REQUIRED')
        return result.stdout.strip()
    require(Path(git('rev-parse', '--show-toplevel')).resolve() == source,
            'REAL_DONOR_GIT_CHECKOUT_REQUIRED')
    require(git('rev-parse', 'HEAD') == DONOR_COMMIT, 'PINNED_DONOR_COMMIT_CHANGED')
    for name, expected in DONOR_BLOBS.items():
        row = git('ls-files', '--stage', '--', name).split()
        require(len(row) == 4 and row[1] == expected and row[2] == '0',
                'PINNED_DONOR_INDEX_CHANGED:' + name)
    return {'donor_commit': DONOR_COMMIT, 'source_hashes': source_check(source),
            'git_blobs': check_donor_blobs(source)}


def function(source, name):
    match = re.search(r'^(?:static\s+)?[^\n;]+\b' + name + r'\([^;]+?\n\{', source, re.M)
    require(match is not None, 'DRIVER_FUNCTION_REQUIRED:' + name)
    return source[match.start():source.index('\n}', match.end()) + 2]


def verify_package():
    names = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in names, 'UNSAFE_MANIFEST')
        require(not (ROOT / path).is_symlink() and sha(ROOT / path) == digest, 'PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names and len(pins()) == 3, 'PACKAGE_SCOPE_CHANGED')
    for name, pin in pins().items():
        for side in ['Before', 'After']:
            require(sha(ROOT / side / name) == pin[side.lower() + '_sha256'], 'SOURCE_FIXTURE_CHANGED:' + name)
    check_donor_blobs(ROOT / 'Before')
    reference = json.loads((ROOT / 'References/DONOR_GIT_BLOBS.json').read_text())
    require(reference['commit'] == DONOR_COMMIT and {r['path']: r['git_blob_sha'] for r in reference['files']} == DONOR_BLOBS, 'INDEPENDENT_DONOR_REFERENCE_CHANGED')
    selected = json.loads((ROOT / 'References/SELECTED_REPAIRS.json').read_text())
    before = (ROOT / 'Before' / DRIVER).read_text()
    expected = before
    for prefix in ['allocation', 'registration']:
        old, new = selected[prefix + '_before'], selected[prefix + '_after']
        require(expected.count(old) == 1, 'UNIQUE_PROBE_REPAIR_CONTEXT_REQUIRED:' + prefix)
        expected = expected.replace(old, new, 1)
    require(hashlib.sha256(expected.encode()).hexdigest()
            == '97f1c31d8ed22e5a730dbf8fae6f3a9ff6648d716b9e8a2ba5e352802bbfb576'
            and (ROOT / 'References/M29_PROVEN_BQ.c').read_text() == expected,
            'PROVEN_M29_PROBE_BASE_REQUIRED')
    proven=(ROOT/'References/M32_PROVEN_BQ.c').read_text()
    require(hashlib.sha256(proven.encode()).hexdigest()
            == '0e5eb0093755c26e1d5bc688f8cb89d405b7b4180127c15553ced11c36953daf',
            'PROVEN_M32_STARTUP_READ_WRITE_BASE_REQUIRED')
    names=json.loads((ROOT/'References/BQ_SHUTDOWN_FUNCTIONS.json').read_text())
    require(names==['bq2589x_force_dpdm_done','bq2589x_adapter_in_workfunc',
            'bq2589x_adapter_out_workfunc','bq2589x_ico_workfunc','bq2589x_force_workfunc',
            'bq2589x_monitor_workfunc','bq2589x_charger_irq_workfunc','bq2589x_charger_interrupt',
            'bq2589x_show_registers','bq2589x_charger_probe','bq2589x_charger_shutdown'],
            'EXACT_SHUTDOWN_REPAIR_SCOPE_REQUIRED')
    actual=(ROOT/'After'/DRIVER).read_text()
    neutral=actual
    for name in ['bq_iio_read_raw','bq_iio_write_raw']:
        body=function(actual,name+'_unlocked')
        require(body.replace(name+'_unlocked(',name+'(',1)==function(proven,name),
                'PROVEN_M32_CALLBACK_BODY_CHANGED:'+name)
        neutral=neutral.replace('\n\n'+function(actual,name),'',1)
        neutral=neutral.replace(body,function(proven,name),1)
    # Only stop checks and guarded scheduling may change the worker bodies.
    for name in names[:8]:
        body=function(actual,name)
        body=re.sub(r'(?m)^([ \t]*)if \(!READ_ONCE\(bq->stopping\)\)\n\1\t(schedule_(?:delayed_)?work\([^\n]+;[^\n]*)$',r'\1\2',body)
        body=body.replace('\n\tif (READ_ONCE(bq->stopping))\n\t\treturn'+(' IRQ_HANDLED'if name=='bq2589x_charger_interrupt'else'')+';\n','',1)
        if name=='bq2589x_force_dpdm_done':
            body=body.replace('\n\t\tif (READ_ONCE(bq->stopping))\n\t\t\treturn;','',1)
        require(body==function(proven,name),'WORKER_CHARGING_POLICY_CHANGED:'+name)
    for name in names:
        neutral=neutral.replace(function(actual,name),function(proven,name),1)
    field='\n\t/* Serialize external IIO/sysfs access with shutdown. */\n\tstruct mutex io_lock;\n\tbool stopping;\n\tbool irq_wake_enabled;'
    require(neutral.count(field)==1,'EXACT_PRIVATE_SHUTDOWN_FIELDS_REQUIRED')
    neutral=neutral.replace(field,'',1).replace('#include <linux/module.h>\n#include <linux/mutex.h>','#include <linux/module.h>',1)
    require(neutral==proven,'M33_UNAPPROVED_DRIVER_BYTES_CHANGED')
    require({n for n, p in pins().items() if p['before_sha256'] != p['after_sha256']} == {DRIVER},
            'ONLY_BQ_PROBE_DRIVER_MAY_CHANGE')
    require(sha(ROOT / 'References/HISTORICAL/0001-bq2589x-lifecycle-and-caller-errors.patch')
            == '4d8a5e752a83a923f686304b76c326951422ccbcfa69ca25d9de7933bec6d258',
            'HISTORICAL_PROBE_REPAIR_REFERENCE_CHANGED')


def source_check(source, after=False):
    source = Path(source).resolve(strict=True)
    result = {}
    for name, pin in pins().items():
        path = source / name
        require(path.is_file() and all(not p.is_symlink() for p in [path, *path.parents]
                if p.is_relative_to(source)), 'SOURCE_NOT_REGULAR:' + name)
        result[name] = sha(path)
        expected = pin['after_sha256' if after else 'before_sha256']
        require(result[name] == expected,
                'BQ_SOURCE_CONTEXT_CHANGED:' + name + ':expected=' + expected + ':actual=' + result[name])
    if not after:
        check_donor_blobs(source)
    return result


def apply_source(source):
    source = Path(source).resolve(strict=True)
    source_check(source)
    for name, pin in pins().items():
        if pin['before_sha256'] != pin['after_sha256']:
            (source / name).write_bytes((ROOT / 'After' / name).read_bytes())
    return source_check(source, after=True)


def linked_proof(text):
    patterns = {'bq_probe': r'bq2589x_charger_probe(?:[.$]\S+)?',
                'iio_read_callback': r'bq_iio_read_raw(?:[.$]\S+)?',
                'iio_write_callback': r'bq_iio_write_raw(?:[.$]\S+)?',
                'bq_shutdown_callback': r'bq2589x_charger_shutdown(?:[.$]\S+)?',
                'bq_initcall': r'__initcall_\S*bq2589x_charger_driver_init6(?:\.llvm\.\S+)?'}
    result = {}
    for key, pattern in patterns.items():
        found = re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(' + pattern + r')$', text)
        require(found, 'BQ_PROBE_INTERFACE_NOT_LINKED:' + key)
        result[key] = sorted(set(found))
    return result


def error_marker_proof(out, marker=ERROR_MARKER):
    result = {}
    for name in ['arch/arm64/boot/Image', 'vmlinux']:
        with (out / name).open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as data:
            result[name] = data.find(marker)
        require(result[name] >= 0, 'BQ_ERROR_BRANCH_NOT_LINKED:' + name)
    return result


def probe_proof(build):
    build = Path(build).resolve(strict=True)
    out = build / 'candidate-out'
    sources = source_check(build / 'candidate-source', after=True)
    require(sha(out / '.config') == profile()['baseline_config_sha256'], 'ACTUAL_M28_R2_CONFIG_CHANGED')
    require(sha(out / 'Module.symvers') == profile()['full_symvers_sha256'], 'FULL_M28_R2_EXPORT_TABLE_CHANGED')
    require(re.search(r'(?m)^CONFIG_BQ2589X_CHARGER=y$', (out / '.config').read_text()), 'BUILTIN_BQ_PROBE_REQUIRED')
    obj = out / (UNIT + '.o')
    cmd = obj.parent / ('.' + obj.name + '.cmd')
    with obj.open('rb') as f:
        require(f.read(4) in [b'BC\xc0\xde', b'\xde\xc0\x17\x0b'], 'BQ_PROBE_OBJECT_NOT_LLVM_BITCODE')
    command = cmd.read_text()
    require(DRIVER in command and '-flto=thin' in command and '-fsanitize=cfi' in command,
            'ACTUAL_BQ_PROBE_CFI_COMMAND_REQUIRED')
    return {'bq_shutdown_marker_offsets': error_marker_proof(out,SHUTDOWN_MARKER),
            'bq_startup_error_marker_offsets': error_marker_proof(out, STARTUP_ERROR_MARKER),
            'bq_read_error_marker_offsets': error_marker_proof(out),
            'bq_write_error_marker_offsets': error_marker_proof(out, WRITE_ERROR_MARKER), 'bq_probe_source_hashes': sources, 'bq_probe_object_sha256': sha(obj),
            'bq_probe_command_sha256': sha(cmd),
            'linked_bq_probe_interfaces': linked_proof((out / 'System.map').read_text()),
            'new_config_values_requested': [], 'actual_config_sha256': sha(out / '.config'),
            'full_symvers_sha256': sha(out / 'Module.symvers')}


def load_parent(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['m28_tool_sha256'], 'AUTHENTIC_M28_R2_TOOL_CHANGED')
    spec = importlib.util.spec_from_file_location('m33_original_m28', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def write_result(out, name, result):
    if out.is_dir():
        (out / name).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def build(args):
    verify_package()
    parent = load_parent(args.m28_tool)
    original = parent.apply_source
    out = Path(args.output).resolve()
    result = {'status': 'M33_BUILD_PENDING', 'kernel_compiled': False,
              'device_pass': False, 'flash_allowed': False, 'runtime_charging_tested': False,
              'baseline_run': profile()['baseline_run'], 'new_config_values_requested': []}

    def overlay(source):
        result['bq_probe_preflight'] = source_check(source)
        prior = original(source)
        result['applied_bq_probe_source_hashes'] = apply_source(source)
        return prior

    parent.apply_source = overlay
    try:
        parent.build(args)
        prior = parent.verify_fresh(out, parent.load_parent(args.m27_tool), args.m26_tool, args.m25_tool)
        require(prior['status'] == parent.STATUS and prior['kernel_compiled'] is True
                and prior['wt_reporting_source_compiled_and_linked'] is True, 'FULL_M28_R2_WT_ADC_RPM_BUILD_REQUIRED')
        result.update(probe_proof(out))
        require(result['bq_probe_source_hashes'] == result['applied_bq_probe_source_hashes'], 'PROBE_SOURCE_CHANGED_DURING_BUILD')
        require(prior['fully_matching_modules'] == 37 and prior['qgki_counts'] ==
                {'MATCH': 1423, 'CRC_MISMATCH': 0, 'NOT_EXPORTED': 0}, 'COMPLETE_QGKI_COHORT_REQUIRED')
        result.update(status=STATUS, kernel_compiled=True, bq_probe_source_compiled_and_linked=True, bq_read_error_paths_compiled_and_linked=True, bq_write_error_paths_compiled_and_linked=True, bq_startup_resource_paths_compiled_and_linked=True, bq_shutdown_paths_compiled_and_linked=True,
                      fully_matching_modules=37, qgki_counts=prior['qgki_counts'],
                      kernel_product_hashes=prior['kernel_product_hashes'], release=prior['release'])
    except Exception as error:
        result.update(status='M33_BUILD_OR_PROBE_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.apply_source = original
        write_result(out, 'M33_RESULT.json', result)
    print(result['status'], 'DEVICE_PASS=NO FLASH=NO')


def verify_fresh(build, parent, m27_tool, m26_tool, m25_tool):
    build = Path(build).resolve(strict=True)
    result = json.loads((build / 'M33_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('bq_probe_source_compiled_and_linked') is True
            and result.get('bq_read_error_paths_compiled_and_linked') is True
            and result.get('bq_write_error_paths_compiled_and_linked') is True
            and result.get('bq_startup_resource_paths_compiled_and_linked') is True
            and result.get('bq_shutdown_paths_compiled_and_linked') is True
            and result.get('runtime_charging_tested') is False
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_M33_FULL_SHUTDOWN_BUILD_REQUIRED')
    parent.verify_fresh(build, parent.load_parent(m27_tool), m26_tool, m25_tool)
    proof = probe_proof(build)
    require(all(result.get(k) == v for k, v in proof.items()), 'FRESH_PROBE_PROOF_CHANGED')
    for name, digest in result['kernel_product_hashes'].items():
        require(sha(build / 'candidate-out' / name) == digest, 'FRESH_KERNEL_PRODUCT_CHANGED:' + name)
    return result


def package(args):
    verify_package()
    parent = load_parent(args.m28_tool)
    result = verify_fresh(args.build, parent, args.m27_tool, args.m26_tool, args.m25_tool)
    out = Path(args.output).resolve()
    package_result = {'status': 'M33_PACKAGE_PENDING', 'static_boot_path_pass': False,
                      'device_pass': False, 'flash_allowed': False}
    try:
        parent.package(args)
        prior = json.loads((out / 'M28_PACKAGE_RESULT.json').read_text())
        require(prior['static_boot_path_pass'] is True and prior['device_pass'] is False, 'M28_R2_STATIC_PACKAGE_GATES_REQUIRED')
        for path in sorted((out / 'review').iterdir()):
            require(path.is_file() and path.name.startswith('VEUX_M28_R2_'), 'UNEXPECTED_REVIEW_FILE')
            target = path.with_name(path.name.replace('VEUX_M28_R2_', 'VEUX_M33_', 1))
            require(not target.exists(), 'REVIEW_TARGET_EXISTS')
            path.rename(target)
        pair = parent.load_parent(args.m27_tool).load_parent(args.m26_tool).load_parent(args.m25_tool).audit_pair(args.build, out)
        verify_fresh(args.build, parent, args.m27_tool, args.m26_tool, args.m25_tool)
        package_result.update(status='M33_BQ_SHUTDOWN_STARTUP_WRITE_READ_PROBE_WT_ADC_RPM_CONFIG_BOOT_AK3_PAIR_PASS_NOFLASH',
                              static_boot_path_pass=True, review_pair_sha256=pair,
                              kernel_release=result['release']['verified_release'])
    except Exception as error:
        package_result.update(status='M33_PACKAGE_GATE_FAILED_NOFLASH', error=str(error))
        review = out / 'review'
        if review.exists():
            review.rename(out / 'unverified-review')
        raise
    finally:
        write_result(out, 'M33_PACKAGE_RESULT.json', package_result)
    print('M33_BQ_SHUTDOWN_STARTUP_WRITE_READ_ERRORS_PROBE_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='op', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    sub.add_parser('check-git-source').add_argument('--source', required=True)
    b = sub.add_parser('build')
    for name in ('m28-tool', 'm27-tool', 'm26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-tool', 'r19-tool',
                 'r18-tool', 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + name, required=True)
    a = sub.add_parser('package')
    for name in ('m28-tool', 'm27-tool', 'm26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-package-tool',
                 'build', 'packager-tool', 'work', 'output'):
        a.add_argument('--' + name, required=True)
    args = p.parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'check-source':
        print(json.dumps(source_check(args.source), sort_keys=True))
    elif args.op == 'check-git-source':
        print(json.dumps(check_git_source(args.source), sort_keys=True))
    else:
        print('M33_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
