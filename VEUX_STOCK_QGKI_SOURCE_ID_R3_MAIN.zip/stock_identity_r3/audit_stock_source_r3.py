#!/usr/bin/env python3
"""Fail-closed, read-only source fingerprint audit for the ORIGINAL VEUX stock-QGKI image.

This does NOT rebuild, patch, or certify a kernel. Candidate Git blob SHA-1
values are tied to immutable commits; optional GitHub API checks verify them.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile
import urllib.error
import urllib.parse
import urllib.request
import zipfile

STOCK_RELEASE = '5.4.274-qgki-g82179e362f33'
ZIP_SHA = '45d7cebf4496301c2f1b32a635d2e3eb5fa6d55559919b20135a560e3be86189'
IMAGE_SHA = '6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
CONFIG_SHA = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
KHEADERS_SHA = '39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279'
TAR_SHA = '7755134abdfcd0aa0926acc7a06838256cc9da74cfbcbc12f03965461d50f262'
PREFIX = 'stock-qgki/' + STOCK_RELEASE
HEADERS = [
 'include/linux/sched.h', 'include/linux/fs.h', 'include/linux/security.h',
 'include/linux/rcupdate.h', 'include/linux/uidgid.h',
 'include/linux/sched/sysctl.h', 'include/linux/cpumask.h',
 'include/linux/kallsyms.h', 'include/linux/types.h', 'include/linux/mount.h',
 'include/uapi/linux/fs.h', 'include/uapi/linux/mount.h',
 'arch/arm64/include/asm/unistd.h',
]
CANDIDATES = {
 'xiaomi_veux_r_oss': {
  'repository': 'MiCode/Xiaomi_Kernel_OpenSource',
  'commit': '61397e524093d1ccb94769b5460825e2eaf8871e', 'source_version': '5.4.134',
  'blobs': ['888b27fe998a2bd6200144bcf06285da0ebe1aed','f97c1879a601d6ab9dcec144bc0615320a6077cc','269625983941a83b6c71f16c9b6839bfef5dbda9','09e6ac4b669b2b2ce67823229a90e0bafa0c3b47','b0542cd11aeb09f5d0c979e1acf31ad8d550bb6d','b6fdfd97a8f37837a599405b6d9583a3e2697ac0','4e226e8d737b72f35126341d3c59c0b0af282145','a45f5c0bc585781cf8fba78faa5094293fd1d0bf','05030f608be32224779a399360d407a84d396201','40714c6040e457678e1a7a3b0274e2bfdbfa2029','379a612f8f1d9f45d1703bc55a67fa677862b8d0','96a0240f23fed37be9430b72d2f2d9ffd6d42237','febc1aa577148d47217941200a639201a1d1d91f']},
 'positron_20240619': {
  'repository': 'dereference23/kernel_xiaomi_sm6375',
  'commit': 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632', 'source_version': '5.4.268',
  'blobs': ['c29af309e5bd38653b6d3c872d41723ba895646e','4158ac0dc8c6dfd542508d21c4f8a0d788ac9547','3e168fb4bb4437396d564dce5bd01286a12e7023','c75b38ba4a7282377bc838da35e4179d63fd0747','b0542cd11aeb09f5d0c979e1acf31ad8d550bb6d','494db4557d40b668866caa1060580d5c4ded12c2','a4bf0248afedbeb82ddcfe437ff74b1bf1b34517','a45f5c0bc585781cf8fba78faa5094293fd1d0bf','05030f608be32224779a399360d407a84d396201','40714c6040e457678e1a7a3b0274e2bfdbfa2029','379a612f8f1d9f45d1703bc55a67fa677862b8d0','96a0240f23fed37be9430b72d2f2d9ffd6d42237','b3b2019f8d16bbeef51948c249dcfb6dbd97a0fb']},
 'aosp_android11_5_4_274': {
  'repository': 'aosp-mirror/kernel_common',
  'commit': '181edea14ae07024cc87699f3cd49116e6f8fbb3', 'source_version': '5.4.274',
  'blobs': ['29aab47f59f5281322b7151b9461ec114f0e3ba7','8824a611cd58332122bdc3b85758e2ce6f95c862','66c49a244fd72b59e2767b6a7891c7d2b1d780be','bc4b5c905a602daa9d57dd0429915991cb21f864','b0542cd11aeb09f5d0c979e1acf31ad8d550bb6d','d4f6215ee03f7d03a517338b742e95f3a0400413','78a73eba64dd6f4d8faaf441f3e7e0c980a36c92','a45f5c0bc585781cf8fba78faa5094293fd1d0bf','05030f608be32224779a399360d407a84d396201','40714c6040e457678e1a7a3b0274e2bfdbfa2029','379a612f8f1d9f45d1703bc55a67fa677862b8d0','96a0240f23fed37be9430b72d2f2d9ffd6d42237','8c1b73dc8f55d17e2de2a2eb5b15fbb7695081be']},
}
FLAGS = ('CONFIG_ARCH_HOLI','CONFIG_QGKI','CONFIG_SCHED_WALT','CONFIG_MODULES','CONFIG_MODVERSIONS','CONFIG_CFI_CLANG','CONFIG_LTO_CLANG','CONFIG_IKHEADERS','CONFIG_KALLSYMS')
REGEX40 = re.compile(r'[0-9a-f]{40}\Z')

class AuditError(RuntimeError):
    pass


def require(condition, reason):
    if not condition:
        raise AuditError(reason)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\x00' + data).hexdigest()


def verify_candidate_pins():
    require(set(CANDIDATES) == {'xiaomi_veux_r_oss','positron_20240619','aosp_android11_5_4_274'}, 'CANDIDATE_SCOPE_DRIFT')
    for key, item in CANDIDATES.items():
        require(REGEX40.fullmatch(item['commit']) is not None, 'INVALID_CANDIDATE_COMMIT '+key)
        require(len(item['blobs']) == len(HEADERS), 'HEADER_PIN_LENGTH_MISMATCH '+key)
        require(all(REGEX40.fullmatch(x) for x in item['blobs']), 'INVALID_GIT_BLOB_SHA '+key)
        require(re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', item['repository']) is not None, 'INVALID_REPO '+key)


def unpack_verified_stock_reference(stock_zip):
    require(Path(stock_zip).is_file(), 'STOCK_R1_ARCHIVE_MISSING')
    require(file_sha256(stock_zip) == ZIP_SHA, 'STOCK_R1_ROOT_SHA_MISMATCH')
    with zipfile.ZipFile(stock_zip) as z:
        require(z.testzip() is None, 'STOCK_R1_ZIP_CRC_MISMATCH')
        manifest_path=PREFIX+'/RELEASE_MANIFEST.json'
        require(manifest_path in z.namelist(), 'STOCK_R1_MANIFEST_MISSING')
        manifest = json.loads(z.read(manifest_path))
        require(manifest['root']==PREFIX and manifest['kernel_release']==STOCK_RELEASE, 'STOCK_R1_RELEASE_DRIFT')
        require(manifest['stock_image_expected_sha256']==IMAGE_SHA, 'STOCK_R1_IMAGE_IDENTITY_DRIFT')
        require(manifest['stock_image_in_package'] is False and manifest['stock_kernel_source_complete'] is False and manifest['flashable'] is False and manifest['repository_write'] is False, 'STOCK_R1_SCOPE_DRIFT')
        cfgpath=PREFIX+'/evidence/stock_kernel.config'
        tarpath=PREFIX+'/evidence/stock_embedded_kheaders.tar.xz'
        require(set((cfgpath,tarpath)).issubset(set(manifest['files'])), 'STOCK_R1_REQUIRED_FILES_MISSING')
        cfg=z.read(cfgpath)
        xz=z.read(tarpath)
        require(sha256(cfg)==CONFIG_SHA==manifest['files'][cfgpath], 'STOCK_R1_CONFIG_SHA_MISMATCH')
        require(sha256(xz)==KHEADERS_SHA==manifest['files'][tarpath], 'STOCK_R1_KHEADERS_SHA_MISMATCH')
    with tarfile.open(fileobj=io.BytesIO(xz), mode='r:xz') as tar:
        members=tar.getmembers()
        require(len(members)==9405,'STOCK_HEADER_MEMBER_COUNT_DRIFT')
        for member in members:
            p=PurePosixPath(member.name)
            require(not p.is_absolute() and '..' not in p.parts, 'STOCK_HEADER_UNSAFE_PATH')
            require(member.isfile() or member.isdir() or member.issym(), 'STOCK_HEADER_UNSUPPORTED_TYPE')
        require(sum(m.isfile() for m in members)==7717, 'STOCK_HEADER_FILE_COUNT_DRIFT')
        require(sum(m.issym() for m in members)==2, 'STOCK_HEADER_SYMLINK_DRIFT')
        h={}
        for path in HEADERS + ['include/generated/utsrelease.h','include/generated/compile.h']:
            obj=tar.getmember('./'+path)
            require(obj.isfile(),'STOCK_HEADER_EXPECTED_REGULAR_FILE '+path)
            h[path]=tar.extractfile(obj).read()
        require('Module.symvers' not in {m.name.removeprefix('./') for m in members},'MODULE_SYMVERS_UNEXPECTED')
    require(sha256(xz)==KHEADERS_SHA,'STOCK_TAR_EMBEDDED_SHA_DRIFT')
    require(STOCK_RELEASE.encode() in h['include/generated/utsrelease.h'], 'STOCK_UTS_RELEASE_MISMATCH')
    compile_h=h['include/generated/compile.h'].decode('utf-8','replace')
    require('clang version 11.0.2' in compile_h, 'STOCK_CLANG_VERSION_DRIFT')
    cfgtext=cfg.decode('utf-8')
    values={}
    for flag in FLAGS:
        m=re.search(r'^'+re.escape(flag)+r'=(\S+)$',cfgtext,re.MULTILINE)
        values[flag]=m.group(1) if m else ('n' if re.search(r'^# '+re.escape(flag)+r' is not set$',cfgtext,re.MULTILINE) else 'unknown')
    for flag in FLAGS:
        require(values[flag]=='y', 'STOCK_CONFIG_REQUIRED_FLAG_NOT_Y '+flag)
    return {'headers':h,'flags':values,'config_sha256':sha256(cfg),'compiler':compile_h,'config_lines':len(cfgtext.splitlines())}


def compare_candidates(headermap):
    verify_candidate_pins()
    stock={name:blob_sha(headermap[name]) for name in HEADERS}
    result={}
    rows=[]
    for name,item in CANDIDATES.items():
        matches=[]
        for path, expected in zip(HEADERS, item['blobs']):
            row={'candidate':name,'source_version':item['source_version'],'path':path,
                 'stock_git_blob_sha1':stock[path],'source_git_blob_sha1':expected,
                 'exact':stock[path]==expected}
            rows.append(row)
            if row['exact']:matches.append(path)
        result[name]={'repository':item['repository'],'commit':item['commit'],
            'source_version':item['source_version'],'tested_headers':len(HEADERS),
            'exact_header_matches':len(matches),'matched_paths':matches,
            'full_source_identity_proven':False}
    return stock,rows,result


def remote_verify(blobs, token=None, fetcher=None):
    """Re-verify immutable GitHub commits only, don't consult mutable HEAD branches."""
    verify_candidate_pins()
    if fetcher is None:
        def fetcher(url):
            hdr={'Accept':'application/vnd.github+json','User-Agent':'VEUX-stock-source-identity-R3'}
            if token:
                hdr['Authorization']='Bearer '+token
            req=urllib.request.Request(url,headers=hdr)
            with urllib.request.urlopen(req,timeout=18) as response:
                data=response.read(2400000)
            return json.loads(data)
    outcome={}
    for name,item in CANDIDATES.items():
        observed=0
        failures=[]
        for path,pinned in zip(HEADERS,item['blobs']):
            url='https://api.github.com/repos/'+item['repository']+'/contents/'+urllib.parse.quote(path,safe='/')+'?ref='+item['commit']
            try:
                response=fetcher(url)
                remote_blob=response.get('sha')
                require(response.get('type')=='file' and response.get('path')==path and REGEX40.fullmatch(str(remote_blob)) is not None,
                        'REMOTE_UNEXPECTED_OBJECT '+name+' '+path)
                require(remote_blob==pinned, 'REMOTE_GIT_BLOB_PIN_DRIFT '+name+' '+path)
                observed+=1
            except Exception as exc:
                failures.append({'path':path,'type':type(exc).__name__,
                                 'reason':str(exc)[:100] if isinstance(exc, AuditError) else 'REMOTE_NOT_VERIFIED'})
        outcome[name]={'verified':observed,'expected':len(HEADERS),
                       'status':'COMPLETE' if observed==len(HEADERS) else 'INCOMPLETE',
                       'failures':failures}
    return outcome


def repository_history(repo):
    """Old updater is evidence of a DIFFERENT Image, never accepted as stock."""
    path=Path(repo)/'common/contracts/CURRENT_BUILD.json'
    if not path.exists():
        return {'available':False,'stock_source_equivalent':False,'reason':'CURRENT_BUILD_NOT_PRESENT'}
    contract=json.loads(path.read_text(encoding='utf-8'))
    old=contract.get('lineages',{}).get('5.4.274',{})
    old_image=old.get('image_sha256')
    old_config=old.get('config_audit',{}).get('actual_config_sha256')
    return {'available':True,'old_reference_image_sha256':old_image,
            'old_reference_config_sha256':old_config,
            'stock_image_sha256':IMAGE_SHA,'stock_config_sha256':CONFIG_SHA,
            'image_equal':old_image==IMAGE_SHA,
            'config_equal':old_config==CONFIG_SHA,
            'stock_source_equivalent':False,
            'reason':'OLD_BUILDS_CANNOT_CERTIFY_STOCK_SOURCE_OR_ABI'}


def write_report(output, ref, repo, remote):
    output=Path(output)
    require(not output.exists() or not any(output.iterdir()),'OUTPUT_DIR_MUST_BE_EMPTY')
    output.mkdir(parents=True,exist_ok=True)
    stock,rows,results=compare_candidates(ref['headers'])
    hist=repository_history(repo)
    result={'schema':1,'target_kernel_release':STOCK_RELEASE,'image_sha256':IMAGE_SHA,
        'image_bytes_present_in_reusable_zip':False,'stock_image_source_completeness':'HEADERS_ONLY',
        'stock_config_sha256':CONFIG_SHA,'stock_kheaders_compressed_sha256':KHEADERS_SHA,
        'stock_config_flags':ref['flags'],'stock_compiler':'Android Clang 11.0.2',
        'module_symvers_present':False,'candidate_fingerprints':results,
        'old_updater':hist,'remote_git_blob_verification':remote,
        'results':{'header_reference_authenticated':True,
           'candidate_full_source_proven':False,
           'module_abi_proven':False,'kernel_build_proven':False,
           'bakasu_susfs_nomount_integrated':False,'flash_approved':False},
        'gate':'BLOCKED_MISSING_MATCHING_COMPLETE_STOCK_SOURCE_AND_ABI',
        'warning':'13-header source similarity is NOT equivalent to full source or ABI identity.'}
    (output/'STOCK_SOURCE_IDENTITY_R3.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    with (output/'HEADER_FINGERPRINTS_R3.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['candidate','source_version','path','stock_git_blob_sha1','source_git_blob_sha1','exact'])
        writer.writeheader();writer.writerows(rows)
    (output/'INTEGRATION_GATE_R3.txt').write_text(
        'VEUX STOCK QGKI 5.4.274 SOURCE/ABI AUDIT R3\n'
        f'IMAGE SHA256: {IMAGE_SHA}\n'
        f'STOCK CONFIG SHA256: {CONFIG_SHA}\n'
        f'HEADER ENTRIES: 9405; ABI Module.symvers: MISSING\n'
        +''.join(f'{n}: {x["exact_header_matches"]}/{len(HEADERS)} EXACT HEADER MATCHES ({x["source_version"]})\n' for n,x in results.items())
        +'No candidate is proven to be the full matching stock tree.\n'
        +'Old custom updater artifacts are NOT interchangeable with this Image.\n'
        +'NO PATCH, NO BUILD, NO BOOT. FLASH APPROVAL: NO.\n',encoding='utf-8')
    return result


def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--stock-zip',required=True)
    p.add_argument('--repo-root',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--verify-remote',action='store_true')
    a=p.parse_args(argv)
    try:
        ref=unpack_verified_stock_reference(a.stock_zip)
        _,_,sums=compare_candidates(ref['headers'])
        remote=remote_verify(sums, os.environ.get('GITHUB_TOKEN')) if a.verify_remote else {'status':'NOT_REQUESTED'}
        result=write_report(a.output,ref,a.repo_root,remote)
        print('STOCK_QGKI_R3_HEADER_FINGERPRINTS=PASS')
        print('STOCK_QGKI_R3_MATCH_COUNTS='+','.join(f'{k}:{v["exact_header_matches"]}' for k,v in result['candidate_fingerprints'].items()))
        print('STOCK_QGKI_R3_GATE='+result['gate'])
        print('STOCK_QGKI_R3_KERNEL_BUILD=NOT_RUN; FLASH=NO')
    except (AuditError, OSError, ValueError, KeyError, zipfile.BadZipFile, tarfile.TarError) as e:
        raise SystemExit('STOCK_QGKI_R3_FAIL_CLOSED: '+str(e))

if __name__=='__main__':
    main()
