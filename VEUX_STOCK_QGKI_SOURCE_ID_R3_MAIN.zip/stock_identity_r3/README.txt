VEUX Stock QGKI 5.4.274 – Source Identity & ABI Gate R3

Source-of-truth: user-provided unmodified VEUX_5.4.274_qgki_Image
  SHA256 6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b
  Linux 5.4.274-qgki-g82179e362f33; WALT=y, CFI=y, LTO=y, MODVERSIONS=y.

Read-only audit uses existing root ZIP:
  VEUX_STOCK_QGKI_274_IMPORT_R1_MAIN.zip
  SHA256 45d7cebf4496301c2f1b32a635d2e3eb5fa6d55559919b20135a560e3be86189
This root ZIP contains verified stock kheaders and .config; it does NOT contain the Image binary or the full source tree.

Source candidates, pinned to immutable commits (read-only comparison):
  MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e (5.4.134)
  dereference23/kernel_xiaomi_sm6375@b2b7a3bbc36d120ee523ebc8d68e0f13a97df632 (5.4.268)
  aosp-mirror/kernel_common@181edea14ae07024cc87699f3cd49116e6f8fbb3 (5.4.274)

Method: 13 original header bytes -> Git blob SHA-1 -> pinned candidate blobs (verified via GitHub read, optional re-verification by GitHub API at run time). This is a narrow *fingerprint comparison*, NOT a reconstruction or full ABI test. Candidate matches are neither sufficient to prove identical full sources nor a reason to flash.

NoKernelBuild. No kernel edits. No GitHub repository writes. No boot.img. No AK3.
An unmodified matching stock source tree, full kernel ABI (incl. Module.symvers) and device boot tests are still missing.

Upload stock R3 MAIN ZIP to repo root and R3 YAML separately to .github/workflows.
Run only "VEUX Stock QGKI R3 - Source Identity Audit (NO BUILD)" once.
Artifact includes JSON and CSV report and non-flash gate description.
