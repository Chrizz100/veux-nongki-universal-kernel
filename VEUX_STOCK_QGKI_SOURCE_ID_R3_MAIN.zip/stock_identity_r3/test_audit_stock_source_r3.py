#!/usr/bin/env python3
"""Concrete positive and fail-closed controls for VEUX Stock source audit."""
import copy
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import audit_stock_source_r3 as s

SOURCE = Path(os.environ.get('VEUX_R3_STOCK_ZIP','/mnt/data/VEUX_STOCK_QGKI_274_IMPORT_R1_MAIN.zip'))

class StockAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.stock=s.unpack_verified_stock_reference(SOURCE)
        cls.sha,cls.rows,cls.matches=s.compare_candidates(cls.stock['headers'])

    def test_01_reference_archive_sha(self): self.assertEqual(s.file_sha256(SOURCE),s.ZIP_SHA)
    def test_02_target_release(self): self.assertEqual(s.STOCK_RELEASE,'5.4.274-qgki-g82179e362f33')
    def test_03_manifest_image_hash(self): self.assertEqual(len(s.IMAGE_SHA),64)
    def test_04_config_sha(self): self.assertEqual(self.stock['config_sha256'],s.CONFIG_SHA)
    def test_05_compiler_identified(self): self.assertIn('clang version 11.0.2',self.stock['compiler'])
    def test_06_walt_on(self): self.assertEqual(self.stock['flags']['CONFIG_SCHED_WALT'],'y')
    def test_07_cfi_on(self): self.assertEqual(self.stock['flags']['CONFIG_CFI_CLANG'],'y')
    def test_08_lto_on(self): self.assertEqual(self.stock['flags']['CONFIG_LTO_CLANG'],'y')
    def test_09_modules_on(self): self.assertEqual(self.stock['flags']['CONFIG_MODULES'],'y')
    def test_10_modversions_on(self): self.assertEqual(self.stock['flags']['CONFIG_MODVERSIONS'],'y')
    def test_11_holi_on(self): self.assertEqual(self.stock['flags']['CONFIG_ARCH_HOLI'],'y')
    def test_12_qgki_on(self): self.assertEqual(self.stock['flags']['CONFIG_QGKI'],'y')
    def test_13_ikheaders_on(self): self.assertEqual(self.stock['flags']['CONFIG_IKHEADERS'],'y')
    def test_14_canonical_header_count(self): self.assertEqual(len(s.HEADERS),13)
    def test_15_all_headers_extracted(self): self.assertEqual(set(s.HEADERS)|{'include/generated/utsrelease.h','include/generated/compile.h'},set(self.stock['headers']))
    def test_16_gitblob_format(self): self.assertTrue(all(re.fullmatch('[0-9a-f]{40}',h) for h in self.sha.values()))
    def test_17_all_3_candidates(self): self.assertEqual(len(self.matches),3)
    def test_18_candidate_sha_pins(self): s.verify_candidate_pins()
    def test_19_source_versions(self): self.assertEqual({v['source_version'] for v in self.matches.values()},{'5.4.134','5.4.268','5.4.274'})
    def test_20_xiaomi_no_exact_match(self): self.assertEqual(self.matches['xiaomi_veux_r_oss']['exact_header_matches'],0)
    def test_21_positron_no_exact_match(self): self.assertEqual(self.matches['positron_20240619']['exact_header_matches'],0)
    def test_22_aosp_no_exact_match(self): self.assertEqual(self.matches['aosp_android11_5_4_274']['exact_header_matches'],0)
    def test_23_all_matches_cannot_certify_full_tree(self): self.assertFalse(any(v['full_source_identity_proven'] for v in self.matches.values()))
    def test_24_fingerprint_csv_rows(self): self.assertEqual(len(self.rows),39)
    def test_25_constant_full_image_hash(self): self.assertEqual(s.IMAGE_SHA,'6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b')
    def test_26_root_sha_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            bad=Path(d)/'archive.zip';bad.write_bytes(b'fake')
            with self.assertRaisesRegex(s.AuditError,'ROOT_SHA_MISMATCH'): s.unpack_verified_stock_reference(bad)
    def test_27_missing_archive_rejected(self):
        with self.assertRaisesRegex(s.AuditError,'ARCHIVE_MISSING'): s.unpack_verified_stock_reference('/unavailable/VEUX.zip')
    def test_28_candidate_bad_blob_sha_rejected(self):
        saved=s.CANDIDATES
        try:
            s.CANDIDATES=copy.deepcopy(saved)
            s.CANDIDATES['aosp_android11_5_4_274']['blobs'][0]='missing'
            with self.assertRaisesRegex(s.AuditError,'INVALID_GIT_BLOB_SHA'):s.verify_candidate_pins()
        finally:s.CANDIDATES=saved
    def test_29_candidate_wrong_count_rejected(self):
        saved=s.CANDIDATES
        try:
            s.CANDIDATES=copy.deepcopy(saved)
            s.CANDIDATES['aosp_android11_5_4_274']['blobs'].pop()
            with self.assertRaisesRegex(s.AuditError,'HEADER_PIN_LENGTH_MISMATCH'):s.verify_candidate_pins()
        finally:s.CANDIDATES=saved
    def test_30_bad_commit_pin_rejected(self):
        saved=s.CANDIDATES
        try:
            s.CANDIDATES=copy.deepcopy(saved)
            s.CANDIDATES['xiaomi_veux_r_oss']['commit']='main'
            with self.assertRaisesRegex(s.AuditError,'INVALID_CANDIDATE_COMMIT'):s.verify_candidate_pins()
        finally:s.CANDIDATES=saved
    def test_31_remote_all_verified_mock(self):
        def fake(url):
            for item in s.CANDIDATES.values():
                if item['commit'] in url:
                    for path,sha in zip(s.HEADERS,item['blobs']):
                        if path+'?ref=' in url:return {'path':path,'sha':sha,'type':'file'}
            raise AssertionError('unexpected URL')
        r=s.remote_verify(None, fetcher=fake)
        self.assertTrue(all(v['status']=='COMPLETE' and v['verified']==13 for v in r.values()))
    def test_32_remote_mismatch_cannot_pass(self):
        def bad(url):
            path=url.split('/contents/')[1].split('?ref=')[0]
            return {'path':path,'sha':'0'*40,'type':'file'}
        r=s.remote_verify(None, fetcher=bad)
        self.assertTrue(all(v['status']=='INCOMPLETE' and v['verified']==0 for v in r.values()))
        self.assertIn('AuditError',r['xiaomi_veux_r_oss']['failures'][0]['type'])
    def test_33_remote_offline_cannot_pass(self):
        def denied(_): raise ConnectionError('offline')
        r=s.remote_verify(None,fetcher=denied)
        self.assertTrue(all(v['status']=='INCOMPLETE' for v in r.values()))
    def test_34_wrong_remote_path_cannot_pass(self):
        def wrong(_): return {'type':'file','path':'../evil','sha':'a'*40}
        r=s.remote_verify(None,fetcher=wrong)
        self.assertEqual(r['positron_20240619']['verified'],0)
    def test_35_no_uncontrolled_repository_mutation(self):
        source=Path(s.__file__).read_text()
        for needle in ('git push','git commit','git reset --hard','flashboot','fastboot flash','magiskboot repack'):
            self.assertNotIn(needle,source)
    def test_36_verified_report_gate(self):
        with tempfile.TemporaryDirectory() as d:
            result=s.write_report(Path(d)/'out', self.stock, Path(d), {'status':'NOT_REQUESTED'})
            self.assertEqual(result['gate'],'BLOCKED_MISSING_MATCHING_COMPLETE_STOCK_SOURCE_AND_ABI')
            self.assertFalse(result['results']['flash_approved'])
            self.assertFalse(result['results']['module_abi_proven'])
            self.assertFalse(result['results']['kernel_build_proven'])
    def test_37_refuses_populated_output(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'out';out.mkdir();(out/'old').write_text('x')
            with self.assertRaisesRegex(s.AuditError,'OUTPUT_DIR_MUST_BE_EMPTY'):
                s.write_report(out,self.stock,d,{'status':'NOT_REQUESTED'})
    def test_38_report_is_complete_and_parseable(self):
        with tempfile.TemporaryDirectory() as d:
            s.write_report(Path(d)/'o',self.stock,d,{'status':'NOT_REQUESTED'})
            out=Path(d)/'o'
            m=json.loads((out/'STOCK_SOURCE_IDENTITY_R3.json').read_text())
            self.assertEqual(m['target_kernel_release'],s.STOCK_RELEASE)
            self.assertTrue((out/'HEADER_FINGERPRINTS_R3.csv').exists())
            self.assertIn('FLASH APPROVAL: NO',(out/'INTEGRATION_GATE_R3.txt').read_text())
    def test_39_old_custom_is_not_stock(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'common/contracts';p.mkdir(parents=True)
            (p/'CURRENT_BUILD.json').write_text(json.dumps({'lineages':{'5.4.274':{'image_sha256':'f25157822979c464ad857aeab9472d799f122b807d7be58f9d18a8e64b092eea','config_audit':{'actual_config_sha256':'5904f8d2439e2cb05ef3db7edbe653d269e070b0e28d7e131a44600d61bab229'}}}}))
            result=s.repository_history(d)
            self.assertFalse(result['image_equal'])
            self.assertFalse(result['config_equal'])
            self.assertFalse(result['stock_source_equivalent'])
    def test_40_no_missing_history_claim(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(s.repository_history(d)['available'])
    def test_41_zip_mutation_guard(self):
        with tempfile.TemporaryDirectory() as d:
            tampered=Path(d)/'altered.zip'
            b=bytearray(Path(SOURCE).read_bytes());b[-50]^=1;tampered.write_bytes(b)
            with self.assertRaisesRegex(s.AuditError,'ROOT_SHA_MISMATCH'): s.unpack_verified_stock_reference(tampered)
    def test_42_source_fingerprints_read_only(self):
        self.assertTrue(all(isinstance(v,bytes) and len(v)>10 for v in self.stock['headers'].values()))

if __name__ == '__main__':unittest.main(verbosity=2)
