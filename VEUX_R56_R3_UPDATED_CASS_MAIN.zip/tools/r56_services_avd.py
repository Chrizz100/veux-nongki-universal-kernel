#!/usr/bin/env python3
"""Create an explicit, non-flashable SUSFS AVD read-path patch for Xiaomi's 5.4 services.c.

The unchanged Xiaomi `veux-r-oss` blob is an *anchor*, not evidence that the
modified R13/R41 kernel candidate contains that exact blob.  Any drift blocks
application until a manual three-way review. No SELinux state is written by
this program, nor does it compile or endorse the resulting candidate.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import stat
import sys

XIAOMI_REF = 'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e:security/selinux/ss/services.c'
XIAOMI_BLOB = '6559767d34444c54c03be4d821f64b9745c4ef54'
SYMBOL = 'susfs_spoof_avd_allowed_rcu'

class Blocked(RuntimeError):
    pass

def require(ok: bool, msg: str):
    if not ok:
        raise Blocked(msg)

def blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def create(src: bytes, *, require_xiaomi_blob: bool = True) -> tuple[bytes,dict]:
    if require_xiaomi_blob:
        require(blob(src) == XIAOMI_BLOB, 'STOCK_SERVICES_BLOB_DRIFT_REVIEW_REQUIRED')
    text = src.decode('utf-8')
    require(SYMBOL not in text, 'SELINUX_AVD_ALREADY_INSERTED_REVIEW_REQUIRED')
    header_anchor = '#include "audit.h"\n\n'
    require(text.count(header_anchor)==1, 'SERVICES_HEADER_ANCHOR_MISSING_OR_DUPLICATED')
    function_anchor = 'void security_compute_av_user(struct selinux_state *state,'
    require(text.count(function_anchor)==1, 'REAL_5_4_AVD_FUNCTION_MISSING_OR_DUPLICATED')
    start = text.index(function_anchor)
    end = text.find('\n/*',start)
    require(end>start and end-start < 4000, 'REAL_5_4_AVD_FUNCTION_BOUNDARY_CHANGED')
    body = text[start:end]
    require('read_lock(&state->ss->policy_rwlock);' in body, 'REAL_5_4_POLICY_LOCK_MISSING')
    require('read_unlock(&state->ss->policy_rwlock);' in body, 'REAL_5_4_POLICY_UNLOCK_MISSING')
    check = ('\tcontext_struct_compute_av(policydb, scontext, tcontext, tclass, avd,\n'
             '\t\t\t\t  NULL);\n out:\n')
    require(body.count(check)==1, 'REAL_5_4_POST_COMPUTE_ANCHOR_MISMATCH')
    declarations = ('#ifdef CONFIG_KSU_SUSFS\n'
                    '/* SUSFS type-AVD registry; source must be built into this kernel. */\n'
                    'extern void susfs_spoof_avd_allowed_rcu(u32 s_type, u32 t_type,\n'
                    '                                              u32 c_type, u32 *avd_allowed);\n'
                    '#endif\n\n')
    text = text.replace(header_anchor,header_anchor+declarations,1)
    replacement = (check[:-len(' out:\n')]
                   + '#ifdef CONFIG_KSU_SUSFS\n'
                   + '\t/* Called only after the real policy has computed the AVD. */\n'
                   + '\trcu_read_lock();\n'
                   + '\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
                   + '\t\t\t\t   tclass, &avd->allowed);\n'
                   + '\trcu_read_unlock();\n'
                   + '#endif\n out:\n')
    require(text.count(check)==1, 'AVD_BODY_OUTSIDE_EXPECTED_SCOPE')
    text=text.replace(check,replacement,1)
    require(text.count(SYMBOL+'(')==2, 'AVD_CALL_AND_PROTOTYPE_COUNT_INVALID')
    require(text.count('rcu_read_lock();')==src.decode().count('rcu_read_lock();')+1,
            'EXTRA_RCU_LOCKS_NOT_ALLOWED')
    require(text.count('rcu_read_unlock();')==src.decode().count('rcu_read_unlock();')+1,
            'EXTRA_RCU_UNLOCKS_NOT_ALLOWED')
    require(text.count('read_unlock(&state->ss->policy_rwlock);')==src.decode().count('read_unlock(&state->ss->policy_rwlock);'),
            'SELINUX_LOCK_BEHAVIOR_CHANGED')
    return text.encode(),{'reference':XIAOMI_REF,'reference_git_blob':XIAOMI_BLOB,
                         'pre_sha256':sha(src),'post_sha256':sha(text.encode()),
                         'scope':'one guarded AVD call inside security_compute_av_user plus a declaration',
                         'compiled':False,'whole_CASS_source_integrated':False,'flash_allowed':False}

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--services',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    try:
        require(a.services.is_file() and not a.services.is_symlink(), 'INPUT_NOT_REGULAR')
        require(stat.S_ISREG(a.services.lstat().st_mode),'INPUT_SPECIAL_FILE_REJECTED')
        require(a.out.parent.is_dir() and not a.out.exists() and not a.out.is_symlink(), 'OUTPUT_NOT_NEW')
        require(not a.out.resolve().is_relative_to(a.services.parent.resolve()), 'CANNOT_WRITE_TO_SOURCE_TREE')
        original=a.services.read_bytes()
        updated,report=create(original)
        a.out.mkdir(mode=0o700)
        delta=''.join(difflib.unified_diff(original.decode().splitlines(True),updated.decode().splitlines(True),
                  fromfile='a/security/selinux/ss/services.c',tofile='b/security/selinux/ss/services.c'))
        (a.out/'R56_SERVICES_5_4_AVD_SOURCE_ONLY.patch').write_text(delta)
        (a.out/'R56_SERVICES_AVD_GATE.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        print('R56_STOCK54_SERVICES_AVD_STATIC_SOURCE_PASS__NO_BUILD_NO_FLASH')
        return 0
    except (Blocked,OSError,ValueError,UnicodeError) as e:
        print('R56_SERVICES_AVD_BLOCKED='+str(e),file=sys.stderr)
        return 3
if __name__=='__main__':
    sys.exit(main())
