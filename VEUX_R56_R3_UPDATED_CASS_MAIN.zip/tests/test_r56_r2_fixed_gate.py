from pathlib import Path
import zipfile,unittest,json
ROOT=Path(__file__).resolve().parents[1]
class FixedReferenceGate(unittest.TestCase):
 def test_01_r54_pin_uses_actual_nested_archive(self):
  from hashlib import sha256
  import importlib.util
  p=ROOT/'tools/r56_source_gate.py'
  spec=importlib.util.spec_from_file_location('gate_r2',p)
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  self.assertEqual(m.PINS['R54'],sha256((ROOT/'references/VEUX_R54_CASS_SOURCE_MAIN.zip').read_bytes()).hexdigest())
 def test_02_fixed_r54_source_is_packaged(self):
  with zipfile.ZipFile(ROOT/'references/VEUX_R54_CASS_SOURCE_MAIN.zip') as z:
   s=z.read('tools/r54/r54_susfs_54_references.py').decode()
   self.assertIn('JACK_AVD_IMPLEMENTATION_MISSING',s)
   self.assertIn('security/selinux/ss/services.c',s)
   self.assertNotIn("'susfs_spoof_avd_allowed_rcu' not in jackpatch",s)
 def test_03_r54_real_regression_is_packaged(self):
  with zipfile.ZipFile(ROOT/'references/VEUX_R54_CASS_SOURCE_MAIN.zip') as z:
   s=z.read('tests/r54/test_r54_gates.py').decode()
   self.assertIn('test_21_avd_definition_in_jack_fs_is_not_selinux_host_hook',s)
 def test_04_runtime_error_is_shown_not_only_generic(self):
  s=(ROOT/'tools/R56_GITHUB_SOURCE_AND_BOOT_GATES_NOFLASH.sh').read_text()
  self.assertIn('tail -n 65',s)
  self.assertIn('fail R54_REAL_UPSTREAM_REPLAY_BLOCKED',s)
 def test_05_never_flash_or_build(self):
  import importlib.util
  spec=importlib.util.spec_from_file_location('gate_r2',ROOT/'tools/r56_source_gate.py')
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  from tempfile import TemporaryDirectory
  with TemporaryDirectory() as d:
   z=m.audit_new_build(Path(d))
   self.assertFalse(z['flash_allowed'])
   self.assertEqual(z['status'],'NO_NEW_KERNEL_BUILD_RECEIPT')
if __name__=='__main__':unittest.main()
