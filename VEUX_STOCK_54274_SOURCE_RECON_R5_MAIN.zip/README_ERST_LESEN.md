# R5 VEUX Stock-Kernel 5.4.274 – originale core_ctl.h als DIAGNOSE-Header

Dieses Paket nutzt ausschließlich die SHA256-verifizierte `include/linux/sched/core_ctl.h` (799 Byte) aus den eingebetteten Headern des vom Nutzer gesicherten Stock-Images. Es erfindet keine Dummy-Stubs und überschreibt keine existierende Quelldatei. Die Headerdatei wird ausschließlich in den separaten Diagnose-Worktree aus R4 kopiert. R1/R2/R4 MAIN bleiben unverändert. GitHub erzeugt nur Textdiagnostik, keine Flash-Dateien.

Header SHA256 `bc73b24be7b7ffad9807d23f7eae5b16771c08aa37082493cd41f2b191ccd1d8`.
Stock-Headerarchiv SHA256 `39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279`.
Spenderquellbaum **5.4.268**, nicht original Xiaomi 5.4.274. Noch keine verifizierte OEM-ABI, keine korrekt geprüfte R4 Sperr-Synchronisation, keine Boot-/Flashfreigabe.
