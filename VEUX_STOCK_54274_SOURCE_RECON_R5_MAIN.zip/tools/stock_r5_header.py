#!/usr/bin/env python3
"""R5 NOFLASH: stage one byte-identical Stock kheaders file into an isolated donor worktree.

The archived reference is kernel-embedded kheaders, not a validated OEM source tree.
Never stages code into the repository and never grants ABI/boot/flash approval.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

DONOR_SHA = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
STOCK_TAR_SHA = '39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279'
STOCK_HEADER_SHA = 'bc73b24be7b7ffad9807d23f7eae5b16771c08aa37082493cd41f2b191ccd1d8'
STOCK_HEADER = 'include/linux/sched/core_ctl.h'
TAR_MEMBER_NAME = './' + STOCK_HEADER
R4_CHANGED_FILES = {'kernel/sched/debug.c', 'mm/vmscan.c'}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def extract_verified_header(tar_path: Path) -> bytes:
    if not tar_path.is_file() or tar_path.is_symlink():
        raise ValueError('R5_STOCK_HEADER_ARCHIVE_INVALID')
    compressed = tar_path.read_bytes()
    if len(compressed) > 7_000_000 or sha256(compressed) != STOCK_TAR_SHA:
        raise ValueError('R5_STOCK_HEADER_ARCHIVE_SHA_DRIFT')
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:xz') as tar:
        found = [m for m in tar.getmembers() if m.name in (TAR_MEMBER_NAME, STOCK_HEADER)]
        if len(found) != 1 or not found[0].isfile() or found[0].size != 799:
            raise ValueError('R5_STOCK_HEADER_MEMBER_INVALID')
        handle = tar.extractfile(found[0])
        if handle is None:
            raise ValueError('R5_STOCK_HEADER_EXTRACT_FAILED')
        data = handle.read()
    if len(data) != 799 or sha256(data) != STOCK_HEADER_SHA:
        raise ValueError('R5_STOCK_HEADER_CONTENT_SHA_DRIFT')
    if b'#define __CORE_CTL_H' not in data or b'core_ctl_notifier_register' not in data or b'#ifdef CONFIG_SCHED_WALT' not in data:
        raise ValueError('R5_STOCK_HEADER_CONTENT_UNEXPECTED')
    return data


def git(cwd: Path, *args: str) -> str:
    p = subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True)
    if p.returncode:
        raise ValueError(f'R5_GIT_FAILED:{args[0]}:rc={p.returncode}:{p.stderr[-350:]}')
    return p.stdout.strip()


def stage(r1: Path, donor: Path, worktree: Path, reports: Path) -> dict:
    r1, donor, worktree, reports = map(lambda p: p.resolve(), (r1, donor, worktree, reports))
    header = extract_verified_header(r1/'reference/stock_kheaders.tar.xz')
    if not (donor/'.git').exists() or not worktree.is_dir():
        raise ValueError('R5_NOT_SEPARATE_WORKTREE')
    if donor == worktree or not (worktree/'.git').exists():
        raise ValueError('R5_WORKTREE_NOT_GIT')
    if git(donor,'rev-parse','HEAD') != DONOR_SHA or git(worktree,'rev-parse','HEAD') != DONOR_SHA:
        raise ValueError('R5_DONOR_COMMIT_DRIFT')
    if git(donor,'status','--porcelain'):
        raise ValueError('R5_ORIGINAL_DONOR_DIRTY')
    if set(git(worktree,'diff','--name-only').splitlines()) != R4_CHANGED_FILES:
        raise ValueError('R5_R4_PATCH_SET_DRIFT')
    if git(worktree,'ls-files','--others','--exclude-standard'):
        raise ValueError('R5_UNTRACKED_WORKTREE_CONTENT')
    dst = worktree/STOCK_HEADER
    if dst.exists() or dst.is_symlink() or (donor/STOCK_HEADER).exists():
        raise ValueError('R5_HEADER_ALREADY_PRESENT_OR_OVERWRITE')
    if not dst.parent.is_dir() or any((worktree/p).is_symlink() for p in ('include', 'include/linux', 'include/linux/sched')):
        raise ValueError('R5_HEADER_PARENT_UNSAFE')
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    if hasattr(os, 'O_NOFOLLOW'):
        flags |= os.O_NOFOLLOW
    fd = os.open(dst, flags, 0o644)
    with os.fdopen(fd,'wb') as f:
        f.write(header)
    if dst.read_bytes() != header or sha256(dst.read_bytes()) != STOCK_HEADER_SHA:
        raise ValueError('R5_STAGED_HEADER_NOT_IDENTICAL')
    if git(donor,'status','--porcelain'):
        raise ValueError('R5_ORIGINAL_DONOR_MODIFIED')
    if git(worktree,'ls-files','--others','--exclude-standard') != STOCK_HEADER:
        raise ValueError('R5_UNEXPECTED_UNTRACKED_FILES_AFTER_STAGE')
    reports.mkdir(parents=True,exist_ok=True)
    report = {'status':'R5_VERIFIED_STOCK_HEADER_STAGED_IN_ISOLATED_WORKTREE',
      'stock_header':STOCK_HEADER,'stock_header_bytes':799,'stock_header_sha256':STOCK_HEADER_SHA,
      'stock_kheaders_tar_sha256':STOCK_TAR_SHA,'stock_reference_origin':'embedded-kheaders-from-user-stock-image',
      'donor_commit':DONOR_SHA,'donor_source_version':'5.4.268',
      'original_donor_clean':True,'prior_r4_source_edits':sorted(R4_CHANGED_FILES),
      'injected_files':[STOCK_HEADER], 'stock_5_4_274_source_recovered':False,
      'full_stock_abi_verified':False,'boot_img_produced':False,'flash_allowed':False,
      'warning':'Header declaration alone does not establish WALT implementation, symbol ABI or runtime compatibility.'}
    (reports/'R5_STOCK_HEADER_STAGE.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


def summarize(log: Path, return_code: Path, output: Path) -> dict:
    lines=log.read_text(encoding='utf-8',errors='replace').splitlines()
    code=int(return_code.read_text().strip())
    errors=[{'line':n+1,'text':t.strip()[:1024]} for n,t in enumerate(lines)
            if re.search(r'(?<!LLVM )\berror:|\bfatal error:',t,re.I)]
    pipe=sum('LLVM ERROR: IO failure on output stream: Broken pipe' in t for t in lines)
    report={'status':'DONOR_COMPILE_DIAGNOSTIC_PASS' if code==0 else 'DONOR_COMPILE_DIAGNOSTIC_FAILED',
       'exit_code':code,'donor_version':'5.4.268','stock_kernel_version':'5.4.274',
       'line_count':len(lines),'compiler_error_count':len(errors),'compiler_errors':errors[:160],
       'llvm_broken_pipe_count':pipe,'image_flashable':False,'oem_abi_verified':False,
       'full_stock_source_reproduced':False,'boot_tested':False,'flash_allowed':False,
       'meaning':'Experimental donor compile with two R4 edits and original stock core_ctl.h. This is NOT OEM kernel compatibility.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser()
    p=parser.add_subparsers(dest='command',required=True)
    a=p.add_parser('stage')
    for n in ('r1','donor','worktree','reports'):
        a.add_argument('--'+n,type=Path,required=True)
    b=p.add_parser('summarize')
    for n in ('log','return-code','output'):
        b.add_argument('--'+n,type=Path,required=True)
    x=parser.parse_args()
    r=stage(x.r1,x.donor,x.worktree,x.reports) if x.command=='stage' else summarize(x.log,x.return_code,x.output)
    print(json.dumps({k:v for k,v in r.items() if k not in ('compiler_errors','prior_r4_source_edits')},sort_keys=True))

if __name__=='__main__':
    main()
