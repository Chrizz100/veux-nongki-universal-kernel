import io
import json
import sys
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest import mock
import stock_r5_header as r

class StockHeaderTests(unittest.TestCase):
    def test_sha_match_known_bytes(self):
        self.assertEqual(r.STOCK_HEADER_SHA,'bc73b24be7b7ffad9807d23f7eae5b16771c08aa37082493cd41f2b191ccd1d8')
    def test_original_stock_header_from_real_archive(self):
        root=Path(__file__).resolve().parents[2]
        tar=root/'r1'/'reference'/'stock_kheaders.tar.xz'
        if not tar.is_file():
            self.skipTest('Full original R1 stock archive required to test against original bytes')
        data=r.extract_verified_header(tar)
        self.assertEqual(len(data),799)
        self.assertEqual(r.sha256(data),r.STOCK_HEADER_SHA)
    def test_missing_archive_fails(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'ARCHIVE_INVALID'):
                r.extract_verified_header(Path(d)/'missing.tar.xz')
    def test_bad_sha_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'sample.tar.xz';f.write_bytes(b'fake')
            with self.assertRaisesRegex(ValueError,'SHA_DRIFT'):
                r.extract_verified_header(f)
    def test_symlink_archive_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'sample.tar.xz';f.write_bytes(b'fake')
            q=Path(d)/'link.tar.xz';q.symlink_to(f)
            with self.assertRaisesRegex(ValueError,'ARCHIVE_INVALID'):
                r.extract_verified_header(q)
    def test_duplicate_tar_member_fails(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'foo.tar.xz'
            with tarfile.open(file,'w:xz') as t:
                for _ in range(2):
                    n=tarfile.TarInfo(r.TAR_MEMBER_NAME);n.size=799
                    t.addfile(n,io.BytesIO(b'a'*799))
            with mock.patch.object(r,'STOCK_TAR_SHA',r.sha256(file.read_bytes())):
                with self.assertRaisesRegex(ValueError,'MEMBER_INVALID'):
                    r.extract_verified_header(file)
    def test_member_data_mismatch(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'foo.tar.xz'
            with tarfile.open(file,'w:xz') as t:
                n=tarfile.TarInfo(r.TAR_MEMBER_NAME);n.size=799
                t.addfile(n,io.BytesIO(b'a'*799))
            with mock.patch.object(r,'STOCK_TAR_SHA',r.sha256(file.read_bytes())):
                with self.assertRaisesRegex(ValueError,'CONTENT_SHA_DRIFT'):
                    r.extract_verified_header(file)
    def test_non_regular_member_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'foo.tar.xz'
            with tarfile.open(file,'w:xz') as t:
                n=tarfile.TarInfo(r.TAR_MEMBER_NAME);n.type=tarfile.SYMTYPE;n.linkname='/tmp/fake'
                t.addfile(n)
            with mock.patch.object(r,'STOCK_TAR_SHA',r.sha256(file.read_bytes())):
                with self.assertRaisesRegex(ValueError,'MEMBER_INVALID'):
                    r.extract_verified_header(file)
    def test_empty_log_return_code_error(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'build.log').write_text('fatal error: missing\nLLVM ERROR: IO failure on output stream: Broken pipe\n')
            (p/'rc').write_text('2')
            out=r.summarize(p/'build.log',p/'rc',p/'out.json')
            self.assertEqual(out['compiler_error_count'],1)
            self.assertEqual(out['llvm_broken_pipe_count'],1)
            self.assertFalse(out['flash_allowed'])
            self.assertEqual(json.loads((p/'out.json').read_text())['exit_code'],2)
    def test_clean_build_never_flash(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'build.log').write_text('CC kernel/sched/debug.o\n');(p/'rc').write_text('0')
            out=r.summarize(p/'build.log',p/'rc',p/'out.json')
            self.assertEqual(out['status'],'DONOR_COMPILE_DIAGNOSTIC_PASS')
            self.assertFalse(out['image_flashable'])
            self.assertFalse(out['oem_abi_verified'])
    def test_stage_rejects_non_git(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);ref=p/'reference';ref.mkdir()
            with mock.patch.object(r,'extract_verified_header',return_value=b'a'*799):
                with self.assertRaisesRegex(ValueError,'NOT_SEPARATE_WORKTREE'):
                    r.stage(p,p/'donor',p/'work',p/'reports')
    def test_git_head_pin_known(self):
        self.assertEqual(len(r.DONOR_SHA),40)
        self.assertEqual(r.STOCK_HEADER,'include/linux/sched/core_ctl.h')

if __name__=='__main__': unittest.main()
