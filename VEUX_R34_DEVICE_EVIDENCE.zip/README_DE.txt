VEUX R34 R2: Root-unterstuetzte Nur-Lese-Diagnose. Keine Partition oder Modul veraendert.
