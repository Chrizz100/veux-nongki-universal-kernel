#!/usr/bin/env python3
"""Real 5.4.274 WALT-on ARM64 R11 object diagnostic, no image or flash.
Reuse the unchanged, pinned R9 make runner and historical Android clang 12.0.5.
"""
import argparse, hashlib, importlib.util, json, shutil, sys
from pathlib import Path

class GateError(Exception): pass

def check(ok, message):
    if not ok: raise GateError(message)

def run(snapshot,r10_gate,r11_gate,r9_report,report,stock,toolchain,driver):
    check(r10_gate.is_file() and r11_gate.is_file(),'SOURCE_GATES_MISSING')
    g10=json.loads(r10_gate.read_text())
    g11=json.loads(r11_gate.read_text())
    check(g10['status']=='R10_OEM_WALT_SOURCE_API_STAGED_NOT_COMPILED','BAD_R10_GATE')
    check(g11['status']=='R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED','BAD_R11_GATE')
    for key, value in g10['after_sha256'].items():
        check(g11['before_sha256'].get(key)==value,'R10_R11_CHAIN_BROKEN:'+key)
    check(g11['before_sha256'].get('kernel/sched/fair.c')=='71c88ae1771d35fb23c5b05217a0d9e6aa73eb3e6fe747ad087fef8f76a3b87c','P10_FAIR_PREIMAGE_DRIFT')
    check(g11['modified_files']==['include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c','kernel/sched/fair.c'],'R11_SCOPE_DRIFT')
    check(not any(g11[k] for k in ('kernel_image_built','all_objects_compiled','flash_allowed','vendor_abi_proven','brene_changed','bakasusu_nomount_changed')),'R11_FALSE_APPROVAL')
    for f,expected in g11['after_sha256'].items():
        p=snapshot/f
        check(p.is_file() and not p.is_symlink(),'R11_MISSING_SOURCE:'+f)
        check(hashlib.sha256(p.read_bytes()).hexdigest()==expected,'R11_POSTIMAGE_DRIFT:'+f)
    check(not report.exists() and not report.is_symlink(),'REPORT_ALREADY_EXISTS')
    check(driver.is_file() and not driver.is_symlink(),'R9_DRIVER_MISSING')
    spec=importlib.util.spec_from_file_location('r9_original_pinned',driver)
    check(spec and spec.loader,'R9_ORIGINAL_CANNOT_LOAD')
    r9=importlib.util.module_from_spec(spec);spec.loader.exec_module(r9)
    check(r9.R8_SCHED_HASH==g10['before_sha256']['kernel/sched/sched.h'],'R9_ORIGINAL_DRIVER_PIN_DRIFT')
    r9.R8_SCHED_HASH=g11['after_sha256']['kernel/sched/sched.h']
    stage=r9_report/'R9_STAGE_REPORT.json'
    check(stage.is_file() and not stage.is_symlink(),'R9_STAGE_PROOF_MISSING')
    s=json.loads(stage.read_text())
    check(s['status']=='R9_SOURCE_SNAPSHOT_STAGED' and Path(s['snapshot']).resolve()==snapshot.resolve(),'R9_ORIGIN_DRIFT')
    check(s['provenance']['r8_gate']=='PASS','R8_ORIGIN_NOT_PROVEN')
    report.mkdir(parents=True)
    shutil.copy2(stage,report/'R9_STAGE_REPORT.json')
    outcome=r9.compile_objects(snapshot, objout=report.parent/'veux-r11-objout',reportdir=report,
        stock=stock,toolchain=toolchain,limit=300,jobs=2)
    obj=outcome.get('objects',{})
    passed=sum(bool(v.get('compiled',False)) for v in obj.values())
    full_diff=None
    effective=report/'R9_EFFECTIVE_CONFIG.config'
    if effective.is_file() and not effective.is_symlink():
        desired=r9.config_values(stock.read_text())
        actual=r9.config_values(effective.read_text())
        full_diff={k:{'oem':desired.get(k,'ABSENT'),'effective':actual.get(k,'ABSENT')}
                   for k in sorted(set(desired)|set(actual)) if desired.get(k,'ABSENT')!=actual.get(k,'ABSENT')}
    (report/'R11_FULL_CONFIG_DIFF.json').write_text(json.dumps({'status':'COMPARED' if full_diff is not None else 'NOT_AVAILABLE',
         'difference_count':len(full_diff) if full_diff is not None else None,
         'differences':full_diff,'vendor_abi_proven':False},indent=2,sort_keys=True)+'\n')
    good=len(obj)==3 and passed==3 and bool(outcome.get('object_make_attempted'))
    ret={'status':'R11_ALL_THREE_OBJECTS_COMPILED' if good else 'R11_COMPILER_ERRORS_RECORDED' if outcome.get('object_make_attempted')
         else 'R11_PRECOMPILATION_BLOCKED','r9_underlying_status':outcome['status'],'objects':obj,
         'object_success_count':passed,'object_make_attempted':bool(outcome.get('object_make_attempted')),
         'source_r11_sha256':g11['after_sha256'],'r10_source_sha256':g10['after_sha256'],
         'config_walt_y':outcome.get('config_walt_y',False),
         'full_oem_config_diff_count':len(full_diff) if full_diff is not None else None,
         'full_config_compared':full_diff is not None,
         'image_built':False,'vendor_abi_proven':False,'flash_allowed':False,
         'brene_changed':False,'bakasusu_nomount_changed':False}
    (report/'R11_COMPILER_RESULT.json').write_text(json.dumps(ret,indent=2,sort_keys=True)+'\n')
    print('R11_REAL_OBJECT_DIAG='+ret['status']+'; COMPILED='+str(passed)+'/3; IMAGE=NO; ABI=NO; FLASH=NO')
    return ret

def main():
    ap=argparse.ArgumentParser()
    for arg in ('snapshot','r10-gate','r11-gate','r9-report','report','stock','toolchain','driver'):
        ap.add_argument('--'+arg,required=True,type=Path)
    a=ap.parse_args()
    try:run(a.snapshot,a.r10_gate,a.r11_gate,a.r9_report,a.report,a.stock,a.toolchain,a.driver)
    except (GateError,OSError,ValueError,KeyError,AttributeError) as e:
        print('R11_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':sys.exit(main())
