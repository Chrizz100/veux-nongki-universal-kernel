#!/usr/bin/env python3
"""VEUX R11: real Xiaomi WALT missing API follow-up, source-only.

For the EXACT R10 staged disposable snapshot, anchored to published GitHub
R10 hashes. This program never flashes, links, edits the source repository,
or claims ABI compatibility. It intentionally preserves WALT-OFF PELT behavior.
Original donor: MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e.
"""
import argparse
import difflib
import hashlib
import json
import re
import sys
from pathlib import Path

class GateError(Exception):
    pass

R10_PIN = {
    'include/linux/sched.h': '128aba2c4eaa1fec50fb78b7dda25699571c3af349afe9f718284f161fddb29e',
    'kernel/sched/sched.h': 'c115c1f0dcd0d1b38a69df1c0b6136436f8e60ceb83b1eb4280cdaa059797d09',
    'kernel/sched/core.c': '9a00615c33906ac97490dd052cdeff73b36e7c27ffbdce7483f219472838fd06',
    'kernel/sched/fair.c': '71c88ae1771d35fb23c5b05217a0d9e6aa73eb3e6fe747ad087fef8f76a3b87c',
}
PATHS = ('include/linux/sched.h', 'kernel/sched/sched.h', 'kernel/sched/core.c', 'kernel/sched/fair.c')
R10_SOURCE_STATUS = 'R10_OEM_WALT_SOURCE_API_STAGED_NOT_COMPILED'


def need(ok, message):
    if not ok:
        raise GateError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def exactly_once(text, old, new, label):
    need(text.count(old) == 1, f'{label}:EXPECTED_1_GOT_{text.count(old)}')
    return text.replace(old, new, 1)


def linux_sched(src):
    need('DECLARE_PER_CPU_READ_MOSTLY(int, sched_load_boost)' not in src, 'PERCPU_DECL_ALREADY_PRESENT')
    anchor = 'struct cpu_cycle_counter_cb {\n\tu64 (*get_cpu_cycle_counter)(int cpu);\n};\n\n'
    return exactly_once(src, anchor,
       anchor + '#ifdef CONFIG_SCHED_WALT\nDECLARE_PER_CPU_READ_MOSTLY(int, sched_load_boost);\n#endif\n\n',
       'LINUX_SCHED_PERCPU_DECL')


def kernel_sched(src):
    need('struct walt_root_domain\twrd;' not in src, 'ROOT_WALT_ALREADY_PRESENT')
    need('walt_irq_work_queue(' not in src, 'IRQ_WRAPPER_ALREADY_PRESENT')
    need('sched_capacity_margin_up[NR_CPUS]' not in src, 'MARGINS_ALREADY_DECLARED')
    inc = '#include <linux/irq_work.h>\n'
    src = exactly_once(src, '#include <linux/kprobes.h>\n', '#include <linux/kprobes.h>\n'+inc, 'IRQ_WORK_INCLUDE')
    anchor = 'struct rq;\nstruct cpuidle_state;\n'
    extras = ('\n#ifdef CONFIG_SCHED_WALT\n'
       '/* Original Xiaomi WALT scheduling controls and capacity helpers. */\n'
       'extern __read_mostly bool sched_predl;\n'
       'extern unsigned int sched_capacity_margin_up[NR_CPUS];\n'
       'extern unsigned int sched_capacity_margin_down[NR_CPUS];\n'
       'unsigned long capacity_curr_of(int cpu);\n'
       'void sched_update_hyst_times(void);\n'
       '#endif\n')
    src = exactly_once(src, anchor, anchor + extras, 'OEM_WALT_EXTERN')
    src = exactly_once(src, 'struct perf_domain __rcu *pd;\n};',
       'struct perf_domain __rcu *pd;\n#ifdef CONFIG_SCHED_WALT\n\tstruct walt_root_domain\twrd;\n#endif\n};', 'WALT_ROOT_DOMAIN_FIELD')
    anchor = 'static inline int cluster_first_cpu(struct walt_sched_cluster *cluster)\n{\n    return cpumask_first(&cluster->cpus);\n}\n'
    src = exactly_once(src, anchor, anchor + ('static inline bool is_min_capacity_cluster(struct walt_sched_cluster *cluster)\n'
       '{\n\treturn is_min_capacity_cpu(cluster_first_cpu(cluster));\n}\n'), 'MIN_CAPACITY_CLUSTER')
    wrapper = '''
/* Xiaomi WALT irq_work scheduling, real CPU-online fallback. */
#ifdef CONFIG_SCHED_WALT
static inline void walt_irq_work_queue(struct irq_work *work)
{
	if (likely(cpu_online(raw_smp_processor_id())))
		irq_work_queue(work);
	else
		irq_work_queue_on(work, cpumask_any(cpu_online_mask));
}
#else
static inline void walt_irq_work_queue(struct irq_work *work)
{
	irq_work_queue(work);
}
#endif
'''
    need(src.endswith('\n'), 'SCHED_H_MISSING_NEWLINE')
    return src + wrapper


def kernel_core(src):
    need(not re.search(r'\b(?:bool|int)\s+sched_predl\s*=', src), 'SCHED_PREDL_ALREADY_DEFINED')
    anchor = '#include "walt/walt.h"\n'
    addition = ('\n#ifdef CONFIG_SCHED_WALT\n'
       '/* Genuine Xiaomi WALT default; the sched_predl early_param may override. */\n'
       '__read_mostly bool sched_predl = 1;\n'
       '#endif\n')
    return exactly_once(src, anchor, anchor+addition, 'CORE_WALT_HEADER')


def kernel_fair(src):
    # Precisely preserve the PELT helper when WALT is off. WALT=y uses the
    # R10 header's demand_scaled helper, as in MiCode's WALT scheduler.
    pelt = ('static inline unsigned long task_util(struct task_struct *p)\n'
            '{\n\treturn READ_ONCE(p->se.avg.util_avg);\n}\n')
    src = exactly_once(src, pelt, '#ifndef CONFIG_SCHED_WALT\n'+pelt+'#endif\n', 'FAIR_TASK_UTIL_DUPLICATE')
    need(not re.search(r'\bDEFINE_PER_CPU_READ_MOSTLY\(int,\s*sched_load_boost\)', src), 'FAIR_PERCPU_ALREADY_DEFINED')
    need('sched_capacity_margin_up[NR_CPUS]' not in src, 'FAIR_MARGINS_ALREADY_DEFINED')
    need(re.search(r'\bcapacity_curr_of\s*\(', src) is None, 'FAIR_CURR_CAPACITY_ALREADY_DEFINED')
    m = re.search(r'^const_debug unsigned int sysctl_sched_migration_cost\s*=\s*500000UL;\n', src, re.M)
    need(m is not None and src.count('sysctl_sched_migration_cost') >= 1, 'FAIR_MIGRATION_COST_ANCHOR_MISSING')
    defs = '''#ifdef CONFIG_SCHED_WALT
/* MiCode 5.4.134 WALT capacity arrays and per-CPU boost; no fake values. */
DEFINE_PER_CPU_READ_MOSTLY(int, sched_load_boost);
unsigned int sched_capacity_margin_up[NR_CPUS] = {
	[0 ... NR_CPUS-1] = 1078};
unsigned int sched_capacity_margin_down[NR_CPUS] = {
	[0 ... NR_CPUS-1] = 1205};

/* Original Xiaomi current CPU capacity: hardware capacity * current freq. */
unsigned long capacity_curr_of(int cpu)
{
	unsigned long max_cap = cpu_rq(cpu)->cpu_capacity_orig;
	unsigned long scale_freq = arch_scale_freq_capacity(cpu);

	return cap_scale(max_cap, scale_freq);
}
#endif
'''
    src = src[:m.end()] + '\n' + defs + src[m.end():]
    return src

TRANSFORMS = {
    'include/linux/sched.h': linux_sched,
    'kernel/sched/sched.h': kernel_sched,
    'kernel/sched/core.c': kernel_core,
    'kernel/sched/fair.c': kernel_fair,
}


def transform(srcs):
    need(set(srcs) == set(PATHS), 'SOURCE_PATHS_DRIFT')
    for p, h in R10_PIN.items():
        need(digest(srcs[p].encode()) == h, 'R10_SHA_DRIFT:'+p)
    return {k: TRANSFORMS[k](srcs[k]) for k in PATHS}


def stage(snapshot, r10_gate, out):
    need(snapshot.is_dir() and not snapshot.is_symlink(), 'SNAPSHOT_NOT_DIRECTORY')
    need(r10_gate.is_file() and not r10_gate.is_symlink(), 'R10_GATE_MISSING')
    gate = json.loads(r10_gate.read_text())
    need(gate['status'] == R10_SOURCE_STATUS and gate['source_original_unchanged'], 'R10_STAGING_NOT_PROVEN')
    three={k:v for k,v in R10_PIN.items() if k != 'kernel/sched/fair.c'}
    need(gate['after_sha256'] == three, 'R10_PINS_DISAGREE')
    need(not any(gate[k] for k in ('all_objects_compiled','flash_allowed','vendor_abi_proven','brene_changed','kernel_image_built')), 'R10_FALSE_APPROVAL')
    need(not out.exists() and not out.is_symlink(), 'R11_OUTPUT_EXISTS')
    srcs={}
    for name in PATHS:
        p=snapshot/name
        need(p.is_file() and not p.is_symlink(), 'R11_SOURCE_MISSING_OR_SYMLINK:'+name)
        srcs[name]=p.read_text()
    changed=transform(srcs)
    # Precompute every patch + postimage before touching the working snapshot.
    patches=[]
    for name in PATHS:
        need(changed[name] != srcs[name], 'R11_NO_MODIFICATION:'+name)
        patches.extend(difflib.unified_diff(srcs[name].splitlines(keepends=True),
                  changed[name].splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
    patch=''.join(patches)
    need(patch.count('--- a/') == 4 and patch.count('+++ b/') == 4, 'R11_PATCH_SCOPE_DRIFT')
    out.mkdir(parents=True)
    (out/'R11_PORT.patch').write_text(patch)
    for k in PATHS:
        (snapshot/k).write_text(changed[k])
    result={
        'status':'R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED',
        'source_original_unchanged':True, 'modified_files':list(PATHS),
        'before_sha256':{k:digest(srcs[k].encode()) for k in PATHS},
        'after_sha256':{k:digest(changed[k].encode()) for k in PATHS},
        'patch_sha256':digest(patch.encode()),
        'upstream_ref':'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e',
        'r10_source_sha_verified':True,
        'fair_original_source_sha_verified':True,
        'kernel_image_built':False,'all_objects_compiled':False,'vendor_abi_proven':False,
        'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False
    }
    (out/'R11_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R11_OEM_API_SOURCE_STAGED=PASS; PATHS=4; WALT_ON_COMPILE=NOT_PROVEN; ABI=NO; FLASH=NO')
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--snapshot',type=Path,required=True)
    ap.add_argument('--r10-gate',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    q=ap.parse_args()
    try:stage(q.snapshot,q.r10_gate,q.output)
    except (GateError, OSError, ValueError, KeyError) as exc:
        print('R11_SOURCE_GATE_ERROR:'+str(exc),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':sys.exit(main())
