#!/usr/bin/env python3
"""R11 provenance and compile-result coordinator tests; mock compiler, never claim kernel compiled."""
import hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path
DIR=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r11_compiler',DIR/'r11_real_compile.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)

class CompileGateTests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
  d=Path(self.t.name);self.base=d
  for n in ['snapshot','old','tools']:(d/n).mkdir()
  self.snapshot=d/'snapshot'
  g10=json.loads((DIR/'fixtures/R10_SOURCE_GATE.json').read_text())
  self.g10=g10
  self.g10_file=d/'R10_SOURCE_GATE.json';self.g10_file.write_text(json.dumps(g10))
  g11={'status':'R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED',
       'before_sha256':{**g10['after_sha256'],'kernel/sched/fair.c':'71c88ae1771d35fb23c5b05217a0d9e6aa73eb3e6fe747ad087fef8f76a3b87c'},
       'modified_files':['include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c','kernel/sched/fair.c'],
       'after_sha256':{},'kernel_image_built':False,'all_objects_compiled':False,
       'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
       'bakasusu_nomount_changed':False}
  for f in g11['modified_files']:
   dst=self.snapshot/f;dst.parent.mkdir(parents=True,exist_ok=True)
   dst.write_text('R11 postimage fixture: '+f+'\n');g11['after_sha256'][f]=hashlib.sha256(dst.read_bytes()).hexdigest()
  self.g11=g11;self.g11_file=d/'R11_SOURCE_GATE.json';self.g11_file.write_text(json.dumps(g11))
  self.old=d/'old';(self.old/'R9_STAGE_REPORT.json').write_text(json.dumps({
   'status':'R9_SOURCE_SNAPSHOT_STAGED','snapshot':str(self.snapshot),
   'provenance':{'r8_gate':'PASS'}}))
  self.stock=d/'OEM.config';self.stock.write_text('CONFIG_SCHED_WALT=y\n')
  self.toolchain=d/'tools'
  self.driver=d/'stub_driver.py'
  self.driver.write_text('''R8_SCHED_HASH="12f10b1be96b1868304dd0f5e85a8e4e421ae72383d8b76571a2dc91fd6d4f5d"
from pathlib import Path

def config_values(s):
    return dict(line.split('=',1) for line in s.strip().splitlines() if '=' in line)

def compile_objects(snapshot,objout,reportdir,stock,toolchain,limit,jobs):
    (reportdir/'R9_EFFECTIVE_CONFIG.config').write_text(stock.read_text())
    return {'status':'R9_COMPILER_ERRORS_RECORDED','object_make_attempted':True,
       'config_walt_y':True,'objects':{
          'kernel/sched/walt/walt.o': {'compiled':False,'exit_code':2},
          'kernel/sched/core.o':{'compiled':True,'exit_code':0},
          'kernel/sched/fair.o':{'compiled':True,'exit_code':0}}}
''')
 def execute(self):
  return C.run(self.snapshot,self.g10_file,self.g11_file,self.old,self.base/'report',self.stock,self.toolchain,self.driver)
 def test_01_reject_invalid_r10_gate(self):
  x=dict(self.g10,status='WRONG');self.g10_file.write_text(json.dumps(x))
  with self.assertRaisesRegex(C.GateError,'BAD_R10_GATE'):self.execute()
 def test_02_reject_invalid_r11_gate(self):
  x=dict(self.g11,status='WRONG');self.g11_file.write_text(json.dumps(x))
  with self.assertRaisesRegex(C.GateError,'BAD_R11_GATE'):self.execute()
 def test_03_reject_wrong_r10_sha_chain(self):
  x=dict(self.g11,before_sha256={**self.g11['before_sha256'],'kernel/sched/core.c':'f'*64})
  self.g11_file.write_text(json.dumps(x))
  with self.assertRaisesRegex(C.GateError,'R10_R11_CHAIN_BROKEN:kernel/sched/core.c'):self.execute()
 def test_04_reject_wrong_p10_fair_sha(self):
  x=dict(self.g11,before_sha256={**self.g11['before_sha256'],'kernel/sched/fair.c':'0'*64})
  self.g11_file.write_text(json.dumps(x))
  with self.assertRaisesRegex(C.GateError,'P10_FAIR_PREIMAGE_DRIFT'):self.execute()
 def test_05_reject_wrong_postimage(self):
  (self.snapshot/'kernel/sched/fair.c').write_text('mutation')
  with self.assertRaisesRegex(C.GateError,'R11_POSTIMAGE_DRIFT:kernel/sched/fair.c'):self.execute()
 def test_06_reject_missing_origin(self):
  (self.old/'R9_STAGE_REPORT.json').unlink()
  with self.assertRaisesRegex(C.GateError,'R9_STAGE_PROOF_MISSING'):self.execute()
 def test_07_reject_wrong_snapshot(self):
  (self.old/'R9_STAGE_REPORT.json').write_text(json.dumps({
     'status':'R9_SOURCE_SNAPSHOT_STAGED','snapshot':'/tmp/unrelated','provenance':{'r8_gate':'PASS'}}))
  with self.assertRaisesRegex(C.GateError,'R9_ORIGIN_DRIFT'):self.execute()
 def test_08_reject_wrong_original_driver(self):
  self.driver.write_text(self.driver.read_text().replace('R8_SCHED_HASH="12f10b','R8_SCHED_HASH="f2f2f2'))
  with self.assertRaisesRegex(C.GateError,'R9_ORIGINAL_DRIVER_PIN_DRIFT'):self.execute()
 def test_09_mock_compile_two_objects_returns_diagnostics(self):
  result=self.execute()
  self.assertEqual(result['object_success_count'],2)
  self.assertEqual(result['status'],'R11_COMPILER_ERRORS_RECORDED')
  self.assertTrue((self.base/'report/R11_COMPILER_RESULT.json').exists())
  self.assertTrue((self.base/'report/R11_FULL_CONFIG_DIFF.json').exists())
  self.assertFalse(result['flash_allowed']);self.assertFalse(result['image_built'])
 def test_10_mock_compile_three_objects_labelled_exactly(self):
  p=self.driver;s=p.read_text().replace("'kernel/sched/walt/walt.o': {'compiled':False,'exit_code':2}","'kernel/sched/walt/walt.o': {'compiled':True,'exit_code':0}")
  p.write_text(s);result=self.execute()
  self.assertEqual(result['status'],'R11_ALL_THREE_OBJECTS_COMPILED')
  self.assertFalse(result['vendor_abi_proven'])
 def test_11_reject_unsafe_abi_claim(self):
  x=dict(self.g11,flash_allowed=True);self.g11_file.write_text(json.dumps(x))
  with self.assertRaisesRegex(C.GateError,'R11_FALSE_APPROVAL'):self.execute()
 def test_12_reject_existing_report(self):
  (self.base/'report').mkdir()
  with self.assertRaisesRegex(C.GateError,'REPORT_ALREADY_EXISTS'):self.execute()

if __name__=='__main__':unittest.main(verbosity=2)
