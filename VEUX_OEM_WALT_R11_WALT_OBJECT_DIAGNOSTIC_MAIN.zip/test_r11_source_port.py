#!/usr/bin/env python3
"""Source/negative tests. Not a substitute for real ARM64 kernel compilation."""
import importlib.util, hashlib, json, os, re, shutil, subprocess, tempfile, unittest, unittest.mock
from pathlib import Path
DIR=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r11',DIR/'r11_source_port.py')
r11=importlib.util.module_from_spec(spec);spec.loader.exec_module(r11)

class R11Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  fx=DIR/'fixtures'
  cls.header=(fx/'R10_sched.h').read_text()
  cls.linux=(fx/'R10_linux_sched.h').read_text()
  cls.fair=(fx/'R3_real_fair.c').read_text()
  cls.core=(fx/'core_walt_fixture.c').read_text()
  cls.sh=r11.kernel_sched(cls.header)
  cls.lh=r11.linux_sched(cls.linux)
  cls.fa=r11.kernel_fair(cls.fair)
  cls.co=r11.kernel_core(cls.core)
 @staticmethod
 def expect_fail(fn,*args):
  with unittest.TestCase().assertRaises(r11.GateError):fn(*args)
 def test_01_header_hash(self):self.assertEqual(r11.digest(self.header.encode()),r11.R10_PIN['kernel/sched/sched.h'])
 def test_02_linux_header_hash(self):self.assertEqual(r11.digest(self.linux.encode()),r11.R10_PIN['include/linux/sched.h'])
 def test_03_header_modified(self):self.assertNotEqual(self.sh,self.header)
 def test_04_linux_modified(self):self.assertNotEqual(self.lh,self.linux)
 def test_05_core_modified(self):self.assertNotEqual(self.co,self.core)
 def test_06_fair_modified(self):self.assertNotEqual(self.fa,self.fair)
 def test_07_fair_pelt_body_kept(self):self.assertIn('return READ_ONCE(p->se.avg.util_avg);',self.fa)
 def test_08_fair_pelt_walt_off_only(self):self.assertIn('#ifndef CONFIG_SCHED_WALT\nstatic inline unsigned long task_util',self.fa)
 def test_09_walt_task_util_kept(self):self.assertIn('return p->wts.demand_scaled;',self.sh)
 def test_10_no_duplicate_task_util(self):self.assertEqual(self.sh.count('static inline unsigned long task_util('),1)
 def test_11_fair_guard_end(self):self.assertIn('return READ_ONCE(p->se.avg.util_avg);\n}\n#endif',self.fa)
 def test_12_clock_not_mutated(self):self.assertIn('u64 sched_ktime_clock(void);',self.sh)
 def test_13_reserved_not_mutated(self):self.assertIn('return test_bit(CPU_RESERVED, &rq->wrq.walt_flags);',self.sh)
 def test_14_root_wrd_walt_only(self):self.assertIn('struct perf_domain __rcu *pd;\n#ifdef CONFIG_SCHED_WALT\n\tstruct walt_root_domain\twrd;',self.sh)
 def test_15_sched_predl_extern(self):self.assertIn('extern __read_mostly bool sched_predl;',self.sh)
 def test_16_sched_predl_real_default(self):self.assertIn('__read_mostly bool sched_predl = 1;',self.co)
 def test_17_capacity_margin_values(self):self.assertIn('[0 ... NR_CPUS-1] = 1078',self.fa);self.assertIn('[0 ... NR_CPUS-1] = 1205',self.fa)
 def test_18_percpu_decl(self):self.assertIn('DECLARE_PER_CPU_READ_MOSTLY(int, sched_load_boost);',self.lh)
 def test_19_percpu_definition(self):self.assertIn('DEFINE_PER_CPU_READ_MOSTLY(int, sched_load_boost);',self.fa)
 def test_20_cpu_current_frequency(self):self.assertIn('return cap_scale(max_cap, scale_freq);',self.fa)
 def test_21_critical_irq_fallback(self):self.assertIn('irq_work_queue_on(work, cpumask_any(cpu_online_mask));',self.sh)
 def test_22_irq_normal_case(self):self.assertIn('irq_work_queue(work);',self.sh)
 def test_23_hysteresis_nonstub(self):self.assertIn('void sched_update_hyst_times(void);',self.sh)
 def test_24_min_cluster_real_check(self):self.assertIn('is_min_capacity_cpu(cluster_first_cpu(cluster))',self.sh)
 def test_25_headers_no_other_changes(self):self.assertTrue(self.sh.startswith(self.header.splitlines()[0]))
 def test_26_reapply_sched_blocked(self):
  with self.assertRaises(r11.GateError):r11.kernel_sched(self.sh)
 def test_27_reapply_linux_blocked(self):
  with self.assertRaises(r11.GateError):r11.linux_sched(self.lh)
 def test_28_reapply_fair_blocked(self):
  with self.assertRaises(r11.GateError):r11.kernel_fair(self.fa)
 def test_29_reapply_core_blocked(self):
  with self.assertRaises(r11.GateError):r11.kernel_core(self.co)
 def test_30_header_missing_required_anchor(self):
  with self.assertRaises(r11.GateError):r11.kernel_sched(self.header.replace('struct perf_domain __rcu *pd;',''))
 def test_31_fair_duplicate_rejected(self):
  with self.assertRaises(r11.GateError):r11.kernel_fair(self.fair+'\nDEFINE_PER_CPU_READ_MOSTLY(int, sched_load_boost);\n')
 def test_32_core_missing_include_rejected(self):
  with self.assertRaises(r11.GateError):r11.kernel_core(self.core.replace('#include "walt/walt.h"',''))
 def test_33_bad_r10_hash_rejected(self):
  x={'kernel/sched/sched.h':self.header+'MUTATION','include/linux/sched.h':self.linux,
      'kernel/sched/core.c':self.core,'kernel/sched/fair.c':self.fair}
  with self.assertRaises(r11.GateError):r11.transform(x)
 def test_34_stage_missing_gate(self):
  with tempfile.TemporaryDirectory() as t:
   x=Path(t);(x/'src').mkdir()
   with self.assertRaises(r11.GateError):r11.stage(x/'src',x/'missing.json',x/'result')
 def test_35_stage_fails_closed_before_edits(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);src=d/'snap';src.mkdir();
   for name,content in {'include/linux/sched.h':self.linux,'kernel/sched/sched.h':self.header,
        'kernel/sched/core.c':self.core,'kernel/sched/fair.c':self.fair}.items():
    p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
   gate=d/'R10_SOURCE_GATE.json';gate.write_text(json.dumps({'status':r11.R10_SOURCE_STATUS,
       'source_original_unchanged':True,'after_sha256':{k:v for k,v in r11.R10_PIN.items() if k != 'kernel/sched/fair.c'},
       'all_objects_compiled':False,'flash_allowed':False,'vendor_abi_proven':False,'brene_changed':False,'kernel_image_built':False}))
   with self.assertRaises(r11.GateError):r11.stage(src,gate,d/'r11out')
   self.assertFalse((d/'r11out').exists());self.assertEqual((src/'kernel/sched/fair.c').read_text(),self.fair)
 def test_36_core_symlink_blocked(self):
  with tempfile.TemporaryDirectory() as t:
   d=Path(t);src=d/'snap';src.mkdir()
   for name,content in {'include/linux/sched.h':self.linux,'kernel/sched/sched.h':self.header,
        'kernel/sched/fair.c':self.fair}.items():
    p=src/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(content)
   (d/'core_source.c').write_text(self.core)
   (src/'kernel/sched/core.c').symlink_to(d/'core_source.c')
   gate=d/'R10_SOURCE_GATE.json';gate.write_text(json.dumps({'status':r11.R10_SOURCE_STATUS,
       'source_original_unchanged':True,'after_sha256':{k:v for k,v in r11.R10_PIN.items() if k != 'kernel/sched/fair.c'},
       'all_objects_compiled':False,'flash_allowed':False,'vendor_abi_proven':False,'brene_changed':False,'kernel_image_built':False}))
   with self.assertRaisesRegex(r11.GateError,'R11_SOURCE_MISSING_OR_SYMLINK'):
    r11.stage(src,gate,d/'output')
   self.assertFalse((d/'output').exists())
 def test_37_static_walt_semantics_clang(self):
  self.assertIsNotNone(shutil.which('clang'),'clang required: no silent model-test skip')
  source='''typedef unsigned long ulong;
struct task_struct { struct { ulong demand_scaled; } wts; struct { struct { ulong util_avg; } avg; } se; };
#define READ_ONCE(x) (x)
#ifdef CONFIG_SCHED_WALT
static inline ulong task_util(struct task_struct *p) {return p->wts.demand_scaled;}
#else
static inline ulong task_util(struct task_struct *p) {return READ_ONCE(p->se.avg.util_avg);}
#endif
ulong get(struct task_struct *p){return task_util(p);}
'''
  for flags in [[],['-DCONFIG_SCHED_WALT=1']]:
   p=subprocess.run(['clang','-x','c','-fsyntax-only','-Werror',*flags,'-'],input=source,text=True,capture_output=True)
   self.assertEqual(p.returncode,0,p.stderr)
 def test_38_r10_source_gate_in_original_archive(self):
  obj=json.loads((DIR/'fixtures/R10_SOURCE_GATE.json').read_text())
  for key,value in obj['after_sha256'].items():self.assertEqual(r11.R10_PIN[key],value)
 def test_39_source_scope_only_four_paths(self):self.assertEqual(len(r11.PATHS),4)
 def test_40_no_flashable_components(self):
  source=(DIR/'r11_source_port.py').read_text();self.assertNotIn('fastboot flash',source);self.assertNotIn('anykernel',source.lower())
 def test_41_postimage_sha_repeatable(self):self.assertEqual(r11.digest(self.sh.encode()),r11.digest(r11.kernel_sched(self.header).encode()))
 def test_42_config_macro_no_forced_values(self):
  self.assertNotIn('#define CONFIG_SCHED_WALT',self.sh)
 def test_43_no_pretend_symbols(self):
  self.assertNotIn('static inline void sched_update_hyst_times(void) {}',self.sh)
 def test_44_no_abi_claim(self):self.assertIn("'vendor_abi_proven':False",(DIR/'r11_source_port.py').read_text())
 def test_45_real_p10_fair_sha_pin(self):
  self.assertEqual(r11.digest(self.fair.encode()),r11.R10_PIN['kernel/sched/fair.c'])
 def test_46_real_p10_fair_git_blob(self):
  p=subprocess.run(['git','hash-object','--stdin'],input=self.fair,capture_output=True,text=True)
  self.assertEqual(p.returncode,0,p.stderr)
  self.assertEqual(p.stdout.strip(),'fad0d4c9a014560b6a6a07a20efdb4910306fd3c')
 def test_47_walt_off_task_util_preprocessor(self):
  # Extract the two genuine production definitions, not a hand-written model.
  sh=re.search(r'static inline unsigned long task_util\(struct task_struct \*p\)\n\{.*?\n\}',self.sh,re.S)
  fp=re.search(r'#ifndef CONFIG_SCHED_WALT\nstatic inline unsigned long task_util\(struct task_struct \*p\)\n\{.*?\n\}\n#endif',self.fa,re.S)
  self.assertTrue(sh and fp)
  code='''typedef unsigned long ulong;
struct task_struct { struct { ulong demand_scaled; } wts; struct { struct { ulong util_avg; } avg; } se; };
#define READ_ONCE(x) (x)
#ifdef CONFIG_SCHED_WALT
'''+sh.group(0)+"\n#endif\n"+fp.group(0)+"\nunsigned long get(struct task_struct *p) {return task_util(p); }\n"
  for flag in ([],['-DCONFIG_SCHED_WALT=1']):
   p=subprocess.run(['clang','-x','c','-fsyntax-only','-Werror',*flag,'-'],input=code,text=True,capture_output=True)
   self.assertEqual(p.returncode,0,p.stderr)
 def test_48_negative_fair_pin_changed(self):
  x={'kernel/sched/sched.h':self.header, 'include/linux/sched.h':self.linux,
     'kernel/sched/core.c':self.core,'kernel/sched/fair.c':self.fair+'\n/* mutated */\n'}
  with unittest.mock.patch.dict(r11.R10_PIN, {'kernel/sched/core.c':r11.digest(self.core.encode())}):
   with self.assertRaisesRegex(r11.GateError,'R10_SHA_DRIFT:kernel/sched/fair.c'):r11.transform(x)


 def test_49_positive_source_stage_with_surrogate_core(self):
  # R10 did not export the full core.c postimage. Exercise exact source staging
  # using a declared surrogate core hash; the real CI must use its original pin.
  with tempfile.TemporaryDirectory() as td:
   base=Path(td);snapshot=base/'src';snapshot.mkdir()
   source={'kernel/sched/sched.h':self.header,'include/linux/sched.h':self.linux,
           'kernel/sched/core.c':self.core,'kernel/sched/fair.c':self.fair}
   for path,data in source.items():
    out=snapshot/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(data)
   g=base/'R10_SOURCE_GATE.json'
   pins={k:v for k,v in r11.R10_PIN.items() if k!='kernel/sched/fair.c'}
   pins['kernel/sched/core.c']=r11.digest(self.core.encode())
   g.write_text(json.dumps({'status':r11.R10_SOURCE_STATUS,'source_original_unchanged':True,
         'after_sha256':pins,'all_objects_compiled':False,'flash_allowed':False,
         'vendor_abi_proven':False,'brene_changed':False,'kernel_image_built':False}))
   with unittest.mock.patch.dict(r11.R10_PIN, {'kernel/sched/core.c':pins['kernel/sched/core.c']}):
    report=r11.stage(snapshot,g,base/'report')
   self.assertEqual(report['modified_files'],list(r11.PATHS))
   self.assertFalse(report['flash_allowed'])
   replay=base/'replay';replay.mkdir()
   for path,dat in source.items():
    dst=replay/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(dat)
   patch=base/'report/R11_PORT.patch'
   cp=subprocess.run(['git','apply','--check',str(patch)],cwd=replay,capture_output=True,text=True)
   self.assertEqual(cp.returncode,0,cp.stderr)
   cp=subprocess.run(['git','apply',str(patch)],cwd=replay,capture_output=True,text=True)
   self.assertEqual(cp.returncode,0,cp.stderr)
   for name in r11.PATHS:
    self.assertEqual((snapshot/name).read_bytes(),(replay/name).read_bytes())
 def test_50_no_pseudo_positive_stage_without_actual_core(self):
  with tempfile.TemporaryDirectory() as td:
   base=Path(td);snapshot=base/'src';snapshot.mkdir()
   source={'kernel/sched/sched.h':self.header,'include/linux/sched.h':self.linux,
           'kernel/sched/core.c':self.core,'kernel/sched/fair.c':self.fair}
   for name,dat in source.items():
    dst=snapshot/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(dat)
   gate=base/'R10_GATE.json';gate.write_text(json.dumps({'status':r11.R10_SOURCE_STATUS,
       'source_original_unchanged':True,'after_sha256':{k:v for k,v in r11.R10_PIN.items() if k!='kernel/sched/fair.c'},
       'all_objects_compiled':False,'flash_allowed':False,'vendor_abi_proven':False,
       'brene_changed':False,'kernel_image_built':False}))
   with self.assertRaisesRegex(r11.GateError,'R10_SHA_DRIFT:kernel/sched/core.c'):
    r11.stage(snapshot,gate,base/'out')
   self.assertFalse((base/'out').exists())


if __name__=='__main__':unittest.main(verbosity=2)
