#!/usr/bin/env python3
"""Restore complete stock memory features and the original non-threaded NAPI path."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_LAYOUT = '0x945d02f2'
EXPECTED_CONFIG_DELTA = {n: [None, 'y'] for n in (
    'CONFIG_EMERGENCY_MEMORY', 'CONFIG_MULTIPLE_KSWAPD',
    'CONFIG_VM_EVENT_COUNT_CLEAN_PAGE_RECLAIM')}
OEM = {'hardwareinfo_set_prop': '0x8124e3e6', 'smartpa_type': '0xed687ffd',
       'snd_soc_set_smartpa_type': '0x777f6815'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def token_sha(text):
    return hashlib.sha256(re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '',
                          text, flags=re.S)).encode()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def reference_cohort():
    # This is a read-only 1423-symbol historical comparison, not a kernel
    # Module.symvers. The full real build still uses h.parse_symvers unchanged.
    values = {}
    for line in (ROOT / 'References/R15_IMPORT_COHORT.symvers').read_text().splitlines():
        fields = line.split()
        require(len(fields) == 4 and re.fullmatch(r'0x[0-9a-f]{8}', fields[0])
                and fields[1] not in values and fields[2:] == ['REFERENCE_ONLY', 'EXPORT_SYMBOL'],
                'MALFORMED_R15_REFERENCE_COHORT')
        values[fields[1]] = fields[0]
    require(len(values) == 1423, 'INCOMPLETE_R15_REFERENCE_COHORT')
    return values


def dependency():
    spec = importlib.util.spec_from_file_location('r16_bootstrap', ROOT / 'Tools/bootstrap.py')
    bootstrap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bootstrap)
    return bootstrap.parent()


def verify_package():
    listed = set()
    for row in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = row.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in listed,
                'UNSAFE_MANIFEST')
        require(not (ROOT / p).is_symlink() and sha(ROOT / p) == digest,
                'PACKAGE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and 'runtime-r15' not in p.parts
              and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == listed, 'MANIFEST_SCOPE_CHANGED')
    dependency()


def pins():
    value = json.loads((ROOT / 'References/FILE_PINS.json').read_text())
    require(len(value) == 18 and {n for n, p in value.items() if p['mode'] == 'context'}
            == {'init/Kconfig', 'init/main.c', 'kernel/sysctl.c'}, 'R16_SOURCE_SCOPE_CHANGED')
    return value


def regular(source, name):
    path = source / name
    require(path.is_file() and not path.is_symlink()
            and all(not p.is_symlink() for p in path.parents if p.is_relative_to(source)),
            'SOURCE_NOT_REGULAR:' + name)
    return path


def functional_checks(source):
    text = {n: (source / n).read_text() for n in pins()}
    checks = {
        'emergency_initializer': ('mm/page_alloc.c', 'void __init emergency_mm_init(void)'),
        'emergency_allocator': ('mm/page_alloc.c', 'get_emergency_page_from_freelist'),
        'emergency_init_call': ('init/main.c', 'emergency_mm_init();'),
        'emergency_capacity': ('include/linux/mmzone.h', 'nr_reserved_emergency'),
        'migration_enum': ('include/linux/mmzone.h', 'MIGRATE_EMERGENCY'),
        'kswapd_array': ('include/linux/mmzone.h', 'mkswapd[MAX_KSWAPD_THREADS]'),
        'kswapd_control': ('mm/page_alloc.c', 'kswapd_threads_sysctl_handler'),
        'kswapd_sysctl': ('kernel/sysctl.c', 'kswapd_threads_sysctl_handler'),
        'clean_page_counter': ('include/linux/vm_event_item.h', 'PGPGOUTCLEAN'),
        'clean_page_count_call': ('mm/filemap.c', 'count_vm_event_clean_page_put'),
        'clean_page_stat': ('mm/vmstat.c', '"pgpgoutclean"'),
        'original_shrinker_lock': ('mm/vmscan.c', 'static DECLARE_RWSEM(shrinker_rwsem);'),
        'preserved_274_compaction': ('mm/vmscan.c', 'if (!gfp_compaction_allowed(sc->gfp_mask))'),
        'real_multicast_export': ('net/core/dev.c', 'EXPORT_SYMBOL(embms_tm_multicast_recv);'),
    }
    for label, (name, fragment) in checks.items():
        require(fragment in text[name], 'FUNCTIONAL_COMPONENT_MISSING:' + label)
    require(text['mm/vmscan.c'].count('static DECLARE_RWSEM(shrinker_rwsem);') == 1,
            'SHRINKER_LOCK_DUPLICATED')
    for name in ('mm/vmscan.c', 'mm/page_alloc.c', 'mm/internal.h', 'include/linux/mmzone.h'):
        require('kshrinkd_wait' not in text[name] and 'pgdat->kshrinkd' not in text[name],
                'PARTIAL_KSHRINKD_ROLLBACK:' + name)
    require('NAPI_STATE_THREADED' not in text['include/linux/netdevice.h']
            and 'napi_threaded_poll' not in text['net/core/dev.c']
            and 'dev_set_threaded' not in text['net/core/net-sysfs.c'], 'PARTIAL_NAPI_ROLLBACK')
    require('static int (*embms_tm_multicast_recv)' not in text['net/core/dev.c'],
            'R46_EXPORT_FIX_LOST')
    alloc = text['mm/page_alloc.c']
    require(alloc.count('if (!page && !(gfp_mask & __GFP_NOWARN) && !costly_order)') == 1,
            'EMERGENCY_FAILURE_PATH_CHANGED')
    return {'components_checked': len(checks), 'complete_memory_feature_port': True,
            'complete_threaded_napi_series_reversed': True, 'crcs_overridden': False}


def prepared(source):
    source = Path(source).resolve(strict=True)
    for name, pin in pins().items():
        path = regular(source, name)
        if pin['mode'] == 'exact':
            require(sha(path) == pin['before_sha256'], 'R16_PREIMAGE_DRIFT:' + name
                    + ':expected=' + pin['before_sha256'] + ':observed=' + sha(path))
        elif pin['mode'] == 'tokens':
            require(token_sha(path.read_text()) == pin['before_tokens_sha256'],
                    'R16_HEADER_TOKEN_DRIFT:' + name)
    # Apply to a private complete set first. Context-only files keep all unrelated
    # earlier CASS/KSU/WALT changes; every patch hunk must still match exactly.
    with tempfile.TemporaryDirectory(prefix='r16-prepare-') as tmp:
        stage = Path(tmp)
        for name in pins():
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, stage / name)
        for flags in (['--check'], []):
            result = subprocess.run(['git', 'apply', '--whitespace=error', *flags,
                str(ROOT / 'References/RESTORE_MEMORY_AND_NETWORK.patch')],
                cwd=stage, capture_output=True, text=True)
            require(result.returncode == 0, 'R16_CONTEXT_PATCH_FAILED:' + result.stderr)
        for name, pin in pins().items():
            if pin['mode'] == 'exact':
                require(sha(stage / name) == pin['after_sha256'], 'R16_POSTIMAGE_DRIFT:' + name)
            elif pin['mode'] == 'tokens':
                require(token_sha((stage / name).read_text()) == pin['after_tokens_sha256'],
                        'R16_POSTIMAGE_TOKEN_DRIFT:' + name)
        functional_checks(stage)
        return {n: (stage / n).read_bytes() for n in pins()}


def check_source(source):
    prepared(source)
    return {'files_checked': 18, 'source_changed': False, 'all_patch_hunks_verified': True}


def apply_source(source):
    source = Path(source).resolve(strict=True)
    data = prepared(source)
    for name, contents in data.items():
        (source / name).write_bytes(contents)
    return dict(functional_checks(source), changed_files=len(data),
                source_hashes={n: sha(source / n) for n in data})


def check_baseline(source):
    source = Path(source).resolve(strict=True)
    r15 = dependency()
    r14 = r15.dependency()
    r13, r12, h = r14.dependency()
    names = set(h.FILES) | set(r12.pins()) | set(r13.pins()) | set(r14.pins()) | set(r15.pins()) | set(pins())
    new_files = {n for helper in (r12, r13, r14, r15) for n, pin in helper.pins().items()
                 if pin['before_sha256'] is None}
    with tempfile.TemporaryDirectory(prefix='r16-early-chain-') as tmp:
        stage = Path(tmp)
        for name in names:
            if not (source / name).exists():
                require(name in new_files, 'EARLY_SOURCE_MISSING:' + name)
                continue
            path = regular(source, name)
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, stage / name)
        h.apply_scoped(stage, h.generated_patches())
        for helper in (r12, r13, r14, r15):
            helper.apply_source(stage)
        result = check_source(stage)
    return dict(result, prior_ports_replayed_without_modifying_source=True,
                baseline_files_checked=len(names))


def verify_config(before, after):
    delta = {k: [before.get(k), after.get(k)] for k in before.keys() | after.keys()
             if before.get(k) != after.get(k)}
    require(delta == EXPECTED_CONFIG_DELTA, 'UNEXPECTED_CONFIG_CHANGE:' + repr(delta))
    require(after.get('CONFIG_RTMM') is None, 'RTMM_ENABLED_WITHOUT_IMPLEMENTATION')
    for key in ('CONFIG_QGKI', 'CONFIG_SCHED_WALT', 'CONFIG_SPECULATIVE_PAGE_FAULT',
                'CONFIG_HARDWARE_INFO', 'CONFIG_LTO', 'CONFIG_LTO_CLANG', 'CONFIG_CFI_CLANG',
                'CONFIG_HAVE_HW_BREAKPOINT', 'CONFIG_MM_STAT_UNRECLAIMABLE_PAGES'):
        require(after.get(key) == 'y', 'REQUIRED_FUNCTION_DISABLED:' + key)
    return delta


def verify_abi(actual, reference, expected):
    require(actual.get('module_layout') == EXPECTED_LAYOUT, 'STOCK_MODULE_LAYOUT_LOST')
    require(all(actual.get(n) == crc for n, crc in OEM.items()), 'OEM_EXPORT_REGRESSION')
    old = {n for n, crc in expected.items() if reference.get(n) == crc}
    new = {n for n, crc in expected.items() if actual.get(n) == crc}
    require(not old - new, 'PREVIOUS_STOCK_MATCH_LOST:' + repr(sorted(old - new)))
    require(not expected.keys() - actual.keys(), 'MISSING_ORIGINAL_IMPORTS')
    forecast = json.loads((ROOT / 'Reports/LOCAL_COMBINED_RESULT.json').read_text())
    gains = {n for p in forecast['probes'].values() for n in p['stock_gains']}
    require(len(gains) == 66 and gains <= new - old, 'LOCAL_66_IMPORT_GAINS_NOT_CONFIRMED')
    return {'gained_matching_symbols': sorted(new - old), 'lost_matching_symbols': [],
            'remaining_missing_symbols': [], 'module_layout_matches_stock': EXPECTED_LAYOUT,
            'local_66_gain_forecast_confirmed': True}


def build(args):
    verify_package()
    r15 = dependency()
    r14 = r15.dependency()
    r13, r12, h = r14.dependency()
    r6 = r14.load(Path(args.r6_tool), 'r16_r6_verifier')
    src = Path(args.source).resolve(strict=True)
    obj = Path(args.objout).resolve(strict=True)
    out = Path(args.output).resolve()
    ws = Path(os.environ['GITHUB_WORKSPACE']).resolve(strict=True)
    project = Path(args.project).resolve(strict=True)
    require(not out.exists() and out.is_relative_to(ws), 'OUTPUT_MUST_BE_NEW')
    require(src.is_relative_to(ws) and obj.is_relative_to(ws)
            and not out.is_relative_to(src) and not out.is_relative_to(obj)
            and not out.is_relative_to(project) and not src.is_relative_to(project), 'UNSAFE_OUTPUT')
    base = json.loads(Path(args.r6_report).read_text())
    require(base['status'] == 'R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH',
            'R6_CONTROL_NOT_GREEN')
    require(sha(obj / '.config') == h.CONFIG_SHA and sha(obj / 'Module.symvers') == h.SYMVERS_SHA
            and sha(obj / 'arch/arm64/boot/Image') == base['image_sha256'], 'R6_CONTROL_CHANGED')
    guards = {n: sha(obj / n) for n in ('.config', 'Module.symvers', 'arch/arm64/boot/Image')}
    expected, imports = h.references()
    reference = reference_cohort()
    _, _, old_counts = h.compare(reference, expected, imports)
    require(old_counts == {'MATCH': 1092, 'CRC_MISMATCH': 331, 'NOT_EXPORTED': 0}, 'R15_NOT_AUTHENTIC')
    require(set(reference) == set(expected), 'R15_REFERENCE_COHORT_CHANGED')
    require(sha(ROOT / 'References/R15.config') == 'df76959d1b5a7adf3b351e13892810b3e599aee71278470e39689e7116ec0419', 'R15_CONFIG_CHANGED')
    before = r12.config_values((ROOT / 'References/R15.config').read_text())
    commands = {row['target']: row['invocation'] for row in base['make_results']}
    require(set(commands) == {'Image', 'dtbs', 'modules'}, 'BASELINE_COMMANDS_MISSING')
    out.mkdir(parents=True)
    result = dict(status='R16_BUILD_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  flash_allowed=False, device_boot_tested=False, make_results=[],
                  baseline_verified_run=43377692149, baseline_r15_qgki_counts=old_counts,
                  rtmm_driver_enabled=False, rtmm_functionality_restored=False)
    try:
        candidate, candidate_out = out / 'candidate-source', out / 'candidate-out'
        shutil.copytree(src, candidate, ignore=shutil.ignore_patterns('.git'), symlinks=True)
        candidate_out.mkdir()
        shutil.copyfile(obj / '.config', candidate_out / '.config')
        result['r11_iommu'] = h.apply_scoped(candidate, h.generated_patches())
        result['r11_dependencies'] = h.audit_dependencies(candidate)
        result['r12_spf'] = r12.apply_source(candidate)
        result['r13_cpu_exports'] = r13.apply_source(candidate)
        result['r14_oem'] = r14.apply_source(candidate)
        result['r15_layout'] = r15.apply_source(candidate)
        result['r16_memory_network'] = apply_source(candidate)
        request = subprocess.run(['bash', str(candidate / 'scripts/config'), '--file',
                                  str(candidate_out / '.config'), '-e', 'SPECULATIVE_PAGE_FAULT',
                                  '-e', 'HARDWARE_INFO', '-e', 'MM_STAT_UNRECLAIMABLE_PAGES',
                                  '-e', 'EMERGENCY_MEMORY', '-e', 'MULTIPLE_KSWAPD',
                                  '-e', 'VM_EVENT_COUNT_CLEAN_PAGE_RECLAIM'],
                                 text=True, capture_output=True)
        require(request.returncode == 0, 'CONFIG_REQUEST_FAILED:' + request.stderr)
        units = sorted(set(r12.object_targets(obj) + r15.NEW_UNITS
                           + ['init/main.o', 'kernel/sysctl.o', 'mm/page_alloc.o',
                              'mm/filemap.o', 'net/core/dev.o', 'net/core/net-sysfs.o',
                              'net/core/skbuff.o', 'drivers/base/core.o']
                           + ['kernel/smp.o', 'lib/cpumask.o', 'sound/soc/soc-core.o',
                              'drivers/misc/hardware_info.o']))
        resolved_sha = None
        for target in ['olddefconfig'] + units + ['Image', 'dtbs', 'modules']:
            argv = list(commands.get(target, commands['Image']))
            require(argv[0] == 'make' and argv.count('-C') == 1
                    and argv[argv.index('-C') + 1] == str(src)
                    and argv.count('O=' + str(obj)) == 1, 'INVALID_BASELINE_INVOCATION')
            argv[argv.index('-C') + 1] = str(candidate)
            argv[argv.index('O=' + str(obj))] = 'O=' + str(candidate_out)
            argv[-1] = target
            row = h.run_make(argv, out, target.replace('/', '_'), r6.pinned_llvm_tool_env(argv))
            row['target'] = target
            result['make_results'].append(row)
            require(row['exit_code'] == 0, 'ARM64_BUILD_FAILED:' + target)
            if target == 'olddefconfig':
                result['config_delta_against_r15'] = verify_config(before,
                    r12.config_values((candidate_out / '.config').read_text()))
                resolved_sha = sha(candidate_out / '.config')
            require(sha(candidate_out / '.config') == resolved_sha, 'CONFIG_DRIFT')
        require(r6.is_arm64_image(candidate_out / 'arch/arm64/boot/Image')
                and r6.is_arm64_elf(candidate_out / 'vmlinux'), 'NOT_AN_ARM64_KERNEL')
        result['kernel_compiled'] = True
        result['release'] = r6.verify_generated_release(candidate_out)
        result['rmnet_initcalls'] = r6.prove_real_linked_initcalls(candidate_out / 'System.map')
        result['real_build_log'] = r6.prove_build_log(out / 'Image.log')
        require(result['real_build_log']['linker_warning_free'], 'LINKER_WARNINGS')
        actual = h.parse_symvers(candidate_out / 'Module.symvers')
        symbols, modules, counts = h.compare(actual, expected, imports)
        h.save_csv(out / 'QGKI_1423_SYMBOL_RESULTS.csv', symbols)
        h.save_csv(out / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result['qgki_counts'] = counts
        result['module_layout_crc'] = actual.get('module_layout')
        result['fully_matching_modules'] = sum(row['fully_compatible'] for row in modules)
        result['linked_cpu_exports'] = r13.prove_linked_exports(candidate_out / 'System.map')
        result['linked_oem_exports'] = r14.prove_linked(candidate_out / 'System.map')
        result['abi_progress'] = verify_abi(actual, reference, expected)
        result['source_postimage_hashes'] = {n: sha(candidate / n) for n in pins()}
        result['kernel_product_hashes'] = {n: sha(candidate_out / n) for n in
            ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux')}
        result['status'] = 'R16_FULL_ARM64_BUILD_AND_MEMORY_NETWORK_ABI_PROGRESS_PROVEN_NOFLASH'
    except Exception as error:
        result.update(status='R16_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        result['r6_baseline_unchanged'] = all(sha(obj / n) == digest for n, digest in guards.items())
        write_json(out / 'R16_RESULT.json', result)
    require(result['r6_baseline_unchanged'], 'R6_BASELINE_MUTATED')
    print(result['status'], result['qgki_counts'], 'RTMM_IMPLEMENTATION=UNAVAILABLE FLASH=NO')



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    for name in ('patch-source', 'check-source', 'check-baseline'):
        sub.add_parser(name).add_argument('--source', required=True)
    bp = sub.add_parser('build')
    for name in ('source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        bp.add_argument('--' + name, required=True)
    args = parser.parse_args()
    verify_package()
    if args.operation == 'verify-package':
        print('R16_COMPLETE_MEMORY_AND_NETWORK_SOURCES_AUTHENTICATED')
    elif args.operation == 'patch-source':
        print(json.dumps(apply_source(args.source), sort_keys=True))
    elif args.operation == 'check-baseline':
        print(json.dumps(check_baseline(args.source), sort_keys=True))
    elif args.operation == 'check-source':
        print(json.dumps(check_source(args.source), sort_keys=True))
    else:
        build(args)


if __name__ == '__main__':
    main()
