import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r16_test', ROOT / 'Tools/restore_memory_network.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class RepairTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original_R15', self.source)

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self):
        return {str(p.relative_to(self.source)): p.read_bytes()
                for p in self.source.rglob('*') if p.is_file()}

    def test_complete_eighteen_file_port_has_exact_fixture_postimages(self):
        result = r.apply_source(self.source)
        self.assertEqual(result['changed_files'], 18)
        self.assertFalse(result['crcs_overridden'])
        for name, pin in r.pins().items():
            self.assertEqual(r.sha(self.source / name), pin['after_sha256'], name)

    def test_shared_final_allocator_exit_releases_waiter_count_once(self):
        r.apply_source(self.source)
        alloc = (self.source / 'mm/page_alloc.c').read_text()
        start = alloc.index('static inline struct page *\n__alloc_pages_slowpath')
        section = alloc[start:alloc.index('static inline void finalise_ac', start)]
        self.assertEqual(section.count('atomic_long_dec(&kswapd_waiters)'), 1)
        fallback = section.index('if (!page && !(gfp_mask & __GFP_NOWARN) && !costly_order)')
        self.assertLess(fallback, section.index('atomic_long_dec(&kswapd_waiters)'))

    def test_no_source_write_after_late_preimage_drift(self):
        p = self.source / 'net/core/net-sysfs.c'
        p.write_text(p.read_text() + '\nint unexpected_drift;\n')
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
            r.apply_source(self.source)
        self.assertEqual(self.snapshot(), before)

    def test_public_type_drift_is_rejected_before_writing(self):
        p = self.source / 'include/linux/mmzone.h'
        p.write_text(p.read_text().replace('struct zone {', 'struct zone { int wrong;'))
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'HEADER_TOKEN_DRIFT'):
            r.apply_source(self.source)
        self.assertEqual(self.snapshot(), before)

    def test_unrelated_prior_sysctl_changes_are_preserved(self):
        p = self.source / 'kernel/sysctl.c'
        addition = '\n/* earlier independent WALT integration */\nextern int old_walt_control;\n'
        p.write_text(p.read_text() + addition)
        r.apply_source(self.source)
        self.assertTrue(p.read_text().endswith(addition))

    def test_changed_sysctl_hunk_is_rejected_before_any_write(self):
        p = self.source / 'kernel/sysctl.c'
        old = '.procname\t= "watermark_scale_factor"'
        self.assertIn(old, p.read_text())
        p.write_text(p.read_text().replace(old, '.procname\t= "unrelated_control"'))
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'CONTEXT_PATCH_FAILED'):
            r.apply_source(self.source)
        self.assertEqual(self.snapshot(), before)

    def test_symlink_cannot_redirect_a_write(self):
        p = self.source / 'mm/internal.h'
        outside = Path(self.temp.name) / 'outside'
        outside.write_bytes(p.read_bytes())
        original = outside.read_bytes()
        p.unlink()
        p.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'SOURCE_NOT_REGULAR'):
            r.apply_source(self.source)
        self.assertEqual(outside.read_bytes(), original)

    def test_second_application_is_rejected(self):
        r.apply_source(self.source)
        with self.assertRaises(ValueError):
            r.apply_source(self.source)

    def test_real_r15_reference_has_1092_matches_and_331_differences(self):
        h = r.dependency().dependency().dependency()[2]
        expected, imports = h.references()
        actual = r.reference_cohort()
        self.assertEqual(set(actual), set(expected))
        _, modules, counts = h.compare(actual, expected, imports)
        self.assertEqual(counts, {'MATCH': 1092, 'CRC_MISMATCH': 331, 'NOT_EXPORTED': 0})
        self.assertEqual(sum(m['fully_compatible'] for m in modules), 1)

    def abi_fixture(self):
        h = r.dependency().dependency().dependency()[2]
        expected, _ = h.references()
        reference = r.reference_cohort()
        actual = dict(reference)
        for p in json.loads((ROOT / 'Reports/LOCAL_COMBINED_RESULT.json').read_text())['probes'].values():
            for name in p['stock_gains']:
                actual[name] = expected[name]
        return actual, reference, expected

    def test_all_66_locally_verified_import_gains_are_required(self):
        actual, reference, expected = self.abi_fixture()
        self.assertTrue(r.verify_abi(actual, reference, expected)['local_66_gain_forecast_confirmed'])
        actual['register_netdev'] = reference['register_netdev']
        with self.assertRaisesRegex(ValueError, '66_IMPORT_GAINS_NOT_CONFIRMED'):
            r.verify_abi(actual, reference, expected)

    def test_any_loss_of_previous_1092_matches_fails(self):
        actual, reference, expected = self.abi_fixture()
        name = next(n for n in expected if n not in r.OEM and n != 'module_layout'
                    and reference[n] == expected[n])
        actual[name] = '0x00000000'
        with self.assertRaisesRegex(ValueError, 'PREVIOUS_STOCK_MATCH_LOST'):
            r.verify_abi(actual, reference, expected)

    def test_module_layout_and_real_oem_exports_are_mandatory(self):
        actual, reference, expected = self.abi_fixture()
        actual['module_layout'] = '0x71c13c49'
        with self.assertRaisesRegex(ValueError, 'STOCK_MODULE_LAYOUT_LOST'):
            r.verify_abi(actual, reference, expected)

    def test_only_three_real_memory_flags_change(self):
        r12 = r.dependency().dependency().dependency()[1]
        before = r12.config_values((ROOT / 'References/R15.config').read_text())
        after = dict(before, **{n: 'y' for n in r.EXPECTED_CONFIG_DELTA})
        self.assertEqual(r.verify_config(before, after), r.EXPECTED_CONFIG_DELTA)
        after['CONFIG_CFI_CLANG'] = None
        with self.assertRaises(ValueError):
            r.verify_config(before, after)

    def test_early_guard_replays_previous_ports_without_touching_source(self):
        r15 = r.dependency()
        r14 = r15.dependency()
        r13, r12, h = r14.dependency()
        for fixture in (r15.ROOT / 'Original_R14', r14.ROOT / 'Original_R13',
                        r13.ROOT / 'Original_R12', r12.ROOT / 'Original_R11',
                        h.ROOT / 'Original_Donor'):
            shutil.copytree(fixture, self.source, dirs_exist_ok=True)
        before = self.snapshot()
        result = r.check_baseline(self.source)
        self.assertTrue(result['prior_ports_replayed_without_modifying_source'])
        self.assertEqual(before, self.snapshot())


if __name__ == '__main__':
    unittest.main()
