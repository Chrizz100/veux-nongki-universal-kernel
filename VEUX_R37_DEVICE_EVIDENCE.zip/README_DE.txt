R37 Nur-Lese-Erfassung, aktiver Slot _a
Enthaelt nur Stock-Vendor-Boot-Basis-DTB, Stock-DTBO-Eintrag 0 und freigegebene FDT-Metadaten.
Das rohe aktive Laufzeit-FDT wird nicht gespeichert. KEIN FLASH.
