VEUX R41 – Nur Quell- und Manifest-Gate (NO FLASH)

Dies ist KEINE AK3-Flashdatei und KEIN fertig gepruefter Kernel.
R41 basiert exakt auf VEUX_R13_CASS_MAIN.zip (SHA im Vertrag) und
autorisiert genau vier Quell-/Dokumentationsdateien.

Geaendert:
- r13/assets/anykernel.sh.in: Original-R40-Fail-Closed-NoMount
- r13/package_anykernel.py: Hinweise ohne automatische NoMount-Deaktivierung
- r13/audit_revision.py: neuer strenger R41-Quellhash-Vertrag
- ANLEITUNG.txt: R41-Quellkandidat und Nicht-Flashen ausdruecklich

R13-SOURCE_CONTRACT, Kernel- und RMNET-Quellstand bleiben unveraendert.
Der SHA-beglaubigte R41-Manifeststand ersetzt NICHT ungeprueft die R13-Build-YAML.
Das Skript r41/verify_r41_source.py laesst sich rein lokal ausfuehren:
python3 -B r41/verify_r41_source.py --candidate-main VEUX_R41_NOMOUNT_SOURCE_MAIN.zip --r13-main VEUX_R13_CASS_MAIN.zip --r40-main VEUX_R40_NOMOUNT_REMOVE_GUARD_SOURCE_ONLY_MAIN.zip --out R41_RESULT

Die Ausfuehrung erfordert keine Root-Rechte, keinen Kernelbau und keinen Flash.
Keine GitHub-YAML, weil actionlint lokal bislang nicht verfuegbar ist.
Das fehlende CI-Gate und die OEM-ABI werden nicht als bestanden gemeldet.
