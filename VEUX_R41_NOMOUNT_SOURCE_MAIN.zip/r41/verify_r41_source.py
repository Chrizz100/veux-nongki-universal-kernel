#!/usr/bin/env python3
"""R41 authenticated SOURCE-ONLY gate, never builds, executes or flashes an installer.

Requires the original immutable R13 source MAIN and the original R40 audit ZIP.
Can be executed offline. Never writes to the original inputs or repository.
The ONLY write target is --out, which must not exist, plus temporary directories.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

R13_MAIN_SHA = '15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1'
R40_MAIN_SHA = '396c97202fc36a350c7ab17d87b5893d72ce9f12126976d92fbc27c1bc414344'
SHELLCHECK_SHA = '4da528ddb3a4d1b7b24a59d4e16eb2f5fd960f4bd9a3708a15baddbdf1d5a55b'
AUTHORIZED = {'ANLEITUNG.txt', 'r13/assets/anykernel.sh.in',
              'r13/package_anykernel.py', 'r13/audit_revision.py'}
ADDITIONS = {
    "r41/INSTALLER_SOURCE_CONTRACT.json",
    "r41/README_DE.txt",
    "r41/verify_r41_source.py",
    "r41/evidence/VEUX_R40_NOMOUNT_REMOVE_GUARD_SOURCE_ONLY_MAIN.zip",
    "r41/patches/R40_PATCH_FROM_R13_TEMPLATE_SOURCE_ONLY.diff",
    "r41/patches/R39_PATCH_R13_PACKAGING_DOCS_SOURCE_ONLY.diff",
    "r41/patches/R41_PATCH_R13_AUDIT_SOURCE_ONLY.diff",
    "r41/patches/R41_PATCH_R13_ANLEITUNG_SOURCE_ONLY.diff",
}
PATCHES = {
    'r13/assets/anykernel.sh.in': 'R40_PATCH_FROM_R13_TEMPLATE_SOURCE_ONLY.diff',
    'r13/package_anykernel.py': 'R39_PATCH_R13_PACKAGING_DOCS_SOURCE_ONLY.diff',
    'r13/audit_revision.py': 'R41_PATCH_R13_AUDIT_SOURCE_ONLY.diff',
    'ANLEITUNG.txt': 'R41_PATCH_R13_ANLEITUNG_SOURCE_ONLY.diff',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def run(cmd, cwd=None, check=True):
    p=subprocess.run([str(x) for x in cmd],cwd=cwd,text=True,stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE,timeout=60)
    if check and p.returncode != 0:
        raise RuntimeError('COMMAND_FAILED: '+repr([str(x) for x in cmd])+'\n'+(p.stdout+p.stderr)[-1500:])
    return p


def safe_archive(path, output, expected_sha, require_manifest=True):
    require(path.is_file() and not path.is_symlink(), 'INPUT_ARCHIVE_MISSING_OR_SYMLINK')
    require(digest(path.read_bytes())==expected_sha,'INPUT_SHA_MISMATCH:'+path.name)
    with zipfile.ZipFile(path) as z:
        infos=z.infolist(); names=[x.filename for x in infos]
        require(len(names)==len(set(names)) and z.testzip() is None,'ZIP_CRC_OR_DUPLICATES:'+path.name)
        require(len(infos)<400 and sum(i.file_size for i in infos)<130_000_000,'ZIP_SIZE_LIMIT')
        for i in infos:
            p=PurePosixPath(i.filename)
            require(not p.is_absolute() and '..' not in p.parts and '.' not in p.parts
                    and len(p.parts)<8 and not i.is_dir() and '\\' not in i.filename
                    and stat.S_IFMT(i.external_attr>>16)!=stat.S_IFLNK,
                    'UNSAFE_ZIP_MEMBER:'+i.filename)
        if require_manifest:
            require('PAYLOAD_MANIFEST.json' in names,'MISSING_SOURCE_MANIFEST')
            m=json.loads(z.read('PAYLOAD_MANIFEST.json'))
            require(m.get('schema')==1 and m.get('automatic_flash') is False,
                    'UNSAFE_MANIFEST_SCHEMA')
            require(set(m.get('files',{}))|{'PAYLOAD_MANIFEST.json'}==set(names),
                    'MANIFEST_MEMBER_SET_MISMATCH')
            for n,sha in m['files'].items():
                require(re.fullmatch(r'[0-9a-f]{64}',sha) is not None
                        and digest(z.read(n))==sha,'INVALID_MEMBER:'+n)
        else:
            m=None
        output.mkdir()
        for n in names:
            dest=output/n
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(z.read(n))
    return m, names


def source_audit(folder):
    # Independent subprocess avoids importing the other revision into sys.modules.
    script=("import sys,json; sys.path.insert(0,sys.argv[1]+'/r13');"
            "from audit_revision import audit;print(json.dumps(audit(sys.argv[1]),sort_keys=True))")
    p=run([sys.executable,'-B','-c',script,str(folder)])
    return json.loads(p.stdout)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--candidate-main',required=True,type=Path)
    ap.add_argument('--r13-main',required=True,type=Path)
    ap.add_argument('--r40-main',type=Path,help='optional external R40; embedded R40 evidence is used by default')
    ap.add_argument('--out',required=True,type=Path)
    args=ap.parse_args()
    for a in [x for x in [args.candidate_main,args.r13_main,args.r40_main] if x is not None]:
        args_path=a.resolve(strict=True)
        require(args.out.resolve()!=args_path, 'REPORT_OUT_IS_INPUT_ARCHIVE')
    require(not args.out.exists() and not args.out.is_symlink(), 'OUT_DIRECTORY_ALREADY_EXISTS')
    checks=[]; neg=[]; test_records={}
    with tempfile.TemporaryDirectory(prefix='veux-r41-') as temporary:
        t=Path(temporary);orig=t/'original';r41=t/'candidate'
        m0,n0=safe_archive(args.r13_main,orig,R13_MAIN_SHA)
        checks.append('R13_319_ARCHIVE_MEMBERS_AUTHENTICATED')
        # The candidate archive's external SHA pin is supplied by its future CI YAML;
        # this local audit uses an independently created source-contract manifest.
        candidate_sha=digest(args.candidate_main.read_bytes())
        m1,n1=safe_archive(args.candidate_main,r41,candidate_sha)
        checks.append('R41_EVERY_ARCHIVE_MEMBER_AUTHENTICATED')
        embedded=r41/'r41/evidence/VEUX_R40_NOMOUNT_REMOVE_GUARD_SOURCE_ONLY_MAIN.zip'
        require(digest(embedded.read_bytes())==R40_MAIN_SHA, 'EMBEDDED_R40_SHA_MISMATCH')
        if args.r40_main is not None:
            require(args.r40_main.is_file() and not args.r40_main.is_symlink()
                    and digest(args.r40_main.read_bytes())==R40_MAIN_SHA, 'R40_ARCHIVE_SHA_CHANGED')
            require(args.r40_main.read_bytes()==embedded.read_bytes(), 'R40_EMBEDDED_EXTERNAL_DIFFER')
        r40_path=embedded
        checks.append('R40_ORIGINAL_ARCHIVE_PIN_MATCH')
        contract=json.loads((r41/'r41/INSTALLER_SOURCE_CONTRACT.json').read_text())
        require(contract.get('schema')==1 and contract.get('status')=='SOURCE_ONLY_NO_FLASH'
                and contract.get('flash_allowed') is False and contract.get('kernel_build') is False,
                'R41_CONTRACT_UNSAFE')
        require(contract['base_r13_main_sha256']==R13_MAIN_SHA
                and contract['r40_main_sha256']==R40_MAIN_SHA,
                'R41_CONTRACT_INPUT_MISMATCH')
        require(sorted(contract['allowed_modified_r13_files'])==sorted(AUTHORIZED),
                'R41_MODIFICATION_SCOPE_CHANGED')
        require(m1.get('name')=='VEUX R41 CASS NOFLASH source contract and NoMount installer guard'
                and m1.get('r41_source_only') is True
                and m1.get('kernel_build') is False
                and m1.get('r41_contract_sha256')==digest((r41/'r41/INSTALLER_SOURCE_CONTRACT.json').read_bytes()),
                'R41_MANIFEST_METADATA_CHANGED')
        checks.append('R41_NEW_MANIFEST_AND_CONTRACT_PINNED')
        old_files=set(m0['files'])
        require(set(n1)-set(n0)==ADDITIONS and set(n0)-set(n1)==set(),
                'R41_UNEXPECTED_ADDED_OR_REMOVED_ARCHIVE_MEMBER')
        require(set(m1['files'])==old_files|ADDITIONS,
                'R41_MANIFEST_INPUT_SCOPE_MISMATCH')
        require(not any('__pycache__' in n or n.endswith('.pyc') for n in n1),
                'PYTHON_CACHE_INSIDE_SOURCE_ARCHIVE')
        require({n for n in old_files if m0['files'][n]!=m1['files'][n]}==AUTHORIZED,
                'R41_UNAUTHORIZED_BASE_FILE_CHANGE')
        for name in old_files-AUTHORIZED:
            require((orig/name).read_bytes()==(r41/name).read_bytes(),
                    'ORIGINAL_INPUT_CHANGED:'+name)
        for name in AUTHORIZED:
            expected=contract['authorized_changes'][name]
            require(digest((orig/name).read_bytes())==expected['before_sha256']
                    and digest((r41/name).read_bytes())==expected['after_sha256'],
                    'R41_AUTHORIZED_FILE_HASH_MISMATCH:'+name)
        checks.append('ONLY_FOUR_AUTHORIZED_R13_FILES_CHANGED')
        require((orig/'r13/SOURCE_CONTRACT.json').read_bytes()==(r41/'r13/SOURCE_CONTRACT.json').read_bytes(),
                'KERNEL_SOURCE_CONTRACT_CHANGED')
        require((orig/'r13/static_green.py').read_bytes()==(r41/'r13/static_green.py').read_bytes(),
                'HISTORICAL_BUILD_GATE_CHANGED')
        checks.append('CASS_BAKASU_SUSFS_NOMOUNT_KERNEL_CONTRACT_UNCHANGED')
        with zipfile.ZipFile(r40_path) as w:
            require(w.testzip() is None,'R40_ZIP_CRC_FAILURE')
            for name in PATCHES.values():
                if name.startswith('R40_') or name.startswith('R39_'):
                    expected=w.read(name)
                    require(expected==(r41/'r41/patches'/name).read_bytes(),
                            'NOT_ORIGINAL_R40_PATCH:'+name)
        for target,pn in PATCHES.items():
            raw=(r41/'r41/patches'/pn).read_bytes()
            require(digest(raw)==contract['authorized_changes'][target]['patch_sha256'],
                    'PATCH_HASH_CHANGED:'+target)
        checks.append('R40_GUARD_AND_DOCUMENTATION_PATCHES_PROVENANCE_VERIFIED')
        # Prove that the four current files are exactly what the four pinned diffs create.
        overlay=t/'rebuild_from_original';shutil.copytree(orig,overlay)
        for name in PATCHES.values():
            patch=r41/'r41/patches'/name
            run(['git','apply','--check',str(patch)],cwd=overlay)
            run(['git','apply',str(patch)],cwd=overlay)
        for n in old_files:
            require((overlay/n).read_bytes()==(r41/n).read_bytes(), 'R41_PATCH_REPRODUCTION_MISMATCH:'+n)
        checks.append('FOUR_PATCHES_REPRODUCED_BYTE_FOR_BYTE')
        report0=source_audit(orig)
        report1=source_audit(r41)
        require(report0['status']=='R13_EXPLICIT_REVISION_PASS'
                and report1['status']=='R41_EXPLICIT_INSTALLER_OVERLAY_PASS'
                and report1['authorized_r40_installer_overlay'] is True
                and report1['full_abi_and_compiler_pins_preserved'] is True,
                'SOURCE_REVISION_CHAIN_REJECTED')
        checks.append('R13_AND_R41_REVISION_AUDITS_PASSED')
        # The historical R13 auditor must still reject this intentionally changed installer.
        stale=t/'stale_original_auditor.py';stale.write_bytes((orig/'r13/audit_revision.py').read_bytes())
        archived=(r41/'r13/audit_revision.py').read_bytes()
        (r41/'r13/audit_revision.py').write_bytes(stale.read_bytes())
        try:
            p=run([sys.executable,'-B','-c',
                   "import sys;sys.path.insert(0,sys.argv[1]+'/r13');from audit_revision import audit;audit(sys.argv[1])",
                   str(r41)],check=False)
            require(p.returncode!=0 and 'R13_ANYKERNEL_BEHAVIOR_CHANGED' in p.stderr,
                    'ORIGINAL_R13_AUDITOR_FAILED_TO_REJECT_NEW_TEMPLATE')
            neg.append('ORIGINAL_R13_GUARD_REJECTS_R40_INSTALLER')
        finally:
            (r41/'r13/audit_revision.py').write_bytes(archived)
        for target in ['r13/assets/anykernel.sh.in','r13/package_anykernel.py','r13/SOURCE_CONTRACT.json']:
            dest=r41/target;content=dest.read_bytes();dest.write_bytes(content+b'\n#tamper\n')
            try:
                p=run([sys.executable,'-B','-c',
                   "import sys;sys.path.insert(0,sys.argv[1]+'/r13');from audit_revision import audit;audit(sys.argv[1])",
                   str(r41)],check=False)
                require(p.returncode!=0,'R41_AUDITOR_ACCEPTED_TAMPER:'+target)
                neg.append('R41_AUDITOR_REJECTS_'+target.upper().replace('/','_'))
            finally:dest.write_bytes(content)
        # Shell syntax only; never source or execute any installer function.
        template=r41/'r13/assets/anykernel.sh.in'
        for shell in [['/bin/sh'],['/bin/bash']]:
            run(shell+['-n',str(template)])
        native=r41/'r12/host-tools/shellcheck'
        require(digest(native.read_bytes())==SHELLCHECK_SHA,'R13_PINNED_SHELLCHECK_CHANGED')
        native.chmod(0o755)
        run([native,'--shell=ash','--severity=warning',str(template)])
        checks.append('SHELL_SYNTAX_AND_PINNED_SHELLCHECK_PASS')
        # Existing independent R13 and R12 regression scripts, all tests explicit.
        for label,subfolder,pattern,count in [('R13_GUARDS','r13/tests','test_r13_guards.py',15),
                                               ('R12_ENV','r12/tests','test_environment_lifecycle.py',27)]:
            p=run([sys.executable,'-B','-m','unittest','discover','-s',str(r41/subfolder),
                   '-p',pattern,'-v'])
            require(re.search(r'Ran\s+'+str(count)+r'\s+tests',p.stderr) is not None
                    and '\nOK' in p.stderr,'REGRESSION_COUNT_CHANGED:'+label)
            test_records[label]={'passed':count,'total':count}
        checks.append('ORIGINAL_42_REGRESSIONS_PASSED')
        # Preserve original kernel source contract and forbid flashable artifacts.
        require(not any(n=='Image' or n in ('boot.img','vendor_boot.img','dtbo.img')
                        for n in n1),'R41_FLASHABLE_IMAGE_PRESENT')
        require(not any(n.startswith('.github/workflows/') for n in n1),'R41_WORKFLOW_NOT_GREEN')
        checks.append('NO_KERNEL_IMAGE_BOOT_IMAGE_OR_WORKFLOW_EMBEDDED')
        data={
            'status':'R41_SOURCE_MANIFEST_CONTRACT_LOCAL_GREEN__GITHUB_ACTIONLINT_PENDING__NO_FLASH',
            'source_candidate_sha256':candidate_sha,
            'original_r13_sha256':R13_MAIN_SHA,'original_r40_sha256':R40_MAIN_SHA,
            'original_r13_members':len(n0),'r41_candidate_members':len(n1),
            'authorized_modified_members':sorted(AUTHORIZED),
            'checks':checks,'negative_controls':neg,
            'regression_tests':test_records,
            'revision_audit':report1,
            'limitations':['no actionlint binary available locally','no GitHub Actions R41 run',
                'no fresh kernel compile/repack/DTB/DTBO test','no on-device NoMount version verification',
                'no boot partition write or recovery test','nine external OEM module ABI paths remain unresolved'],
            'kernel_build_performed':False,'installer_executed':False,'device_modified':False,
            'flash_allowed':False,
        }
    args.out.mkdir(parents=True)
    (args.out/'R41_SOURCE_GATE_RESULT.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    (args.out/'R41_SOURCE_GATE_SUMMARY.txt').write_text(
        'VEUX R41 – authentifizierte Quell-/Manifest-Integration (NO FLASH)\n'
        +f'Quelle R13: {R13_MAIN_SHA}\nPatch R40: {R40_MAIN_SHA}\n'
        +f'R41 ZIP: {candidate_sha}\n'
        +f'Offline-Kontrollen: {len(checks)}/{len(checks)} bestanden; Negativtests: {len(neg)}/{len(neg)} abgewiesen; '\
        +f'R13/R12 Regressionen: {sum(x["passed"] for x in test_records.values())} bestanden\n'
        +'Keine GitHub-CI-/actionlint-Freigabe. Kein Kernelbau, kein Flash, keine Moduländerung.\n'
    )
    print(json.dumps({'status':data['status'],'checks':len(checks),
                      'negative_controls':len(neg),'regressions':sum(x['passed'] for x in test_records.values())}))

if __name__=='__main__':
    main()
