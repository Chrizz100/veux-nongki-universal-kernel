#!/usr/bin/env python3
"""Restore the real WALT domain feature and the configured stock vendor release."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
HEADER = 'include/linux/sched/topology.h'
FILES = (HEADER, 'kernel/sched/sched.h', 'kernel/sched/fair.c', 'kernel/sched/topology.c')
LOCALVERSION = 'CONFIG_LOCALVERSION'
AUTO = 'CONFIG_LOCALVERSION_AUTO'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def token_sha(text):
    return hashlib.sha256(re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '', text,
                                                flags=re.S)).encode()).hexdigest()


def profile():
    p = json.loads((ROOT/'References/PROFILE.json').read_text())
    require(len(set(p['previous_matches'])) == 1420 and len(p['required_scheduler_crcs']) == 3,
            'R21_PROFILE_CHANGED')
    return p


def pins():
    p = json.loads((ROOT/'References/SOURCE_PINS.json').read_text())
    require(set(p) == set(FILES), 'R21_SOURCE_SCOPE_CHANGED')
    return p


def verify_package():
    names = set()
    for line in (ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1);p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in names,
                'UNSAFE_R21_MANIFEST')
        require(not (ROOT/p).is_symlink() and sha(ROOT/p) == digest, 'R21_PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names, 'R21_MANIFEST_SCOPE_CHANGED');profile();pins()


def functional_checks(source):
    source = Path(source);text = {n:(source/n).read_text() for n in FILES}
    struct = re.search(r'(?ms)^struct sched_domain_shared \{.*?^};', text[HEADER])
    require(struct is not None and re.search(r'#ifdef CONFIG_SCHED_WALT\s+bool\s+overutilized;\s+#endif',
                                             struct[0]), 'REAL_STOCK_DOMAIN_FIELD_MISSING')
    fair = text['kernel/sched/fair.c'];topology = text['kernel/sched/topology.c']
    for token in ('sd->shared->overutilized', 'set_sd_overutilized(env->sd);',
                  'clear_sd_overutilized(env->sd);', 'sds->total_util += sgs->group_util;',
                  'sds->total_capacity * 1024 < sds->total_util *',
                  'if (sd->flags & SD_ASYM_CPUCAPACITY)', '!sd_overutilized(env->sd)',
                  'if (!sd_overutilized(sd))', 'trace_android_rvh_find_busiest_group'):
        require(token in fair, 'WALT_DOMAIN_IMPLEMENTATION_MISSING:' + token)
    require(fair.count('static bool sd_overutilized(') == 1
            and fair.count('static void set_sd_overutilized(') == 1
            and fair.count('static void clear_sd_overutilized(') == 1,
            'DOMAIN_ACCESSOR_IMPLEMENTATION_CHANGED')
    require('#define SG_HAS_MISFIT_TASK' in text['kernel/sched/sched.h'], 'MISFIT_STATUS_FLAG_MISSING')
    require(re.search(r'sd->shared = \*per_cpu_ptr\(sdd->sds, sd_id\);\s+atomic_inc\(&sd->shared->ref\);\s+if \(sd->flags & SD_SHARE_PKG_RESOURCES\)',
                      topology), 'SHARED_STATE_NOT_ALLOCATED_AT_ALL_DOMAIN_LEVELS')
    require('kzalloc_node(sizeof(struct sched_domain_shared)' in topology,
            'DOMAIN_STATE_NOT_ZERO_INITIALIZED')
    return {'original_domain_storage_restored':True, 'live_domain_read_set_clear':True,
            'misfit_and_parent_capacity_propagation_restored':True,
            'all_domain_levels_have_initialized_shared_storage':True,
            'existing_android_out_balance_hook_retained':True, 'crcs_overridden':False}


def prepared(source):
    source = Path(source).resolve(strict=True);pp = pins()
    for name, pin in pp.items():
        path = source/name
        require(path.is_file() and not path.is_symlink()
                and all(not x.is_symlink() for x in path.parents if x.is_relative_to(source)),
                'R21_SOURCE_NOT_REGULAR:' + name)
        observed = sha(path) if pin['mode'] == 'exact' else token_sha(path.read_text())
        expected = pin['before_sha256'] if pin['mode'] == 'exact' else pin['before_tokens_sha256']
        require(observed == expected, 'R21_PREIMAGE_DRIFT:' + name)
    with tempfile.TemporaryDirectory(prefix='r21-source-check-') as tmp:
        stage = Path(tmp)
        for name in FILES:
            (stage/name).parent.mkdir(parents=True, exist_ok=True);shutil.copyfile(source/name, stage/name)
        for flags in (['--check'], []):
            r = subprocess.run(['git','apply','--whitespace=error',*flags,
                                str(ROOT/'References/RESTORE_WALT_DOMAIN.patch')],
                               cwd=stage,text=True,capture_output=True)
            require(r.returncode == 0, 'R21_EXACT_CONTEXT_PATCH_FAILED:' + r.stderr)
        for name,pin in pp.items():
            observed = sha(stage/name) if pin['mode']=='exact' else token_sha((stage/name).read_text())
            expected = pin['after_sha256'] if pin['mode']=='exact' else pin['after_tokens_sha256']
            require(observed == expected, 'R21_POSTIMAGE_DRIFT:' + name)
        functional_checks(stage)
        return {n:(stage/n).read_bytes() for n in FILES}


def check_source(source):
    prepared(source)
    return {'four_complete_preimages_verified':True, 'source_changed':False}


def apply_source(source):
    source = Path(source).resolve(strict=True);data = prepared(source)
    for n,b in data.items():(source/n).write_bytes(b)
    return dict(functional_checks(source), source_hashes={n:sha(source/n) for n in FILES})


def request_release(source, config):
    source = Path(source).resolve(strict=True);config = Path(config).resolve(strict=True)
    require(config.is_file() and not config.is_symlink(), 'RELEASE_CONFIG_NOT_REGULAR')
    release = profile()['expected_release']
    r = subprocess.run(['bash',str(source/'scripts/config'),'--file',str(config),
                        '--set-str','LOCALVERSION',release.removeprefix('5.4.274'),
                        '--disable','LOCALVERSION_AUTO'],text=True,capture_output=True)
    require(r.returncode == 0, 'RELEASE_CONFIG_REQUEST_FAILED:' + r.stderr)
    return {'configured_release':release, 'defconfig_modified':False,
            'only_requested_keys':[LOCALVERSION,AUTO], 'binary_patched':False,
            'stock_git_suffix_is_vendor_compatibility_label':True,
            'original_stock_source_commit_claimed':False}


def normalize_release_config(values):
    require(values.get(LOCALVERSION) == '"' + profile()['expected_release'].removeprefix('5.4.274') + '"'
            and values.get(AUTO) == 'n', 'ORIGINAL_RELEASE_CONFIG_NOT_REQUESTED')
    old = dict(values);old[LOCALVERSION] = '"-qgki"';old[AUTO] = 'y'
    observed = hashlib.sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    require(observed == profile()['r19_config_values_sha256'], 'CONFIG_CHANGED_OUTSIDE_TWO_RELEASE_KEYS')
    return old


def configure_release_verifier(module):
    require(sha(module.__file__) == profile()['r6_tool_sha256'], 'ORIGINAL_RELEASE_VERIFIER_CHANGED')
    require(module.CANDIDATE_RELEASE == '5.4.274-qgki'
            and module.STOCK_RELEASE == profile()['expected_release'], 'R6_RELEASE_CONTRACT_CHANGED')
    original = module.verify_generated_release
    module.CANDIDATE_RELEASE = profile()['expected_release']
    def verify(objout):
        result = original(objout)
        result.pop('no_stock_git_id_spoof',None)
        result.update(original_vendor_release_configured=True, binary_identity_edited=False,
                      original_stock_source_commit_claimed=False,
                      source_identity_reported_separately_from_compatibility_release=True)
        return result
    module.verify_generated_release = verify
    return module


def verify_abi(actual,expected):
    require(set(profile()['previous_matches']) <= expected.keys(), 'R19_REFERENCE_SCOPE_CHANGED')
    missing = sorted(expected.keys()-actual.keys())
    mismatched = {n:[crc,actual.get(n)] for n,crc in expected.items() if actual.get(n)!=crc}
    require(not missing and not mismatched, 'ALL_1423_ORIGINAL_IMPORTS_MUST_MATCH:' + repr(mismatched))
    require(len(expected)==1423 and actual.get('module_layout')=='0x945d02f2', 'OEM_LAYOUT_OR_COHORT_CHANGED')
    return {'counts':{'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0},
            'all_three_scheduler_crcs_restored':True,'lost_matching_symbols':[],
            'gained_matching_symbols':sorted(profile()['required_scheduler_crcs'])}


def load_r19(path):
    path = Path(path).resolve(strict=True)
    require(sha(path)==profile()['r19_tool_sha256'], 'AUTHENTIC_R19_EXTENSION_CHANGED')
    spec = importlib.util.spec_from_file_location('r21_proven_r19',path)
    m = importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.verify_package();return m


def build(args):
    verify_package();check_source(args.source)
    r19 = load_r19(args.r19_tool);r18 = r19.load_r18(args.r18_tool)
    r17 = r18.load_r17(args.r17_tool);base = r17.load_base(args.base_tool)
    r15 = base.dependency();r14 = r15.dependency()
    original_dependency, original_r15_dep, original_load = base.dependency, r15.dependency, r14.load
    original_apply, original_config, original_abi = base.apply_source, base.verify_config, base.verify_abi
    out = Path(args.output).resolve()
    result = {'status':'R21_BUILD_PENDING','baseline_run':43471009003,'kernel_compiled':False,
              'device_boot_tested':False,'static_boot_path_tested':False,'flash_allowed':False}

    def load(path,name):
        m = original_load(path,name)
        if Path(path).resolve() == Path(args.r6_tool).resolve():configure_release_verifier(m)
        return m

    def source(source):
        old = original_apply(source)
        result['R17_DMA'] = r17.apply_cache(source)
        result['R18_IRQ'] = r18.apply_source(source)
        result['R18_handlers'] = r18.audit_handlers(source)
        result['R19_RMNET'] = r19.apply_source(source)
        result['scheduler_source'] = apply_source(source)
        result['release_request'] = request_release(source,Path(source).parent/'candidate-out/.config')
        return dict(old,R17_stock_DMA=result['R17_DMA'],R18_stock_IRQ=result['R18_IRQ'],
                    R19_RMNET=result['R19_RMNET'],R21_scheduler=result['scheduler_source'])

    def config(before,after):
        normalized = normalize_release_config(after)
        filtered = r18.verify_config(before,normalized,r17)
        delta = original_config(before,filtered)
        result['only_new_config_changes_against_R19'] = {
            LOCALVERSION:['"-qgki"',after[LOCALVERSION]],AUTO:['y','n']}
        return dict(delta,CONFIG_GENERIC_IRQ_EFFECTIVE_AFF_MASK=[None,'y'],
                    **result['only_new_config_changes_against_R19'])

    def abi(actual,reference,expected):
        old = original_abi(actual,reference,expected)
        result['R17_abi'] = r17.verify_current_abi(actual,expected)
        result['R18_abi'] = r18.verify_abi(actual,expected)
        result['R19_abi'] = r19.verify_abi(actual,expected)
        result['abi_progress'] = verify_abi(actual,expected)
        return dict(old,R21_progress=result['abi_progress'])

    base.dependency=lambda:r15;r15.dependency=lambda:r14;r14.load=load
    base.apply_source,base.verify_config,base.verify_abi=source,config,abi
    try:
        base.build(args)
        report=json.loads((out/'R16_RESULT.json').read_text())
        require(report['kernel_compiled'] and report['r6_baseline_unchanged'], 'FULL_BUILD_NOT_PROVEN')
        require(report['qgki_counts']==result['abi_progress']['counts']
                and report['fully_matching_modules']==37, 'FULL_MODULE_COHORT_NOT_MATCHING')
        require(report['release']['verified_release']==profile()['expected_release'], 'RELEASE_NOT_REBUILT')
        for n,h in result['scheduler_source']['source_hashes'].items():
            require(sha(out/'candidate-source'/n)==h, 'SCHEDULER_SOURCE_CHANGED_DURING_BUILD:' + n)
        for key in ('R17_DMA','R18_IRQ','R19_RMNET'):
            for n,h in result[key].get('source_hashes',{}).items():
                require(sha(out/'candidate-source'/n)==h,'PREVIOUS_SOURCE_REPAIR_CHANGED:'+n)
        require(sha(out/'candidate-source/arch/arm64/include/asm/cache.h')
                == result['R17_DMA']['header_sha256'], 'STOCK_DMA_ALIGNMENT_SOURCE_CHANGED')
        result.update(status='R21_FULL_ARM64_BUILD_ALL_1423_OEM_CRCS_AND_STOCK_RELEASE_PROVEN_NOFLASH',
                      kernel_compiled=True,all_1423_import_crcs_match=True,
                      qgki_counts=report['qgki_counts'],fully_matching_modules=37,
                      kernel_product_hashes=report['kernel_product_hashes'],release=report['release'],
                      r6_baseline_unchanged=True)
    except Exception as error:
        result.update(status='R21_BUILD_OR_STOCK_ABI_RELEASE_GATE_FAILED_NOFLASH',error=str(error));raise
    finally:
        base.dependency=original_dependency;r15.dependency=original_r15_dep;r14.load=original_load
        base.apply_source,base.verify_config,base.verify_abi=original_apply,original_config,original_abi
        if out.is_dir():(out/'R21_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'],result['qgki_counts'],result['release']['verified_release'],'FLASH=NO')


def main():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='op',required=True)
    s.add_parser('verify-package');s.add_parser('check-source').add_argument('--source',required=True)
    b=s.add_parser('build')
    for n in ('r19-tool','r18-tool','r17-tool','base-tool','source','objout','r6-report','r6-tool','project','output'):
        b.add_argument('--'+n,required=True)
    args=p.parse_args();verify_package()
    if args.op=='build':build(args)
    elif args.op=='check-source':print(json.dumps(check_source(args.source)))
    else:print('R21_FUNCTIONAL_SCHEDULER_AND_CONFIGURED_VENDOR_RELEASE_PACKAGE_VERIFIED; FULL_BUILD_PENDING; FLASH=NO')


if __name__=='__main__':main()
