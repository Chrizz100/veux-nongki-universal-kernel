#!/usr/bin/env python3
"""Package only the freshly rebuilt, completely CRC-matching R21 kernel."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import struct
import tempfile
import urllib.request
import zipfile

ROOT=Path(__file__).resolve().parents[1]
STATUS='R21_FULL_ARM64_BUILD_ALL_1423_OEM_CRCS_AND_STOCK_RELEASE_PROVEN_NOFLASH'


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def load_packager(path):
    p=json.loads((ROOT/'References/PROFILE.json').read_text());path=Path(path).resolve(strict=True)
    require(sha(path)==p['packager_tool_sha256'],'AUTHENTIC_R20_PACKAGER_CHANGED')
    s=importlib.util.spec_from_file_location('r21_proven_r20_packager',path)
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify_package();return m


def verify_build(build):
    build=Path(build).resolve(strict=True);p=json.loads((ROOT/'References/PROFILE.json').read_text())
    r=json.loads((build/'R21_RESULT.json').read_text())
    require(r.get('status')==STATUS and r.get('kernel_compiled') is True
            and r.get('all_1423_import_crcs_match') is True and r.get('r6_baseline_unchanged') is True,
            'FRESH_R21_FULL_BUILD_NOT_PROVEN')
    require(r.get('qgki_counts')=={'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0}
            and r.get('fully_matching_modules')==37,'COMPLETE_OEM_COHORT_REQUIRED')
    expected=json.loads((ROOT/'References/OEM_1423_CRC.json').read_text())
    out=build/'candidate-out';actual={}
    for line in (out/'Module.symvers').read_text().splitlines():
        row=line.split();require(len(row)>=4,'INVALID_SYMVERS')
        require(row[1] not in actual,'DUPLICATE_EXPORT');actual[row[1]]=row[0].lower()
    require(len(expected)==1423 and all(actual.get(n)==crc for n,crc in expected.items()),
            'INDEPENDENT_1423_IMPORT_CRC_CHECK_FAILED')
    require(set(r['kernel_product_hashes'])=={'.config','Module.symvers','arch/arm64/boot/Image','vmlinux'},
            'COMPLETE_KERNEL_PRODUCT_SET_REQUIRED')
    for n,h in r['kernel_product_hashes'].items():require(sha(out/n)==h,'R21_PRODUCT_HASH_CHANGED:'+n)
    image=out/'arch/arm64/boot/Image';data=image.read_bytes()
    require(data[56:60]==b'ARMd','NOT_ARM64_IMAGE')
    elf=(out/'vmlinux').open('rb').read(64)
    require(elf[:6]==b'\x7fELF\x02\x01' and struct.unpack_from('<H',elf,18)[0]==183,'NOT_ARM64_VMLINUX')
    banners=set(x.decode() for x in re.findall(rb'Linux version (5\.[^\s\0]+) ',data))
    require(banners=={p['expected_release']},'ACTUAL_KERNEL_BANNER_NOT_ORIGINAL_RELEASE')
    require((out/'include/config/kernel.release').read_text().strip()==p['expected_release']
            and ('#define UTS_RELEASE "'+p['expected_release']+'"') in (out/'include/generated/utsrelease.h').read_text(),
            'GENERATED_KERNEL_HEADERS_NOT_ORIGINAL_RELEASE')
    require(r['release']['verified_release']==p['expected_release'],'R21_RELEASE_REPORT_DISAGREES')
    for artifact in r['release']['artifacts']:
        n=artifact['file'];require(n in r['kernel_product_hashes'] or n.endswith('.ko'),'RELEASE_ARTIFACT_SCOPE')
        require(sha(out/n)==artifact['sha256'],'REBUILT_RELEASE_ARTIFACT_CHANGED:'+n)
        if n.endswith('.ko'):
            require(('vermagic='+p['expected_release']+' ').encode() in (out/n).read_bytes(),
                    'MODULE_VERMAGIC_NOT_ORIGINAL:'+n)
    return image,r


def download(url,path,expected):
    path=Path(path)
    for attempt in range(3):
        try:
            h=hashlib.sha256()
            with urllib.request.urlopen(url,timeout=60) as response,path.open('wb') as f:
                for b in iter(lambda:response.read(1024*1024),b''):h.update(b);f.write(b)
            require(h.hexdigest()==expected,'REFERENCE_HASH_MISMATCH:'+path.name);return
        except (OSError,TimeoutError):
            if attempt==2:raise


def package(args):
    image,build=verify_build(args.build);m=load_packager(args.packager_tool);p=m.profile()
    work=Path(args.work).resolve();output=Path(args.output).resolve()
    require(not work.exists() and not output.exists(),'PACKAGING_OUTPUT_MUST_BE_NEW')
    work.mkdir(parents=True);output.mkdir(parents=True)
    result={'status':'R21_PACKAGING_PENDING','device_pass':False,'flash_allowed':False}
    try:
        for key,name in [('reference_ak3','reference-AK3.zip'),('reference_boot','reference-boot.img'),('magisk_apk','Magisk.apk')]:
            download(p[key+'_url'],work/name,p[key+'_sha256'])
        mb=work/'magiskboot'
        with zipfile.ZipFile(work/'Magisk.apk') as z:
            names=[n for n in z.namelist() if n.startswith('lib/x86_64/') and 'magiskboot' in n]
            require(len(names)==1,'HOST_MAGISKBOOT_AMBIGUOUS');data=z.read(names[0])
            require(hashlib.sha256(data).hexdigest()==p['host_magiskboot_sha256'],'HOST_MAGISKBOOT_CHANGED')
            mb.write_bytes(data);mb.chmod(0o755)
        boot,boot_proof=m.construct_boot(image.read_bytes(),work/'reference-boot.img',mb,work/'boot-proof')
        ak3=work/'kernel-AK3.zip';ak3_proof=m.construct_ak3(image.read_bytes(),work/'reference-AK3.zip',ak3)
        require(boot_proof['image_sha256']==ak3_proof['image_sha256']==sha(image),'BOOT_AK3_KERNEL_PAIR_MISMATCH')
        # Publish both files together, only after all gates and roundtrips.
        staged=work/'validated-pair';staged.mkdir()
        b=staged/'VEUX_R21_5.4.274_QGKI_NOFLASH_boot.img';a=staged/'VEUX_R21_5.4.274_QGKI_NOFLASH_AK3.zip'
        shutil.copyfile(boot,b);shutil.copyfile(ak3,a)
        require(sha(b)==boot_proof['boot_sha256'] and sha(a)==ak3_proof['ak3_sha256'],'PAIR_DELIVERY_HASH_MISMATCH')
        staged.replace(output/'review')
        result.update(status='R21_STATIC_BOOT_AND_AK3_PAIR_PASS_DEVICE_UNTESTED_NOFLASH',
                      static_boot_path_pass=True,all_1423_import_crcs_match=True,
                      fully_matching_modules=37,kernel_release=build['release']['verified_release'],
                      image_sha256=sha(image),boot=boot_proof,ak3=ak3_proof)
    except Exception as error:
        result.update(status='R21_BOOT_AK3_STATIC_GATE_FAILED_NOFLASH',error=str(error));raise
    finally:
        (output/'R21_PACKAGE_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'],'DEVICE_PASS=NO FLASH=NO')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for n in ('build','packager-tool','work','output'):p.add_argument('--'+n,required=True)
    package(p.parse_args())


if __name__=='__main__':main()
