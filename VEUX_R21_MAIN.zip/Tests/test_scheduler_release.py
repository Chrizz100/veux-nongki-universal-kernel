import importlib.util
import json
import lzma
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r21_tests',ROOT/'Tools/r21_scheduler_release.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


class SchedulerReleaseTests(unittest.TestCase):
    def reference_config(self):
        result={}
        for line in lzma.decompress((ROOT/'References/R19.config.xz').read_bytes()).decode().splitlines():
            m=re.fullmatch(r'(CONFIG_\w+)=(.*)',line);n=re.fullmatch(r'# (CONFIG_\w+) is not set',line)
            if m or n:result[m[1] if m else n[1]]=m[2] if m else 'n'
        return result

    def new_config(self):
        value=self.reference_config();value[r.LOCALVERSION]='"-qgki-g82179e362f33"';value[r.AUTO]='n';return value

    def test_only_two_release_keys_can_change(self):
        self.assertEqual(r.normalize_release_config(self.new_config()),self.reference_config())
        for key,value in [('CONFIG_SCHED_WALT','n'),('CONFIG_CFI_CLANG','n'),
                          ('CONFIG_LTO','n'),('CONFIG_GENERIC_IRQ_EFFECTIVE_AFF_MASK','n')]:
            cfg=self.new_config();cfg[key]=value
            with self.assertRaisesRegex(ValueError,'OUTSIDE_TWO_RELEASE_KEYS'):r.normalize_release_config(cfg)

    def test_short_or_auto_generated_release_is_rejected(self):
        for key,value in [(r.LOCALVERSION,'"-qgki"'),(r.AUTO,'y')]:
            cfg=self.new_config();cfg[key]=value
            with self.assertRaisesRegex(ValueError,'RELEASE_CONFIG_NOT_REQUESTED'):r.normalize_release_config(cfg)

    def test_all_1423_real_import_crcs_are_mandatory(self):
        expected=json.loads((ROOT/'References/OEM_1423_CRC.json').read_text())
        self.assertEqual(r.verify_abi(dict(expected),expected)['counts'],
                         {'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0})
        for n in r.profile()['required_scheduler_crcs']:
            actual=dict(expected);actual[n]='0x00000000'
            with self.assertRaisesRegex(ValueError,'1423_ORIGINAL_IMPORTS'):r.verify_abi(actual,expected)

    def test_a_previous_match_loss_or_missing_import_cannot_pass(self):
        expected=json.loads((ROOT/'References/OEM_1423_CRC.json').read_text())
        for missing in [True,False]:
            actual=dict(expected);n=r.profile()['previous_matches'][0]
            if missing:del actual[n]
            else:actual[n]='0x00000000'
            with self.assertRaisesRegex(ValueError,'1423_ORIGINAL_IMPORTS'):r.verify_abi(actual,expected)

    def original_r6(self):
        p=ROOT/'References/ORIGINAL_R6_VERIFIER.py';s=importlib.util.spec_from_file_location('r21_original_r6',p)
        m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

    def test_kernel_setlocalversion_produces_the_original_label_from_config(self):
        m=self.original_r6()
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'src';out=root/'out';(source/'scripts').mkdir(parents=True)
            (out/'include/config').mkdir(parents=True)
            shutil.copyfile(ROOT/'References/scripts_config',source/'scripts/config')
            script=(ROOT/'References/scripts_setlocalversion').read_bytes()
            self.assertEqual(script.count(m.SETLOCALVERSION_OLD),1)
            (source/'scripts/setlocalversion').write_bytes(script.replace(m.SETLOCALVERSION_OLD,m.SETLOCALVERSION_NEW,1))
            (source/'localversion').write_bytes(b'');cfg=out/'.config'
            cfg.write_bytes(lzma.decompress((ROOT/'References/R19.config.xz').read_bytes()))
            result=r.request_release(source,cfg)
            self.assertFalse(result['defconfig_modified']);self.assertFalse(result['binary_patched'])
            (out/'include/config/auto.conf').write_text('\n'.join(x for x in cfg.read_text().splitlines() if x.startswith('CONFIG_'))+'\n')
            env=dict(os.environ,KERNELVERSION='5.4.274');env.pop('LOCALVERSION',None)
            p=subprocess.run(['bash',str(source/'scripts/setlocalversion'),str(source)],cwd=out,env=env,text=True,capture_output=True)
            self.assertEqual(p.returncode,0,p.stderr)
            self.assertEqual('5.4.274'+p.stdout.strip(),r.profile()['expected_release'])

    def release_fixture(self,root,module):
        release=r.profile()['expected_release']
        for n in ['include/config/kernel.release','include/generated/utsrelease.h',
                  'arch/arm64/boot/Image','vmlinux',*sorted(module.OTHER_MODULE_PATHS)]:
            p=root/n;p.parent.mkdir(parents=True,exist_ok=True)
            if n.endswith('kernel.release'):p.write_text(release+'\n')
            elif n.endswith('utsrelease.h'):p.write_text('#define UTS_RELEASE "'+release+'"\n')
            elif n.endswith('.ko'):p.write_bytes(('fixture\0vermagic='+release+' SMP preempt mod_unload modversions aarch64\0').encode())
            else:p.write_bytes(('fixture Linux version '+release+' \0').encode())

    def test_existing_verifier_checks_both_kernel_binaries_and_all_four_modules(self):
        m=r.configure_release_verifier(self.original_r6())
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.release_fixture(root,m);result=m.verify_generated_release(root)
            self.assertEqual(result['verified_release'],r.profile()['expected_release'])
            self.assertEqual(len(result['artifacts']),6)
            self.assertFalse(result['binary_identity_edited']);self.assertFalse(result['original_stock_source_commit_claimed'])
            self.assertNotIn('no_stock_git_id_spoof',result)
            n=sorted(m.OTHER_MODULE_PATHS)[0];(root/n).write_bytes(b'vermagic=5.4.274-qgki SMP\0')
            with self.assertRaises(Exception):m.verify_generated_release(root)

    def test_generated_header_cannot_disagree_with_rebuilt_binaries(self):
        m=r.configure_release_verifier(self.original_r6())
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);self.release_fixture(root,m)
            (root/'include/generated/utsrelease.h').write_text('#define UTS_RELEASE "5.4.274-qgki"\n')
            with self.assertRaises(Exception):m.verify_generated_release(root)

    def test_native_walt_domain_state_and_parent_propagation(self):
        prefix=r'''
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#define CONFIG_SCHED_WALT 1
#define SG_OVERUTILIZED 2
#define SG_HAS_MISFIT_TASK 4
#define SD_ASYM_CPUCAPACITY 8
struct sched_domain_shared { bool overutilized; };
struct sched_domain { struct sched_domain_shared *shared; struct sched_domain *parent; int flags; };
struct rq { struct sched_domain *sd; int cpu; };
struct lb_env { struct sched_domain *sd; };
struct sd_lb_stats { unsigned long total_capacity,total_util; int local; };
static unsigned long sched_capacity_margin_up[2]={1024,1024};
static bool busy[2];
static int lock_depth;
static void rcu_read_lock(void) { lock_depth++; }
static void rcu_read_unlock(void) { lock_depth--; }
#define rcu_dereference(x) (x)
static bool cpu_overutilized(int cpu) { return busy[cpu]; }
static int group_first_cpu(int group) { return group; }
'''
        suffix=r'''
int main(void) {
 struct sched_domain_shared a={0},b={0},c={0};
 struct sched_domain root={&c,NULL,SD_ASYM_CPUCAPACITY},mid={&b,&root,0},leaf={&a,&mid,0};
 struct rq rq={&leaf,0};struct lb_env env={&leaf};struct sd_lb_stats stats={100,0,0};
 update_overutilized_status(&rq);assert(!a.overutilized && lock_depth==0);
 busy[0]=true;update_overutilized_status(&rq);assert(a.overutilized && !b.overutilized && lock_depth==0);
 rq.sd=NULL;update_overutilized_status(&rq);assert(lock_depth==0);
 propagate(&env,&stats,0);assert(!sd_overutilized(&leaf));
 propagate(&env,&stats,SG_OVERUTILIZED);assert(sd_overutilized(&leaf) && !sd_overutilized(&mid));
 propagate(&env,&stats,SG_HAS_MISFIT_TASK);assert(!a.overutilized && !b.overutilized && c.overutilized);
 c.overutilized=false;stats.total_util=200;propagate(&env,&stats,0);assert(b.overutilized && !c.overutilized);
 clear_sd_overutilized(&mid);stats.total_util=0;leaf.parent=NULL;propagate(&env,&stats,SG_HAS_MISFIT_TASK);
 assert(!a.overutilized && !b.overutilized && lock_depth==0);
 return 0;
}
'''
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'domain.c';path.write_text(prefix+(ROOT/'References/NATIVE_DOMAIN_FUNCTIONS.c').read_text()+suffix)
            exe=path.with_suffix('');p=subprocess.run(['cc','-std=c11','-O1','-Wall','-Wextra','-Werror',
                '-fsanitize=address,undefined','-fno-omit-frame-pointer',str(path),'-o',str(exe)],text=True,capture_output=True)
            self.assertEqual(p.returncode,0,p.stderr)
            p=subprocess.run([str(exe)],text=True,capture_output=True,
                             env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
            self.assertEqual(p.returncode,0,p.stderr)

    def packager(self):
        s=importlib.util.spec_from_file_location('r21_pack_tests',ROOT/'Tools/r21_package.py')
        m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

    def test_a_previous_green_build_cannot_be_packaged_as_repaired_r21(self):
        m=self.packager()
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'R21_RESULT.json').write_text(json.dumps({'status':'R19_FULL_ARM64_BUILD_AND_RMNET_VENDOR_API_PROGRESS_PROVEN_NOFLASH','kernel_compiled':True}))
            with self.assertRaisesRegex(ValueError,'FRESH_R21_FULL_BUILD_NOT_PROVEN'):m.verify_build(p)

    def test_a_false_zero_error_report_cannot_bypass_the_measured_r19_crcs(self):
        m=self.packager();expected=json.loads((ROOT/'References/OEM_1423_CRC.json').read_text())
        actual=dict(expected)
        # The three real CRCs measured in run 43471009003, before this repair.
        actual.update(set_cpus_allowed_ptr='0x7110d634',set_user_nice='0x63e242d9',wake_up_process='0xfa330e74')
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'candidate-out').mkdir()
            (p/'candidate-out/Module.symvers').write_text(''.join(crc+'\t'+n+'\tvmlinux\tEXPORT_SYMBOL\n' for n,crc in actual.items()))
            report={'status':m.STATUS,'kernel_compiled':True,'all_1423_import_crcs_match':True,
                    'r6_baseline_unchanged':True,'fully_matching_modules':37,
                    'qgki_counts':{'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0}}
            (p/'R21_RESULT.json').write_text(json.dumps(report))
            with self.assertRaisesRegex(ValueError,'INDEPENDENT_1423_IMPORT_CRC_CHECK_FAILED'):m.verify_build(p)


if __name__=='__main__':unittest.main()
