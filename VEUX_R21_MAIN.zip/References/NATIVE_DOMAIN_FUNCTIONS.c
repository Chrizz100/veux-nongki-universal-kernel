static bool sd_overutilized(struct sched_domain *sd)
{
	return sd->shared->overutilized;
}

static void set_sd_overutilized(struct sched_domain *sd)
{
	sd->shared->overutilized = true;
}

static void clear_sd_overutilized(struct sched_domain *sd)
{
	sd->shared->overutilized = false;
}

static inline void update_overutilized_status(struct rq *rq)
{
#ifdef CONFIG_SCHED_WALT
	struct sched_domain *sd;

	rcu_read_lock();
	sd = rcu_dereference(rq->sd);
	if (sd && !sd_overutilized(sd) && cpu_overutilized(rq->cpu))
		set_sd_overutilized(sd);
	rcu_read_unlock();
#else
	if (!READ_ONCE(rq->rd->overutilized) && cpu_overutilized(rq->cpu)) {
		WRITE_ONCE(rq->rd->overutilized, SG_OVERUTILIZED);
		trace_sched_overutilized_tp(rq->rd, SG_OVERUTILIZED);
	}
#endif
}

static void propagate(struct lb_env *env, struct sd_lb_stats *sds, int sg_status)
{
#ifdef CONFIG_SCHED_WALT
	if (sg_status & SG_OVERUTILIZED)
		set_sd_overutilized(env->sd);
	else
		clear_sd_overutilized(env->sd);

	/* A misfit task needs a parent domain with unequal CPU capacities. */
	if (sg_status & SG_HAS_MISFIT_TASK) {
		struct sched_domain *sd = env->sd->parent;

		while (sd) {
			if (sd->flags & SD_ASYM_CPUCAPACITY) {
				set_sd_overutilized(sd);
				break;
			}
			sd = sd->parent;
		}
	}

	/* A domain above its capacity also needs balancing at its parent. */
	if (env->sd->parent &&
	    sds->total_capacity * 1024 < sds->total_util *
			 sched_capacity_margin_up[group_first_cpu(sds->local)])
		set_sd_overutilized(env->sd->parent);
#endif
}
