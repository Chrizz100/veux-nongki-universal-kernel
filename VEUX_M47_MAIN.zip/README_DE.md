# VEUX M47 · Stock-Verity · NOFLASH

M46 aus Lauf 44901355794 hat den fehlenden Android-Verified-Boot-Fehlerpfad des M44-Kandidaten bestätigt. Stock und Kandidat verwenden die Kennung `5.4.274-qgki-g82179e362f33`. Den vollständigen M46-Befund enthält M46_ERGEBNIS.json. Der Gerätecheck auf dem laufenden Stock-System meldet Slot A und den DTBO-Index 0. Der beim Verity-Fehler anzusprechende Datenträger ist dort unbekannt.

## Auf GitHub ausführen

1. VEUX_M47_MAIN.zip im Stamm des Repositorys ablegen.
2. VEUX_M47_VERITY_NOFLASH.yml unter .github/workflows/ ablegen.
3. In Actions den Workflow **VEUX M47 Stock-Verity (NOFLASH)** manuell starten.

Der Job prüft die SHA-256-Werte seiner Eingaben. Er verwendet die GitHub-Artefakte 14699092267 (M44) und 14706022228 (M46). Für einen lokalen Lauf können identische Originalarchive mit `--m44` und `--m46` angegeben werden. Auf dem Linux-x86_64-Buildhost werden Python 3.9 oder neuer, git, make, cc, GCC-Header, nm, readelf und der per SHA-256 geprüfte Android-Clang r416183b benötigt. Der Workflow lädt den Compiler automatisch.

## Was der Patch ändert

M47 ergänzt die Option CONFIG_DM_VERITY_AVB, ihre Kbuild-Einbindung und den Aufruf vor dem Neustart bei einem dm-verity-Integritätsfehler im Modus RESTART. Die beiden Bootloaderparameter, die AVB-Kennungen und die Auswahl des Zielgeräts folgen dem Xiaomi-Quellstand. Bei unbekanntem Ziel endet der Handler. Das Konfigurationsfragment enthält ausschließlich CONFIG_DM_VERITY_AVB=y.

Der Linux-5.4-Port weicht beim Blockzugriff bewusst von der Xiaomi-Implementierung ab. Er bearbeitet einen logischen Block, prüft I/O-Fehler und hält die Ressourcen bis zum Ende jedes eingereichten Zugriffs. Ein separater Worker begrenzt die Wartezeit des Neustartpfads auf insgesamt sechs Sekunden. Im OEM-Quellstand gilt ein Zeitlimit von zwei Sekunden pro Transfer. Ein bereits eingereichter Zugriff kann nach Ablauf des Zeitlimits abschließen. Ob die Firmware den erwarteten Zielparameter liefert und wie der Speicher auf dem Gerät im Fehlerfall reagiert, ist offen.

## Was der Job prüft

- Der Patch lässt sich auf den mitgelieferten, per SHA-256 geprüften Stand der betroffenen Kernelquellen anwenden.
- Der Prüfer liest die M44-Konfiguration, die generierten Header und die Symboltabelle aus dem Originalartefakt. GNU make bestimmt die dm-verity-Komponenten aus der gepatchten Kernel-Makefile mit und ohne M47-Option.
- Android-Clang baut beide Treibervarianten mit ThinLTO und CFI für ARM64. Nach dem Linken prüft das Skript den Aufruf des AVB-Handlers und gleicht die externen Symbole namentlich mit der M44-System.map ab.
- 90 RAM-Testfälle prüfen Parameter, AVB-Kopf und -Footer, Blockgrößen, Schreibumfang, Zeitüberschreitungen, Fehler und Freigabe der Ressourcen. Datenträger und verzögerter Worker sind simuliert.

Das erzeugte GitHub-Artefakt enthält M47_RESULT.json und ein relocatierbares ARM64-Treiberobjekt zur Prüfung. Die vollständige Integration in vmlinux und boot.img, der erneute Vendor-ABI-Abgleich, die statische AK3-Prüfung, der Start auf Hardware und die unabhängige Wiederherstellung ohne PC stehen aus. Der Job setzt flash_allowed auf false.

## Quellen

Kernelbasis für den betroffenen Quellbereich: dereference23/kernel_xiaomi_sm6375, Commit b2b7a3bbc36d120ee523ebc8d68e0f13a97df632.
https://github.com/dereference23/kernel_xiaomi_sm6375/tree/b2b7a3bbc36d120ee523ebc8d68e0f13a97df632/drivers/md

Xiaomi-Referenz: MiCode/Xiaomi_Kernel_OpenSource, Commit 61397e524093d1ccb94769b5460825e2eaf8871e.
https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/md/dm-verity-avb.c

M46-Geräte- und Stockabgleich:
https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/44901355794/job/136837753041
