/* Userspace test for the actual M47 C functions. Storage is a byte array. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

typedef uint64_t sector_t;
typedef unsigned int fmode_t;
enum {
    PAGE_SIZE = 4096,
    SECTOR_SHIFT = 9,
    GFP_NOIO = 0,
    FMODE_READ = 1,
    FMODE_WRITE = 2,
    FMODE_EXCL = 4,
    REQ_OP_READ = 0,
    REQ_OP_WRITE = 1,
    REQ_FUA = 2
};
struct block_device {
    loff_t *bd_inode;
};
struct page {
    unsigned char bytes[PAGE_SIZE];
};
struct bio {
    struct {
        sector_t bi_sector;
    } bi_iter;
    struct page *page;
    unsigned int len, op, flags;
};
#define DMINFO(...) ((void)0)
#define DMERR(...) ((void)0)
#define IS_ERR(ptr) ((ptr) == NULL)
#define PTR_ERR(ptr) (-EACCES)
#define i_size_read(p) (*(p))
#define is_power_of_2(x) ((x) && !((x) & ((x) - 1)))
#define page_address(p) ((p)->bytes)

static unsigned char storage[4 * PAGE_SIZE], original[sizeof(storage)];
static struct page pg;
static struct bio request;
static loff_t media_size;
static struct block_device device = {&media_size};
static unsigned int logical, opens, held, live_page, live_bio, transfers,
    writes, cases;
enum failure {
    OK,
    OPEN,
    PAGE_ALLOC,
    BIO_ALLOC,
    ADD_PARTIAL,
    READ_FIRST,
    READ_LAST,
    WRITE_FAIL
};
static enum failure failure;
static unsigned long jiffies;
static bool expire_after_read, delay_worker, fail_request_alloc;
static unsigned int outstanding;
static struct work_struct *queued;
struct work_struct {
    void (*run)(struct work_struct *);
};
struct completion {
    bool done;
};
typedef unsigned int refcount_t;
#define container_of(ptr, type, member)                                        \
    ((type *)((char *)(ptr) - offsetof(type, member)))
#define INIT_WORK(w, fn) ((w)->run = (fn))
#define system_unbound_wq NULL
#define time_after_eq(a, b) ((long)((a) - (b)) >= 0)
#define msecs_to_jiffies(ms) (ms)
static void *kzalloc(size_t n, int flags)
{
    assert(flags == GFP_NOIO);
    if (fail_request_alloc)
        return NULL;
    void *p = calloc(1, n);
    assert(p);
    outstanding++;
    return p;
}
static void kfree(void *p)
{
    assert(outstanding);
    outstanding--;
    free(p);
}
static void refcount_set(refcount_t *ref, unsigned int n) { *ref = n; }
static bool refcount_dec_and_test(refcount_t *ref)
{
    assert(*ref);
    return --*ref == 0;
}
static void init_completion(struct completion *c) { c->done = false; }
static void complete(struct completion *c) { c->done = true; }
static void queue_work(void *queue, struct work_struct *w)
{
    (void)queue;
    if (delay_worker) {
        assert(!queued);
        queued = w;
    } else
        w->run(w);
}
static unsigned long wait_for_completion_timeout(struct completion *c,
                                                 unsigned long t)
{
    if (c->done)
        return 1;
    jiffies += t;
    return 0;
}

static dev_t name_to_dev_t(const char *name)
{
    return !strcmp(name, "mock-selected");
}
static struct block_device *blkdev_get_by_dev(dev_t number, fmode_t mode,
                                              void *holder)
{
    assert(number == 1 && !held &&
           mode == (FMODE_READ | FMODE_WRITE | FMODE_EXCL) && holder);
    opens++;
    if (failure == OPEN)
        return NULL;
    held = 1;
    return &device;
}
static void blkdev_put(struct block_device *d, fmode_t mode)
{
    assert(d == &device && mode == (FMODE_READ | FMODE_WRITE | FMODE_EXCL) &&
           held && !live_page && !live_bio);
    held = 0;
}
static unsigned int bdev_logical_block_size(struct block_device *d)
{
    assert(d == &device);
    return logical;
}
static struct page *alloc_page(int g)
{
    (void)g;
    assert(!live_page && held);
    if (failure == PAGE_ALLOC)
        return NULL;
    live_page = 1;
    return &pg;
}
static void __free_page(struct page *p)
{
    assert(p == &pg && live_page && !live_bio);
    live_page = 0;
}
static struct bio *bio_alloc(int g, int n)
{
    (void)g;
    assert(!live_bio && n == 1 && live_page);
    if (failure == BIO_ALLOC)
        return NULL;
    memset(&request, 0, sizeof(request));
    live_bio = 1;
    return &request;
}
static void bio_put(struct bio *b)
{
    assert(b == &request && live_bio);
    live_bio = 0;
}
static void bio_set_dev(struct bio *b, struct block_device *d)
{
    assert(d == &device && b == &request && held);
}
static void bio_set_op_attrs(struct bio *b, int op, int flags)
{
    b->op = op;
    b->flags = flags;
}
static unsigned int bio_add_page(struct bio *b, struct page *p, unsigned int n,
                                 int off)
{
    assert(off == 0 && n == logical && n <= PAGE_SIZE && p == &pg);
    b->page = p;
    b->len = n;
    return failure == ADD_PARTIAL ? n / 2 : n;
}
static int submit_bio_wait(struct bio *b)
{
    size_t offset = b->bi_iter.bi_sector * 512;
    assert(live_bio && live_page && held && offset % logical == 0 &&
           offset + b->len <= (size_t)media_size);
    transfers++;
    if (b->op == REQ_OP_READ) {
        if ((failure == READ_FIRST && !offset) ||
            (failure == READ_LAST && offset))
            return -EIO;
        memcpy(b->page->bytes, storage + offset, b->len);
        if (expire_after_read)
            jiffies += 6000;
    } else {
        assert(b->op == REQ_OP_WRITE && b->flags == REQ_FUA);
        if (failure == WRITE_FAIL)
            return -EIO;
        writes++;
        memcpy(storage + offset, b->page->bytes, b->len);
    }
    return 0;
}
#include "handler-under-test.inc"

static void reset(unsigned int bs, loff_t bytes, int off, const char *magic)
{
    assert(!live_page && !live_bio && !held);
    assert(!outstanding && !queued);
    jiffies = 0;
    fail_request_alloc = expire_after_read = delay_worker = false;
    logical = bs;
    media_size = bytes;
    failure = OK;
    opens = transfers = writes = 0;
    cases++;
    for (size_t i = 0; i < sizeof(storage); i++)
        storage[i] = (unsigned char)(i * 17 + 5);
    if (off >= 0)
        memcpy(storage + off, magic, 4);
    memcpy(original, storage, sizeof(storage));
}
static void expect(int offset)
{
    if (offset >= 0)
        memcpy(original + offset, "AVE0", 4);
    assert(writes == (offset >= 0) &&
           !memcmp(original, storage, sizeof(storage)));
    assert(!live_page && !live_bio && !held);
}
int main(void)
{
    for (unsigned int bs = 512; bs <= PAGE_SIZE; bs *= 2) {
        for (int blocks = 1; blocks <= 3; blocks += 2) {
            int bytes = (int)bs * blocks;
            for (int mode = 0; mode < 3; mode++) {
                int off = mode == 0 ? 0 : bytes - 64;
                reset(bs, bytes, mode == 2 ? -1 : off,
                      mode == 0 ? "AVB0" : "AVBf");
                assert(invalidate_vbmeta(1, AVB_TIMEOUT_MS) ==
                       (mode == 2 ? -EINVAL : 0));
                expect(mode == 2 ? -1 : off);
            }
            for (int f = OPEN; f <= WRITE_FAIL; f++) {
                if (f == READ_LAST && blocks == 1)
                    continue;
                reset(bs, bytes, bytes - 64, "AVBf");
                failure = f;
                assert(invalidate_vbmeta(1, AVB_TIMEOUT_MS) < 0);
                expect(-1);
            }
        }
    }
    unsigned int sizes[] = {0, 64, 513, 8192};
    for (size_t i = 0; i < sizeof(sizes) / sizeof(*sizes); i++) {
        reset(sizes[i], sizeof(storage), 0, "AVB0");
        assert(invalidate_vbmeta(1, AVB_TIMEOUT_MS) == -EINVAL &&
               transfers == 0);
        expect(-1);
    }
    reset(4096, 0, -1, "");
    assert(invalidate_vbmeta(1, AVB_TIMEOUT_MS) == -EINVAL);
    expect(-1);
    reset(4096, 4097, -1, "");
    assert(invalidate_vbmeta(1, AVB_TIMEOUT_MS) == -EINVAL);
    expect(-1);
    const char *flags[] = {"", "no", "yes", "yes", "yes"};
    const char *targets[] = {"mock-selected", "mock-selected", "", "missing",
                             "mock-selected"};
    for (size_t i = 0; i < 5; i++) {
        reset(4096, 8192, 0, "AVB0");
        strcpy(avb_invalidate_on_error, flags[i]);
        strcpy(avb_vbmeta_device, targets[i]);
        dm_verity_avb_error_handler();
        assert(opens == (i == 4));
        expect(i == 4 ? 0 : -1);
    }
    reset(4096, 8192, 0, "AVB0");
    fail_request_alloc = true;
    assert(avb_invalidate_with_timeout(1) == -ENOMEM && opens == 0 &&
           !outstanding);
    expect(-1);
    reset(4096, 8192, 0, "AVB0");
    delay_worker = true;
    assert(avb_invalidate_with_timeout(1) == -ETIMEDOUT && opens == 0 &&
           outstanding == 1 && queued);
    struct work_struct *late = queued;
    queued = NULL;
    late->run(late);
    assert(!outstanding && opens == 0);
    expect(-1);
    reset(4096, 8192, 0, "AVB0");
    expire_after_read = true;
    assert(avb_invalidate_with_timeout(1) == -ETIMEDOUT && !outstanding &&
           transfers == 1);
    expect(-1);
    printf("%u mock cases passed\n", cases);
    return 0;
}
