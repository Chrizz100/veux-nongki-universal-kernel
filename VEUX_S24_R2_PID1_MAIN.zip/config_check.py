import re

def values(raw):
    mapping={}
    for line in raw.decode().splitlines():
        m=re.fullmatch(r"(?:# )?(CONFIG_\w+)(?:=(.*)| is not set)",line)
        if m: mapping[m[1]]=m[2] if m[2] is not None else "n"
    return mapping

def validate(base,actual,final=True):
    baseline=values(base); candidate=values(actual)
    delta={k:[baseline.get(k),candidate.get(k)] for k in sorted(baseline.keys()|candidate.keys()) if baseline.get(k)!=candidate.get(k)}
    if any(not (k=="CONFIG_NOMOUNT" or k=="CONFIG_KSU" or k.startswith("CONFIG_KSU_")) for k in delta):
        raise ValueError("Unexpected R11 configuration change: "+str(delta))
    for key in ("CONFIG_KSU","CONFIG_KSU_SUSFS"):
        if candidate.get(key)!="y": raise ValueError(key)
    if (candidate.get("CONFIG_NOMOUNT")=="y")!=final: raise ValueError("NoMount build phase")
    if candidate["CONFIG_SECURITY_SELINUX"]!="y" or candidate["CONFIG_MODULES"]!="y":
        raise ValueError("Stock config requirements")
    return delta
