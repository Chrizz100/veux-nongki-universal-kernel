"""Test the actual VEUX PID1 filename handoff with in-memory VFS fixtures."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

def body(text, signature):
    start=text.index(signature)
    pos=text.index("{",start)
    depth=1
    for i in range(pos+1,len(text)):
        if text[i]=="{": depth+=1
        if text[i]=="}":
            depth-=1
            if depth==0: return text[start:i+1]
    raise ValueError(signature)

prefix=r"""
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#define INIT_PATH "/system/bin/init"
#define AT_FDCWD (-100)
#define AT_EMPTY_PATH 0x1000
#define O_CLOEXEC 1
#define LOOKUP_FOLLOW 1
#define CONFIG_KSU_SUSFS 1
#define likely(x) (!!(x))
#define unlikely(x) (!!(x))
#define IS_ERR(x) ((uintptr_t)(x) >= (uintptr_t)-4095)
#define PTR_ERR(x) ((long)(intptr_t)(x))
#define READ_ONCE(x) (x)
#define xchg(ptr,val) __atomic_exchange_n((ptr),(val),__ATOMIC_SEQ_CST)
#define static_branch_likely(p) (*(p))
#define static_branch_unlikely(p) (*(p))
#define pr_info(...) ((void)0)
#define pr_err(...) ((void)0)
struct file { int dummy; };
struct path { int dummy; };
struct user_arg_ptr { int dummy; };
struct filename { const char *name; int puts; };
struct task { int pid; } task, *current=&task;
static struct file blob,*ksu_preinit_file;
static struct filename original,temporary;
static char original_bytes[128],temporary_bytes[128],expected_fd[32],observed[2][128];
static int fd_value,fd_is_open,fs_error,alloc_error,helper_error,fatal_pending,attempts,original_changed,close_error;
static struct filename *passed[2];
static int ksu_su_compat_enabled=1,susfs_is_sdcard_android_data_not_decrypted;
static int is_selinux_setup(struct user_arg_ptr *p){return 1;}
static int get_unused_fd_flags(int flags){return fd_value;}
static void fput(struct file *f){}
static void fd_install(int fd,struct file *f){fd_is_open=1;}
static int kern_path(const char *name,int flags,struct path *path){return fs_error;}
static void path_put(struct path *path){}
static int ksu_close_fd(int fd){if(fd!=fd_value||!fd_is_open)close_error=1;fd_is_open=0;return 0;}
static struct filename *getname_kernel(const char *name){
 if(alloc_error)return (struct filename *)(intptr_t)-ENOMEM;
 snprintf(temporary_bytes,sizeof(temporary_bytes),"%s",name); temporary.name=temporary_bytes; return &temporary;
}
static void putname(struct filename *name){name->puts++;}
static int fatal_signal_pending(struct task *t){return fatal_pending;}
static int susfs_is_current_proc_no_su(void){return 0;}
static int ksu_handle_execveat(int *fd,struct filename **f,void*a,void*b,int*flags){return -EINVAL;}
#define ksu_handle_execveat_sucompat ksu_handle_execveat
static int ksu_handle_post_execveat_sucompat(int *fd,struct filename **f,void*a,void*b,int*flags,int*ret){return 0;}
static int __do_execve_file(int fd,struct filename *f,struct user_arg_ptr av,struct user_arg_ptr env,int flags,struct file *file){
 if(attempts>=2)abort();
 if(strcmp(original.name,INIT_PATH))original_changed=1;
 passed[attempts]=f;
 snprintf(observed[attempts],sizeof(observed[attempts]),"%s",f->name); attempts++;
 if(!strcmp(f->name,INIT_PATH))return 0;
 if(strcmp(f->name,expected_fd))return -ENOENT;
 if(helper_error)return -ENOEXEC;
 fd_is_open=0; /* A successful exec consumes O_CLOEXEC. */
 return 0;
}
"""
suffix=r"""
int main(int argc,char **argv){
 if(argc!=3)return 2;
 const char *mode=argv[1];
 fd_value=atoi(argv[2]);
 int init_only=!strcmp(mode,"not-pid1")||!strcmp(mode,"missing-proc")||!strcmp(mode,"enomem")||!strcmp(mode,"no-fd");
 task.pid=!strcmp(mode,"not-pid1")?2:1; fs_error=!strcmp(mode,"missing-proc");
 alloc_error=!strcmp(mode,"enomem"); fatal_pending=!strcmp(mode,"fatal");
 helper_error=fatal_pending||!strcmp(mode,"fallback");
 if(!strcmp(mode,"no-fd"))fd_value=-EMFILE;
 ksu_preinit_file=&blob;
 memset(original_bytes,'x',sizeof(original_bytes)); original_bytes[sizeof(original_bytes)-1]=0;
 memcpy(original_bytes,INIT_PATH,sizeof(INIT_PATH)); original.name=original_bytes;
 snprintf(expected_fd,sizeof(expected_fd),"/proc/self/fd/%d",fd_value);
 struct user_arg_ptr a={0};
 int ret=do_execveat_common(AT_FDCWD,&original,a,a,0);
 const int fallback=!strcmp(mode,"fallback");
 const int want_attempts=1+fallback;
 const char *want=init_only?INIT_PATH:expected_fd;
 int correct_calls=attempts==want_attempts && !strcmp(observed[0],want) &&
                  (!fallback || (passed[1]==&original && !strcmp(observed[1],INIT_PATH)));
 int correct_owner=original.puts==1 && temporary.puts==!init_only && !original_changed && !strcmp(original.name,INIT_PATH);
 int okay=correct_calls && correct_owner && !fd_is_open && !close_error && ret==(fatal_pending?-ENOEXEC:0);
 printf("%d %d %d %d %d %d\n",okay,correct_calls,correct_owner,attempts,ret,!strcmp(observed[0],want));
 return 0;
}
"""
def check(src):
    driver=(src/"KernelSU/kernel/preinit/preinit.c").read_text()
    core=(src/"fs/exec.c").read_text()
    functions=[body(driver,"int ksu_setup_preinit_file("),body(driver,"int ksu_preinit_handle_post_execveat("),body(core,"static int do_execveat_common(int fd,")]
    cases=[("normal",d) for d in (0,9,10,99,100,999,1024,1000000)]
    cases += [(m,d) for m in ("fallback","fatal","enomem","missing-proc","not-pid1","no-fd") for d in (0,100)]
    results=[]
    with tempfile.TemporaryDirectory() as d:
        d=Path(d); c=d/"fixture.c"; b=d/"fixture"
        c.write_text(prefix+"\n"+"\n".join(functions)+"\n"+suffix)
        subprocess.run(["cc","-std=gnu11","-O2","-Werror=implicit-function-declaration",str(c),"-o",str(b)],check=True)
        for mode,fd in cases:
            fields=list(map(int,subprocess.check_output([str(b),mode,str(fd)],text=True).split()))
            ok,calls,owner,n,ret,valid=fields
            results.append(dict(mode=mode,descriptor=fd,passed=bool(ok),expected_exec_calls=bool(calls),ownership_and_original_name=bool(owner),attempts=n,return_value=ret,first_exec_path_exact=bool(valid)))
    return dict(total=len(results),passed=sum(r["passed"] for r in results),cases=results)
if __name__=="__main__":
    cli=argparse.ArgumentParser(description=__doc__)
    cli.add_argument("source",type=Path);cli.add_argument("evidence",type=Path);cli.add_argument("--baseline",action="store_true")
    args=cli.parse_args()
    result=check(args.source)
    args.evidence.write_text(json.dumps(result,indent=2)+"\n")
    print(f"{result['passed']}/{result['total']} PID1 path/ownership cases")
    if not args.baseline and result["passed"]!=result["total"]: raise SystemExit(1)
