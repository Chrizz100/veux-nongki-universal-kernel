"""Report whether this CI run exactly reproduces the locally inspected kernel or its executable sections."""
from pathlib import Path
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parent
LOCAL="3f98cb06e93b75c6e50dabfc0eff66c9b9676955cc8c1e6c866428eb0b7b3ef2"
def check(image,evidence):
    with image.open("rb") as src: current=hashlib.file_digest(src,"sha256").hexdigest()
    local=json.loads((ROOT/"referenz/S24-LLDB-sections.json").read_text())
    observed=json.loads((evidence/"S24-LLDB-sections.json").read_text())
    if local.keys()!=observed.keys(): raise ValueError("Unexpected ELF section inventory")
    same={n:x["sha256"]==observed[n]["sha256"] for n,x in local.items()}
    info=dict(current_image_sha256=current,local_control_sha256=LOCAL,image_identical=current==LOCAL,
              section_content_identical=same,device_pass=False)
    (evidence/"Vergleich-lokaler-Bau.json").write_text(json.dumps(info,indent=2)+"\n")
    if not all(same.values()):
        print("Executable bytes differ from the local control. See the per-section hashes and run a fresh binary comparison.")
    return info
if __name__=="__main__": check(*(Path(x) for x in sys.argv[1:]))
