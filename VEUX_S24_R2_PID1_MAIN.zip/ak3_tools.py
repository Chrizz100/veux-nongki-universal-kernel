"""Recover the stock-repack toolkit byte-for-byte from the pinned public R11 build kit."""
import hashlib
import io
from pathlib import Path
import urllib.request
import zipfile

KIT=Path(__file__).resolve().parent
R11="https://raw.githubusercontent.com/Chrizz100/veux-nongki-universal-kernel/697ceef6ca7626e98a6e5569acd5daaba7a22ffd/VEUX_M63_R11_MAIN.zip"
def load():
    dest=KIT/"oem/ak3-tools.zip"
    if dest.is_file() and hashlib.sha256(dest.read_bytes()).hexdigest()==EXPECTED:
        return
    with urllib.request.urlopen(R11,timeout=65) as src: data=src.read()
    if hashlib.sha256(data).hexdigest()!="d446fda7bb947bd7d7c0069a9c5ec9217e54ffd54af856c1538d13c768809ca9":
        raise ValueError("Public R11 kit digest")
    with zipfile.ZipFile(io.BytesIO(data)) as z: tool=z.read("ak3-tools.zip")
    if hashlib.sha256(tool).hexdigest()!=EXPECTED: raise ValueError("AK3 component digest")
    temp=dest.with_suffix(".part");temp.write_bytes(tool);temp.replace(dest)
EXPECTED="236c80a1930f0c62b950c7cb4507faf8f8092fec5c9a82cc93334d96d5b28ab1"
if __name__=="__main__": load()
