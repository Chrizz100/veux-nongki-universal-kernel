"""Address and configuration readers for the VEUX arm64 Image."""
import re,struct,zlib
from stock_elf import BASE
def align(x):return (x+7)&~7
def unpack(b):
    candidates=[];needle=struct.pack('<Q',BASE)
    for m in re.finditer(re.escape(needle),b):
        pos=m.start();n=struct.unpack_from('<Q',b,pos+8)[0]
        if not pos%8 and 30000<n<300000:candidates.append((pos,n))
    (pos,n),=candidates;start=pos+16;end=start;markers=[]
    for j in range(n):
        if not j%256:markers.append(end-start)
        end+=1+b[end]
    mr=align(end);assert list(struct.unpack_from(f'<{len(markers)}I',b,mr))==markers
    token_at=align(mr+len(markers)*4);p=token_at;tokens=[];offsets=[]
    for j in range(256):
        end=b.index(0,p);offsets.append(p-token_at);tokens.append(b[p:end]);p=end+1
    assert list(struct.unpack_from('<256H',b,align(p)))==offsets
    addresses=struct.unpack_from(f'<{n}I',b,pos-align(n*4))
    assert all(x<=y for x,y in zip(addresses,addresses[1:]))
    out=[];p=start
    for a in addresses:
        size=b[p];p+=1;s=b''.join(tokens[x] for x in b[p:p+size]).decode();p+=size
        out.append((a,s[0],s[1:]))
    assert (4096,'T','_stext') in out
    return out
def normal(name):
    return re.sub(r'(?:\$[0-9a-fA-F]{32}|\.llvm\.\d+)(?=\.|$)','',name)
def gzconfig(blob):
    start=blob.index(b'IKCFG_ST')+8; stop=blob.index(b'IKCFG_ED',start);return zlib.decompress(blob[start:stop],31)
