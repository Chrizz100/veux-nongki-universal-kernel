"""Check the direction of both mode-19 branches and the ESD call in compiled AArch64 code."""
from collections import deque
import struct

BASE = 0xffffffc010080000

def word(k, a):
    return struct.unpack_from("<I", k.raw, a)[0]

def target(a, imm, bits):
    if imm & (1 << (bits - 1)):
        imm -= 1 << bits
    return a + 4 * imm

def destination(k, a, kind):
    op = word(k,a)
    if kind in ("eq","ne"):
        wanted = 0x54000000 | int(kind == "ne")
        assert op & 0xff00001f == wanted, (k.name,hex(a),kind)
    elif kind == "cbnz":
        assert op & 0xff000000 == 0x35000000
    return target(a, (op >> 5) & 0x7ffff,19)

def compare(k, a, value):
    op = word(k, a)
    assert op & 0xffc0001f == 0x7100001f and (op >> 10) & 0xfff == value
    return (op >> 5) & 31

def from_argument(k, start, end, reg, arg):
    if reg == arg:
        return True
    # ORR Wd, WZR, Wm is MOV Wd, Wm.
    return any(word(k, a) == 0x2a0003e0 | (arg << 16) | reg for a in range(start,end,4))

def dispatch(k, calls):
    rules=calls["gtp_set_cur_value"]
    s, = [int(x,16)-BASE for x in rules["goodix_ts_suspend"]]
    r, = [int(x,16)-BASE for x in rules["goodix_ts_resume"]]
    first=k.ranges["gtp_set_cur_value"][0]
    if k.name == "Stock":
        mode=compare(k,s-16,19)
        value=compare(k,r-12,1)
        assert destination(k,s-12,"ne")==r-20
        assert destination(k,s-8,"cbnz")==r-20 and word(k,s-8)&31==value
        assert compare(k,r-20,19)==mode
        assert destination(k,r-16,"ne")==destination(k,r-8,"ne")==r+8
        guards=[s-16,s-12,s-8,r-20,r-16,r-12,r-8]
    else:
        mode=compare(k,s-28,19)
        value=compare(k,s-16,1)
        assert destination(k,s-20,"ne")==destination(k,s-8,"cbnz") and word(k,s-8)&31==value
        assert destination(k,s-12,"eq")==r-4
        guards=[s-28,s-20,s-16,s-12,s-8]
    assert from_argument(k,first,min(guards),mode,0) and from_argument(k,first,min(guards),value,1)
    return {"mode":19,"0":["suspend",hex(BASE+s)],"1":["resume",hex(BASE+r)],"branches":[hex(BASE+v) for v in guards]}

def esd(k, calls):
    # From the optional grip registration, inspect every possible intra-procedural
    # successor. Every returning path must pass the ESD init call.
    name="goodix_ts_stage2_init"
    origin, = calls[name]["init_wt_tp_grip_area"]
    barrier, = calls[name]["goodix_ts_esd_init"]
    a,end=k.ranges[name]
    begin=int(origin,16)-BASE+4; stop=int(barrier,16)-BASE
    def reachable(block):
        queue=deque([begin]);seen=set();returns=set()
        while queue:
            pc=queue.popleft()
            if pc in seen or pc == block: continue
            if not a <= pc < end: raise ValueError("Unexpected jump out of stage2")
            seen.add(pc);ins=word(k,pc)
            if ins & 0xfffffc1f==0xd65f0000:
                returns.add(pc);continue
            if ins>>26==5:
                queue.append(target(pc,ins&0x3ffffff,26));continue
            if ins & 0xff000010==0x54000000 or ins & 0x7e000000==0x34000000:
                queue.append(target(pc,(ins>>5)&0x7ffff,19))
            if ins & 0x7e000000==0x36000000:
                queue.append(target(pc,(ins>>5)&0x3fff,14))
            queue.append(pc+4)
        return seen,returns
    reach,ret=reachable(None);_,bypass=reachable(stop)
    assert stop in reach and ret and not bypass
    return {"after_grip":hex(BASE+begin),"ESD_init":barrier,"reachable_returns":[hex(BASE+r) for r in sorted(ret)],"return_without_ESD":False}
