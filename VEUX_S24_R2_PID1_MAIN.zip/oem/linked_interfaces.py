"""Verify the real sysfs entries and callbacks in the final VEUX images."""
import re
import struct
from image_symbols import BASE, normal
from oem_checks import name_at

def inspect(kernel, targets):
    attrs = ('disp_param', 'mipi_reg')
    rows = {}
    for name in attrs:
        offsets = [a for a, t, n in kernel.symbol_rows
                   if normal(n) == 'dev_attr_' + name and t.lower() in ('r','d')]
        if len(offsets) != 1:
            raise ValueError(f'{kernel.name} attribute {name}: {offsets}')
        rows[name] = offsets[0]
    pointers = {off + delta:struct.unpack_from('<Q', kernel.raw, off + delta)[0]
                for off in rows.values() for delta in (0, 16, 24)}
    if kernel.name == 'Stock':
        for loc in re.finditer(re.escape(struct.pack('<Q',1027)), kernel.raw):
            if loc.start() < 8:continue
            key, _, ptr = struct.unpack_from('<QQQ', kernel.raw, loc.start()-8)
            if key-BASE in pointers:
                pointers[key-BASE] = ptr
    result = {}
    for name, off in rows.items():
        mode = struct.unpack_from('<H', kernel.raw, off+8)[0]
        if mode != 0o644 or not kernel.raw.startswith(name.encode()+b'\0', pointers[off]-BASE):
            raise ValueError(f'{kernel.name} {name}: name or mode')
        entry = {'Modus': '0644'}
        for delta, suffix in [(16, 'show'), (24, 'store')]:
            target = pointers[off+delta]-BASE
            expected = name+'_'+suffix
            if expected not in name_at(kernel, target):
                raise ValueError(f'{kernel.name} {name}: {suffix} is not {expected}')
            entry[suffix] = hex(BASE+target)
        result[name] = entry
    if b'tp_data_dump\0' not in kernel.raw:
        raise ValueError(kernel.name+' missing Goodix proc name')
    if kernel.name == 'Stock':
        edges = {'goodix_data_dump_read':('gtx8_dump_data',),
                 'mipi_reg_store':('dsi_display_mipi_reg_write',),
                 'mipi_reg_show':('dsi_display_mipi_reg_read',),
                 'gtx8_dump_data':('gtx8_poll_read','gtx8_noisetest_prepare')}
    else:
        edges = {'goodix_data_dump_open':('single_open_size',),
                 'goodix_data_dump_show':('gtx8_dump_data','mutex_trylock'),
                 'gtx8_dump_data':('disable_irq','gtx8_poll_read','gtx8_noisetest_prepare','enable_irq','seq_printf'),
                 'disp_param_show':('sde_veux_reply',),'mipi_reg_show':('sde_veux_reply',),
                 'mipi_reg_store':('dsi_display_veux_mipi_store',),
                 'dsi_display_veux_mipi_store':('dsi_panel_create_cmd_packets','dsi_display_clk_ctrl',
                    'dsi_display_cmd_engine_enable','dsi_ctrl_cmd_transfer','dsi_display_cmd_engine_disable'),
                 'dsi_panel_create_cmd_packets':('kfree',)}
    for caller, callees in edges.items():
        for callee in callees:
            sites = targets.get(caller, {}).get(callee, [])
            if not sites:
                raise ValueError(f'{kernel.name} missing {caller} -> {callee}')
            result[caller+' -> '+callee] = sites
    return result
