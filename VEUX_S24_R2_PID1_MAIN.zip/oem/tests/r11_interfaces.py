"""Compile and exercise the exact C functions used by the VEUX procfs and DSI paths."""
from pathlib import Path
import re
import subprocess
import sys
import tempfile

here = Path(__file__).resolve().parent
src = Path(sys.argv[1]).resolve()
dsi = src / "techpack/display/msm/dsi"
gx = src / "drivers/input/touchscreen/goodix_gtx8"
groups = [
    (dsi / "dsi_panel.c", "dsi_panel_get_cmd_pkt_count dsi_panel_create_cmd_packets"),
    (dsi / "dsi_display.c", "dsi_veux_next_token dsi_veux_parse_mipi dsi_veux_read_packet dsi_veux_write_packets"),
    (dsi.parent / "sde/sde_connector.c", "sde_veux_reply"),
    (gx / "goodix_ts_test.c", "gtx8_dump_matrix gtx8_read_dump_frames"),
]
with tempfile.TemporaryDirectory() as temp:
    out = Path(temp)
    pieces = []
    for path, names in groups:
        source = path.read_text()
        for name in names.split():
            pattern = r"^(?:static )?(?:int |ssize_t |void |char \*)" + name + r"\([^;{}]*\)\s*\{.*?^\}"
            match = re.search(pattern, source, re.M | re.S)
            if not match:
                raise ValueError(name)
            pieces.append(match[0])
    (out / "production.h").write_text("\n".join(pieces))
    binary = out / "test"
    subprocess.run(["cc", "-std=gnu11", "-Wall", "-Werror", "-Wno-sign-compare",
                    "-fsanitize=undefined", "-fno-sanitize-recover=all", "-I", str(out),
                    str(here / "r11_interfaces.c"), "-o", binary], check=True)
    subprocess.run([binary], check=True)
