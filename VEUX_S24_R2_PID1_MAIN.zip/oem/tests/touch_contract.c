/* Isolate the external input-core, uaccess and bus calls of the real driver. */
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <linux/input.h>
#include "interfaces.h"

typedef uint8_t u8;
#define __user
#define WRITE_ONCE(x, value) ((x) = (value))
#define smp_load_acquire(p) (*(p))
#define ts_info(...) ((void)0)
#define ts_err(...) ((void)0)
#define CORE_INIT_STAGE2 3
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + (c))
#define LINUX_VERSION_CODE KERNEL_VERSION(5,4,274)
#define INPUT_TYPE_B_PROTOCOL
#define INPUT_MT_DIRECT 2
#define GOODIX_CORE_DRIVER_NAME "goodix"
#define GOOIDX_INPUT_PHYS "input/ts"
#define GOODIX_PEN_DRIVER_NAME "pen"
struct input_dev {
    int (*event)(struct input_dev *, unsigned, unsigned, int);
    const char *name, *phys;
    struct input_id id;
    unsigned evbit[1], absbit[1], keybit[1], propbit[1];
};
struct goodix_ts_device { int unused; };
struct goodix_ts_board_data { int panel_max_x, panel_max_y; };
struct goodix_ts_core {
    struct goodix_ts_device *ts_dev;
    struct input_dev *input_dev, *pen_dev;
    int init_stage, gtp_game;
    bool gamemode_on, aod_changed;
};
struct file { void *private_data; };
static struct goodix_ts_core cd;
static struct goodix_ts_device device;
static struct goodix_ts_board_data board;
static struct { struct goodix_ts_core *core_data; } goodix_modules = { &cd };
static struct goodix_ts_core *goodix_core_data = &cd;
static struct xiaomi_touch_interface xiaomi_touch_interfaces;
static struct xiaomi_touch_interface *touch_data = &xiaomi_touch_interfaces;
static struct { void *dev; } xiaomi_touch_dev = { &device };
static int touch_lock;
static int writes, fail_write, write_error, reset_error, suspends, resumes;
static int copy_in_error, copy_out_error;
static unsigned char packet[5];

static int goodix_i2c_write(struct goodix_ts_device *dev, int addr, u8 *value, int len)
{
    assert(dev == &device && len == 1 && writes < 5 && addr == GTP_GAME_CMD_ADD + writes);
    packet[writes] = *value;
    return writes++ == fail_write ? write_error : 0;
}
static int goodix_set_global_mode(struct goodix_ts_core *core, int r, int e, int f, int l, int g)
{
    assert(core == &cd && !r && e == 2 && f == 3 && !l && !g);
    return reset_error;
}
static int goodix_ts_suspend(struct goodix_ts_core *core) { ++suspends; return 0; }
static int goodix_ts_resume(struct goodix_ts_core *core) { ++resumes; return 0; }

static void mutex_lock(int *lock) { assert(!*lock); ++*lock; }
static void mutex_unlock(int *lock) { assert(*lock == 1); --*lock; }
static int copy_from_user(void *to, const void *from, size_t n) {
    if (copy_in_error) return n;
    memcpy(to, from, n);
    return 0;
}
static int copy_to_user(void *to, const void *from, size_t n) {
    if (copy_out_error) return n;
    memcpy(to, from, n);
    return 0;
}

static int alloc_error, slots_error, register_error, allocated, registered, freed, removed;
static struct input_dev input;
#define board_data(core) (&board)
#define BIT_MASK(n) (1U << ((n) % 32))
#define __set_bit(...) ((void)0)
#define input_set_drvdata(...) ((void)0)
#define input_set_capability(...) ((void)0)
#define input_set_abs_params(...) ((void)ts_bdata)
#define goodix_ts_set_input_params(...) ((void)ts_bdata)
static int gsx_gesture_switch(struct input_dev *dev, unsigned type, unsigned code, int value) { return 0; }
static struct input_dev *input_allocate_device(void) {
    if (alloc_error) return NULL;
    assert(!allocated && !registered);
    allocated = 1;
    return &input;
}
static int input_mt_init_slots(struct input_dev *dev, int slots, int flags) {
    assert(allocated && dev == &input && slots == GOODIX_MAX_TOUCH && flags == INPUT_MT_DIRECT);
    return slots_error;
}
static int input_register_device(struct input_dev *dev) {
    assert(allocated && !registered);
    if (register_error) return register_error;
    registered = 1;
    return 0;
}
static void input_free_device(struct input_dev *dev) {
    assert(dev == &input && allocated && !registered);
    allocated = 0; ++freed;
}
static void input_unregister_device(struct input_dev *dev) {
    assert(dev == &input && allocated && registered);
    registered = allocated = 0; ++removed;
}
#include "functions.h"

static int buffer[VALUE_TYPE_SIZE], cases;
static struct file handle = { &device };
static long request(int op, int mode, int value) {
    buffer[0] = 0; buffer[1] = mode; buffer[2] = value;
    long result = xiaomi_touch_dev_ioctl(&handle, 0x5400 + op, (unsigned long)buffer);
    assert(touch_lock == 0);
    return result;
}
static void touch_tests(void) {
    cd.ts_dev = &device;
    touch_data->setModeValue = gtp_set_cur_value;
    touch_data->resetMode = gtp_reset_mode;
    touch_data->getModeValue = gtp_get_mode_value;
    touch_data->getModeAll = gtp_get_mode_all;
    for (int mode = 0; mode < Touch_Mode_NUM; ++mode) {
        assert(request(SET_CUR_VALUE, mode, 1) == -EAGAIN && writes == 0);
        assert(request(RESET_MODE, mode, 0) == 0 && buffer[0] == -EAGAIN);
        cases += 2;
    }
    cd.init_stage = CORE_INIT_STAGE2;
    fail_write = -1;
    assert(request(SET_CUR_VALUE, Touch_Suspend_Resume, 0) == 0 && suspends == 1 && !writes);
    assert(request(SET_CUR_VALUE, Touch_Suspend_Resume, 1) == 0 && resumes == 1 && !writes);
    cases += 2;
    for (int mode = 0; mode < Touch_Suspend_Resume; ++mode) {
        for (int op = GET_CUR_VALUE; op <= GET_MAX_VALUE; ++op) {
            touch_data->touch_mode[mode][op] = 10 + op;
            assert(request(op, mode, 0) == 0 && buffer[0] == 10 + op);
            ++cases;
        }
        assert(request(GET_MODE_VALUE, mode, 0) == 0);
        for (int i = 0; i < 4; ++i) assert(buffer[i] == 11 + i);
        ++cases;
    }
    memset(touch_data->touch_mode, 0, sizeof(touch_data->touch_mode));
    for (int step = 0; step < 5; ++step) {
        for (int mode = 0; mode < Touch_Suspend_Resume; ++mode) {
            writes = 0; fail_write = step; write_error = step % 2 ? -EREMOTEIO : -EIO;
            assert(request(SET_CUR_VALUE, mode, 1) == write_error && writes == step + 1);
            assert(touch_data->touch_mode[mode][SET_CUR_VALUE] == 0);
            assert(request(GET_CUR_VALUE, mode, 0) == 0 && buffer[0] == 0);
            assert(!cd.aod_changed && !cd.gamemode_on && !cd.gtp_game);
            ++cases;
        }
    }
    /* Encodings exercised by the original register sequence. */
    writes = 0; fail_write = -1;
    assert(request(SET_CUR_VALUE, Touch_Game_Mode, 1) == 0 && writes == 5 && cd.gamemode_on);
    assert(!memcmp(packet, (u8[]){0x0e,0,0,0,0x0e}, 5));
    writes = 0;
    assert(request(SET_CUR_VALUE, Touch_Panel_Orientation, 3) == 0 && writes == 5);
    assert(!memcmp(packet, (u8[]){0x0e,0x80,0,0,0x8e}, 5));
    writes = 0;
    assert(request(SET_CUR_VALUE, Touch_Edge_Filter, 3) == 0 && writes == 5);
    assert(!memcmp(packet, (u8[]){0x0e,0x80,0xc0,1,0x4e}, 5));
    writes = 0;
    assert(request(SET_CUR_VALUE, Touch_Aod_Enable, 1) == 0 && writes == 5 && cd.aod_changed);
    writes = 0; fail_write = 4; write_error = -EIO;
    assert(request(SET_CUR_VALUE, Touch_Game_Mode, 0) == -EIO && cd.gamemode_on && cd.gtp_game);
    assert(request(GET_CUR_VALUE, Touch_Game_Mode, 0) == 0 && buffer[0] == 1);
    writes = 0; fail_write = -1;
    assert(request(SET_CUR_VALUE, Touch_Game_Mode, 0) == 0 && writes == 5 && !cd.gamemode_on);
    assert(!memcmp(packet, (u8[]){0,0,0,0,0}, 5));
    cases += 6;
    reset_error = -EREMOTEIO;
    assert(request(RESET_MODE, 0, 0) == 0 && buffer[0] == -EREMOTEIO);
    reset_error = 0;
    assert(request(RESET_MODE, 0, 0) == 0 && buffer[0] == 0 && !cd.gtp_game);
    assert(request(SET_CUR_VALUE, -1, 0) == -EINVAL);
    assert(request(SET_CUR_VALUE, Touch_Mode_NUM, 0) == -EINVAL);
    assert(request(7, 0, 0) == -EINVAL);
    copy_in_error = 1; assert(request(GET_CUR_VALUE, 0, 0) == -EFAULT); copy_in_error = 0;
    copy_out_error = 1; assert(request(GET_CUR_VALUE, 0, 0) == -EFAULT); copy_out_error = 0;
    handle.private_data = NULL; assert(request(SET_CUR_VALUE, 0, 0) == -ENODEV); handle.private_data = &device;
    touch_data = NULL; assert(request(SET_CUR_VALUE, 0, 0) == -EAGAIN); touch_data = &xiaomi_touch_interfaces;
    cases += 9;
}
static void lifecycle_tests(void) {
    for (int pen = 0; pen <= 1; ++pen) {
        int (*setup)(struct goodix_ts_core *) = pen ? goodix_ts_pen_dev_config : goodix_ts_input_dev_config;
        void (*teardown)(struct goodix_ts_core *) = pen ? goodix_ts_pen_dev_remove : goodix_ts_input_dev_remove;
        struct input_dev **published = pen ? &cd.pen_dev : &cd.input_dev;
        for (int failure = 0; failure < 4; ++failure) {
            if (pen && failure == 2) continue;
            freed = removed = 0;
            alloc_error = failure == 1;
            slots_error = failure == 2 ? -ENOMEM : 0;
            register_error = failure == 3 ? -ENODEV : 0;
            int status = setup(&cd);
            assert(status == (alloc_error ? -ENOMEM : slots_error ? slots_error : register_error));
            assert(*published == (failure ? NULL : &input));
            teardown(&cd);
            teardown(&cd);
            assert(!*published && !registered && !allocated);
            assert(freed == (failure == 2 || failure == 3) && removed == (failure == 0));
            ++cases;
        }
    }
}
int main(void) {
    touch_tests(); lifecycle_tests();
    printf("%d touch, bus and input-core cases passed\n", cases);
    return 0;
}
