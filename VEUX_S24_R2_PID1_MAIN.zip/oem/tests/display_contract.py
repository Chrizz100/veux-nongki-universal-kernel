"""Exercise VEUX display controls against the switch and DSI tables in the original Xiaomi Image."""
from pathlib import Path
import argparse, re, struct, subprocess, tempfile
from r10_interfaces import body
from sys import path
path.insert(0,str(Path(__file__).resolve().parents[1]))
import stock_elf
def main():
 p=argparse.ArgumentParser();p.add_argument('src',type=Path);p.add_argument('stock_boot',type=Path);a=p.parse_args()
 boot=a.stock_boot.read_bytes();raw=boot[4096:4096+struct.unpack_from('<I',boot,8)[0]]
 sy=dict((n,off) for off,t,n in stock_elf.symbols(raw));base=stock_elf.BASE
 def ptr(pc):
  w,z=struct.unpack_from('<II',raw,pc)
  assert w&0x9f000000==0x90000000 and z&0xffc00000==0x91000000 and (w&31)==(z>>5&31)
  rel=((w>>5&0x7ffff)<<2)|(w>>29&3);rel=rel-(1<<21) if rel&(1<<20) else rel
  return ((pc+base)&~4095)+(rel<<12)+(z>>10&4095)-base
 s=sy['panel_disp_param_send'];jump=raw[ptr(s+0xac):ptr(s+0xac)+15]
 assert list(jump)==[23,0,0,0,0,0,0,0,0,28,31,36,23,0,44]
 labels=['MAX','HBM_L3','MAX','MAX','MAX','MAX','MAX','MAX','MAX','MAX','HBM_OFF','HBM_L1','HBM_L2','HBM_L3','MAX','HBM_OFF']
 tables={}
 for n in ['cmd_set_prop_map','cmd_set_state_map']:
  start=sy[n];r={}
  for m in re.finditer(re.escape(struct.pack('<Q',1027)),raw):
   if m.start()<8 or m.start()+16>len(raw):continue
   addr,kind,value=struct.unpack_from('<QQQ',raw,m.start()-8)
   if start<=addr-base<start+37*8:r[(addr-base-start)//8]=raw[value-base:raw.index(0,value-base)].decode()
  assert len(r)==37
  tables[n]=[r[i] for i in range(37)]
 d=a.src/'techpack/display/msm/dsi';c=(d/'dsi_panel.c').read_text();h=(d/'dsi_defs.h').read_text()
 filtered=lambda s:re.sub(r'#ifdef CONFIG_WT_QGKI\n(.*?)#else\n.*?#endif',r'\1',s,flags=re.S)
 for name,tab in tables.items():
  match=re.search(r'const char \*'+name+r'\[DSI_CMD_SET_MAX\] = \{(.*?)\n};',c,re.S)
  assert re.findall(r'"([^"]+)"',filtered(match[1]))==tab,name
 src_enum=re.search(r'enum dsi_cmd_set_type \{.*?\n};',h,re.S)[0]
 lookup=lambda v:'DSI_CMD_SET_'+('MAX' if v=='MAX' else 'DISP_'+v)
 source='\n'.join([filtered(src_enum),'static const int expected_hbm[16] = {'+','.join(lookup(v) for v in labels)+'};',body(c,'dsi_panel_apply_veux_parameter'),body(c,'dsi_panel_apply_veux_doze')])
 with tempfile.TemporaryDirectory() as tmp:
  out=Path(tmp);(out/'production.h').write_text(source)
  exe=out/'test';subprocess.run(['cc','-std=gnu11','-Wall','-Werror','-I',str(out),str(Path(__file__).with_suffix('.c')),'-o',str(exe)],check=True)
  subprocess.run([exe],check=True)
 print('37 DSI-Kommandonamen, 37 Statusnamen und Stock-Sprungtabelle am Originalabbild verifiziert.')
if __name__=='__main__':main()
