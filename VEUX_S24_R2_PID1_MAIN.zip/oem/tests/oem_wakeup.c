#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SUSPEND_ABORT_LEN 256
#define PAGE_SIZE 4096
#define GFP_ATOMIC 0
#define __init
#define EXPORT_SYMBOL_GPL(symbol)
#define late_initcall(name)
#define unlikely(x) (x)
#define WARN_ON(x) (!!(x))
typedef long long ktime_t;
typedef long long s64;
struct timespec64 { long long tv_sec; long tv_nsec; };
struct irqaction { const char *name; };
struct irq_desc { struct irqaction *action; };
struct kobject { int live; };
struct attribute { const char *name; };
struct kobj_attribute {
    struct attribute attr;
    ssize_t (*show)(struct kobject *, struct kobj_attribute *, char *);
};
struct attribute_group { struct attribute **attrs; };
struct notifier_block {
    int (*notifier_call)(struct notifier_block *, unsigned long, void *);
};
struct list_head { struct list_head *next, *prev; };
#define LIST_HEAD(n) struct list_head n = { &(n), &(n) }
#define INIT_LIST_HEAD(p) do { (p)->next = (p); (p)->prev = (p); } while (0)
#define list_empty(p) ((p)->next == (p))
#define node_of(p,t,m) ((t *)((char *)(p) - offsetof(t,m)))
#define list_first_entry(p,t,m) node_of((p)->next,t,m)
#define list_for_each_entry(v,h,m) \
    for (v = node_of((h)->next,__typeof__(*v),m); &v->m != (h); v = node_of(v->m.next,__typeof__(*v),m))
static void list_add(struct list_head *n, struct list_head *p)
{
    n->next = p->next; n->prev = p;
    p->next->prev = n; p->next = n;
}
static void list_del(struct list_head *n) { n->prev->next = n->next; n->next->prev = n->prev; }
static void list_del_init(struct list_head *n) { list_del(n); INIT_LIST_HEAD(n); }
static void list_add_tail(struct list_head *n, struct list_head *p) { list_add(n,p->prev); }
#define DEFINE_SPINLOCK(n) int n
#define spin_lock_irqsave(lock,flags) do { assert(!*(lock)); *(lock)=1; (flags)=0; } while (0)
#define spin_unlock_irqrestore(lock,flags) do { assert(*(lock) && (flags)==0); *(lock)=0; } while (0)
#define __ATTR_RO(n) { { #n }, n##_show }
#define NOTIFY_DONE 0
#define PM_SUSPEND_PREPARE 3
#define PM_POST_SUSPEND 4
static const long long billion = 1000000000LL;
static ktime_t mono, boot;
static ktime_t ktime_get(void) { return mono; }
static ktime_t ktime_get_boottime(void) { return boot; }
static ktime_t ktime_sub(ktime_t a,ktime_t b) { return a-b; }
static struct timespec64 ktime_to_timespec64(ktime_t a)
{
    return (struct timespec64){a / billion, a % billion};
}
static struct timespec64 timespec64_sub(struct timespec64 a, struct timespec64 b)
{
    return ktime_to_timespec64((a.tv_sec-b.tv_sec)*billion + a.tv_nsec-b.tv_nsec);
}
static int scnprintf(char *b,size_t size,const char *fmt,...)
{
    if (!size) return 0;
    va_list args; va_start(args,fmt);
    int n=vsnprintf(b,size,fmt,args); va_end(args);
    return (size_t)n >= size ? (int)size-1 : n;
}
static void quiet(const char *fmt,...) { (void)fmt; }
#define pr_warn quiet
#define pr_info quiet
static struct kobject parent, object;
static struct kobject *kernel_kobj = &parent;
static struct notifier_block *registered;
static struct attribute_group *group;
static int fail_stage;
static bool fail_node;
static size_t allocated;
struct kmem_cache { size_t size; };
static struct kmem_cache pool;
static int register_pm_notifier(struct notifier_block *n)
{
    if (fail_stage == 1) return -1;
    registered=n; return 0;
}
static void unregister_pm_notifier(struct notifier_block *n) { assert(registered==n); registered=NULL; }
static struct kobject *kobject_create_and_add(const char *name,struct kobject *p)
{
    assert(!strcmp(name,"wakeup_reasons") && p==&parent);
    if (fail_stage==2) return NULL;
    object.live=1; return &object;
}
static void kobject_put(struct kobject *o) { assert(o==&object && o->live); o->live=0; }
static int sysfs_create_group(struct kobject *o,struct attribute_group *v)
{
    assert(o==&object && o->live);
    if (fail_stage==3) return -1;
    group=v; return 0;
}
static void sysfs_remove_group(struct kobject *o,struct attribute_group *v)
{
    assert(o->live && v==group); group=NULL;
}
static struct kmem_cache *kmem_cache_create(const char *name,size_t size,unsigned align,
                                             unsigned flags,void *ctor)
{
    assert(!strcmp(name,"wakeup_irq_node_cache"));
    if (fail_stage==4) return NULL;
    pool.size=size; return &pool;
}
static void *kmem_cache_alloc(struct kmem_cache *p,int flags)
{
    assert(p==&pool);
    if (fail_node) return NULL;
    allocated++; return calloc(1,p->size);
}
static void kmem_cache_free(struct kmem_cache *p,void *n)
{
    assert(p==&pool && allocated); allocated--; free(n);
}
static struct irqaction irq_action={"touch"};
static struct irq_desc irq_line={&irq_action};
static struct irq_desc *irq_to_desc(int irq) { return irq==99 ? NULL : &irq_line; }

#include "production.inc"

static void check_reason(const char *expected)
{
    char out[PAGE_SIZE] = {0};
    ssize_t n=last_resume_reason_show(kobj,&resume_reason,out);
    assert(n==(ssize_t)strlen(expected) && !strcmp(out,expected));
}
static void event(unsigned long n) { assert(registered->notifier_call(registered,n,NULL)==NOTIFY_DONE); }

int main(void)
{
    for (fail_stage=1;fail_stage<=4;fail_stage++) {
        assert(wakeup_reason_init()!=0 && !registered && !object.live && !group);
        clear_wakeup_reasons();
        log_irq_wakeup_reason(10);
        check_reason("");
    }
    fail_stage=0;
    assert(wakeup_reason_init()==0 && registered && group);
    assert(!strcmp(group->attrs[0]->name,"last_resume_reason"));
    assert(!strcmp(group->attrs[1]->name,"last_suspend_time") && !group->attrs[2]);
    mono=billion; boot=5*billion;
    event(PM_SUSPEND_PREPARE);
    log_irq_wakeup_reason(20);
    log_irq_wakeup_reason(3);
    log_irq_wakeup_reason(20);
    check_reason("3 touch\n20 touch\n");
    log_threaded_irq_wakeup_reason(6,20);
    log_threaded_irq_wakeup_reason(7,20);
    log_threaded_irq_wakeup_reason(7,20);
    log_threaded_irq_wakeup_reason(15,88);
    check_reason("3 touch\n6 touch\n7 touch\n");
    log_irq_wakeup_reason(99);
    check_reason("3 touch\n6 touch\n7 touch\n99 (unnamed)\n");
    mono+=2*billion; boot+=7*billion;
    event(PM_POST_SUSPEND);
    log_irq_wakeup_reason(2);
    check_reason("3 touch\n6 touch\n7 touch\n99 (unnamed)\n");
    char timebuf[PAGE_SIZE]={0};
    assert(last_suspend_time_show(kobj,&suspend_time,timebuf)>0);
    assert(!strcmp(timebuf,"2.000000000 5.000000000\n"));
    event(PM_SUSPEND_PREPARE);
    assert(!allocated); check_reason("");
    log_suspend_abort_reason("resume %s", "50%");
    log_abnormal_wakeup_reason("later");
    log_irq_wakeup_reason(1);
    check_reason("Abort: resume 50%");
    event(PM_SUSPEND_PREPARE);
    log_abnormal_wakeup_reason("unexpected HW IRQ %u",12);
    log_suspend_abort_reason("later"); check_reason("-1 unexpected HW IRQ 12");
    event(PM_SUSPEND_PREPARE);
    fail_node=true;
    log_irq_wakeup_reason(9); check_reason("");
    fail_node=false; log_irq_wakeup_reason(9); check_reason("9 touch\n");
    clear_wakeup_reasons(); assert(!allocated);
    puts("Wakeup: init/unwind, IRQ ordering, threaded IRQ, faults, aborts, resume and timing passed");
    return 0;
}
