#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef int16_t s16;
#define PAGE_SIZE 4096
#define SZ_64K 65536
#define GFP_KERNEL 0
#define MAX_DRV_NUM 40
#define MAX_SEN_NUM 36
#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define BUILD_BUG_ON(x) _Static_assert(!(x), "bounds")
#define be16_to_cpu(x) ntohs(x)
#define scnprintf snprintf
#define GTX8_RETRY_NUM_3 3
#define IC_TYPE_YELLOWSTONE 2
#define DSI_CTRL_CMD_FETCH_MEMORY 1
#define DSI_CTRL_CMD_READ 2
#define DSI_CTRL_CMD_CUSTOM_DMA_SCHED 4
#define DSI_CTRL_CMD_LAST_COMMAND 8
#define MIPI_DSI_MSG_LASTCOMMAND 16
#define MIPI_DSI_MSG_USE_LPM 32
#define DSI_ALL_CLKS 1
#define DSI_CLK_ON 1
#define DSI_CLK_OFF 0
enum { CLOCK_ON=1, ENGINE_ON, ALLOC, TRANSFER, ENGINE_OFF, CLOCK_OFF, TRANSMIT,
       INIT_CMDS, PARAMS, CONFIG, CHANNELS, SEND, POLL, PREP_NOISE, NOISE, NORMAL, ACK };
static int fail, trace[64], steps, reads, transfer_bytes, waits, checks;
static int record(int point) { assert(steps<64); trace[steps++]=point; return fail==point ? -EIO : 0; }
static void reset(int f) { fail=f;steps=reads=waits=0;transfer_bytes=3; }
static void check(int ok) { assert(ok);checks++; }
static int count(int value) { int n=0;for(int i=0;i<steps;i++) n+=trace[i]==value;return n; }
static int alloc_count,fail_alloc,free_count;
static void *allocated[16];
static void *kzalloc(size_t size,int flags) {
    (void)flags;int i=alloc_count++;if(i==fail_alloc)return NULL;
    assert(i<16);return allocated[i]=calloc(1,size?size:1);
}
static void kfree(const void *p) {
    if(!p)return;
    for(int i=0;i<alloc_count;i++)if(allocated[i]==p){free(allocated[i]);allocated[i]=NULL;free_count++;return;}
    assert(!"non-owned packet allocation");
}
static int kstrtouint(const char *s,int base,unsigned int *out) {
    char *end;errno=0;unsigned long value=strtoul(s,&end,base);
    if(!*s||*s=='-'||*end||errno||value>UINT32_MAX)return -EINVAL;
    *out=(unsigned)value;return 0;
}
static int kstrtou8(const char *s,int base,u8 *out) {
    unsigned int val;if(kstrtouint(s,base,&val)||val>255)return -EINVAL;*out=val;return 0;
}
struct dsi_ctrl { int n; };
struct msg { unsigned type,channel,flags,ctrl,wait_ms,tx_len,rx_len;void *rx_buf;const void *tx_buf; };
struct dsi_cmd_desc { struct msg msg; unsigned post_wait_ms;bool last_command; };
struct dsi_panel_cmd_set { struct dsi_cmd_desc *cmds;unsigned count; };
struct host; struct ops { ssize_t (*transfer)(struct host *, struct msg *); };
struct host { struct ops *ops; };
struct dsi_panel { int panel_lock;char veux_parameter_reply[256];u8 veux_mipi_reply[64],veux_mipi_reply_len;struct host *host; };
struct dsi_display { struct {struct dsi_ctrl *ctrl;} ctrl[2];unsigned cmd_master_idx,ctrl_count;void *tx_cmd_buf;int dsi_clk_handle; };
static int dsi_display_clk_ctrl(int h,int which,int on){(void)h;(void)which;return record(on?CLOCK_ON:CLOCK_OFF);}
static int dsi_display_cmd_engine_enable(struct dsi_display *d){(void)d;return record(ENGINE_ON);}
static int dsi_display_cmd_engine_disable(struct dsi_display *d){(void)d;return record(ENGINE_OFF);}
static int dsi_host_alloc_cmd_tx_buffer(struct dsi_display *d){(void)d;return record(ALLOC);}
static int dsi_ctrl_cmd_transfer(struct dsi_ctrl *c,struct msg *m,u32 *flags){
    assert(c && (*flags&7)==7 && !!(*flags&8)==!!(m->flags&16));
    int rc=record(TRANSFER);if(rc)return rc;memset(m->rx_buf,0xa1,m->rx_len);return transfer_bytes;
}
static ssize_t htransfer(struct host *h,struct msg *m){assert(h && (m->flags&32));return record(TRANSMIT);}
static void usleep_range(unsigned a,unsigned b){assert(b==a+10);waits++;}
struct drm_modeset_lock {int locked;};
struct drm_connector { struct { struct { struct drm_modeset_lock connection_mutex; } mode_config; } *dev;struct dsi_panel *panel;};
struct device { struct drm_connector *data; };
static struct drm_connector *dev_get_drvdata(struct device *d){return d->data;}
static struct dsi_panel *sde_veux_panel(struct drm_connector *c){return c->panel;}
static int drm_modeset_lock_single_interruptible(struct drm_modeset_lock *l){if(fail==-1)return -EINTR;assert(!l->locked++);return 0;}
static void drm_modeset_unlock(struct drm_modeset_lock *l){assert(l->locked--==1);}
static void mutex_lock(int *l){assert(!(*l)++);}
static void mutex_unlock(int *l){assert((*l)--==1);}
struct seq_file { char buf[2048];size_t used; };
#define seq_printf(s,...) ((s)->used+=(size_t)snprintf((s)->buf+(s)->used,sizeof((s)->buf)-(s)->used,__VA_ARGS__))
static void seq_putc(struct seq_file *s,char c){s->buf[s->used++]=c;s->buf[s->used]=0;}
struct goodix_ts_device;
struct cmd {int cmd_reg;u8 cmds[4];int length;};
struct goodix_ts_hw_ops {int (*send_cmd)(struct goodix_ts_device *,struct cmd *);int (*write_trans)(struct goodix_ts_device *,int,u8 *,int);};
struct goodix_ts_device {int ic_type;struct {int coor;} reg;const struct goodix_ts_hw_ops *hw_ops;};
struct goodix_ts_core {struct goodix_ts_device *ts_dev;};
struct ts_test_params {unsigned drv_num,sen_num,rawdata_addr,noisedata_addr;};
struct gtx8_ts_test {struct goodix_ts_core *ts;struct ts_test_params test_params;struct {u8 data[12];}orig_config;
    struct cmd rawdata_cmd,normal_cmd;struct {u16 data[32];}rawdata;};
static int gtx8_init_cmds(struct gtx8_ts_test *t){t->normal_cmd.cmd_reg=3;return record(INIT_CMDS);}
static int gtx8_init_params(struct gtx8_ts_test *t){(void)t;return record(PARAMS);}
static int gtx8_cache_origconfig(struct gtx8_ts_test *t){(void)t;return record(CONFIG);}
static int gtx8_get_channel_num(struct goodix_ts_core *c,u32 *r,u32 *t,u8 *buf){(void)c;(void)r;(void)t;(void)buf;return record(CHANNELS);}
static int send_cmd(struct goodix_ts_device *d,struct cmd *c){(void)d;(void)c;return record(SEND);}
static int write_trans(struct goodix_ts_device *d,int reg,u8 *buf,int n){if(reg==d->reg.coor)assert(n==1 && !*buf);return record(reg==d->reg.coor?ACK:NORMAL);}
static void msleep(unsigned n){assert(n==50);}
static int gtx8_poll_read(struct gtx8_ts_test *t,int addr,u8 *buf,unsigned n){assert(addr==10 && n==12 && buf==(u8*)t->rawdata.data);reads++;return record(POLL);}
static int gtx8_noisetest_prepare(struct gtx8_ts_test *t){(void)t;return record(PREP_NOISE);}
static int gtx8_cache_noisedata(struct gtx8_ts_test *t){(void)t;return record(NOISE);}
#include "production.h"
int main(void) {
    const char *bad[]={"", "1", "1 0 06", "1 65 06", "0 0 100", "x 2 06", "1 -1 06","0 0 xyz"};
    unsigned n;u32 len;bool read;u8 data[256];
    for(unsigned i=0;i<ARRAY_SIZE(bad);i++){char buf[64];strcpy(buf,bad[i]);check(dsi_veux_parse_mipi(buf,data,&len,&read,&n)<0);}
    char cmd[]=" \t1  3 06 01 00 00 00 00 01 a1\n";
    check(!dsi_veux_parse_mipi(cmd,data,&len,&read,&n)&&read&&len==8&&n==3);
    u32 nr;
    for(unsigned i=1;i<8;i++)check(dsi_panel_get_cmd_pkt_count((char*)data,i,&nr)<0);
    check(!dsi_panel_get_cmd_pkt_count((char*)data,8,&nr)&&nr==1);
    check(dsi_panel_get_cmd_pkt_count((char*)data,9,&nr)<0);
    memcpy(data+8,data,8);memcpy(data+16,data,8);
    for(int f=0;f<4;f++) {
        struct dsi_cmd_desc pkt[3]={};alloc_count=free_count=0;fail_alloc=f;
        int rc=dsi_panel_create_cmd_packets((char*)data,24,3,pkt);
        check((f==3 && rc==0)||(f<3 && rc==-ENOMEM));check(free_count==(f==3?0:f));
        if(!rc) for(int i=0;i<3;i++)kfree(pkt[i].msg.tx_buf);
        for(int i=0;i<3;i++)check(!allocated[i]);
    }
    struct dsi_ctrl ctrl={};struct dsi_display display={ .ctrl={{&ctrl}},.ctrl_count=1 };
    for(int f=0;f<=CLOCK_OFF;f++){
        reset(f);struct dsi_cmd_desc pkt={.last_command=true};u8 rx[3];
        int rc=dsi_veux_read_packet(&display,&pkt,rx,sizeof(rx));
        check(f ? rc==-EIO : (!rc && rx[0]==0xa1));
        check(count(CLOCK_OFF)==(f!=CLOCK_ON));check(count(ENGINE_OFF)==(f!=CLOCK_ON && f!=ENGINE_ON));
    }
    reset(0);transfer_bytes=2;struct dsi_cmd_desc pkt={};u8 rx[3];
    check(dsi_veux_read_packet(&display,&pkt,rx,3)==-EIO);
    display.cmd_master_idx=2;check(dsi_veux_read_packet(&display,&pkt,rx,3)==-ENODEV);
    struct ops hops={htransfer};struct host host={&hops};struct dsi_panel panel={.host=&host};
    struct dsi_cmd_desc msgs[2]={{.post_wait_ms=2},{.last_command=true}};
    struct dsi_panel_cmd_set set={msgs,2};reset(0);
    check(!dsi_veux_write_packets(&panel,&set)&&count(TRANSMIT)==2&&waits==1&&(msgs[1].msg.flags&16));
    reset(TRANSMIT);check(dsi_veux_write_packets(&panel,&set)==-EIO&&count(TRANSMIT)==1&&!waits);
    struct drm_connector conn={.panel=&panel};typeof(*conn.dev) displaydev={};conn.dev=&displaydev;
    struct device dev={&conn};char out[PAGE_SIZE]={};reset(0);
    check(sde_veux_reply(&dev,out,false)==0);strcpy(panel.veux_parameter_reply,"abc");
    check(sde_veux_reply(&dev,out,false)==3&&!memcmp(out,"abc",3));
    memset(panel.veux_parameter_reply,'x',256);check(sde_veux_reply(&dev,out,false)==255);
    panel.veux_mipi_reply_len=2;panel.veux_mipi_reply[0]=0xa1;panel.veux_mipi_reply[1]=0x0b;
    check(sde_veux_reply(&dev,out,true)==10&&!strcmp(out,"0xa1 0x0b\n"));
    conn.panel=NULL;check(!sde_veux_reply(&dev,out,false));reset(-1);check(sde_veux_reply(&dev,out,false)==-EINTR);
    struct goodix_ts_hw_ops gops={send_cmd,write_trans};struct goodix_ts_device gd={.reg={5},.hw_ops=&gops};
    struct goodix_ts_core core={&gd};struct gtx8_ts_test test={.ts=&core,.test_params={2,3,10,20}};
    for(int f=INIT_CMDS;f<=ACK;f++){
        reset(f);check(gtx8_read_dump_frames(&test)==-EIO);
        check(count(NORMAL)==(f>=SEND));check(count(ACK)==(f>=SEND));if(f==POLL)check(reads==3);
    }
    reset(0);check(!gtx8_read_dump_frames(&test)&&count(CONFIG)==1&&count(NOISE)==1&&count(ACK)==1);
    gd.ic_type=IC_TYPE_YELLOWSTONE;reset(0);check(!gtx8_read_dump_frames(&test)&&!count(CONFIG));
    test.test_params.sen_num=MAX_SEN_NUM+1;reset(0);check(gtx8_read_dump_frames(&test)==-EINVAL&&!count(SEND));
    struct seq_file seq={};u16 values[]={htons(1),htons(2),htons(3),htons(4),htons(5),htons((u16)-6)};
    gtx8_dump_matrix(&seq,values,2,3);check(!strcmp(seq.buf,"   1,   4,\n   2,   5,\n   3,  -6,\n"));
    printf("%d Pruefbedingungen am Produktionscode erfuellt.\n",checks);return 0;
}
