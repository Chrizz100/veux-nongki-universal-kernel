"""Run the production Xiaomi read and wakeup functions with controlled inputs."""
import argparse
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent


def run(tree, directory, source, test, symbols=None):
    code = (tree / source).read_text()
    if test == "oem_wakeup.c":
        # Keep the complete implementation, including the real attribute definitions
        # and init/cleanup order. The host provides only the Linux services.
        body = code[code.index("struct wakeup_irq_node {"):]
    else:
        body = code[code.index("#define "):code.index("static struct of_device_id")]
    (directory / "production.inc").write_text(body)
    targets = ["cc", "-std=gnu11", "-O2", "-Wall", "-Werror", "-Wno-unused-parameter",
               "-Wno-format", "-I", str(directory)]
    for key, value in (symbols or {}).items():
        targets.append(f"-D{key}={value}")
    exe = directory / "check"
    subprocess.run(targets + [str(HERE / test), "-o", str(exe)], check=True)
    subprocess.run([str(exe)], check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tree", type=Path)
    tree = parser.parse_args().tree.resolve()
    with TemporaryDirectory() as work:
        tmp = Path(work)
        run(tree, tmp, "kernel/power/wakeup_reason.c", "oem_wakeup.c")
        rows = [
            ("serial_num", "sn_fuse", "sn_proc_open", "serial_num", "sn-base", "0x0000002a\n"),
            ("secboot_fuse", "secboot_fuse", "secboot_proc_open", "secboot_fuse_reg", "sec-boot-base", "0x2a\n"),
            ("cpu_feature_id", "feature_id", "featureid_proc_open", "cpu_feature_id", "cpu-feature-id", "0x2a\n"),
        ]
        for file, name, opened, node, reg, formatted in rows:
            expected = formatted.replace("\n", "\\n")
            run(tree, tmp, f"drivers/soc/qcom/{file}.c", "oem_register.c",
                {"PROBE": name + "_probe", "REMOVE": name + "_remove", "OPEN": opened,
                 "PROC_NAME": f'"{node}"', "REG_NAME": f'"{reg}"', "EXPECTED": f'"{expected}"'})


if __name__ == "__main__":
    main()
