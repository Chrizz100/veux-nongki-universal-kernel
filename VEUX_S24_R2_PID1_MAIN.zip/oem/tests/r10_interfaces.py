"""Exercise the production C functions for panel identification, palm updates and Goodix power transitions."""
import argparse, re, subprocess, tempfile
from pathlib import Path
HERE=Path(__file__).resolve().parent
def body(s,n):
 pat=r'^(?:static )?(?:long|ssize_t|int|void|bool) '+n+r'\([^;{}]*\)\s*\{.*?^}'
 m=re.search(pat,s,re.M|re.S)
 if not m:raise ValueError(n)
 return m[0]
def main():
 ap=argparse.ArgumentParser();ap.add_argument('src',type=Path);ap.add_argument('--r9',action='store_true');ap.add_argument('--vendor-csv',type=Path);a=ap.parse_args()
 t=a.src/'drivers/input/touchscreen';gx=t/'goodix_gtx8';d=(gx/'goodix_ts_core.c').read_text()
 io=(gx/'goodix_ts_i2c.c').read_text();touch=(t/'xiaomi/xiaomi_touch.c').read_text()
 panel=(a.src/('drivers/gpu/drm/drm_sysfs.c' if a.r9 else 'techpack/display/msm/sde/sde_connector.c')).read_text()
 parts=[(panel,'panel_info_show'),(touch,'palm_sensor_store'),(d,'gtp_palm_sensor_write'),(io,'goodix_hw_reset'),(io,'goodix_hw_suspend'),(io,'goodix_hw_resume'),(d,'goodix_ts_suspend'),(d,'goodix_ts_resume')]
 if not a.r9:
  factory=(gx/'goodix_ts_test.c').read_text()
  parts.extend([(factory,'gtx8_parse_section'),(d,'goodix_selftest_result')])
 with tempfile.TemporaryDirectory() as tmp:
  tmp=Path(tmp);(tmp/'driver.h').write_text('\n'.join(body(s,n) for s,n in parts))
  out=tmp/'check';base=['cc','-std=gnu11','-O1','-Wall','-Werror=implicit-function-declaration','-Wno-unused-variable','-Wno-unused-function','-Wno-unused-parameter','-I',str(tmp)]
  if a.r9:base+=['-DBEFORE']
  subprocess.run(base+[str(HERE/'r10_interfaces.c'),'-o',str(out)],check=True)
  subprocess.run([out]+([a.vendor_csv] if a.vendor_csv else []),check=True)
if __name__=='__main__': main()
