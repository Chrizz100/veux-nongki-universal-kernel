#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

#define PAGE_SIZE 4096
#define U8_MAX 255
#define DRM_MODE_CONNECTOR_DSI 16
#define to_sde_connector(p) ((struct sde_connector *)(p))
#define dev_get_drvdata(d) ((d)->data)
#define scnprintf snprintf
#define ts_info(...) ((void)0)
#define ts_err(...) ((void)0)
#define list_empty(h) 1
#define list_for_each_entry_safe(e,n,h,m) for (;0;)
#define TOUCHSCREEN_XIAOMI_TOUCHFEATURE 1
#define CONFIG_PINCTRL 1
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define smp_load_acquire(x) (*(x))
#define atomic_read(x) (*(x))
#define atomic_set(x,v) (*(x)=(v))
#define CORE_INIT_STAGE2 3
#define EVT_CANCEL_RESUME 4
#define EVT_CANCEL_SUSPEND 5
#define TP_NO_SUSPEND 0
#define TP_GESTURE 1
#define TP_SLEEP 2
#define NOTIFY_SUSPEND 1
#define NOTIFY_RESUME 2
#define NOTIFY_ESD_ON 3
#define COMMAND_SLEEP 5
#define GFP_KERNEL 0
typedef unsigned char u8; typedef int32_t s32;
struct device { void *data; }; struct device_attribute {int unused;};
struct drm_modeset_lock {int held;};
struct drm_device {struct {struct drm_modeset_lock connection_mutex;} mode_config;};
struct drm_encoder {void *bridge;};
struct drm_connector {struct drm_device *dev; struct drm_encoder *encoder;};
struct dsi_display {const char *name;};
struct sde_connector {struct drm_connector base;int connector_type;struct dsi_display *display;};
static int lock_error;
static int drm_modeset_lock_single_interruptible(struct drm_modeset_lock *l) {
 if (lock_error) return lock_error;
 assert(!l->held);l->held=1;return 0;
}
static void drm_modeset_unlock(struct drm_modeset_lock *l){assert(l->held);l->held=0;}
static void mutex_lock(int *x){assert(!*x); *x=1;}
static void mutex_unlock(int *x){assert(*x); *x=0;}
static int mutex_trylock(int *x){if (*x) return 0;*x=1;return 1;}
static int goodix_diagnostic_lock,touch_lock;
struct goodix_ts_device;
struct hw_ops {int (*suspend)(struct goodix_ts_device *);int (*resume)(struct goodix_ts_device *);};
struct goodix_ts_device {struct {int reset_gpio;} board_data;struct {int esd,command;} reg;struct hw_ops *hw_ops;};
struct goodix_ts_cmd {int initialized;};
struct pdev {struct device dev;};
struct goodix_ts_core {int work_stat, suspend_stat, suspended, irq_enabled, gesture_irq_wake,irq;
 int power_on,palm_changed,sleep_enable,init_stage,gesture_enable,pinctrl,pin_sta_active,pin_sta_suspend;
 struct {int esd_on;} ts_esd;struct goodix_ts_device *ts_dev;struct pdev *pdev;};
struct goodix_ext_module {const char *name;struct {int (*before_suspend)(),(*before_resume)(),(*after_suspend)(),(*after_resume)();} *funcs;};
static struct {int mutex,head;struct goodix_ts_core *core_data;} goodix_modules;
static struct {int (*palm_sensor_write)(int);} td,*touch_data;
static int gpio_error[2],gpio_calls,esd_error,send_error,command_ready=1,palm_error,palm_calls,release_count;
static int gpio_direction_output(int pin,int val){gpio_calls++;return gpio_error[val];}
static void udelay(int x){} static void msleep(int x){}
static int goodix_i2c_write_trans(struct goodix_ts_device *d,int r,u8 *b,int n){return esd_error;}
static void goodix_cmd_init(struct goodix_ts_device *d,struct goodix_ts_cmd *c,int op,int v,int r){c->initialized=command_ready;}
static int goodix_send_command(struct goodix_ts_device *d,struct goodix_ts_cmd *c){return send_error;}
static int goodix_ts_power_on(struct goodix_ts_core *c){c->power_on=1;return 0;}
static int goodix_ts_power_off(struct goodix_ts_core *c){c->power_on=0;return 0;}
static int disable_irq_wake(int n){return 0;}
static int pinctrl_select_state(int ctl,int st){return 0;}
static void goodix_ts_irq_enable(struct goodix_ts_core *c,bool b){c->irq_enabled=b;}
static void goodix_ts_blocking_notify(int why,void *p){goodix_modules.core_data->ts_esd.esd_on=why!=NOTIFY_SUSPEND;}
static void goodix_ts_release_connects(struct goodix_ts_core *c){release_count++;}
static int update_palm_sensor_value(int v){return 0;}
static int goodix_set_palm_mode(struct goodix_ts_core *c,bool on){palm_calls++;return palm_error;}
static int kstrtouint(const char *s,int base,unsigned *out){
 char *end;unsigned long v=strtoul(s,&end,base);if(end==s||*end||v>UINT_MAX)return -EINVAL;*out=v;return 0;
}
static char *strim(char *s){while(isspace((unsigned char)*s))s++;size_t n=strlen(s);while(n&&isspace((unsigned char)s[n-1]))s[--n]=0;return s;}
static int kstrtos32(const char *s,int base,s32 *out){
 errno=0;char *end;long v=strtol(s,&end,base);if(errno||v<INT32_MIN||v>INT32_MAX)return -ERANGE;
 if (*end || end == s) return -EINVAL;
 *out = v;
 return 0;
}
struct seq_file {void *private;char text[40];};
struct ts_rawdata_info {char result[100];};
static int alloc_error,measure_err,measure_count;
static const char *measured;
#define kzalloc(n,g) (alloc_error?NULL:calloc(1,n))
#define kfree free
#define seq_puts(m,s) snprintf((m)->text,sizeof((m)->text),"%s",s)
#define seq_printf(m,f,...) snprintf((m)->text,sizeof((m)->text),f,__VA_ARGS__)
static int gtx8_get_rawdata(struct device *d,struct ts_rawdata_info *info){
 measure_count++;snprintf(info->result,sizeof(info->result),"%s",measured);return measure_err;
}
#include "driver.h"
static int tests;
#define CHECK(x) do {if(!(x)){fprintf(stderr,"Fehler Zeile %d: %s\n",__LINE__,#x);exit(2);}tests++;}while(0)

#ifndef BEFORE
static int section(const char *text,const char *key,int rows,int cols,bool var,s32 *v){
 char *c=strdup(text);assert(c);int ret=gtx8_parse_section(c,key,v,rows,cols,var);free(c);return ret;
}
#endif
int main(int argc,char **argv){
 struct drm_device drm={0};struct drm_encoder enc={.bridge=&enc};
 struct dsi_display display={"qcom,mdss_dsi_k6s_38_0c_0a_fhdp_dsc_vid"};
 struct sde_connector con={.base={&drm,&enc},.connector_type=DRM_MODE_CONNECTOR_DSI,.display=&display};
 struct device dev={&con};char text[PAGE_SIZE]={0};
 struct goodix_ts_core core={0};struct goodix_ts_device chip={0};
 struct hw_ops ops={goodix_hw_suspend,goodix_hw_resume};
 struct pdev pd={0};core.pdev=&pd;core.ts_dev=&chip;chip.hw_ops=&ops;goodix_modules.core_data=&core;
 core.power_on=1;core.ts_esd.esd_on=1;core.irq_enabled=1;core.init_stage=CORE_INIT_STAGE2;
 CHECK(panel_info_show(&dev,NULL,text)>0 && !strcmp(text,"panel_name=dsi_k6s_38_0c_0a_fhdp_dsc_vid_display\n"));
 display.name="qcom,mdss_dsi_sim_video";
#ifdef BEFORE
 CHECK(panel_info_show(&dev,NULL,text)>0 && !strstr(text,"sim_video"));
 con.base.encoder=NULL;CHECK(panel_info_show(&dev,NULL,text)>0);
 CHECK(palm_sensor_store(NULL,NULL,"1",1)==1 && !palm_calls);
 touch_data=&td;td.palm_sensor_write=gtp_palm_sensor_write;palm_error=-EREMOTEIO;
 CHECK(palm_sensor_store(NULL,NULL,"1",1)==-EREMOTEIO && core.palm_changed);
 send_error=-EREMOTEIO;CHECK(goodix_ts_suspend(&core)==0 && core.suspend_stat==TP_SLEEP && !core.irq_enabled);
 gpio_error[1]=-EIO;CHECK(goodix_ts_resume(&core)==0 && core.suspend_stat==TP_NO_SUSPEND && core.irq_enabled);
 printf("%d R9-Kontrollbefunde reproduziert.\n",tests);return 0;
#else
 CHECK(panel_info_show(&dev,NULL,text)>0 && !strcmp(text,"panel_name=dsi_sim_video_display\n"));
 con.base.encoder=NULL;CHECK(panel_info_show(&dev,NULL,text)==0);con.base.encoder=&enc;
 enc.bridge=NULL;CHECK(panel_info_show(&dev,NULL,text)==0);enc.bridge=&enc;
 display.name=NULL;CHECK(panel_info_show(&dev,NULL,text)==0);display.name="xy";
 CHECK(panel_info_show(&dev,NULL,text)>0&&!strcmp(text,"panel_name=_display\n"));
 con.connector_type=3;CHECK(panel_info_show(&dev,NULL,text)==0);con.connector_type=DRM_MODE_CONNECTOR_DSI;
 lock_error=-EINTR;CHECK(panel_info_show(&dev,NULL,text)==-EINTR);lock_error=0;
 CHECK(palm_sensor_store(NULL,NULL,"1",1)==-EAGAIN && !palm_calls);
 touch_data=&td;CHECK(palm_sensor_store(NULL,NULL,"1",1)==-EOPNOTSUPP);
 td.palm_sensor_write=gtp_palm_sensor_write;palm_error=-EREMOTEIO;
 CHECK(palm_sensor_store(NULL,NULL,"1",1)==palm_error && !core.palm_changed);
 palm_error=0;CHECK(palm_sensor_store(NULL,NULL,"1",1)==1 && core.palm_changed);
 send_error=-EREMOTEIO;
 for(int esd=0;esd<2;esd++)for(int irq=0;irq<2;irq++){
  core.ts_esd.esd_on=esd;core.irq_enabled=irq;
  CHECK(goodix_ts_suspend(&core)==-EREMOTEIO && core.suspend_stat==TP_NO_SUSPEND &&
        core.irq_enabled==irq && core.ts_esd.esd_on==esd && !core.work_stat && !release_count);
 }
 command_ready=0;CHECK(goodix_ts_suspend(&core)==-EINVAL && !core.suspended);command_ready=1;
 send_error=0;core.sleep_enable=1;CHECK(!goodix_ts_suspend(&core) && core.suspend_stat==TP_SLEEP && !core.power_on);
 for(int edge=0;edge<2;edge++){
  gpio_calls=0;gpio_error[edge]=-EIO;
  CHECK(goodix_ts_resume(&core)==-EIO && core.suspend_stat==TP_SLEEP && !core.irq_enabled &&
        core.suspended && !core.power_on && gpio_calls==edge+1 && !core.work_stat);
  gpio_error[edge]=0;
 }
 core.gesture_irq_wake=1;core.suspend_stat=TP_GESTURE;core.power_on=1;gpio_error[1]=-EIO;
 CHECK(goodix_ts_resume(&core)==-EIO && core.gesture_irq_wake && core.suspend_stat==TP_GESTURE);
 gpio_error[1]=0;CHECK(!goodix_ts_resume(&core)&&!core.gesture_irq_wake&&core.suspend_stat==TP_NO_SUSPEND&&core.irq_enabled);
 struct seq_file seq={.private=&core};measured="0P-1P-2P-3P-5P-GT";
 CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"2\n"));
 CHECK(!goodix_selftest_result(&seq,false)&&!strcmp(seq.text,"result=1\n"));
 measured="0P-1F-2P-3P-5P";CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"0\n"));
 measure_err=-EIO;CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"1\n"));measure_err=0;
 int before=measure_count;core.suspend_stat=TP_SLEEP;
 CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"1\n")&&measure_count==before);
 core.suspend_stat=0;goodix_diagnostic_lock=1;
 CHECK(!goodix_selftest_result(&seq,false)&&!strcmp(seq.text,"result=0\n")&&measure_count==before);goodix_diagnostic_lock=0;
 core.init_stage=0;CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"1\n")&&measure_count==before);
 alloc_error=1;CHECK(!goodix_selftest_result(&seq,true)&&!strcmp(seq.text,"1\n"));alloc_error=0;
 s32 values[4096]={0};const char *csv="header,\r\n1,2,,,\r\n3,4,,\n";
 CHECK(section(csv,"header",2,2,false,values)==4 && values[0]==1 && values[3]==4);
 CHECK(section(csv,"header",2,1,false,values)==-E2BIG);
 CHECK(section(csv,"header",2,3,false,values)==-EINVAL);
 CHECK(section(csv,"header",3,2,false,values)==-EINVAL);
 CHECK(section(csv,"unknown",2,2,false,values)==-ENOENT);
 CHECK(section("h\n0x00,0x01,2,3,256\n","h",1,4096,true,values)==-ERANGE);
 CHECK(section("h\n0x00,0x01,2,3\n","h",1,4096,true,values)==-EINVAL);
 if(argc>1){
  FILE *f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);long n=ftell(f);rewind(f);
  char *data=calloc(n+1,1);assert(data);assert(fread(data,1,n,f)==(size_t)n);fclose(f);
  const char *keys[]={"unified_raw_limit","noise_data_limit","shortciurt_threshold","specail_raw_max","specail_raw_min","special_raw_delta","test_config","noise_config"};
  int rows[]={1,1,1,35,35,35,1,1}, cols[]={3,1,7,16,16,16,4096,4096};
  for(int i=0;i<8;i++){int expected=i<6?rows[i]*cols[i]:965;
   CHECK(section(data,keys[i],rows[i],cols[i],i>=6,values)==expected);}
  free(data);
 }
 printf("%d R10-Pruefungen bestanden.\n",tests);return 0;
#endif
}
