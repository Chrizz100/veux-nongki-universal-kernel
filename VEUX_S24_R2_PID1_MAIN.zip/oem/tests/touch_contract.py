"""Run the actual touch driver functions with controlled I/O and input-core returns."""
import argparse
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory


def function(text, name):
    match = re.search(r"^(?:static )?(?:long|int|void) " + name + r"\(.*?^\}", text, re.M | re.S)
    if match is None:
        raise ValueError(f"Missing driver function {name}")
    return match[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("tree", type=Path)
    args = parser.parse_args()
    root = args.tree / "drivers/input/touchscreen"
    goodix = (root / "goodix_gtx8/goodix_ts_core.c").read_text()
    definitions = (root / "goodix_gtx8/goodix_ts_core.h").read_text()
    api = (root / "xiaomi/xiaomi_touch.h").read_text()
    ioctl = (root / "xiaomi/xiaomi_touch.c").read_text()
    here = Path(__file__).resolve().parent
    with TemporaryDirectory() as directory:
        work = Path(directory)
        enums = api[api.index("#define VALUE_TYPE_SIZE"):api.index("struct xiaomi_touch {")]
        macros = []
        for key in ("GOODIX_MAX_TOUCH", "GOODIX_PEN_MAX_PRESSURE", "GTP_GAME_CMD_ADD",
                    "GTP_GAME_CMD_ENTER", "GTP_GAME_CMD_EXIT"):
            macros.append(re.search(r"^#define\s+" + key + r"\s+\S+", definitions, re.M)[0])
        (work / "interfaces.h").write_text(enums + "\n" + "\n".join(macros))
        names = ["goodix_ts_input_dev_config", "goodix_ts_pen_dev_config",
                 "goodix_ts_input_dev_remove", "goodix_ts_pen_dev_remove",
                 "gtp_set_cur_value", "gtp_get_mode_value", "gtp_get_mode_all", "gtp_reset_mode"]
        (work / "functions.h").write_text("\n\n".join(
            [function(goodix, name) for name in names] + [function(ioctl, "xiaomi_touch_dev_ioctl")]))
        exe = work / "touch-test"
        subprocess.run(["cc", "-std=gnu11", "-O2", "-Wall", "-Wno-unused-parameter",
                        "-I", str(work), str(here / "touch_contract.c"), "-o", str(exe)], check=True)
        subprocess.run([str(exe)], check=True)


if __name__ == "__main__":
    main()
