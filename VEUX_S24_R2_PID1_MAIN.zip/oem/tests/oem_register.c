#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint32_t u32;
#define __iomem
#define GFP_KERNEL 0
#define IORESOURCE_MEM 1
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x) = (v))
#define dev_dbg(...) ((void)0)
struct device { unsigned int tag; };
struct resource { uintptr_t start; };
struct platform_device { struct device dev; void *data; };
struct proc_dir_entry { void *data; };
struct inode { void *data; };
struct file { void *data; };
struct seq_file { void *private; char output[32]; };
struct file_operations { int (*open)(struct inode *, struct file *); void *read, *llseek, *release; };
static char seq_read, seq_lseek, single_release;
#define seq_read ((void *)&seq_read)
#define seq_lseek ((void *)&seq_lseek)
#define single_release ((void *)&single_release)
enum failure { NONE, RESOURCE, ALLOCATION, MAPPING, PROC };
static enum failure failure;
static struct resource resource;
static struct proc_dir_entry node;
static u32 hardware;
static unsigned int reads, removals;
static bool published;
static void *allocation;
static int (*show)(struct seq_file *, void *);

static struct resource *platform_get_resource_byname(struct platform_device *p, int type, const char *key)
{
    assert(p && type == IORESOURCE_MEM && !strcmp(key, REG_NAME));
    return failure == RESOURCE ? NULL : &resource;
}
static void *devm_kzalloc(struct device *d, size_t size, int flags)
{
    return failure == ALLOCATION ? NULL : (allocation = calloc(1, size));
}
static size_t resource_size(struct resource *r) { return sizeof(hardware); }
static void *devm_ioremap(struct device *d, uintptr_t start, size_t size)
{
    assert(size == sizeof(hardware));
    return failure == MAPPING ? NULL : &hardware;
}
static u32 __raw_readl(const void *ptr)
{
    assert(ptr == &hardware);
    reads++;
    return hardware;
}
static struct proc_dir_entry *proc_create_data(const char *name, int mode, void *parent,
                                               const struct file_operations *ops, void *data)
{
    assert(!strcmp(name, PROC_NAME) && mode == 0 && !parent && ops->open);
    assert(ops->read == seq_read && ops->llseek == seq_lseek && ops->release == single_release);
    if (failure == PROC) return NULL;
    node.data = data;
    published = true;
    return &node;
}
static void platform_set_drvdata(struct platform_device *p, void *d) { p->data = d; }
static void *platform_get_drvdata(struct platform_device *p) { return p->data; }
static void proc_remove(struct proc_dir_entry *e)
{
    assert(e == &node && published);
    published = false;
    removals++;
}
#define PDE_DATA(i) ((i)->data)
static int single_open(struct file *f, int (*fn)(struct seq_file *, void *), void *data)
{
    f->data = data;
    show = fn;
    return 0;
}
#define seq_printf(m,...) snprintf((m)->output,sizeof((m)->output),__VA_ARGS__)
#include "production.inc"

static void check_lifecycle(u32 value)
{
    struct platform_device p = {0};
    struct file file = {0};
    hardware = value;
    assert(PROBE(&p) == 0 && published);
    struct inode inode = {.data = node.data};
    assert(OPEN(&inode, &file) == 0 && file.data == p.data);
    struct seq_file seq = {.private = file.data};
    reads = 0;
    assert(show(&seq, NULL) == 0 && reads == 1);
    if (value) assert(!strcmp(seq.output, EXPECTED));
    hardware = 42;
    assert(show(&seq, NULL) == 0 && reads == (value ? 1U : 2U));
    assert(!strcmp(seq.output, EXPECTED));
    assert(REMOVE(&p) == 0 && !published);
    free(allocation);
    allocation = NULL;
}
int main(void)
{
    static const int expected[] = {0, -ENODEV, -ENOMEM, -ENOMEM, -ENOMEM};
    for (failure = RESOURCE; failure <= PROC; failure++) {
        struct platform_device p = {0};
        assert(PROBE(&p) == expected[failure]);
        assert(!published && !p.data && !reads && !removals);
        free(allocation);
        allocation = NULL;
    }
    failure = NONE;
    check_lifecycle(42);
    check_lifecycle(0);
    assert(removals == 2);
    printf("%s: four probe failures, two read/open/remove cycles passed\n", PROC_NAME);
    return 0;
}
