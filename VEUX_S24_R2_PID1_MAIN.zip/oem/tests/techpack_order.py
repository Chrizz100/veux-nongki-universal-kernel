"""Read the production Kbuild with both directions of directory enumeration."""
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

tree = Path(sys.argv[1]).resolve()
with TemporaryDirectory() as temp:
    tools = Path(temp)
    find = tools / "find"
    find.write_text("""#!/usr/bin/env python3
import os, sys
from pathlib import Path
root = Path(sys.argv[1])
assert root.name == "techpack"
items = sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith("."))
if os.environ["TEST_ORDER"] == "reverse":
    items.reverse()
for path in items:
    print(path)
""")
    find.chmod(0o755)
    makefile = "include $(srctree)/techpack/Kbuild\nall:\n\t@echo $(obj-y)\n"
    for order in ["forward", "reverse"]:
        env = {**os.environ, "PATH": str(tools)+":"+os.environ["PATH"], "TEST_ORDER": order}
        command = ["make", "--no-print-directory", "-f", "-", "srctree="+str(tree), "VEUX_STOCK_VENDOR_MODULES=y"]
        result = subprocess.check_output(command, input=makefile, env=env, text=True).split()
        expected = ["stub/", "video/", "dataipa/", "display/"]
        if result != expected:
            raise ValueError(f"{order}: {result}")
        print(order, *result)
