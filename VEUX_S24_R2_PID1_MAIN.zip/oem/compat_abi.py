"""Resolve every native and AArch32 syscall entry in the ELF-linked image and in Xiaomi's original Image."""
import csv
import re
import struct
from image_symbols import BASE,normal

def targets(kernel):
    raw = kernel.raw
    tables = [kernel.symbols[n] for n in ('sys_call_table','compat_sys_call_table')]
    count = 441
    fn = kernel.symbols['el0_svc_common']
    comparisons = {ins >> 10 & 4095 for (ins,) in struct.iter_unpack('<I',raw[fn:fn+260])
                   if ins & 0x7f00001f == 0x7100001f}
    if not {count-1,count} <= comparisons:
        raise ValueError('Syscall dispatch limit in '+kernel.name)
    reloc = {}
    if kernel.name=='Stock':
        for m in re.finditer(re.escape(struct.pack('<Q',1027)),raw):
            off,_,address = struct.unpack_from('<QQQ',raw,m.start()-8)
            if any(base<=off-BASE<base+count*8 for base in tables):
                reloc[off-BASE]=address-BASE
    resolved = []
    for table in tables:
        rows=[]
        for i in range(count):
            offset = table+i*8
            pc = reloc[offset] if kernel.name=='Stock' else struct.unpack_from('<Q',raw,offset)[0]-BASE
            for _ in range(2):
                word=struct.unpack_from('<I',raw,pc)[0]
                if word>>26 !=5:
                    break
                imm=word&0x3ffffff
                pc+=4*(imm-(1<<26) if imm&(1<<25) else imm)
            names = sorted(n for n in kernel.by_addr[pc] if not n.startswith(('__typeid_','$')) and not n.endswith('.cfi_jt'))
            if not names:
                raise ValueError(f'{kernel.name}: unresolved syscall {i} at {pc:x}')
            rows.append('|'.join(names))
        resolved.append(rows)
    return resolved

def compare(stock, candidate, dest):
    original, built = targets(stock), targets(candidate)
    with (dest/'Systemaufrufe-Stock.csv').open('w') as stream:
        writer=csv.writer(stream)
        writer.writerow(('ABI','Nummer','Xiaomi','Neubau'))
        for arch, a, b in zip(('arm64','compat'), original, built):
            writer.writerows((arch,i,x,y) for i,(x,y) in enumerate(zip(a,b,strict=True)))
    for bank,arch in enumerate(('arm64','compat')):
        if original[bank] != built[bank]:
            raise ValueError(f'{arch}: syscall mismatch at '+str([i for i,(a,b) in enumerate(zip(original[bank],built[bank])) if a!=b]))
    assert built[1][436]=='__arm64_sys_process_madvise' and built[1][440]=='__arm64_sys_ni_syscall'
    return {'native':len(built[0]),'compat':len(built[1]),'gleiche_Zielnamen':True}
