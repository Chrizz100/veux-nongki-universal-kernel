"""Give LLDB a read-only file view of the pinned, unmodified Xiaomi arm64 Image."""
from bisect import bisect_right
from hashlib import sha256
from pathlib import Path
import json
import struct
import sys

BASE=0xffffffc010080000
STOCK='6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
def symbols(b):
    if sha256(b).hexdigest()!=STOCK:raise ValueError('Xiaomi Image SHA-256 stimmt nicht')
    offsets,count,names,markers,tokens,index=0x18ee158,0x199d410,0x199d418,0x1d65e80,0x1d66978,0x1d66ca0
    n=struct.unpack_from('<I',b,count)[0];assert n==179372
    words=[]
    for rel in struct.unpack_from('<256H',b,index):
        a=tokens+rel;words.append(b[a:b.index(0,a,index)])
    rows=[];p=names
    for i in range(n):
        if i%256==0:assert struct.unpack_from('<I',b,markers+i//256*4)[0]==p-names
        l=b[p];p+=1;name=b''.join(words[j] for j in b[p:p+l]).decode();p+=l
        rows.append((struct.unpack_from('<I',b,offsets+4*i)[0],name[0],name[1:]))
    assert (p+7)&~7==markers and (4096,'T','_stext') in rows
    return rows

def make(src,dest,additional_verified_symbols=None):
    b=src.read_bytes();sy=symbols(b) if additional_verified_symbols is None else additional_verified_symbols;by={n:a for a,t,n in sy}
    code=[('.head.text',0,by['_stext']),('.text',by['_stext'],by['_etext']),
          ('.init.text',by['_sinittext'],by['_einittext'])]
    if '__alt_instructions' in by:
        # Each alternative table entry stores two signed displacement fields relative to their own addresses.
        alt_start=by['__alt_instructions'];alt_end=by['__alt_instructions_end'];alt_code_end=alt_end
        assert (alt_end-alt_start)%12==0
        for a in range(alt_start,alt_end,12):
            _,rel,_,_,size=struct.unpack_from('<iiHBB',b,a)
            t=a+4+rel
            if size and alt_end<=t<by['__initdata_begin']:alt_code_end=max(alt_code_end,t+size)
        assert alt_end<alt_code_end<=by['__initdata_begin']
        assert not any(b[alt_code_end:by['__initdata_begin']])
        code.extend([('.exit.text',by['__exittext_begin'],by['__exittext_end']),
                     ('.altinstr_replacement',alt_end,alt_code_end)])
    elif additional_verified_symbols is None:raise ValueError('Fehlende Abschnittsgrenzen im Xiaomi-Original')
    spans=[];p=0
    for name,start,end in code:
        if start>p:spans.append((f'.oem_data_{p:x}',p,start,False))
        spans.append((name,start,end,True));p=end
    spans.extend([(f'.oem_data_{p:x}',p,len(b),False),('.bss',len(b),by.get('_end',len(b)),False)])
    first=0x1000;sec=[(0,)*10];names=bytearray(b'\0');tab=bytearray(b'\0')
    def add(table,s):
        idx=len(table);table.extend(s.encode()+b'\0');return idx
    for name,start,end,x in spans:
        typ=8 if name=='.bss' else 1
        sec.append((add(names,name),typ,2|(4 if x else 0),BASE+start,first+start,end-start,0,0,4,0))
    starts=[v[1] for v in spans]
    loc=[];glob=[]
    for off,t,name in sy:
        i=bisect_right(starts,off)-1
        ref=i+1 if 0<=i<len(spans) and off<spans[i][2] else 0xfff1
        fun=ref!=0xfff1 and spans[i][3] and t.lower() in ('t','w')
        bind=1 if t.isupper() else 0
        row=struct.pack('<IBBHQQ',add(tab,name),bind*16+(2 if fun else 0),0,ref,BASE+off,0)
        (glob if bind else loc).append(row)
    packed=bytes(24)+b''.join(loc)+b''.join(glob)
    symsec=len(sec);strsec=symsec+1;namsec=symsec+2
    data=bytearray(first);data.extend(b)
    def append(blob,align=1):
        data.extend(bytes(-len(data)%align));pos=len(data);data.extend(blob);return pos
    pos=append(packed,8);sec.append((add(names,'.symtab'),2,0,0,pos,len(packed),strsec,1+len(loc),8,24))
    pos=append(tab);sec.append((add(names,'.strtab'),3,0,0,pos,len(tab),0,0,1,0))
    idx=add(names,'.shstrtab');pos=append(names);sec.append((idx,3,0,0,pos,len(names),0,0,1,0))
    pos=append(b''.join(struct.pack('<IIQQQQIIQQ',*s) for s in sec),8)
    ident=b'\x7fELF'+bytes([2,1,1])+bytes(9)
    struct.pack_into('<16sHHIQQQIHHHHHH',data,0,ident,2,183,1,BASE,64,pos,0,64,56,1,64,len(sec),namsec)
    struct.pack_into('<IIQQQQQQ',data,64,1,5,first,BASE,BASE,len(b),by.get('_end',len(b)),4096)
    assert data[first:first+len(b)]==b
    dest.write_bytes(data)
    return dict(base=hex(BASE),raw_sha256=sha256(b).hexdigest(),raw_bytes=len(b),raw_offset=first,elf_sha256=sha256(data).hexdigest(),
                kallsyms=len(sy),machine_code_ranges=[(n,hex(BASE+a),hex(BASE+z)) for n,a,z in code],
                source_lines='Keine OEM-DWARF-Zeilen im ausgelieferten arm64 Image. Die Symbolgroessen sind im Lese-ELF null.')
if __name__=='__main__':
    print(json.dumps(make(Path(sys.argv[1]),Path(sys.argv[2])),indent=2))
