"""Check return-value provenance in LLDB's word-verified AArch64 disassembly."""
import re
from paths import BASE, word


def instruction(assembly, pc):
    text = assembly[pc].split(";", 1)[0].strip().split(None, 1)
    return text[0], text[1].strip() if len(text) > 1 else ""


def require(test, message):
    if not test:
        raise ValueError(message)


def branch_address(operands):
    address, = re.findall(r"0x[0-9a-f]{8,}", operands)
    return int(address, 16) - BASE


def register(operand):
    match = re.fullmatch(r"[wx](\d+)", operand.strip())
    return int(match[1]) if match else None


def trace_return(kernel, assembly, fn, pc, markers, required, allowed_calls):
    """Follow a fixed error branch with an intact stack guard. Unknown operations fail."""
    start, end = kernel.ranges[fn]
    seen = set()
    calls = []
    while start <= pc < end and pc not in seen:
        seen.add(pc)
        op, args = instruction(assembly, pc)
        operands = [field.strip() for field in args.split(",")]
        dst = register(operands[0])
        if op == "ret":
            require(markers.get(0) == required, f"{fn}: return value lost at {BASE+pc:#x}")
            return {"ret": hex(BASE+pc), "calls": calls, "instructions": len(seen)}
        if op == "b":
            pc = branch_address(args)
            continue
        if op == "b.ne":
            guard = branch_address(args)
            require(instruction(assembly, guard)[0] == "bl" and
                    "__stack_chk_fail" in assembly[guard], f"{fn}: unexpected alternate path")
        elif op == "bl":
            called = next((n for n in allowed_calls if f"; {n} " in assembly[pc]), None)
            require(called, f"{fn}: unexpected call at {BASE+pc:#x}")
            calls.append(called)
            for scratch in range(19):
                markers.pop(scratch, None)
        elif op in ("mov", "sxtw"):
            old = markers.get(register(operands[1]))
            markers.pop(dst, None)
            if old:
                markers[dst] = "signed64" if op == "sxtw" else old
        elif op in ("ldr", "ldur", "ldp", "adrp", "add", "sub"):
            markers.pop(dst, None)
            if op == "ldp":
                markers.pop(register(operands[1]), None)
        else:
            require(op in ("cmp", "str", "strb", "stp", "nop"), f"{fn}: unknown instruction {op}")
        pc += 4
    raise ValueError(f"{fn}: error path did not return")


def check(kernel, assembly):
    ioctl = "xiaomi_touch_dev_ioctl"
    start, end = kernel.ranges[ioctl]
    ins = lambda pc: instruction(assembly, pc)
    # AArch64 switch dispatch: ADRP + ADD gives the byte table. Each table
    # entry is a 4-byte instruction offset from the address in ADR.
    dispatch, = (pc for pc in range(start, end, 4) if ins(pc)[0] == "br")
    base, index, add, adr, load, offset = range(dispatch-24, dispatch, 4)
    require(ins(index)[0] == "and" and "#0xff" in ins(index)[1] and
            ins(load)[0] == "ldrb" and "lsl #2" in ins(offset)[1], "ioctl dispatch layout")
    op = word(kernel, base)
    require(op & 0x9f000000 == 0x90000000 and ins(add)[0] == "add", "ioctl dispatch table")
    rel = ((op >> 5 & 0x7ffff) << 2) | (op >> 29 & 3)
    rel = rel - (1 << 21) if rel & (1 << 20) else rel
    table = ((BASE+base) & ~4095) + (rel << 12) + (word(kernel, add) >> 10 & 4095) - BASE
    origin = branch_address(ins(adr)[1])
    cases = [origin + 4 * n for n in kernel.raw[table:table+7]]
    require(len(cases) == 7 and all(start <= c < end for c in cases), "ioctl cases")
    setter = cases[0]
    require(ins(setter)[0] == "ldr" and "#0x1e0" in ins(setter)[1], "setter pointer after 20x6 integers")
    call = next(pc for pc in range(setter, end, 4) if ins(pc)[0] == "blr")
    require(ins(call)[1] == ins(setter)[1].split(",")[0] and ins(call-4) == ("ldp", "w0, w1, [sp, #0x4]"),
            "setter arguments")
    require(ins(call+4) == ("str", "w0, [sp]") and
            ins(call+8)[0] == "tbz" and ins(call+8)[1].startswith("w0, #0x1f,"), "setter signed status test")
    ioctl_trace = trace_return(kernel, assembly, ioctl, call+12, {0:"int32"}, "signed64", ["mutex_unlock"])
    require(ioctl_trace["calls"] == ["mutex_unlock"], "setter must unlock once on error")
    goodix = "gtp_set_cur_value"
    writes = kernel.direct_calls(goodix)["goodix_i2c_write"]
    require(len(writes) == 5, "five Goodix bus writes")
    bus = {}
    for index, at in enumerate(writes):
        pc = int(at,16) - BASE
        require(any(ins(p) == ("mov", f"w1, #{0x4160+index:#x}") for p in range(pc-20, pc, 4)),
                f"unexpected bus address at {at}")
        sign, operands = ins(pc+4)
        require(sign == "tbnz" and operands.startswith("w0, #0x1f,"), f"missing bus error branch {at}")
        trace = trace_return(kernel, assembly, goodix, branch_address(operands), {0:"int32"}, "int32", ["printk"])
        bus[at] = dict(register=hex(0x4160+index), **trace)
    arm = "goodix_ts_stage2_init"
    slots, = kernel.direct_calls(arm)["input_mt_init_slots"]
    site = int(slots,16) - BASE + 4
    op, args = ins(site)
    require(op == "cbnz" and args.startswith("w0,"), "multitouch slots error ignored")
    dest = branch_address(args)
    release_calls = {int(a,16)-BASE for a in kernel.direct_calls(arm)["input_free_device"]}
    pc = dest
    for _ in range(6):
        if pc in release_calls:
            break
        require(ins(pc)[0] in ("mov", "b"), "unexpected slot cleanup branch")
        pc = branch_address(ins(pc)[1]) if ins(pc)[0] == "b" else pc+4
    require(pc in release_calls, "missing release for rejected unregistered input device")
    return {"ioctl_cases": [hex(BASE+c) for c in cases], "setter_callback": hex(BASE+call),
            "setter_negative": ioctl_trace, "bus_negative": bus,
            "slot_setup": slots, "slot_error_cleanup": hex(BASE+pc)}
