# VEUX S24 für das POCO X4 Pro 5G R2

R2 bewahrt Androids ursprünglichen Init-Dateinamen, bis der Aufruf vollständig abgeschlossen ist. Der temporäre Name wird über die VFS-Funktion getname_kernel() angelegt und separat freigegeben. Vor dem Bauen laufen 20 Prüfungen mit dem tatsächlichen Quellcode für Erfolgsfälle, Rückfallpfade, Speicherfehler und Dateideskriptoren bis 1.000.000. Die Kompression der eingebetteten Kernelheader verwendet einen festgelegten XZ-Modus.

Für Android 13 und HyperOS Global OS1.0.12.0.TKCMIXM. Die Xiaomi-Kernelkennung lautet `5.4.274-qgki-g82179e362f33`. Der Build, die Prüfung der tatsächlichen ARM64-Dateien und die Tests des Paketierers wurden lokal ausgeführt. Der Hardwaretest für diesen neuen Stand steht aus.

## Reihenfolge

1. R11 mit Baumkennung `bc664e3178a2cddad6247940259442614bf9255f` wiederherstellen. Das Paket enthält die Git-Objekte, mit denen Git diesen Quellbaum aus der öffentlichen Xiaomi-Revision `61397e524093d1ccb94769b5460825e2eaf8871e` rekonstruiert. Der Bau benötigt kein altes GitHub-Actions-Artefakt. Für einen vorhandenen Originaldownload lässt sich mit `prepare.py base --archive` auch das geprüfte R11-Artefakt verwenden.
2. Den Kernelteil von midori01 SUSFS 2.4.0 auf die VEUX-QGKI-Basis anwenden. Der erste Bau prüft die ARM64-Objekte separat. BakaSU stellt anschließend die Kconfig-Optionen sowie die gegenseitigen Verweise für das vollständig gelinkte Image bereit.
3. BakaSU vom festgelegten Hauptzweig einbinden und mit den auf diese Kernelbasis angepassten Aufrufen aus Jacks Inline-Patch vollständig linken. Die originale Xiaomi-Prüfung von `nosuid` und `no_new_privs` bleibt am Ausführungspfad wirksam. Der Treiber verwendet den realen 32-Bit-Systemaufrufwert aus der konfigurierten Architekturtabelle. Der Kernelstart über ein bereits geöffnetes Kernel-Dateiobjekt verwendet den Xiaomi-Pfad. Der PID-1-Pfad behält den Namen bis zum Abschluss des Aufrufs. Ein fehlgeschlagener Preinit-Versuch kann einmal den originalen Init-Pfad versuchen.
4. NoMount zuletzt über das veröffentlichte Kconfig und Kbuild einbinden. Der verwendete Dev-Stand schließt den überprüften Master-Stand ein. Der VEUX-Bau übernimmt den Stackschutz der Kernelkonfiguration für den eingebauten Treiber. Die vollständigen Commit-IDs und die Prüfsummen stehen in `sources.json`.

## GitHub Actions

`VEUX_S24_MAIN.zip` gehört in das Hauptverzeichnis des Projekt-Repositories. `VEUX_S24_SUSFS_BAKASU_NOMOUNT.yml` gehört in `.github/workflows`. Der Workflow unterstützt den manuellen Start sowie Pushes mit den beiden Dateien auf `repair/veux-s24-sequenz`. GitHub baut die beiden vollständigen Stufen im selben Ausgabeverzeichnis. Der zweite Link kann so die vorhandenen Objektdateien und den ThinLTO-Cache weiterverwenden.

Der Workflow lädt den unveränderlichen Xiaomi-Quellstand, die Referenz aus der identischen Global-OTA sowie die festgelegten Entwicklerrevisionen. Er prüft das Bootpaar, die tatsächlichen Treiberaufrufe, die OEM-Schnittstellen, die ausführbaren Abschnitte und die Übereinstimmung mit dem lokalen Kontrollbuild. Die gesonderten lokalen Vergleiche mit den echten ConfigDiag10- und R11-Dateien stehen unter `referenz`. Ein abweichender GitHub-Kernel erhält eigene Sektionshashes. Die Vergleichswerte des lokalen Builds dürfen dann nicht als Ergebnis des neuen Binaries gelesen werden.

## Gerätetest und Prüfdateien

Das AK3 mit `GERAETETEST` im Namen enthält den Kernel für das Gerät und kann beim bewussten Start in einer kompatiblen Recovery den aktiven Boot-Slot schreiben. Es prüft zuerst, ob dieser Slot exakt das originale Global-Bootabbild enthält. Ein gepatchtes Bootabbild fällt durch diese Prüfung. Nach dem Schreiben liest es den Slot zurück. Bei einem während des Schreibens erkannten Fehler versucht es, die vorher überprüfte Kopie wiederherzustellen. Für den Fall eines Stromausfalls kann dieser Rückweg nicht zugesichert werden.

Das AK3 mit `NOFLASH` im Namen ist der schreibgeschützte Prüfer. Das separate `boot.img` enthält denselben Kernel und die originale Xiaomi-Ramdisk. Es gibt keine Hardwarebestätigung für Start, PIN, Touch oder Aufwachen dieses Builds. Das originale signierte Xiaomi-vbmeta enthält weiterhin den Hash des Original-Bootabbilds. Der geänderte Boot-Inhalt weicht davon ab. Die Pakete ändern keine separate vbmeta-Partition.

Die Quelldateien tragen ihre jeweiligen Lizenzhinweise. Für die hinzugefügten SUSFS-Dateien liegt die Projektlizenz unter `patches/SUSFS-LICENSE`. Die vollständigen Originalquellen von BakaSU und NoMount werden aus den in `sources.json` benannten Git-Revisionen geladen.
