"""Compare labelled, executable ranges from two genuine Image files at section-relative positions."""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import sys
from collections import Counter

from decode import sections
sys.path.insert(0,str(Path(__file__).resolve().parent/"oem"))
from image_symbols import normal,unpack
from stock_elf import symbols

def spans(raw,stock,ss):
    rows=symbols(raw) if stock else unpack(raw)
    names={}
    for a,t,name in rows:
        if t.lower() in ("t","w") and not name.startswith(("$","__typeid_")) and not name.endswith(".cfi_jt"):
            names.setdefault(a,set()).add(normal(name))
    result={}
    for section,start,end in ss:
        addresses=sorted(a for a in names if start<=a<end and a%4==0)
        for i,a in enumerate(addresses):
            e=addresses[i+1] if i+1<len(addresses) else end
            for name in names[a]:
                if name in result: result[name]=None
                else: result[name]=(a,e)
    return {n:span for n,span in result.items() if span is not None}

def compare(ref_elf,ref_image,new_elf,new_image,label):
    a=ref_image.read_bytes(); b=new_image.read_bytes()
    left=sections(ref_elf); right=sections(new_elf)
    left_map={n:(p,q) for n,p,q in left}
    result={}
    for n,r,s in right:
        if n not in left_map: continue
        p,q=left_map[n]
        length=min(q-p,s-r)
        aa=memoryview(a)[p:p+length].cast("I"); bb=memoryview(b)[r:r+length].cast("I")
        identical=sum(u==v for u,v in zip(aa,bb))
        result[n]={"reference_words":(q-p)//4,"candidate_words":(s-r)//4,"compared_words":length//4,
                   "identical_words":identical,"different_words":length//4-identical}
    fa=spans(a,label=="Stock",left); fb=spans(b,False,right)
    common=fa.keys()&fb.keys()
    exact=sum((fa[k][1]-fa[k][0]==fb[k][1]-fb[k][0]) and a[fa[k][0]:fa[k][1]]==b[fb[k][0]:fb[k][1]] for k in common)
    return {"reference_sha256":hashlib.sha256(a).hexdigest(),"candidate_sha256":hashlib.sha256(b).hexdigest(),
            "section_relative":result,"reference_sections_without_bounds":sorted({n for n,_,_ in right}-{n for n,_,_ in left}),
            "unique_common_text_symbols":len(common),"same_byte_span":exact,"different_byte_span":len(common)-exact,
            "method":"Fixed-offset words per common executable section. Function spans use unique common normalized symbols through the next symbol. Relocations, alignment, layout and the compiler affect these figures."}
if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ("reference_elf","reference_image","new_elf","new_image","output"):p.add_argument(arg,type=Path)
    p.add_argument("label")
    a=p.parse_args()
    a.output.write_text(json.dumps(compare(a.reference_elf,a.reference_image,a.new_elf,a.new_image,a.label),indent=2)+"\n")
