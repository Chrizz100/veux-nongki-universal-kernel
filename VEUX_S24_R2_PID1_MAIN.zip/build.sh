#!/usr/bin/env bash
# Build VEUX in three phases. Normal entry point for CI and local builds.
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
work=$(realpath -m "$1")
toolchain=$(realpath "$2")
stock=$(realpath "$3")
src="$work/src"
out="$work/out"
evidence="$work/evidence"
mkdir -p "$out" "$work/sus-out" "$evidence"
export KBUILD_BUILD_TIMESTAMP='Sat Nov 7 00:00:00 UTC 2026' SOURCE_DATE_EPOCH=1794009600
export KBUILD_BUILD_USER=veux-ci KBUILD_BUILD_HOST=github-actions KBUILD_BUILD_VERSION=1
export PYTHONDONTWRITEBYTECODE=1 XZ_OPT=-T1
build=(bash "$kit/oem/tools/kbuild.sh" "$src" "$out" "$toolchain")
susbuild=(bash "$kit/oem/tools/kbuild.sh" "$src" "$work/sus-out" "$toolchain")
python3 "$kit/prepare.py" susfs "$src"
cp "$kit/oem/kernel.config" "$work/sus-out/.config"
"${susbuild[@]}" olddefconfig
flags=$(awk -F= '/^CONFIG_KSU_SUSFS.*=y$/{printf "-D%s=1 ", $1}' "$kit/feature.config")
"${susbuild[@]}" CONFIG_KSU_SUSFS=y "KCFLAGS=$flags" fs/susfs.o
"${susbuild[@]}" CONFIG_KSU_SUSFS=y "KCFLAGS=$flags" fs/proc/cmdline.o
"$toolchain/bin/ld.lld" -r "$work/sus-out/fs/susfs.o" "$work/sus-out/fs/proc/cmdline.o" -o "$work/susfs-arm64.o"
test ! -e "$src/KernelSU" && test ! -e "$src/NoMount"
sha256sum "$work/susfs-arm64.o" >"$evidence/01-objects.sha256"

python3 "$kit/prepare.py" bakasu "$src"
python3 "$kit/preinit_test.py" "$src" "$evidence/PID1-Dateinamen.json"
cp "$kit/oem/kernel.config" "$out/.config"
"$src/scripts/config" --file "$out/.config" -e KSU -d KSU_MANUAL_HOOK -d KSU_TRACEPOINT_HOOK -e KSU_SUSFS
"${build[@]}" olddefconfig
"${build[@]}" headers
"${build[@]}" init/version.o
"${build[@]}" security/selinux/
"${build[@]}" Image
test -s "$out/drivers/kernelsu/preinit/runner.elf"
test "$(grep -c '^#define __NR_compat32_process_madvise ' "$out/drivers/kernelsu/compat/syscall_no.h")" = 1
grep -qx '#define __NR_compat32_process_madvise 436' "$out/drivers/kernelsu/compat/syscall_no.h"
test ! -e "$src/NoMount"
sha256sum "$out/arch/arm64/boot/Image" >"$evidence/02-linked.sha256"

python3 "$kit/prepare.py" nomount "$src"
"$src/scripts/config" --file "$out/.config" -e NOMOUNT
"${build[@]}" olddefconfig
cmp "$kit/feature.config" "$out/.config"
"${build[@]}" Image
for t in techpack_order touch_contract oem_contract r10_interfaces r11_interfaces; do
    python3 "$kit/oem/tests/$t.py" "$src" | tee "$evidence/$t.log"
done
python3 "$kit/oem/tests/display_contract.py" "$src" "$stock" | tee "$evidence/display_contract.log"
python3 "$kit/oem/proof.py" "$stock" "$out" "$evidence" --lldb "${LLDB:-lldb-19}" --objcopy "$toolchain/bin/llvm-objcopy"
python3 "$kit/feature_check.py" "$out" "$toolchain" "$evidence"
python3 "$kit/ak3_tools.py"
python3 "$kit/oem/pair.py" "$kit/oem/tools" "$stock" "$out/arch/arm64/boot/Image" "$work/pair"
python3 "$kit/recovery.py" "$work/pair" "$stock"
cp "$out/.config" "$evidence/kernel.config"
cp "$kit/sources.json" "$evidence/"
