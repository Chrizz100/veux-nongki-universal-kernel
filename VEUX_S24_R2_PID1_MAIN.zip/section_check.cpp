#include "lldb/API/LLDB.h"
#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

int main(int argc, char **argv) {
    if (argc != 4) return 2;
    try {
        constexpr uint64_t base = 0xffffffc010080000ULL;
        std::ifstream image(argv[2], std::ios::binary);
        std::ifstream ranges(argv[3]);
        if (!image || !ranges) throw std::runtime_error("Eingabe fehlt");
        lldb::SBDebugger::Initialize();
        auto debugger = lldb::SBDebugger::Create(false);
        debugger.SetAsync(false);
        lldb::SBError error;
        auto target = debugger.CreateTarget(argv[1], "aarch64-linux-gnu", nullptr, false, error);
        if (error.Fail() || !target.IsValid()) throw std::runtime_error("ELF-Ziel ungueltig");
        std::vector<uint8_t> data(16384), expected(data.size());
        std::string section;
        uint64_t lo, hi;
        while (ranges >> section >> std::hex >> lo >> hi) {
            uint64_t unknown = 0, words = 0;
            if ((lo | hi) % 4 || lo >= hi) throw std::runtime_error("Abschnittsgrenzen ungueltig");
            for (uint64_t offset = lo; offset < hi;) {
                size_t length = std::min<uint64_t>(data.size(), hi - offset);
                auto address = target.ResolveFileAddress(base + offset);
                auto size = target.ReadMemory(address, data.data(), length, error);
                if (error.Fail() || size != length) throw std::runtime_error("ELF-Lesefehler Offset " + std::to_string(offset));
                image.seekg(offset);
                image.read(reinterpret_cast<char *>(expected.data()), length);
                if (!image || std::memcmp(data.data(),expected.data(),length) != 0) throw std::runtime_error("ELF und Image verschieden");
                auto list = target.GetInstructions(address, data.data(), length);
                if (list.GetSize() != length / 4) throw std::runtime_error("Unvollstaendige Decoder-Ausgabe");
                for (size_t j = 0; j < list.GetSize(); ++j) {
                    auto instruction = list.GetInstructionAtIndex(j);
                    uint64_t here = offset+j*4;
                    if (instruction.GetByteSize() != 4 || instruction.GetAddress().GetFileAddress() != base+here)
                        throw std::runtime_error("Falsche Befehlsgrenze");
                    const char *op = instruction.GetMnemonic(target);
                    if (!op) op = "<undekodiert>";
                    if (*op == '.' || *op == '<' || !*op) ++unknown;
                    ++words;
                }
                offset += length;
            }
            std::fprintf(stderr, "%s %llx %llx %llu %llu\n", section.c_str(), (unsigned long long)lo,
                (unsigned long long)hi, (unsigned long long)words, (unsigned long long)unknown);
        }
        if (std::fflush(stdout) != 0) return 3;
        lldb::SBDebugger::Destroy(debugger);
        lldb::SBDebugger::Terminate();
    } catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
    return 0;
}
