#!/bin/sh
# Install the fully rendered, hash-verified boot image into the already selected slot.
set -eu
original=$1
candidate=$2
block=$3
slot=$4
stock_sha=$5
candidate_sha=$6

matches() {
    result=$(sha256sum "$1") || return 1
    [ "${result%% *}" = "$2" ]
}
case "$slot" in _a|_b) ;; *) exit 1 ;; esac
[ "${block##*/}" = "boot$slot" ] || exit 1
[ -f "$original" ] && [ -f "$candidate" ] || exit 1
[ -b "$block" ] || [ -f "$block" ] || exit 1
[ "$(wc -c <"$original")" -eq 134217728 ] || exit 1
[ "$(wc -c <"$candidate")" -eq 134217728 ] || exit 1
matches "$original" "$stock_sha" && matches "$candidate" "$candidate_sha" || exit 1
matches "$block" "$stock_sha" || exit 1

read_only=0
started=0
finish() {
    rc=$?
    trap - EXIT HUP INT TERM
    if [ "$started" = 1 ]; then
        if dd if="$original" of="$block" bs=1048576 conv=fsync &&
           matches "$block" "$stock_sha"; then
            echo "Originales Xiaomi-Bootabbild wiederhergestellt." >&2
        else
            echo "Wiederherstellung des Bootabbilds fehlgeschlagen." >&2
        fi
        rc=1
    fi
    if [ "$read_only" = 1 ]; then
        blockdev --setro "$block" || rc=1
    fi
    exit "$rc"
}
trap finish EXIT
trap 'exit 1' HUP INT TERM
if [ -b "$block" ]; then
    read_only=$(blockdev --getro "$block")
    if [ "$read_only" = 1 ]; then blockdev --setrw "$block"; fi
fi
started=1
dd if="$candidate" of="$block" bs=1048576 conv=fsync
matches "$block" "$candidate_sha"
started=0
