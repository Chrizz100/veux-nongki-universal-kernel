"""Verify Kbuild references, the linked ARM64 code, boot identity and privilege-related build options."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"oem"))
from image_symbols import BASE, gzconfig
from config_check import validate

HOOKS={
    "fs/exec.o":["ksu_handle_execveat","ksu_handle_execveat_sucompat","ksu_handle_post_execveat_sucompat","ksu_setup_preinit_file","ksu_preinit_handle_post_execveat"],
    "fs/read_write.o":["ksu_handle_sys_read"],
    "fs/open.o":["ksu_handle_faccessat"],
    "fs/stat.o":["ksu_handle_stat","ksu_handle_vfs_fstat"],
    "kernel/sys.o":["ksu_handle_setresuid"],
    "kernel/reboot.o":["ksu_handle_sys_reboot"],
    "drivers/input/input.o":["ksu_handle_input_handle_event"],
}
def verify(out,toolchain,dest):
    config=(out/".config").read_bytes()
    raw=(out/"arch/arm64/boot/Image").read_bytes()
    if gzconfig(raw)!=config: raise ValueError("IKCONFIG")
    delta=validate((HERE/"oem/kernel.config").read_bytes(),config)
    if (out/"include/config/kernel.release").read_text().strip()!="5.4.274-qgki-g82179e362f33":
        raise ValueError("VEUX release")
    if not all(tag in raw for tag in (b"v2.4.0",b"v4.2.0-rc3-57b2db60",b"23 (789)")):
        raise ValueError("Baked version fields")
    compat=(out/"drivers/kernelsu/compat/syscall_no.h").read_text()
    if re.findall(r"^#define __NR_compat32_process_madvise (\d+)$",compat,re.M)!=["436"]:
        raise ValueError("BakaSU compat syscall table")
    runner=(out/"drivers/kernelsu/preinit/runner.elf").read_bytes()
    if runner[:6]!=b"\x7fELF\x02\x01" or struct.unpack_from("<H",runner,18)[0]!=183 or raw.count(runner)!=1:
        raise ValueError("Embedded PID 1 preinit runner")
    edges={}
    for obj,names in HOOKS.items():
        undefined=subprocess.check_output([toolchain/"bin/llvm-nm","-u",out/obj],text=True)
        refs={line.split()[-1] for line in undefined.splitlines() if line.strip()}
        if set(names)-refs: raise ValueError(f"{obj} missing {set(names)-refs}")
        edges[obj]=names
    symbols={}
    for row in (out/"System.map").read_text().splitlines():
        pc,kind,name=row.split()
        if kind in "tTwW": symbols[name]=int(pc,16)
    targets=sorted({name for names in edges.values() for name in names} |
                   {"kernelsu_init","susfs_init","nomount_init","nm_key_preparse","do_execveat_common","__do_execve_file"})
    commands=['settings set use-color false','target create --arch aarch64 "'+str((out/'vmlinux').resolve())+'"']
    for name in targets:
        if name not in symbols: raise ValueError(f"Missing text symbol {name}")
        commands.append(f"disassemble --bytes --start-address 0x{symbols[name]:x} --count 4")
    dest.mkdir(parents=True,exist_ok=True)
    script=dest/"feature.lldb"; script.write_text("\n".join(commands)+"\n")
    log=subprocess.check_output([os.environ.get("LLDB","lldb-19"),"--no-lldbinit","--batch","-s",script],text=True,stderr=subprocess.STDOUT)
    (dest/"Features-LLDB.txt").write_text(log)
    words={int(p,16):int(v,16) for p,v in re.findall(r"^\S+\[0x([0-9a-f]+)\]\s+<[^>]*>:\s+(0x[0-9a-f]{8})",log,re.M)}
    for name in targets:
        for pc in range(symbols[name],symbols[name]+16,4):
            if words.get(pc)!=struct.unpack_from("<I",raw,pc-BASE)[0]: raise ValueError("LLDB mismatch: "+name)
    result={"kernel_sha256":hashlib.sha256(raw).hexdigest(),"symbols":{n:hex(symbols[n]) for n in targets},
            "kbuild_caller_references":edges,"lldb_words_checked":len(words),"embedded_preinit_bytes":len(runner),
            "preinit_sha256":hashlib.sha256(runner).hexdigest(),"compat_process_madvise":436,"config_delta":delta,
            "device_pass":False}
    (dest/"Features.json").write_text(json.dumps(result,indent=2)+"\n")
    print(f"{len(targets)} linked functions, {len(words)} debugger-checked words")
if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__)
    for n in ("out","toolchain","dest"):p.add_argument(n,type=Path)
    verify(**vars(p.parse_args()))
