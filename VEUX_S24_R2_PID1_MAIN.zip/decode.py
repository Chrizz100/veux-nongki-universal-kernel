"""Byte-check and decode all file-backed executable sections declared by an input ELF."""
import argparse
from pathlib import Path
import subprocess
import struct
import hashlib
import json

BASE = 0xffffffc010080000
def sections(elf):
    with elf.open("rb") as f:
        hdr=f.read(64)
        if hdr[:6] != b"\x7fELF\x02\x01" or struct.unpack_from("<H",hdr,18)[0] != 183:
            raise ValueError("ARM64 ELF required")
        off=struct.unpack_from("<Q",hdr,40)[0]
        step,count,index=struct.unpack_from("<HHH",hdr,58)
        f.seek(off)
        headers=[struct.unpack("<IIQQQQIIQQ",f.read(step)) for _ in range(count)]
        f.seek(headers[index][4]); strings=f.read(headers[index][5])
    return [(strings[n:strings.index(0,n)].decode(),a-BASE,a-BASE+size)
            for n,t,fl,a,_,size,*_ in headers if fl & 4 and t==1 and size]

def decode(tool,elf,image,output,label):
    output.mkdir(parents=True,exist_ok=True)
    spans=sections(elf)
    if not spans:
        raise ValueError("Missing executable data")
    ranges=output/(label+"-addresses.txt")
    ranges.write_text("".join(f"{n} {a:x} {e:x}\n" for n,a,e in spans))
    proc=subprocess.run([tool.resolve(),elf.resolve(),image.resolve(),ranges.resolve()],stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True)
    if proc.returncode:
        raise RuntimeError(proc.stderr[-1600:])
    rows=[r.split() for r in proc.stderr.splitlines() if r.startswith(".")]
    report={}
    with image.open("rb") as f:
        for (n,a,e),r in zip(spans,rows,strict=True):
            if r[:3]!=[n,f"{a:x}",f"{e:x}"] or int(r[3])!=(e-a)//4: raise ValueError(r)
            f.seek(a)
            report[n]=dict(offset=a,bytes=e-a,words=int(r[3]),undecoded_or_data=int(r[4]),sha256=hashlib.sha256(f.read(e-a)).hexdigest())
    (output/(label+"-LLDB-sections.json")).write_text(json.dumps(report,indent=2)+"\n")
    print(label, sum(r["words"] for r in report.values()), "ARM64 words verified and decoded",flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    for n in ("tool","elf","image","output"): parser.add_argument(n,type=Path)
    parser.add_argument("label")
    args=parser.parse_args(); decode(**vars(args))
