#!/usr/bin/env python3
"""Offline R33 boot-DTB provenance comparison, strictly non-flashable.

Input: SHA-pinned R28/R30/R32 evidence and optionally a fresh R33 device metadata ZIP.
No kernel build or installed binaries are required. No source patches are produced.
"""
import argparse
import csv
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import sys
import zipfile

# Let the standard-library-only device FDT parser be reused for the pinned R20 DTB.
from VEUX_R33_CAPTURE_GERAET import fdt_root_metadata

SCHEMA = 'VEUX_R33_DTB_VENDORBOOT_PROVENANCE_GATE_V1'
DEVICE_SCHEMA = 'VEUX_R33_DEVICE_DTB_PROVENANCE_V1'
SOURCE_FILES = {
    'evidence/R32_RESULT.json',
    'evidence/R30_RESULT.json',
    'evidence/R28_DEVICE_EVIDENCE.json',
    'evidence/R20_VEUX.dtb',
}
REPORT_FILES = ('R33_RESULT.json','R33_BERICHT_DE.txt','R33_DTB_MATRIX.csv','SHA256SUMS.txt')


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def checked_json(blob):
    obj=json.loads(blob)
    if not isinstance(obj,dict): raise ValueError('JSON_OBJECT_REQUIRED')
    return obj


def verify_manifest(base):
    manifest=checked_json((base/'MANIFEST_SHA256.json').read_bytes())
    files=manifest.get('files')
    if not isinstance(files,dict) or len(files)<5: raise ValueError('INVALID_MANIFEST')
    want=set(files)|{'MANIFEST_SHA256.json'}
    found={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if want!=found: raise ValueError('MANIFEST_CONTENT_SET_MISMATCH')
    for name,meta in files.items():
        p=base/name
        if not p.is_file() or p.is_symlink() or '..' in p.parts or p.is_relative_to(base) is False:
            raise ValueError('UNSAFE_MANIFEST_MEMBER')
        b=p.read_bytes()
        if len(b)!=meta['bytes'] or sha(b)!=meta['sha256']:
            raise ValueError('HASH_MISMATCH:'+name)
    if not SOURCE_FILES <= found:
        raise ValueError('MISSING_REFERENCE_FILES')
    return manifest


def reference_values(base):
    r32=checked_json((base/'evidence/R32_RESULT.json').read_bytes())
    r30=checked_json((base/'evidence/R30_RESULT.json').read_bytes())
    r28=checked_json((base/'evidence/R28_DEVICE_EVIDENCE.json').read_bytes())
    dtb=(base/'evidence/R20_VEUX.dtb').read_bytes()
    if r32['audit_status'] != 'PASS_STATIC_PROVENANCE_WITH_BOOT_BLOCKERS' or r32['r20_all_six_module_imports']!=307 or r32['boot_ready'] is not False or r32['flash_allowed'] is not False or r32['other_vendor_modules_abi_proven'] is not False:
        raise ValueError('R32_STATIC_PROVENANCE_NOT_AUTHENTICATED')
    d=r32['dtb']
    if len(dtb)!=d['bytes'] or sha(dtb)!=d['sha256']:
        raise ValueError('R20_DTB_NOT_ORIGINAL')
    meta=fdt_root_metadata(dtb)
    if 'qcom,blair' not in meta['root'].get('compatible',[]):
        raise ValueError('R20_DTB_EXPECTED_SOC_MISSING')
    if r30.get('schema')!='VEUX_R30_VENDOR_BOOT_MODULE_PROVENANCE_V1' or r28.get('schema')!='VEUX_R28_DEVICE_CAPTURE_V1':
        raise ValueError('HISTORIC_SCHEMA_MISMATCH')
    expected_size={r['partition']:r.get('header',{}).get('dtb_size') for r in r30['vendor_boot']}
    if not all(expected_size.get(p)==651045 for p in ('vendor_boot_a','vendor_boot_b')):
        raise ValueError('R30_VENDOR_BOOT_DTB_SIZE_CHANGED')
    if r28['kernel_release'] != r32['device']['kernel_release'] or r28['boot_active_slot_reported']!=r32['device']['reported_active_slot']:
        raise ValueError('HISTORIC_DEVICE_IDENTITY_MISMATCH')
    return {'r20_dtb':meta,'r20_dtb_sha':d['sha256'],'r20_dtb_size':d['bytes'],
            'kernel_release':r28['kernel_release'],'historical_slot':r28['boot_active_slot_reported'],
            'r30_dtb_size_by_partition':expected_size,'r32_import_count':307,
            'r20_kernel_banner':r32['image']['kernel_banner'],
            'r30_loader_observed':r32['r30_device_module_loader_observed']}


def load_device_zip(path):
    data=Path(path).read_bytes()
    if len(data)>3_000_000: raise ValueError('DEVICE_ZIP_TOO_LARGE')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if z.testzip() is not None: raise ValueError('DEVICE_ZIP_BAD_CRC')
        inf=z.infolist()
        expected={'R33_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'}
        if len(inf)!=3 or {x.filename for x in inf} != expected:
            raise ValueError('DEVICE_ZIP_UNEXPECTED_MEMBERS')
        for item in inf:
            if item.is_dir() or stat.S_ISLNK(item.external_attr>>16) or item.file_size>2_000_000:
                raise ValueError('DEVICE_ZIP_UNSAFE_MEMBER')
        manifest={}
        for ln in z.read('SHA256SUMS.txt').decode().splitlines():
            part=ln.split('  ',1)
            if len(part)!=2 or not re.fullmatch(r'[0-9a-f]{64}',part[0]):
                raise ValueError('DEVICE_SHA_MANIFEST_INVALID')
            manifest[part[1]]=part[0]
        if set(manifest)!=expected-{'SHA256SUMS.txt'}:
            raise ValueError('DEVICE_SHA_SET_INVALID')
        for name,digest in manifest.items():
            if sha(z.read(name))!=digest:
                raise ValueError('DEVICE_INTERNAL_SHA_MISMATCH')
        device=checked_json(z.read('R33_DEVICE_EVIDENCE.json'))
    if device.get('schema')!=DEVICE_SCHEMA or device.get('read_only') is not True:
        raise ValueError('DEVICE_SCHEMA_OR_SAFETY_MISMATCH')
    if device.get('reported_active_slot') not in ('_a','_b') or not re.fullmatch(r'[A-Za-z0-9._+~:-]{3,160}',device.get('kernel_release','')):
        raise ValueError('DEVICE_SLOT_OR_RELEASE_INVALID')
    vendor=device.get('vendor_boot')
    overlays=device.get('dtbo')
    if not isinstance(vendor,list) or sorted(x.get('partition') for x in vendor)!=['vendor_boot_a','vendor_boot_b']:
        raise ValueError('DEVICE_VENDOR_BOOT_PARTITIONS_MISSING')
    if not isinstance(overlays,list) or sorted(x.get('partition') for x in overlays)!=['dtbo_a','dtbo_b']:
        raise ValueError('DEVICE_DTBO_PARTITIONS_MISSING')
    return device


def compare(ref,device):
    findings=[]
    if device is None:
        return {'report_status':'WAITING_FOR_CURRENT_DEVICE_CAPTURE','fresh_capture':False,
                'board_soc_compatible_observed':False,'r20_dtb_byte_match':False,
                'active_vendor_boot_dtb_read':False,'active_dtbo_table_read':False,
                'matrix':[], 'warnings':['Kein aktuelles VEUX_R33_DEVICE_EVIDENCE.zip im GitHub-Root vorhanden'],
                'blockers':['Aktuelle DTB-/DTBO-Metadaten fehlen; Boot-/Vendor-ABI weiterhin unbewiesen']}
    warnings=list(device.get('warnings',[]))
    blockers=[]
    if device['kernel_release']!=ref['kernel_release']:
        blockers.append('Kernelkennung seit R28 abweichend: historische Nachweise nicht ohne Weiteres anwendbar')
    if device['reported_active_slot']!=ref['historical_slot']:
        blockers.append('Aktiver Boot-Slot seit R28 gewechselt; alte Referenzen ggf. veraltet')
    active_slot=device['reported_active_slot'][-1]
    active_vendor=next(v for v in device['vendor_boot'] if v['partition'].endswith(active_slot))
    active_dtbo=next(v for v in device['dtbo'] if v['partition'].endswith(active_slot))
    vendor_ready=active_vendor.get('status')=='PARSED' and bool(active_vendor.get('dtbs'))
    dtbo_ready=active_dtbo.get('status')=='PARSED' and bool(active_dtbo.get('entries'))
    if not vendor_ready: blockers.append('Aktiver vendor_boot-DTB-Bereich nicht vollständig validiert')
    if not dtbo_ready: blockers.append('Aktive DTBO-Tabelle nicht vollständig validiert')
    if active_vendor.get('dtb_section_size')!=ref['r30_dtb_size_by_partition'][active_vendor['partition']]:
        blockers.append('vendor_boot DTB-Bereich unterscheidet sich von R30 (651045 Byte)')
    r20_compat=set(ref['r20_dtb']['root'].get('compatible',[]))
    seen_soc=False
    byte_match=False
    for item in device['vendor_boot']:
        for dtb in item.get('dtbs',[]):
            compatible=set(dtb.get('root',{}).get('compatible',[]))
            overlap=sorted(r20_compat & compatible)
            if item['partition']==active_vendor['partition'] and overlap: seen_soc=True
            if item['partition']==active_vendor['partition'] and dtb.get('sha256')==ref['r20_dtb_sha']: byte_match=True
            findings.append({'partition':item['partition'],'kind':'vendor_boot_dtb','index_or_offset':dtb.get('offset',''),
                             'sha256':dtb.get('sha256',''),'compatible_common':';'.join(overlap),
                             'exact_r20_dtb':str(dtb.get('sha256')==ref['r20_dtb_sha'])})
    for item in device['dtbo']:
        for ent in item.get('entries',[]):
            compatible=set(ent.get('fdt',{}).get('root',{}).get('compatible',[]))
            overlap=sorted(r20_compat & compatible)
            findings.append({'partition':item['partition'],'kind':'dtbo_overlay','index_or_offset':ent.get('index',''),
                             'sha256':ent.get('sha256',''),'compatible_common':';'.join(overlap),
                             'exact_r20_dtb':str(ent.get('sha256')==ref['r20_dtb_sha'])})
    if vendor_ready and not seen_soc:
        blockers.append('Kein SoC-compat-Treffer zwischen aktivem vendor_boot und R20 (qcom,blair)')
    if not byte_match:
        blockers.append('Keine bytegenaue Uebereinstimmung zwischen aktivem vendor_boot-DTB und R20-DTB')
    blockers.extend([
        'DTBO-Auswahl des Bootloaders ist nicht nachgewiesen; keine Overlay-Kompatibilitaetsfreigabe',
        'R20- und Geraete-Kernelkonfiguration/Kernelkennung weichen weiterhin ab',
        'Gesamte ROM-/Vendor-Modul-ABI nicht validiert (nur R20-eigene sechs Module: 307/307)',
        'Alter 2EF0-RMNET-Loader nicht auf R20-Modulpaare umgestellt oder getestet',
        'Keine echten Boot-/SELinux-/VINTF-/BakaSU-/SUSFS-/NoMount-Tests'
    ])
    return {'report_status':'DEVICE_CAPTURE_ANALYZED_WITH_BOOT_BLOCKERS',
            'fresh_capture':True,'board_soc_compatible_observed':seen_soc,
            'r20_dtb_byte_match':byte_match,'active_vendor_boot_dtb_read':vendor_ready,
            'active_dtbo_table_read':dtbo_ready,'matrix':findings,
            'warnings':warnings,'blockers':blockers}


def save_result(reference,comparison,outdir):
    p=Path(outdir)
    p.mkdir(parents=True,exist_ok=True)
    result={'schema':SCHEMA,'status':comparison['report_status'],
        'read_only':True,'reference_kernel_run':39910955809,'r32_green_run':40018409566,
        'reference_r20_dtb_sha256':reference['r20_dtb_sha'],
        'reference_r20_dtb_compatible':reference['r20_dtb']['root'].get('compatible',[]),
        'r20_internal_six_modules_matching_imports':307,
        'r33_device_capture_present':comparison['fresh_capture'],
        'vendor_boot_dtb_parsed_active':comparison['active_vendor_boot_dtb_read'],
        'dtbo_table_parsed_active':comparison['active_dtbo_table_read'],
        'soc_compatible_overlap_observed':comparison['board_soc_compatible_observed'],
        'exact_dtb_byte_match_observed':comparison['r20_dtb_byte_match'],
        'vendor_abi_proven':False,'boot_ready':False,'source_patch_created':False,
        'kernel_built':False,'device_modified':False,'flash_allowed':False,
        'blockers':comparison['blockers'],'warnings':comparison['warnings'],
        'limitations':['FDT root compatible alone cannot prove board/overlay match',
                       'Device JSON is a self-reported capture, not cryptographic attestation',
                       'No complete vendor module ABI validation'],
    }
    (p/'R33_RESULT.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    columns=['partition','kind','index_or_offset','sha256','compatible_common','exact_r20_dtb']
    with (p/'R33_DTB_MATRIX.csv').open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,columns);w.writeheader();w.writerows(comparison['matrix'])
    report=(f"VEUX R33 – DTB/DTBO/Vendor-Boot Quellenvergleich (READ ONLY)\n"
            f"Befund: {comparison['report_status']}\n"
            f"R20 DTB SHA256: {reference['r20_dtb_sha']}\n"
            f"R20 DTB compatible: {', '.join(reference['r20_dtb']['root'].get('compatible',[]))}\n"
            f"R20 Eigenmodule: 307/307 CRC-Importe stimmen mit R20-Symvers ueberein\n"
            f"Frische Geraetedaten: {'JA' if comparison['fresh_capture'] else 'NEIN'}\n"
            f"Aktives vendor_boot DTB gelesen: {'JA' if comparison['active_vendor_boot_dtb_read'] else 'NEIN'}\n"
            f"Aktives DTBO gelesen: {'JA' if comparison['active_dtbo_table_read'] else 'NEIN'}\n"
            f"qcom,blair SoC-kompatibel beobachtet: {'JA' if comparison['board_soc_compatible_observed'] else 'NEIN'}\n"
            f"Exakte R20-DTB-Byteidentitaet: {'JA' if comparison['r20_dtb_byte_match'] else 'NEIN'}\n\n"
            'OFFENE SPERRGRUENDE:\n'+'\n'.join('- '+x for x in comparison['blockers'])+'\n\n'
            'KEIN Kernelbuild, KEIN Flash, KEINE Bootfreigabe, KEINE BReNE-Aenderung.\n')
    (p/'R33_BERICHT_DE.txt').write_text(report)
    hashes=''.join(sha((p/n).read_bytes())+'  '+n+'\n' for n in REPORT_FILES if n!='SHA256SUMS.txt')
    (p/'SHA256SUMS.txt').write_text(hashes)
    return result


def main(argv=None):
    ap=argparse.ArgumentParser()
    ap.add_argument('--bundle',required=True)
    ap.add_argument('--device-zip')
    ap.add_argument('--out',required=True)
    args=ap.parse_args(argv)
    base=Path(args.bundle)
    try:
        verify_manifest(base)
        ref=reference_values(base)
        device=load_device_zip(args.device_zip) if args.device_zip else None
        compare_data=compare(ref,device)
        result=save_result(ref,compare_data,args.out)
    except (ValueError,KeyError,TypeError,RuntimeError,FileNotFoundError,zipfile.BadZipFile) as e:
        print('R33_INPUT_GATE=FAIL:',e,file=sys.stderr)
        return 2
    print(f"R33_AUDIT=PASS; RESULT={result['status']}; "
          f"MODULE_CRC=307/307; VENDOR_ABI=UNPROVEN; BOOT=NO; FLASH=NO")
    return 0


if __name__=='__main__':
    sys.exit(main())
