#!/usr/bin/env python3
"""VEUX R33: read-only active device-tree/DTBO/vendor_boot provenance capture.

Output: /sdcard/Download/VEUX_R33_DEVICE_EVIDENCE.zip
Only whitelisted partition reads and whitelisted kernel metadata. No flash, no mount,
no modprobe/insmod, no partition or module bytes in the ZIP. Requires root for
partition access. Values are device-reported evidence, not remote attestation.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import struct
import subprocess
import sys
import zipfile

SCHEMA = 'VEUX_R33_DEVICE_DTB_PROVENANCE_V1'
OUTPUT_NAME = 'VEUX_R33_DEVICE_EVIDENCE.zip'
FDT_MAGIC = 0xD00DFEED
DTBO_MAGIC = 0xD7B7AB1E
MAX_FDT = 6 * 1024 * 1024
MAX_DTBO = 24 * 1024 * 1024
MAX_DTB_SECTION = 16 * 1024 * 1024
VENDOR_PARTITIONS = ('vendor_boot_a', 'vendor_boot_b')
OVERLAY_PARTITIONS = ('dtbo_a', 'dtbo_b')
ALLOW_PROPS = {'model','compatible','qcom,board-id','qcom,msm-id','qcom,pmic-id', 'qcom,platform-id'}
MODULE_LISTS = (
 '/vendor/lib/modules/modules.load', '/vendor/lib/modules/5.4-gki/modules.load',
 '/vendor/etc/modules.load', '/vendor_dlkm/etc/modules.load',
 '/vendor_dlkm/lib/modules/modules.load', '/odm/etc/modules.load',
 '/odm_dlkm/etc/modules.load', '/odm_dlkm/lib/modules/modules.load',
 '/system_dlkm/etc/modules.load', '/system_dlkm/lib/modules/modules.load',
)


def digest(b):
    return hashlib.sha256(b).hexdigest()


def run(argv, timeout=25, limit=1_000_000):
    try:
        p = subprocess.run(argv, check=False, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if p.returncode or len(p.stdout) > limit:
        return None
    return p.stdout


def root_read(path, limit=1_000_000):
    if path not in MODULE_LISTS and path not in ('/sys/firmware/fdt',
        '/proc/device-tree/compatible','/proc/device-tree/model',
        '/sys/firmware/devicetree/base/compatible','/sys/firmware/devicetree/base/model',
        '/proc/modules','/proc/sys/kernel/osrelease'):
        raise ValueError('PATH_NOT_ALLOWED')
    return run(['su','-c','cat '+shlex.quote(path)], limit=limit)


def partition_window(name, offset, length):
    if name not in (*VENDOR_PARTITIONS, *OVERLAY_PARTITIONS):
        raise ValueError('PARTITION_NOT_WHITELISTED')
    if not 0 <= offset <= 64 * 1024 * 1024 or not 0 < length <= MAX_DTBO or offset + length > 96 * 1024 * 1024:
        raise ValueError('INVALID_PARTITION_READ_RANGE')
    bs = 4096
    block, displacement = divmod(offset, bs)
    count = (displacement + length + bs - 1) // bs
    cmd = f'dd if={shlex.quote("/dev/block/by-name/" + name)} bs=4096 skip={block} count={count} 2>/dev/null'
    data = run(['su','-c',cmd], timeout=80, limit=count * bs + 32)
    if data is None or len(data) < displacement + length:
        raise ValueError('PARTITION_WINDOW_READ_FAILED')
    return data[displacement:displacement + length]


def aligned(n, page):
    return (n + page - 1) // page * page


def _strings(b):
    return [s.decode('utf-8', 'replace')[:140] for s in b.split(b'\0') if s][:14]


def fdt_root_metadata(blob):
    if len(blob) < 40:
        raise ValueError('FDT_TOO_SHORT')
    hdr = struct.unpack_from('>10I', blob, 0)
    magic, total, off_struct, off_strings, off_mem, version, last, boot_cpuid, size_strings, size_struct = hdr
    if magic != FDT_MAGIC or not 40 <= total <= len(blob) or total > MAX_FDT:
        raise ValueError('FDT_INVALID_MAGIC_OR_TOTAL')
    if not (40 <= off_mem < total and 40 <= off_struct < total and 40 <= off_strings < total and
            off_struct + size_struct <= total and off_strings + size_strings <= total):
        raise ValueError('FDT_INVALID_OFFSETS')
    strings = blob[off_strings:off_strings + size_strings]
    end = off_struct + size_struct
    pos, depth, node_count, root_props, ended = off_struct, 0, 0, {}, False
    while pos + 4 <= end:
        tok = struct.unpack_from('>I', blob, pos)[0]
        pos += 4
        if tok == 1:  # FDT_BEGIN_NODE
            limit = blob.find(b'\0', pos, end)
            if limit == -1: raise ValueError('FDT_UNTERMINATED_NODE')
            pos = aligned(limit + 1, 4)
            depth += 1
            node_count += 1
            if depth > 80 or node_count > 50000: raise ValueError('FDT_NODE_LIMIT')
        elif tok == 2:
            depth -= 1
            if depth < 0: raise ValueError('FDT_UNBALANCED')
        elif tok == 3:
            if pos + 8 > end: raise ValueError('FDT_TRUNCATED_PROP')
            size, nameoff = struct.unpack_from('>II',blob,pos)
            pos += 8
            if size > MAX_FDT or nameoff >= len(strings) or pos + size > end:
                raise ValueError('FDT_PROP_BOUNDS')
            nend = strings.find(b'\0',nameoff)
            if nend == -1: raise ValueError('FDT_PROP_UNTERMINATED_NAME')
            name = strings[nameoff:nend].decode('ascii','replace')
            if depth == 1 and name in ALLOW_PROPS:
                value = blob[pos:pos + size]
                if name in ('model','compatible'):
                    root_props[name] = _strings(value)
                elif len(value) % 4 == 0 and len(value) <= 64:
                    root_props[name] = [f'0x{x:08x}' for x in struct.unpack('>' + 'I' * (len(value)//4),value)]
            pos = aligned(pos + size, 4)
        elif tok == 4:
            pass
        elif tok == 9:
            ended = True
            break
        else:
            raise ValueError('FDT_UNEXPECTED_TOKEN')
    if not ended or depth != 0:
        raise ValueError('FDT_MISSING_END_OR_UNBALANCED')
    return {'bytes':total,'sha256':digest(blob[:total]),'version':version,
            'nodes':node_count,'root':root_props,'parsed':True}


def fdt_sequence(blob, max_entries=48):
    found=[];pos=0
    while pos+40<=len(blob) and len(found)<max_entries:
        offset = blob.find(b'\xd0\x0d\xfe\xed',pos)
        if offset == -1: break
        try:
            ent = fdt_root_metadata(blob[offset:])
        except ValueError:
            pos = offset + 4
            continue
        found.append({'offset':offset,**ent})
        pos = aligned(offset + ent['bytes'],4)
    return found


def parse_vendor_boot_dtb(name):
    answer={'partition':name,'status':'UNAVAILABLE','dtbs':[]}
    try:
        header = partition_window(name,0,4096)
        if header[:8]!=b'VNDRBOOT': raise ValueError('VENDOR_BOOT_MAGIC')
        version,page_size = struct.unpack_from('<II',header,8)
        ramdisk_bytes=struct.unpack_from('<I',header,24)[0]
        header_size=struct.unpack_from('<I',header,2096)[0]
        dtb_size=struct.unpack_from('<I',header,2100)[0]
        if version not in (3,4) or page_size not in (2048,4096,8192,16384) or not 2112<=header_size<=page_size*2:
            raise ValueError('VENDOR_BOOT_INVALID_HEADER')
        if not 0<dtb_size<=MAX_DTB_SECTION or ramdisk_bytes>96*1024*1024:
            raise ValueError('VENDOR_BOOT_INVALID_DTB_SECTION')
        offset=aligned(header_size,page_size)+aligned(ramdisk_bytes,page_size)
        content=partition_window(name,offset,dtb_size)
        parsed=fdt_sequence(content)
        answer.update({'header_version':version,'page_size':page_size,'ramdisk_bytes':ramdisk_bytes,
                      'dtb_section_size':dtb_size,'dtb_section_sha256':digest(content),
                      'dtb_section_offset':offset,'dtbs':parsed,
                      'status':'PARSED' if parsed else 'NO_VALID_FDT_FOUND'})
    except (ValueError,struct.error) as e:
        answer.update({'status':'READ_OR_FORMAT_ERROR','reason':str(e)[:120]})
    return answer


def parse_dtbo(name):
    answer={'partition':name,'status':'UNAVAILABLE','entries':[]}
    try:
        head=partition_window(name,0,4096)
        if len(head)<32: raise ValueError('DTBO_HEADER_SHORT')
        magic,total,header_size,entry_size,entry_count,entries_offset,page_size,version=struct.unpack_from('>8I',head,0)
        if magic!=DTBO_MAGIC or not 32<=header_size<=4096 or not 32<=entry_size<=128:
            raise ValueError('DTBO_TABLE_HEADER_INVALID')
        if not 32<=total<=MAX_DTBO or entry_count>256 or entries_offset<header_size or entries_offset+entry_count*entry_size>total:
            raise ValueError('DTBO_TABLE_BOUNDS')
        whole=partition_window(name,0,total)
        entries=[]
        for i in range(entry_count):
            at=entries_offset+i*entry_size
            length,offset,ident,revision,c0,c1,c2,c3=struct.unpack_from('>8I',whole,at)
            if length<40 or offset<header_size or offset+length>total:
                raise ValueError('DTBO_ENTRY_RANGE')
            payload=whole[offset:offset+length]
            ent={'index':i,'id':f'0x{ident:08x}','rev':f'0x{revision:08x}',
                 'custom':[f'0x{x:08x}' for x in (c0,c1,c2,c3)],'offset':offset,'bytes':length,
                 'sha256':digest(payload)}
            try:
                ent['fdt']=fdt_root_metadata(payload)
            except ValueError as err:
                ent['parse_error']=str(err)[:120]
            entries.append(ent)
        answer.update({'status':'PARSED' if all('fdt' in x for x in entries) else 'PARTIAL_FDT_PARSE',
                       'total_bytes':total,'header_size':header_size,'entry_count':entry_count,
                       'entries':entries,'table_sha256':digest(whole),'version':version,
                       'page_size':page_size})
    except (ValueError,struct.error) as e:
        answer.update({'status':'READ_OR_FORMAT_ERROR','reason':str(e)[:120]})
    return answer


def read_runtime_fdt():
    raw=root_read('/sys/firmware/fdt',limit=MAX_FDT+4096)
    if raw is not None:
        try:
            return {'source':'/sys/firmware/fdt','status':'PARSED','fdt':fdt_root_metadata(raw)}
        except ValueError as e:
            return {'source':'/sys/firmware/fdt','status':'INVALID_FDT','reason':str(e)[:100]}
    compat=root_read('/proc/device-tree/compatible',limit=2048)
    model=root_read('/proc/device-tree/model',limit=2048)
    if compat is None:
        compat=root_read('/sys/firmware/devicetree/base/compatible',limit=2048)
        model=root_read('/sys/firmware/devicetree/base/model',limit=2048)
    if compat is not None:
        return {'source':'device-tree properties only','status':'PROPERTIES_ONLY',
                'root':{'compatible':_strings(compat),'model':_strings(model or b'')}}
    return {'source':'runtime device-tree','status':'UNAVAILABLE'}


def module_load_lists():
    result=[]
    for name in MODULE_LISTS:
        b=root_read(name,limit=200_000)
        if b is None: continue
        lines=[]
        for line in b.decode('utf8','replace').splitlines():
            entry=line.partition('#')[0].strip()
            if entry and len(entry)<180:
                lines.append(entry.rsplit('/',1)[-1][:100])
        result.append({'path':name,'sha256':digest(b),'entry_count':len(lines),
                       'module_names':lines[:200], 'truncated':len(lines)>200})
    return result


def capture():
    if (run(['su','-c','id -u'],timeout=12,limit=200) or b'').strip() != b'0':
        raise RuntimeError('ROOT_LESEZUGRIFF_FEHLT; keine Änderungen vorgenommen')
    slot=(run(['/system/bin/getprop','ro.boot.slot_suffix'],limit=100) or b'').decode('ascii','replace').strip()
    release=(root_read('/proc/sys/kernel/osrelease',limit=300) or b'').decode('utf8','replace').strip()
    modules=(root_read('/proc/modules',limit=150_000) or b'').decode('utf8','replace')
    loaded=sorted({ln.split()[0] for ln in modules.splitlines() if ln.split()})
    vendor=[parse_vendor_boot_dtb(p) for p in VENDOR_PARTITIONS]
    dtbo=[parse_dtbo(p) for p in OVERLAY_PARTITIONS]
    active='a' if slot=='_a' else 'b' if slot=='_b' else None
    for item in vendor + dtbo:
        item['reported_active']=(item['partition'].endswith(active) if active else None)
    runtime=read_runtime_fdt()
    lists=module_load_lists()
    warnings=[]
    if not active: warnings.append('ACTIVE_SLOT_UNKNOWN')
    if runtime['status'] not in ('PARSED','PROPERTIES_ONLY'): warnings.append('RUNTIME_DEVICE_TREE_UNAVAILABLE')
    for item in vendor+dtbo:
        if item['status']!='PARSED':warnings.append(f"{item['partition']}:{item['status']}")
    doc={'schema':SCHEMA,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'read_only':True,'kernel_release':release,'reported_active_slot':slot,
         'runtime_device_tree':runtime,'vendor_boot':vendor,'dtbo':dtbo,
         'loaded_module_names':loaded[:500],'loaded_modules_total':len(loaded),
         'module_load_lists':lists,'warnings':warnings,
         'limits':['No raw FDT, DTBO, partition, module bytes or unique device identifiers stored',
                   'Board compatible/DTBO metadata is not proof of bootability',
                   'No evidence of which overlay the bootloader actually selected',
                   'No vendor ABI or flash approval is inferred']}
    return doc


def save_report(doc, directory=None):
    destdir=Path(directory) if directory is not None else Path('/sdcard/Download')
    if not destdir.is_dir() or not os.access(destdir,os.W_OK):
        destdir=Path.cwd()
    target=destdir/OUTPUT_NAME
    payload=(json.dumps(doc,indent=2,sort_keys=True,ensure_ascii=False)+'\n').encode('utf8')
    note=(f'VEUX R33 Geraetebaum-Diagnose (read only)\n'
          f"Slot: {doc['reported_active_slot']}\n"
          f"vendor_boot: {', '.join(v['partition']+'='+v['status'] for v in doc['vendor_boot'])}\n"
          f"dtbo: {', '.join(v['partition']+'='+v['status'] for v in doc['dtbo'])}\n"
          f"Warnungen: {len(doc['warnings'])}\n"
          'NO BUILD / NO FLASH / Keine Bootfreigabe\n').encode('utf8')
    manifest=(digest(payload)+'  R33_DEVICE_EVIDENCE.json\n'+digest(note)+'  README_DE.txt\n').encode()
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.writestr('R33_DEVICE_EVIDENCE.json',payload)
        z.writestr('README_DE.txt',note)
        z.writestr('SHA256SUMS.txt',manifest)
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None or z.read('R33_DEVICE_EVIDENCE.json')!=payload:
            raise RuntimeError('ERZEUGTE_ZIP_NICHT_INTAKT')
    return target


def main():
    try:
        d=capture()
        p=save_report(d)
    except Exception as exc:
        print('R33_DIAGNOSE_FEHLER; KEINE AENDERUNGEN:',exc,file=sys.stderr)
        return 2
    print('R33_ERGEBNIS_ERSTELLT:',p)
    print('GELADENE_MODULE:',d['loaded_modules_total'],'WARNUNGEN:',len(d['warnings']))
    print('KEIN FLASH / KEIN BOOTIMAGE / KEINE QUELLAENDERUNG')
    return 0


if __name__=='__main__':
    sys.exit(main())
