#!/usr/bin/env python3
"""R33 positive and adverse cases for binary parsers, provenance and fail-closed gates."""
import copy
import hashlib
import io
import json
import pathlib
import struct
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import VEUX_R33_CAPTURE_GERAET as d
import r33_gate as g

BASE = pathlib.Path(__file__).resolve().parents[1]


def fdt(props=None):
    props = props or {'model':b'Qualcomm Blair Test\0',
                      'compatible':b'qcom,blair\0qcom,other\0',
                      'qcom,msm-id': struct.pack('>4I',507,65536,578,65536)}
    strings=bytearray()
    names={}
    body=bytearray(struct.pack('>I',1)+b'\0'*4)
    for name, val in props.items():
        names[name]=len(strings); strings.extend(name.encode()+b'\0')
        body.extend(struct.pack('>3I',3,len(val),names[name]));body.extend(val)
        body.extend(b'\0'*((-len(body))%4))
    body.extend(struct.pack('>II',2,9))
    st_off=56;str_off=st_off+len(body);total=str_off+len(strings)
    hdr=struct.pack('>10I',d.FDT_MAGIC,total,st_off,str_off,40,17,16,0,len(strings),len(body))
    return hdr+b'\0'*16+body+strings


def vendor_image(version=3,dtbs=None,ramdisk=b'abc'):
    dtbs = dtbs if dtbs is not None else [fdt()]
    section=b''.join(blob+b'\0'*((-len(blob))%4) for blob in dtbs)
    hdr=bytearray(4096);hdr[:8]=b'VNDRBOOT'
    struct.pack_into('<II',hdr,8,version,4096)
    struct.pack_into('<I',hdr,24,len(ramdisk))
    struct.pack_into('<I',hdr,2096,2112 if version==3 else 2128)
    struct.pack_into('<I',hdr,2100,len(section))
    return bytes(hdr)+ramdisk+b'\0'*(4096-len(ramdisk))+section


def dtbo_image(entries=None):
    if entries is None:entries=[fdt({'compatible':b'qcom,blair\0'})]
    count=len(entries)
    off=32+32*count
    total=off+sum(len(x) for x in entries)
    head=struct.pack('>8I',d.DTBO_MAGIC,total,32,32,count,32,4096,0)
    records=[]
    for i,blob in enumerate(entries):
        records.append(struct.pack('>8I',len(blob),off,0x1234+i,0x5678,0,0,0,0))
        off+=len(blob)
    payload=head+b''.join(records)+b''.join(entries)
    return payload + b'\0'*max(0,4096-len(payload))


def in_memory_partitions(*images):
    files={'vendor_boot_a':images[0],'vendor_boot_b':images[1],
           'dtbo_a':images[2],'dtbo_b':images[3]}
    def read(name,off,length):
        if name not in files:raise ValueError('NOT_FOUND')
        value=files[name][off:off+length]
        if len(value)<length:raise ValueError('SHORT_READ')
        return value
    return read


def sample_device():
    b=fdt()
    meta=d.fdt_root_metadata(b)
    vendor=[{'partition':name,'status':'PARSED','dtb_section_size':651045,
             'dtbs':[{'offset':0,**meta}], 'reported_active':name.endswith('a')}
            for name in ('vendor_boot_a','vendor_boot_b')]
    overlays=[{'partition':name,'status':'PARSED','entries':[{'index':0,
                 'bytes':len(b),'sha256':d.digest(b),'fdt':meta}],
               'reported_active':name.endswith('a')}
              for name in ('dtbo_a','dtbo_b')]
    return {'schema':d.SCHEMA,'read_only':True,'reported_active_slot':'_a',
            'kernel_release':'5.4.274-qgki-g82179e362f33',
            'vendor_boot':vendor,'dtbo':overlays,'warnings':[],
            'runtime_device_tree':{'status':'PARSED','fdt':meta},
            'loaded_module_names':['rmnet_shs','rmnet_offload'],
            'module_load_lists':[]}


def device_zip(doc, corrupt=False,extra=None):
    payload=(json.dumps(doc,sort_keys=True)+'\n').encode()
    readme=b'Veux R33 test\n'
    sums=(d.digest(payload)+'  R33_DEVICE_EVIDENCE.json\n'+d.digest(readme)+'  README_DE.txt\n').encode()
    z=io.BytesIO()
    with zipfile.ZipFile(z,'w') as out:
        out.writestr('R33_DEVICE_EVIDENCE.json',payload)
        out.writestr('README_DE.txt',readme if not corrupt else b'different')
        out.writestr('SHA256SUMS.txt',sums)
        if extra:out.writestr(extra,b'EXTRA')
    return z.getvalue()


class BinaryTests(unittest.TestCase):
    def test_01_r20_original_dtb_is_valid(self):
        r=g.reference_values(BASE)
        self.assertEqual(r['r20_dtb']['root']['compatible'],['qcom,blair'])
        self.assertEqual(r['r20_dtb']['nodes'],1829)
    def test_02_fdt_root_properties(self):
        r=d.fdt_root_metadata(fdt());self.assertIn('qcom,blair',r['root']['compatible'])
        self.assertEqual(r['root']['qcom,msm-id'][0],'0x000001fb')
    def test_03_invalid_fdt_magic_rejected(self):
        b=bytearray(fdt());b[0]=0
        with self.assertRaises(ValueError):d.fdt_root_metadata(b)
    def test_04_short_fdt_rejected(self):
        with self.assertRaises(ValueError):d.fdt_root_metadata(b'\0'*32)
    def test_05_fdt_string_bounds_rejected(self):
        b=bytearray(fdt());struct.pack_into('>I',b,12,999999)
        with self.assertRaises(ValueError):d.fdt_root_metadata(b)
    def test_06_fdt_struct_outside_rejected(self):
        b=bytearray(fdt());struct.pack_into('>I',b,36,999999)
        with self.assertRaises(ValueError):d.fdt_root_metadata(b)
    def test_07_invalid_token_rejected(self):
        b=bytearray(fdt());struct.pack_into('>I',b,56,42)
        with self.assertRaises(ValueError):d.fdt_root_metadata(b)
    def test_08_missing_fdt_end_rejected(self):
        b=bytearray(fdt())
        struct_off=struct.unpack_from('>I',b,8)[0]
        size=struct.unpack_from('>I',b,36)[0]
        struct.pack_into('>I',b,struct_off+size-4,4)
        with self.assertRaises(ValueError):d.fdt_root_metadata(b)
    def test_09_fdt_ignores_private_properties(self):
        obj=d.fdt_root_metadata(fdt({'serial-number':b'SECRET\0','compatible':b'qcom,blair\0'}))
        self.assertNotIn('serial-number',obj['root'])
    def test_10_fdt_sequence_two(self):
        one=fdt();two=fdt({'compatible':b'qcom,blair\0'})
        seq=d.fdt_sequence(one+b'\0'*((-len(one))%4)+two)
        self.assertEqual(len(seq),2)
    def test_11_fdt_sequence_empty(self):
        self.assertEqual(d.fdt_sequence(b'not a dtb'),[])
    def test_12_vendor_boot_v3(self):
        contents=in_memory_partitions(vendor_image(),vendor_image(),dtbo_image(),dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_vendor_boot_dtb('vendor_boot_a')
        self.assertEqual(x['status'],'PARSED');self.assertEqual(x['dtbs'][0]['root']['compatible'][0],'qcom,blair')
    def test_13_vendor_boot_v4(self):
        contents=in_memory_partitions(vendor_image(4),vendor_image(4),dtbo_image(),dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_vendor_boot_dtb('vendor_boot_b')
        self.assertEqual(x['header_version'],4)
        self.assertEqual(x['status'],'PARSED')
    def test_14_vendor_boot_bad_magic_blocks(self):
        bad=b'INVALID!'+vendor_image()[8:]
        contents=in_memory_partitions(bad,vendor_image(),dtbo_image(),dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_vendor_boot_dtb('vendor_boot_a')
        self.assertEqual(x['status'],'READ_OR_FORMAT_ERROR')
    def test_15_vendor_boot_no_valid_fdt_is_blocked(self):
        raw=bytearray(vendor_image());raw[8192:8196]=b'FAIL'
        contents=in_memory_partitions(raw,vendor_image(),dtbo_image(),dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_vendor_boot_dtb('vendor_boot_a')
        self.assertEqual(x['status'],'NO_VALID_FDT_FOUND')
    def test_16_dtbo_one_entry(self):
        contents=in_memory_partitions(vendor_image(),vendor_image(),dtbo_image(),dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_dtbo('dtbo_a')
        self.assertEqual(x['status'],'PARSED');self.assertEqual(x['entry_count'],1)
    def test_17_dtbo_two_entries(self):
        img=dtbo_image([fdt(),fdt({'compatible':b'qcom,blair\0'})])
        contents=in_memory_partitions(vendor_image(),vendor_image(),img,dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_dtbo('dtbo_a')
        self.assertEqual(x['entry_count'],2)
    def test_18_dtbo_magic_invalid(self):
        img=bytearray(dtbo_image());img[0]=0
        contents=in_memory_partitions(vendor_image(),vendor_image(),img,dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_dtbo('dtbo_a')
        self.assertEqual(x['status'],'READ_OR_FORMAT_ERROR')
    def test_19_dtbo_bad_offset_blocks(self):
        img=bytearray(dtbo_image());struct.pack_into('>I',img,32+4,0xdeadbeef)
        contents=in_memory_partitions(vendor_image(),vendor_image(),img,dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_dtbo('dtbo_a')
        self.assertEqual(x['status'],'READ_OR_FORMAT_ERROR')
    def test_20_dtbo_bad_count_blocks(self):
        img=bytearray(dtbo_image());struct.pack_into('>I',img,16,257)
        contents=in_memory_partitions(vendor_image(),vendor_image(),img,dtbo_image())
        with patch.object(d,'partition_window',side_effect=contents):
            x=d.parse_dtbo('dtbo_a')
        self.assertEqual(x['status'],'READ_OR_FORMAT_ERROR')
    def test_21_partition_whitelist(self):
        with self.assertRaises(ValueError):d.partition_window('boot_a',0,128)
    def test_22_partitions_no_negative_ranges(self):
        with self.assertRaises(ValueError):d.partition_window('dtbo_a',-1,128)
    def test_23_root_read_whitelist(self):
        with self.assertRaises(ValueError):d.root_read('/data/adb/boot-completed.d/50-veux-rmnet.sh')
    def test_24_capture_hash_only_no_partition_bytes(self):
        obj=d.fdt_root_metadata(fdt())
        self.assertEqual(set(obj),{'bytes','sha256','version','nodes','root','parsed'})
    def test_25_capture_report_schema(self):
        x=sample_device();self.assertTrue(x['read_only'])
    def test_26_device_zip_save_and_load(self):
        with tempfile.TemporaryDirectory() as tmp:
            obj=sample_device();p=d.save_report(obj,tmp)
            self.assertEqual(g.load_device_zip(p)['schema'],d.SCHEMA)
    def test_27_report_zip_has_no_raw_partitions(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=d.save_report(sample_device(),tmp)
            with zipfile.ZipFile(p) as z:
                self.assertEqual(set(z.namelist()),{'R33_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'})
    def test_28_device_archive_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'bad.zip';p.write_bytes(device_zip(sample_device(),corrupt=True))
            with self.assertRaises(ValueError):g.load_device_zip(p)
    def test_29_device_archive_extra_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'bad.zip';p.write_bytes(device_zip(sample_device(),extra='escape'))
            with self.assertRaises(ValueError):g.load_device_zip(p)
    def test_30_device_archive_unsafe_schema_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'bad.zip';m=sample_device();m['read_only']=False
            p.write_bytes(device_zip(m))
            with self.assertRaises(ValueError):g.load_device_zip(p)
    def test_31_device_archive_bad_slot_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'bad.zip';m=sample_device();m['reported_active_slot']='_x'
            p.write_bytes(device_zip(m))
            with self.assertRaises(ValueError):g.load_device_zip(p)
    def test_32_device_archive_missing_vendor_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'bad.zip';m=sample_device();m['vendor_boot']=[]
            p.write_bytes(device_zip(m))
            with self.assertRaises(ValueError):g.load_device_zip(p)
    def test_33_manifest_valid_original(self):
        self.assertIn('evidence/R20_VEUX.dtb',g.verify_manifest(BASE)['files'])
    def test_34_manifest_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            # Verify wrong reference hash always fails closed.
            real=json.loads((BASE/'MANIFEST_SHA256.json').read_text())
            new=copy.deepcopy(real);new['files']['evidence/R20_VEUX.dtb']['sha256']='0'*64
            with patch.object(g,'checked_json',return_value=new):
                with self.assertRaises(ValueError):g.verify_manifest(BASE)
    def test_35_reference_is_known_green_r32(self):
        ref=g.reference_values(BASE)
        self.assertEqual(ref['r32_import_count'],307)
        self.assertEqual(ref['historical_slot'],'_a')
    def test_36_no_device_is_explicitly_blocked(self):
        cmp=g.compare(g.reference_values(BASE),None)
        self.assertEqual(cmp['report_status'],'WAITING_FOR_CURRENT_DEVICE_CAPTURE')
        self.assertFalse(cmp['active_dtbo_table_read'])
    def test_37_device_soc_match_is_not_boot_approval(self):
        cmp=g.compare(g.reference_values(BASE),sample_device())
        self.assertTrue(cmp['board_soc_compatible_observed'])
        self.assertIn('DTBO-Auswahl',str(cmp['blockers']))
    def test_38_device_unknown_soc_is_blocked(self):
        doc=sample_device();doc['vendor_boot'][0]['dtbs'][0]['root']['compatible']=['wrong,soc']
        cmp=g.compare(g.reference_values(BASE),doc)
        self.assertFalse(cmp['board_soc_compatible_observed'])
    def test_39_device_new_slot_warns(self):
        doc=sample_device();doc['reported_active_slot']='_b'
        cmp=g.compare(g.reference_values(BASE),doc)
        self.assertIn('gewechselt',str(cmp['blockers']))
    def test_40_device_dtb_size_mismatch_blocks(self):
        doc=sample_device();doc['vendor_boot'][0]['dtb_section_size']=98765
        cmp=g.compare(g.reference_values(BASE),doc)
        self.assertIn('651045',str(cmp['blockers']))
    def test_41_device_dtbo_error_blocks(self):
        doc=sample_device();doc['dtbo'][0]['status']='READ_OR_FORMAT_ERROR'
        cmp=g.compare(g.reference_values(BASE),doc)
        self.assertFalse(cmp['active_dtbo_table_read'])
    def test_42_result_is_never_flashable(self):
        with tempfile.TemporaryDirectory() as tmp:
            ref=g.reference_values(BASE);cmp=g.compare(ref,sample_device());r=g.save_result(ref,cmp,tmp)
            self.assertFalse(r['boot_ready']);self.assertFalse(r['flash_allowed']);self.assertFalse(r['kernel_built'])
    def test_43_result_hashes_integrity(self):
        with tempfile.TemporaryDirectory() as tmp:
            g.save_result(g.reference_values(BASE),g.compare(g.reference_values(BASE),None),tmp)
            for l in (pathlib.Path(tmp)/'SHA256SUMS.txt').read_text().splitlines():
                digest,name=l.split('  ',1)
                self.assertEqual(g.sha((pathlib.Path(tmp)/name).read_bytes()),digest)
    def test_44_result_is_only_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            g.save_result(g.reference_values(BASE),g.compare(g.reference_values(BASE),None),tmp)
            self.assertEqual({p.name for p in pathlib.Path(tmp).iterdir()},set(g.REPORT_FILES))
    def test_45_full_offline_no_device(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(g.main(['--bundle',str(BASE),'--out',tmp]),0)
            r=json.loads((pathlib.Path(tmp)/'R33_RESULT.json').read_text())
            self.assertFalse(r['r33_device_capture_present'])
    def test_46_full_offline_with_device(self):
        with tempfile.TemporaryDirectory() as tmp:
            dfile=pathlib.Path(tmp)/'device.zip';dfile.write_bytes(device_zip(sample_device()))
            out=pathlib.Path(tmp)/'out'
            self.assertEqual(g.main(['--bundle',str(BASE),'--device-zip',str(dfile),'--out',str(out)]),0)
            r=json.loads((out/'R33_RESULT.json').read_text())
            self.assertTrue(r['r33_device_capture_present']);self.assertFalse(r['flash_allowed'])
    def test_47_module_list_preserves_only_names(self):
        with patch.object(d,'root_read',side_effect=lambda p,limit=0:b'rmnet_shs.ko\n# comment\nother.ko\n' if p.endswith('/modules.load') else None):
            got=d.module_load_lists()
        self.assertTrue(got);self.assertEqual(got[0]['entry_count'],2)
    def test_48_no_root_can_never_capture(self):
        with patch.object(d,'run',return_value=b'1\n'):
            with self.assertRaises(RuntimeError):d.capture()


if __name__=='__main__':
    unittest.main()
