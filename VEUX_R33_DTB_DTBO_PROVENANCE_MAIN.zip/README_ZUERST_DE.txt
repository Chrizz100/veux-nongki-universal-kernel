VEUX R33 - gezielte DTB/DTBO/Vendor-Boot Diagnose (23.10.2026)
Repo: Chrizz100/veux-nongki-universal-kernel | Branch main

Kein neuer Kernelbuild, keine Boot-/Flashfreigabe, keine Aenderung an BReNE, SUSFS, NoMount oder BakaSU.

Drei Einheiten:
1) VEUX_R33_CAPTURE_GERAET.py: auf dem Poco X4 Pro in Termux ausfuehren; benoe­tigt Root NUR zum LESEN von vendor_boot/dtbo. Erzeugt VEUX_R33_DEVICE_EVIDENCE.zip in Downloads.
2) VEUX_R33_DTB_DTBO_PROVENANCE_MAIN.zip: UNENTPACKT ins Repository-Root main hochladen.
3) VEUX_R33_DTB_DTBO_PROVENANCE_GATE.yml: in .github/workflows/ ablegen; Dateiname muss exakt stimmen (kein (1), keine Leerzeichen).

Nachdem das Termux-Skript VEUX_R33_DEVICE_EVIDENCE.zip erstellt hat, auch DIESE ZIP UNENTPACKT ins Repo-Root main hochladen, dann den R33-Workflow starten. Alternativ die Ergebnis-ZIP zuerst im Chat zur Auswertung hochladen.

R33 prueft:
- Tatsächlich in vendor_boot_a/b gespeicherte DTBs (im Gegensatz zur zuvor untersuchten Ramdisk)
- dtbo_a/b Tabelle und Overlay-Metadaten
- /sys/firmware/fdt (Laufzeit-Device-Tree) bzw. erlaubte compatible/model-Properties
- R20-VEUX-DTB gegen R30-/R32-Nachweise
- historische RMNET/Kernel-/Slot-Kontextwerte aus R28/R30/R32
- trennt "SOC kompatibel" klar von "Bootfaehig"

Sicherheit:
Nur su -c id/cat/dd if= zum Lesen, KEINE Schreibbefehle zu Partitionen.
Keine Roh-Boot-/DTB-/DTBO-/Moduldateien werden in die Ergebnis-ZIP geschrieben; nur Metadaten und SHA-256.
Die im GitHub-Root gespeicherte R33-Haupt-ZIP enthaelt das Referenz-DTB nur als statische Eingabe, NICHT zur Installation.

Ein gruenes GitHub-Run-Ergebnis bedeutet NUR, dass der Diagnoseworkflow erfolgreich war. Der Ausgabestatus blockiert weiterhin Flash und Bootfreigabe.
