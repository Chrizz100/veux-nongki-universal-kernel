"""Check ARM64 relocations from the compiled signal, reaper and sysctl objects."""
import json
import re
import subprocess
import sys
from pathlib import Path

def sections(tool, path):
    text = subprocess.check_output([tool, '-rW', path], text=True)
    chunks = re.split(r"Relocation section '([^']+)'[^\n]*\n",text)
    return dict(zip(chunks[1::2], chunks[2::2]))

def calls(body):
    return re.findall(r'R_AARCH64_(?:CALL|JUMP)26\s+[0-9a-f]+ (?:\.text\.)?([\w.]+) \+', body)

def ordered(body, wanted):
    names = calls(body)
    relevant = [name for name in names if name in wanted]
    if relevant != wanted:
        raise ValueError('Expected '+repr(wanted)+' in '+repr(names))

def main():
    tool, signal, oom, sysctl, dest = sys.argv[1:]
    ordered(sections(tool,signal)['.rela.text.group_send_sig_info'],
            ['check_kill_permission','do_send_sig_info','capable','__get_task_comm','add_to_oom_reaper'])
    reaper = sections(tool,oom)['.rela.text.add_to_oom_reaper']
    ordered(reaper,['task_will_free_mem','wake_oom_reaper'])
    if 'sysctl_reap_mem_on_sigkill' not in reaper or '.bss.panic_on_oom_timeout' not in reaper:
        raise ValueError('Missing sysctl read or timeout reset in reaper')
    ctl = sections(tool, sysctl)
    entries = [line for title, body in ctl.items() if title.endswith('.vm_table')
               for line in body.splitlines() if 'R_AARCH64_ABS64' in line and
               ' sysctl_reap_mem_on_sigkill + ' in line]
    if len(entries) != 1:
        raise ValueError('Expected exactly one reaper sysctl data pointer in vm_table')
    Path(dest).write_text(json.dumps({'signal_permission_delivery_and_sender':True,
                                      'reaper_eligibility_wake_and_timeout':True,
                                      'vm_table_reaper_data_entries':1},indent=2)+'\n')

if __name__ == '__main__':
    main()
