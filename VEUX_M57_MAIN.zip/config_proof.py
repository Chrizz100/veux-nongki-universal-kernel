"""IKCONFIG framing and config parsing from the verified M25 build checks."""
import mmap
import zlib
from pathlib import Path

def require(ok, message):
    if not ok:
        raise ValueError(message)

def extract_config(data):
    """Read the unique complete IKCONFIG stream; validate gzip CRC and framing."""
    found = []
    pos = 0
    while True:
        marker = data.find(b'IKCFG_ST', pos)
        if marker < 0:
            break
        pos = marker + 8
        raw = data[pos:pos + 2 * 1024 * 1024]
        try:
            decoder = zlib.decompressobj(31)
            config = decoder.decompress(raw, 2 * 1024 * 1024 + 1)
        except zlib.error:
            continue
        if not decoder.eof or len(config) > 2 * 1024 * 1024:
            continue
        end = pos + len(raw) - len(decoder.unused_data)
        if data[end:end + 8] == b'IKCFG_ED':
            found.append((marker, config))
    require(len(found) == 1, 'IKCONFIG_UNIQUE_COMPLETE_PAYLOAD_REQUIRED:' + str(len(found)))
    return found[0][1]

def embedded(path):
    require(Path(path).stat().st_size > 0, 'EMPTY_KERNEL_PRODUCT')
    with Path(path).open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        return extract_config(data)

def config_values(data):
    values = {}
    for line in data.decode().splitlines():
        if line.startswith('CONFIG_'):
            require('=' in line, 'MALFORMED_CONFIG')
            name, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            name, value = line[2:-11], 'n'
        else:
            continue
        require(name not in values, 'DUPLICATE_CONFIG:' + name)
        values[name] = value
    return values

def autoconf_check(config, header):
    expected = {}
    for name, value in config_values(config).items():
        if value == 'n':
            continue
        expected[name + '_MODULE' if value == 'm' else name] = '1' if value in ('y', 'm') else value
    actual = {}
    for line in header.splitlines():
        if line.startswith('#define CONFIG_'):
            _, name, value = line.split(' ', 2)
            require(name not in actual, 'DUPLICATE_AUTOCONF:' + name)
            actual[name] = value
    require(expected == actual, 'AUTOCONF_DIFFERS_FROM_BUILD_CONFIG')
    return len(expected)

