"""Exercise the compiled driver's callbacks against a scheduler/hotplug fixture."""
import subprocess,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1]); here=Path(__file__).resolve().parent
src=(root/'drivers/thermal/qcom/cpu_isolate.c').read_text()
with tempfile.TemporaryDirectory() as t:
    p=Path(t)
    (p/'driver.inc').write_text(src[src.index('struct cpu_isolate_cdev {'):src.index('static const struct of_device_id')])
    subprocess.run(['gcc','-std=gnu11','-O2','-Wall','-Werror','-pthread',
                    '-fsanitize=undefined','-fno-sanitize-recover=all','-I',t,
                    here/'test_thermal.c','-o',p/'test'],check=True)
    subprocess.run([p/'test'],check=True)
