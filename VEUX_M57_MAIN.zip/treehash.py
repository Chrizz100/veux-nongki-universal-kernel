"""Verify a Gitiles toolchain export using the original Git tree object identity."""
import hashlib
import os
from pathlib import Path
import sys

EXPECTED = "0a90693130898d6f98a76538086247b374d4a57f"

def blob(path):
    sha = hashlib.sha1()
    size = path.stat().st_size
    sha.update(f"blob {size}\0".encode())
    with path.open("rb") as src:
        for block in iter(lambda: src.read(1 << 20), b""):
            sha.update(block)
    return sha.digest()

def obj(kind, data):
    return hashlib.sha1(f"{kind} {len(data)}\0".encode() + data).digest()

def tree(path):
    rows = []
    for item in path.iterdir():
        name = os.fsencode(item.name)
        if item.is_symlink():
            mode, digest = b"120000", obj("blob", os.fsencode(os.readlink(item)))
        elif item.is_dir():
            mode, digest = b"40000", tree(item)
        elif item.is_file():
            mode = b"100755" if item.stat().st_mode & 0o111 else b"100644"
            digest = blob(item)
        else:
            raise ValueError(f"Unexpected entry: {item}")
        rows.append((name + (b"/" if mode == b"40000" else b""), mode+b" "+name+b"\0"+digest))
    return obj("tree", b"".join(data for _, data in sorted(rows)))

if __name__ == "__main__":
    result = tree(Path(sys.argv[1])).hex()
    if result != EXPECTED:
        raise SystemExit("Unexpected Android toolchain tree " + result)
    print("Android Clang tree verified", result)
