"""Authenticate the M56 source and extract the matching Xiaomi reference image."""
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m56.zip') as archive:
    require(sha(work/'m56.zip')=='86406276b0f934366bc973921afccece9aa4148a79419f4d4a7b9b3ff12ea377', 'M56 artifact digest')
    manifest=json.loads(archive.read('M56_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M56 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M56 config identity')
    archive.extract('M56-kernel-source.tar.gz',work)
tar=work/'M56-kernel-source.tar.gz'
require(sha(tar)=='ee4817e24be060a6026226cc1ebe1030ac4439d32c41f439f895bca9851a391f','M56 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'zram.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-e','MIUI_ZRAM_MEMORY_TRACKING'],check=True)
