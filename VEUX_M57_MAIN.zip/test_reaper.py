"""Compile the signal, victim eligibility, mm ownership and queue functions from the build tree."""
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(sys.argv[1])
here = Path(__file__).resolve().parent

def body(source, signature):
    start = source.index(signature)
    return source[start:source.index('\n}', start) + 2]

mm = (root / 'mm/oom_kill.c').read_text()
signal = (root / 'kernel/signal.c').read_text()
functions = [body(mm, s) for s in (
    'static bool attach_oom_mm(', 'static inline bool __task_will_free_mem(',
    'static bool task_will_free_mem(', 'static void wake_oom_reaper(',
    'void add_to_oom_reaper(')]
functions.append(body(signal, 'int group_send_sig_info('))
with tempfile.TemporaryDirectory() as tmp:
    directory = Path(tmp)
    (directory / 'reaper.inc').write_text('\n\n'.join(functions))
    for mode in ([], ['-DCONFIG_PRIORITIZE_OOM_TASKS=1']):
        subprocess.run(['gcc','-std=gnu11','-O2','-Wall','-Werror','-pthread',
                        '-fsanitize=undefined','-fno-sanitize-recover=all',*mode,'-I',tmp,
                        here/'test_reaper.c','-o',directory/'test'],check=True)
        subprocess.run([directory/'test'],check=True)
