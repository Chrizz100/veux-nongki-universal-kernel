"""Exercise the MIUI zRAM functions extracted from the authenticated patched source."""
import subprocess
import sys
import tempfile
from pathlib import Path


def function(source, name):
    start = source.index('static void ' + name + '(')
    return source[start:source.index('\n}', start) + 2]


def load_driver(source):
    stats = source.index('static const u32 default_time_list')
    end_stats = source.index('\n#endif', source.index('spin_unlock_irqrestore(&zram->sample_lock', stats))
    sysfs = source.index('static ssize_t zram_life_show')
    end_sysfs = source.index('\n#endif', source.index('static DEVICE_ATTR_RO(avg_size);', sysfs))
    init = source.index('\t{\n\t\tstruct zram_pages_life *life = zram_life_alloc(ARRAY_SIZE(default_time_list))')
    end_init = source.index('\n#endif', init)
    return '\n'.join([source[stats:end_stats], function(source, 'zram_accessed'),
                      function(source, 'zram_reset_device'), source[sysfs:end_sysfs],
                      'static void init_stats(struct zram *zram)\n{', source[init:end_init], '}\n'])


root = Path(sys.argv[1])
fixture = Path(__file__).with_name('test_zram.c')
driver = (root / 'drivers/block/zram/zram_drv.c').read_text()
with tempfile.TemporaryDirectory() as tmp:
    work = Path(tmp)
    (work / 'driver.inc').write_text(load_driver(driver))
    for writeback in [False, True]:
        flags = ['-DCONFIG_ZRAM_WRITEBACK'] if writeback else []
        subprocess.run(['gcc', '-std=gnu11', '-DCONFIG_MIUI_ZRAM_MEMORY_TRACKING',
                        '-Wall', '-Werror', '-O2', '-pthread', '-fsanitize=undefined',
                        '-fno-sanitize-recover=all', *flags, '-I', work, fixture, '-o', work / 'test'],
                       check=True)
        print('WRITEBACK=' + ('y' if writeback else 'n'), flush=True)
        subprocess.run([work / 'test'], check=True)
