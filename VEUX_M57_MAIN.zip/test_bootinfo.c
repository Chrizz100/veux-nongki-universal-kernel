#include <arpa/inet.h>
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint32_t u32, __be32;
#define __init
#define __ro_after_init
#define pr_info(...) ((void)0)
#define EXPORT_SYMBOL(x)
#define BIT(n) (1U << (n))
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
#define __ffs(x) ((unsigned int)__builtin_ctz(x))
#define be32_to_cpup(p) ntohl(*(p))
struct qpnp_pon { unsigned int generation; };
static struct qpnp_pon pmic, *bootinfo_pon;
static int bootinfo_pon_lock;
static unsigned int value, reads;
static int error;
static void mutex_lock(int *p) { assert(!*p); *p = 1; }
static void mutex_unlock(int *p) { assert(*p); *p = 0; }
static bool is_pon_gen3(struct qpnp_pon *p) { return p->generation == 3; }
#define QPNP_POFF_REASON1(p) ((p)->generation == 1 ? 0x80c : 0x8c5)
static int qpnp_pon_read(struct qpnp_pon *p, unsigned int addr, unsigned int *out)
{
	assert(p == &pmic && bootinfo_pon_lock && addr == QPNP_POFF_REASON1(p));
	reads++;
	if (!error) *out = value;
	return error;
}
#include "code.inc"

static const char *reference(unsigned int low, unsigned int hi, unsigned int reg)
{
	static const char *const reset[] = { "wdog", "kpanic", "reboot", "other",
		"dm_verity_enforcing", "dm_verity_logging", "dm_verity_keysclear", "reboot" };
	static const unsigned int bits[] = { 1, 2, 4, 3, 7, 5 };
	static const char *const labels[] = { "smpl", "rtc", "usb_chg", "dc_chg", "keypad", "pon1" };
	if ((low & 256) || ((low & 1) && (reg & 2))) {
		for (unsigned int i = 0; i < ARRAY_SIZE(reset); i++)
			if (hi & BIT(i)) return reset[i];
	}
	if (low & 1) return (reg & 128) ? "long_power_key" : "hw_reset";
	for (unsigned int i = 0; i < ARRAY_SIZE(bits); i++)
		if (low & BIT(bits[i])) return labels[i];
	return "unknown reboot";
}

int main(void)
{
	__be32 cells[] = { 0, htonl(0x80010001) };
	unsigned int cases = 0;
	bootinfo_read_reason(NULL, 4);
	assert(powerup_reason == 0);
	for (int n = -1; n <= 16; n++)
		if (n != 4 && n != 8) {
			bootinfo_read_reason(cells + 1, n);
			assert(powerup_reason == 0);
		}
	bootinfo_read_reason(cells, 8);
	assert(powerup_reason == 0x80010001);
	cells[0] = htonl(1);
	bootinfo_read_reason(cells, 8);
	assert(powerup_reason == 0x80010001);
	bootinfo_read_reason(cells, 4);
	assert(powerup_reason == 1);
	assert(!qpnp_pon_is_lpk() && !qpnp_pon_is_ps_hold_reset() && !reads);
	bootinfo_pon = &pmic;
	for (unsigned int gen = 1; gen <= 3; gen++) {
		pmic.generation = gen;
		for (value = 0; value < 256; value++)
			for (error = 0; error >= -1; error--) {
				unsigned int prev = reads;
				unsigned int reg = gen <= 2 && !error ? value : 0;
				assert(qpnp_pon_is_lpk() == !!(reg & 128));
				assert(qpnp_pon_is_ps_hold_reset() == !!(reg & 2));
				assert(reads - prev == (gen == 3 ? 0U : 2U));
			}
	}
	pmic.generation = 2;
	error = 0;
	for (unsigned int low = 0; low < 1024; low++)
		for (unsigned int mask = 0; mask < 4; mask++) {
			value = (mask & 1 ? 2 : 0) | (mask & 2 ? 128 : 0);
			for (unsigned int i = 0; i < 259; i++) {
				unsigned int hi = i < 256 ? i : i == 256 ? 0x8000 : i == 257 ? 0xff00 : 0xffff;
				assert(!strcmp(bootinfo_reason_name((hi << 16) | low), reference(low, hi, value)));
				cases++;
			}
		}
	printf("%u reason combinations passed; DT lengths, PMIC variants and read failures passed\n", cases);
	return 0;
}
