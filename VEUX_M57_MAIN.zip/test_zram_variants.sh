#!/usr/bin/env bash
set -euo pipefail
tools=$(cd "$(dirname "$0")" && pwd)
for variant in stock-config no-writeback no-tracking; do
    output=out
    if [[ "$variant" != stock-config ]]; then
        output="zram-$variant"
        mkdir -p "$output"
        cp out/.config "$output/.config"
        flag=ZRAM_WRITEBACK
        if [[ "$variant" = no-tracking ]]; then flag=MIUI_ZRAM_MEMORY_TRACKING; fi
        bash src/scripts/config --file "$output/.config" -d "$flag"
        bash "$tools/kbuild.sh" src "$output" clang olddefconfig
    fi
    object=drivers/block/zram/zram_drv.o
    bash "$tools/kbuild.sh" src "$output" clang "$object"
    clang/bin/ld.lld -r "$output/$object" -o "evidence/zRAM-$variant.o"
    python3 -B "$tools/zram_object.py" "$variant" clang/bin/llvm-nm "$output/.config" \
        "evidence/zRAM-$variant.o" "evidence/zRAM-$variant.json"
done
