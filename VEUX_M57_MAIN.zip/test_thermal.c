// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NR_CPUS 8
#define nr_cpu_ids NR_CPUS
#define THERMAL_NAME_LENGTH 20
#define GFP_KERNEL 0
#define CPUHP_AP_ONLINE_DYN 1
#define PM_HIBERNATION_PREPARE 1
#define PM_RESTORE_PREPARE 2
#define PM_SUSPEND_PREPARE 3
#define PM_POST_HIBERNATION 4
#define PM_POST_RESTORE 5
#define PM_POST_SUSPEND 6
#define NOTIFY_OK 1
#define for_each_possible_cpu(i) for ((i)=0;(i)<NR_CPUS;++(i))
#define cpu_possible(i) ((unsigned)(i)<NR_CPUS)
#define DEFINE_MUTEX(m) pthread_mutex_t m=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(m) assert(!pthread_mutex_lock(m))
#define mutex_unlock(m) assert(!pthread_mutex_unlock(m))
#define BLOCKING_NOTIFIER_HEAD(n) int n
#define system_highpri_wq NULL
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define WARN_ON(c) assert(!(c))
#define pr_warn_ratelimited(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_warn(...) ((void)0)
#define IS_ERR(p) ((intptr_t)(p)<0)
#define PTR_ERR(p) ((long)(p))

struct cpumask { unsigned long bits; };
#define cpumask_t struct cpumask
#define cpumask_set_cpu(c,p) ((p)->bits|=1ul<<(c))
#define cpumask_clear_cpu(c,p) ((p)->bits&=~(1ul<<(c)))
static bool cpumask_test_and_clear_cpu(int cpu, struct cpumask *p)
{ bool set=p->bits & (1ul<<cpu); cpumask_clear_cpu(cpu,p); return set; }

struct device_node { int cpu, refs; struct device_node *child, *next, *target; };
struct device { struct device_node *of_node; int cpu; };
struct platform_device { struct device dev; };
struct work_struct { void (*fn)(struct work_struct *); bool queued; };
struct thermal_cooling_device { void *devdata; };
struct thermal_cooling_device_ops {
	int (*get_max_state)(struct thermal_cooling_device *,unsigned long *);
	int (*get_cur_state)(struct thermal_cooling_device *,unsigned long *);
	int (*set_cur_state)(struct thermal_cooling_device *,unsigned long);
};
struct notifier_block { int (*notifier_call)(struct notifier_block *,unsigned long,void *); };
static DEFINE_MUTEX(map_lock);
static DEFINE_MUTEX(device_hotplug);
static _Thread_local bool maps, device_locked;
static bool online[NR_CPUS], no_device, fail_register, fail_pm, fail_hp, fail_alloc;
static int late_error, votes[NR_CPUS], notifier_on, notifier_off, registered, dev_error, sched_error;
static int (*hp_up)(unsigned),(*hp_down)(unsigned);
static struct notifier_block *pm;
static struct device devices[NR_CPUS];
static struct device_node nodes[NR_CPUS], cpu_nodes[NR_CPUS], parent;
static void *allocations[64]; static int allocs;
static struct platform_device pdev={.dev.of_node=&parent};

static void cpu_maps_update_begin(void) { assert(!maps); mutex_lock(&map_lock); maps=true; }
static void cpu_maps_update_done(void) { assert(maps); maps=false; mutex_unlock(&map_lock); }
static void lock_device_hotplug(void) { assert(!maps); mutex_lock(&device_hotplug); device_locked=true; }
static void unlock_device_hotplug(void) { device_locked=false; mutex_unlock(&device_hotplug); }
#define cpu_online(c) online[c]
static int sched_isolate_cpu_unlocked(int cpu)
{
	assert(maps && online[cpu]); if (sched_error) return sched_error;
	++votes[cpu]; return 0;
}
static int sched_unisolate_cpu_unlocked(int cpu)
{
	assert(maps && votes[cpu]>0); if (sched_error) return sched_error;
	--votes[cpu]; return 0;
}
static void blocking_notifier_chain_register(int *n,struct notifier_block *nb) { ++*n; }
static void blocking_notifier_chain_unregister(int *n,struct notifier_block *nb) { --*n; }
static int blocking_notifier_call_chain(int *n,int on,void *cpu)
{
	assert(!maps && (uintptr_t)cpu<NR_CPUS);
	if (on) ++notifier_on; else ++notifier_off;
	return 0;
}
#define INIT_WORK(w,handler) ((w)->fn=(handler))
static void queue_work(void *q,struct work_struct *w) { assert(w->fn); w->queued=true; }
static void cancel_work_sync(struct work_struct *w) { w->queued=false; }
static void run_work(struct work_struct *w) { if (w->queued) { w->queued=false; w->fn(w); } }
static struct device *get_cpu_device(unsigned cpu) { return no_device?NULL:&devices[cpu]; }
static int device_online(struct device *d)
{
	assert(device_locked && !maps); if (dev_error) return dev_error;
	cpu_maps_update_begin(); int ret=hp_up?hp_up(d->cpu):0;
	if (!ret && late_error) { if (hp_down) hp_down(d->cpu); ret=late_error; }
	if (!ret) online[d->cpu]=true;
	cpu_maps_update_done(); return ret;
}
static struct device_node *of_node_get(struct device_node *n) { if (n) ++n->refs; return n; }
static void of_node_put(struct device_node *n) { if (n) { assert(n->refs>0); --n->refs; } }
static struct device_node *of_parse_phandle(struct device_node *n,const char *prop,int i)
{ assert(!strcmp(prop,"qcom,cpu")&&!i); return of_node_get(n->target); }
static int of_cpu_node_to_id(struct device_node *n) { return n->cpu; }
#define for_each_available_child_of_node(p,n) for ((n)=of_node_get((p)->child);(n);of_node_put(n),(n)=of_node_get((n)->next))
static void *devm_kzalloc(struct device *d,size_t size,int gfp)
{
	if (fail_alloc) return NULL;
	assert(allocs<64); return allocations[allocs++]=calloc(1,size);
}
static struct thermal_cooling_device *thermal_of_cooling_device_register(struct device_node *n,const char *name,void *data,struct thermal_cooling_device_ops *ops)
{
	char expected[20]; snprintf(expected,sizeof(expected),"cpu-isolate%d",n->cpu); assert(!strcmp(name,expected));
	if (fail_register) return (void *)(intptr_t)-ENOMEM;
	struct thermal_cooling_device *c=calloc(1,sizeof(*c)); c->devdata=data; ++registered; return c;
}
static void thermal_cooling_device_unregister(struct thermal_cooling_device *c) { --registered; free(c); }
static int cpuhp_setup_state(int state,const char *name,int (*up)(unsigned),int (*down)(unsigned))
{
	assert(!hp_up); if (fail_hp) return -ENOMEM; hp_up=up; hp_down=down;
	cpu_maps_update_begin();
	for (int i=0;i<NR_CPUS;++i) if (online[i]) assert(!up(i));
	cpu_maps_update_done(); return 47;
}
static void cpuhp_remove_state_nocalls(int id) { assert(id==47); hp_up=hp_down=NULL; }
static int register_pm_notifier(struct notifier_block *n) { if (fail_pm) return -EIO; pm=n; return 0; }
static void unregister_pm_notifier(struct notifier_block *n) { assert(pm==n); pm=NULL; }
#include "driver.inc"

static void setup(void)
{
	for(int i=0;i<NR_CPUS;++i) {
		assert(!nodes[i].refs&&!cpu_nodes[i].refs&&!votes[i]&&!ports[i]);
		devices[i].cpu=cpu_nodes[i].cpu=nodes[i].cpu=i;
		nodes[i].target=&cpu_nodes[i]; nodes[i].next=i+1<NR_CPUS?&nodes[i+1]:NULL;
		online[i]=true;
	}
	parent.child=nodes; notifier_on=notifier_off=0;
	assert(!owner&&!pm&&!hp_up&&!registered);
}
static void release_memory(void)
{ while(allocs) free(allocations[--allocs]); }
static int set(int cpu,unsigned long s) { return cpu_isolate_set_cur_state(ports[cpu]->cdev,s); }
static int hot(int cpu,bool up)
{
	cpu_maps_update_begin(); int ret=up?hp_up(cpu):hp_down(cpu);
	if (!ret) online[cpu]=up;
	cpu_maps_update_done(); return ret;
}
static void *cycle(void *ignored)
{
	for (int i=0;i<250;++i) { assert(!hot(3,false)); int r=hot(3,true); assert(!r||r==-EBUSY); }
	return NULL;
}
int main(void)
{
	setup(); nodes[1].target=nodes[0].target; assert(cpu_isolate_probe(&pdev)==-EINVAL); release_memory();
	setup(); nodes[4].target=NULL; assert(cpu_isolate_probe(&pdev)==-EINVAL); release_memory();
	setup(); fail_alloc=true; assert(cpu_isolate_probe(&pdev)==-ENOMEM); fail_alloc=false;
	setup(); fail_hp=true; assert(cpu_isolate_probe(&pdev)==-ENOMEM); fail_hp=false; release_memory();
	setup(); fail_pm=true; assert(cpu_isolate_probe(&pdev)==-EIO); fail_pm=false; release_memory();
	setup(); online[7]=false; assert(!cpu_isolate_probe(&pdev)); assert(cpu_isolate_probe(&pdev)==-EBUSY);
	for (int i=0;i<7;++i) run_work(&ports[i]->reg_work);
	assert(registered==7 && !ports[7]->cdev); assert(!hot(7,true));
	fail_register=true; run_work(&ports[7]->reg_work); fail_register=false; assert(!ports[7]->cdev);
	assert(!hot(7,false)&&!hot(7,true)); run_work(&ports[7]->reg_work); assert(registered==8);
	unsigned long val;
	for (int i=0;i<NR_CPUS;++i) {
		assert(!cooling_ops.get_max_state(ports[i]->cdev,&val)&&val==1);
		assert(!cooling_ops.get_cur_state(ports[i]->cdev,&val)&&!val);
		assert(set(i,2)==-EINVAL);
	}
	sched_error=-EBUSY; assert(set(2,1)==-EBUSY&&!votes[2]&&!notifier_on); sched_error=0;
	votes[2]=1; /* Another scheduler client owns the first vote. */
	assert(!set(2,1)&&!set(2,1)&&votes[2]==2&&notifier_on==1);
	assert(cpumask_test_and_clear_cpu(2,&cpus_in_max_cooling_level)); cpumask_set_cpu(2,&cpus_in_max_cooling_level);
	sched_error=-EINVAL; assert(set(2,0)==-EINVAL&&ports[2]->voted&&ports[2]->requested); sched_error=0;
	assert(!hot(2,false)&&votes[2]==1); assert(hot(2,true)==-EBUSY&&ports[2]->pending_online);
	assert(!set(2,0)&&notifier_off==1&&ports[2]->online_work.queued);
	assert(!cpu_cooling_get_max_level_cpumask()->bits);
	no_device=true; run_work(&ports[2]->online_work); no_device=false; assert(ports[2]->pending_online);
	assert(!set(2,0)); dev_error=-EIO; run_work(&ports[2]->online_work); dev_error=0;
	assert(!online[2]&&ports[2]->pending_online);
	assert(!set(2,0)); late_error=-EBUSY; run_work(&ports[2]->online_work); late_error=0;
	assert(!online[2] && ports[2]->pending_online && !ports[2]->online_work.queued);
	assert(!set(2,0)); run_work(&ports[2]->online_work); assert(online[2]&&!ports[2]->pending_online&&votes[2]==1);
	--votes[2];
	assert(!set(1,1)); pm->notifier_call(pm,PM_SUSPEND_PREPARE,NULL);
	assert(!hot(1,false)&&!votes[1]&&!hot(1,true)&&!votes[1]);
	pm->notifier_call(pm,PM_POST_SUSPEND,NULL); assert(votes[1]==1);
	pm->notifier_call(pm,PM_POST_RESTORE,NULL); assert(votes[1]==1);
	assert(!set(1,0)); assert(!votes[1]);
	pthread_t th;
	assert(!pthread_create(&th,NULL,cycle,NULL));
	for (int i=0;i<250;++i) { assert(!set(3,1)); assert(!set(3,0)); }
	assert(!pthread_join(th,NULL)); assert(!set(3,0)); run_work(&ports[3]->online_work);
	assert(!votes[3]&&!ports[3]->requested);
	assert(!set(0,1)); assert(!cpu_isolate_remove(&pdev)); release_memory();
	setup();
	puts("PASS 8 CPU mappings, levels, shared votes, errors/retries, CPU hotplug, suspend/resume, concurrent transitions, probe unwind and remove");
}
