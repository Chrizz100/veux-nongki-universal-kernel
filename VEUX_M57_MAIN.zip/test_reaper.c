// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <stdbool.h>
#include <errno.h>
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <string.h>

#define CONFIG_QGKI 1
#define CONFIG_MMU 1
#define SIGKILL 9
#define CAP_KILL 5
#define TASK_COMM_LEN 16
#define SIGNAL_GROUP_EXIT 1
#define SIGNAL_GROUP_COREDUMP 2
#define PF_EXITING 4
#define MMF_OOM_SKIP 0
#define MMF_OOM_VICTIM 1
#define MMF_OOM_REAP_QUEUED 2

struct mm_struct { unsigned long flags; int mm_users, refs; };
struct signal_struct { unsigned int flags; struct mm_struct *oom_mm; };
struct task_struct {
	struct mm_struct *mm;
	struct signal_struct *signal;
	struct task_struct *oom_reaper_list;
	pthread_mutex_t lock;
	bool alone;
	int refs, pid, flags;
};
enum pid_type { PIDTYPE_TGID };
struct kernel_siginfo { int code; };
static struct kernel_siginfo user, kernel = {1};
static struct mm_struct mm, old_mm;
static struct signal_struct group, other;
static struct task_struct tasks[3], *oom_reaper_list;
static pthread_mutex_t oom_reaper_lock = PTHREAD_MUTEX_INITIALIZER;
static _Thread_local int depth;
static int sysctl_reap_mem_on_sigkill, send_result, permission;
static unsigned long panic_on_oom_timeout;
static bool cap;
static const char *sender_comm;
static atomic_int sends, wakes, lookups;

#define READ_ONCE(x) __atomic_load_n(&(x), __ATOMIC_RELAXED)
#define WRITE_ONCE(x,y) __atomic_store_n(&(x), (y), __ATOMIC_RELAXED)
#define cmpxchg(p,a,b) ({ __typeof__(*(p)) expected=(a); \
	__atomic_compare_exchange_n((p), &expected, (b), false, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST); expected; })
#define set_bit(n,p) ((void)__atomic_fetch_or((p), 1UL<<(n), __ATOMIC_SEQ_CST))
#define test_bit(n,p) ((READ_ONCE(*(p)) >> (n)) & 1)
#define test_and_set_bit(n,p) ((__atomic_fetch_or((p),1UL<<(n),__ATOMIC_SEQ_CST) >> (n)) & 1)
#define mmgrab(m) ((void)__atomic_add_fetch(&(m)->refs,1,__ATOMIC_SEQ_CST))
#define spin_lock(m) assert(!pthread_mutex_lock(m))
#define spin_unlock(m) assert(!pthread_mutex_unlock(m))
#define get_task_struct(t) ((void)__atomic_add_fetch(&(t)->refs,1,__ATOMIC_SEQ_CST))
#define trace_wake_reaper(pid) ((void)0)
#define wake_up(w) ((void)++wakes)
#define atomic_read(p) READ_ONCE(*(p))
#define thread_group_empty(t) ((t)->alone)
#define for_each_process(p) for ((p)=tasks; (p)<tasks+3; ++(p))
#define process_shares_mm(t,m) ((t)->mm==(m))
#define same_thread_group(t,p) ((t)->signal==(p)->signal)
#define rcu_read_lock() ((void)++depth)
#define rcu_read_unlock() assert(--depth>=0)
#define current NULL
#define SI_FROMUSER(info) ((info)->code<=0)
#define is_si_special(info) ((info)==NULL)
#define capable(c) ((c)==CAP_KILL && cap)
#define get_task_comm(buf,unused) snprintf(buf,sizeof(buf),"%s",sender_comm)

static int check_kill_permission(int sig, struct kernel_siginfo *i, struct task_struct *p)
{
	assert(depth==1); return permission;
}
static int do_send_sig_info(int sig, struct kernel_siginfo *i, struct task_struct *p, enum pid_type type)
{
	assert(!depth); ++sends; return send_result;
}
static struct task_struct *find_lock_task_mm(struct task_struct *p)
{
	++lookups;
	for (unsigned i=0; i<3; ++i) {
		struct task_struct *t=&tasks[(p-tasks+i)%3];
		if (t->signal!=p->signal) continue;
		spin_lock(&t->lock);
		if (t->mm) return t;
		spin_unlock(&t->lock);
	}
	return NULL;
}
static void task_unlock(struct task_struct *p) { spin_unlock(&p->lock); }
#include "reaper.inc"

static void reset(void)
{
	assert(!depth && !oom_reaper_list);
	mm=(struct mm_struct){.mm_users=1,.refs=1};
	old_mm=(struct mm_struct){.mm_users=1,.refs=1};
	group=(struct signal_struct){.flags=SIGNAL_GROUP_EXIT};
	other=(struct signal_struct){0};
	for (int i=0; i<3; ++i) {
		tasks[i].mm=i==0?&mm:NULL;
		tasks[i].signal=i<2?&group:&other;
		tasks[i].refs=1; tasks[i].flags=0; tasks[i].alone=true;
	}
	permission=send_result=0; cap=true; sender_comm="lmkd"; sysctl_reap_mem_on_sigkill=1;
	lookups=sends=wakes=0; panic_on_oom_timeout=91;
}
static int deliver(int sig, struct kernel_siginfo *info)
{
	return group_send_sig_info(sig,info,tasks,PIDTYPE_TGID);
}
static void check_result(bool queued)
{
	assert(!depth && mm.refs==1+queued && wakes==queued && !!oom_reaper_list==queued);
	assert(test_bit(MMF_OOM_VICTIM,&mm.flags)==queued);
	assert(test_bit(MMF_OOM_REAP_QUEUED,&mm.flags)==queued);
#ifdef CONFIG_PRIORITIZE_OOM_TASKS
	assert(panic_on_oom_timeout==(queued?0:91));
#else
	assert(panic_on_oom_timeout==91);
#endif
	int taskrefs=0;
	for (int i=0; i<3; ++i) taskrefs+=tasks[i].refs;
	assert(taskrefs==3+queued);
	if (queued) {
		assert(group.oom_mm==&mm && !oom_reaper_list->oom_reaper_list);
		--oom_reaper_list->refs; oom_reaper_list=NULL;
		--mm.refs; group.oom_mm=NULL;
	}
}
static void *repeat(void *p)
{
	for (int i=0; i<100; ++i)
		assert(!group_send_sig_info(SIGKILL,&user,p,PIDTYPE_TGID));
	return NULL;
}
int main(void)
{
	for (int i=0; i<3; ++i) assert(!pthread_mutex_init(&tasks[i].lock,NULL));
	const char *names[]={"lmkd","PreKillActionT","lmkd-x","PreKillAction","LMKD","ordinary"};
	for (int i=0; i<6; ++i) {
		reset(); sender_comm=names[i]; assert(!deliver(SIGKILL,&user)); check_result(i<2);
	}
	reset(); permission=-EPERM; assert(deliver(SIGKILL,&user)==-EPERM && !sends && !lookups); check_result(false);
	reset(); send_result=-ESRCH; assert(deliver(SIGKILL,&user)==-ESRCH && sends==1 && !lookups); check_result(false);
	reset(); assert(!deliver(0,&user) && !sends); check_result(false);
	reset(); assert(!deliver(15,&user) && sends==1 && !lookups); check_result(false);
	reset(); cap=false; assert(!deliver(SIGKILL,&user) && !lookups); check_result(false);
	reset(); assert(!deliver(SIGKILL,NULL) && !lookups); check_result(false);
	reset(); assert(!deliver(SIGKILL,&kernel) && !lookups); check_result(false);
	reset(); sysctl_reap_mem_on_sigkill=0; assert(!deliver(SIGKILL,&user) && !lookups); check_result(false);
	reset(); tasks[0].mm=NULL; assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); tasks[0].mm=NULL; tasks[1].mm=&mm; assert(!deliver(SIGKILL,&user)); assert(oom_reaper_list==&tasks[1]); check_result(true);
	reset(); group.flags=0; assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); group.flags|=SIGNAL_GROUP_COREDUMP; assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); group.flags=0; tasks[0].flags=PF_EXITING; assert(!deliver(SIGKILL,&user)); check_result(true);
	reset(); group.flags=0; tasks[0].flags=PF_EXITING; tasks[0].alone=false; assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); set_bit(MMF_OOM_SKIP,&mm.flags); assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); mm.mm_users=2; tasks[2].mm=&mm; assert(!deliver(SIGKILL,&user)); check_result(false);
	reset(); mm.mm_users=2; tasks[2].mm=&mm; other.flags=SIGNAL_GROUP_EXIT; assert(!deliver(SIGKILL,&user)); check_result(true);
	reset(); group.oom_mm=&old_mm; assert(!deliver(SIGKILL,&user)); assert(group.oom_mm==&old_mm); check_result(false);
	reset(); mm.mm_users=2; tasks[1].mm=&mm;
	pthread_t workers[8];
	for (int i=0; i<8; ++i) assert(!pthread_create(&workers[i],NULL,repeat,&tasks[i%2]));
	for (int i=0; i<8; ++i) assert(!pthread_join(workers[i],NULL));
	assert(sends==800); check_result(true);

	/* Two dying processes share an mm, but own distinct signal_structs. */
	reset(); mm.mm_users=2; tasks[2].mm=&mm; other.flags=SIGNAL_GROUP_EXIT;
	for (int i=0; i<8; ++i) assert(!pthread_create(&workers[i],NULL,repeat,&tasks[(i%2)*2]));
	for (int i=0; i<8; ++i) assert(!pthread_join(workers[i],NULL));
	assert(sends==800 && group.oom_mm==&mm && other.oom_mm==&mm);
	assert(mm.refs==3 && wakes==1 && oom_reaper_list && !oom_reaper_list->oom_reaper_list);
	assert(tasks[0].refs+tasks[2].refs==3);
	--oom_reaper_list->refs;
	oom_reaper_list=NULL;
	mm.refs-=2;
	assert(mm.refs==1 && tasks[0].refs==1 && tasks[2].refs==1);
	puts("PASS signal filters, mm ownership, shared groups, stale mm, timeout, 2 x 800 concurrent deliveries, one queue reference per mm");
	return 0;
}
