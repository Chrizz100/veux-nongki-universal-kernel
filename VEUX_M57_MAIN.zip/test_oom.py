"""Compile the actual OOM selection functions against deterministic task and memory fixtures."""
from pathlib import Path
import subprocess
import sys
import tempfile

src = Path(sys.argv[1])
here = Path(__file__).resolve().parent
code = (src / 'mm/oom_kill.c').read_text()
header = (src / 'include/linux/oom.h').read_text()

def function(text, signature):
    start = text.index(signature)
    return text[start:text.index('\n}', start) + 2]

with tempfile.TemporaryDirectory() as tmp:
    dest = Path(tmp)
    (dest / 'layout.inc').write_text(function(header, 'enum oom_constraint {') + ';\n' +
                                     function(header, 'struct oom_control {') + ';\n')
    early = ['static inline bool is_sysrq_oom(', 'static bool oom_unkillable_task(',
             'long oom_badness(', 'static int oom_evaluate_task(', 'static void select_bad_process(']
    logic = '\n'.join(function(code, name) for name in early)
    panic = code[code.index('#define PANIC_ON_OOM_DEFER_TIMEOUT'):code.index('static BLOCKING_NOTIFIER_HEAD')]
    late = function(code, 'bool out_of_memory(')
    (dest / 'selection.inc').write_text(logic + '\n' + panic + '\n' + late + '\n')
    signal = function(code, 'static void __oom_kill_process(')
    begin = signal.index('do_send_sig_info(SIGKILL, SEND_SIG_PRIV, victim')
    end = signal.index('mark_oom_victim(victim);', begin)
    (dest/'after_signal.inc').write_text(signal[signal.index('\n',begin):end])
    for value in ('off','0','300','-1000'):
        flags = [] if value=='off' else ['-DCONFIG_PRIORITIZE_OOM_TASKS=1','-DCONFIG_OOM_TASK_PRIORITY_ADJ_LIMIT='+value]
        subprocess.run(['gcc','-std=gnu11','-O2','-Wall','-Werror','-fsanitize=undefined',
                        '-fno-sanitize-recover=all',*flags,'-I',str(dest),str(here/'test_oom.c'),
                        '-o',dest/'test'],check=True)
        subprocess.run([dest/'test'],check=True)
