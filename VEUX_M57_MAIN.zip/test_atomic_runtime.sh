#!/usr/bin/env bash
set -euo pipefail
tools=$(cd "$(dirname "$0")" && pwd)
src=$(realpath "$1")
out=$(realpath "$2")
tc=$(realpath "$3")
runner=${QEMU_AARCH64:-qemu-aarch64}
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
cp "$tools"/probe/{Makefile,probe.c,start.S} "$work/"
bash "$tools/kbuild.sh" "$src" "$out" "$tc" M="$work" probe.o
"$tc/bin/clang" --target=aarch64-linux-gnu -c "$work/start.S" -o "$work/start.o"
"$tc/bin/ld.lld" -static --gc-sections -e _start "$work/start.o" "$work/probe.o" -o "$work/test"
timeout 30 "$runner" -cpu cortex-a53 "$work/test" 0
echo 'PASS ARM64 Cortex-A53, HWCAP_ATOMICS=0, 65536 rounds, 32/64-bit'
timeout 30 "$runner" -cpu max "$work/test" 1
echo 'PASS ARM64 max, HWCAP_ATOMICS=1, 65536 rounds, 32/64-bit'
