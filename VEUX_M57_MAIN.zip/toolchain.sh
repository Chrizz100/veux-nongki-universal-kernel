#!/usr/bin/env bash
set -euo pipefail
root=$(cd "$(dirname "$0")" && pwd)
dest=$(realpath -m "$1")
mkdir -p "$dest"
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
rev=aa2e4a514a6c85eebcc4a27149eaf9244e951a1e
subtree=0a90693130898d6f98a76538086247b374d4a57f
url="https://android.googlesource.com/platform/prebuilts/clang/host/linux-x86/+archive/$rev/clang-r416183b.tar.gz"
if curl -fsSL --retry 2 --connect-timeout 25 --max-time 420 "$url" -o "$tmp/clang.tgz" && \
   mkdir "$tmp/gitiles" && tar xzf "$tmp/clang.tgz" -C "$tmp/gitiles" && \
   python3 "$root/treehash.py" "$tmp/gitiles"; then
    cp -a "$tmp/gitiles/." "$dest/"
else
    git init -q "$tmp/repo"
    git -C "$tmp/repo" remote add origin https://github.com/msft-mirror-aosp/platform.prebuilts.clang.host.linux-x86.git
    git -C "$tmp/repo" fetch --depth=1 --filter=blob:none origin "$rev"
    test "$(git -C "$tmp/repo" rev-parse 'FETCH_HEAD:clang-r416183b')" = "$subtree"
    git -C "$tmp/repo" archive 'FETCH_HEAD:clang-r416183b' | tar xf - -C "$dest"
    python3 "$root/treehash.py" "$dest"
fi
"$dest/bin/clang" --version | grep -F 'clang version 12.0.5'
