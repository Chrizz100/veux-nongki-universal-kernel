# VEUX M57 – MIUI-zRAM-Speicherstatistik

Reparatur für den POCO X4 Pro 5G (veux) mit Xiaomi V816.0.12.0.TKCMIXM und der Kernelkennung `5.4.274-qgki-g82179e362f33`.

## Auf GitHub bauen

1. `VEUX_M57_MAIN.zip` unentpackt ins Hauptverzeichnis des Repositorys hochladen.
2. `VEUX_M57_ZRAM_NOFLASH.yml` auf demselben Branch unter `.github/workflows/` ablegen.
3. In Actions den Workflow „VEUX M57 – MIUI-zRAM-Speicherstatistik, QGKI 5.4.274“ manuell starten.

Die YAML prüft den SHA-256 der MAIN.zip. Sie lädt den M56-Quellstand aus Artefakt 14759161566 und die Xiaomi-Referenz aus Artefakt 14706022228. Beide müssen in GitHub noch verfügbar sein. Vor dem Kompilieren prüft der Workflow die Archive, den inneren Quell-Tarball, die Ausgangskonfiguration, Xiaomis boot.img und die drei gepatchten Quelldateien. Der Workflow benötigt Lesezugriff auf das Repository und seine Actions-Artefakte.

## Ausgangspunkt

M56 bestand 13 von 13 Jobschritten. Beide ZIP-Archive wurden heruntergeladen und anhand der SHA-256 und der ZIP-CRC geprüft. Sie enthalten 41 Nachweisdateien und vier Dateien zum Quellstand. Die Nachprüfung des GitHub-Images bestätigt die thermische CPU-Isolation, die Speicherverwaltung und die geprüften Atomikpfade. Die 3.148 Vendor-Importverwendungen aus 37 Modulen passen bei CRC und Anbieter. Die eingebetteten Konfigurationen in Image und vmlinux stimmen mit der archivierten Konfiguration überein. Das statisch nachgebaute Boot-Layout hat 134.217.728 Byte und enthält die originale Xiaomi-Ramdisk. [M56-Lauf und Job](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45033288887/job/137241387485)

## Änderung

M57 aktiviert Xiaomis Option `CONFIG_MIUI_ZRAM_MEMORY_TRACKING`. Die Änderungen liegen in `drivers/block/zram/Kconfig`, `zram_drv.c` und `zram_drv.h`. Die nachfolgenden Dateien gehören zu `/sys/block/zram0/`. Dieselben Attribute gelten für weitere initialisierte zRAM-Geräte.

| Datei | Modus | Bedeutung |
|---|---|---|
| `pages_life` | 0444 | Zählt Zugriffe nach Sekunden seit dem letzten Zugriff auf denselben Block. Die letzte Klasse erfasst Zeiten über der höchsten Grenze. |
| `time_list` | 0644 | Liest die Klassengrenzen oder setzt sie über Anzahl und aufsteigende Sekundenwerte neu. Bei Neuanlage gelten 60, 120, 180, 300 und 600 Sekunden. |
| `avg_size` | 0444 | Zeitgewichtete mittlere Anzahl belegter logischer Seiten. Eine neue Stichprobe wird ab 201 Millisekunden Abstand angenommen. |
| `origin_pages_max` | 0444 | Höchststand der gleichzeitig belegten logischen Seiten seit der Initialisierung. |
| `wb_pages_max` | 0444 | Höchststand der gleichzeitig zugewiesenen Seiten auf dem Writeback-Gerät. Dieses Attribut setzt zRAM-Writeback voraus. |

Die Schnittstellen orientieren sich an Xiaomis öffentlichem VEUX-Treiber und der Attributtabelle im Original-Image. M57 serialisiert den Wechsel der Klassengrenzen, schützt parallele Zähler und vermeidet Überläufe beim Zeitmittel. Ein Fehler beim Anlegen des Histogramms lässt die zRAM-Initialisierung weiterlaufen. Listen mit zu vielen, fallenden oder doppelten Grenzen werden zurückgewiesen. Der Geräte-Reset setzt die Statistiken zurück. [Xiaomi-Referenzcode](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/block/zram/zram_drv.c)

## Prüfungen

Die C-Tests führen Funktionen aus dem gepatchten Kernelquelltext mit nachgebildeten Kernel-Schnittstellen aus. Sie prüfen Klassengrenzen, Zähler, Parallelzugriffe, den Austausch der Grenzen, Speichermangel, Höchststände, Zeitmittel und Geräte-Reset. Der Test des Zeitmittels vergleicht 20.000 Eingaben mit einer unabhängigen 128-Bit-Rechnung. Die Tests laufen mit aktiviertem und deaktiviertem Writeback. Drei ARM64-Kbuild-Varianten prüfen die Attributregistrierung mit beiden Optionen aktiv, ohne Writeback und ohne MIUI-Tracking.

Im verlinkten Image verfolgt die Prüfung die Zeiger von der zRAM-Attributgruppe zu jedem Eintrag und dessen Lese- und Schreibfunktion. Weitere Prüfungen verfolgen im Maschinencode Zeitmessung bei I/O und Seitenfreigabe, die RCU-Aufrufe im I/O-Pfad und das verzögerte Freigeben der alten Tabelle. Aus dem Xiaomi-Image werden außerdem die fünf Vorgabezeiten ausgelesen. Die vorhandenen Prüfungen für DTB, Thermik, F2FS, Bootinfo, OOM, SIGKILL, Atomics, Vendor-ABI, eingebettete Konfiguration und Boot-Layout bleiben Teil des Workflows.

## Offene Punkte

Die Bestandsaufnahme zählt 26 zRAM-Gerätedateien im Stock-Image. M56 hatte 17. Vier weitere Stock-Schnittstellen liegen außerhalb der fünf hier reparierten Statistiken. Als nächste zusammenhängende Reparatur sind `new`, `new_stat` und `idle_stat` samt den Seitenzuständen und Zählern zu prüfen. Separat ist die Verarbeitung der Kompressionsgrenze `low_compress_ratio` mit dem Original abzugleichen.

In `Restkonfiguration.csv` stehen die 48 verbleibenden textlichen Konfigurationsunterschiede. Darunter sind Compilerkennungen und bereits funktional abgeglichene Optionen. Auch Treiberverhalten kann sich bei gleicher Konfiguration unterscheiden. Die Liste misst deshalb keinen prozentualen Reparaturgrad. Für den Kandidaten stehen der Start auf dem Gerät, das Verhalten von Boot, dm-verity, UFS, Speicher und Thermik im Betrieb sowie der praktische Rückweg mit der gesicherten boot.img aus. Gerätefreigabe und Flash-Freigabe sind offen.

## Lokaler Vollbau

Der vollständige ARM64-Bau mit Image, vmlinux, VEUX-DTB und vier Modulen wurde lokal geprüft. Das Image hat SHA-256 `eb06e0429ac8ace60906cff8ed5761f143361c5cef671a8b38ad71e798932789`. Die Prüfung bestätigt 22 von 26 Stock-zRAM-Dateien anhand ihrer Namen und bei den fünf reparierten Attributen zusätzlich Berechtigungen und Funktionszeiger. Zwei Negativtests verändern den Schreibpfad beziehungsweise die Zugriffsrechte von time_list im Speicher. Beide fallen wie erwartet durch. Alle 3.148 geprüften Vendor-Importe, die eingebettete Konfiguration und das statische Boot-Layout bestehen. Der F2FS-Hosttest lief lokal mit deaktiviertem LeakSanitizer, die Atomik-Laufzeittests unter QEMU. Die lokalen Nachweise stehen unter `Nachweise/`. Der GitHub-Lauf für M57 und die Messung auf dem Telefon stehen aus.
