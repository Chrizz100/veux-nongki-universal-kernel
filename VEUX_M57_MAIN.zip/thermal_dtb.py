"""Resolve the eight isolation CPU phandles and cooling maps in the compiled VEUX DTB."""
from pathlib import Path
import json,struct,sys
from check import DTB, require, sha

def nodes(data):
    magic,total,tree,names,_,version,_,_,ns,ts=struct.unpack_from('>10I',data)
    require(magic==0xd00dfeed and total==len(data) and version==17,'DTB header')
    strings=data[names:names+ns]; table={}; path=[]; pos=tree
    while pos<tree+ts:
        token,=struct.unpack_from('>I',data,pos); pos+=4
        if token==1:
            end=data.index(0,pos,tree+ts); path.append(data[pos:end].decode())
            pos=(end+4)&~3
            key='/'.join(path) or '/'
            require(key not in table,'duplicate DT node')
            table[key]={}
        elif token==2:
            path.pop()
        elif token==3:
            length,off=struct.unpack_from('>II',data,pos); pos+=8
            key=strings[off:strings.index(0,off)].decode()
            table['/'.join(path) or '/'][key]=data[pos:pos+length]
            pos=(pos+length+3)&~3
        elif token==9:
            require(not path,'DTB scope'); return table
        else:
            require(token==4,'DTB token')
    raise ValueError('DTB terminator')

def enabled(table,path):
    while path:
        if table[path].get('status',b'okay\0') not in (b'okay\0',b'ok\0'):
            return False
        path=path.rpartition('/')[0]
    return True

def cell(raw):
    return struct.unpack('>I',raw)[0]

def inspect(path):
    require(sha(path)==DTB,'VEUX DTB digest')
    tree=nodes(path.read_bytes())
    handles={cell(n['phandle']):k for k,n in tree.items() if 'phandle' in n}
    node,=[k for k,n in tree.items() if b'qcom,cpu-isolate' in n.get('compatible',b'').split(b'\0')]
    require(enabled(tree,node),'isolation device disabled')
    require('qcom,cpufreq-hw-epss' in tree[node.rpartition('/')[0]]['compatible'].decode().split('\0'),'cpufreq parent')
    ports={}; report={}
    children=[p for p in tree if p.rpartition('/')[0]==node and enabled(tree,p)]
    require(len(children)==8,'cooling device count')
    for cpu in range(8):
        name=f'cpu{cpu}-isolate'
        n=tree[node+'/'+name]; target=handles[cell(n['qcom,cpu'])]
        require(target==f'/cpus/cpu@{cpu*256:x}' and enabled(tree,target) and
                tree[target]['device_type']==b'cpu\0' and int.from_bytes(tree[target]['reg'],'big')==cpu*256 and
                cell(n['#cooling-cells'])==2, 'bad CPU phandle or cooling cells: '+name)
        ports[cell(n['phandle'])]=name
        report[name]={'cpu':target,'cooling_maps':[]}
    for k,n in tree.items():
        if 'cooling-device' not in n or not enabled(tree,k): continue
        raw=n['cooling-device']; offset=0
        while offset<len(raw):
            handle=cell(raw[offset:offset+4]); count=cell(tree[handles[handle]]['#cooling-cells'])
            args=struct.unpack_from('>'+str(count)+'I',raw,offset+4); offset+=4*(1+count)
            if handle in ports:
                require(args==(1,1),'unexpected isolation cooling limits: '+k)
                report[ports[handle]]['cooling_maps'].append(k)
    require([len(v['cooling_maps']) for v in report.values()]==[1,1,1,1,1,1,2,2],
            'Expected ten enabled CPU-isolation cooling maps on VEUX')
    return report

if __name__=='__main__':
    info=inspect(Path(sys.argv[1]))
    Path(sys.argv[2]).write_text(json.dumps(info,indent=2)+'\n')
    print('VEUX cooling maps:',{n:len(r['cooling_maps']) for n,r in info.items()})
