"""Build a review-only boot/AK3 pair and replay the stock-based entry for both slots."""

import hashlib
import io
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
M45_SHA = "6c31c1189deb4a5c0909f2737dc87e1c395dcd25c8abd96a70764e8efb5e5bcd"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unpack_m45(work):
    archive = ROOT / "m45-base.zip"
    need(sha(archive.read_bytes()) == M45_SHA, "M45 template mismatch")
    home = work / "m45"
    with zipfile.ZipFile(archive) as z:
        z.extractall(home)
    sys.path.insert(0, str(home))
    import review

    return review


def align(size):
    return (size + 4095) // 4096 * 4096


def make_image(m45, stock, kernel):
    need(
        sha(stock) == m45.STOCK_SHA and kernel[56:60] == b"ARM\x64",
        "Stock or ARM64 Image mismatch",
    )
    si = m45.image_info(stock)
    need(
        si["embedded_boot_digest"] == m45.STOCK_DESCRIPTOR, "Stock descriptor mismatch"
    )
    original = m45.avb.AvbFooter(stock[-64:])
    old_kernel, ram_len = struct.unpack_from("<II", stock, 8)
    rd_start = 4096 + align(old_kernel)
    header = bytearray(stock[:4096])
    struct.pack_into("<I", header, 8, len(kernel))
    payload = (
        bytes(header)
        + kernel.ljust(align(len(kernel)), b"\0")
        + stock[rd_start : rd_start + align(ram_len)]
    )
    end = len(payload)
    need(end + 4096 <= len(stock) - 4096, "Kernel and ramdisk exceed boot partition")
    meta = stock[original.vbmeta_offset : original.vbmeta_offset + 4096]
    desc = m45.boot_descriptor(meta[: original.vbmeta_size], False)
    before = desc.encode()
    desc.image_size = end
    desc.digest = hashlib.sha256(desc.salt + payload).digest()
    need(meta.count(before) == 1, "Stock boot descriptor must occur exactly once")
    page = meta.replace(before, desc.encode(), 1)
    original.original_image_size = end
    original.vbmeta_offset = end
    image = bytearray(len(stock))
    image[:end] = payload
    image[end : end + 4096] = page
    image[-64:] = original.encode()
    info = m45.image_info(image)
    need(
        info["kernel_sha256"] == sha(kernel) and info["ramdisk_sha256"] == m45.RAMDISK,
        "Invalid canonical boot image",
    )
    return bytes(image), page, end // 4096


