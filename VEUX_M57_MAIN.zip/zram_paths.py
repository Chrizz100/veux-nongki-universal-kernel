"""Trace shared MIUI zRAM I/O and table-replacement call paths in linked kernels."""
import argparse
import json
import struct
import tempfile
from pathlib import Path

from check import BOOT, require, sha
from memory_image import Code, mapped_symbols, stock_symbols


def inspect(image, symbols, compiler, work):
    code = Code(image, symbols, compiler, work)
    names = {addr: name.split('$')[0] for name, addr in code.names.items()}

    def calls(function):
        return {names.get(int(arg, 16)) for _, op, arg in code.instructions(function)
                if op in ('b', 'bl')}

    io = calls('zram_bvec_rw')
    release = calls('zram_free_page')
    store = calls('time_list_store')
    clock = 'ktime_get_with_offset'
    timed_sample = ('zram_sample_pages' in code.names and
                    clock in calls('zram_sample_pages'))
    checks = dict(
        io_calls_rcu_read_lock_and_unlock={'__rcu_read_lock', '__rcu_read_unlock'} <= io,
        io_reads_elapsed_time=clock in io,
        free_samples_boot_time=clock in release or ('zram_sample_pages' in release and timed_sample),
        replace_defers_table_free=bool(store & {'kfree_call_rcu', 'call_rcu'}),
    )
    require(all(checks.values()), 'Missing linked zRAM calls: ' + repr(checks))
    return checks


p = argparse.ArgumentParser(description=__doc__)
p.add_argument('mode', choices=['stock', 'candidate'])
for name in ('compiler', 'image', 'result'):
    p.add_argument(name, type=Path)
p.add_argument('--map', type=Path)
a = p.parse_args()
data = a.image.read_bytes()
if a.mode == 'stock':
    require(sha(a.image) == BOOT, 'Wrong Xiaomi boot.img')
    data = data[4096:4096 + struct.unpack_from('<I', data, 8)[0]]
    syms = stock_symbols(data)
else:
    syms = mapped_symbols(a.map)
with tempfile.TemporaryDirectory() as tmp:
    checks = inspect(data, syms, a.compiler, Path(tmp))
a.result.write_text(json.dumps(checks, indent=2) + '\n')
print(a.mode, checks)
