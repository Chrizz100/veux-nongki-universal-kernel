"""Inspect OOM selection and the default zRAM compressor in actual linked ARM64 code."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess
import tempfile

from check import BOOT, require, sha

def stock_symbols(image):
    # These offsets describe only the SHA-256 pinned Xiaomi Image from boot.img.
    addresses, count, names, markers = 0x18ee158, 0x199d410, 0x199d418, 0x1d65e80
    table, index = 0x1d66978, 0x1d66ca0
    n, = struct.unpack_from('<I', image, count)
    require(n == 179372, 'Xiaomi kallsyms symbol count')
    tokens = []
    for offset in struct.unpack_from('<256H', image, index):
        start = table + offset
        tokens.append(image[start:image.index(0,start,index)])
    pos = names
    symbols = []
    for i in range(n):
        if i % 256 == 0:
            require(struct.unpack_from('<I',image,markers+4*(i//256))[0] == pos-names, 'Xiaomi kallsyms marker')
        size = image[pos]
        name = b''.join(tokens[c] for c in image[pos+1:pos+1+size]).decode('ascii')
        pos += size + 1
        symbols.append((struct.unpack_from('<I', image, addresses+4*i)[0], name[0], name[1:]))
    require((pos+7)&~7 == markers and (0,'T','_text') in symbols, 'Xiaomi symbol table bounds')
    return symbols

def mapped_symbols(path):
    rows = [line.split() for line in path.read_text().splitlines()]
    base, = [int(a,16) for a,t,n in rows if n == '_text' and t=='T']
    return [(int(a,16)-base,t,n) for a,t,n in rows]

class Code:
    def __init__(self, image, symbols, tc, tmp):
        self.image, self.tc, self.tmp = image,tc,tmp
        self.names = {}
        for addr,kind,name in symbols:
            if kind.lower()=='t' and not name.startswith('$') and '.cfi_jt' not in name:
                self.names[name.split('$')[0]]=addr
        self.starts = sorted(set(self.names.values()))

    def instructions(self, name):
        start = self.names[name]
        end = next(x for x in self.starts if x>start)
        require(0 <= start < end <= len(self.image), 'Bad function range: '+name)
        raw, obj = self.tmp/'code.bin', self.tmp/'code.o'
        raw.write_bytes(self.image[start:end])
        subprocess.run([self.tc/'llvm-objcopy','-I','binary','-O','elf64-littleaarch64','-B','aarch64',
                        '--rename-section','.data=.text,alloc,code,contents,load,readonly',raw,obj],check=True)
        output=subprocess.check_output([self.tc/'llvm-objdump','-D','-j','.text','--no-show-raw-insn',
                                       '--mattr=+lse',f'--adjust-vma={start}',obj],text=True)
        return [(int(a,16),op,args.split(' <')[0].strip()) for a,op,args in
                re.findall(r'^\s*([0-9a-f]+):\s+([\w.]+)[ \t]*(.*?)$',output,re.M)]

def compressor(code):
    ins = code.instructions('zram_add')
    calls = [i for i,(_,op,args) in enumerate(ins) if op=='bl' and int(args,16)==code.names['strlcpy']]
    result = []
    for i in calls:
        # Slice strlcpy's x1 argument back to its PC-relative literal. Unhandled
        # writes invalidate the value, so a different caller cannot supply it.
        source = None
        size = None
        for _,op,args in ins[max(0,i-10):i]:
            fields = args.split(', ')
            if op in ('bl','blr'):
                source = size = None
            elif fields[0] in ('x1','w1'):
                if op in ('adrp','adr') and fields[0]=='x1':
                    source = int(fields[1],16)
                elif op=='add' and fields[:2]==['x1','x1'] and fields[2].startswith('#') and source is not None:
                    source += int(fields[2][1:],0)
                else:
                    source = None
            elif fields[0] in ('w2','x2'):
                size=int(fields[1][1:],0) if op=='mov' and fields[1].startswith('#') else None
        if source is not None and size==128 and code.image.startswith(b'lzo-rle\0',source):
            result.append('lzo-rle')
    require(result==['lzo-rle'],'zram_add must pass lzo-rle and length 128 to strlcpy')
    return result[0]

def oom(code, enabled):
    ins=code.instructions('out_of_memory')
    eval_fn=code.instructions('oom_evaluate_task')
    def count_bl(body,destination):
        return sum(op=='bl' and int(arg,16)==code.names[destination] for _,op,arg in body)
    loops=count_bl(ins,'mem_cgroup_scan_tasks')
    global_loops=count_bl(ins,'oom_evaluate_task')
    # ThinLTO may keep the common scan as a single out-of-line helper.
    if 'select_bad_process' in code.names and count_bl(ins,'select_bad_process'):
        helper=code.instructions('select_bad_process')
        calls=count_bl(ins,'select_bad_process')
        loops+=calls*count_bl(helper,'mem_cgroup_scan_tasks')
        global_loops+=calls*count_bl(helper,'oom_evaluate_task')
    min_zero=any(op=='strh' and re.fullmatch(r'wzr, \[x\d+, #56\]',arg) for _,op,arg in ins)
    min_load=any(op=='ldrsh' and arg.endswith(', #56]') for _,op,arg in eval_fn)
    require(loops==global_loops==(2 if enabled else 1),'OOM scans: '+repr((loops,global_loops)))
    require(min_zero==min_load==enabled,'OOM threshold store/load')
    for marker in (b'Could not find task with adj >= %d',b'current killed, retry'):
        require((marker in code.image)==enabled,'OOM diagnostic '+repr(marker))
    return dict(global_scan_sites=global_loops,memcg_scan_sites=loops,priority_threshold=0 if enabled else None)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['stock','m53','candidate'])
    p.add_argument('tc',type=Path)
    p.add_argument('image',type=Path)
    p.add_argument('result',type=Path)
    p.add_argument('--map',type=Path)
    a=p.parse_args()
    raw=a.image.read_bytes()
    if a.mode=='stock':
        require(sha(a.image)==BOOT,'Wrong Xiaomi boot.img')
        image=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
        syms=stock_symbols(image)
    else:
        if a.mode=='m53':
            require(sha(a.image)=="bfde94963367beb578e27eac0f5c2259a7c5d6f65523ecc3da0f9a34ebaa45fc",'M53 source Image')
        image=raw
        syms=mapped_symbols(a.map)
    with tempfile.TemporaryDirectory() as tmp:
        code=Code(image,syms,a.tc,Path(tmp))
        proof=oom(code,a.mode!='m53')
        proof['zram_default_compressor']=compressor(code)
    a.result.write_text(json.dumps(proof,indent=2)+'\n')
    print(a.mode,proof)

if __name__=='__main__':
    main()
