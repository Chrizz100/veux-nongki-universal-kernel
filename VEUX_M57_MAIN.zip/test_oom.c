// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>
#include <setjmp.h>

typedef unsigned int gfp_t;
typedef unsigned long nodemask_t;
struct mem_cgroup { int id; };
struct task_struct;
#include "layout.inc"
struct mm_struct { unsigned long flags; long rss, swap, ptbytes; };
struct signal_struct { short oom_score_adj; struct mm_struct *oom_mm; };
struct task_struct {
	struct signal_struct *signal;
	struct mm_struct *mm;
	unsigned long flags;
	int refs, group;
	bool init, cpuset, origin, vfork, freeing;
};
#define OOM_SCORE_ADJ_MIN (-1000)
#define LONGEST_OOM ((struct task_struct *)-1UL)
#define PAGE_SIZE 4096
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,y) ((x)=(y))
#define HZ 250
#define __GFP_FS 1
#define PF_KTHREAD 1
#define MMF_OOM_SKIP 0
#define test_bit(n,p) ((*(p) >> (n)) & 1)
#define time_before_eq(a,b) ((long)((a)-(b)) <= 0)
#define time_after_eq(a,b) ((long)((a)-(b)) >= 0)
#define is_memcg_oom(oc) ((oc)->memcg != NULL)
#define is_global_init(p) ((p)->init)
#define in_vfork(p) ((p)->vfork)
#define oom_cpuset_eligible(p,oc) ((p)->cpuset)
#define oom_task_origin(p) ((p)->origin)
#define tsk_is_oom_victim(p) ((p)->signal->oom_mm != NULL)
#define get_mm_rss(mm) ((mm)->rss)
#define get_mm_counter(mm,kind) ((mm)->swap)
#define mm_pgtables_bytes(mm) ((mm)->ptbytes)
#define task_will_free_mem(p) ((p)->freeing)
#define WARN(...) ((void)0)
#define pr_warn(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
#define likely(x) (x)
#define try_online_one_block(x) (false)
#define mark_oom_victim(p) ((void)0)
#define wake_oom_reaper(p) ((void)0)
#define blocking_notifier_call_chain(a,b,freed) ((void)0)
#define rcu_read_lock() (++rcu_depth)
#define rcu_read_unlock() assert(--rcu_depth == 0)

static struct task_struct tasks[4], *current = &tasks[3], *killed;
static struct signal_struct signals[4];
static struct mm_struct mms[4];
static struct mem_cgroup group = {1};
static unsigned int num_tasks, scans, pairs;
static int locks, rcu_depth, dumps;
static int sysctl_panic_on_oom, sysctl_oom_kill_allocating_task;
static bool oom_killer_disabled;
static jmp_buf panic_return;
static bool expect_panic;
#ifdef CONFIG_PRIORITIZE_OOM_TASKS
static unsigned long panic_on_oom_timeout, jiffies;
#define THRESHOLD CONFIG_OOM_TASK_PRIORITY_ADJ_LIMIT
#define MODE "on"
#else
#define THRESHOLD OOM_SCORE_ADJ_MIN
#define MODE "off"
#endif

static void panic(const char *fmt, ...)
{
	assert(expect_panic);
	longjmp(panic_return,1);
}
static void dump_header(struct oom_control *oc, struct task_struct *p) { ++dumps; }
static struct task_struct *find_lock_task_mm(struct task_struct *task)
{
	if (!task->mm) return NULL;
	assert(locks++ == 0);
	return task;
}
static void task_unlock(struct task_struct *task) { assert(--locks == 0); }
static void get_task_struct(struct task_struct *task) { ++task->refs; }
static void put_task_struct(struct task_struct *task) { assert(--task->refs >= 0); }
static enum oom_constraint constrained_alloc(struct oom_control *oc)
{
	oc->totalpages = 1000;
	return oc->memcg ? CONSTRAINT_MEMCG : CONSTRAINT_NONE;
}
#define for_each_process(p) for (++scans, (p)=tasks; (p)<tasks+num_tasks; ++(p))
static void mem_cgroup_scan_tasks(struct mem_cgroup *cg, int (*visit)(struct task_struct *,void *), void *arg)
{
	++scans;
	for (unsigned int i=0; i<num_tasks; ++i)
		if (tasks[i].group == cg->id && visit(&tasks[i],arg)) break;
}
static void oom_kill_process(struct oom_control *oc, const char *message)
{
	assert(oc->chosen && oc->chosen != LONGEST_OOM && !killed);
	killed=oc->chosen;
#include "after_signal.inc"
	put_task_struct(killed);
}
#include "selection.inc"

static void reset(void)
{
	memset(tasks,0,sizeof(tasks));
	memset(signals,0,sizeof(signals));
	memset(mms,0,sizeof(mms));
	for (unsigned i=0; i<4; ++i) {
		tasks[i].mm=&mms[i]; tasks[i].signal=&signals[i];
		tasks[i].group=1; tasks[i].cpuset=true;
	}
	num_tasks=2; scans=0; killed=NULL; dumps=0; expect_panic=false;
	sysctl_oom_kill_allocating_task=0; sysctl_panic_on_oom=0;
#ifdef CONFIG_PRIORITIZE_OOM_TASKS
	jiffies=10000; panic_on_oom_timeout=0;
#endif
}
static void clean(void)
{
	assert(!rcu_depth && !locks);
	for (unsigned i=0;i<4;++i) assert(!tasks[i].refs);
}
static int rank(int a, int rss) { return rss+a; }

static void pairs_test(void)
{
	const int adj[]={-1000,-999,-900,-300,-1,0,1,299,300,899,1000};
	const int rss[]={1,19,800,2500};
	for(unsigned g=0;g<2;++g)
	for(unsigned a=0;a<sizeof(adj)/sizeof(*adj);++a)
	for(unsigned b=0;b<sizeof(adj)/sizeof(*adj);++b)
	for(unsigned x=0;x<sizeof(rss)/sizeof(*rss);++x)
	for(unsigned y=0;y<sizeof(rss)/sizeof(*rss);++y) {
		reset();
		struct oom_control oc={.memcg=g?&group:NULL,.order=-1};
		signals[0].oom_score_adj=adj[a]; signals[1].oom_score_adj=adj[b];
		mms[0].rss=rss[x]; mms[1].rss=rss[y];
		int best=-1;
		for (int i=0;i<2;++i) {
			if (signals[i].oom_score_adj == OOM_SCORE_ADJ_MIN) continue;
			if (best<0) { best=i; continue; }
			bool preferred=signals[i].oom_score_adj>=THRESHOLD;
			bool prior=signals[best].oom_score_adj>=THRESHOLD;
			if (preferred>prior || (preferred==prior &&
			    rank(signals[i].oom_score_adj,mms[i].rss)>=rank(signals[best].oom_score_adj,mms[best].rss)))
				best=i;
		}
		assert(out_of_memory(&oc)==(best>=0));
		assert(killed==(best<0?NULL:&tasks[best]));
		assert(scans==(THRESHOLD>OOM_SCORE_ADJ_MIN &&
			(best<0 || signals[best].oom_score_adj<THRESHOLD)?2U:1U));
		clean(); ++pairs;
	}
}
static void exclusions(void)
{
	for (int reason=0;reason<7;++reason) {
		reset();
		struct oom_control oc={.memcg=reason==6?&group:NULL};
		mms[0].rss=1500;mms[1].rss=1;
		switch(reason) {
		case 0: tasks[0].init=true; break;
		case 1: tasks[0].flags=PF_KTHREAD; break;
		case 2: tasks[0].mm=NULL; break;
		case 3: tasks[0].vfork=true; break;
		case 4: mms[0].flags=1; break;
		case 5: tasks[0].cpuset=false; break;
		case 6: tasks[0].group=2; break;
		}
		assert(out_of_memory(&oc) && killed==&tasks[1]);clean();
	}
	reset();
	struct oom_control oc={0};
	signals[1].oom_mm=&mms[1];
	assert(out_of_memory(&oc) && oc.chosen==LONGEST_OOM && !killed && scans==1);
	clean();
	reset(); oc.chosen=NULL;
	sysctl_oom_kill_allocating_task=1;
	assert(out_of_memory(&oc) && killed==current && scans==0);clean();
}
static void special_tasks(void)
{
	reset();
	struct oom_control oc={0};
	signals[0].oom_score_adj=-999; tasks[0].origin=true;
	signals[1].oom_score_adj=1000;
	assert(out_of_memory(&oc));
	assert(killed==(THRESHOLD > -999 ? &tasks[1] : &tasks[0]));
	clean();
	reset(); oc.chosen=NULL;
	signals[0].oom_score_adj=-900; signals[1].oom_score_adj=-901;
	signals[3].oom_mm=&mms[3]; /* current is outside the scanned group */
	oc.memcg=&group;
	assert(out_of_memory(&oc));
	if (THRESHOLD > -900) assert(!killed && scans==1 && !oc.chosen);
	else assert(killed==&tasks[0]);
	clean();
	reset(); oc.chosen=NULL; oc.memcg=NULL;
	tasks[3].signal->oom_score_adj=OOM_SCORE_ADJ_MIN;
	sysctl_oom_kill_allocating_task=1;
	assert(out_of_memory(&oc) && killed!=current); clean();
	reset();
	struct oom_control sysrq={.order=-1};
	sysctl_panic_on_oom=2;
	check_panic_on_oom(&sysrq);
	assert(!sysrq.chosen && !dumps); clean();
	reset();
	struct oom_control constrained={.constraint=CONSTRAINT_MEMCG};
	sysctl_panic_on_oom=1;
	check_panic_on_oom(&constrained);
	assert(!constrained.chosen && !dumps); clean();
}
static void panic_tests(void)
{
	reset();
	struct oom_control oc={0};
	sysctl_panic_on_oom=1;
#ifdef CONFIG_PRIORITIZE_OOM_TASKS
	check_panic_on_oom(&oc);
	assert(oc.chosen==LONGEST_OOM && panic_on_oom_timeout==jiffies+5*HZ);
	oc.chosen=NULL; jiffies=panic_on_oom_timeout;
	check_panic_on_oom(&oc); assert(oc.chosen==LONGEST_OOM);
	oc.chosen=NULL; ++jiffies;
#endif
	expect_panic=true;
	if (setjmp(panic_return)==0) { check_panic_on_oom(&oc); assert(0); }
	assert(dumps==1);expect_panic=false;
#ifdef CONFIG_PRIORITIZE_OOM_TASKS
	jiffies=panic_on_oom_timeout+20*HZ;
	check_panic_on_oom(&oc); assert(panic_on_oom_timeout==jiffies+5*HZ);
	oc.chosen=NULL;
	jiffies=ULONG_MAX-40; panic_on_oom_timeout=0;
	check_panic_on_oom(&oc);
	jiffies+=80; oc.chosen=NULL; check_panic_on_oom(&oc); assert(oc.chosen==LONGEST_OOM);
	sysctl_panic_on_oom=0; oc.chosen=NULL;
	assert(out_of_memory(&oc) && killed && !panic_on_oom_timeout);
#endif
	clean();
}
int main(void)
{
	pairs_test(); exclusions(); special_tasks(); panic_tests();
	printf("PASS mode=%s threshold=%d, %u paired selections, global/memcg, exclusions, references and panic timing\n",
	       MODE,THRESHOLD,pairs);
	return 0;
}
