"""Check the call relocations emitted by Kbuild and ThinLTO in the ARM64 F2FS object."""
import argparse
import json
from pathlib import Path
import re
import struct
import subprocess

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('readelf',type=Path)
p.add_argument('object',type=Path)
p.add_argument('result',type=Path)
args=p.parse_args()
with args.object.open('rb') as f:
    header=f.read(20)
if header[:6]!=b'\x7fELF\x02\x01' or struct.unpack_from('<HH',header,16)!=(1,183):
    raise SystemExit('Expected AArch64 ELF relocatable')
expected={('__f2fs_setxattr','xa_store'),('f2fs_do_sync_file','xa_load'),
          ('f2fs_write_checkpoint','xa_destroy'),('f2fs_release_ino_entry','xa_destroy')}
found=set()
caller=None
with subprocess.Popen([args.readelf,'-rW',args.object], stdout=subprocess.PIPE,text=True) as proc:
    for line in proc.stdout:
        if line.startswith('Relocation section '):
            match=re.match(r"Relocation section '\.rela\.text\.([^']+)'",line)
            caller=match.group(1).split('$')[0] if match else None
        elif caller:
            fields=line.split()
            if len(fields)>=5 and fields[2] in ('R_AARCH64_CALL26','R_AARCH64_JUMP26'):
                found.add((caller,fields[4]))
    if proc.wait():
        raise SystemExit('Could not read ARM64 relocations')
if expected-found:
    raise SystemExit('Missing ARM64 calls: '+str(sorted(expected-found)))
args.result.write_text(json.dumps(sorted(expected),indent=2)+'\n')
print('Four ARM64 F2FS call sites verified')
