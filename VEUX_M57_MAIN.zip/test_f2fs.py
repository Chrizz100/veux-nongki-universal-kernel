"""Test the ported F2FS checkpoint decisions against this kernel's real XArray."""
import argparse
from pathlib import Path
import shutil
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('source', type=Path)
args = parser.parse_args()
src = args.source.resolve()
package = Path(__file__).resolve().parent
fs = src / 'fs/f2fs'
file_c = (fs / 'file.c').read_text()
xattr = (fs / 'xattr.c').read_text()
cp = (fs / 'checkpoint.c').read_text()
header = (fs / 'f2fs.h').read_text()

def section(code, opening, following):
    start = code.index(opening)
    return code[start:code.index(following, start)]

enum = section(header, 'enum cp_reason_type {', 'enum iostat_type')
mark = section(xattr, 'static void f2fs_track_dir_xattr(', 'static int __f2fs_setxattr(')
reason = section(file_c, 'static inline enum cp_reason_type need_do_checkpoint', 'static bool need_inode_page_update')
complete = section(cp, '\terr = do_checkpoint(sbi, cpc);', 'stop:')
sync = section(file_c, '\t\tret = f2fs_sync_fs(inode->i_sb, 1);', '\n\t}\nsync_nodes:')
write = section(xattr, 'error = write_all_xattrs(', 'exit:\n')
assert write.index('if (error)\n\t\tgoto exit;') < write.index('f2fs_track_dir_xattr(inode);')
assert 'xa_init(&sbi->xattr_dirs)' in section(cp, 'void f2fs_init_ino_entry_info(', 'int __init f2fs_create_checkpoint')
assert 'if (all)\n\t\txa_destroy(&sbi->xattr_dirs);' in section(cp, 'void f2fs_release_ino_entry(', 'void f2fs_set_dirty_device')
assert 'unblock_operations(sbi)' not in complete
entry = section(cp,'int f2fs_write_checkpoint(', 'void f2fs_init_ino_entry_info')
assert entry.index('block_operations(sbi)') < entry.index(complete) < entry.rindex('unblock_operations(sbi)')

with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    dest = root / 'tools/testing/radix-tree'
    shutil.copytree(src / 'tools/testing/radix-tree', dest)
    for sub in ('lib', 'include', 'tools/include', 'tools/lib'):
        (root / sub).symlink_to(src / sub, target_is_directory=True)
    # Let liburcu supply synchronize_rcu instead of the old tools-header stub.
    shim = dest / 'linux/rcupdate.h'
    shim.write_text(shim.read_text().replace('#include <urcu.h>', '#undef synchronize_rcu\n#include <urcu.h>'))
    (dest / 'production.inc').write_text(enum + mark + reason +
        '\nstatic void commit_fixture(struct f2fs_sb_info *sbi, int cpc)\n{\nint err;\n' + complete + '}\n' +
        'static int sync_fixture(struct inode *inode)\n{\nstruct f2fs_sb_info *sbi = inode->i_sb;\nint ret;\n'+
        sync+'\nout:\nreturn ret;\n}\n')
    shutil.copyfile(package/'test_f2fs.c', dest/'m52.c')
    # The upstream userspace slab adapter otherwise assumes blocking allocations succeed.
    # Wrap only its allocator to inject an actual ENOMEM return into xa_store.
    flags = ['-std=gnu11','-I.', '-I../../include','-g','-Og','-D_LGPL_SOURCE',
             '-fsanitize=address,undefined','-fno-sanitize-recover=all']
    objs = 'xarray.o radix-tree.o idr.o linux.o test.o find_bit.o bitmap.o'.split()
    subprocess.run(['make','-s','-j2','SHIFT=6',*objs],cwd=dest,check=True)
    for mode in ('enabled','disabled'):
        cmd=['gcc',*flags,'-Wall','-Werror','-Wno-unused-parameter','-o','m52','m52.c',*objs,
             '-Wl,--wrap=kmem_cache_alloc','-lpthread','-lurcu']
        if mode=='enabled':cmd.insert(1,'-DCONFIG_F2FS_CP_OPT=1')
        subprocess.run(cmd,cwd=dest,check=True)
        subprocess.run(['./m52'],cwd=dest,check=True)
