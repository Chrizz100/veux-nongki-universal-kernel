// SPDX-License-Identifier: GPL-2.0-only
.text
.global _start
.type _start,%function
_start:
	mov x0, sp
	adr x18, shadow_stack
	bl run_atomics
	mov x8, #93
	svc #0

.bss
.balign 16
shadow_stack:
	.skip 1024
.section .note.GNU-stack,"",%progbits

.text
.global __stack_chk_fail
.type __stack_chk_fail,%function
__stack_chk_fail:
	mov x0, #99
	mov x8, #93
	svc #0

.section .rodata
.balign 8
.global __stack_chk_guard
__stack_chk_guard:
	.quad 0x47c9a1f62e84b300
