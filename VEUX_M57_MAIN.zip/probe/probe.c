// SPDX-License-Identifier: GPL-2.0-only
#include <linux/atomic.h>
#include <uapi/asm/hwcap.h>
#include <uapi/linux/auxvec.h>

int run_atomics(const unsigned long *initial_stack);
int run_atomics(const unsigned long *initial_stack)
{
	const unsigned long argc = *initial_stack;
	const unsigned long *env = initial_stack + argc + 2;
	atomic_t small = ATOMIC_INIT(0);
	atomic64_t large = ATOMIC64_INIT(1LL << 40);
	const s64 start = 1LL << 40;
	int i, expected_lse;
	bool have_hwcap = false;

	if (argc != 2)
		return 1;
	expected_lse = *(const char *)initial_stack[2] - '0';
	while (*env++)
		;
	for (; env[0] != AT_NULL; env += 2) {
		if (env[0] == AT_HWCAP) {
			have_hwcap = true;
			if (!!(env[1] & HWCAP_ATOMICS) != expected_lse)
				return 2;
		}
	}
	if (!have_hwcap)
		return 3;
	for (i = 0; i < 65536; ++i) {
		if (atomic_fetch_add_relaxed(1, &small) != i ||
		    atomic_cmpxchg_acquire(&small, -1, 42) != i + 1 ||
		    atomic_xchg_release(&small, i + 1) != i + 1)
			return 4;
		if (atomic64_add_return(1, &large) != start + i + 1 ||
		    atomic64_cmpxchg(&large, start + i + 1, start + i + 2) != start + i + 1 ||
		    atomic64_fetch_sub_release(1, &large) != start + i + 2)
			return 5;
	}
	return atomic_read(&small) != 65536 || atomic64_read(&large) != start + 65536;
}
