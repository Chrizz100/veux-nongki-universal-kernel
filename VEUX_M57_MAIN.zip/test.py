"""Exercise the exact patched C functions with host-only PMIC and FDT fixtures."""
from pathlib import Path
import subprocess
import sys
import tempfile

src = Path(sys.argv[1]).resolve()
root = Path(__file__).resolve().parent
boot = (src / 'arch/arm64/kernel/bootinfo.c').read_text()
pon = (src / 'drivers/input/misc/qpnp-power-on.c').read_text()
enum = (src / 'arch/arm64/include/asm/bootinfo.h').read_text()
with tempfile.TemporaryDirectory() as tmp:
    out = Path(tmp)
    (out / 'code.inc').write_text(
        enum[enum.index('typedef enum'):enum.index('void __init')] +
        pon[pon.index('static int qpnp_pon_bootinfo_test'):pon.index('#endif', pon.index('EXPORT_SYMBOL(qpnp_pon_is_lpk);'))] +
        boot[boot.index('static u32 powerup_reason'):boot.index('static ssize_t powerup_reason_show')])
    subprocess.run(['cc', '-std=c11', '-Wall', '-Wextra', '-Werror', '-O2', '-fsanitize=undefined',
                    '-fno-sanitize-recover=all', '-I', str(out), root/'test_bootinfo.c', '-o', out/'test'], check=True)
    subprocess.run([out/'test'], check=True)
