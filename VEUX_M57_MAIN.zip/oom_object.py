"""Verify the compiled priority field, fallback scan and OOM timeout reset in the ARM64 object."""
from pathlib import Path
import argparse
import json
import re
import subprocess

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('bin', type=Path)
    p.add_argument('mode', choices=['on','off'])
    p.add_argument('obj', type=Path)
    p.add_argument('result', type=Path)
    a=p.parse_args()
    enabled=a.mode=='on'
    output=subprocess.check_output([a.bin/'llvm-readelf','-rW',a.obj],text=True)
    parts=re.split(r"Relocation section '([^']+)'[^\n]*\n",output)
    sections=dict(zip(parts[1::2],parts[2::2]))
    main=sections['.rela.text.out_of_memory']
    direct_scans=sum('R_AARCH64_CALL26' in line and ' mem_cgroup_scan_tasks + ' in line
                     for line in main.splitlines())
    if direct_scans != (2 if enabled else 1):
        raise ValueError('Unexpected number of compiled scan sites: '+str(direct_scans))
    reset='.bss.panic_on_oom_timeout' in sections['.rela.text.__oom_kill_process']
    if reset!=enabled:
        raise ValueError('Unexpected timeout reset code')
    debug=subprocess.check_output([a.bin/'llvm-dwarfdump','--name=oom_control','--show-children',a.obj],text=True)
    fields={}
    for block in debug.split('DW_TAG_member')[1:]:
        name=re.search(r'DW_AT_name\s+\("([^"]+)"\)',block)
        offset=re.search(r'DW_AT_data_member_location\s+\((0x[0-9a-f]+)\)',block)
        if name and offset: fields[name.group(1)]=int(offset.group(1),16)
    expected={'chosen_points':48,'min_kill_adj':56,'constraint':60} if enabled else {'chosen_points':48,'constraint':56}
    if {k:v for k,v in fields.items() if k in ('chosen_points','min_kill_adj','constraint')}!=expected:
        raise ValueError('Unexpected oom_control layout: '+str(fields))
    data=dict(mode=a.mode,memcg_scan_sites=direct_scans,reset_after_kill=reset,offsets=expected)
    a.result.write_text(json.dumps(data,indent=2)+'\n')
    print('PASS',data)

if __name__=='__main__':
    main()
