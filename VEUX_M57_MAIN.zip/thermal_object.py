"""Resolve the compiled thermal_ops, platform probe, PM and hotplug callback pointers."""
import json,re,subprocess,sys
from pathlib import Path
from check import require

tool,obj,dest=sys.argv[1:]
data=subprocess.check_output([tool, '-rW', obj],text=True)
parts=re.split(r"Relocation section '([^']+)'[^\n]*\n",data)
sections=dict(zip(parts[1::2],parts[2::2]))
def table(section):
    result={}
    for offset,name in re.findall(r'^([0-9a-f]+)\s+\S+\s+R_AARCH64_ABS64\s+\S+ (\S+) \+',sections[section],re.M):
        result[int(offset,16)]=name.split('$')[0]
    return result
ops=table('.rela.data.cooling_ops')
require(ops=={
    0:'cpu_isolate_get_max_state',8:'cpu_isolate_get_cur_state',16:'cpu_isolate_set_cur_state'},'thermal callback table')
driver=table('.rela.data.cpu_isolate_driver')
require(driver[0]=='cpu_isolate_probe' and driver[8]=='cpu_isolate_remove' and
        '.rodata.cpu_isolate_match' in driver.values(),'platform probe, teardown and DT match')
require(table('.rela.data.pm_nb')=={0:'cpu_isolate_pm_notify'},'PM notifier callback')
probe, = [v for k,v in sections.items() if k.split('$')[0]=='.rela.text.cpu_isolate_probe']
for name in ('cpu_isolate_hp_online','cpu_isolate_hp_offline'):
    require(re.search('R_AARCH64_ADR_PREL_PG_HI21\\s+\\S+ '+name+r'\$',probe) is not None,'Hotplug callback: '+name)
require(' __cpuhp_setup_state + ' in probe,'hotplug registration')
Path(dest).write_text(json.dumps({'ops':ops,'probe':driver[0],'remove':driver[8],
                                  'hotplug_callbacks':2,'pm_callback':'cpu_isolate_pm_notify'},indent=2)+'\n')
