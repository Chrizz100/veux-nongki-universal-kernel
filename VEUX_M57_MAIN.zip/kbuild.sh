#!/usr/bin/env bash
set -euo pipefail
src=$(realpath "$1")
out=$(realpath -m "$2")
tools=$(realpath "$3")/bin
shift 3
export PATH="$tools:$PATH"
make --no-print-directory -C "$src" O="$out" ARCH=arm64 LLVM=1 LLVM_IAS=1 \
    HOSTCC=gcc HOSTCXX=g++ CC="$tools/clang" LD="$tools/ld.lld" AR="$tools/llvm-ar" \
    NM="$tools/llvm-nm" OBJCOPY="$tools/llvm-objcopy" OBJDUMP="$tools/llvm-objdump" \
    STRIP="$tools/llvm-strip" -j"${KBUILD_JOBS:-2}" "$@"
