"""Create the device-test variant and exercise its packaged entry using regular slot fixtures."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import tempfile
import zipfile

HERE=Path(__file__).resolve().parent
def digest(path):
    with path.open("rb") as f: return hashlib.file_digest(f,"sha256").hexdigest()
def package(pair,stock):
    report=json.loads(next(pair.glob("*-Stock-Boot.json")).read_text())
    boot=next(pair.glob("*_boot_NOFLASH.img"))
    source=next(pair.glob("*AK3_NOFLASH.zip"))
    target=pair/"VEUX_S24_BakaSU35285_NoMount789_AK3_GERAETETEST.zip"
    if digest(boot)!=report["boot_sha256"] or digest(stock)!=report["stock_boot_sha256"] or digest(source)!=report["ak3_sha256"]: raise ValueError("Boot pair digest")
    with zipfile.ZipFile(source) as template, zipfile.ZipFile(target,"w") as archive:
        for item in template.infolist():
            data=template.read(item)
            if item.filename=="anykernel.sh":
                entry=data.decode().replace("# AnyKernel3 review for the exact stock base. No partition is written.","# AnyKernel3 device-test installer for VEUX Global Android 13.")
                entry=entry.replace("Stock-Repack-Pruefung NOFLASH","Android 13 GERAETETEST")
                lines=entry.splitlines()
                if not lines[-1].startswith("ui_print ") or "Keine Partition beschrieben." not in lines[-1]:
                    raise ValueError("Unknown AK3 entry")
                lines[-1]='sh "$AKHOME/veux/install-verified.sh" "$AKHOME/m45-stock.img" "$AKHOME/m45-review/reviewed-boot.img" "$BLOCK" "$SLOT" '+report["stock_boot_sha256"]+" "+report["boot_sha256"]+' || abort "Prüfung oder Schreiben des aktiven Boot-Slots fehlgeschlagen"'
                lines.append('ui_print "Boot-Slot geschrieben und zurückgelesen. Gerätepass offen."')
                data=("\n".join(lines)+"\n").encode()
            archive.writestr(item,data)
        item=zipfile.ZipInfo("veux/install-verified.sh",(2026,11,25,0,0,0)); item.external_attr=0o100755<<16;item.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(item,(HERE/"install-verified.sh").read_bytes())
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None or hashlib.sha256(z.read("Image")).hexdigest()!=report["kernel_sha256"]: raise ValueError("AK3 payload")
        with tempfile.TemporaryDirectory(dir=pair.parent) as tmp:
            tmp=Path(tmp).resolve(); home=tmp/"ak";z.extractall(home)
            bin=home/"tools";arm=bin/"magiskboot.arm";(bin/"magiskboot").rename(arm);arm.chmod(0o700)
            (bin/"magiskboot").write_text("#!/bin/sh\nexec "+shlex.quote(shutil.which("qemu-arm"))+" "+shlex.quote(str(arm))+' "$@"\n')
            (bin/"magiskboot").chmod(0o700)
            core=bin/"ak3-core.sh";s=core.read_text()
            if s.count("\nsetup_ak;")!=1: raise ValueError("Unknown recovery framework")
            core.write_text(s.replace("\nsetup_ak;",'\nBLOCK="$TEST_BLOCK"; SLOT="$TEST_SLOT";'))
            cmd=tmp/"commands";cmd.mkdir(); dd=cmd/"dd"
            dd.write_text("""#!/bin/sh
case "$*" in
  *reviewed-boot.img*"of=$TEST_BLOCK"*)
    if [ "${TEST_BREAK_WRITE:-0}" = 1 ] && [ ! -e "$TEST_MARK" ]; then
      : > "$TEST_MARK"
      head -c 4096 "$AKHOME/m45-review/reviewed-boot.img" | /bin/dd "of=$TEST_BLOCK" conv=notrunc status=none
      exit 1
    fi
    ;;
esac
exec /bin/dd "$@"
""")
            dd.chmod(0o700)
            a,b=tmp/"boot_a",tmp/"boot_b"
            cases=[]
            def run(label,block,slot,ok,expected,interrupt=False):
                # Use independent slot copies; never link a writable test slot to the reference.
                if (home/"m45-review").exists(): shutil.rmtree(home/"m45-review")
                other=b if block==a else a
                untouched=digest(other)
                env=dict(os.environ,AKHOME=str(home),OUTFD="1",TEST_BLOCK=str(block),TEST_SLOT=slot,TEST_BREAK_WRITE=str(int(interrupt)),TEST_MARK=str(tmp/"failure-injected"),PATH=str(cmd)+os.pathsep+os.environ["PATH"])
                proc=subprocess.run(["sh","anykernel.sh"],cwd=home,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                if (proc.returncode==0)!=ok or digest(block)!=expected or digest(other)!=untouched:
                    raise ValueError(label+" "+proc.stdout.decode(errors="replace")[-600:])
                cases.append(label)
            for f in (a,b): shutil.copyfile(stock,f)
            run("reject wrong slot suffix",a,"_b",False,report["stock_boot_sha256"])
            run("reject unknown slot",a,"",False,report["stock_boot_sha256"])
            b.write_bytes(b"wrong base");run("reject foreign boot image",b,"_b",False,digest(b));shutil.copyfile(stock,b)
            run("restore original after partial write",a,"_a",False,report["stock_boot_sha256"],True)
            if not (tmp/"failure-injected").exists(): raise ValueError("Fault injection did not run")
            run("write and reread slot A",a,"_a",True,report["boot_sha256"])
            run("write and reread slot B",b,"_b",True,report["boot_sha256"])
            if digest(stock)!=report["stock_boot_sha256"]: raise ValueError("Reference changed")
    out={"installer":target.name,"installer_sha256":digest(target),"boot_sha256":report["boot_sha256"],"regular_file_tests":cases,
         "source_must_be_exact_xiaomi_boot":True,"writes_only_selected_boot_slot":True,"device_pass":False,"production_release":False}
    (pair/"AK3-Geraetetest-Statik.json").write_text(json.dumps(out,indent=2)+"\n")
    print(f"{len(cases)} AK3 installation cases passed on regular files")
if __name__=="__main__":
    import sys
    package(*(Path(x).resolve() for x in sys.argv[1:]))
