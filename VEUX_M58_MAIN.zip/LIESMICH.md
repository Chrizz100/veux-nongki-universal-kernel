# VEUX M58 – zRAM-Seitenzustände und Kompressionsgrenze

Reparaturpaket für POCO X4 Pro 5G (veux), Xiaomi V816.0.12.0.TKCMIXM und Kernel `5.4.274-qgki-g82179e362f33`.

## Auf GitHub bauen

1. `VEUX_M58_MAIN.zip` unentpackt im Hauptverzeichnis des Repositorys speichern.
2. `VEUX_M58_ZRAM_NOFLASH.yml` im selben Branch unter `.github/workflows/` speichern.
3. In Actions den M58-Workflow manuell starten. Er baut alle vier Reparaturen gemeinsam.

Der Workflow lädt das M57-Quellarchiv aus Actions-Artefakt 14762106015 und Xiaomis Referenz aus Artefakt 14706022228. Die YAML prüft den SHA-256 der MAIN.zip. Die Eingangsprüfung authentifiziert die beiden Archive, den Quell-Tarball, die Build-Konfiguration und die Stock-boot.img. Nach dem Patch prüft sie die SHA-256 der beiden geänderten Treiberdateien. Die Artefakte müssen in GitHub noch verfügbar sein. Der Workflow benötigt Lesezugriff auf Repository und Actions.

## Befund aus M57

Der Job hat 13 von 13 Schritten bestanden. Beide Archive wurden heruntergeladen und gegen ihre GitHub-SHA-256 geprüft. Für alle 56 Nachweisdateien und alle vier Dateien des Quellstands enthält `Nachweise/M57-Artefaktinventar.json` die Größe und die SHA-256. Der erneute Abgleich des GitHub-Images bestätigt die fünf MIUI-Statistikschnittstellen, 22 von 26 Stock-zRAM-Dateien, den Standardkompressor, die geprüften OOM-, Reaper-, Atomik- und Thermikpfade sowie das statische Boot-Layout. Bei 3.148 Importverwendungen aus 37 Xiaomi-Vendormodulen passen CRC und Exportanbieter. [M57-Job](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45039393264/job/137260228361)

## Gemeinsame Reparatur

| Schnittstelle unter /sys/block/zram0/ | Zugriff | Verhalten |
|---|---|---|
| new | 0200 | Die Eingabe `all` setzt Altersklasse und Idle-Markierung für die Slots zurück. |
| new_stat | 0444 | Liefert die Anzahl berücksichtigter Seiten in Altersklasse null. |
| idle_stat | 0444 | Liefert zehn durch Leerzeichen getrennte Zähler für die Altersklassen 1 bis 10. Die letzte Klasse sättigt bei 10. |
| low_compress_ratio | 0644 | Globaler Schwellenwert. Die anfängliche geforderte Platzersparnis beträgt 75 Prozent. Eine Änderung wirkt beim Schreiben einer Seite. |

Der Treiber berechnet die ganzzahlige Platzersparnis aus gespeicherter Seitengröße und unkomprimierter Größe. Die Seite erhält das Kennzeichen für geringe Kompression, wenn die Ersparnis unter der Grenze liegt. Bei 4.096 Byte Seitengröße und einer Grenze von 75 erreicht eine auf 1.024 Byte komprimierte Seite die Vorgabe. Eine mit 1.025 Byte unterschreitet sie. Der Vergleich, die Standardgrenze und das Setzen des Kennzeichens sind im verlinkten Xiaomi-Image nachvollzogen. Die Statistik zählt geeignete Seiten im RAM. Bereits ausgelagerte Seiten und Seiten in laufendem Writeback sind ausgeschlossen.

M58 ergänzt im vorhandenen `mm_stat` den neunten Stock-Zähler. Die Alterung über `idle`, das Zurücksetzen bei Zugriff oder Freigabe und die Seitenauswahl für Writeback verwenden dieselben Zustände. Die Writeback-Schnittstelle verarbeitet `idle` mit optionaler maximaler Seitenzahl und Mindestalter sowie `huge`. Klassifikation und Buchführung laufen unter der Slot-Sperre. Die vorhandenen fünf MIUI-Statistiken aus M57 werden im selben Build erneut geprüft. Referenz sind das Xiaomi-Bootimage und der öffentliche VEUX-Treiber. [Xiaomi-Quellstand](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/block/zram/zram_drv.c)

## Prüfumfang

- Der Funktionstest kompiliert die tatsächlichen sysfs- und Slot-Funktionen mit nachgebildeten Kernelschnittstellen. Er vergleicht 421.991 Kombinationen aus Objektgröße und Schwellenwert mit einer unabhängigen Rechnung. Er prüft Grenzwerte, Altersklassen, Zugriff, Freigaben, Writeback-Auswahl und gleichzeitige Statistikanfragen und Änderungen.
- Die drei ARM64-Objektvarianten verwenden die Stock-Konfiguration oder deaktivieren einzeln Writeback und MIUI-Tracking. Der Image-Vergleich löst die gesamte zRAM-Attributgruppe samt Dateimodus und den Zieladressen der vorgesehenen Lese- und Schreibfunktionen auf. Die Schwelle und die Berechnung werden zusätzlich im ARM64-Schreibpfad nachgewiesen, das neunte Statistikfeld im Pfad von `mm_stat_show`.
- Der Workflow übernimmt die bisherigen Bootinfo-, DTB-, Thermik-, F2FS-, OOM-, Reaper-, Atomik-, Modul- und Layoutprüfungen. Die vollständige Build-Konfiguration muss bytegleich mit dem authentifizierten M57-Stand sein.
- Die GitHub-Ausgaben sind Prüfnachweise und der Quellstand für die nächste Reparatur. Ein praktischer Test des Kernels auf dem Telefon, der Betrieb von Boot, Verity und UFS sowie die Wiederherstellung aus dem gesicherten Geräte-Image bleiben offen. Die Flash-Freigabe steht aus.

## Weitere Reparaturgruppen

`Restgruppen.csv` ordnet alle 48 textlichen Konfigurationsunterschiede jeweils genau einer von sieben Gruppen zu. Die Gruppen enthalten 15 Werkzeugketten- und Architekturmerkmale, neun Einträge mit bereits geprüfter Auswirkung auf den gebauten Kernel, acht Dateisystemeinträge, sieben Geräteeinträge, vier Scheduler- und Diagnoseeinträge, vier Xiaomi-Speicher- und Diensteeinträge sowie einen UFS-Eintrag. Die Anzahl der Einträge beschreibt die Konfiguration. Die vier hier behobenen Unterschiede im Treiberverhalten waren bei derselben Konfiguration sichtbar.

Den nächsten Stock-Abgleich hat der UFS-Pfad bei der Erkennung des Laufwerks verdient. Im Xiaomi-Image kann `sd_probe` die Funktion `ufs_ffu` aufrufen. Von dort führen bedingte Pfade zum Firmware-Schreibbefehl und zum Neustart. Im M57-Symbolbestand fehlen der gleichnamige Einstieg und der Konfigurationsschalter. Die Symbole des eigentlichen Qualcomm-UFS-Treibers und der Verity-Fehlerbehandlung sind vorhanden. Im nächsten Paket sind die Stock-Aufrufbedingungen und die Zuordnung zu Speicherbaustein und Firmware zu prüfen. Die Vergleichsdaten stehen in `Nachweise/Xiaomi-UFS-Aufrufe.json` und `Nachweise/Subsystem-Symbole.json`. Weitere Kandidaten für gemeinsame Prüfungen sind die Xiaomi-Speicherstatistiken und Millet sowie die Dateisystemtreiber.

## Lokaler Vollbau

Der vollständige ARM64-Bau von Image, vmlinux, VEUX-DTB und vier Modulen bestand die Nachprüfung. Die SHA-256 des lokalen Images lautet `b6a1b057673603563737ed55157147899375e0c0ac9295400dcf272203aa3e25`. Alle 26 zRAM-Dateien stimmen bei Namen, Zugriffsmodus und Funktionszuordnung mit Xiaomi überein. Der Vergleich im ARM64-Image bestätigt auch die strikte Kompressionsgrenze, den Standardwert 75 und neun Felder in mm_stat. Negativtests verändern gezielt einen Callback, den Standardwert oder den bedingten Sprung im Speicher. Alle drei Änderungen werden erkannt. Alle 3.148 geprüften Vendor-Importe, das statische Boot-Layout und die eingebettete Konfiguration stimmen. Die ARM64-Atomik-Laufzeittests liefen unter QEMU, der lokale F2FS-Hosttest mit deaktiviertem LeakSanitizer. Ein eigenständiger GitHub-Lauf für M58 und Messungen auf dem Gerät stehen aus.
