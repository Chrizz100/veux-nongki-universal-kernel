"""Authenticate the M57 source and extract the matching Xiaomi reference image."""
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m57.zip') as archive:
    require(sha(work/'m57.zip')=='d1b977a15e07b33717e36dea10d74197b5e16ed2b858f14a6338503e004be031', 'M57 artifact digest')
    manifest=json.loads(archive.read('M57_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M57 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M57 config identity')
    archive.extract('M57-kernel-source.tar.gz',work)
tar=work/'M57-kernel-source.tar.gz'
require(sha(tar)=='018e22017729125aa9058dcfe6f943af13e12b001f0a633e1f3210d8c3c4b26b','M57 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'stock-zram.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
