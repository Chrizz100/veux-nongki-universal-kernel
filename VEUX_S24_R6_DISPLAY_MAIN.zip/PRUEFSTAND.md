# VEUX S24-R6 · Nachweis der Displayfehler

26. November 2026 · POCO X4 Pro 5G · HyperOS Global OS1.0.12.0.TKCMIXM

**S24-R6 ist lokal gebaut und statisch geprüft. GitHub-Lauf, Gerätetest und Flash-Freigabe stehen aus.** Der Original-Xiaomi-Stockkernel aus der identischen Global-OTA ist die Referenz. Die Kernelkennung ist 5.4.274-qgki-g82179e362f33. Die Buildnummer #6 kennzeichnet R6 im Gerätemitschnitt. [Xiaomi Global-OTA](https://bigota.d.miui.com/OS1.0.12.0.TKCMIXM/miui_VEUXGlobal_OS1.0.12.0.TKCMIXM_c42114b47d_13.0.zip)

## Reproduzierte Fehler

| Fall mit den Funktionen aus dem Produktionsquellcode | S24-R5 | S24-R6 |
| --- | --- | --- |
| Synchroner DCS-Transfer ohne Interrupt und ohne Abschlussbit nach dem 200-ms-Timeout | Rückgabe 0, obwohl kein DMA-Abschluss vorliegt | Rückgabe -110, der Treiber kann die Helligkeit erneut versuchen |
| Panel wechselt in LP2, der Regler meldet einen Fehler. Danach wird ON angefordert | Der Connector meldet Erfolg, das Panel bleibt in LP2 | Der Connector führt den Rückwechsel zu ON aus |
| Bildvorbereitung bricht vor dem DSI-Callback ab | Das Flag für asynchrones Warten bleibt gesetzt | Der Fehlerpfad setzt das Flag zurück |
| Die Helligkeit 800 wurde vorgemerkt und drei Schreibversuche schlagen fehl | Die Anforderung geht verloren und das Panel im Test bleibt bei 0 | Die Anforderung bleibt gespeichert. Nach dem nächsten erfolgreichen Bildauftrag erreicht der Testcontroller 800 |

Der DSI-Timeout ist eine fehlerhafte Erfolgsmeldung des Qualcomm-Displaytreibers. Die Fehlerverzweigung lässt sich im originalen Xiaomi-Image, im ausgelieferten S24-R3 und im GitHub-S24-R5 nachvollziehen. R13 und ConfigDiag10 zeigen denselben Aufruf des Wartepfads ohne ausgewerteten Fehlerstatus. Der tatsächliche Gerätebaum aus der Xiaomi-OTA enthält 15 zu dem im Gerätelog identifizierten `k6s_38_0c_0a` passenden Panelknoten. Alle 15 geben Videomodus an. Gewöhnliche Helligkeitsbefehle laufen dort synchron. Der Fehler beim Aufräumen des asynchronen Modus ist ein separater Befund.

| Originales Rohimage | Offset des DMA-Wartepfads | Offset des synchronen Senders | In den untersuchten Funktionen mit LLDB geprüfte Wörter |
| --- | ---: | ---: | ---: |
| Xiaomi Stock | `0x1049400` | `0x1048180` | 2.638 |
| GitHub S24-R3 | `0x11e442c` | `0x11e3310` | 2.615 |
| GitHub S24-R5 | `0x11e4620` | `0x11e3504` | 2.843 |
| Gerätebestätigtes R13 | `0xfd9278` | `0xfd8038` | 2.656 |
| Gerätebestätigtes ConfigDiag10 | `0xfd2b98` | `0xfd1958` | 2.656 |

Im gelinkten R6-Image erzeugt der Timeout-Zweig bei `0xffffffc0112647b0` den Wert -110. `dsi_message_tx` übernimmt ihn in `w25`, der verzögert ausgelöste Übertragungsweg in `w23`. Beide geben den Wert im Rückgaberegister `w0` aus. LLDB prüfte dafür elf Funktionen mit 2.492 Codewörtern. Der Test mit einem vorhandenen Abschlussbit trotz fehlenden Interrupts liefert wie zuvor Erfolg. Die Tests bestätigen auch den späten Interrupt, einen ausstehenden asynchronen Arbeitseintrag und das Aufräumen nach einem Timeout.

## Abgleich des lokalen R6-Images

LLDB las alle 5.940.066 Wortpositionen der fünf ausführbaren Abschnitte des lokalen R6. Für die historischen Abbilder sind die bekannten Abschnittsgrenzen berücksichtigt. Die Zählung vergleicht die gleiche Position im jeweiligen Abschnitt und umfasst Code, eingebettete Daten und Ausrichtung. Verlagerte Adressen beeinflussen die Zahl der Unterschiede.

| Referenz | Abschnitte | Vergleichbare Wörter | Abweichende Wörter | Gemeinsame eindeutige Textbereiche | Bytegleiche Textbereiche |
| --- | ---: | ---: | ---: | ---: | ---: |
| Xiaomi Stock | 5 | 5.772.739 | 5.755.570 | 60.443 | 5.397 |
| GitHub S24-R3 | 5 | 5.940.056 | 5.614.687 | 61.661 | 12.306 |
| GitHub S24-R5 | 5 | 5.940.066 | 1.390.887 | 61.865 | 20.156 |
| Gerätebestätigtes R13 | 3 | 5.813.300 | 5.803.590 | 47.297 | 4.222 |
| Gerätebestätigtes ConfigDiag10 | 3 | 5.810.769 | 5.801.055 | 47.232 | 4.218 |

- 1.187 Stock-Initialisierer und die Zielnamen der jeweils 441 nativen und kompatiblen Systemaufrufe wurden bestätigt.
- 3.148 Importzeilen der 37 Original-QGKI-Module sind geprüft. Bei den weiteren 66 GKI-Dateien aus `vendor_boot` behalten alle 2.999 Importzeilen denselben Prüfstatus wie unter GitHub-R5.
- Die bisherigen Prüfungen für Goodix, HBM, pstore, Wakeup sowie den Android-Starter bestanden erneut. Die pstore-Sicherung übernimmt das vorhandene Xiaomi-Speicherlayout.
- Die lesende AK3-Vorprüfung bestand sieben Fälle mit Dateikopien. Xiaomi Stock und die exakte R13-Sicherung für Slot A und B ergaben dasselbe Prüfabbild.

| Prüfsumme SHA-256 | Wert |
| --- | --- |
| Lokales R6-Kernelimage | `bc8971db176bad5daa4a190f2f01a5055cf77f39f10c083f15a2c283cd9186b7` |
| Lokales R6-Bootabbild | `629004656638d37b004d602933b4851a3f6e120959138a031b9809748ed0132b` |
| Original-Xiaomi-Stockkernel | `6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b` |

Die reproduzierten Abläufe können ein dunkles Display verursachen, während Android weiterläuft. Der vorhandene S24-R3-Gerätemitschnitt endet nach 6,75 Sekunden. Der Auslöser des konkreten Hängers nach der PIN und der Zustand von Android in diesem Moment bleiben offen. [Bisheriges GitHub-R5-Image](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45751820696/job/139681161311)
