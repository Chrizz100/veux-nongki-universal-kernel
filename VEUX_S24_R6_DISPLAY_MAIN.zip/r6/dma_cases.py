"""Run the DSI controller's production TX code with injected completion events."""
import argparse
from pathlib import Path
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parent / "r5"))
from source_functions import function, run_case

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path)
parser.add_argument("--before", action="store_true")
args = parser.parse_args()
controller = (args.source / "techpack/display/msm/dsi/dsi_ctrl.c").read_text()
names = [
    "dsi_ctrl_dma_cmd_wait_for_done", "dsi_kickoff_msg_tx",
    "dsi_ctrl_validate_msg_flags", "dsi_message_tx", "dsi_ctrl_cmd_transfer",
    "dsi_ctrl_cmd_tx_trigger",
]
if not args.before:
    names.insert(0, "dsi_ctrl_wait_dma_done")
test = [
    (here / "dma_harness.h").read_text(),
    f"#define EXPECT_TIMEOUT {int(not args.before)}",
    *(function(controller, name) for name in names),
    (here / "dma_cases.c").read_text(),
]
run_case("\n".join(test), "dsi_dma")
