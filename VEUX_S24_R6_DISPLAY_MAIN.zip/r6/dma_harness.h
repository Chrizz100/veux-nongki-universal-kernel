#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef uint8_t u8;
typedef uint32_t u32;

#define BIT(n) (1u << (n))
#define ALIGN(n, a) (((n) + (a) - 1) & ~((a) - 1))
#define CEIL(n, a) (((n) + (a) - 1) / (a))
#define container_of(ptr, type, member) ((type *)((char *)(ptr) - offsetof(type, member)))
#define atomic_read(ptr) (*(ptr))
#define atomic_set(ptr, value) (*(ptr) = (value))
#define msecs_to_jiffies(ms) (ms)
#define SDE_EVT32(...) ((void)0)
#define DSI_CTRL_ERR(...) ((void)0)
#define DSI_CTRL_WARN(...) ((void)0)
#define DSI_CTRL_DEBUG(...) ((void)0)
#define local_irq_save(flags) do { (flags) = 1; } while (0)
#define local_irq_restore(flags) assert(flags)
#define DSI_CTRL_TX_TO_MS 200
#define DSI_CMD_MODE_DMA_DONE BIT(0)
#define DSI_BTA_DONE BIT(1)
#define DSI_SINT_CMD_MODE_DMA_DONE 0
#define DSI_CTRL_CMD_FETCH_MEMORY BIT(0)
#define DSI_CTRL_CMD_FIFO_STORE BIT(1)
#define DSI_CTRL_CMD_READ BIT(2)
#define DSI_CTRL_CMD_NON_EMBEDDED_MODE BIT(3)
#define DSI_CTRL_CMD_LAST_COMMAND BIT(4)
#define DSI_CTRL_CMD_BROADCAST BIT(5)
#define DSI_CTRL_CMD_BROADCAST_MASTER BIT(6)
#define DSI_CTRL_CMD_DEFER_TRIGGER BIT(7)
#define DSI_CTRL_CMD_CUSTOM_DMA_SCHED BIT(8)
#define DSI_CTRL_CMD_ASYNC_WAIT 0x200
#define DSI_CTRL_HW_CMD_WAIT_FOR_TRIGGER BIT(10)
#define MIPI_DSI_MSG_LASTCOMMAND BIT(3)
#define MIPI_DSI_MSG_ASYNC_OVERRIDE BIT(4)
#define MIPI_DSI_MSG_USE_LPM BIT(5)
#define DSI_OP_CMD_MODE 0
#define DSI_OP_VIDEO_MODE 1
#define DSI_CTRL_ENGINE_ON 1
#define DSI_CTRL_VERSION_2_4 4
#define DSI_CTRL_OP_CMD_TX 1
#define ENOTSUPP 524

struct work_struct { unsigned int unused; };
struct mipi_dsi_msg {
    u32 flags, wait_ms, type;
    size_t tx_len;
    const void *tx_buf;
};
struct mipi_dsi_packet { u32 size; u8 header[4]; };
struct dsi_ctrl_cmd_dma_fifo_info {
    u32 *command;
    u32 size;
    bool en_broadcast, is_master, use_lpm;
};
struct dsi_ctrl_cmd_dma_info {
    u32 offset, datatype, length;
    bool en_broadcast, is_master, use_lpm;
};
struct dsi_mode_info { u32 v_sync_width, v_back_porch, v_front_porch, v_active, refresh_rate; };
struct dsi_ctrl_hw;
struct dsi_ctrl_hw_ops {
    u32 (*get_interrupt_status)(struct dsi_ctrl_hw *);
    void (*clear_interrupt_status)(struct dsi_ctrl_hw *, u32);
    void (*reset_trig_ctrl)(struct dsi_ctrl_hw *, void *);
    void (*init_cmddma_trig_ctrl)(struct dsi_ctrl_hw *, void *);
    void (*kickoff_command)(struct dsi_ctrl_hw *, struct dsi_ctrl_cmd_dma_info *, u32);
    void (*kickoff_command_non_embedded_mode)(struct dsi_ctrl_hw *, struct dsi_ctrl_cmd_dma_info *, u32);
    void (*kickoff_fifo_command)(struct dsi_ctrl_hw *, struct dsi_ctrl_cmd_dma_fifo_info *, u32);
    void (*reset_cmd_fifo)(struct dsi_ctrl_hw *);
    void (*soft_reset)(struct dsi_ctrl_hw *);
    void (*schedule_dma_cmd)(struct dsi_ctrl_hw *);
    void (*trigger_command_dma)(struct dsi_ctrl_hw *);
    u32 (*log_line_count)(struct dsi_ctrl_hw *, bool);
};
struct dsi_ctrl_hw { struct dsi_ctrl_hw_ops ops; bool reset_trig_ctrl; };
struct platform_device { int dev; };
struct dsi_ctrl {
    struct dsi_ctrl_hw hw;
    struct {
        int panel_mode, common_config;
        struct dsi_mode_info video_timing;
    } host_config;
    struct { int cmd_dma_done; } irq_info;
    struct { int vid_engine_state; } current_state;
    struct work_struct dma_cmd_wait;
    struct platform_device *pdev;
    void *dma_cmd_workq, *tx_cmd_buf;
    u8 vaddr[64];
    unsigned int cmd_len, cmd_buffer_iova, version, cell_index;
    int ctrl_lock, dma_irq_trig, cmd_trigger_line, cmd_trigger_frame;
    bool cmd_mode, dma_wait_queued, enable_cmd_dma_stats;
};

static unsigned long completion_result;
static u32 interrupt_status, cleared_status;
static unsigned int starts, waits, queued_calls, disabled, fifo_resets;
static bool late_irq;
static u32 get_status(struct dsi_ctrl_hw *h) { return interrupt_status; }
static void clear_status(struct dsi_ctrl_hw *h, u32 status) { cleared_status = status; }
static void start_mem(struct dsi_ctrl_hw *h, struct dsi_ctrl_cmd_dma_info *m, u32 flags) { starts++; }
static void start_fifo(struct dsi_ctrl_hw *h, struct dsi_ctrl_cmd_dma_fifo_info *m, u32 flags) { starts++; }
static void trigger(struct dsi_ctrl_hw *h) { starts++; }
static void reset_fifo(struct dsi_ctrl_hw *h) { fifo_resets++; }
static void mutex_lock(int *lock) { assert((*lock)++ == 0); }
static void mutex_unlock(int *lock) { assert(--(*lock) == 0); }

static unsigned long wait_for_completion_timeout(int *value, unsigned long delay)
{
    struct dsi_ctrl *ctrl = container_of(value, struct dsi_ctrl, irq_info.cmd_dma_done);
    assert(delay == 200);
    waits++;
    if (late_irq)
        ctrl->dma_irq_trig = 1;
    return completion_result;
}

static void dsi_ctrl_disable_status_interrupt(struct dsi_ctrl *c, int id) { disabled++; }
static void dsi_ctrl_enable_status_interrupt(struct dsi_ctrl *c, int id, void *arg) {}
static void reinit_completion(int *value) { *value = 0; }
static void queue_work(void *q, struct work_struct *work) { queued_calls++; }
static void dsi_ctrl_wait_for_video_done(struct dsi_ctrl *c) {}
static void dsi_ctrl_mask_overflow(struct dsi_ctrl *c, bool enable) {}
static void dsi_ctrl_flush_cmd_dma_queue(struct dsi_ctrl *c) { c->dma_wait_queued = false; }
static void dsi_ctrl_clear_slave_dma_status(struct dsi_ctrl *c, u32 flags) {}
static void dsi_configure_command_scheduling(struct dsi_ctrl *c, struct dsi_ctrl_cmd_dma_info *m) {}
static void dsi_message_setup_tx_mode(struct dsi_ctrl *c, u32 length, u32 *flags) {}
static int dsi_message_validate_tx_mode(struct dsi_ctrl *c, u32 length, u32 *flags) { return 0; }
static int dsi_ctrl_check_state(struct dsi_ctrl *c, int operation, int state) { return 0; }
static void dsi_ctrl_update_state(struct dsi_ctrl *c, int operation, int state) {}
static int dsi_message_rx(struct dsi_ctrl *c, const struct mipi_dsi_msg *m, u32 *flags) { return 2; }
static void msm_gem_sync(void *buffer) {}
static int mipi_dsi_create_packet(struct mipi_dsi_packet *p, const struct mipi_dsi_msg *m)
{
    memset(p, 0, sizeof(*p));
    p->size = m->tx_len + sizeof(p->header);
    return 0;
}
static int dsi_ctrl_copy_and_pad_cmd(const struct mipi_dsi_packet *p, u8 *b, u32 size) { return 0; }
static void *devm_kzalloc(int *dev, unsigned int len, int flags) { return calloc(len, 1); }
static void devm_kfree(int *dev, void *ptr) { free(ptr); }
#define GFP_KERNEL 0
static u32 calculate_schedule_line(struct dsi_ctrl *c, u32 flags) { return 1; }
static void udelay(unsigned int usec) {}
