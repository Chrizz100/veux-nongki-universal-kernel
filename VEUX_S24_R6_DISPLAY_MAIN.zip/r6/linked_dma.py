"""Use LLDB and the final Image to check the ARM64 DMA timeout return path."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import struct
import sys

kit = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(kit / "oem"))
import proof

FUNCTIONS = (
    "dsi_ctrl_wait_dma_done", "dsi_ctrl_dma_cmd_wait_for_done", "dsi_message_tx",
    "dsi_ctrl_cmd_transfer", "dsi_ctrl_cmd_tx_trigger", "dsi_host_transfer",
    "sde_connector_pre_kickoff", "_sde_connector_update_power_locked",
    "dsi_display_set_power", "dsi_panel_restore_brightness", "dsi_panel_retry_wake_brightness",
)

def verify(build, evidence):
    path = build / "arch/arm64/boot/Image"
    raw = path.read_bytes()
    proof.FUNCTIONS = FUNCTIONS
    image = proof.Image("S24-R6-DMA", raw, (build / "vmlinux").resolve())
    evidence.mkdir(exist_ok=True, parents=True)
    decoded = image.debug(os.environ.get("LLDB", "lldb-19"), evidence)

    def word(offset):
        return struct.unpack_from("<I", raw, offset)[0]

    functions = {}
    for name in FUNCTIONS:
        start, end = image.ranges[name]
        words = (end - start) // 4
        proof.require(all(addr in decoded for addr in range(start, end, 4)),
                      name + " LLDB range")
        functions[name] = {
            "offset": hex(start), "words": words, "direct_calls": image.direct_calls(name)
        }
    wait = "dsi_ctrl_wait_dma_done"
    start, end = image.ranges[wait]
    timeout = [hex(proof.BASE + a) for a in range(start, end, 4)
               if word(a) & 0xffffffe0 == 0x12800da0]
    proof.require(len(timeout) == 1, "expected one ARM64 mov of -ETIMEDOUT")
    proof.require("wait_for_completion_timeout" in functions[wait]["direct_calls"],
                  "actual DMA completion wait")

    status_moves = {}
    for caller in ("dsi_message_tx", "dsi_ctrl_cmd_tx_trigger"):
        address, = functions[caller]["direct_calls"][wait]
        offset = int(address, 16) - proof.BASE
        following = word(offset + 4)
        proof.require(following & 0xffffffe0 == 0x2a0003e0,
                      caller + " saves the synchronous status")
        register = following & 31
        a, b = image.ranges[caller]
        moves = [hex(proof.BASE + p) for p in range(a, b, 4)
                 if word(p) == 0x2a0003e0 | (register << 16)]
        proof.require(bool(moves), caller + " returns the saved status")
        status_moves[caller] = {"call": address, "register": register, "return_moves": moves}
    proof.require("dsi_panel_retry_wake_brightness" in
                  functions["sde_connector_pre_kickoff"]["direct_calls"], "frame reschedules brightness")
    report = {
        "sha256": sha256(raw).hexdigest(), "functions": functions,
        "checked_words": sum(row["words"] for row in functions.values()),
        "etimedout_instructions": timeout, "synchronous_returns": status_moves,
        "device_pass": False, "flash_allowed": False,
    }
    (evidence / "Display-DMA-LLDB.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"{len(functions)} linked DSI functions, {report['checked_words']} words checked with LLDB")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path)
    parser.add_argument("evidence", type=Path)
    verify(**vars(parser.parse_args()))
