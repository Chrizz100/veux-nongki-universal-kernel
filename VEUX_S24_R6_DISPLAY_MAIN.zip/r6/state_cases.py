"""Replay power-mode reversal, kickoff cancellation and wake brightness recovery."""
import argparse
from pathlib import Path
import re
import sys

here = Path(__file__).resolve().parent
sys.path.insert(0, str(here.parent / "r5"))
from source_functions import function, run_case

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path)
parser.add_argument("--before", action="store_true")
args = parser.parse_args()
drivers = args.source / "techpack/display/msm"
panel = (drivers / "dsi/dsi_panel.c").read_text()
display = (drivers / "dsi/dsi_display.c").read_text()
connector = (drivers / "sde/sde_connector.c").read_text()
names = [
    "dsi_panel_update_backlight", "dsi_panel_set_backlight",
    "dsi_panel_enter_doze", "dsi_panel_reset_wake", "dsi_panel_restore_brightness",
    "dsi_panel_commit_power_mode", "dsi_panel_set_lp1", "dsi_panel_set_lp2",
    "dsi_panel_set_nolp",
]
if not args.before:
    names.append("dsi_panel_retry_wake_brightness")

stub = """
#include <assert.h>
#define SDE_EVT32_VERBOSE(...) ((void)0)
#define pr_info_ratelimited(...) ((void)0)
struct sde_connector_state { int rois, hdr_meta; };
#define to_sde_connector(c) container_of(c, struct sde_connector, base)
#define to_sde_connector_state(s) ((struct sde_connector_state *)(s))
static int dirty_result, kickoff_result;
static int _sde_connector_update_dirty_properties(struct drm_connector *c)
{
    assert(((struct dsi_display *)to_sde_connector(c)->display)->queue_cmd_waits);
    return dirty_result;
}
static int finish_kickoff(struct drm_connector *c, void *disp, struct msm_display_kickoff_params *params)
{
    struct dsi_display *display = disp;
    assert(display->queue_cmd_waits);
    assert(params->rois && params->hdr_meta);
    return kickoff_result;
}
"""
declaration = re.search(r"enum veux_brightness_phase \{[\s\S]*?^#else", panel, re.M)[0]
test = [
    (here.parent / "r5/panel_harness.h").read_text(),
    f"#define EXPECT_FIXED {int(not args.before)}",
    declaration.removesuffix("#else"), stub,
    *(function(panel, name) for name in names),
    *(function(display, name) for name in ("dsi_display_set_backlight", "dsi_display_set_power")),
    *(function(connector, name) for name in ("_sde_connector_update_power_locked", "sde_connector_pre_kickoff")),
    (here / "state_cases.c").read_text(),
]
run_case("\n".join(test), "display_state")
