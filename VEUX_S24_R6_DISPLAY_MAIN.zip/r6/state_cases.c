static void run_wake_worker(struct dsi_panel *panel)
{
    assert(panel->wake_brightness_work.pending);
    panel->wake_brightness_work.pending = false;
    dsi_panel_restore_brightness(&panel->wake_brightness_work.work);
}

int main(void)
{
    struct dsi_panel panel = {
        .bl_config = {.type = DSI_BACKLIGHT_DCS, .bl_scale = 1024, .bl_scale_sv = 65535},
        .host = 1, .cur_mode = 1, .panel_initialized = 1,
    };
    struct dsi_display display = {.panel = &panel};
    struct sde_connector_state state = {0};
    struct sde_connector connector = {
        .base.state = &state,
        .display = &display,
        .connector_type = DRM_MODE_CONNECTOR_DSI,
        .ops = {.set_power = dsi_display_set_power, .pre_kickoff = finish_kickoff},
        .lock = 1, .dpms_mode = DRM_MODE_DPMS_ON, .lp_mode = SDE_MODE_DPMS_LP2,
    };

    dirty_result = -EIO;
    assert(sde_connector_pre_kickoff(&connector.base) == -EIO);
    printf("Async flag after failed preparation: %d\n", display.queue_cmd_waits);
    assert(display.queue_cmd_waits == !EXPECT_FIXED);
    dirty_result = 0;
    connector.ops.pre_kickoff = NULL;
    assert(sde_connector_pre_kickoff(&connector.base) == 0);
    assert(display.queue_cmd_waits == !EXPECT_FIXED);
    connector.ops.pre_kickoff = finish_kickoff;
    kickoff_result = -EIO;
    assert(sde_connector_pre_kickoff(&connector.base) == -EIO && !display.queue_cmd_waits);
    kickoff_result = 0;

    ulp_error = -EIO;
    assert(_sde_connector_update_power_locked(&connector) == -EIO);
    assert(panel.power_mode == SDE_MODE_DPMS_LP2 && connector.power_update_pending);
    assert(connector.last_panel_power_mode == SDE_MODE_DPMS_ON);
    ulp_error = 0;
    connector.lp_mode = SDE_MODE_DPMS_ON;
    assert(_sde_connector_update_power_locked(&connector) == 0);
    printf("Panel mode after LP2 failure and requested ON: %d\n", panel.power_mode);
    assert(panel.power_mode == (EXPECT_FIXED ? SDE_MODE_DPMS_ON : SDE_MODE_DPMS_LP2));
    assert(!connector.power_update_pending && esd_on);

    assert(dsi_display_set_power(NULL, SDE_MODE_DPMS_ON, &display) == 0);
    assert(dsi_display_set_backlight(NULL, &display, 0) == 0);
    assert(dsi_display_set_power(NULL, SDE_MODE_DPMS_LP1, &display) == 0);
    assert(dsi_display_set_backlight(NULL, &display, 800) == 0);
    assert(dsi_display_set_power(NULL, SDE_MODE_DPMS_ON, &display) == 0);
    tx_error = -ETIMEDOUT;
    for (int retry = 0; retry < 3; retry++)
        run_wake_worker(&panel);
    printf("After three failed writes: pending value=%d, hardware brightness=%u\n",
           panel.wake_brightness_valid, level);
    assert(!level && !panel.wake_brightness_work.pending);
    assert(panel.wake_brightness_valid == EXPECT_FIXED);

    tx_error = 0;
    panel.esd_recovery_pending = 1;
    assert(sde_connector_pre_kickoff(&connector.base) == 0);
    assert(!panel.wake_brightness_work.pending);
    panel.esd_recovery_pending = 0;
    assert(sde_connector_pre_kickoff(&connector.base) == 0);
    assert(panel.wake_brightness_work.pending == EXPECT_FIXED);
    if (EXPECT_FIXED) {
        assert(panel.wake_brightness_work.delay == msecs_to_jiffies(250));
        run_wake_worker(&panel);
        assert(!panel.wake_brightness_valid && level == 800);
    }
    printf("After the next successful kickoff: hardware brightness=%u\n", level);
    puts("PASS connector rollback, early kickoff return and wake brightness recovery");
    return 0;
}
