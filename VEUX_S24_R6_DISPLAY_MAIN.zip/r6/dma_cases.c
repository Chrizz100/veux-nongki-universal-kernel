int main(void)
{
    struct platform_device device = {0};
    struct dsi_ctrl ctrl = {
        .pdev = &device,
        .hw.ops = {
            .get_interrupt_status = get_status,
            .clear_interrupt_status = clear_status,
            .kickoff_command = start_mem,
            .kickoff_fifo_command = start_fifo,
            .trigger_command_dma = trigger,
            .reset_cmd_fifo = reset_fifo,
        },
        .host_config = {
            .panel_mode = DSI_OP_VIDEO_MODE,
            .video_timing = {.v_active = 2400, .v_front_porch = 20, .refresh_rate = 120},
        },
    };
    u8 payload[] = {0x51, 0x03, 0x20};
    const struct mipi_dsi_msg message = {
        .flags = MIPI_DSI_MSG_LASTCOMMAND, .tx_len = sizeof(payload), .tx_buf = payload,
    };
    const int timeout = EXPECT_TIMEOUT ? -ETIMEDOUT : 0;
    u32 flags = DSI_CTRL_CMD_FETCH_MEMORY | DSI_CTRL_CMD_ASYNC_WAIT;
    int rc = dsi_ctrl_cmd_transfer(&ctrl, &message, &flags);
    printf("Video DCS transfer with no completion: rc=%d, starts=%u, waits=%u, async=%u\n",
           rc, starts, waits, queued_calls);
    assert(rc == timeout && starts == 1 && waits == 1 && disabled == 1);
    assert(!queued_calls && !ctrl.ctrl_lock && !ctrl.dma_wait_queued && fifo_resets == 1);

    completion_result = 1;
    flags = DSI_CTRL_CMD_FETCH_MEMORY;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 0 && waits == 2);
    completion_result = 0;
    interrupt_status = DSI_CMD_MODE_DMA_DONE;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 0);
    assert(cleared_status == (DSI_CMD_MODE_DMA_DONE | DSI_BTA_DONE));
    interrupt_status = 0;
    late_irq = true;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 0 && waits == 4);
    late_irq = false;

    flags = DSI_CTRL_CMD_FIFO_STORE;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == timeout && waits == 5);
    flags = DSI_CTRL_CMD_READ;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 2 && waits == 5);

    flags = DSI_CTRL_CMD_FETCH_MEMORY | DSI_CTRL_CMD_DEFER_TRIGGER |
        DSI_CTRL_CMD_LAST_COMMAND | DSI_CTRL_CMD_BROADCAST | DSI_CTRL_CMD_BROADCAST_MASTER;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 0 && waits == 5);
    rc = dsi_ctrl_cmd_tx_trigger(&ctrl, flags);
    printf("Deferred broadcast with no completion: rc=%d\n", rc);
    assert(rc == timeout && waits == 6 && !ctrl.ctrl_lock);

    ctrl.host_config.panel_mode = DSI_OP_CMD_MODE;
    flags = DSI_CTRL_CMD_FETCH_MEMORY | DSI_CTRL_CMD_ASYNC_WAIT;
    assert(dsi_ctrl_cmd_transfer(&ctrl, &message, &flags) == 0);
    assert(ctrl.dma_wait_queued && queued_calls == 1 && waits == 6);
    dsi_ctrl_dma_cmd_wait_for_done(&ctrl.dma_cmd_wait);
    assert(!ctrl.dma_wait_queued && waits == 7);
    puts("PASS completion, lost IRQ, late IRQ, timeout, deferred broadcast and async work");
    return 0;
}
