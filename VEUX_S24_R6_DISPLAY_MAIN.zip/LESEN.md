# VEUX S24-R6 · Display und Crashprotokoll

Kernel 5.4.274-qgki für POCO X4 Pro 5G und HyperOS Global OS1.0.12.0.TKCMIXM.

Das Paket baut auf S24-R5 einschließlich der bisherigen Xiaomi-, Touch-, Wakeup-, ABI- und Startkorrekturen auf. Die drei gepinnten Erweiterungsstände sind SUSFS 2.4.0, BakaSU 35285 und NoMount 789. Der Build kontrolliert die Einbindungsreihenfolge, linkt die fertige Kombination einmal und prüft die ausführbaren Abschnitte mit LLDB. Die Kernelmeldung enthält die Buildkennung #6, damit R6 in einem Gerätemitschnitt erkennbar ist.

## Display und Eingabe

Der DSI-Treiber meldet einen fehlenden synchronen DMA-Abschluss als Timeout. Das verhindert, dass ein solcher Transfer als erfolgreiche Helligkeitsänderung verbucht wird. Der Display-Connector räumt den asynchronen Modus auch auf Fehlerpfaden auf und wiederholt den ausstehenden Rückwechsel aus LP2. Helligkeitsanforderungen einschließlich Stufe 0 bleiben nach vorübergehenden Fehlern für den nächsten gültigen Bildauftrag oder eine neue Helligkeitsanforderung erhalten. Der erste Wiederherstellungsversuch behält die Xiaomi-Verzögerung von 50 ms. Goodix wiederholt weiterhin bestimmte vorübergehende Aufwachfehler einmal im Touch-Arbeitseintrag.

## Crashaufzeichnung

Der ramoops-Treiber kann bei einer Panic, einem Notneustart über den Kernel oder einem regulären Kernel-Neustart den jüngsten Kernelpuffer in die vorhandene persistente Konsole schreiben. Diese zusätzliche Sicherung greift bei Firmware ohne eigenen Dump-Bereich, sofern ein Konsolenbereich vorhanden ist. Sie verwendet höchstens 256 KiB und höchstens die Hälfte der Ringkapazität. Das Xiaomi-Speicherlayout bleibt für den bisherigen Kernel lesbar. Der Zugriff im Fehlerpfad wartet bei einer belegten Sperre nicht. Für Aufwachübergänge und fehlerhafte Display- oder Touch-Übertragungen gibt es zusätzliche Meldungen im Kernelprotokoll.

Bei kompletter Blockade, direktem Hardware-Reset oder Stromverlust kann der Kernel den abschließenden Mitschnitt verlieren. Dann ist die bis dahin erreichte Konsolenaufzeichnung die verfügbare Spur.

Nach einem fehlgeschlagenen Start und einem Rückflash kann Termux mit dem funktionierenden Kernel die erhaltenen Logs kopieren. Der Befehl liest beide gebräuchlichen Konsolennamen, vorhandene Crashdateien und die in pstore erhaltenen Android-Protokolle. [Android-Quellcode für `logcat -L`](https://android.googlesource.com/platform/system/logging/+/0c63e34de3db9d9274f8113b1cde667d19248055/logcat/logcat.cpp)

```sh
su -c '
ziel="/sdcard/Download/VEUX-Crashlog-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$ziel" || exit 1
for f in /sys/fs/pstore/console-ramoops* /sys/fs/pstore/unused-ramoops* /sys/fs/pstore/dmesg-ramoops*; do
  [ -f "$f" ] || continue
  cat "$f" > "$ziel/${f##*/}"
done
if [ -r /proc/last_kmsg ]; then
  cat /proc/last_kmsg > "$ziel/last_kmsg.txt"
fi
/system/bin/logcat -L -d -b main,system,crash,events -v threadtime \
  > "$ziel/Android-vor-Neustart.txt" 2> "$ziel/Android-Auslesestatus.txt"
{
  date
  uname -a
  for eigenschaft in ro.boot.bootreason sys.boot.reason.last; do
    printf "%s = " "$eigenschaft"
    getprop "$eigenschaft"
  done
} > "$ziel/Lesender-Kernel.txt"
ls -l "$ziel"
'
```

## GitHub Actions und Gerätestatus

Lege die MAIN-ZIP ins Repository-Hauptverzeichnis. Die YAML gehört nach `.github/workflows/`. Starte den Workflow nach dem Commit beider Dateien über **Run workflow**.

Das Ergebnis enthält ein Bootabbild für die statische Prüfung und eine lesende AK3-Vorprüfung für die verifizierten Xiaomi-Stock- und R13-Ausgangsabbilder. Die Prüfnachweise und der Buildlog werden getrennt gespeichert. Der Gerätetest und die Flash-Freigabe stehen aus.

[Ergebnisse des lokalen Builds, der Fehlertests und des Stock-Abgleichs](PRUEFSTAND.md)
