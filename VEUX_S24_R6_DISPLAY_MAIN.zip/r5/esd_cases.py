"""Exercise stock-derived display control paths with synthetic controller responses."""
from pathlib import Path
import re
import sys
from source_functions import function, run_case

kernel = Path(sys.argv[1])
display = (kernel / "techpack/display/msm/dsi/dsi_display.c").read_text()
panel = (kernel / "techpack/display/msm/dsi/dsi_panel.c").read_text()
mipi = (kernel / "drivers/gpu/drm/drm_mipi_dsi.c").read_text()

stub = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stddef.h>
#include <sys/types.h>
#include <errno.h>
typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t u8;
#define CONFIG_WT_QGKI 1
#define DSI_ERR(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
#define DSI_DEBUG(...) ((void)0)
#define MIPI_DSI_MODE_LPM 1
#define MIPI_DCS_SET_DISPLAY_BRIGHTNESS 0x51
#define MIPI_DSI_MSG_UNICAST 1
#define MIPI_DSI_MSG_ASYNC_OVERRIDE 2
#define MIPI_DSI_MSG_CMD_DMA_SCHED 4
#define DSI_CTRL_CMD_FETCH_MEMORY 1
#define DSI_CTRL_CMD_ASYNC_WAIT 2
#define DSI_CTRL_CMD_CUSTOM_DMA_SCHED 4
#define DSI_ALL_CLKS 3
#define DSI_CLK_ON 1
#define DSI_CLK_OFF 0
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x) = (v))
#define unlikely(x) (x)
#define atomic_read(p) (*(p))

struct dsi_display;
struct mipi_dsi_host { struct dsi_display *display; };
struct mipi_dsi_msg { int flags, ctrl; unsigned brightness; };
struct mipi_dsi_device { unsigned long mode_flags; struct mipi_dsi_host *host; };
struct dsi_panel {
    int esd_recovery_pending;
    struct mipi_dsi_device mipi_device;
    struct { bool lp_mode, bl_inverted_dbv; } bl_config;
    unsigned last_dcs_brightness;
    bool dcs_brightness_valid;
};
struct dsi_display {
    struct dsi_panel *panel;
    void *tx_cmd_buf;
    int enabled, ctrl_count, queue_cmd_waits, dsi_clk_handle;
    struct { int ctrl; } ctrl[1];
};
static int controller_calls, clock_calls, writes, io_error;
static unsigned hardware = 120;
static struct dsi_display *to_dsi_display(struct mipi_dsi_host *host) {return host->display;}
static int dsi_display_clk_ctrl(int h, int c, int on) {clock_calls++; return 0;}
static int dsi_display_wake_up(struct dsi_display *d) {return 0;}
static int dsi_display_cmd_engine_enable(struct dsi_display *d) {return 0;}
static int dsi_display_cmd_engine_disable(struct dsi_display *d) {return 0;}
static int dsi_host_alloc_cmd_tx_buffer(struct dsi_display *d) {d->tx_cmd_buf=d;return 0;}
static int dsi_display_broadcast_cmd(struct dsi_display *d, const struct mipi_dsi_msg *m) {assert(0);return -EINVAL;}
static int dsi_ctrl_cmd_transfer(int c, const struct mipi_dsi_msg *m, u32 *f) {
    controller_calls++;
    if (io_error) return io_error;
    hardware = m->brightness;
    writes++;
    return 0;
}
static ssize_t dsi_host_transfer(struct mipi_dsi_host *, const struct mipi_dsi_msg *);
static ssize_t mipi_dsi_dcs_write(struct mipi_dsi_device *d, u8 code, const void *bytes, size_t n) {
    const u8 *b=bytes;
    assert(code==MIPI_DCS_SET_DISPLAY_BRIGHTNESS && n==2);
    struct mipi_dsi_msg m={.brightness=b[0]|((unsigned)b[1]<<8)};
    return dsi_host_transfer(d->host,&m);
}
'''
main = r'''
int main(void) {
    struct dsi_panel panel = {.last_dcs_brightness=120};
    struct dsi_display display = {.panel=&panel, .ctrl_count=1};
    struct mipi_dsi_host host={.display=&display};
    panel.mipi_device.host=&host;
    int rc;

    rc=dsi_panel_update_backlight(&panel,200);
    printf("control %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    panel.esd_recovery_pending=1;
    rc=dsi_panel_update_backlight(&panel,900);
    printf("pending %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    assert(rc==-EAGAIN && controller_calls==1 && panel.last_dcs_brightness==200);
    panel.esd_recovery_pending=0;
    rc=dsi_panel_update_backlight(&panel,900);
    printf("resumed %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    assert(rc==0 && controller_calls==2 && hardware==900);
    io_error=-EIO;
    rc=dsi_panel_update_backlight(&panel,750);
    printf("error %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    io_error=-ETIMEDOUT;
    rc=dsi_panel_update_backlight(&panel,755);
    printf("DMA timeout %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    assert(rc==-ETIMEDOUT && controller_calls==4 && writes==2);
    assert(hardware==900 && panel.last_dcs_brightness==900);
    io_error=0;
    hardware=0;
    panel.last_dcs_brightness=0;
    panel.esd_recovery_pending=1;
    rc=dsi_panel_update_backlight(&panel,800);
    printf("blank_before_restore %d %d %d %u %u\n",rc,controller_calls,writes,hardware,panel.last_dcs_brightness);
    assert(rc==-EAGAIN && hardware==0 && panel.last_dcs_brightness==0);
    puts("PASS ESD does not acknowledge an unsent DCS write");
    return 0;
}
'''
source = "\n".join((stub, function(display,"dsi_host_transfer"),
                   function(mipi,"mipi_dsi_dcs_set_display_brightness"),
                   function(panel,"dsi_panel_update_backlight"), main))
run_case(source,"esd")
