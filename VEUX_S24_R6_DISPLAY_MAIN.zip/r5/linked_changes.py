"""Check the linked pstore, panel, and touch paths with LLDB."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys

kit=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(kit/"oem"))
import proof

names=(
    "dsi_host_transfer", "dsi_panel_restore_brightness", "dsi_display_set_power",
    "_sde_connector_update_dirty_properties", "goodix_ts_resume_work",
    "pstore_dump","ramoops_pstore_write","ramoops_probe","persistent_ram_write",
)

def check(build, out):
    raw=(build/"arch/arm64/boot/Image").read_bytes()
    proof.FUNCTIONS=names
    elf=(build/"vmlinux").resolve()
    kernel=proof.Image("S24-R6-Display-Pstore",raw,elf)
    out.mkdir(parents=True,exist_ok=True)
    asm=kernel.debug(os.environ.get("LLDB","lldb-19"),out)
    functions={}
    for name in names:
        if name not in kernel.ranges:
            raise ValueError("Missing linked implementation "+name)
        start,end=kernel.ranges[name]
        checked=sum(address in asm for address in range(start,end,4))
        if checked!=(end-start)//4:
            raise ValueError("Incomplete debugger range "+name)
        functions[name]=dict(offset=hex(start),words=checked,direct_calls=kernel.direct_calls(name))
    if b"crash/restart snapshot in console zone (" not in raw:
        raise ValueError("Missing console fallback")
    if b"VEUX DSI: transfer deferred during panel recovery" not in raw:
        raise ValueError("Missing recovery log")
    if "ramoops_console_lock" not in kernel.symbols:
        raise ValueError("Missing shared console lock")
    data=dict(sha256=hashlib.sha256(raw).hexdigest(),functions=functions,
              checked_words=len(asm),device_pass=False,flash_allowed=False)
    (out/"Display-Pstore-LLDB.json").write_text(json.dumps(data,indent=2)+"\n")
    print(f"{len(functions)} linked display/pstore paths, {len(asm)} verified words")

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("build",type=Path)
    p.add_argument("out",type=Path)
    check(**vars(p.parse_args()))
