# AnyKernel3 for the verified VEUX Global boot inputs. The build selects the package mode.
properties() { '
kernel.string=VEUX S24-R6 · AK3-Vorprüfung für R13 und Xiaomi Stock
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=1
device.name1=veux
supported.versions=13
supported.patchlevels=
'; }
BLOCK=boot
IS_SLOT_DEVICE=1
SLOT_SELECT=active
PATCH_VBMETA_FLAG=0
. tools/ak3-core.sh

case "$SLOT" in _a|_b) ;; *) abort "Boot-Slot konnte nicht eindeutig bestimmt werden." ;; esac
case "${BLOCK##*/}" in "boot$SLOT") ;; *) abort "Boot-Gerät und erkannter Slot stimmen nicht überein." ;; esac
source_img=$AKHOME/slot-vorher.img
log=$AKHOME/veux-pruefung.log
expected=@BOOT_SHA@

show_error() {
    tail -n 4 "$log" | while IFS= read -r msg; do
        [ -z "$msg" ] || ui_print "$msg"
    done
    abort "$1"
}
dd if="$BLOCK" of="$source_img" bs=1048576 >"$log" 2>&1 || show_error "Lesen von $BLOCK fehlgeschlagen."
bytes=$(wc -c < "$source_img") || abort "Größe des gelesenen Bootabbilds nicht bestimmbar."
[ "$bytes" -eq 134217728 ] || abort "Unerwartete Boot-Größe auf $BLOCK. Gelesen wurden $bytes Bytes."
sum=$(sha256sum "$source_img") || abort "Prüfsumme des gelesenen Bootabbilds nicht bestimmbar."
source_digest=${sum%% *}
case "$source_digest" in
    "$expected") ui_print "Das geprüfte R6-Bootabbild ist auf $BLOCK bereits vorhanden. Kein Schreibvorgang."; exit 0 ;;
    ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5) base_label="Xiaomi Global Stock" ;;
    c6ed9ad7a90adf9d670a48da9b9edd9a2276e51598ffc7e2e4a6676434138ff6) base_label="bestätigtes R13-Geräteabbild" ;;
    *) abort "Unbekanntes Bootabbild auf $BLOCK. SHA-256 $source_digest" "Abbruch vor dem Schreibschritt." ;;
esac
ui_print "Erkannte Basis auf $BLOCK ist $base_label."
sh "$AKHOME/veux/render.sh" "$source_img" "$source_digest" "$AKHOME" "$AKHOME/veux-repack" >"$log" 2>&1 ||
    show_error "Abgleich vor dem Schreibschritt abgebrochen."
ui_print "R6-Bootabbild geprüft. SHA-256 $expected"
ui_print "Vorprüfung bestanden. Der Boot-Slot wurde nur gelesen."
