#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef uint32_t u32;
typedef uint64_t u64;
#define CONFIG_WT_QGKI 1
#define DSI_DEBUG(...) ((void)0)
#define DSI_ERR(...) ((void)0)
#define DSI_WARN(...) ((void)0)
#define SDE_EVT32(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
#define unlikely(x) (x)
#define time_after(a,b) ((long)((b)-(a))<0)
#define atomic_read(p) (*(p))
#define container_of(ptr,type,member) ((type *)((char *)(ptr)-offsetof(type,member)))
#define to_delayed_work(p) container_of(p,struct delayed_work,work)
#define HZ 250
#define jiffies 7000UL
#define MAX_BL_SCALE_LEVEL 1024
#define MAX_SV_BL_SCALE_LEVEL 65535
#define MIPI_DSI_MODE_LPM 2048
#define ENOTSUPP 524
#define VEUX_DSI_TOUCH_NOTIFY 1
#define system_wq NULL
#define msecs_to_jiffies(ms) (((ms)*HZ+999)/1000)
enum {SDE_MODE_DPMS_ON=0,SDE_MODE_DPMS_LP1,SDE_MODE_DPMS_LP2,SDE_MODE_DPMS_OFF};
enum {DRM_BLANK_UNBLANK,DRM_BLANK_LP1,DRM_BLANK_LP2,DRM_BLANK_POWERDOWN};
enum {DRM_EARLY_EVENT_BLANK,DRM_EVENT_BLANK};
enum {DSI_BACKLIGHT_PWM,DSI_BACKLIGHT_WLED,DSI_BACKLIGHT_DCS,DSI_BACKLIGHT_EXTERNAL};
enum {DSI_CMD_SET_LP1=14,DSI_CMD_SET_LP2,DSI_CMD_SET_NOLP,DSI_CMD_SET_DISP_DOZE_HBM=29,DSI_CMD_SET_DISP_DOZE_LBM,DSI_CMD_SET_OFF};
enum dsi_doze_type {DSI_DOZE_OFF,DSI_DOZE_HBM,DSI_DOZE_LBM};
enum {REGULATOR_MODE_IDLE,REGULATOR_MODE_NORMAL,REGULATOR_MODE_STANDBY};
enum {DSI_CORE_CLK,DSI_CLK_ON,DSI_CLK_OFF};
struct work_struct { int unused; };
struct delayed_work { struct work_struct work; int pending; unsigned delay; };
struct mipi_dsi_device { unsigned long mode_flags; };
struct dsi_backlight_config { unsigned type,lp_mode,bl_inverted_dbv,bl_level_nodim,bl_level,bl_scale,bl_scale_sv; int raw_bd, bl_max_level, brightness_max_level; };
struct dsi_panel {
    struct { bool ext_bridge_mode; } host_config;
    struct mipi_dsi_device mipi_device;
    struct dsi_backlight_config bl_config;
    struct delayed_work wake_brightness_work;
    enum dsi_doze_type doze_status;
    unsigned doze_hbm_threshold, last_dcs_brightness, wake_brightness;
    unsigned wake_retries, brightness_phase;
    bool dcs_brightness_valid, wake_brightness_valid;
    int cur_mode,panel_lock,host,panel_initialized,power_mode,power_info,is_twm_en,esd_recovery_pending;
};
struct drm_connector { struct { unsigned int id; } base; void *state; };
struct dsi_display { struct dsi_panel *panel; int dsi_clk_handle; bool queue_cmd_waits; };
struct msm_display_kickoff_params { int *rois, *hdr_meta; };
static int failed_command=-1, tx_error, clock_on_error, clock_off_error, writes, notifications, last_command, commands;
static int ulp_calls,ulp_value,ulp_error;
static unsigned level;
static void mutex_lock(int *lock) { if ((*lock)++) abort(); }
static void mutex_unlock(int *lock) { if (--(*lock)) abort(); }
static int delayed_work_pending(struct delayed_work *work) { return work->pending; }
static void cancel_delayed_work(struct delayed_work *work) { work->pending=0; }
static void mod_delayed_work(void *queue, struct delayed_work *work, unsigned delay) { work->pending=1;work->delay=delay; }
static int dsi_panel_initialized(struct dsi_panel *p) { return p->panel_initialized; }
static int dsi_panel_is_type_oled(struct dsi_panel *p) { return 1; }
static int dsi_pwr_panel_regulator_mode_set(int *info,const char *name,int val) { return 0; }
static int dsi_display_set_ulp_load(struct dsi_display *d, bool low) { ulp_calls++;ulp_value=low;return ulp_error; }
static void dsi_display_notify_blank(struct dsi_display *d,int event,int blank) { if(event==DRM_EVENT_BLANK) notifications++; }
static int dsi_panel_tx_cmd_set(struct dsi_panel *p,int cmd) { if (!p->panel_lock) abort(); last_command=cmd;commands++;return cmd==failed_command?-EIO:0; }
static int mipi_dsi_dcs_set_display_brightness(struct mipi_dsi_device *m, unsigned value) {
    if (tx_error)
        return tx_error;
    writes++;
    level=value;
    return 0;
}
static int dsi_panel_update_pwm_backlight(struct dsi_panel *p,unsigned value) { return 0; }
static int backlight_device_set_brightness(int dev,unsigned value) { return 0; }
static int dsi_display_clk_ctrl(int handle,int which,int state) { return state==DSI_CLK_ON?clock_on_error:clock_off_error; }

#define U32_MAX UINT32_MAX
#define cmpxchg(addr,old,new_value) ({ if (*(addr)==(old)) *(addr)=(new_value); })
#define SDE_DEBUG(...) ((void)0)
#define SDE_ERROR(...) ((void)0)
enum { DRM_MODE_DPMS_ON,DRM_MODE_DPMS_STANDBY,DRM_MODE_DPMS_SUSPEND,DRM_MODE_DPMS_OFF };
enum { SDE_MODE_DPMS_STANDBY=4,SDE_MODE_DPMS_SUSPEND };
enum dsi_cmd_set_type { DSI_CMD_SET_MAX=128,DSI_CMD_SET_DISP_HBM_L1,DSI_CMD_SET_DISP_HBM_L2,DSI_CMD_SET_DISP_HBM_L3,DSI_CMD_SET_DISP_HBM_OFF,DSI_CMD_SET_DISP_FLAT_ON,DSI_CMD_SET_DISP_FLAT_OFF };
enum { DRM_MODE_CONNECTOR_DSI,DRM_MODE_CONNECTOR_eDP };
struct dp_display { int unused; };
struct dp_backlight_config {unsigned bl_scale,bl_scale_sv,bl_level;};
struct dp_panel {struct dp_backlight_config bl_config;};
struct sde_connector {
    struct drm_connector base;
    struct {
        int (*set_power)(struct drm_connector *, int, void *);
        int (*set_backlight)(struct drm_connector *, void *, u32);
        int (*pre_kickoff)(struct drm_connector *, void *, struct msm_display_kickoff_params *);
    } ops;
    void *display,*drv_panel;
    int lock,dpms_mode,lp_mode,last_panel_power_mode,connector_type,allow_bl_update;
    unsigned bl_scale,bl_scale_sv,unset_bl_level;
    bool power_update_pending;
};
static int esd_on;
static void sde_connector_schedule_status_work(struct drm_connector *c,bool on) { esd_on=on; }
