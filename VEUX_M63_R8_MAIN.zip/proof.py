"""Inspect the actual Xiaomi and built arm64 bytes with LLDB and validate required interfaces."""
import argparse
from bisect import bisect_right
from collections import Counter, defaultdict
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
from tempfile import TemporaryDirectory
import stock_elf
import paths
import linked_touch
from image_symbols import BASE, gzconfig, unpack, normal

HERE = Path(__file__).resolve().parent
BOOT = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
CONFIG = "c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54"
FUNCTIONS = """xiaomi_touch_init xiaomi_touch_probe xiaomi_touch_dev_ioctl palm_sensor_store
gtp_set_cur_value gtp_get_mode_value gtp_get_mode_all gtp_reset_mode gtp_palm_sensor_write
update_palm_sensor_value goodix_ts_probe goodix_ts_stage2_init goodix_ts_esd_init goodix_ts_esd_work
goodix_ts_irq_enable goodix_ts_suspend goodix_ts_resume goodix_ts_report_finger
goodix_ts_fb_notifier_callback gtp_sleep_write gtp_gesture_write goodix_gsx_gesture_init
gsx_gesture_before_suspend gsx_gesture_ist dsi_bridge_pre_enable dsi_bridge_post_disable
dsi_display_set_power dsi_display_notify_blank _sde_kms_drm_check_dpms
goodix_ts_input_dev_remove goodix_ts_pen_dev_remove goodix_ts_remove
input_unregister_device input_free_device goodix_i2c_write""".split()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

def u32(raw, off):
    return struct.unpack_from("<I", raw, off)[0]

def u64(raw, off):
    return struct.unpack_from("<Q", raw, off)[0]

class Image:
    def __init__(self, name, raw, elf):
        self.name, self.raw, self.elf = name, raw, elf
        rows = stock_elf.symbols(raw) if name == "Stock" else unpack(raw)
        self.symbols = {n:a for a, _, n in rows}
        self.by_addr = defaultdict(set)
        spans = [(self.symbols[a], self.symbols[z]) for a,z in
                 [("_stext","_etext"),("_sinittext","_einittext")]]
        names = defaultdict(set)
        for off, kind, name in rows:
            if kind.lower() in ("t","w") and not name.startswith("$") and not off % 4:
                if any(a <= off < e for a,e in spans):
                    n = normal(name)
                    self.by_addr[off].add(n)
                    names[n].add(off)
        addresses = sorted(self.by_addr)
        self.ranges = {}
        for n in FUNCTIONS:
            if len(names[n]) == 1:
                a, = names[n]
                i = bisect_right(addresses, a)
                e = next(e for l,e in spans if l <= a < e)
                self.ranges[n] = a,min(addresses[i] if i < len(addresses) else e, e)

    def direct_calls(self, fn):
        targets = defaultdict(list)
        for off in range(*self.ranges[fn],4):
            word = u32(self.raw,off)
            if word >> 26 in (5,37):
                imm = word & 0x3ffffff
                if imm & (1 << 25):
                    imm -= 1 << 26
                dest = off + 4 * imm
                for n in self.by_addr.get(dest, ()):
                    targets[n].append(hex(BASE + off))
        return dict(sorted(targets.items()))

    def initcalls(self):
        s = self.symbols
        edges = [s["__initcall_start"]] + [s[f"__initcall{i}_start"] for i in range(8)] + [s["__initcall_end"]]
        reloc = {}
        if self.name == "Stock":
            for m in re.finditer(re.escape(struct.pack("<Q",1027)),self.raw):
                p = m.start()
                if p >= 8:
                    off = u64(self.raw,p-8)-BASE
                    if edges[0] <= off < edges[-1]:
                        reloc[off] = u64(self.raw,p+8)-BASE
        out = []
        for lv,(st,end) in enumerate(zip(edges,edges[1:]),-1):
            for off in range(st,end,8):
                ptr = reloc[off] if self.name == "Stock" else u64(self.raw,off)-BASE
                names = self.by_addr.get(ptr,set())
                ins = u32(self.raw,ptr)
                if ins >> 26 == 5 and (not names or any(n.endswith(".cfi_jt") or n.startswith("__typeid_") for n in names)):
                    imm = ins & 0x3ffffff
                    if imm & (1<<25):
                        imm -= 1<<26
                    tgt = ptr+4*imm
                    if tgt in self.by_addr:
                        names = self.by_addr[tgt]
                plain = sorted(n for n in names if not n.endswith(".cfi_jt") and not n.startswith("__typeid_"))
                if not plain:
                    plain = sorted(n.removesuffix(".cfi_jt") for n in names if n.endswith(".cfi_jt"))
                require(bool(plain), f"{self.name}: unnamed initcall {off:x}")
                out.append((lv,"|".join(plain)))
        return out

    def exports(self):
        s = self.symbols
        entries = {a:n[len("__ksymtab_"):] for n,a in s.items() if n.startswith("__ksymtab_")}
        result = {}
        for suffix in ("","_gpl"):
            start, end = s["__start___ksymtab"+suffix],s["__stop___ksymtab"+suffix]
            crc = s["__start___kcrctab"+suffix]
            require((end-start)//24 == (s["__stop___kcrctab"+suffix]-crc)//4, "CRC count")
            for i,off in enumerate(range(start,end,24)):
                name = entries[off]
                pos = s["__kstrtab_"+name] if self.name == "Stock" else u64(self.raw,off+8)-BASE
                require(self.raw[pos:self.raw.index(0,pos)].decode()==name, f"Export {name}")
                result[name]=(suffix,u32(self.raw,crc+4*i))
        return result

    def debug(self, lldb, dest):
        cmd = ["settings set use-color false", 'target create --arch aarch64 "'+str(self.elf)+'"']
        for n,(a,e) in self.ranges.items():
            cmd.append(f"image lookup --verbose --address {BASE+a:#x}")
            cmd.append(f"disassemble --bytes --start-address {BASE+a:#x} --end-address {BASE+e:#x}")
        script = dest/(self.name+".lldb")
        script.write_text("\n".join(cmd)+"\n")
        log = subprocess.check_output([lldb,"--no-lldbinit","--batch","-s",script],text=True,stderr=subprocess.STDOUT)
        (dest/(self.name+"-LLDB.txt")).write_text(log)
        show = {}
        for m in re.finditer(r"^\S+\[0x([a-f0-9]+)\]\s+<[^>]*>:\s+(0x[a-f0-9]{8})\s+(.+)$",log,re.M):
            off = int(m[1],16) - BASE
            require(int(m[2],16) == u32(self.raw,off), f"{self.name} debugger/Image {off:x}")
            show[off] = m[3]
        expect = {off for a,e in self.ranges.values() for off in range(a,e,4)}
        require(expect == show.keys(), f"{self.name} debugger coverage {len(show)} / {len(expect)}")
        return show

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("stock_boot",type=Path); ap.add_argument("out",type=Path)
    ap.add_argument("evidence",type=Path); ap.add_argument("--lldb",default="lldb")
    ap.add_argument("--objcopy",default="llvm-objcopy")
    args=ap.parse_args(); dest=args.evidence.resolve(); dest.mkdir(exist_ok=True,parents=True)
    out=args.out.resolve(); boot=args.stock_boot.read_bytes()
    require(sha(boot)==BOOT and boot[:8]==b"ANDROID!" and u32(boot,40)==3,"Xiaomi boot v3")
    oem=boot[4096:4096+u32(boot,8)]
    require(sha(oem)==stock_elf.STOCK,"Original Xiaomi arm64 Image")
    raw=(out/"arch/arm64/boot/Image").read_bytes(); config=(out/".config").read_bytes()
    require(sha(config)==CONFIG and config==gzconfig(raw),"R6 configuration in final kernel")
    banners=re.findall(rb"Linux version [0-9]+\.[^\0\n]+",raw)
    require(len(banners)==1, "single Linux build banner")
    banner=banners[0].decode()
    require(banner.startswith("Linux version 5.4.274-qgki-g82179e362f33 "),"VEUX stock release")
    with TemporaryDirectory(dir=dest.parent) as tmp:
        tmp=Path(tmp); tmp.joinpath("OEM.Image").write_bytes(oem)
        stock_elf.make(tmp/"OEM.Image",tmp/"Xiaomi.elf")
        subprocess.run([args.objcopy,"-O","binary","-R",".note","-R",".note.gnu.build-id","-R",".comment","-S",out/"vmlinux",tmp/"ELF.Image"],check=True)
        require((tmp/"ELF.Image").read_bytes()==raw,"vmlinux and actual arm64 Image differ")
        kernels = [Image("Stock",oem,tmp/"Xiaomi.elf"), Image("R8",raw,out/"vmlinux")]
        checks = {}; abis=[]; init=[]; info={}
        for k in kernels:
            asm=k.debug(args.lldb,dest)
            targets={n:k.direct_calls(n) for n in k.ranges}
            write_json(dest/(k.name+"-Sprungziele.json"),targets)
            seq=k.initcalls(); init.append(seq)
            with (dest/(k.name+"-Initcalls.csv")).open("w") as f:
                w=csv.writer(f);w.writerow(["Stufe","Name"]);w.writerows(seq)
            goodix=[n for l,n in seq if l==7 and n in ("goodix_ts_core_init","goodix_tools_init","goodix_gsx_gesture_init")]
            require(goodix==["goodix_ts_core_init","goodix_tools_init","goodix_gsx_gesture_init"], k.name+" Goodix startup order")
            require((4,"xiaomi_touch_init") in seq,k.name+" Xiaomi subsys init")
            cases={}
            def calls(fn,*opts):
                vals={n:targets.get(fn,{}).get(n) for n in opts if n in targets.get(fn,{})}
                require(vals,k.name+" missing call: "+fn+" -> "+"/".join(opts)); return vals
            for fn,opts in [
                ("xiaomi_touch_probe",("misc_register",)),
                ("gtp_set_cur_value",("goodix_ts_suspend",)),
                ("gtp_set_cur_value",("goodix_ts_resume",)),
                ("goodix_ts_irq_enable",("disable_irq",)),
                ("goodix_ts_report_finger",("update_palm_sensor_value",)),
                ("gtp_palm_sensor_write",("update_palm_sensor_value",)),
                ("goodix_ts_fb_notifier_callback",("queue_work_on",)),
                ("goodix_ts_stage2_init",("goodix_ts_esd_init",)),
                ("goodix_ts_stage2_init",("init_wt_tp_palm",)),
                ("goodix_ts_stage2_init",("init_wt_tp_grip_area",)),
                ("goodix_ts_probe",("xiaomitouch_register_modedata",)),
                ("gsx_gesture_before_suspend",("irq_set_irq_wake",)),
                ("dsi_bridge_pre_enable",("blocking_notifier_call_chain","dsi_display_notify_blank")),
                ("dsi_bridge_post_disable",("blocking_notifier_call_chain","dsi_display_notify_blank")),
                ("dsi_display_set_power",("blocking_notifier_call_chain","dsi_display_notify_blank")),
                ("goodix_ts_suspend",("update_palm_sensor_value",)),
                ("goodix_ts_suspend",("goodix_ts_power_off",)),
                ("goodix_ts_resume",("goodix_ts_power_on",)),
            ]:
                cases[fn+" -> "+"/".join(opts)]=calls(fn,*opts)
            for fn in ("gtp_set_cur_value","gtp_get_mode_value","gtp_get_mode_all"):
                bounds=[hex(BASE+p) for p in range(*k.ranges[fn],4) if re.search(r"\bcmp\s+w\d+,\s*#(?:0x13|19|0x14|20)\b",asm[p])]
                require(bounds,k.name+" mode-19 boundary in "+fn);cases[fn+" Modusgrenze"]=bounds
            cases["Modus_19_Zweigfolge"]=paths.dispatch(k,targets)
            cases["ESD_alle_Rueckwege"]=paths.esd(k,targets)
            if k.name=="R8":
                cases["Touch_Fehlerpfade"] = linked_touch.check(k, asm)
                cases["DSI_Vermittlung"]=calls("dsi_display_notify_blank","blocking_notifier_call_chain")
                for helper in ("goodix_ts_input_dev_remove", "goodix_ts_pen_dev_remove"):
                    cases[helper] = calls(helper, "input_unregister_device")
                    require("input_free_device" not in targets[helper], helper+" released the device twice")
            for needle in (b"xiaomi-touch\0",b"tp_sleep\0",b"tp_palm\0",b"tp_grip_area\0"):
                require(needle in k.raw,k.name+" name "+str(needle))
            abis.append(k.exports()); checks[k.name]=cases
            info[k.name]={"Image_SHA256":sha(k.raw),"Bytes":len(k.raw),"LLDB_Functions":len(k.ranges),"LLDB_Checked_Instruction_Words":len(asm),"Initcalls":len(seq),"Goodix_Stufe_7":goodix}
    refs=json.loads((HERE/"baselines.json").read_text())
    prev,hist=(Counter(tuple(row) for row in refs[k]["initcalls"]) for k in ("R6","Diag10"))
    linked=Counter(init[1]); oem_init=Counter(init[0]); shared=oem_init & hist
    require(sum(shared.values())==948 and not (shared-linked), "Stock/Diag10 initcall lost")
    require(not (prev-linked), "R6 initcall lost")
    additional=list((linked-prev).elements())
    require(sorted(additional)==[(4,"xiaomi_touch_init"),(7,"goodix_gsx_gesture_init")], "unexpected initcalls")
    video, display = (6, "msm_vidc_init"), (6, "msm_drm_register")
    with (HERE/"tools/ref/r7-initcalls.csv").open() as reference:
        r7_order = [(int(row["Stufe"]), row["Name"]) for row in csv.DictReader(reference)]
    expected_order = r7_order.copy()
    for seq in (init[0], r7_order):
        require(seq.count(video) == seq.count(display) == 1, "unique video and display initcalls")
    stock_index = init[0].index(video)
    old_index = r7_order.index(display)
    require(init[0][stock_index:stock_index+2] == [video, display], "Xiaomi stock order")
    require(r7_order[old_index:old_index+2] == [display, video], "GitHub R7 order")
    expected_order[old_index:old_index+2] = [video, display]
    require(init[1] == expected_order, "unexpected R8 initcall order")
    init_summary={"Stock_Diag10_shared":sum(shared.values()),"restored_with_R7_and_retained":list((shared-prev).elements()),
                  "R6_all_retained":sum(prev.values()),"R8_additional_vs_R6":additional,
                  "ordered_entries_checked":len(expected_order), "changed_positions_1based":[old_index+1,old_index+2],
                  "Stock_video_display_positions_1based":[stock_index+1,stock_index+2]}
    table=list(csv.DictReader((HERE/"tools/ref/vendor-imports.csv").open()))
    names=set(); module_only=set(); passed=0
    providers=json.loads((HERE/"tools/ref/qgki-providers.json").read_text())["files"]
    require(set(providers)=={Path(row["module"]).name for row in table}, "OEM modules.load")
    external_rows=0
    for row in table:
        n=row["symbol"]; expected=int(row["expected_crc"],16)
        if n in abis[0]:
            require(abis[0][n]==abis[1].get(n) and abis[0][n][1]==expected,"Xiaomi vendor CRC/class mismatch "+n)
            names.add(n);passed+=1
        else:
            require(n not in abis[1],"Xiaomi/R8 export origin mismatch "+n)
            module = Path(row["module"]).name
            require(any(providers[dep]["exports"].get(n) == expected
                        for dep in providers[module]["depends"]), "Missing Xiaomi module provider for "+n)
            external_rows += 1
            module_only.add(n)
    require((len(table),len({r["module"] for r in table}),len(names),len(module_only),passed)==(3148,37,980,443,2579),"Xiaomi inventory")
    result={"Stock_boot_SHA256":BOOT, "kernel_config_SHA256":CONFIG,"R8_release":banner,
            "R8_vmlinux_Image_byte_equal":True, "initcall_comparison":init_summary,"kernels":info,"machine_code_checks":checks,
            "vendor":{"modules":37,"kernel_import_names":len(names),"kernel_import_rows":passed,"external_import_names":len(module_only),"verified_external_rows":external_rows,"all_rows":len(table)},
            "device_pass":False,"flash_allowed":False}
    write_json(dest/"Pruefung.json",result)
    print(json.dumps({"kernels":info,"vendor":result["vendor"]},indent=2))

if __name__=="__main__":
    main()
