# VEUX M63-R8 für das POCO X4 Pro 5G

Referenz ist das ausgelieferte Xiaomi-Bootabbild der Global-ROM OS1.0.12.0.TKCMIXM. R8 korrigiert zwei Treiberdateien und die Kbuild-Datei für die Qualcomm-Treiber des GitHub-R7. Der Xiaomi-Setter erhält den Status eines abgewiesenen Auftrags. Goodix meldet den ersten fehlgeschlagenen Buszugriff und veröffentlicht den neuen Modus erst nach allen fünf Schreibzugriffen. Bei gescheiterter Initialisierung räumt der Treiber die Eingabegeräte entsprechend ihrem Registrierungszustand auf. Das Format für Lese- und Reset-Aufträge stammt aus der Original-HAL. Die Linkreihenfolge für Video und Display folgt fest dem Xiaomi-Original. Alle 1.197 Einträge der Initialisierung werden in ihrer Reihenfolge geprüft. Die Kernelkennung lautet 5.4.274-qgki-g82179e362f33.

## GitHub Actions

`VEUX_M63_R8_MAIN.zip` gehört unverändert ins Stammverzeichnis. Lege `VEUX_M63_R8_STOCK_TOUCH_NOFLASH.yml` unter `.github/workflows/` ab. Der manuelle Lauf verwendet die vollständigen Quellen aus GitHub-Lauf 45351719529, Artefakt 14902383218. Das Paket prüft Quellarchiv, Git-Bäume vor und nach der Änderung, Konfiguration und Stockabbild. Beim Bauen werden die originalen Werkzeugversionen verwendet. Die Ausgaben umfassen Bootabbild, AK3-Prüfpaket, Debuggerprotokolle und den vollständigen Quellstand.

## Lokaler Bau

Mit Python ab 3.12, Git, den Linux-Kernel-Bauwerkzeugen, LLDB 19, qemu-arm für den ARM-Paketierer und Android-Clang r416183b sind die Schritte auch lokal ausführbar. Der Bau verwendet ein eigenes Ausgabeverzeichnis.

```sh
python3 -B prepare.py R7-source.zip work/src /pfad/zum/stock/boot.img
LLDB=lldb-19 bash build.sh work /pfad/zu/clang-r416183b /pfad/zum/stock/boot.img
```

Für das dauerhaft gesicherte R6-Quellenvergleichspaket akzeptiert `prepare.py` die Option `--from-r6 comparison`. Damit werden erst R6 und R7 und anschließend dieselben R8-Quellen wiederhergestellt. Für das originale R6-Quellartefakt lautet die Option `--from-r6 archive`. Ein vorhandenes originales Bootabbild wird anhand seiner Prüfsumme identifiziert. Bei fehlender Datei lädt die Vorbereitung die benötigten Daten der veröffentlichten Xiaomi-OTA.

## Gerätestatus

R6 erreichte die Android-Displaysperre und hing dort. Für die Ursache dieses konkreten Ereignisses fehlt ein Geräteprotokoll. Der Status von R8 ist NOFLASH. Die beiden Slot-Tests prüfen den Paketierer auf Abbilddateien. Die Eingabegeräte- und I²C-Tests prüfen den Treiber mit kontrollierten Rückmeldungen. Ein tatsächlicher Gerätestart und die PIN-Eingabe benötigen einen eigenen Nachweis.
