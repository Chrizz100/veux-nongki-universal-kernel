#!/usr/bin/env python3
"""Read-only, fail-closed OEM module import / candidate Module.symvers audit.

This is an ABI MEASUREMENT, not an ABI compatibility certification. The historical
QGKI cohort is not proven to be the actively loaded phone module set.
"""
import argparse
import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

R28_SOURCE_SHA = 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394'
STOCK_CONFIG_SHA = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
HEADER_SHA = 'bc73b24be7b7ffad9807d23f7eae5b16771c08aa37082493cd41f2b191ccd1d8'
EXPECTED = {'QGKI': (37, 3148, 1423, '0x945d02f2'),
            'GKI': (181, 11500, 3078, '0x1e5b7ab7')}
CRC = re.compile(r'0x[0-9a-fA-F]{1,8}\Z')
SYMBOL = re.compile(r'[A-Za-z_][A-Za-z_0-9.]*\Z')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse_imports(path):
    if sha(path) != R28_SOURCE_SHA:
        raise ValueError('R28_ORIGINAL_IMPORTS_SHA_MISMATCH')
    with Path(path).open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    groups = {'QGKI': [], 'GKI': []}
    for row in rows:
        p, sym, crc = row['path'], row['symbol'], row['module_crc'].lower()
        if p.startswith('/vendor/lib/modules/5.4-gki/'):
            cohort = 'GKI'
        elif p.startswith('/vendor/lib/modules/'):
            cohort = 'QGKI'
        else:
            raise ValueError('R28_UNEXPECTED_MODULE_PATH')
        if not p.endswith('.ko') or '/../' in p or not SYMBOL.fullmatch(sym) or not CRC.fullmatch(crc):
            raise ValueError('R28_INVALID_IMPORT_ROW')
        groups[cohort].append((p, sym, crc))
    if sum(len(v) for v in groups.values()) != 14648:
        raise ValueError('R28_INCOMPLETE_MODULE_IMPORTS')
    for cohort, seq in groups.items():
        modules, imports, symbols, layout = EXPECTED[cohort]
        if len(seq) != imports or len({x[0] for x in seq}) != modules or len({x[1] for x in seq}) != symbols:
            raise ValueError('R28_COHORT_COUNT_DRIFT:'+cohort)
        layouts = {x[2] for x in seq if x[1] == 'module_layout'}
        if layouts != {layout}:
            raise ValueError('R28_LAYOUT_EXPECTATION_DRIFT:'+cohort)
        per_symbol = defaultdict(set)
        for _, symbol, v in seq:
            per_symbol[symbol].add(v)
        if any(len(v) != 1 for v in per_symbol.values()):
            raise ValueError('R28_INTRACOHORT_CONFLICT:'+cohort)
    common = set(s for _, s, _ in groups['QGKI']) & set(s for _, s, _ in groups['GKI'])
    q = {s:c for _,s,c in groups['QGKI']}
    g = {s:c for _,s,c in groups['GKI']}
    if len(common) != 1393 or sum(q[s] != g[s] for s in common) != 836:
        raise ValueError('R28_CONFLICT_PROVENANCE_DRIFT')
    return groups


def parse_symvers(path):
    p = Path(path)
    if not p.is_file() or p.stat().st_size < 64:
        raise ValueError('CANDIDATE_SYMVERS_NOT_PRESENT')
    syms = defaultdict(set)
    lines=0
    for raw in p.read_text(encoding='utf-8').splitlines():
        if not raw.strip():
            continue
        fields=raw.split()
        if len(fields) < 4:
            raise ValueError('CANDIDATE_SYMVERS_BAD_FORMAT')
        crc, symbol, provider=fields[0].lower(),fields[1],fields[2]
        if not CRC.fullmatch(crc) or not SYMBOL.fullmatch(symbol):
            raise ValueError('CANDIDATE_SYMVERS_BAD_VALUE')
        if fields[3] not in ('EXPORT_SYMBOL','EXPORT_SYMBOL_GPL','EXPORT_SYMBOL_GPL_FUTURE','EXPORT_UNUSED_SYMBOL','EXPORT_UNUSED_SYMBOL_GPL'):
            raise ValueError('CANDIDATE_SYMVERS_BAD_EXPORT')
        # QGKI/GKI vendor modules can bind to exports from vmlinux or another module.
        # Distinguish duplicate/ambiguous providers rather than inventing an ABI pass.
        syms[symbol].add(crc)
        lines += 1
    if lines < 1000:
        raise ValueError('CANDIDATE_SYMVERS_UNEXPECTEDLY_SMALL')
    return syms, lines


def readconfig(path):
    d={}
    for line in Path(path).read_text(encoding='utf-8').splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key,value=line.split('=',1)
            d[key]=value
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            d[line[len('# '):].split(' ')[0]]='n'
    return d


def evaluate(rows, syms):
    results=[]
    byfile=defaultdict(Counter)
    for p,sym,exp in rows:
        cand = sorted(syms.get(sym,()))
        if len(cand) > 1:
            status='AMBIGUOUS_EXPORTS'
        elif not cand:
            status='NOT_EXPORTED'
        elif cand[0] == exp:
            status='MATCH'
        else:
            status='CRC_MISMATCH'
        byfile[p][status]+=1
        results.append((p,sym,exp, ';'.join(cand),status))
    totals = dict(Counter(r[-1] for r in results))
    complete = sum(c.get('MATCH',0)==sum(c.values()) for c in byfile.values())
    module_summary=[]
    for p,c in sorted(byfile.items()):
        module_summary.append({'path':p,'imports':sum(c.values()),'match':c.get('MATCH',0),
          'crc_mismatch':c.get('CRC_MISMATCH',0),'not_exported':c.get('NOT_EXPORTED',0),
          'ambiguous':c.get('AMBIGUOUS_EXPORTS',0),
          'complete_match':c.get('MATCH',0)==sum(c.values())})
    return results,totals,complete,module_summary


def writecsv(path,header,rows):
    with Path(path).open('w', newline='', encoding='utf-8') as f:
        w=csv.writer(f,lineterminator='\n')
        w.writerow(header)
        w.writerows(rows)


def run(args):
    imports = parse_imports(args.original_r28_imports)
    syms, symvers_count=parse_symvers(args.candidate_symvers)
    if sha(args.stock_config) != STOCK_CONFIG_SHA:
        raise ValueError('STOCK_CONFIG_SHA_MISMATCH')
    original=readconfig(args.stock_config)
    candidate=readconfig(args.candidate_config)
    if original.get('CONFIG_SCHED_WALT')!='y' or original.get('CONFIG_QGKI')!='y' or original.get('CONFIG_MODVERSIONS')!='y':
        raise ValueError('STOCK_FLAGS_MISMATCH')
    # The candidate may differ: never equate a successful build with a stock build.
    build_meta=json.loads(Path(args.build_summary).read_text(encoding='utf-8'))
    rc=Path(args.build_return_code).read_text(encoding='utf-8').strip()
    if rc!='0' or build_meta.get('exit_code')!=0 or build_meta.get('compiler_error_count')!=0:
        raise ValueError('CANDIDATE_BUILD_NOT_SUCCESSFUL')
    img=Path(args.kernel_image)
    if not img.is_file() or img.stat().st_size < 1000000:
        raise ValueError('ARM64_KERNEL_IMAGE_NOT_PRODUCED')
    image_sha=sha(img)
    out=Path(args.out)
    out.mkdir(parents=True,exist_ok=True)
    data={'schema':'VEUX_STOCK_R6_CANDIDATE_ABI_EVIDENCE','candidate_source_commit':args.donor_sha,
      'candidate_source_release':'5.4.268','target_stock_release':'5.4.274-qgki-g82179e362f33',
      'candidate_build_exit_code':0,'r5_diagnostic_llvm_broken_pipe_count':build_meta.get('llvm_broken_pipe_count'),
      'candidate_image_sha256':image_sha,
      'candidate_image_bytes':img.stat().st_size,'candidate_symvers_sha256':sha(args.candidate_symvers),
      'candidate_symvers_exports':symvers_count,'r28_original_sha256':R28_SOURCE_SHA,
      'actual_loaded_module_cohort_verified':False,
      'oem_stock_source_identical':False,'stock_kernel_5_4_274_compiled':False,
      'vendor_abi_green':False,'flash_allowed':False,'boot_img_created':False,
      'note':'CRC comparison against HISTORICAL device exports, not validated active vendor module load set.'}
    for cohort, rows in imports.items():
        results,totals,complete,modules=evaluate(rows,syms)
        writecsv(out/('R6_'+cohort+'_IMPORT_ABI.csv'), ['module','symbol','expected_crc','candidate_crc','result'],results)
        writecsv(out/('R6_'+cohort+'_PER_MODULE.csv'),['module','imports','match','crc_mismatch','not_exported','ambiguous','complete_match'],
          [[x['path'],x['imports'],x['match'],x['crc_mismatch'],x['not_exported'],x['ambiguous'],str(x['complete_match']).lower()] for x in modules])
        data[cohort]={'import_occurrences':len(rows),'module_files':len(modules),
          'unique_symbols':len({x[1] for x in rows}), 'match':totals.get('MATCH',0),
          'crc_mismatch':totals.get('CRC_MISMATCH',0),'not_exported':totals.get('NOT_EXPORTED',0),
          'ambiguous_exports':totals.get('AMBIGUOUS_EXPORTS',0), 'complete_match_module_files':complete,
          'expected_module_layout_crc':EXPECTED[cohort][3],
          'candidate_module_layout_crc':';'.join(sorted(syms.get('module_layout',()))) or None}
    priorities=['CONFIG_QGKI','CONFIG_MODVERSIONS','CONFIG_SCHED_WALT','CONFIG_SCHED_CASS',
                'CONFIG_CFI_CLANG','CONFIG_LTO_CLANG','CONFIG_NR_CPUS','CONFIG_IPC_LOGGING',
                'CONFIG_FINGERPRINT','CONFIG_FINGERPRINT_FPC','CONFIG_HARDWARE_INFO','CONFIG_RTMM',
                'CONFIG_MIHW','CONFIG_MIUI_ZRAM_MEMORY_TRACKING','CONFIG_QTI_TZ_LOG']
    rows=[]
    for k in priorities:
        a,b=original.get(k,'(absent)'),candidate.get(k,'(absent)')
        rows.append((k,a,b,'MATCH' if a==b else 'DIFF'))
    writecsv(out/'R6_STOCK_VS_CANDIDATE_CRITICAL_CONFIG.csv', ['option','stock','candidate','status'],rows)
    data['critical_stock_config_differences']=sum(x[3]=='DIFF' for x in rows)
    data['critical_source_gap_flags']=[x[0] for x in rows if x[3]=='DIFF']
    (out/'R6_CANDIDATE_ABI_REPORT.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({k:data[k] for k in ['candidate_image_sha256','candidate_symvers_exports','QGKI','GKI','critical_stock_config_differences','vendor_abi_green','flash_allowed']},sort_keys=True))
    return data


def main():
    p=argparse.ArgumentParser()
    for field in ['original_r28_imports','candidate_symvers','stock_config','candidate_config',
                  'build_summary','build_return_code','kernel_image','donor_sha','out']:
        p.add_argument('--'+field.replace('_','-'),required=True)
    args=p.parse_args()
    if args.donor_sha!='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632':
        raise ValueError('DONOR_COMMIT_DRIFT')
    run(args)

if __name__=='__main__':
    main()
