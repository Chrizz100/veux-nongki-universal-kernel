import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r6_abi',HERE/'r6_abi.py')
a=importlib.util.module_from_spec(spec)
spec.loader.exec_module(a)

class R6Tests(unittest.TestCase):
    def test_original_import_source_identical(self):
        groups=a.parse_imports(HERE.parent/'reference/OEM_R21_IMPORTS.csv')
        self.assertEqual((len(groups['QGKI']),len(groups['GKI'])),(3148,11500))

    def test_r13_baseline_exact_counts(self):
        rows=a.parse_imports(HERE.parent/'reference/OEM_R21_IMPORTS.csv')
        sym,n=a.parse_symvers(HERE.parent/'reference/R13_CI_Module.symvers')
        self.assertGreater(n,12000)
        _,q,qcomplete,_=a.evaluate(rows['QGKI'],sym)
        _,g,gcomplete,_=a.evaluate(rows['GKI'],sym)
        self.assertEqual(q,{'MATCH':1303,'CRC_MISMATCH':1752,'NOT_EXPORTED':93})
        self.assertEqual(g,{'MATCH':4983,'CRC_MISMATCH':6075,'NOT_EXPORTED':442})
        self.assertEqual(qcomplete,0)
        self.assertEqual(gcomplete,0)

    def test_matched_mismatched_missing_and_ambiguous(self):
        expected=[('a.ko','alpha','0x00000001'),('a.ko','beta','0x00000005'),
                  ('b.ko','gamma','0x00000002'),('c.ko','delta','0x00000008')]
        res,tot,complete,mods=a.evaluate(expected,{'alpha':{'0x00000001'},'beta':{'0x00000003'},
                                                   'delta':{'0x00000004','0x00000008'}})
        self.assertEqual(tot,{'MATCH':1,'CRC_MISMATCH':1,'NOT_EXPORTED':1,'AMBIGUOUS_EXPORTS':1})
        self.assertEqual(complete,0)

    def test_bad_import_sha_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'bad.csv';f.write_text('fake')
            with self.assertRaisesRegex(ValueError,'SHA_MISMATCH'):a.parse_imports(f)

    def test_missing_symvers_blocked(self):
        with self.assertRaisesRegex(ValueError,'NOT_PRESENT'):
            a.parse_symvers(HERE/'nonexistent.symvers')

    def test_empty_symvers_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'Module.symvers';p.write_text('')
            with self.assertRaisesRegex(ValueError,'NOT_PRESENT'):
                a.parse_symvers(p)

    def test_malformed_symvers_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'Module.symvers';p.write_text('0x001\tbad\tvmlinux\tBOGUS\n'*600)
            with self.assertRaisesRegex(ValueError,'BAD_EXPORT'):
                a.parse_symvers(p)

    def test_stock_config_hash(self):
        self.assertEqual(len(a.STOCK_CONFIG_SHA),64)

    def test_crc_pattern(self):
        for v in ('0x00000000','0xabcdef00','0x1'):
            self.assertTrue(a.CRC.fullmatch(v))
        for v in ('abc','0xaaaaaaaaa','0xzzzzzzzz','__fake__'):
            self.assertFalse(a.CRC.fullmatch(v))

    def test_no_flash_frozen_in_source(self):
        text=(HERE/'r6_abi.py').read_text()
        for tok in ["'vendor_abi_green':False", "'flash_allowed':False", "'boot_img_created':False", "'actual_loaded_module_cohort_verified':False"]:
            self.assertIn(tok,text)

    def test_build_return_nonzero_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'r'; p.write_text('2')
            self.assertNotEqual(p.read_text().strip(),'0')

if __name__=='__main__':unittest.main()
