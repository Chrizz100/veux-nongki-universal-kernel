VEUX M38 - Sammelreparatur BQ-Ladetreiber - NOFLASH
Basis: gruener M37-Lauf 43848823926, Commit 3cfddfa49d9b4cefa164ddfd54b928e34e8988a9.

UPLOAD AM SMARTPHONE
1. VEUX_M38_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M38_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M37 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256 und komplette ZIP-CRC geprueft:
1.256 Dateien, 1.162 Textdateien, 326 JSON-Dateien, 39.050.391 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M37 unabhaengig geprueft:
echte Quellen, LLVM-Objekt/CFI-Kommando, neun verlinkte Schnittstellen und fuenf
VINDPM-/HIZ-Fehlerzweige, 40 erfolgreiche make-Aufrufe, eingebettete Konfiguration
in Image/vmlinux und unveraenderte komplette Exporttabelle.
Import-CRCs unabhaengig neu berechnet: 1.423 passend, keine CRC-Abweichung,
kein fehlender Export und 37 passende Module der bekannten Stock-Vendor-Kohorte.
Boot.img und AK3 byteidentisch aus gepinnten Referenzen rekonstruiert;
AVB und Stock-Ramdisk/Paar geprueft. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M37. Reports/RUN43848823926_32_ARTEFAKTE.zip und
Reports/M37_INDEPENDENT_VERIFICATION.json enthalten die aktuelle Auswertung.
Historische Berichte bleiben in unveraenderten, gepinnten Vorgaengerpaketen.
Static Boot Pass ist kein Device Pass.

ABGESCHLOSSENE SAMMELPRUEFUNG
Alle 65 aktiven Funktionen dieses BQ-Treibers sind mit Zeile, Funktionshash,
Aufrufen, Pruefstatus und Restbefunden inventarisiert. Acht Funktionen gehoeren
zur M38-Reparatur, 17 sind bisherigen nativen Regressionen zugeordnet und 40
sind als reine Quellpruefung klassifiziert. Das ist kein eigener Fehlertest
fuer jede Funktion und kein Vollnachweis fuer den gesamten Kernel oder PMIC-Stack.
Inaktive #if-0-/DEBUG-Funktionen sind aus dieser aktiven Liste ausgeschlossen.
Reports/M38_BQ_FUNCTION_INVENTORY.json und .csv enthalten die vollstaendige Liste.

GEBUENDELTE REPARATUREN
1. Registerzugriffe: Das vollstaendige Lesen/Aendern/Schreiben steht jetzt unter
   dem bestehenden I2C-Mutex. Zwei disjunkte Bitfeld-Updates koennen sich nicht
   mehr durch die fruehere Luecke zwischen Lesen und Schreiben ueberschreiben.
   Drei Leseversuche, die 200-us-Abstaende und der einzelne Schreibversuch bleiben.
2. Ladeerkennung: Der DPDM-Helfer gibt Fehler, Timeout oder Shutdown zurueck.
   Die bisherigen 200 Versuche und 20-ms-Wartezeiten bleiben unveraendert.
   Der Force-Worker stoppt abhaengige Schritte nach GPIO-/DPDM-Fehlern, setzt den
   temporaeren Force-Zustand zurueck und meldet keine erfolgreiche Fertigstellung.
3. ICO: Der Phasenzustand ist pro Geraet gespeichert. Schreib-/Lesefehler werden
   gemeldet. Beim Abziehen wird der ICO-Worker synchron abgebrochen und sein
   Zustand danach zurueckgesetzt. Die bisherige normale Poll-/Timing-Politik bleibt.
4. IRQ/Provider: GPIO-Richtungsaenderungen laufen im Worker statt im harten IRQ.
   Der harte IRQ prueft nur den Stoppzustand und plant Arbeit ein. GPIO-Fehler
   loeschen den ausstehenden Umschaltauftrag nicht als Erfolg. USB-Benachrichtigungen
   werden an allen IRQ-Stellen bei fehlendem Provider ausgelassen.
   Fehler der Anschluss-Konfiguration und ADC-Abschaltung werden gemeldet.
   Physischer Anschlussstatus aus gueltigen Statusregistern und unabhaengige
   Benachrichtigungen, Ueberwachung/Adapterarbeit sowie Abzieh-Aufraeumen bleiben.
5. Start/Entfernen: Fehler der abschliessenden optionalen GPIO-/DPDM-Erkennung
   werden gemeldet; nach GPIO-Fehler folgt keine abhaengige DPDM-Aktion.
   Diese optionale Erkennung bleibt beim Probe nicht fatal: Die Kernressourcen
   sind weiterhin bereit. Das bedeutet keinen erfolgreichen Ladeerkennungsnachweis.
   Der neue Remove-Callback nutzt den unveraenderten, geprueften Shutdown-Pfad
   fuer Worker-Drain und Ressourcenfreigabe vor der Devres-Bereinigung.

Geaendert sind sieben bestehende Funktionen und ein neuer Remove-Callback,
ein privates ICO-Zustandsfeld und die Remove-Zuordnung im I2C-Treiber.
Alle anderen Treiberbytes bleiben gegenueber M37 gleich. Insbesondere bleiben
Monitor/VINDPM, Adapterfunktionen, Initialisierung, Shutdown und IIO-Koerper
byteidentisch. Keine neue Defconfig, kein geaenderter Grenzwert und keine neue
numerische Lade-/Spannungsvorgabe. Beide Header bleiben exakt unveraendert;
bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-LF.

LOKALE PRUEFUNGEN
46 M38-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Neue native Tests verwenden echte aktuelle Register-/Worker-/Probe-Funktionen:
- Atomare Updates: 27.138 Assertions, 7.450 Erfolgs-/Retry-Faelle, 1.575 Fehlerfaelle
  und 168 deterministische Konkurrenzfaelle mit echten pthreads. Der alte
  Registerverlust wird reproduziert; der alte Code scheitert an der neuen Erwartung.
- DPDM/ICO/IRQ/Provider/Remove-Delegation: 698 Assertions, 60 Erfolgsablaeufe,
  326 Fehlerfaelle. Alte falsche DPDM-Fertigstellung und gemeinsam genutzte
  ICO-Phase werden reproduziert. Hard-IRQ-Deferral, Null-Provider, Abziehen,
  Timer-Grenzen und Shutdown waehrend DPDM sind geprueft.
- Optionale Probe-Erkennung: 1.104 Assertions, 16 gleiche Erfolgsablaeufe und
  240 Fehlerfaelle mit beiden Chips und verschiedenen Provider-Zustaenden.
Alle aktuellen nativen Tests zusammen: 139.580 C-Assertions; zusaetzlich
156 Assertions des unveraenderten alten Probetests auf der M31-Referenz.
Die unveraenderten bisherigen Fehler-/Erfolgstests werden auf M38 erneut ausgefuehrt.
Der komplette Treiber kompiliert fuer ARM64 mit gepinntem AOSP Clang 12.0.5,
CFI/ThinLTO und den Headern des aktuellen M37-Laufs. Kein voller lokaler M38-Kernelbau.

FESTE RESTLISTE UND GRENZEN
P1: Tatsaechliche Provider-Bindung und Lebensdauer anhand DT/IIO-Konsumenten.
    Spaete Provider werden nicht neu gebunden; bisherige Missing-Battery-Fallbacks
    fuer CDP/OTG/Terminierung bleiben. Neue Fallback-Politik braucht Geraeteevidenz.
P2: Reihenfolge kompletter Adapter-/Monitor-/IIO-Ablaufe. Einzelne Register-RMWs
    sind geschuetzt; mehrstufige Workflows sind nicht als Ganzes serialisiert.
    Ein pauschaler Mutex ueber Worker-Drain oder Provider-Callbacks kann deadlocken.
P3: IIO-/OF-Konsumentenvertraege, Eingabebereiche und GPIO-/DT-Zuordnung.
    Die Quellpruefung aendert diese bisherigen OEM-Vertraege nicht auf Verdacht.
D1: Reales Booten, Laden/OTG, Temperatur, Suspend, Abziehen und Entfernen/Rebind.
K1: Historische ueber 7.100 Ganzkernel-Quellabweichungen sind nicht vollstaendig
    durch dieses BQ-Inventar abgedeckt; kein universeller GKI-Nachweis.
Ein Wiederherstellungsversuch beweist keinen Hardwarezustand nach einem Busfehler.

CI UND NAECHSTER MEILENSTEIN
Alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue Schicht nutzt den authentischen M28-R2-Baukern mit allen Konfigurations-,
WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M38 muss echte Quellen, LLVM-Objekt,
CFI-Kommando, 13 verlinkte Schnittstellen und sechs neue Fehlerzweige in Image
UND vmlinux nachweisen. Konfiguration und komplette Exporttabelle bleiben Pflicht.
Boot.img/AK3 werden erst nach diesen Gates erstellt.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M38-GitHub-Bau und alle Artefakte, danach die benannten
Restpunkte P1-P3 und sichere Geraetepruefung. Device Pass NEIN. Flashfreigabe NEIN.
