#include <stdlib.h>
#define msecs_to_jiffies(x) (x)

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include <stdatomic.h>
#include <string.h>
#include <sched.h>
typedef uint8_t u8;
typedef uint16_t u16;
struct mutex { pthread_mutex_t value; };
#define DEFINE_MUTEX(n) struct mutex n = { PTHREAD_MUTEX_INITIALIZER }
#define mutex_init(m) pthread_mutex_init(&(m)->value, NULL)
#define mutex_lock(m) pthread_mutex_lock(&(m)->value)
#define mutex_unlock(m) pthread_mutex_unlock(&(m)->value)
#define READ_ONCE(x) __atomic_load_n(&(x), __ATOMIC_SEQ_CST)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v), __ATOMIC_SEQ_CST)
#define dev_err(...) ((void)0)
#define dev_err_ratelimited(...) ((void)0)
#define dev_info(dev,...) do { if (0) printf(__VA_ARGS__); } while (0)
#define pr_debug(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_err_ratelimited(...) ((void)0)
#define udelay(x) ((void)0)
#define msleep(x) event(3,(x),0)
#define __pm_stay_awake(x) ((void)0)
#define __pm_relax(x) ((void)0)
static void event(int kind,int a,int b);
struct device { int kobj; };
struct i2c_client { int irq; struct device dev; void *data; };
struct work_struct { int id; };
struct delayed_work { struct work_struct work; int id; };
#define container_of(p,t,m) ((t *)((char *)(p) - offsetof(t,m)))
static void schedule_delayed_work(struct delayed_work *w, int delay) { event(4,w->work.id,delay); }
struct bq2589x_config {
 bool enable_term, otg_status;
 int input_current, charge_voltage, term_current, battery_voltage_term;
};
struct bq2589x {
 bool ico_issued;
 struct device *dev;
 struct i2c_client *client;
 struct mutex io_lock;
 bool startup_ready, stopping, is_bq25890h, hz_flag, usb_switch_flag, force_exit_flag;
 struct bq2589x_config cfg;
 unsigned int status;
 int old_type, charge_type, otg_gpio, irq_gpio, wakeup_flag;
 int curr_flag,vbus_type,vbus_volt,vbat_volt,usb_swtich_status;
 void *batt_psy, *wt_ws, *usb_psy;
 struct work_struct irq_work, adapter_in_work, adapter_out_work;
 struct delayed_work force_work, ico_work, monitor_work;
};
struct iio_dev { struct bq2589x *data; };
struct iio_chan_spec { int channel; };
union power_supply_propval { int intval; };
struct i2c_device_id { int unused; };
static struct bq2589x *g_bq;
static DEFINE_MUTEX(bq2589x_i2c_lock);
static unsigned char registers[256];
static int fail_read, fail_write, read_calls, write_calls, fail_count, fail_reg, fail_from_call;
static int shutdown_phase, drain_count, priv_calls, alloc_fail;
static atomic_int hold_read, read_entered, release_read;
static void *iio_priv(struct iio_dev *d) { assert(d); priv_calls++; return d->data; }
static struct iio_dev *devm_iio_device_alloc(struct device *dev, size_t n) {
 static struct bq2589x data;
 static struct iio_dev d = { &data };
 return alloc_fail ? NULL : &d;
}
static int gpio_direction_output(int gpio, int val) { return 0; }
static int bq2589x_usb_switch(struct bq2589x *bq, bool enabled) { event(5,enabled,0); return 0; }
static int power_supply_get_property(void *psy, int prop, union power_supply_propval *v) {
 v->intval = prop == POWER_SUPPLY_PROP_TEMP ? 250 : 50;
 return 0;
}
static void *i2c_get_clientdata(struct i2c_client *c) { return c->data; }
static void disable_irq(int irq) { assert(g_bq->stopping); shutdown_phase = 1; }
static void sysfs_remove_group(void *obj, void *attr) { assert(shutdown_phase == 1); }
static void cancel_work_sync(struct work_struct *w) {
 assert(shutdown_phase == 1); assert(w->id == ++drain_count);
}
static void cancel_delayed_work_sync(struct delayed_work *w) {
 assert(shutdown_phase == 1); assert(w->id == ++drain_count);
}
static void free_irq(int irq, void *data) { assert(drain_count == 6); }
static void gpio_free(int gpio) { assert(drain_count == 6); }
static void check_final_bus_access(void);
static int i2c_smbus_read_byte_data(struct i2c_client *c, u8 reg) {
 read_calls++; event(1,reg,0);
 if (atomic_load(&hold_read)) {
  atomic_store(&read_entered, 1);
  while (!atomic_load(&release_read)) sched_yield();
 }
 if (shutdown_phase) check_final_bus_access();
 if (fail_read && (fail_reg < 0 || reg == fail_reg) && (fail_from_call <= 0 || read_calls >= fail_from_call) && (fail_count < 0 || fail_count-- > 0)) return fail_read;
 return registers[reg];
}
static int i2c_smbus_write_byte_data(struct i2c_client *c, u8 reg, u8 data) {
 write_calls++; event(2,reg,data);
 if (shutdown_phase) check_final_bus_access();
 if (fail_write) return fail_write;
 registers[reg] = data;
 return 0;
}

struct event_record { int kind,a,b; };
static struct event_record events[4096],saved_events[4096];
static int event_count;
static void event(int kind,int a,int b) {
 if(event_count>=4096) abort();
 events[event_count++] = (struct event_record){kind,a,b};
}
static void check_final_bus_access(void) { abort(); }

#define EPROBE_DEFER 517
#define smp_load_acquire(p) __atomic_load_n((p), __ATOMIC_ACQUIRE)
