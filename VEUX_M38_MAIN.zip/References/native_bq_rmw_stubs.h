
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sched.h>
typedef uint8_t u8;
struct mutex{pthread_mutex_t value;};
#define DEFINE_MUTEX(n)struct mutex n={PTHREAD_MUTEX_INITIALIZER}
struct device{int unused;};struct i2c_client{int unused;};
struct bq2589x{struct device *dev;struct i2c_client *client;};
static DEFINE_MUTEX(bq2589x_i2c_lock);
static unsigned char registers[256];
static int reads,writes,fail_read,left,fail_write,delays;static bool apply_error;
static _Thread_local int role,unlocks;
static atomic_int paused_mode,second_go,second_done;
#define dev_err(...) ((void)0)
#define udelay(x)do{delays++;}while(0)
static void mutex_lock(struct mutex*m){pthread_mutex_lock(&m->value);}
static void mutex_unlock(struct mutex*m){
 pthread_mutex_unlock(&m->value);
 if(atomic_load(&paused_mode)&&role==1&&++unlocks==1){atomic_store(&second_go,1);while(!atomic_load(&second_done))sched_yield();}
}
static int i2c_smbus_read_byte_data(struct i2c_client*c,u8 reg){reads++;if(fail_read&&(left<0||left>0)){if(left>0)left--;return fail_read;}return registers[reg];}
static int i2c_smbus_write_byte_data(struct i2c_client*c,u8 reg,u8 data){writes++;if(fail_write){if(apply_error)registers[reg]=data;return fail_write;}registers[reg]=data;return 0;}
