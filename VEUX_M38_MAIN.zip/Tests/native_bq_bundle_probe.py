"""Execute real BQ probe/DT functions with per-resource failure injection."""
import argparse
from pathlib import Path
import re, subprocess, tempfile
ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/bq2589x_charger.c'

def function(s, n):
    m = re.search('^(?:static\\s+)?[^\\n;]+\\b' + n + '\\([^;]+?\\n\\{', s, re.M)
    if not m:
        raise ValueError(n)
    return s[m.start():s.index('\n}', m.end()) + 2]

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    a = p.parse_args()
    source = a.source.read_text()
    before = (ROOT / 'References/M37_PROVEN_BQ.c').read_text()
    enum = before[before.index('enum bq2589x_part_no {'):before.index('enum bq2589x_part_no {') + before[before.index('enum bq2589x_part_no {'):].index('};') + 2]
    ref = function(before, 'bq2589x_parse_dt').replace('bq2589x_parse_dt(', 'bq2589x_parse_dt_reference(', 1)
    ref += '\n' + function(before, 'bq2589x_charger_probe').replace('bq2589x_charger_probe(', 'bq2589x_charger_probe_reference(', 1).replace('bq2589x_parse_dt(', 'bq2589x_parse_dt_reference(')
    body = function(source, 'bq2589x_parse_dt') + '\n' + function(source, 'bq2589x_charger_probe')
    tests = 'static int resources(void){return awake_refs+battery_refs+usb_refs+gpio_refs+sysfs_refs+iio_refs+irq_refs;}\nint main(void){\n int parts[]={BQ25890,SYV690},errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};int success_cases=0,fault_cases=0;\n for(int chip=0;chip<2;chip++)for(int dt=0;dt<2;dt++)for(int nullable=0;nullable<4;nullable++){\n  reset(parts[chip],dt);nullable_battery=nullable&1;nullable_usb=nullable&2;last_warning=0;CHECK(bq2589x_charger_probe_reference(&client,NULL)==0);int saved_count=used;memcpy(saved,trace,sizeof(trace));\n  reset(parts[chip],dt);nullable_battery=nullable&1;nullable_usb=nullable&2;last_warning=0;CHECK(bq2589x_charger_probe(&client,NULL)==0);CHECK(used==saved_count&&!memcmp(trace,saved,(size_t)used*sizeof(trace[0])));CHECK(state.startup_ready&&early_ready==0&&last_warning==0&&irq_refs==1&&iio_refs==1);success_cases++;\n  for(int phase=0;phase<2;phase++)for(int e=0;e<5;e++){\n   reset(parts[chip],dt);nullable_battery=nullable&1;nullable_usb=nullable&2;last_warning=0;fail_event=phase?FORCE_DPDM:USB_SWITCH;fail_code=errors[e];\n   CHECK(bq2589x_charger_probe(&client,NULL)==0);CHECK(last_warning==errors[e]);CHECK(count(USB_SWITCH)==1&&count(FORCE_DPDM)==phase);CHECK(state.startup_ready&&early_ready==0&&state.irq_wake_enabled);CHECK(resources()==7-!!nullable_battery-!!nullable_usb&&irq_refs==1&&client.data==&state);fault_cases++;\n  }\n  for(int e=0;e<5;e++){\n   reset(parts[chip],dt);nullable_battery=nullable&1;nullable_usb=nullable&2;last_warning=0;fail_event=ENABLE_WAKE;fail_code=errors[e];CHECK(bq2589x_charger_probe(&client,NULL)==0);CHECK(state.startup_ready&&!state.irq_wake_enabled&&last_warning==errors[e]);CHECK(count(USB_SWITCH)==1&&count(FORCE_DPDM)==1&&irq_refs==1);fault_cases++;\n  }\n }\n printf("BQ_BUNDLED_PROBE_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; optional detection failure remains nonfatal, no dependent DPDM after GPIO failure\\n",assertions,success_cases,fault_cases);return 0;\n}\n'
    with tempfile.TemporaryDirectory(prefix='m38-bq-bundle-probe-') as t:
        c = Path(t) / 'test.c'
        exe = Path(t) / 'test'
        c.write_text((ROOT / 'References/native_bq_bundle_probe_stubs.h').read_text() + '\n' + enum + '\n' + ref + '\n' + body + '\n' + tests)
        subprocess.run(['cc', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter', '-Wno-unused-function', '-fsanitize=undefined', '-fno-sanitize-recover=all', str(c), '-o', str(exe)], check=True)
        subprocess.run([str(exe)], check=True, timeout=20)
if __name__ == '__main__':
    main()
