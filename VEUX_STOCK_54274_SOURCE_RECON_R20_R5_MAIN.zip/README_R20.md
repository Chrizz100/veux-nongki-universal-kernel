# R20-R5: originale Qualcomm-WALT-Scheduler-Callbacks – NOFLASH

**GitHub-Basis:** `Chrizz100/veux-nongki-universal-kernel`, Commit `acdb66fb383778f5f72ec23e45c2fdd66af683bd`.
**Vorheriger Lauf:** [R20-R4 #42180147079](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42180147079).
**Ergebnis des vorherigen Laufs:** 5/5 R20- und 12/12 R17-Einzelobjekte gruen; erst der FULL-Image-Build scheiterte an `kernel/sched/idle.c:496` (WALT-5-Parameter-Callback gegen Stock-4-Parameter-Implementierung).

Dieser R5-Versuch uebernimmt nur die exakten `CONFIG_SCHED_WALT`-bedingten Funktionssignaturen von `select_task_rq_idle`, `select_task_rq_dl` und `select_task_rq_stop` aus dem **gepinten Qualcomm-M11-Quellstand** in den isolierten SM6375-Compiler-Worktree. Die restlichen originalen SM6375-Funktionskoerper, insbesondere Nicht-WALT, bleiben unveraendert. Keine Dummy-Callbacks, keine Warnunterdrueckung und keine faelschlichen CRCs.

## Gepruefte gepinnte Originaldateien (Git-Blob SHA)

| Datei | SM8350 Qualcomm | SM6375 Donor |
|---|---|---|
| `kernel/sched/idle.c` | `251a7df055d6ba8644d3df566ba91c2fe5f0ed5f` | `b8e66abbc618f6037d6e306159f123f80e90d546` |
| `kernel/sched/deadline.c` | `58e0eeef00904e84e6a05869f12fc06be55c315e` | `50fdd78145677d10fe6a90fa13168abc0282533e` |
| `kernel/sched/stop_task.c` | `6a0937d4884ff0e07741e060cf45ac17fef8b9d3` | `02dc0a8e392571bb000dc549b57af0a7f48fb1e5` |

## Ablauf in GitHub

1. Gesichertes R19-Baseline-Replay (12 originale Komponenten) und unveraenderte Elternarchive pruefen.
2. R20-R5-Quellen nur im isolierten Compiler-Worktree zusammenfuehren, Hashbelege veroeffentlichen.
3. **8 echte Objektkompilierungen** (CORE, RT, FAIR, VMSCAN, SOFTIRQ, IDLE, DEADLINE, STOP_TASK) und **12 originale R17 Regressionen** neu kompilieren; Fehler muessen rot bleiben.
4. Nur bei erfolgreichem 20/20-Kompilieren das vollstaendige `Image dtbs` und den R18 OEM-ABI-Nachweis versuchen. Logs/JSON als Artefakte; **keine Images/Kernel-ZIPs** hochladen.

**Dies ist keine Stock-Reproduktion und keine Flashfreigabe.** `vmlinux`, OEM-Modul-ABI, Boot-Layout, ReSukiSU, SUSFS und NoMount-Laufzeit sind hier noch nicht freigegeben. Die 20 Objektkompilierungen werden erst auf GitHub nachgewiesen, nicht durch Offline-Python-Tests. Alle R17–R20-R4-Originaldateien bleiben unveraendert.

## Handover

Zum GitHub-Upload gehoert genau die neue `.github/workflows/VEUX_STOCK_54274_SOURCE_RECON_R20_R5_COMPAT_NOFLASH.yml` sowie das neue Repo-Root-Archiv `VEUX_STOCK_54274_SOURCE_RECON_R20_R5_MAIN.zip`. Alte ZIPs nicht ersetzen. SHA256 aus `VEUX_R20_R5_UPLOAD_ANLEITUNG_SHA256.txt` vergleichen.
