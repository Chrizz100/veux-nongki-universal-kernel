VEUX R62-R3 - aktueller SUSFS-2.3-Backport fuer xxKSU / Linux 5.4.274

Dateien fuer GitHub:
1. VEUX_R62_XXKSU_MAIN.zip unveraendert im Repo-Hauptverzeichnis ersetzen.
2. VEUX_R62_XXKSU_5_4_274.yml unter .github/workflows/ ersetzen.
3. Actions > VEUX R62-R3 - xxKSU SUSFS 2.3 native54 update > Run workflow.
Keine eigenen Secrets oder Eingaben erforderlich.

Kernel: native 5.4.274, CASS; Poco X4 Pro / Redmi Note 11 Pro 5G (veux),
Android 13 / HyperOS 1.0.12.0.TKCMIXM. NoMount 2.2.0 unveraendert enthalten.
SUSFS-5.10-Referenz: midori01/susfs4ksu 8a120081f2739bc0e4b1f6a389d8236f22944acc.

Neu gegenueber R62-R2: vollstaendige native SELinux-Abfragepfade, SID-/Zygote-
und Profilbehandlung, KSTAT fuer statfs/inotify/proc-fd, korrigierter KSTAT-
Dreiargument-Aufruf mit FUSE-Auswahl, Mount-/Device-ID-Behandlung und no-su-Pfade.
Die vorhandenen nativen SRCU-, Readlink- und statfs-Sicherheitskorrekturen bleiben erhalten.
Die R62-R2-Korrektur fuer die zwei fehlenden statfs-Linker-Symbole bleibt enthalten.

UAPI 6 ist keine SUSFS-Versionsnummer. Es bezeichnet im BakaSU-Zweig unter anderem
Symbolabfrage und Preinit-Funktionen. xxKSU 32668 verwendet weiterhin seinen
originalen UAPI-5-Vertrag. Keine Versionsnummer ohne passende Implementierung erhoeht.
Die KSU-seitigen SUSFS-Aenderungen sind portiert; ein Wechsel zu BakaSU-UAPI 6
mit dessen Daemon/Manager ist in diesem Paket nicht enthalten.
Die Zuordnung der betrachteten Commits steht in R62_R3_COMMIT_BACKPORT_AUDIT.json.
Upstream-Syncs fuer einen anderen KSU-Fork werden dort ausdruecklich getrennt behandelt.

Pruefungen: 27 reale ARM64-Objekte mit Clang 12.0.5 kompiliert; relocatable
LTO-Link aller integrierten SUSFS/xxKSU-Verbindungen und Negativtests: PASS.
Eine bestehende Warnung in fs/namei.c (unused atomic_open) ist protokolliert.
Der Workflow wiederholt die Kompilier-/Linkpruefung vor dem kompletten Kernelbau.
Ein kompletter R62-R3-GitHub-Bau, OEM-Vendor-ABI-Abgleich und Boot-Test stehen aus.
MAIN ist ein Quell-/Buildpaket; kein Flash-Pass und kein bereits gebauter Kernel.

Passender unveraenderter Upstream-Manager: KaSU_v3.3.0_32668-release.apk,
Paket ka.super, SHA256 2f48d34defb743255bc0ef6ace97b3d87cfd989310a1044640847319504ccada.
Ein separat passender Spoofed-Build ist weiterhin nicht im xxKSU-Upstream belegt.
