VEUX R62-R5 - Korrektur fuer GitHub-Lauf 41959978838

Der R4-Lauf brach in kernel/sched/debug.c mit nicht definiertem __PS ab.
OEM-, Boot- und AK3-Stufen wurden dort deshalb NICHT ausgefuehrt.

Die vorhandenen Repo-Korrekturen sind jetzt uebernommen:
1. ConfigDiag10 sched-debug-pm.patch: echte maskierte Ausgabe mit SEQ_printf.
2. ConfigDiag10 embed-real-config.patch: config_data.gz folgt der echten .config.
3. veux_perf_compat.py: core_ctl.h bleibt im passenden QGKI-Zweig; die echte
   MSM-CPU-Min/Max-Frequenzschnittstelle bleibt aktiv und mit CFI kompiliert.
Keine Deaktivierung von Debug, Audit, CFI, Stackschutz oder MSM_PERFORMANCE.
Ein Postcheck beruecksichtigt jetzt die echten CFI-Symbolsuffixe und verlangt
weiterhin die verknuepften KernelSU-/NoMount-Initcalls.

TATSAECHLICHER LOKALER KONTROLLBAU R5: PASS
- Vollstaendiger ARM64-Bau von Image, DTBs und Modulen mit Clang 12.0.5.
- Finaler vmlinux-Link und Instrumentierung mit CFI bestanden.
- 40 vorhandene Repo-Regressionstests bestanden (Diag10 + Performance).
- Konfiguration ausserhalb xxKSU identisch zur bewaehrten R13-Referenz.
- 132/132 bekannte geladene RMNET-Importe: MATCH, keine fehlenden Exporte.
- VEUX-DTB identisch zur Referenz.
- boot.img erzeugt; Stock-Ramdisk bytegleich, AVB-Hash und AOSP-avbtool-Pruefung
  bestanden; Kernel erneut extrahiert; MagiskBoot-Roundtrip bytegleich.
- AK3 DANACH erzeugt und mit demselben Kernelimage abgeglichen.
Alle lokalen Belege und Logs liegen im MAIN, besonders LOCAL_R5_VALIDATION/.

Der lokale Kontrollbau ist KEIN R5-GitHub-Lauf und KEIN Geraete-Flash-Test.
Der eigentliche Bau laeuft wie vereinbart weiterhin ueber GitHub:
- VEUX_R62_XXKSU_MAIN.zip im Repo-Hauptverzeichnis ersetzen.
- VEUX_R62_XXKSU_5_4_274.yml unter .github/workflows/ ersetzen.
- Actions > VEUX R62-R5 - xxKSU OEM Boot-v3 Diag10 fix > Run workflow.
Keine eigenen Secrets oder weiteren Eingaben erforderlich.

Die neue YAML kompiliert Scheduler, echte Konfiguration und MSM-Performance
bereits vor dem Hauptbau und prueft dabei die drei Original-Repo-Korrekturen.
Danach folgen vollstaendiger Kernelbau, 132-Import-ABI-Pruefung,
Boot-v3-/Ramdisk-/AVB-/Roundtrip-Pruefung und erst anschliessend AK3.
Die Boot-/AK3-Kette samt aktiver Boot-Sicherung und Ruecklesepruefung bleibt erhalten.
Root-Module werden nicht deaktiviert oder entfernt. Kein automatischer Neustart.

Ziel: veux, Android 13, HyperOS OS1.0.12.0.TKCMIXM; Linux 5.4.274,
xxKSU 32668/UAPI 5, SUSFS 2.3.0, NoMount 2.2.0, CASS.
Manager unveraendert passend: KaSU_v3.3.0_32668-release.apk / ka.super.

OEM-Grenze: Das historische 218-Dateien-Archiv enthaelt GKI/QGKI-Familien mit
836 widerspruechlichen Symbol-CRCs. Dies wird getrennt klassifiziert; die
132 bekannten geladenen RMNET-Importe bestehen jetzt tatsaechlich alle.
Der vollstaendige aktuelle aktive OEM-Modulsatz und ein echter Geraeteboot
werden weiterhin nicht aus einem statischen Archiv behauptet.

Fuer den spaeteren Geraetetest liegt DEVICE_TEST.sh im GitHub-Artefakt:
  su -c 'sh /sdcard/Download/DEVICE_TEST.sh before'
  su -c 'sh /sdcard/Download/DEVICE_TEST.sh after'
Der Collector arbeitet lesend. Ein DEVICE PASS erfordert einen echten Test.
