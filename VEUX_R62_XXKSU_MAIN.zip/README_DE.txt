VEUX R62-R4 - xxKSU / OEM-ABI / Boot-v3 / AK3

Auf GitHub ersetzen:
- VEUX_R62_XXKSU_MAIN.zip im Hauptverzeichnis.
- VEUX_R62_XXKSU_5_4_274.yml unter .github/workflows/.
Dann Actions > VEUX R62-R4 - xxKSU OEM ABI Boot-v3 AK3 > Run workflow.
Keine eigenen Secrets und keine zusaetzlichen Eingaben erforderlich.

Gepinnte Repo-Pruefung: 569e75e7e0175d5ca22d7b041b3e94d48b191087.
Vollstaendiger Remote-Dateibaum: 2014 Eintraege, nicht abgeschnitten.
331 Workflows und 114 Root-ZIP-Archive inventarisiert; Boot-/OEM-Vertraege,
R60-Bootkette, R13-Referenzen und originale Vendor-Importbelege ausgewertet.

Korrektur gegenueber R62-R3:
Die generierte R3-Konfiguration wich ausserhalb von KSU in 23 Einstellungen von
der bewaehrten R13-Referenz ab, darunter CFI, Stackschutz, Audit und Treiber.
R4 stellt diese Referenzwerte wieder her und verhindert abweichende Tracing-
Defaults. Alle Nicht-KSU-Konfigurationswerte sind danach gleich zur Referenz.
Kernel-C-Code, xxKSU-Quellstand, SUSFS-Backport, NoMount 2.2 und CASS bleiben erhalten.

Tatsaechlich lokal geprueft:
- Native ARM64-Integrationsobjekte unter aktivem CFI kompiliert und LTO-verknuepft.
- module_layout neu durch genksyms berechnet: 0xbff14f69, passend zu den
  archivierten geladenen RMNET-Modulen. Kein CRC-Override.
- VEUX-DTB neu gebaut: SHA256
  42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37.
- Der wirklich auf GitHub gebaute R62-R3-Kernel wurde mit dem unveraenderten
  Repo-Repacker in die veroeffentlichte Boot-v3-Referenz eingebaut.
  Ramdisk byte-identisch, AVB-Pruefung mit AOSP avbtool, erneute Extraktion und
  byte-identischer MagiskBoot-Roundtrip: PASS.
- OEM-Modulparser: 14 vorhandene Tests und echter R13-Referenzabgleich mit
  132/132 Importen bestanden. Der komplette R4-Abgleich folgt im GitHub-Bau.

Neue GitHub-Befehlskette:
1. Gepinnte Quellen und MAIN-Hashes pruefen.
2. Native Konfiguration einschliesslich CFI/Stackschutz strikt mit R13 abgleichen.
3. ARM64-Kernel, DTBs und Module vollstaendig kompilieren und verknuepfen.
4. Tatsachliches Image, eingebettete .config, DTB und Module.symvers pruefen.
5. Alle 14.648 historischen Importe klassifizieren und die 132 bekannten
   geladenen RMNET-Importe ohne fehlende Exporte oder CRC-Abweichungen verlangen.
6. Die vorhandene veroeffentlichte Boot-Referenz mit SHA256 laden.
7. boot.img ZUERST erstellen: Stock-Ramdisk, Boot-v3-Header und AVB pruefen,
   erneut extrahieren, MagiskBoot-Roundtrip bytegleich verlangen.
8. AK3 DANACH nur bei passender bekannter Modul-ABI erzeugen.
9. Saemtliche Belege und Artefakte einschliesslich Fehlerdiagnosen hochladen.

Vendor-Grenze:
Die 218 historischen Dateien enthalten zwei GKI/QGKI-Familien mit 836
widerspruechlichen Symbol-CRCs. Ein einzelner Kernel kann diese nicht alle
gleichzeitig erfuellen. Die komplette aktuelle aktive OEM-Modulmenge wird daher
nicht aus diesem Archiv behauptet. Die echte geladene RMNET-Referenz wird separat
streng geprueft. Kein Umbenennen oder Faelschen von CRCs, kein Erzwingen von Modulen.

Geraetetest:
Das spaetere GitHub-Artefakt enthaelt DEVICE_TEST.sh.
Vor dem manuellen Test unter Root ausfuehren:
  su -c 'sh /sdcard/Download/DEVICE_TEST.sh before'
Nach einem erfolgreichen Neustart:
  su -c 'sh /sdcard/Download/DEVICE_TEST.sh after'
Die Ausgabe liegt unter /sdcard/Download/VEUX_R62_R4_DEVICE_*.tar.gz.
Der Collector laedt/entlaedt keine Module und aendert keine Root-Konfiguration.

Das neue AK3 nutzt die vorhandene R60-Boot-only-Kette: aktive Bootpartition sichern,
aktuelles Geraete-Boot offline pruefen/repacken, Backup-Hash vor dem Schreiben
nochmals vergleichen, nur aktive Bootpartition schreiben und vollstaendig
zuruecklesen. Kein automatischer Neustart. Keine Root-Module werden entfernt
oder deaktiviert; vendor_boot, dtbo und top-level vbmeta bleiben unbeschrieben.

Status dieser Uebergabe:
R3: kompletter GitHub-Bau und neuer tatsaechlicher statischer Boot-Pfad PASS;
    die R3-Konfiguration bleibt wegen der festgestellten ABI-Abweichung ueberholt.
R4: gepruefte Quellen/Konfiguration/Objekte/Link/DTB/Pruefkette; neuer kompletter
    GitHub-Bau und danach die echte 132-Import-Freigabe stehen noch aus.
Kein DEVICE PASS und keine behauptete ausgefuehrte Geraete-Flashpruefung.

Ziel: veux, Android 13, HyperOS OS1.0.12.0.TKCMIXM; Linux 5.4.274,
xxKSU 32668/UAPI 5, SUSFS 2.3.0, NoMount 2.2.0, CASS.
Manager unveraendert passend: KaSU_v3.3.0_32668-release.apk, Paket ka.super.
