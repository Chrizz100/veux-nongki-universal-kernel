VEUX R62 - xxKSU 32668 / UAPI 5, SUSFS 2.3.0, NoMount 2.2.0

Ziel: Poco X4 Pro 5G / Redmi Note 11 Pro 5G (veux), Android 13, HyperOS 1.0.12.0.TKCMIXM.
Basis: native 5.4.274/CASS aus der authentifizierten bestehenden VEUX-Linie.

Upload: VEUX_R62_XXKSU_MAIN.zip unveraendert ins Repo-Hauptverzeichnis hochladen.
Die YAML nach .github/workflows/VEUX_R62_XXKSU_5_4_274.yml hochladen.
Dann Actions > VEUX R62 - xxKSU SUSFS 2.3 NoMount 2.2 > Run workflow.
Keine Benutzereingaben oder eigenen Secrets notwendig.

Enthalten: exakter nativer Quellpatch, vendierter xxKSU-Kernelteil, NoMount-Quellen, SUSFS-2.3-Anbindung, Hashmanifest, Build-/Pruefprogramme.
Die wesentlichen Kernelobjekte wurden mit Clang 12.0.5 fuer ARM64 kompiliert.
Ein kompletter Kernelbau, finaler OEM-Vendor-ABI-Abgleich, boot.img Static Boot Test und Geraetetest stehen aus.
Kein Flash-Pass. Ein erfolgreicher Objekt- oder CI-Bau ist kein Nachweis fuer Bootfaehigkeit.

Die Quell-Differenzen sind aus bestehender nativer 5.4-Integration und den genannten offiziellen Quellstaenden abgeleitet.
Eine lueckenlose Einzelcommit-Freigabe aller SUSFS-Upstreamaenderungen ist damit noch nicht bewiesen.

Manager: zum exakten xxKSU-Commit gehoert upstream KaSU_v3.3.0_32668-release.apk, Paket ka.super.
Kein separater passender Spoofed-Build im Upstream-Artefakt gefunden. BakaSU/SukiSU-Manager werden nicht als Ersatz ausgegeben.
