#!/usr/bin/env python3
"""Apply the exact native 5.4 patch and pinned kernel sources."""
from pathlib import Path
import sys,json,hashlib,subprocess,shutil
p=Path(__file__).resolve().parent;k=Path(sys.argv[1]).resolve()
m=json.loads((p/'MANIFEST.json').read_text())
for rel,expected in m['files'].items():
 f=p/rel
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=expected:raise SystemExit('PAYLOAD_HASH_FAILED:'+rel)
head=subprocess.check_output(['git','-C',str(k),'rev-parse','HEAD'],text=True).strip()
assert head==m['kernel_base_commit'],'KERNEL_BASE_CHANGED'
assert not subprocess.check_output(['git','-C',str(k),'status','--porcelain'],text=True).strip(),'SOURCE_NOT_CLEAN'
patch=p/'native54.patch'
subprocess.run(['git','-C',str(k),'apply','--check',str(patch)],check=True)
subprocess.run(['git','-C',str(k),'apply',str(patch)],check=True)
shutil.copytree(p/'xxksu-kernel',k/'KernelSU/kernel')
shutil.copytree(p/'nomount',k/'fs/nomount')
version=subprocess.check_output(['make','-s','-C',str(k),'kernelversion'],text=True).strip()
assert version=='5.4.274',version
assert (k/'drivers/kernelsu').resolve()==(k/'KernelSU/kernel').resolve(),'DRIVER_LINK_CHANGED'
print('R62_EXACT_SOURCE_PATCH_AND_HASHES=PASS')
