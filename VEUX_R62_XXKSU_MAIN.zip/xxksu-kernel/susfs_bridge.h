/* SPDX-License-Identifier: GPL-2.0-only */
#ifdef CONFIG_KSU_SUSFS
#include <linux/susfs.h>
void xxksu_susfs_cache_sids(void);
u32 susfs_get_sid_from_name(const char *name);
u32 susfs_get_current_sid(void);
bool susfs_is_sid_equal(const struct cred *cred, u32 sid);
bool susfs_is_current_ksu_domain(void);
bool susfs_is_current_zygote_domain(void);
bool susfs_is_current_zygote_next_domain(void);
bool susfs_is_current_init_domain(void);
void susfs_set_batch_sid(void);
void xxksu_susfs_setuid(const struct cred *new, const struct cred *old);
int xxksu_susfs_command(unsigned int cmd, void __user **arg);
#endif
