/* SPDX-License-Identifier: GPL-2.0-only */
#ifdef CONFIG_KSU_SUSFS
#include <linux/susfs.h>
void xxksu_susfs_cache_sids(void);
void xxksu_susfs_setuid(const struct cred *new, const struct cred *old);
int xxksu_susfs_command(unsigned int cmd, void __user **arg);
#endif
