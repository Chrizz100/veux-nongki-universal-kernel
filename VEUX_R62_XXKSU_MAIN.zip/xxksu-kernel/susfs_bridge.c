/* SPDX-License-Identifier: GPL-2.0-only */
/* VEUX native 5.4 bridge. Keep xxKSU UAPI 5 and userspace ABI intact. */
u32 susfs_ksu_sid __read_mostly;
u32 susfs_init_sid __read_mostly;
u32 susfs_zygote_sid __read_mostly;
u32 susfs_zygote_next_sid __read_mostly;
u32 susfs_priv_app_sid __read_mostly;
extern struct work_struct susfs_extra_works;

u32 susfs_get_sid_from_name(const char *name)
{
	u32 sid = 0;
	if (!name || security_secctx_to_secid(name, strlen(name), &sid))
		return 0;
	return sid;
}

bool susfs_is_sid_equal(const struct cred *cred, u32 sid)
{
	const struct task_security_struct *tsec;
	if (!cred || !sid)
		return false;
	tsec = selinux_cred(cred);
	return tsec && tsec->sid == sid;
}

u32 susfs_get_current_sid(void)
{
	const struct task_security_struct *tsec = selinux_cred(current_cred());
	return tsec ? tsec->sid : 0;
}

bool susfs_is_current_ksu_domain(void)
{
	return is_ksu_domain();
}

bool susfs_is_current_zygote_domain(void)
{
	return is_zygote(current_cred());
}

bool susfs_is_current_zygote_next_domain(void)
{
	return susfs_is_sid_equal(current_cred(), READ_ONCE(susfs_zygote_next_sid));
}

bool susfs_is_current_init_domain(void)
{
	return is_init(current_cred());
}

void susfs_set_batch_sid(void)
{
	WRITE_ONCE(susfs_ksu_sid, susfs_get_sid_from_name(KERNEL_SU_CONTEXT));
	WRITE_ONCE(susfs_init_sid, susfs_get_sid_from_name(INIT_CONTEXT));
	WRITE_ONCE(susfs_zygote_sid, susfs_get_sid_from_name(ZYGOTE_CONTEXT));
	WRITE_ONCE(susfs_zygote_next_sid, susfs_get_sid_from_name("u:r:zygote_next:s0"));
	WRITE_ONCE(susfs_priv_app_sid, susfs_get_sid_from_name("u:r:priv_app:s0:c512,c768"));
}

void xxksu_susfs_cache_sids(void)
{
	susfs_set_batch_sid();
}

bool xxksu_sucompat_enabled(void)
{
	return READ_ONCE(ksu_su_compat_enabled);
}

/* The outer VFS owns one filename reference; replace it only after success. */
static void xxksu_filename_su(struct filename **name)
{
	struct filename *replacement;
	if (!name || IS_ERR_OR_NULL(*name) || !ksu_sucompat_current_allowed() ||
	    !READ_ONCE(ksu_su_compat_enabled) || strcmp((*name)->name, SU_PATH))
		return;
	replacement = getname_kernel(SH_PATH);
	if (IS_ERR(replacement))
		return;
	putname(*name);
	*name = replacement;
}

int xxksu_handle_faccessat(int *dfd, struct filename **name, int *mode, int *flags)
{
	xxksu_filename_su(name);
	return 0;
}

int xxksu_handle_stat(int *dfd, struct filename **name, int *flags)
{
	xxksu_filename_su(name);
	return 0;
}

int ksu_handle_sys_read(unsigned int fd, char __user **buf, size_t *count)
{
	ksu_handle_sys_read_fd(fd);
	return 0;
}

void xxksu_susfs_setuid(const struct cred *new, const struct cred *old)
{
	uid_t uid;
	bool zygote_next;
	bool hide;

	if (!new || !old || ksu_get_uid_t(old->uid) != 0)
		return;
	zygote_next = susfs_is_sid_equal(old, READ_ONCE(susfs_zygote_next_sid));
	if (!zygote_next && !is_zygote(old))
		return;
	uid = ksu_get_uid_t(new->uid);

	/* A newly spawned process must follow its own manager profile. */
	susfs_clear_current_proc_no_su();
	susfs_clear_current_proc_umounted();
	susfs_clear_current_proc_umounted_for_zygote_next();
	if (!is_isolated_process(uid) &&
	    (is_uid_manager(uid) || ksu_is_allow_uid_for_current(uid)))
		return;

	susfs_set_current_proc_no_su();
	hide = is_isolated_process(uid) ||
		((is_appuid(uid) || uid == WEBVIEW_ZYGOTE_UID) && ksu_uid_should_umount(uid));
	if (!hide)
		return;
	susfs_set_current_proc_umounted();
	/* The native unmount handler separately rejects zygote_next's init namespace. */
	if (zygote_next)
		susfs_set_current_proc_umounted_for_zygote_next();
	if (!work_pending(&susfs_extra_works))
		schedule_work(&susfs_extra_works);
}

noinline int xxksu_susfs_command(unsigned int cmd, void __user **arg)
{
	switch (cmd) {
#ifdef CONFIG_KSU_SUSFS_SUS_PATH
	case CMD_SUSFS_ADD_SUS_PATH: susfs_add_sus_path(arg); return 0;
	case CMD_SUSFS_ADD_SUS_PATH_LOOP: susfs_add_sus_path_loop(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
	case CMD_SUSFS_HIDE_SUS_MNTS_FOR_NON_SU_PROCS: susfs_set_hide_sus_mnts_for_non_su_procs(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_SUS_KSTAT
	case CMD_SUSFS_ADD_SUS_KSTAT:
	case CMD_SUSFS_ADD_SUS_KSTAT_STATICALLY: susfs_add_sus_kstat(arg); return 0;
	case CMD_SUSFS_UPDATE_SUS_KSTAT: susfs_update_sus_kstat(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_SPOOF_UNAME
	case CMD_SUSFS_SET_UNAME: susfs_set_uname(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_ENABLE_LOG
	case CMD_SUSFS_ENABLE_LOG: susfs_enable_log(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_SPOOF_CMDLINE_OR_BOOTCONFIG
	case CMD_SUSFS_SET_CMDLINE_OR_BOOTCONFIG: susfs_set_cmdline_or_bootconfig(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_OPEN_REDIRECT
	case CMD_SUSFS_ADD_OPEN_REDIRECT: susfs_add_open_redirect(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_SUS_MAP
	case CMD_SUSFS_ADD_SUS_MAP: susfs_add_sus_map(arg); return 0;
#endif
#ifdef CONFIG_KSU_SUSFS_PRIORITY_UID_FILTER
	case CMD_SUSFS_SET_PRIORITY_UID_FILTER: susfs_set_priority_uid_filter(arg); return 0;
#endif
	case CMD_SUSFS_ENABLE_AVC_LOG_SPOOFING: susfs_set_avc_log_spoofing(arg); return 0;
	case CMD_SUSFS_SHOW_ENABLED_FEATURES: susfs_get_enabled_features(arg); return 0;
	case CMD_SUSFS_SHOW_VARIANT: susfs_show_variant(arg); return 0;
	case CMD_SUSFS_SHOW_VERSION: susfs_show_version(arg); return 0;
	default: return -EINVAL;
	}
}

bool xxksu_selinux_hide_active(void)
{
	return READ_ONCE(ksu_selinux_hide_enabled) && ksu_is_seccomp_enabled();
}

struct page *xxksu_susfs_status_page(void)
{
	return smp_load_acquire(&ksu_fake_status_page);
}
