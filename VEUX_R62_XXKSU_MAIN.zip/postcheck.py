#!/usr/bin/env python3
"""Validate the full linked build; packaging follows OEM and boot-v3 checks."""
from pathlib import Path
import gzip,hashlib,json,re,shutil,struct,subprocess,sys
build=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(exist_ok=True)
config=(build/'.config').read_bytes()
image=build/'arch/arm64/boot/Image';raw=image.read_bytes()
assert len(raw)>1_000_000 and raw[56:60]==b'ARM\x64','INVALID_ARM64_IMAGE'
start=raw.index(b'IKCFG_ST')+8;end=raw.index(b'IKCFG_ED',start)
assert gzip.decompress(raw[start:end])==config,'IMAGE_CONFIG_NOT_ACTUAL'
elf=(build/'vmlinux').read_bytes()[:64]
assert elf[:4]==b'\x7fELF' and elf[4]==2 and struct.unpack_from('<H',elf,18)[0]==183,'INVALID_ARM64_ELF'
nm=subprocess.check_output(['llvm-nm','--defined-only',str(build/'vmlinux')],text=True)
for sym in ['kernelsu_init','nomount_init','xxksu_susfs_command']:
 assert any(re.search(r' '+re.escape(sym)+r'(?:\$[0-9a-f]{32})?(?:\.[A-Za-z0-9_.]+)?$',l) for l in nm.splitlines()),'UNLINKED_FEATURE:'+sym
for init in ['kernelsu_init','nomount_init']:
 assert any(re.search(r' __initcall_\w*_'+re.escape(init)+r'\d(?:\..*)?$',l) for l in nm.splitlines()),'MISSING_LINKED_INITCALL:'+init
for rel in ['drivers/kernelsu/ksu.o','fs/susfs.o','fs/nomount/nomount.o']:
 assert (build/rel).stat().st_size>100,'MISSING_COMPILED_COMPONENT:'+rel
for source,name in [(image,'Image'),(build/'.config','build.config'),(build/'Module.symvers','Module.symvers'),(build/'System.map','System.map'),(build/'include/config/kernel.release','kernel.release'),(build/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb','veux.dtb')]:
 shutil.copyfile(source,out/name)
shutil.copyfile(Path(__file__).with_name('DEVICE_TEST.sh'),out/'DEVICE_TEST.sh')
report={'revision':'R62-R5','kernel':'5.4.274','xxksu_version':32668,'xxksu_uapi':5,
 'susfs':'2.3.0','nomount':'2.2.0','image_header_pass':True,'image_config_identity_pass':True,
 'linked_components_pass':True,'full_kernel_compile_pass':True,
 'static_boot_img_test_performed':False,'vendor_abi_validated':False,
 'device_boot_tested':False,'flash_allowed':False,
 'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}}
(out/'BUILD_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
