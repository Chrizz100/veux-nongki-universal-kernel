#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,struct,subprocess,sys,zipfile,shutil,re
build=Path(sys.argv[1]);ak=Path(sys.argv[2]);out=Path(sys.argv[3]);out.mkdir(exist_ok=True)
config=(build/'.config').read_text()
for name in ['KSU','KSU_SUSFS','KSU_SUSFS_SUS_PATH','KSU_SUSFS_SUS_MOUNT','KSU_SUSFS_SUS_KSTAT','KSU_SUSFS_OPEN_REDIRECT','KSU_SUSFS_PRIORITY_UID_FILTER','NOMOUNT','SECURITY_SELINUX','MODULES','MODVERSIONS']:
 assert f'CONFIG_{name}=y\n' in config,'MISSING_BUILTIN:'+name
for name in ['KSU_LSM_SECURITY_HOOKS','KSU_HACK_ARM64_BRANCH_LINK','KSU_TAMPER_SYSCALL_TABLE','KSU_TINYFS_SUCOMPAT']:
 assert f'CONFIG_{name}=y\n' not in config,'UNEXPECTED_HOOK_MODE:'+name
im=build/'arch/arm64/boot/Image';raw=im.read_bytes()
assert len(raw)>1_000_000 and raw[56:60]==b'ARM\x64','INVALID_ARM64_IMAGE'
elf=(build/'vmlinux').read_bytes()[:64]
assert elf[:4]==b'\x7fELF' and elf[4]==2 and struct.unpack_from('<H',elf,18)[0]==183,'INVALID_ARM64_ELF'
nm=subprocess.check_output(['llvm-nm','--defined-only',str(build/'vmlinux')],text=True)
for sym in ['kernelsu_init','nomount_init','xxksu_susfs_command']:
 assert any(re.search(r' '+re.escape(sym)+r'(?:\..*)?$',l) for l in nm.splitlines()),'UNLINKED_FEATURE:'+sym
for rel in ['drivers/kernelsu/ksu.o','fs/susfs.o','fs/nomount/nomount.o']:
 assert (build/rel).stat().st_size>100,'MISSING_COMPILED_COMPONENT:'+rel
# The candidate uses AnyKernel's split/flash flow to preserve the live ramdisk.
# Runtime boot validation and a matching OEM vendor ABI are separate requirements.
shutil.copyfile(im,out/'Image')
shutil.copyfile(build/'.config',out/'build.config')
shutil.copyfile(build/'Module.symvers',out/'Module.symvers')
shutil.copyfile(Path(__file__).with_name('anykernel.sh'),ak/'anykernel.sh')
shutil.copyfile(im,ak/'Image')
archive=out/'VEUX_R62_XXKSU_EXPERIMENTAL_NOFLASH_AK3.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ak.rglob('*')):
  if p.is_file() and '.git' not in p.parts and not p.is_symlink():
   rel=p.relative_to(ak).as_posix()
   if rel.startswith(('tools/','META-INF/')) or rel in ['Image','anykernel.sh']:z.write(p,rel)
proof={'revision':'R62-R3','kernel':'5.4.274','xxksu_version':32668,'xxksu_uapi':5,'susfs':'2.3.0','nomount':'2.2.0','image_header_pass':True,'linked_components_pass':True,'full_kernel_compile_pass':True,'static_boot_img_test_performed':False,'vendor_abi_validated':False,'device_boot_tested':False,'flash_allowed':False,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir() if p.is_file()}}
(out/'BUILD_RESULT.json').write_text(json.dumps(proof,indent=2)+'\n')
(out/'README_NOFLASH.txt').write_text('EXPERIMENTAL. Full compile and ARM64 header checks passed.\nNo boot.img static boot test, OEM vendor ABI approval, or device boot test has been performed.\nThis archive is not a flash approval.\n')
print(json.dumps(proof,indent=2))
