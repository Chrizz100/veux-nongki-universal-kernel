#!/sbin/sh
# VEUX Android 13 kernel candidate; use the existing boot ramdisk and DTB.
properties() { '
kernel.string=VEUX R62 xxKSU 32668 SUSFS 2.3.0 NoMount 2.2
do.devicecheck=1
do.modules=0
do.systemless=1
do.cleanup=1
do.cleanuponabort=0
device.name1=veux
supported.versions=13
supported.patchlevels=
'; }
BLOCK=boot
IS_SLOT_DEVICE=1
RAMDISK_COMPRESSION=auto
PATCH_VBMETA_FLAG=auto
. tools/ak3-core.sh
split_boot
flash_boot
