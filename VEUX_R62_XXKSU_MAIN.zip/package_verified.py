#!/usr/bin/env python3
"""Create AK3 only after matching the same Image to its boot and OEM receipts."""
from pathlib import Path
import hashlib,json,stat,sys,zipfile
ROOT=Path(__file__).resolve().parent
out=Path(sys.argv[1]);sha=lambda b:hashlib.sha256(b).hexdigest()
boot=json.loads((out/'BOOT_STATIC_CHECK.json').read_text())
oem=json.loads((out/'OEM_ABI_CHECK.json').read_text())
assert boot['status']=='STATIC_BOOT_PATH_PASS_DEVICE_UNTESTED'
assert oem['known_loaded_imports_all_match'] is True and oem['known_loaded_imports']==132
image=(out/'Image').read_bytes();assert sha(image)==boot['kernel_sha256']
assert sha((out/'boot.img').read_bytes())==boot['boot_sha256']
entries={p.relative_to(ROOT/'boot/ak3').as_posix():p.read_bytes() for p in (ROOT/'boot/ak3').rglob('*') if p.is_file()}
entries['tools/r12-boot-repack.sh']=(ROOT/'boot/r12-boot-repack.sh').read_bytes()
entries['tools/r12-magiskboot']=(ROOT/'boot/magiskboot-arm64').read_bytes()
script=(ROOT/'boot/anykernel_verified.sh.in').read_text()
for key,value in {'@@IMAGE_SHA@@':sha(image),'@@CORE_SHA@@':sha(entries['tools/ak3-core.sh']),
 '@@REPACK_SHA@@':sha(entries['tools/r12-boot-repack.sh']),
 '@@MAGISK_SHA@@':sha(entries['tools/r12-magiskboot'])}.items():script=script.replace(key,value)
assert '@@' not in script
assert 'do.modules=0' in script and 'do.systemless=0' in script
entries.update({'Image':image,'anykernel.sh':script.encode(),
 'BOOT_STATIC_CHECK.json':(out/'BOOT_STATIC_CHECK.json').read_bytes(),
 'OEM_ABI_CHECK.json':(out/'OEM_ABI_CHECK.json').read_bytes()})
archive=out/'VEUX_R62_R5_5.4.274_AK3_BOOT_TEST.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  assert not name.startswith('/') and '..' not in Path(name).parts and not name.endswith('.ko')
  i=zipfile.ZipInfo(name,date_time=(2026,11,5,0,0,0));i.create_system=3
  mode=0o755 if name=='anykernel.sh' or name.startswith('tools/') or name.endswith('update-binary') else 0o644
  i.external_attr=(stat.S_IFREG|mode)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,data)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and z.read('Image')==image
 for n,b in entries.items():assert z.read(n)==b
report={'revision':'R62-R5','order':['full_kernel_build','known_loaded_132_ABI','boot_v3_repack_and_roundtrip','AK3'],
 'status':'STATIC_BOOT_AND_KNOWN_RMNET_ABI_PASS__DEVICE_UNTESTED',
 'kernel_sha256':sha(image),'boot_sha256':boot['boot_sha256'],
 'ak3_sha256':sha(archive.read_bytes()),'stock_ramdisk_preserved':True,
 'known_loaded_rmnet_imports_matched':132,'full_active_OEM_module_set_verified':False,
 'automatic_device_flash':False,'device_test_candidate':True,'device_boot_tested':False,
 'full_release_approved':False,'flash_allowed':False}
(out/'PACKAGE_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
(out/'README_DEVICE_TEST.txt').write_text('''R62-R5: compiled Image, real 132-import RMNET check, boot-v3/AVB/ramdisk/roundtrip and AK3 pairing passed.
A historical inventory contains conflicting GKI/QGKI cohorts; this is not proof of the entire current active OEM module set.
boot.img was built from the repository's published reference with the documented stock ramdisk.
The AK3 repacks the actual current boot, keeps a persistent backup and verifies partition readback. No automatic reboot.
No root module is disabled or removed. No vendor_boot, dtbo or top-level vbmeta partition is written.
Device boot and full OEM runtime validation are still pending. This is a device-test candidate, not DEVICE PASS.
''')
(out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt'))
print('R62_R5_BOOT_FIRST_AK3_SECOND=PASS; DEVICE_TEST=NOT_PERFORMED')
