#!/usr/bin/env python3
"""Check the real scheduler object, real embedded config and generated ABI CRC."""
from pathlib import Path
import argparse,gzip,hashlib,importlib.util,json,re,subprocess


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('source',type=Path)
    p.add_argument('build',type=Path)
    p.add_argument('report',type=Path)
    a=p.parse_args()
    pins={'kernel/sched/debug.c':'b21b0fe59da27970be0971e0321d46cc43feefbca7b385907415a1e38d01ca7b',
          'kernel/Makefile':'49921ac5eee19f52c1623963951a7ac0fceb8297f4736aff3cad7641672c032f',
          'drivers/soc/qcom/msm_performance.c':'77e393bbd558535f55643826a28e1f66d892ef8af1c97447bd5afa6f31f7a16e'}
    for rel,digest in pins.items():
        if sha(a.source/rel)!=digest:
            raise ValueError('DIAG10_SOURCE_PIN_MISMATCH:'+rel)
    obj=a.build/'kernel/sched/debug.o'
    undefined=subprocess.check_output(['llvm-nm','--undefined-only',str(obj)],text=True)
    defined=subprocess.check_output(['llvm-nm','--defined-only',str(obj)],text=True)
    if re.search(r'\b__PS\b',undefined) or not re.search(r'\bproc_sched_show_task(?:\..*)?$',defined,re.M):
        raise ValueError('SCHEDULER_DEBUG_OBJECT_INVALID')
    if gzip.decompress((a.build/'kernel/config_data.gz').read_bytes())!=(a.build/'.config').read_bytes():
        raise ValueError('KBUILD_EMBEDDED_CONFIG_NOT_ACTUAL')
    perf_object=a.build/'drivers/soc/qcom/msm_performance.o'
    if not perf_object.is_file() or perf_object.stat().st_size<100:
        raise ValueError('REAL_MSM_PERFORMANCE_OBJECT_MISSING')
    helper=Path(__file__).with_name('repo-diag10')/'veux_perf_compat.py'
    spec=importlib.util.spec_from_file_location('r62_perf_proof',helper)
    perf=importlib.util.module_from_spec(spec);spec.loader.exec_module(perf)
    perf.check_config((a.build/'.config').read_bytes())
    perf_command_hash=perf.command_proof((a.build/'drivers/soc/qcom/.msm_performance.o.cmd').read_text())
    versions=(a.build/'kernel/module.o.symversions').read_text()
    match=re.search(r'__crc_module_layout = (0x[0-9a-f]+);',versions)
    if not match or match[1]!='0xbff14f69':
        raise ValueError('KNOWN_MODULE_LAYOUT_CRC_CHANGED')
    result={'revision':'R62-R5','result':'PASS','source_pins':pins,
      'real_ARM64_scheduler_object_sha256':sha(obj),
      'scheduler_undefined___PS':False,'kbuild_gzip_equals_actual_config':True,
      'module_layout_from_real_genksyms':match[1],
      'module_CRC_override_used':False,'device_boot_tested':False,'real_MSM_performance_object_sha256':sha(perf_object),
      'MSM_performance_real_compile_flags_sha256':perf_command_hash}
    a.report.parent.mkdir(parents=True,exist_ok=True)
    a.report.write_text(json.dumps(result,indent=2)+'\n')
    print('R62_R5_DIAG10_SCHEDULER_IKCONFIG_ABI=PASS')


if __name__=='__main__':main()
