#!/usr/bin/env python3
"""Run the repository's unchanged boot-v3 repacker and independent AVB checks."""
from pathlib import Path
import argparse, hashlib, importlib.machinery, importlib.util, json, os, shutil, struct, subprocess

ROOT=Path(__file__).resolve().parent
BOOT_SHA='3836c55cbf28e17d4e7156eaf6a9a1ca2b885a6fbbb621263e8ecb27115eed31'
RAMDISK_SHA='0bc8b54373b5501818e8b252517419786db207771047b6def7ec9bc89beb607a'
PARTITION=134217728


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(args, cwd, log):
    result=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True,timeout=240)
    log.write_text(result.stdout+result.stderr)
    if result.returncode:
        raise RuntimeError('BOOT_COMMAND_FAILED:'+log.name)


def layout(path):
    data=path.read_bytes()
    if len(data)!=PARTITION or data[:8]!=b'ANDROID!' or struct.unpack_from('<I',data,40)[0]!=3 or struct.unpack_from('<I',data,20)[0]!=1580:
        raise ValueError('INVALID_BOOT_V3_CONTAINER')
    kernel_size,ramdisk_size=struct.unpack_from('<II',data,8)
    offset=4096+(kernel_size+4095)//4096*4096
    end=offset+(ramdisk_size+4095)//4096*4096
    if not (kernel_size>64 and ramdisk_size>0 and end<PARTITION-65536):
        raise ValueError('INVALID_BOOT_PAYLOAD_BOUNDS')
    return data,data[4096:4096+kernel_size],data[offset:offset+ramdisk_size],end


def avb_module():
    loader=importlib.machinery.SourceFileLoader('r62_avb',str(ROOT/'boot/avbtool'))
    spec=importlib.util.spec_from_loader(loader.name,loader)
    module=importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


def avb_state(module,path):
    footer,header,descriptors,size=module.Avb()._parse_image(module.ImageHandler(str(path)))
    hashes=[d for d in descriptors if isinstance(d,module.AvbHashDescriptor)]
    props=[d.encode().hex() for d in descriptors if isinstance(d,module.AvbPropertyDescriptor)]
    if not footer or header.algorithm_type!=0 or len(hashes)!=1 or len(descriptors)!=len(props)+1:
        raise ValueError('AVB_PROFILE_CHANGED')
    h=hashes[0]
    if h.partition_name!='boot' or h.hash_algorithm!='sha256' or h.flags!=0:
        raise ValueError('AVB_HASH_PROFILE_CHANGED')
    return {'salt':h.salt.hex(),'props':props,'flags':header.flags,
      'rollback_index':header.rollback_index,'rollback_location':header.rollback_index_location,
      'release_string':header.release_string,'image_size':h.image_size,
      'original_size':footer.original_image_size,'digest':h.digest.hex(),'bytes':size}


def run(original,image,out,work):
    original,image,out,work=map(lambda p:p.resolve(),[original,image,out,work])
    if sha(original)!=BOOT_SHA:
        raise ValueError('REFERENCE_BOOT_HASH_MISMATCH')
    out.mkdir(parents=True,exist_ok=True)
    tools=ROOT/'boot'
    for name in ['magiskboot-x86_64','r12-boot-repack.sh']:
        (tools/name).chmod(0o755)
    target=out/'boot.img'
    command(['bash',tools/'r12-boot-repack.sh','--original',original,'--kernel',image,
      '--output',target,'--magiskboot',tools/'magiskboot-x86_64','--work',work],
      out,out/'boot-repack.log')
    old,old_kernel,old_ramdisk,_=layout(original)
    new,new_kernel,new_ramdisk,end=layout(target)
    if new_kernel!=image.read_bytes() or new_ramdisk!=old_ramdisk or hashlib.sha256(old_ramdisk).hexdigest()!=RAMDISK_SHA:
        raise ValueError('BOOT_KERNEL_OR_RAMDISK_IDENTITY_FAILED')
    if old[:8]+old[12:4096]!=new[:8]+new[12:4096]:
        raise ValueError('BOOT_HEADER_CHANGED_OUTSIDE_KERNEL_SIZE')
    module=avb_module();a,b=avb_state(module,original),avb_state(module,target)
    for key in ['salt','props','flags','rollback_index','rollback_location','release_string','bytes']:
        if a[key]!=b[key]:raise ValueError('AVB_METADATA_CHANGED:'+key)
    if not (b['image_size']==b['original_size']==end and b['digest']==hashlib.sha256(bytes.fromhex(b['salt'])+new[:end]).hexdigest()):
        raise ValueError('INDEPENDENT_AVB_HASH_FAILED')
    command(['python3',tools/'avbtool','verify_image','--image',target],out,out/'avb-verify.log')
    raw=work/'independent-raw';raw.mkdir()
    command([tools/'magiskboot-x86_64','unpack','-n','-h',target],raw,out/'unpack-verify.log')
    if (raw/'kernel').read_bytes()!=new_kernel or (raw/'ramdisk.cpio').read_bytes()!=old_ramdisk:
        raise ValueError('INDEPENDENT_BOOT_EXTRACTION_FAILED')
    roundtrip=work/'roundtrip.img'
    command([tools/'magiskboot-x86_64','repack','-n',target,roundtrip],raw,out/'roundtrip.log')
    if roundtrip.read_bytes()!=new:
        raise ValueError('BOOT_ROUNDTRIP_NOT_BYTE_IDENTICAL')
    if sha(original)!=BOOT_SHA:
        raise ValueError('REFERENCE_BOOT_MODIFIED')
    build_receipt=json.loads((image.parent/'BUILD_RESULT.json').read_text())
    if build_receipt['files']['Image']!=sha(image):
        raise ValueError('BUILD_RECEIPT_IMAGE_MISMATCH')
    report={'validation_tool_revision':'R62-R4','kernel_build_revision':build_receipt['revision'],'status':'STATIC_BOOT_PATH_PASS_DEVICE_UNTESTED',
      'boot_header':3,'partition_bytes':len(new),'kernel_sha256':sha(image),
      'boot_sha256':sha(target),'reference_boot_sha256':BOOT_SHA,
      'reference_is_published_custom_boot_not_pristine_stock':True,
      'stock_ramdisk_sha256':RAMDISK_SHA,'stock_ramdisk_unchanged':True,
      'header_changes':['kernel_size'],'avb_metadata_preserved':True,
      'independent_salted_hash_pass':True,'aosp_avbtool_verify_pass':True,
      'independent_extraction_pass':True,'magiskboot_roundtrip_byte_identical':True,
      'device_boot_tested':False,'flash_allowed':False}
    (out/'BOOT_STATIC_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
    print('R62_STATIC_BOOT_PATH=PASS; RAMDISK_AND_AVB=PASS; DEVICE_TEST=NO')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference',type=Path)
    parser.add_argument('image',type=Path)
    parser.add_argument('out',type=Path)
    parser.add_argument('work',type=Path)
    args=parser.parse_args()
    run(args.reference,args.image,args.out,args.work)


if __name__=='__main__':main()
