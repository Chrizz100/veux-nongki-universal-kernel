#!/usr/bin/env python3
"""Link actual ARM64 objects and reject missing xxKSU/SUSFS providers."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import tempfile

OBJECTS = [
    'drivers/kernelsu/ksu.o', 'fs/susfs.o', 'fs/nomount/nomount.o',
    'security/security.o', 'security/selinux/ss/services.o',
    'security/selinux/selinuxfs.o', 'security/selinux/hooks.o',
    'security/selinux/ss/status.o', 'security/selinux/avc.o',
    'fs/open.o', 'fs/stat.o', 'fs/statfs.o', 'kernel/sys.o',
    'fs/notify/fdinfo.o', 'fs/proc/fd.o', 'fs/super.o',
    'fs/exec.o', 'fs/namespace.o', 'fs/namei.o', 'fs/read_write.o',
    'fs/proc/base.o', 'fs/proc/task_mmu.o', 'fs/proc_namespace.o',
    'fs/proc/cmdline.o', 'fs/devpts/inode.o',
    'drivers/input/input.o', 'block/ioprio.o',
]
PREFIXES = ('susfs_', 'xxksu_', 'ksu_', '__ksu_')
REQUIRED = {
    'susfs_security_compute_av_user', 'susfs_security_context_to_sid',
    'susfs_security_context_str_to_sid', 'xxksu_susfs_status_page',
    'susfs_sus_kstat_spoof_generic_fillattr',
    'susfs_sus_kstat_spoof_vfs_statfs',
    'susfs_sus_kstat_spoof_inotify_fdinfo',
    'susfs_sus_kstat_spoof_proc_fd_seq_show',
    'statfs_by_dentry_wrapper', 'calculate_f_flags_wrapper',
}


def symbols(path, flag):
    output = subprocess.check_output(['llvm-nm', flag, str(path)], text=True)
    return {line.split()[-1] for line in output.splitlines() if line.split()}


def check_inputs(paths):
    references, definitions = set(), set()
    for path in paths:
        references |= symbols(path, '--undefined-only')
        definitions |= symbols(path, '--defined-only')
    missing = {s for s in references - definitions if s.startswith(PREFIXES)}
    missing |= REQUIRED - definitions
    if missing:
        raise RuntimeError('NATIVE_PROVIDER_MISSING:' + ','.join(sorted(missing)))
    return references, definitions


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('build', type=Path)
    parser.add_argument('report', type=Path)
    parser.add_argument('--negative-test', action='store_true')
    args = parser.parse_args()
    paths = [args.build / name for name in OBJECTS]
    if args.negative_test:
        try:
            check_inputs([p for p in paths if p != args.build / 'security/selinux/ss/services.o'])
        except RuntimeError as error:
            if not str(error).startswith('NATIVE_PROVIDER_MISSING:'):
                raise
        else:
            raise RuntimeError('MISSING_SELINUX_PROVIDER_ACCEPTED')
    references, _ = check_inputs(paths)
    with tempfile.TemporaryDirectory(prefix='r62-r3-native-link-') as directory:
        linked = Path(directory) / 'native54.o'
        subprocess.run(['ld.lld', '-r', '-o', str(linked), *map(str, paths)], check=True)
        unresolved = {s for s in symbols(linked, '--undefined-only') if s.startswith(PREFIXES)}
        if unresolved:
            raise RuntimeError('NATIVE_LINK_UNRESOLVED:' + ','.join(sorted(unresolved)))
        report = {
            'schema': 'VEUX_R62_R4_NATIVE54_LTO_LINK_V1',
            'result': 'PASS',
            'object_count': len(paths),
            'resolved_integration_symbols': sorted(s for s in references if s.startswith(PREFIXES)),
            'required_providers': sorted(REQUIRED),
            'objects': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in zip(OBJECTS, paths)},
            'relocatable_link_sha256': hashlib.sha256(linked.read_bytes()).hexdigest(),
            'missing_selinux_provider_negative_test_pass': args.negative_test,
            'full_vmlinux_link_tested': False,
            'device_boot_tested': False,
            'flash_allowed': False,
        }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + '\n')
    print('R62_R4_NATIVE54_LTO_LINK=PASS; objects=' + str(len(paths)))


if __name__ == '__main__':
    main()
