#!/usr/bin/env python3
"""Fail before the long build if the native SUSFS statfs bridge cannot link."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import tempfile


SYMBOLS = {"statfs_by_dentry_wrapper", "calculate_f_flags_wrapper"}


def nm_symbols(path, option):
    output = subprocess.check_output(
        ["llvm-nm", option, str(path)], text=True
    )
    return {line.split()[-1] for line in output.splitlines() if line.split()}


def verify(consumer, provider):
    references = nm_symbols(consumer, "--undefined-only")
    definitions = nm_symbols(provider, "--defined-only")
    if not SYMBOLS.issubset(references):
        raise RuntimeError("EXPECTED_SUSFS_STATFS_CALLERS_MISSING")
    missing = SYMBOLS - definitions
    if missing:
        raise RuntimeError("STATFS_PROVIDER_MISSING:" + ",".join(sorted(missing)))
    with tempfile.TemporaryDirectory(prefix="r62-statfs-link-") as directory:
        linked = Path(directory) / "susfs_statfs.o"
        subprocess.run(
            ["ld.lld", "-r", "-o", str(linked), str(consumer), str(provider)],
            check=True,
        )
        unresolved = SYMBOLS & nm_symbols(linked, "--undefined-only")
        if unresolved:
            raise RuntimeError("STATFS_LINK_UNRESOLVED:" + ",".join(sorted(unresolved)))
        return {
            "schema": "VEUX_R62_R2_STATFS_LTO_LINK_V1",
            "result": "PASS",
            "symbols_resolved": sorted(SYMBOLS),
            "consumer_sha256": hashlib.sha256(consumer.read_bytes()).hexdigest(),
            "provider_sha256": hashlib.sha256(provider.read_bytes()).hexdigest(),
            "relocatable_link_sha256": hashlib.sha256(linked.read_bytes()).hexdigest(),
            "full_vmlinux_link_tested": False,
            "device_boot_tested": False,
            "flash_allowed": False,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("build", type=Path)
    parser.add_argument("report", type=Path)
    parser.add_argument("--negative-test", action="store_true")
    args = parser.parse_args()
    consumer = args.build / "fs/susfs.o"
    provider = args.build / "fs/statfs.o"
    if args.negative_test:
        # A provider omitted from the link must be rejected, as in the failed CI.
        try:
            verify(consumer, consumer)
        except RuntimeError as error:
            if not str(error).startswith("STATFS_PROVIDER_MISSING:"):
                raise
        else:
            raise RuntimeError("MISSING_PROVIDER_WAS_ACCEPTED")
    report = verify(consumer, provider)
    report["missing_provider_negative_test_pass"] = args.negative_test
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
