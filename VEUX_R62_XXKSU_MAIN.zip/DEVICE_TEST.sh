#!/system/bin/sh
# Read-only device evidence. Does not load/unload or change any root module.
set -eu
stage=${1:-before}
case "$stage" in before|after) ;; *) echo 'Use: sh DEVICE_TEST.sh before|after' >&2; exit 2;; esac
[ "$(id -u)" = 0 ] || { echo 'Run this collector with su.' >&2; exit 2; }
[ "$(getprop ro.product.device)" = veux ] || { echo 'Device is not veux.' >&2; exit 2; }
base=/sdcard/Download/VEUX_R62_R5_DEVICE_$(date +%Y%m%d_%H%M%S)_$stage
mkdir -p "$base/modules"
{
 echo "stage=$stage"
 echo "kernel=$(uname -r)"
 echo "device=$(getprop ro.product.device)"
 echo "android=$(getprop ro.build.version.release)"
 echo "rom=$(getprop ro.build.version.incremental)"
 echo "slot=$(getprop ro.boot.slot_suffix)"
 echo "boot_completed=$(getprop sys.boot_completed)"
 echo "selinux=$(getenforce)"
} > "$base/STATUS.txt"
cat /proc/version > "$base/proc_version.txt"
cat /proc/modules > "$base/proc_modules.txt"
if [ -r /proc/config.gz ]; then cp /proc/config.gz "$base/config.gz"; fi
# Preserve the actual files corresponding to loaded vendor module names.
# The archived historical GKI/QGKI lists are not assumed to be the active set.
while read -r name _rest; do
 [ -n "$name" ] || continue
 for dir in /vendor/lib/modules /vendor_dlkm/lib/modules /system/lib/modules /odm/lib/modules; do
  [ -d "$dir" ] || continue
  find "$dir" -type f -name "$name.ko" 2>/dev/null | while IFS= read -r file; do
   path=$(printf '%s' "$file" | tr '/' '_')
   cp "$file" "$base/modules/$path"
   sha256sum "$file" >> "$base/LOADED_MODULE_FILES_SHA256.txt"
  done
 done
done < /proc/modules
(dmesg | grep -iE 'avc:|selinux|kernelsu|susfs|nomount|unknown symbol|disagrees about version|cfi failure|kernel panic|BUG:|Oops:' | tail -n 400) > "$base/KERNEL_RELEVANT.log" 2>/dev/null || true
{
 echo 'Confirm in the matching KaSU Manager: driver 32668, UAPI 5.'
 echo 'Confirm SUSFS version 2.3.0 and required functions after boot.'
 echo 'Record display/touch, Wi-Fi/mobile data, USB/MTP and charging behavior.'
 echo 'This collector alone never grants DEVICE PASS.'
} > "$base/DEVICE_CHECKLIST.txt"
tar -czf "$base.tar.gz" -C "${base%/*}" "${base##*/}"
echo "Saved device evidence: $base.tar.gz"
