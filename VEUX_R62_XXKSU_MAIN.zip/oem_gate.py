#!/usr/bin/env python3
"""Validate the native configuration and real OEM imports without changing CRCs."""
from pathlib import Path
import argparse, csv, gzip, hashlib, importlib.util, json, struct

ROOT = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def config(path):
    values = {}
    for line in path.read_text().splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            key, value = line[2:-11], 'n'
        else:
            continue
        if key in values:
            raise ValueError('DUPLICATE_CONFIG:' + key)
        values[key] = value
    return values


def check_config(path):
    before, after = config(ROOT/'oem/R13_BUILD.config'), config(path)
    diff = {k: [before.get(k, 'n'), after.get(k, 'n')]
            for k in before.keys() | after.keys()
            if before.get(k, 'n') != after.get(k, 'n')}
    invalid = {k: v for k, v in diff.items() if not k.startswith('CONFIG_KSU')}
    if invalid:
        raise ValueError('NATIVE_CONFIG_PARITY_FAILED:' + json.dumps(invalid, sort_keys=True))
    for key in ['KSU','KSU_SUSFS','KSU_SUSFS_PRIORITY_UID_FILTER','NOMOUNT',
                'SCHED_CASS','SECURITY_SELINUX','MODVERSIONS','CFI_CLANG',
                'STACKPROTECTOR_STRONG','AUDIT']:
        if after.get('CONFIG_'+key) != 'y':
            raise ValueError('REQUIRED_CONFIG_MISSING:' + key)
    return {'result': 'PASS', 'non_KSU_differences': invalid,
            'intentional_KSU_differences': diff}


def run(build, out):
    parity = check_config(build/'.config')
    image=(build/'arch/arm64/boot/Image').read_bytes()
    start=image.index(b'IKCFG_ST')+8; end=image.index(b'IKCFG_ED',start)
    if gzip.decompress(image[start:end])!=(build/'.config').read_bytes():
        raise ValueError('ABI_IMAGE_CONFIG_IDENTITY_FAILED')
    dtb=build/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb'
    if hashlib.sha256(dtb.read_bytes()).hexdigest()!='42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37':
        raise ValueError('PROVEN_VEUX_DTB_CHANGED')
    historical = load('r62_historical', ROOT/'tools/historical_vendor_abi.py')
    binary = load('r62_binary', ROOT/'tools/vendor_modcrc.py')
    reference = historical.run(ROOT/'oem/R21_VENDOR_IMPORTS.csv',
        ROOT/'oem/R13_Module.symvers', build/'Module.symvers',
        ROOT/'oem/R13_BUILD.config', build/'.config')
    modules = {p.name: p.read_bytes() for p in (ROOT/'oem').glob('*.ko')}
    if set(modules) != {'rmnet_shs.ko', 'rmnet_offload.ko'}:
        raise ValueError('KNOWN_LOADED_MODULE_INPUTS_CHANGED')
    for data in modules.values():
        if data[:6] != b'\x7fELF\x02\x01' or struct.unpack_from('<H', data, 18)[0] != 183:
            raise ValueError('KNOWN_MODULE_NOT_ARM64_ELF')
    actual = binary.audit((build/'Module.symvers').read_bytes(), modules)
    passed = all(m['status'] == 'MATCH_FOR_SHARED_SYMBOLS' and not m['absent_symbols']
                 for m in actual['modules'].values())
    imports = sum(m.get('matching_symbols',0)+len(m.get('mismatches',[]))+
                  len(m.get('absent_symbols',[])) for m in actual['modules'].values())
    if imports != 132:
        raise ValueError('KNOWN_LOADED_IMPORT_COUNT_CHANGED')
    table = historical.parse_imports(ROOT/'oem/R21_VENDOR_IMPORTS.csv')
    cohorts = {}
    for row in table:
        cohorts.setdefault(row['symbol'], set()).add(row['crc'])
    conflicts = {k: sorted(v) for k,v in cohorts.items() if len(v)>1}
    out.mkdir(parents=True, exist_ok=True)
    (out/'HISTORICAL_VENDOR_ABI.json').write_text(json.dumps(reference,indent=2)+'\n')
    (out/'KNOWN_LOADED_RMNET_ABI.json').write_text(json.dumps(actual,indent=2)+'\n')
    report = {'revision':'R62-R5',
      'status':'KNOWN_LOADED_132_IMPORTS_PASS' if passed else 'KNOWN_LOADED_MODULE_ABI_BLOCKED',
      'native_config_parity':parity, 'known_loaded_imports':imports,
      'known_loaded_imports_all_match':passed,
      'historical_vendor_files':reference['original_vendor_file_count'],
      'historical_imports':reference['original_vendor_import_count'],
      'historical_candidate_counts':reference['candidate']['totals'],
      'historical_conflicting_symbol_names':len(conflicts),
      'all_historical_cohorts_can_match_one_crc_table':not conflicts,
      'historical_inventory_is_not_current_active_module_proof':True,
      'full_active_OEM_module_set_verified':False,
      'kernel_module_layout_crc':actual['module_layout_kernel_crc'],
      'device_boot_tested':False,'flash_allowed':False}
    (out/'OEM_ABI_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
    print('OEM_GATE='+report['status']+'; known imports='+str(imports))
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['config','abi'])
    parser.add_argument('build',type=Path)
    parser.add_argument('out',type=Path)
    args=parser.parse_args()
    if args.mode=='config':
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(json.dumps(check_config(args.build/'.config'),indent=2)+'\n')
        print('R62_R5_NATIVE_CONFIG_PARITY=PASS')
    else:
        report=run(args.build,args.out)
        if not report['known_loaded_imports_all_match']:
            raise SystemExit(3)


if __name__=='__main__':
    main()
