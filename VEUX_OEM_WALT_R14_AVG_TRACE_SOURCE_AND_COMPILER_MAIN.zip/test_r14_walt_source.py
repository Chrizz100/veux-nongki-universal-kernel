import hashlib,json,pathlib,re,subprocess,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import r14_walt_source_bridge as gate

ROOT=pathlib.Path(__file__).parent
FIX=ROOT/'fixtures'

def original():
 return {p:(FIX/('R11_sched.h' if p.endswith('sched.h') else 'R11_fair.c')).read_text() for p in gate.R11_PINS}

def good_results():
 return json.loads((FIX/'R11_SOURCE_GATE.json').read_text()),json.loads((FIX/'R13_SUBSYSTEM_RESULT.json').read_text())

class RealOriginalTests(unittest.TestCase):
 def setUp(self):self.src=original()
 def test_01_proven_pins(self):self.assertEqual({p:gate.sha(v) for p,v in self.src.items()},gate.R11_PINS)
 def test_02_two_paths_only(self):self.assertEqual(set(gate.TRANSFORMS),set(gate.R11_PINS))
 def test_03_compiler_report_r13_original(self):self.assertTrue(gate.validate_gates(*good_results()))
 def test_04_reject_wrong_r11_status(self):
  r,s=good_results();r['status']='TEST';self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_05_reject_wrong_r11_hash(self):
  r,s=good_results();r['after_sha256']['kernel/sched/sched.h']='0'*64;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_06_reject_wrong_r13_status(self):
  r,s=good_results();s['status']='TEST';self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_07_reject_wrong_r13_count(self):
  r,s=good_results();s['object_success_count']=6;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_08_reject_false_abi(self):
  r,s=good_results();s['vendor_abi_proven']=True;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_09_reject_false_flash(self):
  r,s=good_results();s['flash_allowed']=True;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_10_reject_other_success(self):
  r,s=good_results();s['objects']['kernel/sched/walt/core_ctl.o']['compiled']=True;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_11_reject_walt_not_enabled(self):
  r,s=good_results();s['walt_enabled']=False;self.assertRaises(gate.GateError,gate.validate_gates,r,s)
 def test_12_reject_modified_sched(self):
  x=self.src.copy();x['kernel/sched/sched.h']+='\n';self.assertRaises(gate.GateError,gate.transform,x)
 def test_13_reject_modified_fair(self):
  x=self.src.copy();x['kernel/sched/fair.c']+='\n';self.assertRaises(gate.GateError,gate.transform,x)
 def test_14_reject_extra_path(self):
  x=self.src.copy();x['kernel/sysctl.c']='';self.assertRaises(gate.GateError,gate.transform,x)
 def test_15_both_paths_modified(self):
  x=gate.transform(self.src);self.assertEqual(len(x),2)
  for p in x:self.assertNotEqual(x[p],self.src[p])
 def test_16_expected_header_hash(self):
  x=gate.transform(self.src);self.assertEqual(gate.sha(x['kernel/sched/sched.h']),'fe9743bb8d6f7e5be6b2a8df563924c59e6c7a84739181bb91d39047cd2673c6')
 def test_17_expected_fair_hash(self):
  x=gate.transform(self.src);self.assertEqual(gate.sha(x['kernel/sched/fair.c']),'1768030ba2723f01568ec2aceb7b9dec044d25b16eea83181c42f79ccae37179')
 def test_18_oem_avg_struct_exact(self):
  h=gate.transform(self.src)['kernel/sched/sched.h'];self.assertIn('struct sched_avg_stats {\n\tint nr;\n\tint nr_misfit;\n\tint nr_max;\n\tint nr_scaled;\n};',h)
 def test_19_oem_avg_prototype(self):
  h=gate.transform(self.src)['kernel/sched/sched.h'];self.assertIn('extern void sched_get_nr_running_avg(struct sched_avg_stats *stats);',h)
 def test_20_oem_walt_demand_value(self):
  h=gate.transform(self.src)['kernel/sched/sched.h'];self.assertIn('rq(cpu)->wrq.walt_stats.cumulative_runnable_avg_scaled',h)
 def test_21_oem_trace_cpu_freq(self):
  h=gate.transform(self.src)['kernel/sched/sched.h'];self.assertIn('mult_frac(cpu_max_possible_freq(cpu), capacity_orig_of(cpu),',h)
 def test_22_oem_no_pelt_fallback(self):
  h=gate.transform(self.src)['kernel/sched/sched.h'];self.assertIn('return min_t(unsigned long, walt_cpu_util, capacity_orig_of(cpu));',h)
 def test_23_fair_pelt_untouched(self):
  x=gate.transform(self.src)['kernel/sched/fair.c'];
  old='static inline unsigned long cpu_util(int cpu)\n{\n\tstruct cfs_rq *cfs_rq;'
  self.assertIn('#ifndef CONFIG_SCHED_WALT\n'+old,x)
 def test_24_reject_duplicate_sched(self):
  s=self.src['kernel/sched/sched.h'];x=gate.transform(self.src)['kernel/sched/sched.h'];self.assertRaises(gate.GateError,gate.transform_sched,x)
 def test_25_reject_double_pelt_guard(self):
  s=gate.transform(self.src)['kernel/sched/fair.c'];self.assertRaises(gate.GateError,gate.transform_fair,s)
 def test_26_two_source_paths_no_other(self):
  out=gate.transform(self.src)
  self.assertEqual(tuple(out),tuple(gate.R11_PINS))
 def test_27_upstream_commit(self):self.assertIn('61397e524093d1ccb94769b5460825e2eaf8871e',gate.UPSTREAM)
 def test_28_no_stub_body(self):
  s=gate.transform(self.src)['kernel/sched/sched.h'];self.assertNotIn('return 0; /* R14',s)
 def test_29_genuine_pelt_guards(self):
  s=gate.transform(self.src)['kernel/sched/fair.c'];self.assertEqual(s.count('#ifndef CONFIG_SCHED_WALT\nstatic inline unsigned long cpu_util(int cpu)'),1)
 def test_30_stage_exact_source(self):
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td);(p/'kernel/sched').mkdir(parents=True)
   for k,v in self.src.items():(p/k).write_text(v)
   r,s=good_results();(p/'r11.json').write_text(json.dumps(r));(p/'r13.json').write_text(json.dumps(s))
   out=gate.stage(p,p/'r11.json',p/'r13.json',p/'out')
   self.assertEqual(out['status'],'R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED')
   self.assertTrue((p/'out/R14_WALT_AVG_TRACE.patch').is_file())
   cp=subprocess.run(['git','-C',str(p),'apply','--reverse','--check',str(p/'out/R14_WALT_AVG_TRACE.patch')],capture_output=True,text=True)
   self.assertEqual(cp.returncode,0,cp.stderr)
 def test_31_stage_reject_wrong_preimage_untouched(self):
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td);(p/'kernel/sched').mkdir(parents=True)
   for k,v in self.src.items():(p/k).write_text(v)
   (p/'kernel/sched/sched.h').write_text(self.src['kernel/sched/sched.h']+'changed')
   r,s=good_results();(p/'r11.json').write_text(json.dumps(r));(p/'r13.json').write_text(json.dumps(s))
   self.assertRaises(gate.GateError,gate.stage,p,p/'r11.json',p/'r13.json',p/'out')
   self.assertFalse((p/'out').exists());self.assertTrue((p/'kernel/sched/sched.h').read_text().endswith('changed'))
 def test_32_nonfake_config(self):
  for x in ('CONFIG_SCHED_WALT 1','CONFIG_MODVERSIONS 0','BReNE','KSU_VERSION','SUSFS'):
   self.assertNotIn(x,gate.transform(self.src)['kernel/sched/sched.h'][len(self.src['kernel/sched/sched.h']):])

if __name__=='__main__':unittest.main()
