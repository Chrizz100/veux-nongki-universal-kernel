#!/usr/bin/env python3
"""R14: backport genuine Xiaomi WALT scheduler AVG + trace helpers to exact R11 source.

Strictly pins the two preimages from successful R11 run and authenticated R13
original compiler result. No changes to running kernel, BReNE, BakaSU, SUSFS,
NoMount; no image, vmlinux, or ABI claim.
"""
import argparse
import difflib
import hashlib
import json
import pathlib
import re
import sys

R11_PINS = {
 'kernel/sched/sched.h': '2a61b4d52c2630a0851ee379650634dfa96b004db592820ba1e9bc6ad4d0bbfd',
 'kernel/sched/fair.c': 'f594f7286e068a7009a06e2cb8ae7ac6b10b95a8901580e79a67481a477a8ad3',
}
R11_STATUS = 'R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED'
R13_STATUS = 'R13_COMPONENT_COMPILER_ERRORS_RECORDED'
R13_SUCCESSES = ('kernel/sched/walt/boost.o','kernel/sched/walt/cpu-boost.o')
UPSTREAM='MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'

class GateError(Exception): pass

def need(cond,reason):
 if not cond:raise GateError(reason)

def sha(data):return hashlib.sha256(data if isinstance(data,bytes) else data.encode()).hexdigest()

def exact_replace(data,old,new,tag):
 need(data.count(old)==1,f'{tag}:EXPECTED_ONE_ANCHOR_GOT_{data.count(old)}')
 return data.replace(old,new,1)

def transform_sched(src):
 need('struct sched_avg_stats {' not in src,'AVG_TYPE_ALREADY_EXISTS')
 need(re.search(r'\bcpu_util\s*\(\s*int cpu\s*\)\s*\{',src) is None,'CPU_UTIL_BODY_ALREADY_EXISTS')
 need('static inline unsigned int cpu_max_freq(int cpu)' not in src,'CPU_MAX_FREQ_ALREADY_EXISTS')
 # OEM WALT field-based utilization, not a silent PELT substitution. The
 # WALT=y-only helper exactly follows MiCode's active WALT branch.
 anchor=('static inline unsigned long capacity_orig_of(int cpu)\n'
         '{\n\treturn cpu_rq(cpu)->cpu_capacity_orig;\n}\n')
 add=('''#ifdef CONFIG_SCHED_WALT
/* Xiaomi WALT runnable demand; used by WALT sched_avg and fair.c. */
static inline unsigned long cpu_util(int cpu)
{
	u64 walt_cpu_util =
		cpu_rq(cpu)->wrq.walt_stats.cumulative_runnable_avg_scaled;

	return min_t(unsigned long, walt_cpu_util, capacity_orig_of(cpu));
}
#endif
''')
 src=exact_replace(src,anchor,anchor+add,'OEM_CPU_UTIL_ANCHOR')
 freq=('static inline unsigned int cpu_max_possible_freq(int cpu)\n'
       '{\n    return cpu_rq(cpu)->wrq.cluster->max_possible_freq;\n}\n')
 freqextra=('''/* Original Xiaomi WALT max CPU frequency from capacity scaling. */
static inline unsigned int cpu_max_freq(int cpu)
{
	return mult_frac(cpu_max_possible_freq(cpu), capacity_orig_of(cpu),
			 arch_scale_cpu_capacity(cpu));
}
''')
 src=exact_replace(src,freq,freq+freqextra,'OEM_CPU_MAX_FREQ_ANCHOR')
 footer='''
/* Genuine Xiaomi scheduler-running average ABI, including misfit count. */
struct sched_avg_stats {
	int nr;
	int nr_misfit;
	int nr_max;
	int nr_scaled;
};
extern void sched_get_nr_running_avg(struct sched_avg_stats *stats);
'''
 need(src.endswith('\n'),'SCHED_HEADER_NOT_NEWLINE_TERMINATED')
 return src+footer

def transform_fair(src):
 # Keep original PELT implementation fully intact if WALT is disabled.
 body=('static inline unsigned long cpu_util(int cpu)\n'
       '{\n\tstruct cfs_rq *cfs_rq;\n\tunsigned int util;\n\n'
       '\tcfs_rq = &cpu_rq(cpu)->cfs;\n'
       '\tutil = READ_ONCE(cfs_rq->avg.util_avg);\n\n'
       '\tif (sched_feat(UTIL_EST))\n'
       '\t\tutil = max(util, READ_ONCE(cfs_rq->avg.util_est.enqueued));\n\n'
       '\treturn min_t(unsigned long, util, capacity_orig_of(cpu));\n}\n')
 need('#ifndef CONFIG_SCHED_WALT\n'+body not in src,'FAIR_GUARD_ALREADY_APPLIED')
 return exact_replace(src,body,'#ifndef CONFIG_SCHED_WALT\n'+body+'#endif\n','OEM_FAIR_PELT_GUARD')

TRANSFORMS={'kernel/sched/sched.h':transform_sched,'kernel/sched/fair.c':transform_fair}

def validate_gates(r11,r13):
 need(r11.get('status')==R11_STATUS,'R11_STATUS_DRIFT')
 need(all(r11.get('after_sha256',{}).get(k)==h for k,h in R11_PINS.items()),'R11_SOURCE_PIN_DRIFT')
 need(r13.get('status')==R13_STATUS and r13.get('object_success_count')==2,'R13_RESULT_DRIFT')
 need(r13.get('source_r12_verified') is True and r13.get('walt_enabled') is True,'R13_WALT_NOT_PROVEN')
 need(tuple(sorted(k for k,v in r13.get('objects',{}).items() if v.get('compiled'))) == tuple(sorted(R13_SUCCESSES)), 'R13_SUCCESS_OBJECT_NAMES_DRIFT')
 for item in ('vendor_abi_proven','flash_allowed','brene_changed','kernel_image_built','vmlinux_linked','module_symvers_verified'):
  need(r13.get(item) is False,'R13_UNSAFE_ASSERTION:'+item)
 return True

def transform(srcs):
 need(set(srcs)==set(R11_PINS),'UNEXPECTED_SOURCE_PATHS')
 for p,h in R11_PINS.items():need(sha(srcs[p])==h,'SOURCE_PREIMAGE_SHA_DRIFT:'+p)
 return {p:TRANSFORMS[p](srcs[p]) for p in R11_PINS}

def stage(snapshot,r11_file,r13_file,output):
 need(snapshot.is_dir() and not snapshot.is_symlink(),'SNAPSHOT_BAD')
 for p in (r11_file,r13_file):need(p.is_file() and not p.is_symlink(),'GATE_FILE_MISSING:'+str(p))
 need(not output.exists() and not output.is_symlink(),'OUTPUT_EXISTS')
 r11=json.loads(r11_file.read_text());r13=json.loads(r13_file.read_text())
 validate_gates(r11,r13)
 sources={}
 for rel in R11_PINS:
  p=snapshot/rel
  need(p.is_file() and not p.is_symlink(),'UNSAFE_SOURCE:'+rel)
  sources[rel]=p.read_text()
 changed=transform(sources)
 patches=[]
 for rel in R11_PINS:
  patches.extend(difflib.unified_diff(sources[rel].splitlines(keepends=True),changed[rel].splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel))
 patch=''.join(patches)
 need(patch.startswith('--- a/kernel/sched/sched.h') and '--- a/kernel/sched/fair.c' in patch,'INVALID_PATCH_CONTENT')
 import subprocess
 chk=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=patch,text=True,capture_output=True)
 need(chk.returncode==0,'GIT_APPLY_CHECK_FAILED:'+chk.stderr[:500])
 # No staging mutation before all validation completed.
 for rel in R11_PINS:(snapshot/rel).write_text(changed[rel])
 post={p:sha(changed[p]) for p in R11_PINS}
 for rel in R11_PINS:need(sha((snapshot/rel).read_bytes())==post[rel],'POSTIMAGE_MISMATCH:'+rel)
 output.mkdir(parents=True)
 (output/'R14_WALT_AVG_TRACE.patch').write_text(patch)
 result={
 'status':'R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED',
 'before_sha256':dict(R11_PINS),'after_sha256':post,'modified_files':list(R11_PINS),
 'patch_sha256':sha(patch),'source_r11_verified':True,'source_r13_verified':True,
 'upstream_ref':UPSTREAM,'kernel_version':'5.4.274','kernel_image_built':False,
 'vmlinux_linked':False,'vendor_abi_proven':False,'flash_allowed':False,
 'brene_changed':False,'bakasusu_nomount_changed':False,'kernel_objects_compiled':False}
 (output/'R14_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print('R14_OEM_AVG_TRACE_SOURCE_STAGED=PASS; FILES=2; COMPILE=PENDING; ABI=NO; FLASH=NO')
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--snapshot',type=pathlib.Path,required=True);p.add_argument('--r11-gate',type=pathlib.Path,required=True);p.add_argument('--r13-result',type=pathlib.Path,required=True);p.add_argument('--output',type=pathlib.Path,required=True)
 a=p.parse_args()
 try:stage(a.snapshot,a.r11_gate,a.r13_result,a.output)
 except (GateError,ValueError,KeyError, OSError) as e:print('R14_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr);sys.exit(2)

if __name__=='__main__':main()
