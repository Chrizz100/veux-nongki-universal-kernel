import json,pathlib,sys,tempfile,unittest,types
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import r14_walt_recompile as c
ROOT=pathlib.Path(__file__).parent

class RecompileTests(unittest.TestCase):
 def setUp(self):
  self.good={k:{'compiled':True,'exit_code':0} for k in c.TARGETS}
 def test_01_exact_targets_10(self):self.assertEqual(len(c.TARGETS),10)
 def test_02_baseline_4(self):self.assertEqual(len(c.BASE),4)
 def test_03_remaining_6(self):self.assertEqual(len(c.OTHER),6)
 def test_04_targets_unique(self):self.assertEqual(len(set(c.TARGETS)),10)
 def test_05_good_case(self):self.assertEqual(c.classify(self.good),('R14_TEN_REAL_OBJECTS_COMPILED_NO_LINK',10,4,6))
 def test_06_subsystem_one_error(self):
  self.good[c.OTHER[0]]['compiled']=False
  self.assertEqual(c.classify(self.good),('R14_WALT_SUBSYSTEM_COMPILER_ERRORS_RECORDED',9,4,5))
 def test_07_baseline_regression(self):
  self.good[c.BASE[2]]['compiled']=False
  self.assertEqual(c.classify(self.good),('R14_BASELINE_COMPILER_REGRESSION_RECORDED',9,3,6))
 def test_08_no_invented_target(self):
  self.good['arch/arm64/boot/Image']={'compiled':True}
  self.assertRaises(c.GateError,c.classify,self.good)
 def test_09_no_missing_target(self):
  self.good.pop(c.TARGETS[4]);self.assertRaises(c.GateError,c.classify,self.good)
 def test_10_no_actual_compiler_claim_before_run(self):
  self.assertEqual(c.R14_STATUS,'R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED')
 def test_11_expected_pins_both(self):self.assertEqual(len(c.EXPECTED_SOURCE),2)
 def test_12_r9_driver_sha_valid(self):self.assertEqual(len(c.DRIVER_SHA),64)
 def test_13_r12_verified_status(self):self.assertIn('FOUR_REAL',c.R12_STATUS)
 def test_14_r13_proven_count(self):self.assertIn('ERRORS',c.R13_STATUS)
 def test_15_probe_fake_success(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);snap=p/'src';obj=p/'out';tool=p/'clang';logs=p/'logs';
   for v in [snap/'kernel/sched/walt',obj/'kernel/sched/walt',tool/'bin',logs]:v.mkdir(parents=True,exist_ok=True)
   t=c.OTHER[0];(snap/'kernel/sched/walt/boost.c').write_text('int boost;')
   env={};arg=types.SimpleNamespace(snapshot=snap,objout=obj,toolchain=tool)
   def run(args,log,limit,env=None):
    target=obj/t;target.write_bytes(b'actual object')
    log.write_text('cc actual object\n')
    return {'exit_code':0,'timed_out':False,'log':str(log),'log_sha256':c.sha(log)}
   mod=types.SimpleNamespace(run_cmd=run,make_argv=lambda *args:['make'])
   r=c.probe_one(t,arg,mod,logs,env);self.assertTrue(r['compiled']);self.assertTrue(r['object_sha256'])
 def test_16_probe_fake_failure(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);snap=p/'src';obj=p/'out';tool=p/'clang';logs=p/'logs';
   for v in [snap/'kernel/sched/walt',obj/'kernel/sched/walt',tool/'bin',logs]:v.mkdir(parents=True,exist_ok=True)
   t=c.OTHER[0];(snap/'kernel/sched/walt/boost.c').write_text('x')
   arg=types.SimpleNamespace(snapshot=snap,objout=obj,toolchain=tool)
   def run(args,log,limit,env=None):log.write_text('compile error');return {'exit_code':2,'timed_out':False,'log':str(log)}
   mod=types.SimpleNamespace(run_cmd=run,make_argv=lambda *args:['make'])
   r=c.probe_one(t,arg,mod,logs,{});self.assertFalse(r['compiled'])
 def test_17_missing_source_no_positive(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/'out/kernel/sched/walt').mkdir(parents=True);(p/'logs').mkdir()
   a=types.SimpleNamespace(objout=p/'out',snapshot=p/'src',toolchain=p/'clang')
   r=c.probe_one(c.OTHER[0],a,None,p/'logs',{})
   self.assertFalse(r['compiled'])
 def test_18_stale_object_is_discarded(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/'out/kernel/sched/walt').mkdir(parents=True);(p/'src/kernel/sched/walt').mkdir(parents=True);(p/'logs').mkdir()
   t=c.OTHER[0];(p/'out'/t).write_text('stale');(p/'src/kernel/sched/walt/boost.c').write_text('x')
   arg=types.SimpleNamespace(objout=p/'out',snapshot=p/'src',toolchain=p/'clang')
   def run(args,log,limit,env=None):log.write_text('make failed');return {'exit_code':2,'timed_out':False}
   mod=types.SimpleNamespace(run_cmd=run,make_argv=lambda *args:['make'])
   r=c.probe_one(t,arg,mod,p/'logs',{});self.assertFalse(r['compiled']);self.assertFalse((p/'out'/t).exists())
 def test_19_symlink_object_blocked(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d);(p/'out/kernel/sched/walt').mkdir(parents=True);(p/'src/kernel/sched/walt').mkdir(parents=True);(p/'logs').mkdir()
   t=c.OTHER[0];(p/'src/kernel/sched/walt/boost.c').write_text('x');(p/'else').write_text('protect')
   (p/'out'/t).symlink_to(p/'else')
   arg=types.SimpleNamespace(objout=p/'out',snapshot=p/'src',toolchain=p/'clang')
   self.assertRaises(c.GateError,c.probe_one,t,arg,None,p/'logs',{})
   self.assertEqual((p/'else').read_text(),'protect')
 def test_20_forbidden_target(self):
  self.assertRaises(c.GateError,c.probe_one,'arch/arm64/boot/Image',None,None,None,{})
 def test_21_original_r13_json(self):
  x=json.loads((ROOT/'fixtures/R13_SUBSYSTEM_RESULT.json').read_text());self.assertEqual(x['object_success_count'],2)
 def test_22_original_r13_real_hash(self):
  x=json.loads((ROOT/'fixtures/R13_SUBSYSTEM_RESULT.json').read_text());self.assertEqual(set(k for k,v in x['objects'].items() if v['compiled']),{'kernel/sched/walt/boost.o','kernel/sched/walt/cpu-boost.o'})
 def test_23_no_brene_mutation(self):
  self.assertNotIn('BReNE',c.TARGETS)
 def test_24_no_flash_target(self):self.assertNotIn('Image',' '.join(c.TARGETS))

if __name__=='__main__':unittest.main()
