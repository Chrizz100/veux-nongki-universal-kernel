#!/usr/bin/env python3
"""R14 genuine ARM64 WALT-ON Kbuild: recompile R12 baseline + R13 six targets.

This is a fail-closed diagnostic, not a vmlinux, module ABI, or boot-image build.
Only object files in the expendable GitHub Actions O= directory are replaced.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

BASE=('kernel/sched/walt/walt.o','kernel/sched/core.o','kernel/sched/fair.o','kernel/sysctl.o')
OTHER=('kernel/sched/walt/boost.o','kernel/sched/walt/sched_avg.o',
       'kernel/sched/walt/qc_vas.o','kernel/sched/walt/core_ctl.o',
       'kernel/sched/walt/trace.o','kernel/sched/walt/cpu-boost.o')
TARGETS=BASE+OTHER
EXPECTED_SOURCE={'kernel/sched/sched.h':'fe9743bb8d6f7e5be6b2a8df563924c59e6c7a84739181bb91d39047cd2673c6',
                 'kernel/sched/fair.c':'1768030ba2723f01568ec2aceb7b9dec044d25b16eea83181c42f79ccae37179'}
DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
R12_STATUS='R12_FOUR_REAL_OBJECTS_AND_SYMBOL_CONTRACT_PROVEN'
R13_STATUS='R13_COMPONENT_COMPILER_ERRORS_RECORDED'
R14_STATUS='R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED'

class GateError(Exception):pass

def need(v,message):
 if not v:raise GateError(message)

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(p):return json.loads(Path(p).read_text())

def approve_inputs(args):
 for p in (args.snapshot,args.objout,args.toolchain,args.r12_report,args.r13_report):
  need(p.is_dir() and not p.is_symlink(),'BAD_DIRECTORY:'+str(p))
 for p in (args.source_gate,args.driver):need(p.is_file() and not p.is_symlink(),'MISSING_INPUT:'+str(p))
 need(args.snapshot.resolve()!=args.project.resolve(),'SNAPSHOT_IS_MAIN_REPOSITORY')
 need(args.objout.resolve()!=args.project.resolve(),'OBJOUT_IS_MAIN_REPOSITORY')
 need(args.objout.resolve()!=args.snapshot.resolve(),'OBJOUT_IS_SNAPSHOT')
 need(not args.output.exists() and not args.output.is_symlink(),'R14_OUTPUT_EXISTS')
 need(sha(args.driver)==DRIVER_SHA,'HISTORICAL_CLANG_DRIVER_DRIFT')
 need((args.toolchain/'bin/clang').is_file() and (args.toolchain/'bin/llvm-nm').is_file(),'TOOLCHAIN_NOT_READY')
 gate=read(args.source_gate)
 need(gate.get('status')==R14_STATUS and gate.get('after_sha256')==EXPECTED_SOURCE,'SOURCE_GATE_NOT_PROVEN')
 need(gate.get('modified_files')==list(EXPECTED_SOURCE),'SOURCE_PATHS_CHANGED')
 need(gate.get('source_r13_verified') is True and gate.get('source_r11_verified') is True,'PREDECESSOR_GATE_INVALID')
 for flag in ('flash_allowed','kernel_image_built','vmlinux_linked','vendor_abi_proven','brene_changed','bakasusu_nomount_changed','kernel_objects_compiled'):
  need(gate.get(flag) is False,'UNSAFE_GATE:'+flag)
 for path,digest in EXPECTED_SOURCE.items():
  f=args.snapshot/path
  need(f.is_file() and not f.is_symlink() and sha(f)==digest,'SOURCE_CHANGED:'+path)
 r12=read(args.r12_report/'R12_COMPILER_RESULT.json')
 need(r12.get('status')==R12_STATUS and r12.get('object_success_count')==4 and r12.get('four_object_compile_proven') is True,'R12_BASE_NOT_PROVEN')
 r13=read(args.r13_report/'R13_SUBSYSTEM_RESULT.json')
 need(r13.get('status')==R13_STATUS and r13.get('object_success_count')==2 and r13.get('walt_enabled') is True,'R13_DIAG_NOT_PROVEN')
 need(r13.get('source_r12_verified') is True,'R13_R12_CHAIN_INVALID')
 config=(args.r12_report/'R9_EFFECTIVE_CONFIG.config').read_text()
 for tok in ('CONFIG_SCHED_WALT=y','CONFIG_PROC_SYSCTL=y','CONFIG_CPU_FREQ=y','CONFIG_QGKI=y'):
  need(re.search(r'(?m)^'+re.escape(tok)+'$',config) is not None,'CONFIG_DRIFT:'+tok)
 return gate,r12,r13

def classify(records):
 need(set(records)==set(TARGETS),'REPORT_TARGET_SCOPE_WRONG')
 passing=sum(x.get('compiled') is True for x in records.values())
 base=sum(records[k].get('compiled') is True for k in BASE)
 others=sum(records[k].get('compiled') is True for k in OTHER)
 if passing==len(TARGETS):s='R14_TEN_REAL_OBJECTS_COMPILED_NO_LINK'
 elif base<4:s='R14_BASELINE_COMPILER_REGRESSION_RECORDED'
 else:s='R14_WALT_SUBSYSTEM_COMPILER_ERRORS_RECORDED'
 return s,passing,base,others

def probe_one(target,args,driver,logdir,env):
 need(target in TARGETS,'UNAUTHORIZED_OBJECT_TARGET')
 path=args.objout/target
 parent=path.parent
 need(parent.is_dir() and not parent.is_symlink(),'OBJOUT_TARGET_DIR_MISSING:'+target)
 cmd=parent/('.'+path.name+'.cmd')
 # Delete *only* stale object and exact corresponding Kbuild .cmd in the
 # disposable O= tree so success cannot come from old unpatched objects.
 for f in (path,cmd):
  need(not f.is_symlink() and (not f.exists() or f.is_file()),'UNSAFE_EXISTING_OBJECT:'+str(f))
  if f.exists():f.unlink()
 log=logdir/(target.replace('/','_')+'.log')
 source=args.snapshot/(target[:-1]+'c')
 if not source.is_file() or source.is_symlink():
  log.write_text('SOURCE_FILE_MISSING:'+str(source)+'\n')
  return {'compiled':False,'exit_code':None,'log':str(log),'log_sha256':sha(log),
          'object_file_present':False,'failure':'SOURCE_FILE_MISSING'}
 result=driver.run_cmd(driver.make_argv(args.snapshot,args.objout,args.toolchain,target,2),log,300,env=env)
 exists=path.is_file() and not path.is_symlink() and path.stat().st_size>0
 good=result.get('exit_code')==0 and result.get('timed_out') is False and exists
 return {**result,'compiled':bool(good),'object_file_present':exists,'object_bytes':path.stat().st_size if exists else 0,
         **({'object_sha256':sha(path)} if exists else {})}

def run(args):
 approve_inputs(args)
 spec=importlib.util.spec_from_file_location('veux_r9_driver',args.driver)
 need(spec is not None and spec.loader is not None,'DRIVER_NOT_LOADABLE')
 drv=importlib.util.module_from_spec(spec);spec.loader.exec_module(drv)
 need(callable(drv.run_cmd) and callable(drv.make_argv),'PINNED_DRIVER_MISSING_APIS')
 args.output.mkdir(parents=True);logs=args.output/'compiler_logs';logs.mkdir()
 result={'status':'R14_STARTED','objects':{},'targets':list(TARGETS),'kernel_version':'5.4.274',
   'baseline_objects_compiled':0,'additional_objects_compiled':0,'object_success_count':0,
   'source_r14_verified':True,'real_arm64_make_attempted':True,'walt_enabled':True,
   'kernel_image_built':False,'vmlinux_linked':False,'vendor_abi_proven':False,
   'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False}
 out=args.output/'R14_COMPILER_RESULT.json';out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
 env=os.environ.copy();env['PATH']=str(args.toolchain/'bin')+os.pathsep+env.get('PATH','')
 for target in TARGETS:
  result['objects'][target]=probe_one(target,args,drv,logs,env)
  out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 status,total,base,more=classify(result['objects'])
 result.update({'status':status,'object_success_count':total,'baseline_objects_compiled':base,'additional_objects_compiled':more})
 out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print(f'R14_REAL_KBUILD={total}/10; BASE={base}/4; ADDITIONAL={more}/6; STATUS={status}; IMAGE=NO; ABI=UNPROVEN; FLASH=NO')
 return result

def main():
 p=argparse.ArgumentParser()
 for name in ('snapshot','objout','toolchain','r12-report','r13-report','source-gate','driver','output','project'):
  p.add_argument('--'+name,type=Path,required=True)
 args=p.parse_args()
 try:run(args)
 except (GateError,ValueError,KeyError,OSError) as e:
  print('R14_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr);sys.exit(2)
if __name__=='__main__':main()
