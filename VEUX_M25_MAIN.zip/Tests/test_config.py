import argparse
import gzip
import importlib.util
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import textwrap
import unittest
import zipfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('m25_tested', ROOT / 'Tools/m25_config.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

def payload(config):
    return b'IKCFG_ST' + gzip.compress(config, mtime=0) + b'IKCFG_ED'

def products(root, config=b'CONFIG_IKCONFIG=y\n# CONFIG_TEST is not set\n', embedded=None):
    out = root / 'candidate-out'
    (out / 'arch/arm64/boot').mkdir(parents=True)
    (out / 'include/generated').mkdir(parents=True)
    (out / 'kernel').mkdir(parents=True)
    image = bytearray(64)
    image[56:60] = b'ARM\x64'
    elf = bytearray(64)
    elf[:6] = b'\x7fELF\x02\x01'
    struct.pack_into('<H', elf, 18, 183)
    data = payload(config if embedded is None else embedded)
    (out / 'arch/arm64/boot/Image').write_bytes(image + data)
    (out / 'vmlinux').write_bytes(elf + data)
    (out / '.config').write_bytes(config)
    (out / 'kernel/config_data.gz').write_bytes(gzip.compress(config, mtime=0))
    (out / 'Module.symvers').write_text('0x12345678\tfixture\tvmlinux\tEXPORT_SYMBOL\n')
    (out / 'include/generated/autoconf.h').write_text('#define CONFIG_IKCONFIG 1\n')
    return out

class ConfigTests(unittest.TestCase):
    def test_actual_kbuild_rule_reproduces_old_bug_and_follows_changed_build_config(self):
        with tempfile.TemporaryDirectory(prefix='m25-make-') as tmp:
            root = Path(tmp)
            source, out = root / 'source', root / 'out'
            (source / 'kernel').mkdir(parents=True)
            (source / 'arch/arm64/configs').mkdir(parents=True)
            (out / 'kernel').mkdir(parents=True)
            shutil.copyfile(ROOT / 'References/kernel.Makefile.before', source / 'kernel/Makefile')
            stock = source / 'arch/arm64/configs/stock_defconfig'
            stock.write_bytes(b'CONFIG_STOCK=y\n')
            cfg = out / '.config'
            cfg.write_bytes(b'CONFIG_BUILD=y\n')
            driver = out / 'driver.mk'
            driver.write_text('obj := kernel\nKCONFIG_CONFIG := .config\n'
                              'VPATH := ' + str(source).replace(' ', '\\ ') + '\n'
                              'if_changed = gzip -n -f -9 -c $< > $@\n'
                              'include ' + str(source / 'kernel/Makefile').replace(' ', '\\ ') + '\n'
                              '.PHONY: FORCE\nFORCE:\n')
            def run():
                r = subprocess.run(['make', '-f', 'driver.mk', 'kernel/config_data.gz'], cwd=out,
                                   capture_output=True, text=True, timeout=10)
                self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
                return gzip.decompress((out / 'kernel/config_data.gz').read_bytes())
            self.assertEqual(run(), stock.read_bytes())
            before_cfg = cfg.read_bytes()
            m.patch_makefile(source)
            self.assertEqual(cfg.read_bytes(), before_cfg)
            self.assertEqual(run(), cfg.read_bytes())
            cfg.write_bytes(b'CONFIG_BUILD_CHANGED=y\n')
            self.assertEqual(run(), cfg.read_bytes())

    def test_preimage_drift_rejected_without_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp)
            (source / 'kernel').mkdir()
            p = source / 'kernel/Makefile'
            data = (ROOT / 'References/kernel.Makefile.before').read_bytes() + b'# drift\n'
            p.write_bytes(data)
            with self.assertRaisesRegex(ValueError, 'PREIMAGE_CHANGED'):
                m.patch_makefile(source)
            self.assertEqual(p.read_bytes(), data)

    def test_already_fixed_preimage_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp)
            (source / 'kernel').mkdir()
            (source / 'kernel/Makefile').write_bytes((ROOT / 'References/kernel.Makefile.before').read_bytes())
            m.patch_makefile(source)
            with self.assertRaisesRegex(ValueError, 'PREIMAGE_CHANGED'):
                m.patch_makefile(source)

    def test_unique_complete_gzip_payload(self):
        cfg = b'CONFIG_IKCONFIG=y\n'
        self.assertEqual(m.extract_config(b'prefix' + payload(cfg) + b'suffix'), cfg)

    def test_duplicate_embedded_payloads_rejected(self):
        with self.assertRaisesRegex(ValueError, 'UNIQUE_COMPLETE'):
            m.extract_config(payload(b'A') + payload(b'A'))

    def test_truncated_or_crc_corrupt_payload_rejected(self):
        data = payload(b'CONFIG_IKCONFIG=y\n')
        broken = bytearray(data)
        broken[-12] ^= 1
        for raw in [data[:-9], bytes(broken), b'IKCFG_STinvalidIKCFG_ED', b'no config']:
            with self.subTest(raw=raw), self.assertRaises(ValueError):
                m.extract_config(raw)

    def test_autoconf_maps_modules_numbers_strings_and_disabled_options(self):
        cfg = b'CONFIG_A=y\nCONFIG_B=m\nCONFIG_C=17\nCONFIG_D="a b"\n# CONFIG_E is not set\n'
        header = '#define CONFIG_A 1\n#define CONFIG_B_MODULE 1\n#define CONFIG_C 17\n#define CONFIG_D "a b"\n'
        self.assertEqual(m.autoconf_check(cfg, header), 4)
        for wrong in [header.replace('17', '18'), header + '#define CONFIG_E 1\n', header.replace('_MODULE', '')]:
            with self.subTest(wrong=wrong), self.assertRaises(ValueError):
                m.autoconf_check(cfg, wrong)

    def test_duplicate_config_and_header_rejected(self):
        with self.assertRaisesRegex(ValueError, 'DUPLICATE_CONFIG'):
            m.config_values(b'CONFIG_A=y\nCONFIG_A=n\n')
        with self.assertRaisesRegex(ValueError, 'DUPLICATE_AUTOCONF'):
            m.autoconf_check(b'CONFIG_A=y\n', '#define CONFIG_A 1\n#define CONFIG_A 1\n')

    def test_matching_fixture_image_elf_and_autoconf_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            products(root)
            self.assertTrue(m.audit_build(root, strict=False)['byte_identical_config_image_vmlinux'])

    def test_old_stock_payload_is_a_hard_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            products(root, embedded=b'CONFIG_STOCK=y\n')
            with self.assertRaisesRegex(ValueError, 'Image_IKCONFIG_DIFFERS'):
                m.audit_build(root, strict=False)

    def test_vmlinux_payload_mismatch_is_a_hard_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out = products(root)
            p = out / 'vmlinux'
            p.write_bytes(p.read_bytes()[:64] + payload(b'CONFIG_STOCK=y\n'))
            with self.assertRaisesRegex(ValueError, 'vmlinux_IKCONFIG_DIFFERS'):
                m.audit_build(root, strict=False)

    def test_stale_intermediate_gzip_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out = products(root)
            (out / 'kernel/config_data.gz').write_bytes(gzip.compress(b'CONFIG_STOCK=y\n', mtime=0))
            with self.assertRaisesRegex(ValueError, 'KBUILD_CONFIG_DATA_DIFFERS'):
                m.audit_build(root, strict=False)

    def test_incorrect_elf_or_image_architecture_rejected(self):
        for name in ['vmlinux', 'arch/arm64/boot/Image']:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp)
                out = products(root)
                p = out / name
                p.write_bytes(b'\0' * 64 + p.read_bytes()[64:])
                with self.assertRaises(ValueError):
                    m.audit_build(root, strict=False)

    def test_config_or_full_symvers_drift_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out = products(root)
            with self.assertRaisesRegex(ValueError, 'R25_BUILD_CONFIG_CHANGED'):
                m.audit_build(root)
            with patch.object(m, 'CONFIG_SHA', m.sha(out / '.config')):
                with self.assertRaisesRegex(ValueError, 'FULL_EXPORT_TABLE_CHANGED'):
                    m.audit_build(root)

    def test_old_green_result_cannot_pass_new_gate(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'M25_RESULT.json'
            p.write_text(json.dumps({'status': 'R25_GREEN', 'kernel_compiled': True}))
            with self.assertRaisesRegex(ValueError, 'FRESH_M25_CONFIG_PASS_REQUIRED'):
                m.verify_fresh(tmp)

    def test_failed_build_writes_failure_and_restores_parent_callback(self):
        with tempfile.TemporaryDirectory() as tmp:
            original = lambda source: None
            parent = argparse.Namespace(apply_source=original)
            def fail(args):
                raise RuntimeError('BUILD_FAILED')
            parent.build = fail
            args = argparse.Namespace(r25_tool='fixture', output=tmp)
            with patch.object(m, 'parent_tool', return_value=parent):
                with self.assertRaisesRegex(RuntimeError, 'BUILD_FAILED'):
                    m.build(args)
            self.assertIs(parent.apply_source, original)
            result = json.loads((Path(tmp) / 'M25_RESULT.json').read_text())
            self.assertFalse(result['kernel_compiled'])
            self.assertFalse(result['flash_allowed'])

    def test_real_callback_patches_candidate_before_compilation_without_touching_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'candidate-source'
            (source / 'kernel').mkdir(parents=True)
            shutil.copyfile(ROOT / 'References/kernel.Makefile.before', source / 'kernel/Makefile')
            cfg = root / '.config'
            cfg.write_bytes(b'CONFIG_IKCONFIG=y\n')
            original = lambda tree: {'previous_R25_source': 'preserved'}
            parent = argparse.Namespace(apply_source=original)
            def fail(args):
                self.assertEqual(parent.apply_source(source), {'previous_R25_source': 'preserved'})
                self.assertIn(m.NEW, (source / 'kernel/Makefile').read_bytes())
                self.assertEqual(cfg.read_bytes(), b'CONFIG_IKCONFIG=y\n')
                raise RuntimeError('TEST_STOPS_BEFORE_KERNEL_COMPILATION')
            parent.build = fail
            with patch.object(m, 'parent_tool', return_value=parent):
                with self.assertRaisesRegex(RuntimeError, 'STOPS_BEFORE'):
                    m.build(argparse.Namespace(r25_tool='fixture', output=tmp))
            self.assertIs(parent.apply_source, original)
            self.assertIn('makefile_patch', json.loads((root / 'M25_RESULT.json').read_text()))

    def test_packaged_boot_and_ak3_must_contain_exact_audited_image(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            out = products(root)
            image = (out / 'arch/arm64/boot/Image').read_bytes()
            review = root / 'package/review'
            review.mkdir(parents=True)
            boot = bytearray(4096)
            boot[:8] = b'ANDROID!'
            struct.pack_into('<I', boot, 8, len(image))
            struct.pack_into('<I', boot, 40, 3)
            (review / 'fixture_boot.img').write_bytes(boot + image)
            archive = review / 'fixture_AK3.zip'
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('Image', image)
            self.assertEqual(len(m.audit_pair(root, root / 'package')), 2)
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('Image', image + b'changed')
            with self.assertRaisesRegex(ValueError, 'AK3_KERNEL_DIFFERS'):
                m.audit_pair(root, root / 'package')

    def test_failed_package_is_reported_and_quarantined(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out / 'review').mkdir()
            (out / 'review/unverified_boot.img').write_bytes(b'fixture')
            parent = argparse.Namespace(package=lambda args: None)
            with patch.object(m, 'verify_fresh'), patch.object(m, 'parent_tool', return_value=parent):
                with patch.object(m, 'audit_pair', side_effect=ValueError('BAD_PAIR')):
                    with self.assertRaisesRegex(ValueError, 'BAD_PAIR'):
                        m.package(argparse.Namespace(build='fixture', output=tmp, r25_tool='fixture'))
            self.assertFalse((out / 'review').exists())
            self.assertTrue((out / 'unverified-review/unverified_boot.img').is_file())
            self.assertFalse(json.loads((out / 'M25_PACKAGE_RESULT.json').read_text())['static_boot_path_pass'])

    def test_genuine_original_artifact_rejected_without_modification(self):
        value = os.environ.get('M25_ORIGINAL_BUILD')
        if not value:
            self.skipTest('Original 344 MB artifact used in independent local verification')
        root = Path(value)
        names = ['.config', 'vmlinux', 'arch/arm64/boot/Image', 'Module.symvers']
        before = {n: m.sha(root / 'candidate-out' / n) for n in names}
        with self.assertRaisesRegex(ValueError, 'Image_IKCONFIG_DIFFERS'):
            m.audit_build(root)
        self.assertEqual(before, {n: m.sha(root / 'candidate-out' / n) for n in names})

class WorkflowTests(unittest.TestCase):
    def command(self, op):
        expected = (ROOT / ('References/M25_' + op.upper() + '_COMMAND.sh')).read_text()
        if 'M25_WORKFLOW' not in os.environ:
            return expected
        rows = Path(os.environ['M25_WORKFLOW']).read_text().splitlines()
        found = []
        for i, row in enumerate(rows):
            if row.strip() != 'run: |':
                continue
            indent = len(row) - len(row.lstrip())
            body = []
            for line in rows[i + 1:]:
                if line.strip() and len(line) - len(line.lstrip()) <= indent:
                    break
                body.append(line)
            script = textwrap.dedent('\n'.join(body)) + '\n'
            if 'python3 -B "$M25_DIR/Tools/m25_config.py" ' + op in script:
                found.append(script)
        self.assertEqual(found, [expected])
        return found[0]

    def capture(self, op, broken=False):
        with tempfile.TemporaryDirectory(prefix='m25 argv ') as tmp:
            root = Path(tmp)
            bindir = root / 'bin'
            bindir.mkdir()
            shim = bindir / 'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M25_CAPTURE"\n')
            shim.chmod(0o755)
            keys = ['M25_DIR', 'R25_DIR', 'R24_DIR', 'R23_DIR', 'R21_SCHED_DIR', 'R19_RMNET_DIR',
                    'R18_IRQ_DIR', 'R17_CACHE_DIR', 'R16_REPAIR_DIR', 'R9_SNAPSHOT', 'R13_OBJOUT',
                    'R47_REPORT_DIR', 'R47_TOOLS_DIR', 'GITHUB_WORKSPACE', 'R16_REPAIR_OUTPUT',
                    'R21_PACK_DIR', 'R21_PACKAGE_OUTPUT']
            values = {k: str(root / (k + ' spaces')) for k in keys}
            script = self.command(op)
            if broken:
                script = script.replace(' ' + op + ' \\\n', ' ' + op + ' \\\n  + \\\n', 1)
            r = subprocess.run(['bash', '-c', script], env=dict(os.environ, **values,
                               PATH=str(bindir) + os.pathsep + os.environ['PATH'], M25_CAPTURE=str(root / 'argv')),
                               capture_output=True, text=True, timeout=10)
            self.assertEqual(r.returncode, 0, r.stderr)
            fields = (root / 'argv').read_bytes().split(b'\0')
            self.assertEqual(fields.pop(), b'')
            return [v.decode() for v in fields], values

    def test_delivered_build_command_passes_all_real_parser_paths(self):
        argv, values = self.capture('build')
        self.assertEqual(argv[:2], ['-B', values['M25_DIR'] + '/Tools/m25_config.py'])
        parsed = m.parser().parse_args(argv[2:])
        self.assertEqual(parsed.op, 'build')
        self.assertEqual(len(vars(parsed)), 15)
        self.assertEqual(parsed.r25_tool, values['R25_DIR'] + '/Tools/r25_tzlog.py')
        self.assertEqual(parsed.output, values['R16_REPAIR_OUTPUT'])
        self.assertEqual(parsed.source, values['R9_SNAPSHOT'])

    def test_delivered_package_command_passes_real_parser(self):
        argv, values = self.capture('package')
        parsed = m.parser().parse_args(argv[2:])
        self.assertEqual(parsed.r25_tool, values['R25_DIR'] + '/Tools/r25_tzlog.py')
        self.assertEqual(parsed.build, values['R16_REPAIR_OUTPUT'])
        self.assertEqual(parsed.output, values['R21_PACKAGE_OUTPUT'])

    def test_original_plus_typo_is_rejected_in_both_commands(self):
        for op in ['build', 'package']:
            argv, _ = self.capture(op, broken=True)
            with self.subTest(op=op), self.assertRaises(SystemExit) as error:
                m.parser().parse_args(argv[2:])
            self.assertEqual(error.exception.code, 2)

if __name__ == '__main__':
    unittest.main()
