#!/usr/bin/env python3
"""Correct IKCONFIG's input and require authentic, matching build evidence."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import mmap
import re
import struct
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = b'$(obj)/config_data.gz: arch/arm64/configs/stock_defconfig FORCE'
NEW = b'$(obj)/config_data.gz: $(KCONFIG_CONFIG) FORCE'
R25_TOOL_SHA = 'cf12a36177fb6de48abd2ea4e05b173ed3f3f922a51b6375f6f2aeb1ace5aefb'
CONFIG_SHA = 'c6f842ddf24f496cea367803d2916a17896f221288932e0947de65b66941439a'
SYMVERS_SHA = 'b793e9d853946655546c5e07e9fecc44b876b6147763d887ad032510563ee782'
STATUS = 'M25_REAL_BUILD_CONFIG_IMAGE_VMLINUX_AUTOCONF_AND_QGKI_PASS_NOFLASH'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def verify_package():
    names = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in names,
                'UNSAFE_MANIFEST')
        require(not (ROOT / p).is_symlink() and sha(ROOT / p) == digest,
                'PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names, 'PACKAGE_SCOPE_CHANGED')

def patch_makefile(source):
    path = Path(source) / 'kernel/Makefile'
    before = (ROOT / 'References/kernel.Makefile.before').read_bytes()
    require(path.is_file() and not path.is_symlink(), 'KERNEL_MAKEFILE_MISSING')
    require(path.read_bytes() == before, 'KERNEL_MAKEFILE_PREIMAGE_CHANGED')
    require(before.count(OLD) == 1 and NEW not in before, 'CONFIG_RULE_NOT_UNIQUE')
    after = before.replace(OLD, NEW, 1)
    path.write_bytes(after)
    return {'before_sha256': hashlib.sha256(before).hexdigest(),
            'after_sha256': sha(path), 'changed_source': 'kernel/Makefile',
            'config_values_changed': False}

def extract_config(data):
    """Read the unique complete IKCONFIG stream; validate gzip CRC and framing."""
    found = []
    pos = 0
    while True:
        marker = data.find(b'IKCFG_ST', pos)
        if marker < 0:
            break
        pos = marker + 8
        raw = data[pos:pos + 2 * 1024 * 1024]
        try:
            decoder = zlib.decompressobj(31)
            config = decoder.decompress(raw, 2 * 1024 * 1024 + 1)
        except zlib.error:
            continue
        if not decoder.eof or len(config) > 2 * 1024 * 1024:
            continue
        end = pos + len(raw) - len(decoder.unused_data)
        if data[end:end + 8] == b'IKCFG_ED':
            found.append((marker, config))
    require(len(found) == 1, 'IKCONFIG_UNIQUE_COMPLETE_PAYLOAD_REQUIRED:' + str(len(found)))
    return found[0][1]

def embedded(path):
    require(Path(path).stat().st_size > 0, 'EMPTY_KERNEL_PRODUCT')
    with Path(path).open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
        return extract_config(data)

def config_values(data):
    values = {}
    for line in data.decode().splitlines():
        if line.startswith('CONFIG_'):
            require('=' in line, 'MALFORMED_CONFIG')
            name, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            name, value = line[2:-11], 'n'
        else:
            continue
        require(name not in values, 'DUPLICATE_CONFIG:' + name)
        values[name] = value
    return values

def autoconf_check(config, header):
    expected = {}
    for name, value in config_values(config).items():
        if value == 'n':
            continue
        expected[name + '_MODULE' if value == 'm' else name] = '1' if value in ('y', 'm') else value
    actual = {}
    for line in header.splitlines():
        if line.startswith('#define CONFIG_'):
            _, name, value = line.split(' ', 2)
            require(name not in actual, 'DUPLICATE_AUTOCONF:' + name)
            actual[name] = value
    require(expected == actual, 'AUTOCONF_DIFFERS_FROM_BUILD_CONFIG')
    return len(expected)

def audit_build(build, strict=True):
    build = Path(build)
    out = build / 'candidate-out'
    cfg = (out / '.config').read_bytes()
    require(not strict or sha(out / '.config') == CONFIG_SHA, 'R25_BUILD_CONFIG_CHANGED')
    require(not strict or sha(out / 'Module.symvers') == SYMVERS_SHA, 'R25_FULL_EXPORT_TABLE_CHANGED')
    image = out / 'arch/arm64/boot/Image'
    vmlinux = out / 'vmlinux'
    with image.open('rb') as stream:
        header = stream.read(64)
    require(len(header) == 64 and header[56:60] == b'ARM\x64', 'ARM64_IMAGE_REQUIRED')
    with vmlinux.open('rb') as stream:
        elf = stream.read(20)
    require(elf[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', elf, 18)[0] == 183,
            'AARCH64_ELF_VMLINUX_REQUIRED')
    payloads = {}
    for name, path in [('Image', image), ('vmlinux', vmlinux)]:
        extracted = embedded(path)
        require(extracted == cfg, name + '_IKCONFIG_DIFFERS_FROM_BUILD_CONFIG')
        payloads[name] = hashlib.sha256(extracted).hexdigest()
    generated = gzip.decompress((out / 'kernel/config_data.gz').read_bytes())
    require(generated == cfg, 'KBUILD_CONFIG_DATA_DIFFERS_FROM_BUILD_CONFIG')
    count = autoconf_check(cfg, (out / 'include/generated/autoconf.h').read_text())
    if strict:
        before = (ROOT / 'References/kernel.Makefile.before').read_bytes()
        require((build / 'candidate-source/kernel/Makefile').read_bytes() == before.replace(OLD, NEW, 1),
                'FIXED_KERNEL_MAKEFILE_CHANGED')
    return {'build_config_sha256': hashlib.sha256(cfg).hexdigest(),
            'embedded_config_sha256': payloads, 'active_autoconf_entries': count,
            'byte_identical_config_image_vmlinux': True,
            'kbuild_gzip_matches_build_config': True,
            'export_table_entries': len((out / 'Module.symvers').read_text().splitlines()),
            'full_symvers_sha256': sha(out / 'Module.symvers'),
            'image_sha256': sha(image), 'vmlinux_sha256': sha(vmlinux)}

def parent_tool(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == R25_TOOL_SHA, 'AUTHENTIC_R25_TOOL_CHANGED')
    spec = importlib.util.spec_from_file_location('m25_original_r25', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module

def build(args):
    parent = parent_tool(args.r25_tool)
    original = parent.apply_source
    result = {'status': 'M25_BUILD_PENDING', 'kernel_compiled': False,
              'device_pass': False, 'flash_allowed': False, 'baseline_run': 43589750851}
    def apply(source):
        prior = original(source)
        result['makefile_patch'] = patch_makefile(source)
        return prior
    parent.apply_source = apply
    try:
        parent.build(args)
        parent.verify_fresh(args.output)
        require('makefile_patch' in result, 'CONFIG_FIX_WAS_NOT_APPLIED')
        result['config_proof'] = audit_build(args.output)
        result.update(status=STATUS, kernel_compiled=True)
    except Exception as error:
        result.update(status='M25_BUILD_OR_CONFIG_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.apply_source = original
        if Path(args.output).is_dir():
            write_json(Path(args.output) / 'M25_RESULT.json', result)
    print(STATUS, 'DEVICE_PASS=NO FLASH=NO')

def verify_fresh(build):
    result = json.loads((Path(build) / 'M25_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_M25_CONFIG_PASS_REQUIRED')
    require(result['config_proof'] == audit_build(build), 'M25_PRODUCT_CHANGED')
    return result

def audit_pair(build, output):
    out = Path(build) / 'candidate-out'
    image = (out / 'arch/arm64/boot/Image').read_bytes()
    cfg = (out / '.config').read_bytes()
    review = Path(output) / 'review'
    boots, archives = list(review.glob('*_boot.img')), list(review.glob('*_AK3.zip'))
    require(len(boots) == 1 and len(archives) == 1 and len(list(review.iterdir())) == 2,
            'EXACT_BOOT_AK3_PAIR_REQUIRED')
    data = boots[0].read_bytes()
    require(data[:8] == b'ANDROID!' and len(data) >= 4096, 'ANDROID_BOOT_REQUIRED')
    version = struct.unpack_from('<I', data, 40)[0]
    require(version in (3, 4), 'BOOT_V3_OR_V4_REQUIRED')
    size = struct.unpack_from('<I', data, 8)[0]
    require(data[4096:4096 + size] == image, 'BOOT_KERNEL_DIFFERS_FROM_AUDITED_IMAGE')
    with zipfile.ZipFile(archives[0]) as archive:
        require(archive.namelist().count('Image') == 1 and archive.testzip() is None,
                'AK3_VALID_UNIQUE_IMAGE_REQUIRED')
        require(archive.read('Image') == image, 'AK3_KERNEL_DIFFERS_FROM_AUDITED_IMAGE')
    require(extract_config(image) == cfg, 'PACKAGED_IKCONFIG_MISMATCH')
    return {p.name: sha(p) for p in [boots[0], archives[0]]}

def package(args):
    verify_fresh(args.build)
    parent = parent_tool(args.r25_tool)
    result = {'status': 'M25_PACKAGE_PENDING', 'static_boot_path_pass': False,
              'device_pass': False, 'flash_allowed': False}
    try:
        parent.package(args)
        pair = audit_pair(args.build, args.output)
        verify_fresh(args.build)
        result.update(status='M25_BOOT_AK3_CONFIG_IDENTITY_PASS_NOFLASH',
                      static_boot_path_pass=True, review_pair_sha256=pair,
                      packaged_kernel_config_matches_build=True)
    except Exception as error:
        result.update(status='M25_PACKAGE_GATE_FAILED_NOFLASH', error=str(error))
        review = Path(args.output) / 'review'
        if review.exists():
            review.rename(review.with_name('unverified-review'))
        raise
    finally:
        if Path(args.output).is_dir():
            write_json(Path(args.output) / 'M25_PACKAGE_RESULT.json', result)
    print('M25_BOOT_AK3_CONFIG_IDENTITY_PASS DEVICE_PASS=NO FLASH=NO')

def parser():
    p = argparse.ArgumentParser(description=__doc__)
    subs = p.add_subparsers(dest='op', required=True)
    subs.add_parser('verify-package')
    b = subs.add_parser('build')
    for name in ('r25-tool', 'r24-tool', 'r23-tool', 'r21-tool', 'r19-tool', 'r18-tool',
                 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + name, required=True)
    a = subs.add_parser('package')
    for name in ('r25-tool', 'r24-tool', 'r23-tool', 'r21-package-tool', 'build',
                 'packager-tool', 'work', 'output'):
        a.add_argument('--' + name, required=True)
    c = subs.add_parser('audit')
    c.add_argument('--build', required=True)
    return p

def main():
    args = parser().parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'audit':
        print(json.dumps(audit_build(args.build), sort_keys=True))
    else:
        print('M25_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')

if __name__ == '__main__':
    main()
