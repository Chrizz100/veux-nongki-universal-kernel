"""Regression tests for the P3 vs. M48 source mix-up from run 44958224729."""
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import unittest

import repair


def symbol_block(text, name):
    matches = re.findall(r"(?m)^config " + name + r"\n(?:[ \t].*\n|\n)*", text)
    if len(matches) != 1:
        raise ValueError("Missing or duplicate Kconfig definition: " + name)
    return matches[0].rstrip()


class SourceTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name)
        self.tree = self.root / "source"
        shutil.copytree(repair.ROOT / "baseline", self.tree)
        repair.add_historical_files_to_fixture(self.tree)

    def test_old_stage_rejects_real_control_at_both_paths(self):
        with self.assertRaises(ValueError) as failure:
            repair.apply(self.tree, "p3", self.root)
        for rel in repair.manifest("m48-overlay.json"):
            self.assertIn(rel, str(failure.exception))
        self.assertFalse((self.tree / "drivers/misc/simtray.c").exists())

    def test_mixed_sources_rejected_before_any_changes(self):
        rel = "drivers/misc/Makefile"
        shutil.copyfile(repair.ROOT / "baseline" / rel, self.tree / rel)
        with self.assertRaisesRegex(ValueError, rel):
            repair.apply(self.tree, "m48")
        self.assertFalse((self.tree / "drivers/misc/simtray.c").exists())

    def test_repair_preserves_both_driver_rules_and_kconfig_scope(self):
        config = self.tree / "drivers/misc/Kconfig"
        before = config.read_text()
        repair.apply(self.tree, "m48", self.root)
        after = config.read_text()
        for k in ("ATMEL_TCLIB", "HARDWARE_INFO"):
            self.assertEqual(symbol_block(after, k), symbol_block(before, k))
        self.assertIn("depends on OF_GPIO && GPIOLIB && SYSFS", symbol_block(after, "SIMTRAY_STATUS"))
        mf = (self.tree / "drivers/misc/Makefile").read_text()
        for name, obj in [("HARDWARE_INFO", "hardware_info.o"), ("SIMTRAY_STATUS", "simtray.o")]:
            self.assertEqual(len(re.findall(r"(?m)^obj-\$\(CONFIG_" + name + r"\)\s*\+=\s*"+ re.escape(obj)+r"$", mf)), 1)
        rows = json.loads((self.root / "M50_m48_after.json").read_text())
        self.assertEqual(len(rows), 11)
        self.assertTrue(all(row["match"] for row in rows.values()))
        subprocess.run(["patch", "--batch", "--reverse", "--fuzz=0", "-p1", "-i",
                        str(repair.ROOT / "stock-drivers.patch")], cwd=self.tree, check=True, stdout=subprocess.DEVNULL)
        repair.verify(self.tree, "m48", "before")

    def test_duplicate_and_unregistered_source_drift_rejected(self):
        repair.apply(self.tree, "m48")
        with self.assertRaises(ValueError):
            repair.apply(self.tree, "m48")
        src = self.tree / "drivers/scsi/ufs/ufshcd.c"
        src.write_bytes(src.read_bytes() + b"\n")
        with self.assertRaisesRegex(ValueError, "ufshcd.c"):
            repair.verify(self.tree, "m48", "after")


if __name__ == "__main__":
    unittest.main()
