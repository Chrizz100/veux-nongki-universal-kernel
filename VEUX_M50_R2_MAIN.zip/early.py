from pathlib import Path
import concurrent.futures, os, shutil, subprocess, sys
import argparse, struct, json, tempfile, zipfile
from repair import add_historical_files_to_fixture, apply, manifest, require

cli = argparse.ArgumentParser(description="Cross-compile the five actual M50 drivers with the authenticated M44 headers")
for name in ["engine","m44","toolchain","result"]:
    cli.add_argument("--"+name,required=True,type=Path)
args = cli.parse_args()
root = Path(__file__).resolve().parent
sys.path.insert(0, str(args.engine.resolve()))
import driver_check as driver
out=args.result.resolve()
out.mkdir(parents=True,exist_ok=True)
tmp=tempfile.TemporaryDirectory()
work=Path(tmp.name)
tree=work/"tree"
shutil.copytree(root/"baseline",tree)
headers=work/"headers"
driver.headers_from_build(args.m44,headers)
with zipfile.ZipFile(args.m44) as archive:
    r14 = json.loads(archive.read("r46-r16-result/R16_RESULT.json"))["r14_oem"]
require(r14["real_hardwareinfo_driver"] is True, "Missing M44 hardware-info proof")
for rel, expected in manifest("m48-overlay.json").items():
    record = r14["source_pins"][rel]
    require(record["before_sha256"] == expected["p3"] and record["after_sha256"] == expected["control"],
            "M44 R14 lineage differs: " + rel)
add_historical_files_to_fixture(tree)
apply(tree, "m48", out)
tools=args.toolchain.resolve()
env=driver.toolchain(tools)
defs=['UFS_WB','SIMTRAY_STATUS','CPUMAXFREQ','DEBUG_POLICY_STATUS','DM_VERITY_AVB']
common=['--target=aarch64-linux-gnu','-D__KERNEL__','-nostdinc','-isystem',
        subprocess.check_output(['gcc','-print-file-name=include'],text=True).strip(),'-Werror=implicit-function-declaration','-Werror=incompatible-pointer-types','-Werror=return-type',
        '-Wno-address-of-packed-member','-Wno-pointer-sign','-Wno-gnu-variable-sized-type-not-at-end','-std=gnu89','-O2','-mcmodel=large','-mgeneral-regs-only','-fno-pic','-fno-stack-protector','-flto=thin','-fsplit-lto-unit','-fvisibility=default','-fsanitize=cfi','-fno-sanitize-blacklist','-fsanitize-cfi-cross-dso','-fno-sanitize-cfi-canonical-jump-tables']
includes=['arch/arm64/include','arch/arm64/include/generated','include','arch/arm64/include/uapi','arch/arm64/include/generated/uapi','include/uapi','include/generated/uapi']
common+=['-I'+str(headers/n) for n in includes]+['-include',str(headers/'include/linux/kconfig.h')]
common+=['-DCONFIG_'+n+'=1' for n in defs]
def build(rel):
 f=tree/rel
 mod='ufshcd_core' if f.stem in ('ufshcd','ufs-sysfs') else f.stem.replace('-','_')
 args=[tools/'clang-12',*common,'-DKBUILD_MODNAME="'+mod+'"','-DKBUILD_BASENAME="'+f.stem.replace('-','_')+'"','-c',f,'-o',out/(f.stem+'.bc')]
 p=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/(f.stem+'.log')).write_text(p.stdout)
 print(rel,p.returncode,p.stdout[:1300],flush=True)
 if p.returncode:return False
 subprocess.run([tools/'ld.lld','-r',out/(f.stem+'.bc'),'-o',out/(f.stem+'.o')],env=env,check=True)
 return True
paths=['drivers/scsi/ufs/ufshcd.c','drivers/scsi/ufs/ufs-sysfs.c','drivers/misc/simtray.c','drivers/soc/qcom/cpumaxfreq.c','drivers/soc/qcom/dp_status.c']
with concurrent.futures.ThreadPoolExecutor(4) as pool: result=list(pool.map(build,paths))
require(all(result), "M50 driver compilation failed")
evidence = {}
for name in paths:
    obj = out/(Path(name).stem+".o")
    data = obj.read_bytes()
    require(data[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<HH",data,16) == (1,183), "Expected a genuine AArch64 relocatable")
    evidence[name] = driver.checksum(obj)
(out/"M50_ARM64_OBJECTS.json").write_text(json.dumps(evidence,indent=2)+"\n")
