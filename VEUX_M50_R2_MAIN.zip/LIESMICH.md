# VEUX M50 R2 · Kernelreparatur

Ziel ist ein stocknaher Kernel für das POCO X4 Pro 5G (veux), HyperOS V816.0.12.0.TKCMIXM, Release 5.4.274-qgki-g82179e362f33. Ausgangspunkt ist der vollständige M48-R2-Bau 44919059919 mit M49-Abgleich 44954315192.

## Auf GitHub starten

1. VEUX_M50_R2_MAIN.zip als ZIP in das Hauptverzeichnis von Chrizz100/veux-nongki-universal-kernel auf main hochladen.
2. VEUX_M50_R2_KERNEL_REPARATUR_NOFLASH.yml unter .github/workflows/ auf main ablegen.
3. Unter Actions „VEUX M50 R2 – Kernelreparatur und vollständiger Stock-Vergleich (NOFLASH)“ manuell starten.

## Korrektur nach Lauf 44958224729

Schritt 93 brach noch vor dem M50-Kbuild ab. Beim Vergleich mit dem laufenden M48-Baubaum erwartete M50 für drivers/misc/Kconfig und drivers/misc/Makefile die früheren P3-Dateien. Seit R14 enthalten beide Dateien die Einbindung von Xiaomis HARDWARE_INFO-Treiber. Die beiden Archive des roten Laufs enthalten die Treiber-Vortests und den Fehlerbericht. Im selben Lauf wurde der M48-Kontrollkernel erfolgreich neu gebaut. Für M50 stehen vollständiger Kernelbau, Vendor-ABI und Boot-Layout noch aus.

R2 prüft alle elf Pfade vor dem Patch und danach. P3 und die spätere Kernelquelle haben jeweils eigene Sollwerte. Die geänderten Werte für die beiden historischen Eingabedateien stammen aus dem authentifizierten R14-Quellpaket und dem gespeicherten M44-Baunachweis. Im tatsächlichen Build werden die vorhandenen Dateien an Ort und Stelle gepatcht. Eine frühe Prüfung im Workflow wiederholt die Integration zusätzlich mit den entpackten R14-Quelldateien. Ein weiterer Fehler im M50-Patch betraf die GPIO-Abhängigkeit des SIM-Schachts. R2 ordnet sie SIMTRAY_STATUS zu und erhält den ursprünglichen ATMEL_TCLIB-Eintrag.

M50_R2_Pruefung.json dokumentiert die lokalen Tests und die zwei geprüften GitHub-Artefakte. Die alte Datei M50_LOKAL_GEPRUEFT.json hält den Stand vor R2 fest. Bei einer abweichenden Quelldatei protokolliert der Workflow alle betroffenen Pfade. Nach erfolgreicher Quellprüfung kann auch bei einem späteren Kbuild-Abbruch eine als Quellvergleich gekennzeichnete Bilanz entstehen. Ein Geräteboot und der Rückweg per Fastboot bleiben offen.

## Änderungen

- Im bisherigen Image kehrt ufshcd_wb_ctrl sofort mit 0 zurück. Der neue Code prüft Controller, UFS-Version, Deskriptorlänge, Gerätemerkmal und Pufferzuteilung. Für Xiaomis WriteBooster-Abfragen wird bei Samsung Selektor 1 und sonst Selektor 0 verwendet. Die reguläre exportierte Abfrage behält ihren bisherigen Selektor. Samsung- und andere Geräte, unvollständige Antworten, dedizierte LUNs sowie fehlgeschlagene Abfragen werden vor dem vollständigen Bau geprüft.
- Die Xiaomi-SIM-Schachtanzeige veröffentlicht ihren Gerätezustand vor dem Anlegen der sysfs-Datei und erhält Probe-Fehler wie EPROBE_DEFER.
- Die CPU-Frequenzanzeige benutzt je Lesezugriff die vorhandenen CPUFreq-Policies und gibt jede Referenz wieder frei.
- Die Qualcomm-Debugstatusanzeige liest das OEM-Feld über SCM. Abfragefehler erreichen den Aufrufer.

## Was das Paket belegt

M50_LOKAL_GEPRUEFT.json enthält den lokalen Vorabstand. Fünf Treiberobjekte wurden mit Android Clang 12, ThinLTO und CFI als AArch64-ELF erzeugt. Gegen die anderen Objekte und die bestehende Symboltabelle wurden 206 unterschiedliche externe Symbolnamen aufgelöst. Die Prüfung in GitHub erzeugt anschließend den neuen Kernel und prüft seine 1.423 ABI-Referenzsymbole, 3.148 Modulimporte und 37 Vendor-Module. Sie vergleicht außerdem generierte Konfiguration, eingebettete Konfigurationen in Image und vmlinux, DTB, Kernelkennung und alte Verity-Pfade.

Alle 58 bisherigen Stock-Konfigurationsunterschiede stehen in M50_Arbeitsliste.csv. Der Lauf prüft genau vier neu wirksame Optionen. Erst ein erfolgreicher Lauf belegt für M50 die erwarteten 54 verbleibenden Konfigurationsunterschiede. Diese Zahl umfasst auch Compilermerkmale und unterschiedliche Wege, dieselbe Kernelkennung zu erzeugen.

## Quellbilanz und weitere Reparaturen

Der Lauf vergleicht die gesamte gebaute Quellstruktur nach Pfad, Dateimodus und Git-Blob sowohl mit Xiaomis veröffentlichtem veux-r-oss 5.4.134 als auch mit dem rekonstruierten P3 auf 5.4.274. Jeder Unterschied erhält eine eigene CSV-Zeile. Für C- und Assemblerdateien nennt die Bilanz ein vorhandenes gleichnamiges Kbuild-Objekt als Hinweis. Die Zahl historisch genannter Abweichungen und neue Vergleiche unterschiedlicher Quellstände haben verschiedene Bezugsgrößen.

- UFS-Firmwareupdate (FFU). Der ausgelieferte Stock-Kernel enthält sechs Modell-/Revisionspaare und drei verschiedene Firmwareblöcke. Ihre Zeigerauflösung im ARM64-Image sowie die Übereinstimmung mit den öffentlich verfügbaren Xiaomi-Firmwarebytes sind dokumentiert. Der sechste Eintrag H9QT1G6DN6X132 verweist auf SKhynix_A002. Für die Integration sind die GPT-Zuordnung des FFU-Speichers, die PMIC-Rückmeldung, Wiederholungs- und Abbruchpfade sowie die Herkunft externer Firmwareeinträge noch zu klären. VEUX_M50_UFS_Bestand.sh kann Hersteller, Modell, Revision und GPT-Beschriftung des laufenden Geräts auslesen. Das Skript öffnet keine Partition.
- Bootgrundanzeige. Zwei vom veröffentlichten Xiaomi-Bootinfo-Treiber verwendete PMIC-Funktionen fehlen im M48-Symbolstand (qpnp_pon_is_ps_hold_reset, qpnp_pon_is_lpk). Die Rückgabewerte für Warmstart und langen Tastendruck müssen zusammen mit der Gerätevariante geprüft werden.
- FUSE. Beim veröffentlichten Xiaomi-Code erfordert der Passthrough-Pfad zusätzlich CONFIG_REGION_IS_CN. Diese Option fehlt im ausgelieferten Global-Stock-Image. CONFIG_PASSTHROUGH_SYSTEM allein belegt hier keinen fehlenden Funktionspfad.
- Dateisysteme, Speicherverwaltung, Xiaomi-Prozessverwaltung und thermische CPU-Isolation sind in der Arbeitsliste erfasst. Historische Hinweise zu Lade-/Suspend-Pfaden werden weiter gegen die seit M40 erfolgten Reparaturen und gegen Hardware geprüft.
- Nach dem geprüften Kernel sichert der Workflow den vollständigen Quellstand und kontrolliert, ob der Kandidat mit dem echten Stock-Ramdisk in das Boot-Layout passt. Ein Start dieses Kandidaten auf dem Gerät und die Wiederherstellung des gesicherten boot_a per PC stehen aus. Die bekannte Sicherung gehört zum laufenden Gerät und bleibt separat.

## Herkunft

- Xiaomi-Kernelquelle und Treiber: MiCode/Xiaomi_Kernel_OpenSource, Commit 61397e524093d1ccb94769b5460825e2eaf8871e, Git-Baum ce2507948ba02807da44c5f81d04f8ce9945d66a, 65.451 Einträge.
- Ausgangsquellen der betroffenen Treiber: dereference23/kernel_xiaomi_sm6375, b2b7a3bbc36d120ee523ebc8d68e0f13a97df632, mit dem Android-5.4.274-Abgleich. Der Workflow prüft zusätzlich die Datei-Hashes auf dem rekonstruierten P3-Git-Baum 7f97dbbff432d61bbf11cae03de257a21f1d3c74 und auf dem live gebauten M48-Stand.
- Die echte Stock-boot.img hat SHA-256 ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5. Die Firmware-Referenzdateien enthalten Prüfsummen und Zuordnungen.
