"""Compare every regular file and symlink in the built kernel source against two authenticated Linux trees."""
import argparse
from collections import Counter
import csv
import gzip
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
from repair import P3, ROOT, require

OEM_TREE = "ce2507948ba02807da44c5f81d04f8ce9945d66a"


def read_tree(data):
    entries = {}
    for record in data.split(b"\0"):
        if not record:
            continue
        fields, path = record.split(b"\t", 1)
        mode, kind, sha = fields.decode().split()
        require(kind == "blob", "Unexpected git entry: " + repr(path))
        entries[os.fsdecode(path)] = (mode, sha)
    return entries


def scan(path):
    entries = {}
    for parent, directories, names in os.walk(path):
        base = Path(parent)
        directories[:] = [d for d in directories if d != ".git"]
        links = [d for d in directories if (base / d).is_symlink()]
        directories[:] = [d for d in directories if d not in links]
        for name in names + links:
            if name == ".git":
                continue
            child = base / name
            st = child.lstat()
            if stat.S_ISLNK(st.st_mode):
                data, mode = os.fsencode(os.readlink(child)), "120000"
            elif stat.S_ISREG(st.st_mode):
                data = child.read_bytes()
                mode = "100755" if st.st_mode & stat.S_IXUSR else "100644"
            else:
                raise ValueError("Unexpected special source file: " + str(child))
            digest = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
            entries[child.relative_to(path).as_posix()] = (mode, digest)
    return entries


def compare(ref, candidate, outdir, label, objectdir):
    counts = Counter()
    empty = ("", "")
    with gzip.open(outdir / (label + ".csv.gz"), "wt", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["Pfad", "Status", "Referenzmodus", "Referenz-Git-Blob",
                         "M50-Modus", "M50-Git-Blob", "gleichnamiges Kbuild-Objekt vorhanden"])
        for path in sorted(ref.keys() | candidate.keys()):
            before, after = ref.get(path, empty), candidate.get(path, empty)
            if before == after:
                counts["identisch"] += 1
                continue
            status = "nur_m50" if before == empty else "nur_referenz" if after == empty else "abweichend"
            counts[status] += 1
            unit = Path(path)
            obj = (objectdir / unit.with_suffix(".o")).is_file() if objectdir is not None and unit.suffix in {".c", ".S"} else ""
            writer.writerow([path, status, *before, *after, obj])
    return dict(counts, referenz_dateien=len(ref), m50_dateien=len(candidate))


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    for key in ["source", "objectdir", "git", "out"]:
        cli.add_argument("--" + key, required=True, type=Path)
    cli.add_argument("--source-only", action="store_true", help="Do not attribute object files from an unfinished build")
    args = cli.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    oem = read_tree(gzip.decompress((ROOT / "Xiaomi-veux-r-oss.ls-tree.gz").read_bytes()))
    p3 = read_tree(subprocess.check_output(["git", "-C", args.git, "ls-tree", "-rz", "--full-tree", P3]))
    require(len(oem) > 60000 and len(p3) > 60000, "Incomplete whole-tree reference")
    snapshot = scan(args.source)
    sums = {key: compare(ref, snapshot, args.out, label, None if args.source_only else args.objectdir) for key, ref, label in [
        (OEM_TREE, oem, "M50_gegen_Xiaomi_5.4.134"), (P3, p3, "M50_gegen_P3_5.4.274")]}
    sums["source_only"] = args.source_only
    (args.out / "M50_QUELLBILANZ.json").write_text(json.dumps(sums, indent=2) + "\n")


if __name__ == "__main__":
    main()
