#!/usr/bin/env python3
"""R20-R9: port authentic Xiaomi WALT user-hint max after validated R16 lineage.

Only the staging copy's kernel/sysctl.c is touched. The definition is sourced
from MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e
kernel/sysctl.c, where CONFIG_SCHED_WALT protects:
    const int sched_user_hint_max = 1000;
No fake link stub or replacement for WALT implementation is permitted.
"""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

TARGET='kernel/sysctl.c'
WALT_HEADER='kernel/sched/walt/walt.h'
WALT_SYSCTL='kernel/sched/walt/sysctl.c'
# Proven by R12_SOURCE_GATE.json on R20-R7 run 39733461815, artifact 12407990398.
R12_SYSCTL_SHA256='2faaf4794c66f8629fcf4fb3da0c046ca060a2e13e58e60f549ffde6a9fde370'
R12_STATUS='R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED'
# From R16_SOURCE_GATE.json attached to the real R20-R8 run 39742605954.
# The R16 patch intentionally extends R12 kernel/sysctl.c with capacity APIs.
R16_SYSCTL_SHA256='17489b89bac21a6bfccfed5fd845a53c8a2a3fd11e4531f5304bfa79493074f7'
R16_STATUS='R16_OEM_BOUNDED_API_STAGE_NOT_KERNEL_COMPILED'
R16_PATCH_SHA256='b525cda0d3bcd0701b2309d31c2632c957fcb163ddef374af1f85d8bc5cf142f'
R16_FILES=['include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c',
           'include/linux/sysctl.h','kernel/sysctl.c']
XIAOMI_SOURCE_REPOSITORY='MiCode/Xiaomi_Kernel_OpenSource'
XIAOMI_SOURCE_COMMIT='61397e524093d1ccb94769b5460825e2eaf8871e'
XIAOMI_SOURCE_PATH='kernel/sysctl.c'
# Original MiCode source has CONFIG_SCHED_WALT and the exact global constant.
OEM_DEFINITION='const int sched_user_hint_max = 1000;'
SYMBOL='sched_user_hint_max'
ANCHOR='/* Constants used for minimum and  maximum */\n'
REPLACEMENT=ANCHOR+'#ifdef CONFIG_SCHED_WALT\n'+OEM_DEFINITION+'\n#endif\n'
SYNCHRONIZED_SOURCE=('kernel/sysctl.c','kernel/sched/walt/walt.h')

class ContractError(ValueError):
    pass

def need(condition,code):
    if not condition: raise ContractError(code)

def sha256(data):return hashlib.sha256(data).hexdigest()

def confined_file(root,relpath,optional=False):
    root=Path(root)
    need(root.is_dir() and not root.is_symlink(),'ROOT_NOT_DIRECTORY_OR_SYMLINK')
    rp=Path(relpath)
    need(not rp.is_absolute() and '..' not in rp.parts and '\\' not in relpath,'UNSAFE_RELATIVE_PATH')
    target=root/rp
    if optional and not target.exists() and not target.is_symlink():return None
    need(target.exists(),'SOURCE_FILE_MISSING:'+relpath)
    base=root.resolve()
    current=root
    for seg in rp.parts:
        current=current/seg
        need(not current.is_symlink(),'SYMLINK_SOURCE_PATH:'+relpath)
    need(target.resolve().is_relative_to(base),'SOURCE_PATH_ESCAPE:'+relpath)
    need(target.is_file() and not target.is_symlink(),'NONREGULAR_SOURCE:'+relpath)
    return target

def read_source(root,path,optional=False):
    p=confined_file(root,path,optional)
    if p is None:return None
    data=p.read_bytes()
    need(b'\r\n' not in data,'SOURCE_CRLF:'+path)
    return data

def check_config(contents):
    need(contents.count(b'CONFIG_SCHED_WALT=y\n')==1,'WALT_ON_CONFIG_REQUIRED')
    need(contents.count(b'CONFIG_SYSCTL=y\n')==1,'SYSCTL_CONFIG_REQUIRED')
    return True

def check_r12_proof(report,required_sha=R12_SYSCTL_SHA256):
    need(isinstance(report,dict) and report.get('status')==R12_STATUS,
         'R12_SOURCE_PROVENANCE_MISSING')
    need(report.get('after_sha256',{}).get(TARGET)==required_sha,
         'R12_PINNED_GATE_SHA_DRIFT')
    need(report.get('brene_changed') is False and report.get('bakasusu_nomount_changed') is False,
         'R12_MUTATED_PROTECTED_CODE')

def check_r16_proof(report,observed_sha,patch_bytes,
                    required_r12_sha=R12_SYSCTL_SHA256,
                    required_r16_sha=R16_SYSCTL_SHA256,
                    required_patch_sha=R16_PATCH_SHA256):
    need(isinstance(report,dict) and report.get('status')==R16_STATUS,
         'R16_SOURCE_PROVENANCE_MISSING')
    need(report.get('modified_files')==R16_FILES,
         'R16_MODIFIED_SCOPE_DRIFT')
    need(report.get('before_sha256',{}).get(TARGET)==required_r12_sha,
         'R12_R16_LINEAGE_NOT_CHAINED')
    need(report.get('after_sha256',{}).get(TARGET)==required_r16_sha,
         'R16_PINNED_POSTIMAGE_SHA_DRIFT')
    need(report.get('patch_sha256')==required_patch_sha and
         sha256(patch_bytes)==required_patch_sha,
         'R16_SOURCE_PATCH_NOT_AUTHENTIC')
    need(report.get('source_r15_verified') is True and
         report.get('brene_changed') is False and
         report.get('bakasusu_nomount_changed') is False and
         report.get('flash_allowed') is False and
         report.get('kernel_image_built') is False and
         report.get('vmlinux_linked') is False,
         'R16_FORBIDDEN_MUTATION_OR_FALSE_BUILD')
    need(observed_sha==required_r16_sha,
         'R16_TO_R20_STAGE_SHA_DRIFT')

def check_r19_proof(report):
    need(isinstance(report,dict),'R19_MISSING_PROOF')
    need(report.get('status')=='R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK'
         and report.get('all_verified') is True
         and report.get('type_aware_symbol_count')==13
         and report.get('r18_real_arm64_compiled')==15
         and report.get('flash_allowed') is False,
         'R19_PROVIDERS_NOT_PROVEN')

def parse_symbols(output,symbol=SYMBOL):
    """Support pinned LLVM LTO bitcode and normal ELF nm formatting."""
    lines=[]
    for row in output.splitlines():
        row=row.strip()
        if not row.endswith(' '+symbol):continue
        m=re.fullmatch(r'(?P<addr>[a-fA-F0-9]+|-{16})\s+(?P<kind>[A-Za-z?])\s+'+re.escape(symbol),row)
        need(bool(m),'MALFORMED_SYMBOL_OUTPUT')
        lines.append({'address':m.group('addr'),'kind':m.group('kind'),'line':row})
    return lines

def check_original_sysctl_object(nm_output):
    symbols=parse_symbols(nm_output)
    need(not any(x['kind']!='U' for x in symbols),
         'ORIGINAL_SYSCTL_ALREADY_DEFINES_WALT_USER_HINT')
    return symbols

def port_oem(original,expected_sha=R16_SYSCTL_SHA256):
    need(sha256(original)==expected_sha,'SYSCTL_PREIMAGE_SHA_DRIFT')
    text=original.decode('utf-8')
    need(text.count(ANCHOR)==1,'SYSCTL_CONSTANT_BLOCK_ANCHOR_DRIFT')
    need(text.count('#if defined(CONFIG_SYSCTL)')==1 and
         text.find('#if defined(CONFIG_SYSCTL)')<text.find(ANCHOR),
         'SYSCTL_COMPILE_GUARD_NOT_PROVEN')
    need(SYMBOL not in text,'SYSCTL_ALREADY_CONTAINS_USER_HINT_SYMBOL')
    new=text.replace(ANCHOR,REPLACEMENT,1)
    need(new.count(OEM_DEFINITION)==1,'XIAOMI_CONST_INSERT_FAILED')
    diff=''.join(difflib.unified_diff(text.splitlines(keepends=True),new.splitlines(keepends=True),
                                     fromfile='a/'+TARGET,tofile='b/'+TARGET))
    need(diff.startswith('--- a/'+TARGET) and diff.count('@@')==2 and
         sum(x.startswith('+') and not x.startswith('+++') for x in diff.splitlines())==3,
         'UNEXPECTED_PATCH_SCOPE')
    return new.encode('utf-8'),diff

def run(snapshot,canonical,project,config,r12_proof,r16_proof,r16_patch,r19_proof,
        objout,llvm_nm,output,expected_sha=R16_SYSCTL_SHA256,
        expected_r12_sha=R12_SYSCTL_SHA256,expected_patch_sha=R16_PATCH_SHA256):
    snapshot,canonical,project,config,r12_proof,r16_proof,r16_patch,r19_proof,objout,llvm_nm,output=map(
        Path,(snapshot,canonical,project,config,r12_proof,r16_proof,r16_patch,r19_proof,
              objout,llvm_nm,output))
    for kind,p in [('SNAPSHOT',snapshot),('CANONICAL',canonical),('PROJECT',project),('OBJECTS',objout)]:
        need(p.is_dir() and not p.is_symlink(), 'UNSAFE_ROOT_'+kind)
    snap,can,proj,objs=snapshot.resolve(),canonical.resolve(),project.resolve(),objout.resolve()
    dest=output.resolve()
    need(snap!=can and not snap.is_relative_to(can) and not can.is_relative_to(snap),
         'CANONICAL_AND_SNAPSHOT_OVERLAP')
    need(not snap.is_relative_to(proj) and not can.is_relative_to(proj) and
         not dest.is_relative_to(proj) and not dest.is_relative_to(snap) and
         not dest.is_relative_to(can) and not dest.is_relative_to(objs),
         'OUTPUT_OR_SOURCE_OVERLAP')
    need(not output.exists() and not output.is_symlink(),'AUDIT_OUTPUT_ALREADY_EXISTS')
    need(config.is_file() and not config.is_symlink() and
         r12_proof.is_file() and not r12_proof.is_symlink() and
         r16_proof.is_file() and not r16_proof.is_symlink() and
         r16_patch.is_file() and not r16_patch.is_symlink() and
         r19_proof.is_file() and not r19_proof.is_symlink(),
         'MISSING_CONFIG_OR_PROVENANCE')
    need(llvm_nm.is_file() and not llvm_nm.is_symlink(),'LLVM_NM_UNAVAILABLE')
    # Write report before first source validation; failures remain auditable.
    output.mkdir(parents=True,exist_ok=False)
    evidence={'stage':'R20_R9_XIAOMI_USER_HINT_R12_R16_LINEAGE',
              'status':'UNVERIFIED','source_reference':
              {'repository':XIAOMI_SOURCE_REPOSITORY,'commit':XIAOMI_SOURCE_COMMIT,
               'path':XIAOMI_SOURCE_PATH,'definition':OEM_DEFINITION},
              'expected_r12_sysctl_sha256':expected_r12_sha,
              'expected_r16_sysctl_sha256':expected_sha,
              'expected_r16_patch_sha256':expected_patch_sha,
              'brene_changed':False,'bakasusu_nomount_changed':False,
              'kernel_image_built':False,'vmlinux_linked':False,
              'vendor_abi_proven':False,'flash_allowed':False}
    audit=output/'R20_R9_SOURCE_GATE.json'
    audit.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
    canonical_source=None
    written=False
    try:
        check_config(config.read_bytes())
        r12=json.loads(r12_proof.read_text())
        r16=json.loads(r16_proof.read_text())
        r19=json.loads(r19_proof.read_text())
        src=read_source(snapshot,TARGET)
        original_hash=sha256(src)
        evidence['observed_snapshot_sysctl_sha256']=original_hash
        audit.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
        check_r12_proof(r12,expected_r12_sha)
        check_r16_proof(r16,original_hash,r16_patch.read_bytes(),
                        expected_r12_sha,expected_sha,expected_patch_sha)
        check_r19_proof(r19)
        # Verify the actual R16 capacity API survived subsequent source stages.
        need(src.count(b'int proc_douintvec_capacity(')==2,
             'R16_CAPACITY_SOURCE_ANCHOR_MISSING')
        header=read_source(snapshot,WALT_HEADER).decode('utf-8')
        need(len(re.findall(r'(?m)^extern\s+const\s+int\s+'+SYMBOL+r'\s*;',header))==1,
             'WALT_EXACT_EXTERNAL_CONST_DECLARATION_MISSING')
        other=read_source(snapshot,WALT_SYSCTL,optional=True)
        if other is not None:
            need(not re.search(r'\bconst\s+int\s+'+SYMBOL+r'\s*=',other.decode('utf-8')),
                 'DUPLICATE_WALT_SYSCTL_PROVIDER')
        canonical_source=read_source(canonical,TARGET)
        realobj=confined_file(objout,TARGET[:-1]+'o')
        proc=subprocess.run([str(llvm_nm),'-g',str(realobj)],capture_output=True,text=True,timeout=60)
        (output/'R20_R9_PREIMAGE_LLVM_NM.txt').write_text(
            '# object=kernel/sysctl.o; sha256='+sha256(realobj.read_bytes())+'; rc='+str(proc.returncode)+'\n'+
            proc.stdout+proc.stderr)
        need(proc.returncode==0 and len(proc.stdout)<300000,'LLVM_NM_PREIMAGE_FAILED')
        check_original_sysctl_object(proc.stdout)
        after,diff=port_oem(src,expected_sha)
        evidence.update(r12_source_proof_sha256=sha256(r12_proof.read_bytes()),
                        r16_source_proof_sha256=sha256(r16_proof.read_bytes()),
                        r16_source_patch_sha256=sha256(r16_patch.read_bytes()),
                        r19_proof_sha256=sha256(r19_proof.read_bytes()),
                        sysctl_before_sha256=original_hash, sysctl_after_sha256=sha256(after),
                        canonical_before_sha256=sha256(canonical_source),
                        walt_header_sha256=sha256(header.encode('utf-8')),
                        original_sysctl_object_sha256=sha256(realobj.read_bytes()),
                        changes=[TARGET],original_global_definition_absent=True)
        need(read_source(snapshot,TARGET)==src,'SYSCTL_PREWRITE_RACE')
        (snapshot/TARGET).write_bytes(after)
        written=True
        need(read_source(snapshot,TARGET)==after,'SYSCTL_POSTWRITE_DRIFT')
        need(read_source(canonical,TARGET)==canonical_source,'CANONICAL_SYSCTL_MODIFIED')
        need(read_source(snapshot,WALT_HEADER).decode('utf-8')==header,'WALT_HEADER_MODIFIED')
        (output/'R20_R9_XIAOMI_USER_HINT.patch').write_text(diff)
        evidence.update(status='PASS',patched_files_count=1,
                        canonical_unchanged=True,full_build_proven=False)
        audit.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
        print('R20_R9_OEM_USER_HINT=PASS; R12_R16_LINEAGE=VERIFIED; ORIGINAL_XIAOMI_CONST=1000; PATCHED_FILES=1; PRELINK_ONLY=YES; FLASH=NO')
        return evidence
    except Exception as e:
        # Revert only the content this stage wrote, never overwrite a foreign concurrent edit.
        if written:
            target=snapshot/TARGET
            if target.is_file() and not target.is_symlink() and 'after' in locals() and target.read_bytes()==after:
                target.write_bytes(src)
        evidence.update(status='FAIL_CLOSED',failure_code=str(e))
        audit.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
        raise

def main():
    parser=argparse.ArgumentParser()
    for key in ('snapshot','canonical','project','config','r12-proof','r16-proof','r16-patch','r19-proof','objout','llvm-nm','output'):
        parser.add_argument('--'+key,required=True)
    a=parser.parse_args()
    try:
        run(a.snapshot,a.canonical,a.project,a.config,a.r12_proof,
            a.r16_proof,a.r16_patch,a.r19_proof,a.objout,a.llvm_nm,a.output)
        return 0
    except (ContractError,ValueError,OSError,UnicodeError,json.JSONDecodeError,subprocess.SubprocessError) as e:
        print('R20_R9_FAIL_CLOSED:'+str(e),file=sys.stderr)
        return 2
if __name__=='__main__':raise SystemExit(main())
