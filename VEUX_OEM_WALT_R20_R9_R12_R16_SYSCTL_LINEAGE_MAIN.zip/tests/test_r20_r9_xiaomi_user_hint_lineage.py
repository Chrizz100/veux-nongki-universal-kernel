import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

MODULE=Path(__file__).resolve().parents[1]/'r20_r9_xiaomi_user_hint_lineage.py'
spec=importlib.util.spec_from_file_location('r20_r9_xiaomi_user_hint_lineage',MODULE)
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

SOURCE=b'''// SPDX-License-Identifier: GPL-2.0-only
#include <linux/sysctl.h>
#if defined(CONFIG_SYSCTL)
/* Constants used for minimum and  maximum */
#ifdef CONFIG_LOCKUP_DETECTOR
static int sixty = 60;
#endif
int proc_douintvec_ravg_window(void) {return 0;}
#endif /* CONFIG_SYSCTL */
'''
# Synthetic reproductions of the exact R12 -> R16 source lineage.
# The real production hash is pinned separately in the script and workflow.
R12_ORIGINAL=SOURCE
SOURCE=SOURCE.replace(b'#endif /* CONFIG_SYSCTL */',
    b'int proc_douintvec_capacity(void) { return 0; }\n'
    b'#endif /* CONFIG_SYSCTL */\n'
    b'#else /* CONFIG_SYSCTL */\n'
    b'int proc_douintvec_capacity(void) { return -1; }\n'
    b'#endif /* R16 model */')
R16_PATCH=b'--- a/kernel/sysctl.c\n+++ b/kernel/sysctl.c\n@@ synthetic R16 sample @@\n'
WALT=b'extern const int sched_user_hint_max;\n'
CONFIG=b'CONFIG_SCHED_WALT=y\nCONFIG_SYSCTL=y\nCONFIG_PROC_SYSCTL=y\n'

class Fixture:
    def __init__(self,base):
        self.base=Path(base)
        self.snapshot=self.base/'snapshot';self.canonical=self.base/'canonical'
        self.project=self.base/'project';self.objout=self.base/'out'
        for name in (self.snapshot,self.canonical,self.project,self.objout):name.mkdir()
        for root in (self.snapshot,self.canonical):
            (root/'kernel/sched/walt').mkdir(parents=True)
            (root/'kernel/sysctl.c').write_bytes(SOURCE)
            (root/'kernel/sched/walt/walt.h').write_bytes(WALT)
        (self.objout/'kernel').mkdir()
        (self.objout/'kernel/sysctl.o').write_bytes(b'fake compiled kernel sysctl LLVM bitcode')
        self.cfg=self.base/'real.config';self.cfg.write_bytes(CONFIG)
        self.r12=self.base/'r12.json';self.r16=self.base/'r16.json';self.r16patch=self.base/'r16.patch';self.r19=self.base/'r19.json'
        self.expected=mod.sha256(SOURCE)
        self.r12expected=mod.sha256(R12_ORIGINAL)
        self.patchsha=mod.sha256(R16_PATCH)
        self.r16patch.write_bytes(R16_PATCH)
        self.r12.write_text(json.dumps({'status':mod.R12_STATUS,'after_sha256':{mod.TARGET:self.r12expected},
                                        'brene_changed':False,'bakasusu_nomount_changed':False}))
        self.r16.write_text(json.dumps({
                'status':mod.R16_STATUS,
                'modified_files':mod.R16_FILES,
                'before_sha256':{mod.TARGET:self.r12expected},
                'after_sha256':{mod.TARGET:self.expected},
                'patch_sha256':self.patchsha,
                'source_r15_verified':True,
                'brene_changed':False,
                'bakasusu_nomount_changed':False,
                'flash_allowed':False,
                'kernel_image_built':False,
                'vmlinux_linked':False}))
        self.r19.write_text(json.dumps({'status':'R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK',
               'all_verified':True,'type_aware_symbol_count':13,'r18_real_arm64_compiled':15,
               'flash_allowed':False}))
        self.nm=self.base/'llvm-nm'; self.nm.write_text('#!/bin/sh\nprintf "%s\\n" "---------------- T proc_douintvec_capacity"\n')
        self.nm.chmod(0o755)
        self.audit=self.base/'audit'

    def run(self,**override):
        d=dict(snapshot=self.snapshot,canonical=self.canonical,project=self.project,
               config=self.cfg,r12_proof=self.r12,r16_proof=self.r16,r16_patch=self.r16patch,r19_proof=self.r19,
               objout=self.objout,llvm_nm=self.nm,output=self.audit,expected_sha=self.expected,
               expected_r12_sha=self.r12expected,expected_patch_sha=self.patchsha)
        d.update(override);return mod.run(**d)

    def recalibrate(self):
        self.expected=mod.sha256((self.snapshot/'kernel/sysctl.c').read_bytes())
        j=json.loads(self.r16.read_text());j['after_sha256'][mod.TARGET]=self.expected
        self.r16.write_text(json.dumps(j))

    def source(self):return (self.snapshot/'kernel/sysctl.c').read_bytes()

class Units(unittest.TestCase):
    def test_01_source_pin(self):self.assertEqual(len(mod.R12_SYSCTL_SHA256),64)
    def test_02_xiaomi_pinned(self):self.assertEqual(mod.XIAOMI_SOURCE_COMMIT,'61397e524093d1ccb94769b5460825e2eaf8871e')
    def test_03_original_constant(self):self.assertEqual(mod.OEM_DEFINITION,'const int sched_user_hint_max = 1000;')
    def test_04_positive_patch(self):
        patch,diff=mod.port_oem(SOURCE,mod.sha256(SOURCE));self.assertEqual(patch.count(mod.OEM_DEFINITION.encode()),1);self.assertIn('+const int sched_user_hint_max',diff)
    def test_05_no_extra_source_change(self):
        after,_=mod.port_oem(SOURCE,mod.sha256(SOURCE));self.assertEqual(after.replace(('#ifdef CONFIG_SCHED_WALT\n'+mod.OEM_DEFINITION+'\n#endif\n').encode(),b''),SOURCE)
    def test_06_sha_mutation_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'PREIMAGE'):mod.port_oem(SOURCE+b'x',mod.sha256(SOURCE))
    def test_07_missing_anchor_denied(self):
        src=SOURCE.replace(b'Constants used',b'Constants changed')
        with self.assertRaisesRegex(mod.ContractError,'ANCHOR'):mod.port_oem(src,mod.sha256(src))
    def test_08_duplicate_anchor_denied(self):
        src=SOURCE+mod.ANCHOR.encode()
        with self.assertRaisesRegex(mod.ContractError,'ANCHOR'):mod.port_oem(src,mod.sha256(src))
    def test_09_existing_definition_denied(self):
        src=SOURCE+mod.OEM_DEFINITION.encode()
        with self.assertRaisesRegex(mod.ContractError,'ALREADY'):mod.port_oem(src,mod.sha256(src))
    def test_10_sysctl_guard_denied(self):
        src=SOURCE.replace(b'#if defined(CONFIG_SYSCTL)',b'#if 1')
        with self.assertRaisesRegex(mod.ContractError,'GUARD'):mod.port_oem(src,mod.sha256(src))
    def test_11_walt_config(self): self.assertTrue(mod.check_config(CONFIG))
    def test_12_walt_config_off(self):
        with self.assertRaisesRegex(mod.ContractError,'WALT'):mod.check_config(CONFIG.replace(b'CONFIG_SCHED_WALT=y',b'# CONFIG_SCHED_WALT is not set'))
    def test_13_sysctl_config_off(self):
        with self.assertRaisesRegex(mod.ContractError,'SYSCTL'):mod.check_config(CONFIG.replace(b'CONFIG_SYSCTL=y',b'# CONFIG_SYSCTL is not set'))
    def test_14_duplicate_config_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'WALT'):mod.check_config(CONFIG+b'CONFIG_SCHED_WALT=y\n')
    def test_15_nm_missing_symbol(self):self.assertEqual(mod.check_original_sysctl_object('---------------- T proc_douintvec_capacity\n'),[])
    def test_16_nm_undefined_ok(self):self.assertEqual(mod.check_original_sysctl_object('---------------- U sched_user_hint_max\n')[0]['kind'],'U')
    def test_17_nm_defined_R_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'ALREADY'):mod.check_original_sysctl_object('---------------- R sched_user_hint_max\n')
    def test_18_nm_defined_D_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'ALREADY'):mod.check_original_sysctl_object('00000001 D sched_user_hint_max\n')
    def test_19_nm_malformed_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'MALFORMED'):mod.check_original_sysctl_object('oops R sched_user_hint_max\n')
    def test_51_nm_weak_provider_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'ALREADY'):
            mod.check_original_sysctl_object('---------------- W sched_user_hint_max\n')
    def test_20_r12_provenance(self):
        report={'status':mod.R12_STATUS,'after_sha256':{mod.TARGET:'ab'*32},'brene_changed':False,'bakasusu_nomount_changed':False}
        mod.check_r12_proof(report,'ab'*32)
    def test_21_r12_drift_denied(self):
        report={'status':mod.R12_STATUS,'after_sha256':{mod.TARGET:'ab'*32},'brene_changed':False,'bakasusu_nomount_changed':False}
        with self.assertRaisesRegex(mod.ContractError,'SHA_DRIFT'):mod.check_r12_proof(report,'cd'*32)
    def test_22_r19_gate(self):
        a={'status':'R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK','all_verified':True,'type_aware_symbol_count':13,'r18_real_arm64_compiled':15,'flash_allowed':False}
        mod.check_r19_proof(a)
    def test_23_r19_wrong_count_denied(self):
        a={'status':'R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK','all_verified':True,'type_aware_symbol_count':12,'r18_real_arm64_compiled':15,'flash_allowed':False}
        with self.assertRaisesRegex(mod.ContractError,'PROVIDERS'):mod.check_r19_proof(a)

class Integration(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.f=Fixture(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_24_realmodel_positive(self):
        j=self.f.run();self.assertEqual(j['status'],'PASS');self.assertTrue(j['canonical_unchanged'])
        self.assertEqual((self.f.canonical/mod.TARGET).read_bytes(),SOURCE)
        self.assertEqual(self.f.source().count(mod.OEM_DEFINITION.encode()),1)
        self.assertTrue((self.f.audit/'R20_R9_XIAOMI_USER_HINT.patch').is_file())
    def _deny(self,text):
        with self.assertRaisesRegex((mod.ContractError,OSError,ValueError),text):self.f.run()
        self.assertEqual((self.f.snapshot/mod.TARGET).read_bytes()[:len(SOURCE)],SOURCE)
        if self.f.audit.exists():
            self.assertEqual(json.loads((self.f.audit/'R20_R9_SOURCE_GATE.json').read_text())['status'],'FAIL_CLOSED')
    def test_25_no_config(self):self.f.cfg.unlink();self._deny('CONFIG')
    def test_26_missing_r12(self):self.f.r12.unlink();self._deny('PROVENANCE')
    def test_27_missing_r19(self):self.f.r19.unlink();self._deny('PROVENANCE')
    def test_28_wrong_r12_sha(self):
        j=json.loads(self.f.r12.read_text());j['after_sha256'][mod.TARGET]='0'*64;self.f.r12.write_text(json.dumps(j));self._deny('GATE_SHA_DRIFT')
    def test_29_actual_source_changed(self):
        (self.f.snapshot/mod.TARGET).write_bytes(SOURCE+b'//tamper');self.f.recalibrate()
        # A staged future drift must not be accepted merely because manifest was changed.
        with self.assertRaisesRegex(mod.ContractError,'(GATE|STAGE|POSTIMAGE)_SHA_DRIFT'):self.f.run(expected_sha=mod.sha256(SOURCE))
    def test_30_missing_walt_header(self):
        (self.f.snapshot/mod.WALT_HEADER).unlink();self._deny('SOURCE_FILE_MISSING')
    def test_31_wrong_header_abi(self):
        (self.f.snapshot/mod.WALT_HEADER).write_text('extern unsigned int sched_user_hint_max;\n');self._deny('DECLARATION')
    def test_32_other_provider_duplicate(self):
        p=self.f.snapshot/mod.WALT_SYSCTL;p.write_text('const int sched_user_hint_max=1000;\n');self._deny('DUPLICATE')
    def test_33_duplicate_origin(self):
        p=self.f.snapshot/mod.TARGET;p.write_bytes(SOURCE+mod.OEM_DEFINITION.encode());self.f.recalibrate()
        with self.assertRaisesRegex(mod.ContractError,'(GATE|STAGE|POSTIMAGE)_SHA_DRIFT'):self.f.run(expected_sha=mod.sha256(SOURCE))
    def test_34_existing_nm_definition(self):
        self.f.nm.write_text('#!/bin/sh\nprintf "%s\\n" "---------------- R sched_user_hint_max"\n');self._deny('ALREADY')
    def test_35_nm_exit_failure(self):
        self.f.nm.write_text('#!/bin/sh\nexit 1\n');self._deny('PREIMAGE_FAILED')
    def test_36_original_object_missing(self):
        (self.f.objout/'kernel/sysctl.o').unlink();self._deny('SOURCE_FILE_MISSING')
    def test_37_source_symlink(self):
        p=self.f.snapshot/mod.TARGET;p.unlink();p.symlink_to(self.f.canonical/mod.TARGET);self._deny('SYMLINK')
    def test_38_source_parent_symlink(self):
        shutil.rmtree(self.f.snapshot/'kernel/sched');(self.f.snapshot/'kernel/sched').symlink_to(self.f.canonical/'kernel/sched',target_is_directory=True);self._deny('SYMLINK')
    def test_39_project_overlap_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'OVERLAP'):self.f.run(project=self.f.snapshot)
    def test_40_output_in_snapshot_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'OVERLAP'):self.f.run(output=self.f.snapshot/'bad')
    def test_41_output_in_canonical_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'OVERLAP'):self.f.run(output=self.f.canonical/'bad')
    def test_42_canonical_equals_snapshot(self):
        with self.assertRaisesRegex(mod.ContractError,'OVERLAP'):self.f.run(canonical=self.f.snapshot)
    def test_43_fail_repeated_audit_dir(self):
        self.f.run()
        with self.assertRaisesRegex(mod.ContractError,'ALREADY_EXISTS'):self.f.run()
    def test_44_original_canonical_unchanged(self):
        self.f.run();self.assertEqual((self.f.canonical/mod.TARGET).read_bytes(),SOURCE)
    def test_45_source_report_hash(self):
        report=self.f.run();self.assertEqual(report['sysctl_before_sha256'],mod.sha256(SOURCE));self.assertEqual(report['changes'],[mod.TARGET])
    def test_46_cpp_guard_config_text_preserved(self):
        j=self.f.run();t=self.f.source().decode();self.assertIn('#ifdef CONFIG_SCHED_WALT\n'+mod.OEM_DEFINITION+'\n#endif',t)
    def test_47_walt_header_unchanged(self):
        self.f.run();self.assertEqual((self.f.snapshot/mod.WALT_HEADER).read_bytes(),WALT)
    def test_48_canonical_source_drift_is_recorded(self):
        (self.f.canonical/mod.TARGET).write_bytes(SOURCE+b'// untouched other source')
        j=self.f.run();self.assertEqual(j['status'],'PASS');self.assertEqual((self.f.canonical/mod.TARGET).read_bytes(),SOURCE+b'// untouched other source')
    def test_49_null_symbol_in_r19_denied(self):
        j=json.loads(self.f.r19.read_text());j['all_verified']=False;self.f.r19.write_text(json.dumps(j));self._deny('R19_PROVIDERS_NOT_PROVEN')
    def test_50_symlink_nm(self):
        real=self.f.base/'real-nm';self.f.nm.rename(real);self.f.nm.symlink_to(real);self._deny('LLVM_NM_UNAVAILABLE')


class R16LineageTests(unittest.TestCase):
    def setUp(self):
        self.r12=mod.sha256(R12_ORIGINAL)
        self.r16=mod.sha256(SOURCE)
        self.pdigest=mod.sha256(R16_PATCH)
        self.data={
          'status':mod.R16_STATUS,'modified_files':mod.R16_FILES,
          'before_sha256':{mod.TARGET:self.r12},
          'after_sha256':{mod.TARGET:self.r16},
          'patch_sha256':self.pdigest,'source_r15_verified':True,
          'brene_changed':False,'bakasusu_nomount_changed':False,
          'kernel_image_built':False,'vmlinux_linked':False,'flash_allowed':False}
    def check(self,doc=None,observed=None,patch=None):
        return mod.check_r16_proof(self.data if doc is None else doc,
            self.r16 if observed is None else observed,
            R16_PATCH if patch is None else patch,self.r12,self.r16,self.pdigest)
    def test_52_good_chain(self):self.check()
    def test_53_wrong_R16_before_denied(self):
        self.data['before_sha256'][mod.TARGET]='a'*64
        with self.assertRaisesRegex(mod.ContractError,'LINEAGE_NOT_CHAINED'):self.check()
    def test_54_wrong_R16_after_denied(self):
        self.data['after_sha256'][mod.TARGET]='b'*64
        with self.assertRaisesRegex(mod.ContractError,'PINNED_POSTIMAGE'):self.check()
    def test_55_observed_staged_source_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'R16_TO_R20_STAGE_SHA_DRIFT'):self.check(observed='f'*64)
    def test_56_wrong_patch_content_denied(self):
        with self.assertRaisesRegex(mod.ContractError,'PATCH_NOT_AUTHENTIC'):self.check(patch=R16_PATCH+b'oops')
    def test_57_wrong_patch_gate_denied(self):
        self.data['patch_sha256']='0'*64
        with self.assertRaisesRegex(mod.ContractError,'PATCH_NOT_AUTHENTIC'):self.check()
    def test_58_wrong_R16_status_denied(self):
        self.data['status']='BUILD_SUCCESS'
        with self.assertRaisesRegex(mod.ContractError,'R16_SOURCE_PROVENANCE_MISSING'):self.check()
    def test_59_extra_modified_files_denied(self):
        self.data['modified_files']=self.data['modified_files']+['kernel/extra.c']
        with self.assertRaisesRegex(mod.ContractError,'MODIFIED_SCOPE_DRIFT'):self.check()
    def test_60_brene_flag_denied(self):
        self.data['brene_changed']=True
        with self.assertRaisesRegex(mod.ContractError,'FORBIDDEN_MUTATION'):self.check()
    def test_61_false_image_claim_denied(self):
        self.data['kernel_image_built']=True
        with self.assertRaisesRegex(mod.ContractError,'FORBIDDEN_MUTATION'):self.check()
    def test_62_unverified_R15_denied(self):
        self.data['source_r15_verified']=False
        with self.assertRaisesRegex(mod.ContractError,'FORBIDDEN_MUTATION'):self.check()
    def test_63_missing_source_record_denied(self):
        del self.data['before_sha256'][mod.TARGET]
        with self.assertRaisesRegex(mod.ContractError,'LINEAGE_NOT_CHAINED'):self.check()
    def test_64_R16_source_API_count_denied(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            s=f.source().replace(b'int proc_douintvec_capacity',b'int proc_wrong',1)
            (f.snapshot/mod.TARGET).write_bytes(s)
            f.recalibrate()
            with self.assertRaisesRegex(mod.ContractError,'(PINNED_POSTIMAGE_SHA_DRIFT|CAPACITY_SOURCE_ANCHOR_MISSING)'):
                f.run()
    def test_65_missing_R16_gate_denied(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            f.r16.unlink()
            with self.assertRaisesRegex(mod.ContractError,'MISSING_CONFIG_OR_PROVENANCE'):f.run()
    def test_66_missing_R16_patch_denied(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            f.r16patch.unlink()
            with self.assertRaisesRegex(mod.ContractError,'MISSING_CONFIG_OR_PROVENANCE'):f.run()
    def test_67_R16_patch_tampered_integration(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            f.r16patch.write_bytes(b'R16 PATTERN MISMATCH')
            with self.assertRaisesRegex(mod.ContractError,'PATCH_NOT_AUTHENTIC'):f.run()
    def test_68_R16_origin_chain_success(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            r=f.run()
            self.assertEqual(r['status'],'PASS')
            self.assertEqual(r['sysctl_before_sha256'],mod.sha256(SOURCE))
            self.assertEqual(r['expected_r12_sysctl_sha256'],mod.sha256(R12_ORIGINAL))
            self.assertEqual(r['expected_r16_sysctl_sha256'],mod.sha256(SOURCE))
            self.assertTrue(r['canonical_unchanged'])
    def test_69_guard_against_unexpected_SYSCTL_false(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            f.cfg.write_text('CONFIG_SCHED_WALT=y\n# CONFIG_SYSCTL is not set\n')
            with self.assertRaisesRegex(mod.ContractError,'SYSCTL_CONFIG_REQUIRED'):f.run()
    def test_70_named_errors_preserved_in_failure_report(self):
        with tempfile.TemporaryDirectory() as d:
            f=Fixture(d)
            f.r16patch.write_bytes(b'changed')
            with self.assertRaisesRegex(mod.ContractError,'PATCH_NOT_AUTHENTIC'):f.run()
            result=json.loads((f.audit/'R20_R9_SOURCE_GATE.json').read_text())
            self.assertEqual(result['status'],'FAIL_CLOSED')
            self.assertIn('observed_snapshot_sysctl_sha256',result)
            self.assertEqual(result['observed_snapshot_sysctl_sha256'],mod.sha256(SOURCE))

if __name__=='__main__':unittest.main()
