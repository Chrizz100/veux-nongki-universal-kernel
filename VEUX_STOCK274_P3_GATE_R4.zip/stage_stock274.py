#!/usr/bin/env python3
"""P3: reconstruct exact proven 5.4.274 P2; APPLY CASS deletion locally;
export authenticated Xiaomi WALT donor and version-specific merge evidence.

All edits are to the job's temporary vendor source only. Repository main and
stock reference remain unchanged. Produces no kernel Image, boot.img or AK3.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import replay_p2_source as replay
import walt_source_audit as walt

P2_TOOL_BLOB='10cc6d1a5cd8020d4783073070f2a57f2b9b769d'
EXPECTED_PATHS = {
 'arch/arm64/configs/veux_defconfig', 'init/Kconfig',
 'kernel/sched/fair.c','kernel/sched/rt.c',
 'kernel/sched/cass.c','kernel/sched/cass_rt.h'
}

def checked(cmd: list[str], *, cwd:Path | None = None, timeout:int=60) -> str:
    p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=timeout)
    if p.returncode:raise RuntimeError('COMMAND_FAILED '+repr(cmd[:5])+' '+p.stderr[-400:])
    return p.stdout.strip()


def stage_official_walt_files_only(kernel:Path, donor_dir:Path, output:Path, p3_tree:str) -> dict:
    """Install OFFICIAL WALT donor files in a temporary CI source only.

    Does not touch Kconfig/Makefile/host hooks or claim functional porting.
    Records an exact patch which can later be reviewed and linked to 5.4.274.
    """
    dest=kernel/'kernel/sched/walt'
    if dest.exists() or dest.is_symlink(): raise RuntimeError('WALT_TREE_ALREADY_EXISTS')
    if checked(['git','-C',str(kernel),'rev-parse','HEAD^{tree}'])!=p3_tree:
        raise RuntimeError('P3_PARENT_TREE_DRIFT_BEFORE_WALT')
    dest.mkdir(parents=True)
    for name,blob in sorted(walt.FILES.items()):
        original=donor_dir/name
        if not original.is_file() or original.is_symlink():
            raise RuntimeError('DONOR_FILE_MISSING_OR_UNSAFE '+name)
        data=original.read_bytes()
        if walt.gitblob(data)!=blob:raise RuntimeError('DONOR_CHANGED '+name)
        (dest/name).write_bytes(data)
    checked(['git','-C',str(kernel),'add','--','kernel/sched/walt'])
    changed=set(checked(['git','-C',str(kernel),'diff','--cached','--name-only']).splitlines())
    expected={'kernel/sched/walt/'+n for n in walt.FILES}
    if changed!=expected:raise RuntimeError('WALT_DONOR_PATH_SCOPE '+str(sorted(changed)))
    # The immutable official Xiaomi WALT donor includes precisely ONE inherited
    # Git whitespace warning: trace.c line 82, a blank line at EOF. Preserve the
    # original bytes; do not silently reformat vendor code or ignore other issues.
    strict = subprocess.run(
        ['git','-C',str(kernel),'diff','--cached','--check'],
        text=True, capture_output=True, timeout=60)
    accepted = 'kernel/sched/walt/trace.c:82: new blank line at EOF.\n'
    if strict.returncode != 2 or strict.stdout != accepted or strict.stderr:
        raise RuntimeError('WALT_DONOR_WHITESPACE_UNEXPECTED '
                           +f'rc={strict.returncode} '
                           +repr((strict.stdout+strict.stderr)[-450:]))
    # Only suppress the blank-at-EOF *diagnostic* for the exact hash-pinned
    # vendor files. This still rejects trailing spaces and space-before-tabs.
    checked(['git','-C',str(kernel),'-c','core.whitespace=-blank-at-eof',
             'diff','--cached','--check'])
    patchdata=checked(['git','-C',str(kernel),'diff','--cached','--binary','--no-color'])
    patchpath=output/'P3_TO_P4_OFFICIAL_WALT_DONOR_FILES_ONLY.patch'
    patchpath.write_text(patchdata+'\n')
    checked(['git','-C',str(kernel),'-c','user.name=github-actions[bot]',
             '-c','user.email=41898282+github-actions[bot]@users.noreply.github.com',
             'commit','-m','p4: stage official Xiaomi WALT source files (DORMANT; host port unapproved)'])
    parent=checked(['git','-C',str(kernel),'rev-parse','HEAD^'])
    if checked(['git','-C',str(kernel),'rev-parse',parent+'^{tree}'])!=p3_tree:
        raise RuntimeError('WALT_CANDIDATE_PARENT_CHANGED')
    if checked(['git','-C',str(kernel),'status','--porcelain','--untracked-files=all']):
        raise RuntimeError('WALT_CANDIDATE_DIRTY')
    return {'dormant_walt_file_count':len(expected),
            'dormant_walt_source_tree':checked(['git','-C',str(kernel),'rev-parse','HEAD^{tree}']),
            'patch_sha256':hashlib.sha256(patchpath.read_bytes()).hexdigest(),
            'kernel_config_walt_enabled':False, 'scheduler_hook_integrated':False,
            'compiled':False, 'flashable':False}


def stage(workspace:Path, output:Path) -> dict:
    workspace=workspace.resolve(strict=True)
    output=output.resolve()
    if output.exists() or output.is_relative_to(workspace/'kernel'):
        raise RuntimeError('UNSAFE_OUTPUT')
    project=workspace/'project'
    kernel=workspace/'kernel'
    original=project/'common/stock274/source_only_r2/prepare_stock274_p3.py'
    if not original.is_file() or replay.gitblob(original.read_bytes())!=P2_TOOL_BLOB:
        raise RuntimeError('IMPORTED_P2_TOOL_DRIFT')
    output.mkdir(parents=True)
    p2logs=output/'P2_SOURCE_REPLAY_LOGS'
    p2= replay.replay(workspace/'historical'/replay.DONOR_WORKFLOW,
                      workspace,p2logs)
    p3_patch=output/'P3_CASS_REMOVAL'
    checked(['python3',str(original),'--p2-source',str(kernel),'--output',str(p3_patch)], timeout=100)
    diff=p3_patch/'P2_TO_P3_REMOVE_CASS.patch'
    checked(['git','-C',str(kernel),'apply','--check','--whitespace=error',str(diff)])
    checked(['git','-C',str(kernel),'apply','--index','--whitespace=error',str(diff)])
    changed=set(checked(['git','-C',str(kernel),'diff','--cached','--name-only']).splitlines())
    if changed!=EXPECTED_PATHS:raise RuntimeError('CASS_PATCH_SCOPE_CHANGED '+repr(sorted(changed)))
    checked(['git','-C',str(kernel),'diff','--cached','--check'])
    checked(['git','-C',str(kernel),'-c','user.name=github-actions[bot]',
             '-c','user.email=41898282+github-actions[bot]@users.noreply.github.com',
             'commit','-m','p3: remove Positron CASS source from pinned 5.4.274 P2 (source only)'])
    parent=checked(['git','-C',str(kernel),'rev-parse','HEAD^'])
    if checked(['git','-C',str(kernel),'rev-parse',parent+'^{tree}'])!=replay.P2_TREE:
        raise RuntimeError('CASS_PATCH_BASE_NOT_PROVEN')
    if checked(['git','-C',str(kernel),'status','--porcelain','--untracked-files=all']):
        raise RuntimeError('KERNEL_STAGE_DIRTY')
    aftertree=checked(['git','-C',str(kernel),'rev-parse','HEAD^{tree}'])
    report = walt.audit(kernel,output/'WALT_REFERENCE_AND_CONFLICT_ANALYSIS')
    donor_state=stage_official_walt_files_only(
        kernel,output/'WALT_REFERENCE_AND_CONFLICT_ANALYSIS/xiaomi-original-walt',
        output,aftertree)
    result={
       'kernel':'5.4.274', 'source':'pinned KSU2-P2-v5 historical proven Git tree',
       'p2_tree':p2['git_tree'], 'p3_cass_free_tree':aftertree,
       'cass_patch_sha256':hashlib.sha256(diff.read_bytes()).hexdigest(),
       'cass_patch_paths':sorted(changed),
       'cass_patch_git_apply':'PASS',
       'cass_removal_applied_in_temporary_source':True,
       'kernel_source_repo_modified':False,
       'WALT_donor_files_authenticated':report['walt_donor_source_count'],
       'WALT_dormant_source_files_staged_in_CI':donor_state['dormant_walt_file_count'],
       'p4_dormant_walt_source_tree':donor_state['dormant_walt_source_tree'],
       'walt_subtree_only_patch_sha256':donor_state['patch_sha256'],
       'WALT_5_4_274_integration_proven':False,
       'kernel_compiled':False,'stock_oem_abi_pass':False,'flashable':False,
       'status':'CASS_REMOVED_AND_OFFICIAL_WALT_FILES_STAGED_IN_CI__INTEGRATION_UNAPPROVED',
    }
    (output/'P3_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    with (output/'SHA256SUMS.txt').open('w') as f:
        for path in sorted(output.rglob('*')):
            if path.is_file() and path.name!='SHA256SUMS.txt':
                f.write(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(output))+'\n')
    summ=os.environ.get('GITHUB_STEP_SUMMARY')
    if summ:
        with open(summ,'a') as f:
            f.write('## VEUX 5.4.274 Stock-Restoration P3\n'
                    '- CASS removal applied to exact P2 CI source: **PASS**\n'
                    '- Xiaomi WALT original 11 files staged (DORMANT): **PASS**\n'
                    '- 5.4.274 WALT semantic port / ABI / device: **NOT YET PASSED**\n'
                    '- Repository write / flash / build: **NONE**\n')
    return result

if __name__=='__main__':
    try:
        w=Path(os.environ.get('GITHUB_WORKSPACE',Path.cwd()))
        out=Path(os.environ.get('RUNNER_TEMP',w))/'VEUX_274_P3_OUTPUT'
        x=stage(w,out)
        print('P3_PATCH=APPLIED_SOURCE_ONLY; WALT_DONOR=11_FILES_STAGED_DORMANT; BUILD=NOT_RUN')
        print('P3_TREE='+x['p3_cass_free_tree'])
    except Exception as e:
        print('P3_FAIL_CLOSED: '+str(e),file=sys.stderr)
        sys.exit(2)
