#!/usr/bin/env python3
"""5.4.274 stock WALT pre-port provenance + semantic conflict evidence.

Reads untouched Xiaomi official VEUX tree through git objects already fetched
by historical P2-v5 source recipe. Outputs original WALT files and a targeted
merge-probe report. Source and kernel build configuration are NOT modified.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

XIAOMI_REF = 'refs/remotes/xiaomi/veux-r-oss'
XIAOMI_SHA = '61397e524093d1ccb94769b5460825e2eaf8871e'
P2_TREE = '16ce899d4549819d42d76b423ebcbd51f1b82a61'
FILES = {
 'Makefile':'8bf42cb669afabc17f69bc16cf74f17fcaf5cdd0',
 'boost.c':'c37185e293d0ac7affe9b13124fcf76339fbce4e',
 'core_ctl.c':'af838bd1c71e728d65dcdfee792b1379b07336e5',
 'cpu-boost.c':'9b2363cf275afbeadbc57b112e89818d0e019320',
 'qc_vas.c':'ce49eac6d5907108ed46aa48b7ead5146b49618e',
 'qc_vas.h':'3b67a54946557d92b4582f990e3f015bceb3d0ae',
 'sched_avg.c':'4a5efa4118b3c6605d74380ff028d66e9a24668b',
 'trace.c':'7c06ce1fda642d026295ec87f190df55176c1cf9',
 'trace.h':'5b01043d226142ac380d76f924542719ef863e9e',
 'walt.c':'9d851c1dd315e2f4fb2385b5aa4a0c2749908b7d',
 'walt.h':'9a678f0bbb68d92aa670991c8899a5253f51322e',
}

HOSTS = (
 'kernel/sched/core.c','kernel/sched/fair.c','kernel/sched/sched.h',
 'kernel/sched/rt.c','kernel/sched/Makefile',
 'kernel/sched/cpufreq_schedutil.c','kernel/sched/topology.c',
 'kernel/sched/debug.c','kernel/sched/pelt.c',
 'drivers/cpufreq/cpufreq.c','include/linux/sched.h',
 'include/linux/sched/sysctl.h','init/Kconfig',
)
SYMBOL = re.compile(r'\bwalt[_A-Za-z0-9]*\b|\bCONFIG_SCHED_WALT\b|\bWALT\b',re.I)


def run(root: Path, *args: str, check: bool = True, timeout: int=40) -> subprocess.CompletedProcess:
    cmd=['git','-C',str(root),*args]
    p=subprocess.run(cmd,capture_output=True,check=False,timeout=timeout)
    if check and p.returncode:
        raise RuntimeError('GIT_FAILED '+repr(args[:3])+': '+p.stderr.decode(errors='replace')[-300:])
    return p


def gitblob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def read_git(root: Path, rev: str, path: str) -> bytes | None:
    p=run(root,'show',rev+':'+path,check=False)
    if p.returncode: return None
    return p.stdout



def classify_merge_file_result(proc: subprocess.CompletedProcess, path: str) -> dict:
    """git merge-file returns the count of conflict hunks (capped at 127).

    A positive exit code is NOT necessarily a tool error. However, neither
    conflicts nor clean textual merging proves semantic WALT compatibility.
    Reject negative/tool-error statuses and nonzero exits without conflict
    markers. Never apply this diagnostic result to kernel source.
    """
    code = proc.returncode
    markers = sum(line.startswith(b'<<<<<<< ') for line in proc.stdout.splitlines())
    if code == 0 and markers == 0:
        status = 'TEXT_MERGE_CLEAN_UNREVIEWED'
    elif 1 <= code <= 127 and markers >= 1:
        # Git caps the conflict count at 127; do not imply a truncated
        # status gives the exact number of conflicts.
        if code != 127 and markers != code:
            raise RuntimeError('MERGE_COUNT_MISMATCH '+path+' exit='+str(code)+' markers='+str(markers))
        if code == 127 and markers < 127:
            raise RuntimeError('MERGE_CAPPED_COUNT_MISMATCH '+path)
        status = 'CONFLICTS'
    else:
        raise RuntimeError('MERGE_TOOL_ERROR '+path+' exit='+str(code)+
                           ' markers='+str(markers)+' stderr='+
                           proc.stderr.decode(errors='replace')[-180:])
    return {'diagnostic_merge': status, 'conflict_marker_count': markers,
            'merge_file_exit_status': code, 'semantic_merge_approved':False}


def audit(root: Path, out: Path) -> dict:
    root=root.resolve(strict=True)
    out=out.resolve()
    if out.exists() or out.is_relative_to(root):raise RuntimeError('OUTPUT_UNSAFE')
    if run(root,'rev-parse','--show-toplevel').stdout.decode().strip()!=str(root):raise RuntimeError('NOT_GIT_ROOT')
    if run(root,'status','--porcelain','--untracked-files=all').stdout:raise RuntimeError('SOURCE_DIRTY')
    xsha=run(root,'rev-parse',XIAOMI_REF).stdout.decode().strip()
    if xsha != XIAOMI_SHA:raise RuntimeError('STOCK_DONOR_MOVED '+xsha)
    # CASS removed and P2 parent still accessible. This is a source-only P3, not a flashable kernel.
    parent=run(root,'rev-parse','HEAD^').stdout.decode().strip()
    parent_tree=run(root,'rev-parse',parent+'^{tree}').stdout.decode().strip()
    if parent_tree != P2_TREE:raise RuntimeError('P3_PARENT_NOT_P2 '+parent_tree)
    if (root/'kernel/sched/cass.c').exists() or (root/'kernel/sched/cass_rt.h').exists():
        raise RuntimeError('CASS_FILES_STILL_PRESENT')
    if (root/'kernel/sched/walt').exists(): raise RuntimeError('WALT_ALREADY_ADDED')
    p3tree=run(root,'rev-parse','HEAD^{tree}').stdout.decode().strip()
    common=run(root,'merge-base','HEAD',XIAOMI_REF,check=False)
    shared=common.stdout.decode().strip() if common.returncode==0 else ''
    out.mkdir(parents=True)
    donor=out/'xiaomi-original-walt';donor.mkdir()
    files=[]
    for name,pin in sorted(FILES.items()):
        rel='kernel/sched/walt/'+name
        content=read_git(root,XIAOMI_REF,rel)
        if not content or gitblob(content)!=pin:raise RuntimeError('WALT_FILE_PIN_MISMATCH '+rel)
        (donor/name).write_bytes(content)
        files.append({'path':rel,'git_blob':pin,'sha256':hashlib.sha256(content).hexdigest(),'bytes':len(content)})
    hosts=[]
    for i,rel in enumerate(HOSTS):
        base=read_git(root,shared,rel) if shared else None
        stock=read_git(root,XIAOMI_REF,rel)
        ours=read_git(root,'HEAD',rel)
        item={'path':rel,'stock_present':stock is not None,'p3_present':ours is not None,
              'common_present':base is not None,'semantic_merge_approved':False}
        if stock is None or ours is None:
            item['status']='PATH_MISSING_REVIEW_REQUIRED'
        else:
            orefs=sorted(set(m.group() for m in SYMBOL.finditer(ours.decode(errors='replace'))))
            srefs=sorted(set(m.group() for m in SYMBOL.finditer(stock.decode(errors='replace'))))
            item.update(p3_walt_symbols=orefs[:35],stock_walt_symbols=srefs[:35],
                        stock_sha256=hashlib.sha256(stock).hexdigest(),
                        p3_sha256=hashlib.sha256(ours).hexdigest())
            if base is not None:
                # Three-way text merge is DIAGNOSTIC ONLY: even exit=0 does not mean
                # safe 5.4.274 integration. Files are never installed into source.
                import tempfile
                with tempfile.TemporaryDirectory() as td:
                    paths=[]
                    for j,data in enumerate((ours,base,stock)):
                        f=Path(td)/str(j);f.write_bytes(data);paths.append(str(f))
                    proc=subprocess.run(['git','merge-file','-p','--diff3',*paths],
                                        capture_output=True,timeout=75)
                    item.update(classify_merge_file_result(proc,rel))
                    if proc.stdout!=ours:
                        (out/f'host_merge_{i:02d}.txt').write_bytes(proc.stdout)
                    item['status']='MANUAL_CODE_REVIEW_REQUIRED'
            else:item['status']='NO_COMMON_BASE_MANUAL_REVIEW'
        hosts.append(item)
    result={'kernel':'5.4.274','p2_parent_tree':P2_TREE,'p3_cass_free_tree':p3tree,
            'xiaomi_official_source':XIAOMI_SHA,'common_ancestor':shared or None,
            'walt_donor_source_count':len(files),'walt_files':files,
            'scheduler_host_merge_probes':hosts,
            'walt_5_4_274_port_compiled':False,
            'walt_semantic_rebase_done':False,'stock_vendor_abi_pass':False,
            'flashable':False,'release_status':'BLOCKED_UNTIL_WALT_PORT_AND_ABI_BUILD_PASS',
            'operation_scope':'read-only comparison; donor files copied ONLY into artifact'}
    (out/'WALT_PORT_RISK_REPORT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    if run(root,'status','--porcelain','--untracked-files=all').stdout:
        raise RuntimeError('SOURCE_MUTATED_BY_AUDIT')
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--kernel',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path)
    args=ap.parse_args()
    r=audit(args.kernel,args.output)
    print('OFFICIAL_WALT_FILES=11; CASS_REMOVED=YES; PORT_COMPILE=NOT_RUN; REVIEW_REQUIRED='+str(len(r['scheduler_host_merge_probes'])))

if __name__=='__main__':
    try:main()
    except Exception as e:
        print('WALT_SOURCE_PROBE_BLOCKED '+str(e),file=sys.stderr)
        sys.exit(2)
