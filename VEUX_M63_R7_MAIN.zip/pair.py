"""Generate the exact-Stock-input, read-only AK3 and replay its entry on regular files."""

import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile


def create(upstream, stock_path, image_path, dest):
    sys.path.insert(0, str(upstream.resolve()))
    from layout.boot import unpack_m45, make_image, sha, need

    stock_path = stock_path.resolve()
    kernel = image_path.read_bytes()
    dest.mkdir(parents=True, exist_ok=True)
    qemu = Path(shutil.which("qemu-arm")).resolve()
    with tempfile.TemporaryDirectory(dir=stock_path.parent) as temp:
        work = Path(temp).resolve()
        factory = unpack_m45(work)
        stock = stock_path.read_bytes()
        candidate, page, index = make_image(factory, stock, kernel)
        def parts(image):
            ksize, rsize = struct.unpack_from("<II", image, 8)
            start = 4096 + (ksize + 4095) // 4096 * 4096
            return image[4096:4096 + ksize], image[start:start + rsize]
        factory_kernel, factory_rd = parts(stock)
        built_kernel, built_rd = parts(candidate)
        need(sha(factory_kernel) == "6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b", "OEM kernel")
        need(built_rd == factory_rd and built_kernel == kernel, "Exact original ramdisk and new kernel")
        need(stock[:8] == candidate[:8] and stock[12:4096] == candidate[12:4096], "OEM boot header except kernel size")
        signed = factory.boot_descriptor(
            (factory.ROOT / "stock-vbmeta.bin").read_bytes(), True
        )
        need(
            hashlib.sha256(signed.salt + stock[: signed.image_size]).digest()
            == signed.digest,
            "OEM reference vbmeta",
        )
        candidate_digest = hashlib.sha256(
            signed.salt + candidate[: signed.image_size]
        ).hexdigest()
        with zipfile.ZipFile(Path(__file__).with_name("ak3-tools.zip")) as template:
            arm = work / "magiskboot"
            arm.write_bytes(template.read("tools/magiskboot"))
            arm.chmod(0o700)
            draft = work / "repack"
            draft.mkdir()
            subprocess.run(
                [qemu, arm, "unpack", "-n", "-h", stock_path], cwd=draft, check=True
            )
            need(
                sha((draft / "ramdisk.cpio").read_bytes()) == factory.RAMDISK,
                "Unpacked original ramdisk",
            )
            (draft / "kernel").write_bytes(kernel)
            subprocess.run(
                [qemu, arm, "repack", stock_path, "draft.img"],
                env={**os.environ, "PATCHVBMETAFLAG": "false"},
                cwd=draft,
                check=True,
            )
            raw = (draft / "draft.img").read_bytes()
            offset = index * 4096
            need(
                len(raw) == len(candidate)
                and raw[:offset] == candidate[:offset]
                and raw[offset + 4096 :] == candidate[offset + 4096 :],
                "Independent stock-layout repack",
            )
            render = (factory.ROOT / "render.sh").read_text()
            updates = {
                factory.KERNEL: sha(kernel),
                sha((factory.ROOT / "boot-avb-page.bin").read_bytes()): sha(page),
                "e60bce1b0268e6122546f0706cd8985f4a887fbd0f7a57d0c8191a1f4f7aa224": sha(
                    raw
                ),
                factory.BOOT: sha(candidate),
                "seek=16287": f"seek={index}",
            }
            for old, new in updates.items():
                need(render.count(old) == 1, "Expected stock render field " + old)
                render = render.replace(old, new)
            entry = (factory.ROOT / "anykernel.sh").read_text().replace("M45", "M63-R7")
            ak = work / "VEUX_M63-R7_AK3_NOFLASH.zip"
            with zipfile.ZipFile(ak, "w") as archive:
                for item in template.infolist():
                    archive.writestr(item, template.read(item))
                for name, content in {
                    "Image": kernel,
                    "anykernel.sh": entry.encode(),
                    "veux/render.sh": render.encode(),
                    "veux/boot-avb-page.bin": page,
                }.items():
                    item = zipfile.ZipInfo(name, (2026, 11, 22, 0, 0, 0))
                    item.external_attr = (
                        0o100755 if name.endswith(".sh") else 0o100644
                    ) << 16
                    item.compress_type = zipfile.ZIP_DEFLATED
                    archive.writestr(item, content)
        with zipfile.ZipFile(ak) as archive:
            need(
                archive.testzip() is None
                and archive.namelist().count("Image") == 1
                and archive.read("Image") == kernel,
                "AK3 integrity",
            )
        replay = factory.test_entry(ak, stock_path, candidate, work, qemu)
        need(replay == sha(candidate), "AK3 slot replay")
        (dest / "VEUX_M63-R7_boot_NOFLASH.img").write_bytes(candidate)
        shutil.copyfile(ak, dest / ak.name)
        report = dict(
            kernel_sha256=sha(kernel),
            stock_boot_sha256=sha(stock),
            stock_ramdisk_sha256=factory.RAMDISK,
            boot_sha256=replay,
            ak3_sha256=sha(ak.read_bytes()),
            partition_bytes=len(candidate),
            static_boot_pass=True,
            boot_header_version=struct.unpack_from("<I", candidate, 40)[0],
            original_header_identical_except_kernel_size=True,
            ramdisk_bytes=len(built_rd),
            original_ramdisk_byte_identical=True,
            checked_stock_slots=["a", "b"],
            rejected_inputs=3,
            original_vbmeta_expected=signed.digest.hex(),
            candidate_digest_under_original_vbmeta=candidate_digest,
            original_vbmeta_matches_candidate=candidate_digest == signed.digest.hex(),
            device_pass=False,
            flash_allowed=False,
        )
        (dest / "M63-R7-Stock-Boot.json").write_text(json.dumps(report, indent=2) + "\n")
        print("PASS two Stock slot replays and three rejection cases")


if __name__ == "__main__":
    create(*(Path(arg) for arg in sys.argv[1:]))
