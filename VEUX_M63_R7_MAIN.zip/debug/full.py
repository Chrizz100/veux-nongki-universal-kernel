"""Disassemble each executable ELF section into a word-checked, compressed table."""
import argparse
import json
import shutil
import struct
import subprocess
from pathlib import Path

BASE=0xffffffc010080000

def sections(elf):
    with elf.open("rb") as f:
        h=f.read(64)
        off=struct.unpack_from("<Q",h,40)[0]
        step,count,idx=struct.unpack_from("<HHH",h,58)
        f.seek(off)
        sh=[struct.unpack("<IIQQQQIIQQ",f.read(step)) for _ in range(count)]
        f.seek(sh[idx][4]); names=f.read(sh[idx][5])
    return [(names[n:names.index(0,n)].decode(),a-BASE,a-BASE+size) for n,t,flags,a,_,size,*_ in sh if flags & 4 and t==1 and size]

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("analyzer",type=Path);ap.add_argument("out",type=Path);ap.add_argument("dest",type=Path)
    args=ap.parse_args()
    dest=args.dest.resolve();dest.mkdir(parents=True,exist_ok=True)
    elf=(args.out/"vmlinux").resolve();raw=(args.out/"arch/arm64/boot/Image").resolve()
    slices=sections(elf)
    if [name for name,_,_ in slices] != [".head.text",".text",".init.text",".exit.text",".altinstr_replacement"]:
        raise ValueError("Unexpected executable sections")
    ranges=dest/"R7-Sektionen.txt";ranges.write_text("".join(f"{n} {a:x} {e:x}\n" for n,a,e in slices))
    log=dest/"R7-Abschnittsprotokoll.txt"
    target=dest/"R7-ARM64-LLDB.tsv.zst"
    with target.open("wb") as f, log.open("w") as err:
        with subprocess.Popen([args.analyzer.resolve(),elf,raw,ranges],stdout=subprocess.PIPE,stderr=err) as p:
            if shutil.which("zstd"):
                subprocess.run(["zstd","-q","-3","-c"],stdin=p.stdout,stdout=f,check=True)
            else:
                import zstandard
                with zstandard.ZstdCompressor(level=3).stream_writer(f,closefd=False) as dst:
                    shutil.copyfileobj(p.stdout,dst,1<<20)
            if p.wait()!=0:
                raise RuntimeError(log.read_text())
    counts=[s.split() for s in log.read_text().splitlines()]
    if len(slices)!=len(counts): raise ValueError("Section report incomplete")
    results={}
    for (n,a,e),v in zip(slices,counts):
        if v[:3]!=[n,f"{a:x}",f"{e:x}"] or int(v[3])!=(e-a)//4:
            raise ValueError("Coverage "+n)
        results[n]={"words":int(v[3]),"no_mnemonic_or_data":int(v[4])}
    (dest/"R7-Vollstaendigkeit.json").write_text(json.dumps(results,indent=2)+"\n")
    print(sum(x["words"] for x in results.values()),"file-backed ARM64 words")

if __name__=="__main__":
    main()
