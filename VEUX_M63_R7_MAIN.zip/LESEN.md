# VEUX M63-R7

Dieser Stand repariert die Verbindung zwischen Xiaomis Touch-Schnittstelle, Goodix GT9896 und dem internen Display. Die Referenz ist das ausgelieferte boot.img von HyperOS 1.0.12.0.TKCMIXM. M63-R6 brachte das Testgerät bis zur Android-Displaysperre. Dort fror es ein. Ein physischer Test für R7 steht aus.

## GitHub Actions

Lege VEUX_M63_R7_MAIN.zip unverändert im Stammverzeichnis und VEUX_M63_R7_STOCK_TOUCH_NOFLASH.yml unter .github/workflows/ ab. Das Paket im Repository bleibt gepackt. Der Workflow ist über „Run workflow“ auf dem Standardbranch oder per Push auf dem Branch repair/m63-r7-stock-touch startbar. Der erste Lauf benötigt das verifizierte R6-Quellartefakt 14843626326 aus dem Repository Chrizz100/veux-nongki-universal-kernel. Die folgenden Läufe können dieselbe Eingabe aus dem Cache beziehen. Der Source-Hash und die Prüfsummen der veränderten Dateien stehen in source.json.

Der Workflow baut den Kernel einmal mit der eingebetteten R6-Konfiguration und Android-Clang r416183b. Er liest Xiaomis ursprüngliches boot.img und den neuen ARM64-Code mit LLDB, prüft die Vendor-Importe und verpackt den Kernel mit der originalen Ramdisk. Der abschließende Vergleich protokolliert alle fünf ausführbaren R7-Abschnitte. Die ausführlichen Debug-Symbole und der vollständige Quellstand werden als eigene Artefakte ausgegeben.

## Lokaler Wiederaufbau

Python 3.12, Git, die Kernel-Bauwerkzeuge, LLDB 19 und Clang r416183b werden benötigt. Die Dateien im Paket enthalten die Bau- und Prüfskripte. Bei vorhandenem R6-Quellartefakt bereitet prepare.py den Quellbaum direkt vor. Alternativ kann prepare.py mit der Option --comparison das bereits gesicherte VEUX_M63-R6_Quellenvergleich.zip verwenden. Diese Möglichkeit funktioniert auch nach Ablauf des alten Actions-Artefakts. Ein vorhandenes Xiaomi-boot.img wird zuerst anhand seines SHA-256 geprüft. Fehlt die Datei, versucht das Skript die Wiederherstellung aus der passenden Xiaomi-OTA. Der Quell-Zielordner muss neu sein.

```sh
python3 prepare.py --comparison VEUX_M63-R6_Quellenvergleich.zip work/src /pfad/zum/originalen/boot.img
export LLDB=lldb-19
bash build.sh work /pfad/zu/clang-r416183b /pfad/zum/originalen/boot.img
```

## Grenzen des Prüfpakets

Das AK3 liest die Ausgangsdatei und vergleicht den Repack. Die Arbeitsdateien für beide Slots werden beim Bauen als normale Dateien angelegt. Die Skripte schreiben keine Bootpartition. Der Hash im separaten, signierten OEM-vbmeta gehört zum ursprünglichen Xiaomi-Kernel. Der neue Kernel hat einen eigenen Digest. Der Abschluss dieser Prüfungen erteilt keine Flash-Freigabe.
