"""Load a verified R6 archive and apply the R7 changes out of tree."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
from tempfile import TemporaryDirectory
import zipfile

HERE=Path(__file__).resolve().parent
ARCHIVE="f10564a049a9523de2dda32181822db89b952109571aa6b28e18ac962c936f63"
TAR="9af9a299fd9db068b14120fd17e3f22814fa9fb4e967ff29942cf269d422024c"
BOOT="ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"

def digest(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

def verify(path, expected):
    if digest(path)!=expected:
        raise ValueError(f"SHA-256 {path.name}")

def stock(path):
    if path.is_file():
        verify(path,BOOT)
        return
    path.parent.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory(dir=path.parent) as d:
        tmp=Path(d)
        with zipfile.ZipFile(HERE/"tools/layout/m45-base.zip") as z:
            for n in ("stock_ota.py","stock-ota.json"):
                z.extract(n,tmp)
        sys.path.insert(0,str(tmp))
        from stock_ota import restore
        restore(tmp/"boot.img")
        verify(tmp/"boot.img",BOOT)
        (tmp/"boot.img").replace(path)

def prepare(source, dest, comparison):
    m=json.loads((HERE/"source.json").read_text())
    verify(HERE/"veux-r7.patch",m["patch_sha256"])
    dest.parent.mkdir(exist_ok=True,parents=True)
    if dest.exists():
        raise ValueError(f"Destination exists: {dest}")
    with TemporaryDirectory(dir=dest.parent) as d:
        stage=Path(d); tree=stage/"src"; tree.mkdir()
        if comparison:
            with zipfile.ZipFile(source) as z:
                for n in ("MiCode-61397e5.tar.gz","Quellzeilen.zip"):
                    z.extract(n,stage)
            subprocess.run([sys.executable,HERE/"restore_comparison.py",stage/"verified","--nur-git","--original",stage/"MiCode-61397e5.tar.gz","--differenzen",stage/"Quellzeilen.zip"],check=True)
            repo=stage/"verified/Vergleich.git"
            with subprocess.Popen(["git","--git-dir",repo,"archive","R6"],stdout=subprocess.PIPE) as proc:
                with tarfile.open(fileobj=proc.stdout,mode="r|") as tf:
                    tf.extractall(tree,filter="tar")
                if proc.wait():
                    raise RuntimeError("Could not read the verified R6 Git tree")
        else:
            verify(source,ARCHIVE)
            with zipfile.ZipFile(source) as z:
                src_tar=Path(z.extract("M63-R6-kernel-source.tar.gz",stage))
            verify(src_tar,TAR)
            with tarfile.open(src_tar) as tf:
                tf.extractall(tree,filter="tar")
            src_tar.unlink()
        def files_match(key):
            for name, hashes in m["files"].items():
                file=tree/name
                if hashes[key] is None:
                    if file.exists(): raise ValueError("Unexpected "+name)
                else:
                    verify(file,hashes[key])
        files_match("before")
        subprocess.run(["git","apply","--check",HERE/"veux-r7.patch"],cwd=tree,check=True)
        subprocess.run(["git","apply",HERE/"veux-r7.patch"],cwd=tree,check=True)
        files_match("after")
        tree.rename(dest)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("source",type=Path);ap.add_argument("destination",type=Path)
    ap.add_argument("stock_boot",type=Path)
    ap.add_argument("--comparison",action="store_true",help="Use VEUX_M63-R6_Quellenvergleich.zip as the R6 source")
    args=ap.parse_args()
    stock(args.stock_boot.resolve())
    prepare(args.source.resolve(),args.destination.resolve(),args.comparison)
