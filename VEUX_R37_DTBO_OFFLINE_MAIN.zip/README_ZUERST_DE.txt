VEUX R37 – DTBO-Index 0 und echte Offline-Overlay-Zusammenführung (NUR DIAGNOSE)
Repo: Chrizz100/veux-nongki-universal-kernel ; Branch main

Bisheriger Befund aus Original R33: 16 DTBO-Einträge, nur Index 0 hat
VEUX-Modell + 2 Board-ID-Werte + 2 SoC-ID-Werte + compatible wie Laufzeit-FDT.
Index 3 ist PEUX mit anderem zweiten Board-ID-Wert 0x20. Metadatenzuordnung
ist KEIN unmittelbarer Beweis für die konkrete Bootloader-Auswahl!

Anleitung:
1. VEUX_R37_CAPTURE_GERAET.py in /sdcard/Download/ ablegen und in Termux
   ausführen: python /sdcard/Download/VEUX_R37_CAPTURE_GERAET.py
   Root-Zugriff NUR LESEND autorisieren. Ergebnis: /sdcard/Download/VEUX_R37_DEVICE_EVIDENCE.zip
   Die ZIP enthält Stock-Base-DTB, DTBO-Index0-Daten und ausschließlich 27
   whitelisted Live-Gerätebaum-Knoten. Kein rohes, evtl. gerätespezifisches
   Laufzeit-FDT wird exportiert. Keine Boot-/DTBO-/Kernel-Partition wird verändert.
2. VEUX_R37_DTBO_OFFLINE_MAIN.zip UNENTPACKT in Repo main hochladen.
3. VEUX_R37_DEVICE_EVIDENCE.zip UNENTPACKT in Repo main hochladen.
4. VEUX_R37_DTBO_OFFLINE_GATE.yml nach .github/workflows/ mit EXAKTEM Namen.
5. GitHub Actions: VEUX R37 - Device DTBO Candidate and Offline Merge Gate starten.
   Der Workflow erwartet zwingend die aktuelle Gerätedaten-ZIP unter diesem Namen.

Github-Gates: Root-ZIP-Pin, SHA-256 jedes Paketmembers, R33/R34/R36-Originale,
actionlint 1.7.12, runner ShellCheck, Python-Syntax, 50 Regressionstests,
16 Overlay-Metadaten, SELBSTSTÄNDIGE FDT/DTBO-Rohhash-Verifikation,
fdtoverlay-Tool sowie getrennte Offline-Zusammenführung:
 a) Original Stock vendor_boot Basis-DTB + Index0 DTBO
 b) R20 Einzel-DTB + Index0 DTBO
Vergleich der 27 UFS-/PMIC-Knoten mit dem whitelisted Laufzeit-FDT.
Tool-Fehlschlag wird als technische Blockade erfasst, nicht als Bootfreigabe.
Es werden ausschließlich Textberichte/CSV/JSON als Artefakt gespeichert.

WICHTIG: Bestehender 5.4.274 R20/R11 und BReNE bleiben unangetastet.
Kein Kernelbuild, kein Flash, keine BakaSU/SUSFS/NoMount-Aenderung.
Vendor ABI und Bootfähigkeit bleiben ungeprüft/gesperrt.
