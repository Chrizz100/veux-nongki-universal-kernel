import copy
import hashlib
import io
import json
import pathlib
import tempfile
import unittest
import zipfile
import sys
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import r37_gate as a

class TestR37(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r33, cls.entries=a.verify_r33(ROOT)
        cls.r34, cls.paths=a.verify_r34_r36(ROOT)

    def test_01_r33_schema(self): self.assertEqual(self.r33['schema'],'VEUX_R33_DEVICE_DTB_PROVENANCE_V1')
    def test_02_exact_16_entries(self):self.assertEqual(len(self.entries),16)
    def test_03_only_index_zero(self):self.assertEqual([r['index'] for r in self.entries if r['full_runtime_root_metadata_match']],[0])
    def test_04_veux_model(self):self.assertIn('VEUX QRD NOPMI',self.entries[0]['model'])
    def test_05_peux_model(self):self.assertIn('PEUX QRD NOPMI',self.entries[3]['model'])
    def test_06_peux_id_differs(self):self.assertNotEqual(self.entries[0]['board_id'],self.entries[3]['board_id'])
    def test_07_soc_root(self):self.assertIn('qcom,blair',self.r33['runtime_device_tree']['fdt']['root']['compatible'])
    def test_08_dtbo_a_id(self):self.assertEqual(self.r33['dtbo'][0]['partition'],'dtbo_a')
    def test_09_dtbo_b_id(self):self.assertEqual(self.r33['dtbo'][1]['partition'],'dtbo_b')
    def test_10_two_identical_partitions(self):self.assertEqual(self.r33['dtbo'][0]['table_sha256'],self.r33['dtbo'][1]['table_sha256'])
    def test_11_entry_zero_hash(self):self.assertEqual(self.entries[0]['sha256'],a.ENTRY0_SHA)
    def test_12_vendor_base_hash(self):self.assertEqual(self.r33['vendor_boot'][0]['dtbs'][0]['sha256'],a.BASE_SHA)
    def test_13_r34_node_count(self):self.assertEqual(len(self.r34['device_nodes']),754)
    def test_14_r34_bound_count(self):self.assertEqual(sum(bool(n['stock_bound_drivers']) for n in self.r34['device_nodes']),503)
    def test_15_targets_count(self):self.assertEqual(len(self.paths),27)
    def test_16_targets_distinct(self):self.assertEqual(len(set(self.paths)),27)
    def test_17_ufs_phy_in_target(self):self.assertIn(a.UFS_PATHS[0],self.paths)
    def test_18_ufs_host_in_target(self):self.assertIn(a.UFS_PATHS[1],self.paths)
    def test_19_r33_archive_members(self):self.assertEqual(set(a.safe_zip(ROOT/'evidence/R33_DEVICE_EVIDENCE.zip',a.R33_NAMES)),a.R33_NAMES)
    def test_20_r34_archive_members(self):self.assertEqual(set(a.safe_zip(ROOT/'evidence/R34_DEVICE_EVIDENCE_R2.zip',a.R34_NAMES)),a.R34_NAMES)
    def test_21_r36_archive_members(self):self.assertEqual(set(a.safe_zip(ROOT/'evidence/R36_R2_RESULT.zip',a.R36_NAMES)),a.R36_NAMES)
    def test_22_real_r33_sums(self):self.assertTrue(a.verify_sums(a.safe_zip(ROOT/'evidence/R33_DEVICE_EVIDENCE.zip',a.R33_NAMES)))
    def test_23_real_r34_sums(self):self.assertTrue(a.verify_sums(a.safe_zip(ROOT/'evidence/R34_DEVICE_EVIDENCE_R2.zip',a.R34_NAMES)))
    def test_24_real_r36_sums(self):self.assertTrue(a.verify_sums(a.safe_zip(ROOT/'evidence/R36_R2_RESULT.zip',a.R36_NAMES)))
    def test_25_bad_member_set(self):
        with zipfile.ZipFile(io.BytesIO(self.zip_bytes({'wrong':'data'}))) as z:self.assertEqual(z.namelist(),['wrong'])
        with self.assertRaisesRegex(ValueError,'UNEXPECTED'):a.safe_zip(self.zip_bytes({'wrong':'data'}),a.R33_NAMES)
    def test_26_duplicate_member_blocked(self):
        buf=io.BytesIO()
        with zipfile.ZipFile(buf,'w') as z:
            with __import__('warnings').catch_warnings():
                __import__('warnings').simplefilter('ignore')
                z.writestr('z.txt','a');z.writestr('z.txt','b')
        with self.assertRaises(ValueError):a.safe_zip(buf.getvalue(),{'z.txt'})
    def test_27_zip_path_traversal_blocked(self):
        with self.assertRaises(ValueError):a.safe_zip(self.zip_bytes({'../evil':'abc'}),{'../evil'})
    def test_28_zip_absolute_path_blocked(self):
        with self.assertRaises(ValueError):a.safe_zip(self.zip_bytes({'/evil':'abc'}),{'/evil'})
    def test_29_bad_zip_bytes(self):
        with self.assertRaises(zipfile.BadZipFile):a.safe_zip(b'not_a_zip',a.R33_NAMES)
    def test_30_zip_limits(self):
        with self.assertRaises(ValueError):a.safe_zip(b'abc',a.R33_NAMES,compressed_limit=2)
    def test_31_r20_hash(self):self.assertEqual(a.sha((ROOT/'evidence/R20_VEUX.dtb').read_bytes()),a.ANCHORS['evidence/R20_VEUX.dtb'])
    def test_32_manifest_all_pinned(self):self.assertTrue(a.verify_bundle(ROOT))
    def test_33_manifest_strict(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=pathlib.Path(tmp)
            (base/'MANIFEST_SHA256.json').write_text('{}')
            with self.assertRaises(ValueError):a.verify_bundle(base)
    def test_34_unknown_r33_slot_rejected(self):
        other=copy.deepcopy(self.r33);other['reported_active_slot']='_x'
        with patch.object(a,'safe_zip',return_value=self.mutated_r33_members(other)):
            with self.assertRaises(ValueError):a.verify_r33(ROOT)
    def test_35_normalize_default_enabled(self):self.assertEqual(a.normstatus('okay (default)'),'enabled')
    def test_36_normalize_ok_enabled(self):self.assertEqual(a.normstatus('ok'),'enabled')
    def test_37_normalize_disabled(self):self.assertEqual(a.normstatus('disabled'),'disabled')
    def test_38_compare_one_matching(self):
        n={'path':'/n','status':'okay','compatible':['test,a']}
        self.assertTrue(a.compare_nodes([n],[n])[0]['status_match'])
    def test_39_compare_missing_node(self):
        n={'path':'/n','status':'okay','compatible':['test,a']}
        self.assertFalse(a.compare_nodes([],[n])[0]['in_merged'])
    def test_40_compare_wrong_compatible(self):
        n={'path':'/n','status':'okay','compatible':['test,a']}
        m={'path':'/n','status':'okay','compatible':['test,b']}
        self.assertFalse(a.compare_nodes([m],[n])[0]['compatible_match'])
    def test_41_required_binary_tool(self):
        with tempfile.TemporaryDirectory() as td:
            with patch.object(a.shutil,'which',return_value=None):
                with self.assertRaisesRegex(ValueError,'MISSING_REAL_FDTOVERLAY_TOOL'):
                    a.run_merger(pathlib.Path(td)/'a',pathlib.Path(td)/'b',pathlib.Path(td),'c')
    def test_42_real_r20_fdt_parse(self):self.assertGreater(len(a.fdt_nodes((ROOT/'evidence/R20_VEUX.dtb').read_bytes())),1000)
    def test_43_bad_fdt_parse(self):
        with self.assertRaises(ValueError):a.fdt_nodes(b'broken fdt')
    def test_44_archive_manifest_hash_all_full(self):self.assertTrue(all(len(s)==64 for s in a.ANCHORS.values()))
    def test_45_false_boot_flag(self):
        with tempfile.TemporaryDirectory() as td:
            r=a.audit(ROOT,pathlib.Path(td))
            for key in ['boot_ready','flash_allowed','dtbo_bootloader_choice_proven','vendor_abi_proven','source_patch_created','brene_changed']:
                self.assertIs(r[key],False)
    def test_46_no_raw_runtime_fdt_export(self):
        import ast
        capture=(ROOT/'scripts/VEUX_R37_CAPTURE_GERAET.py').read_text()
        self.assertNotIn("'R37_RUNTIME_FDT.dtb':",capture)
        ast.parse(capture)
    def test_47_no_partition_writes(self):
        capture=(ROOT/'scripts/VEUX_R37_CAPTURE_GERAET.py').read_text()
        self.assertNotIn('dd of=',capture)
        self.assertNotIn('fastboot flash',capture)
    def test_48_hash_bad_values(self):
        r=copy.deepcopy(self.r33)
        r['dtbo'][0]['entries'][0]['sha256']='0'*64
        with patch.object(a,'safe_zip',return_value=self.mutated_r33_members(r)):
            with self.assertRaises(ValueError):a.verify_r33(ROOT)
    def test_49_no_forged_proven_flag(self):
        with tempfile.TemporaryDirectory() as td:
            r=a.audit(ROOT,pathlib.Path(td))
            self.assertEqual(r['status'],'R37_METADATA_UNIQUE_AWAIT_RAW_EVIDENCE')
            self.assertEqual(r['r20_standalone_plus_index0_merge']['outcome'],'NOT_ATTEMPTED_NO_RAW_INPUT')
    def test_50_output_integrity(self):
        with tempfile.TemporaryDirectory() as td:
            a.audit(ROOT,pathlib.Path(td));base=pathlib.Path(td)
            sums={n:h for h,n in (line.split('  ',1) for line in (base/'SHA256SUMS.txt').read_text().splitlines())}
            for n,h in sums.items():self.assertEqual(a.sha((base/n).read_bytes()),h)

    def mutated_r33_members(self,device):
        files=a.safe_zip(ROOT/'evidence/R33_DEVICE_EVIDENCE.zip',a.R33_NAMES)
        files['R33_DEVICE_EVIDENCE.json']=json.dumps(device).encode()
        files['SHA256SUMS.txt']=''.join(f'{a.sha(b)}  {k}\n' for k,b in sorted(files.items()) if k!='SHA256SUMS.txt').encode()
        return files

    @staticmethod
    def zip_bytes(files):
        b=io.BytesIO()
        with zipfile.ZipFile(b,'w') as z:
            for k,v in files.items():z.writestr(k,v)
        return b.getvalue()

if __name__=='__main__':unittest.main()
