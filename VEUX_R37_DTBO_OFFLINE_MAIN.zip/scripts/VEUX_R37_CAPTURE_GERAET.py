#!/usr/bin/env python3
"""VEUX R33: read-only active device-tree/DTBO/vendor_boot provenance capture.

Output: /sdcard/Download/VEUX_R33_DEVICE_EVIDENCE.zip
Only whitelisted partition reads and whitelisted kernel metadata. No flash, no mount,
no modprobe/insmod, no partition or module bytes in the ZIP. Requires root for
partition access. Values are device-reported evidence, not remote attestation.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import struct
import subprocess
import sys
import zipfile

SCHEMA = 'VEUX_R33_DEVICE_DTB_PROVENANCE_V1'
OUTPUT_NAME = 'VEUX_R33_DEVICE_EVIDENCE.zip'
FDT_MAGIC = 0xD00DFEED
DTBO_MAGIC = 0xD7B7AB1E
MAX_FDT = 6 * 1024 * 1024
MAX_DTBO = 24 * 1024 * 1024
MAX_DTB_SECTION = 16 * 1024 * 1024
VENDOR_PARTITIONS = ('vendor_boot_a', 'vendor_boot_b')
OVERLAY_PARTITIONS = ('dtbo_a', 'dtbo_b')
ALLOW_PROPS = {'model','compatible','qcom,board-id','qcom,msm-id','qcom,pmic-id', 'qcom,platform-id'}
MODULE_LISTS = (
 '/vendor/lib/modules/modules.load', '/vendor/lib/modules/5.4-gki/modules.load',
 '/vendor/etc/modules.load', '/vendor_dlkm/etc/modules.load',
 '/vendor_dlkm/lib/modules/modules.load', '/odm/etc/modules.load',
 '/odm_dlkm/etc/modules.load', '/odm_dlkm/lib/modules/modules.load',
 '/system_dlkm/etc/modules.load', '/system_dlkm/lib/modules/modules.load',
)


def digest(b):
    return hashlib.sha256(b).hexdigest()


def run(argv, timeout=25, limit=1_000_000):
    try:
        p = subprocess.run(argv, check=False, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired):
        return None
    if p.returncode or len(p.stdout) > limit:
        return None
    return p.stdout


def root_read(path, limit=1_000_000):
    if path not in MODULE_LISTS and path not in ('/sys/firmware/fdt',
        '/proc/device-tree/compatible','/proc/device-tree/model',
        '/sys/firmware/devicetree/base/compatible','/sys/firmware/devicetree/base/model',
        '/proc/modules','/proc/sys/kernel/osrelease'):
        raise ValueError('PATH_NOT_ALLOWED')
    return run(['su','-c','cat '+shlex.quote(path)], limit=limit)


def partition_window(name, offset, length):
    if name not in (*VENDOR_PARTITIONS, *OVERLAY_PARTITIONS):
        raise ValueError('PARTITION_NOT_WHITELISTED')
    if not 0 <= offset <= 64 * 1024 * 1024 or not 0 < length <= MAX_DTBO or offset + length > 96 * 1024 * 1024:
        raise ValueError('INVALID_PARTITION_READ_RANGE')
    bs = 4096
    block, displacement = divmod(offset, bs)
    count = (displacement + length + bs - 1) // bs
    cmd = f'dd if={shlex.quote("/dev/block/by-name/" + name)} bs=4096 skip={block} count={count} 2>/dev/null'
    data = run(['su','-c',cmd], timeout=80, limit=count * bs + 32)
    if data is None or len(data) < displacement + length:
        raise ValueError('PARTITION_WINDOW_READ_FAILED')
    return data[displacement:displacement + length]


def aligned(n, page):
    return (n + page - 1) // page * page


def _strings(b):
    return [s.decode('utf-8', 'replace')[:140] for s in b.split(b'\0') if s][:14]


def fdt_root_metadata(blob):
    if len(blob) < 40:
        raise ValueError('FDT_TOO_SHORT')
    hdr = struct.unpack_from('>10I', blob, 0)
    magic, total, off_struct, off_strings, off_mem, version, last, boot_cpuid, size_strings, size_struct = hdr
    if magic != FDT_MAGIC or not 40 <= total <= len(blob) or total > MAX_FDT:
        raise ValueError('FDT_INVALID_MAGIC_OR_TOTAL')
    if not (40 <= off_mem < total and 40 <= off_struct < total and 40 <= off_strings < total and
            off_struct + size_struct <= total and off_strings + size_strings <= total):
        raise ValueError('FDT_INVALID_OFFSETS')
    strings = blob[off_strings:off_strings + size_strings]
    end = off_struct + size_struct
    pos, depth, node_count, root_props, ended = off_struct, 0, 0, {}, False
    while pos + 4 <= end:
        tok = struct.unpack_from('>I', blob, pos)[0]
        pos += 4
        if tok == 1:  # FDT_BEGIN_NODE
            limit = blob.find(b'\0', pos, end)
            if limit == -1: raise ValueError('FDT_UNTERMINATED_NODE')
            pos = aligned(limit + 1, 4)
            depth += 1
            node_count += 1
            if depth > 80 or node_count > 50000: raise ValueError('FDT_NODE_LIMIT')
        elif tok == 2:
            depth -= 1
            if depth < 0: raise ValueError('FDT_UNBALANCED')
        elif tok == 3:
            if pos + 8 > end: raise ValueError('FDT_TRUNCATED_PROP')
            size, nameoff = struct.unpack_from('>II',blob,pos)
            pos += 8
            if size > MAX_FDT or nameoff >= len(strings) or pos + size > end:
                raise ValueError('FDT_PROP_BOUNDS')
            nend = strings.find(b'\0',nameoff)
            if nend == -1: raise ValueError('FDT_PROP_UNTERMINATED_NAME')
            name = strings[nameoff:nend].decode('ascii','replace')
            if depth == 1 and name in ALLOW_PROPS:
                value = blob[pos:pos + size]
                if name in ('model','compatible'):
                    root_props[name] = _strings(value)
                elif len(value) % 4 == 0 and len(value) <= 64:
                    root_props[name] = [f'0x{x:08x}' for x in struct.unpack('>' + 'I' * (len(value)//4),value)]
            pos = aligned(pos + size, 4)
        elif tok == 4:
            pass
        elif tok == 9:
            ended = True
            break
        else:
            raise ValueError('FDT_UNEXPECTED_TOKEN')
    if not ended or depth != 0:
        raise ValueError('FDT_MISSING_END_OR_UNBALANCED')
    return {'bytes':total,'sha256':digest(blob[:total]),'version':version,
            'nodes':node_count,'root':root_props,'parsed':True}


def fdt_sequence(blob, max_entries=48):
    found=[];pos=0
    while pos+40<=len(blob) and len(found)<max_entries:
        offset = blob.find(b'\xd0\x0d\xfe\xed',pos)
        if offset == -1: break
        try:
            ent = fdt_root_metadata(blob[offset:])
        except ValueError:
            pos = offset + 4
            continue
        found.append({'offset':offset,**ent})
        pos = aligned(offset + ent['bytes'],4)
    return found


def parse_vendor_boot_dtb(name):
    answer={'partition':name,'status':'UNAVAILABLE','dtbs':[]}
    try:
        header = partition_window(name,0,4096)
        if header[:8]!=b'VNDRBOOT': raise ValueError('VENDOR_BOOT_MAGIC')
        version,page_size = struct.unpack_from('<II',header,8)
        ramdisk_bytes=struct.unpack_from('<I',header,24)[0]
        header_size=struct.unpack_from('<I',header,2096)[0]
        dtb_size=struct.unpack_from('<I',header,2100)[0]
        if version not in (3,4) or page_size not in (2048,4096,8192,16384) or not 2112<=header_size<=page_size*2:
            raise ValueError('VENDOR_BOOT_INVALID_HEADER')
        if not 0<dtb_size<=MAX_DTB_SECTION or ramdisk_bytes>96*1024*1024:
            raise ValueError('VENDOR_BOOT_INVALID_DTB_SECTION')
        offset=aligned(header_size,page_size)+aligned(ramdisk_bytes,page_size)
        content=partition_window(name,offset,dtb_size)
        parsed=fdt_sequence(content)
        answer.update({'header_version':version,'page_size':page_size,'ramdisk_bytes':ramdisk_bytes,
                      'dtb_section_size':dtb_size,'dtb_section_sha256':digest(content),
                      'dtb_section_offset':offset,'dtbs':parsed,
                      'status':'PARSED' if parsed else 'NO_VALID_FDT_FOUND'})
    except (ValueError,struct.error) as e:
        answer.update({'status':'READ_OR_FORMAT_ERROR','reason':str(e)[:120]})
    return answer


def parse_dtbo(name):
    answer={'partition':name,'status':'UNAVAILABLE','entries':[]}
    try:
        head=partition_window(name,0,4096)
        if len(head)<32: raise ValueError('DTBO_HEADER_SHORT')
        magic,total,header_size,entry_size,entry_count,entries_offset,page_size,version=struct.unpack_from('>8I',head,0)
        if magic!=DTBO_MAGIC or not 32<=header_size<=4096 or not 32<=entry_size<=128:
            raise ValueError('DTBO_TABLE_HEADER_INVALID')
        if not 32<=total<=MAX_DTBO or entry_count>256 or entries_offset<header_size or entries_offset+entry_count*entry_size>total:
            raise ValueError('DTBO_TABLE_BOUNDS')
        whole=partition_window(name,0,total)
        entries=[]
        for i in range(entry_count):
            at=entries_offset+i*entry_size
            length,offset,ident,revision,c0,c1,c2,c3=struct.unpack_from('>8I',whole,at)
            if length<40 or offset<header_size or offset+length>total:
                raise ValueError('DTBO_ENTRY_RANGE')
            payload=whole[offset:offset+length]
            ent={'index':i,'id':f'0x{ident:08x}','rev':f'0x{revision:08x}',
                 'custom':[f'0x{x:08x}' for x in (c0,c1,c2,c3)],'offset':offset,'bytes':length,
                 'sha256':digest(payload)}
            try:
                ent['fdt']=fdt_root_metadata(payload)
            except ValueError as err:
                ent['parse_error']=str(err)[:120]
            entries.append(ent)
        answer.update({'status':'PARSED' if all('fdt' in x for x in entries) else 'PARTIAL_FDT_PARSE',
                       'total_bytes':total,'header_size':header_size,'entry_count':entry_count,
                       'entries':entries,'table_sha256':digest(whole),'version':version,
                       'page_size':page_size})
    except (ValueError,struct.error) as e:
        answer.update({'status':'READ_OR_FORMAT_ERROR','reason':str(e)[:120]})
    return answer


def read_runtime_fdt():
    raw=root_read('/sys/firmware/fdt',limit=MAX_FDT+4096)
    if raw is not None:
        try:
            return {'source':'/sys/firmware/fdt','status':'PARSED','fdt':fdt_root_metadata(raw)}
        except ValueError as e:
            return {'source':'/sys/firmware/fdt','status':'INVALID_FDT','reason':str(e)[:100]}
    compat=root_read('/proc/device-tree/compatible',limit=2048)
    model=root_read('/proc/device-tree/model',limit=2048)
    if compat is None:
        compat=root_read('/sys/firmware/devicetree/base/compatible',limit=2048)
        model=root_read('/sys/firmware/devicetree/base/model',limit=2048)
    if compat is not None:
        return {'source':'device-tree properties only','status':'PROPERTIES_ONLY',
                'root':{'compatible':_strings(compat),'model':_strings(model or b'')}}
    return {'source':'runtime device-tree','status':'UNAVAILABLE'}


def module_load_lists():
    result=[]
    for name in MODULE_LISTS:
        b=root_read(name,limit=200_000)
        if b is None: continue
        lines=[]
        for line in b.decode('utf8','replace').splitlines():
            entry=line.partition('#')[0].strip()
            if entry and len(entry)<180:
                lines.append(entry.rsplit('/',1)[-1][:100])
        result.append({'path':name,'sha256':digest(b),'entry_count':len(lines),
                       'module_names':lines[:200], 'truncated':len(lines)>200})
    return result




# Safe FDT node path / compatible / status parser inherited from R34.
def fdt_nodes(blob):
    """Bounded FDT reader; emits only path / compatible / status metadata."""
    if len(blob)<40:raise ValueError('FDT_TOO_SMALL')
    hdr=struct.unpack_from('>10I',blob,0)
    magic,total,ofs,offs,offm,version,_last,_boot,szs,szst=hdr
    if magic!=0xd00dfeed or not 40<=total<=len(blob) or total>MAX_FDT:
        raise ValueError('FDT_HEADER_INVALID')
    if not (40<=ofs<total and 40<=offs<total and 40<=offm<total and szs<MAX_FDT and
            ofs+szst<=total and offs+szs<=total):
        raise ValueError('FDT_OFFSETS_INVALID')
    strings=blob[offs:offs+szs];end=ofs+szst
    pos=ofs;stack=[];nodes=[];final=False
    def align(v):return (v+3)&~3
    while pos+4<=end:
        kind=struct.unpack_from('>I',blob,pos)[0];pos+=4
        if kind==1:
            z=blob.find(b'\x00',pos,end)
            if z<0:raise ValueError('FDT_NODE_NAME_UNTERMINATED')
            name=blob[pos:z].decode('ascii','replace')
            if '/' in name or len(name)>120:raise ValueError('FDT_NODE_NAME_INVALID')
            pos=align(z+1)
            path=('/'+name if not stack else stack[-1]['path'].rstrip('/')+'/'+name)
            if not name and not stack:path='/'
            cur={'path':path,'compatible':[],'status':'okay (default)'}
            stack.append(cur);nodes.append(cur)
            if len(stack)>100 or len(nodes)>10000:raise ValueError('FDT_NODES_TOO_LARGE')
        elif kind==2:
            if not stack:raise ValueError('FDT_UNBALANCED_END_NODE')
            stack.pop()
        elif kind==3:
            if not stack or pos+8>end:raise ValueError('FDT_PROP_INVALID')
            length,no=struct.unpack_from('>II',blob,pos);pos+=8
            if no>=len(strings) or pos+length>end or length>MAX_FDT:raise ValueError('FDT_PROP_OUT_OF_BOUNDS')
            stop=strings.find(b'\x00',no)
            if stop<0:raise ValueError('FDT_PROP_NAME_BAD')
            pname=strings[no:stop].decode('ascii','replace')
            if pname in ('compatible','status') and length<=2048:
                props=[]
                for s in blob[pos:pos+length].split(b'\0'):
                    if not s:continue
                    v=s.decode('ascii','replace')
                    if len(v)<=180 and all(32<=ord(c)<=126 for c in v):props.append(v)
                    if len(props)>=18:break
                if pname=='compatible':stack[-1]['compatible']=props
                elif props:stack[-1]['status']=props[0]
            pos=align(pos+length)
        elif kind==4:pass
        elif kind==9:
            final=True;break
        else:raise ValueError('FDT_UNKNOWN_TOKEN')
    if not final or stack:raise ValueError('FDT_MISSING_END')
    return nodes



TARGET_NODE_PATHS = ('/soc/display_gpio_regulator@1', '/soc/display_panel_ibb_stub', '/soc/gpio-regulator@0', '/soc/gpio-regulator@1', '/soc/gpio-regulator@2', '/soc/i2c@4c90000/qcom,pm8008@9', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/adc_tm@3400', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/adc_tm@3500', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/clock-controller@5b00', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/pinctrl@c000', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/qcom,power-on@800', '/soc/qcom,spmi@1c40000/qcom,pm6125@0/vadc@3100', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/adc_tm@3400', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/pinctrl@b000', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/rtc@6100', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@7100', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@7400', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@7c00', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@7d00', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@8400', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@8500', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@8600', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/sdam@9d00', '/soc/qcom,spmi@1c40000/qcom,pmk8350@0/vadc@3100', '/soc/qcom,spmi@1c40000/qcom,pmr735a@4/pinctrl@8800', '/soc/ufshc@4804000', '/soc/ufsphy_mem@4807000')

R37_SCHEMA='VEUX_R37_TARGETED_RAW_DTBO_EVIDENCE_V1'
EXPECTED_TABLE_SHA='8bb06d7d100109fb79aa08349de003d72f14157e04afd2784a13cc28da1b3a3e'
EXPECTED_ENTRY0_SHA='cc4841c596e0d4264f57f42f344ed0d121b8cd92b3a848457e1e575aae97a731'
EXPECTED_VENDOR_DTB_SHA='4aa52366c6e969394ae3b8e969de14971f90b0886d9011705798a86b464953a7'
EXPECTED_RUNTIME_COMPAT=['qcom,blair-qrd','qcom,blair','qcom,qrd']
EXPECTED_BOARD_ID=['0x0001000b','0x00000000']
EXPECTED_SOC_ID=['0x000001fb','0x00010000']
EXPECTED_MODEL=['Qualcomm Technologies, Inc. VEUX QRD NOPMI']
OUTPUT_NAME='VEUX_R37_DEVICE_EVIDENCE.zip'

def do_r37_capture():
    if (run(['su','-c','id -u'],timeout=12,limit=100) or b'').strip()!=b'0':
        raise RuntimeError('R37_ROOT_READ_ACCESS_REQUIRED')
    slot=(run(['/system/bin/getprop','ro.boot.slot_suffix'],limit=100) or b'').decode('ascii','replace').strip()
    if slot not in ('_a','_b'):
        raise RuntimeError('R37_SLOT_UNKNOWN: capture refused')
    active=slot[1:]
    dtbo=parse_dtbo('dtbo_'+active)
    if dtbo.get('status')!='PARSED' or dtbo.get('entry_count')!=16:
        raise RuntimeError('R37_DTBO_NOT_16_VALID_ENTRIES')
    if dtbo.get('table_sha256')!=EXPECTED_TABLE_SHA:
        raise RuntimeError('R37_DTBO_CHANGED_SINCE_R33_STOP_AND_REVIEW')
    entries=dtbo['entries']
    original=entries[0]
    if original['sha256']!=EXPECTED_ENTRY0_SHA:
        raise RuntimeError('R37_ENTRY0_HASH_DIFFERENT_FROM_R33')
    candidate_root=original['fdt']['root']
    if (candidate_root.get('model')!=EXPECTED_MODEL or
        candidate_root.get('compatible')!=EXPECTED_RUNTIME_COMPAT or
        candidate_root.get('qcom,board-id')!=EXPECTED_BOARD_ID or
        candidate_root.get('qcom,msm-id')!=EXPECTED_SOC_ID):
        raise RuntimeError('R37_ENTRY0_METADATA_UNEXPECTED')
    vendor=parse_vendor_boot_dtb('vendor_boot_'+active)
    if vendor.get('status')!='PARSED' or not vendor.get('dtbs'):
        raise RuntimeError('R37_VENDOR_BOOT_DTB_CANNOT_BE_READ')
    entry=vendor['dtbs'][0]
    if entry.get('sha256')!=EXPECTED_VENDOR_DTB_SHA or entry.get('offset')!=0:
        raise RuntimeError('R37_VENDOR_BOOT_BASE_DTB_DIFFERENT_FROM_R33')
    base=partition_window('vendor_boot_'+active,vendor['dtb_section_offset'],entry['bytes'])
    overlay=partition_window('dtbo_'+active,original['offset'],original['bytes'])
    if digest(base)!=EXPECTED_VENDOR_DTB_SHA or digest(overlay)!=EXPECTED_ENTRY0_SHA:
        raise RuntimeError('R37_RAW_PARTITION_DIGEST_MISMATCH')
    live=root_read('/sys/firmware/fdt',limit=MAX_FDT+4096)
    if not live:
        raise RuntimeError('R37_RUNTIME_FDT_READ_FAILED')
    meta=fdt_root_metadata(live)
    if (meta['root'].get('compatible')!=EXPECTED_RUNTIME_COMPAT or
        meta['root'].get('model')!=EXPECTED_MODEL or
        meta['root'].get('qcom,board-id')!=EXPECTED_BOARD_ID or
        meta['root'].get('qcom,msm-id')!=EXPECTED_SOC_ID):
        raise RuntimeError('R37_CURRENT_RUNTIME_MODEL_OR_BOARD_ID_DIFFERENT')
    bypath={n['path']:n for n in fdt_nodes(live)}
    target=[bypath[p] for p in TARGET_NODE_PATHS if p in bypath]
    if len(target)!=27:
        raise RuntimeError('R37_TARGET_RUNTIME_FDT_NODES_MISSING_'+str(len(target)))
    out={
        'schema':R37_SCHEMA,'read_only':True,'reported_active_slot':slot,
        'dtbo_partition':'dtbo_'+active,'vendor_boot_partition':'vendor_boot_'+active,
        'dtbo_table_sha256':dtbo['table_sha256'],
        'dtbo_entry_count':16,'candidate_entry_index':0,
        'candidate_entry_sha256':digest(overlay),'vendor_boot_base_dtb_sha256':digest(base),
        'candidate_entry_root':candidate_root,'runtime_fdt_metadata':meta,
        'runtime_target_nodes':target,
        'limitation':'Rohes Laufzeit-FDT wird NICHT exportiert; Bootloader-Selektionsentscheidung ist nicht direkt auslesbar.',
        'no_flash':True,'no_source_patch':True,
    }
    result={
        'R37_DEVICE_EVIDENCE.json':json.dumps(out,indent=2,sort_keys=True,ensure_ascii=True).encode(),
        'R37_VENDOR_BOOT_BASE.dtb':base,
        'R37_DTBO_CANDIDATE0.dtbo':overlay,
        'README_DE.txt':('R37 Nur-Lese-Erfassung, aktiver Slot '+slot+'\n'
          'Enthaelt nur Stock-Vendor-Boot-Basis-DTB, Stock-DTBO-Eintrag 0 und freigegebene FDT-Metadaten.\n'
          'Das rohe aktive Laufzeit-FDT wird nicht gespeichert. KEIN FLASH.\n').encode(),
    }
    result['SHA256SUMS.txt']=''.join(f'{digest(b)}  {k}\n' for k,b in sorted(result.items())).encode()
    downloads=Path('/sdcard/Download')
    if not downloads.is_dir():
        raise RuntimeError('R37_DOWNLOAD_FOLDER_NOT_AVAILABLE')
    dest=downloads/OUTPUT_NAME
    temp=downloads/(OUTPUT_NAME+'.tmp')
    try:
        with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
            for n,b in result.items():z.writestr(n,b)
        with zipfile.ZipFile(temp) as z:
            if z.testzip() is not None:raise RuntimeError('R37_ZIP_CRC_FAILED')
        os.replace(temp,dest)
    finally:
        if temp.exists():temp.unlink()
    print('R37_DEVICE_CAPTURE=SUCCESS')
    print('R37_SELECTED_METADATA_CANDIDATE=INDEX_0')
    print('R37_TARGET_NODES=27/27')
    print('R37_EVIDENCE='+str(dest))
    print('R37_NO_FLASH=YES; R37_BOOTLOADER_SELECTION_PROVEN=NO')

if __name__=='__main__':
    try:do_r37_capture()
    except Exception as ex:
        print('R37_CAPTURE_FAILED: '+str(ex),file=sys.stderr)
        sys.exit(2)
