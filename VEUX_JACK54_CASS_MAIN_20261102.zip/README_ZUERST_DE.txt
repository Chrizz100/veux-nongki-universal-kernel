VEUX Stock 5.4.274 – JackAltman 5.4 Quellbridge (Stand 02.11.2026)

ZWECK
Diese MAIN plus zugehörige GitHub-YAML vergleichen den vorhandenen R13/R41-Stock-Stand
und die letzte R56-R3-SUSFS-Korrektur mit einem nach Git-Blob gepinnten echten
SUSFS-v2.3.0-Backport aus JackA1ltman/NonGKI_Kernel_Build_2nd.
Die YAML erstellt nachvollziehbare Review-Artefakte. Sie baut noch KEINEN neuen
Linux-Kernel und liefert KEIN flashbares AK3 oder boot.img.

NUTZUNG: NUR ZWEI GITHUB-DATEIEN HOCHLADEN
  1. VEUX_JACK54_CASS_MAIN_20261102.zip ins Repository-Hauptverzeichnis
  2. VEUX_JACK54_CASS_SOURCE_GATE_20261102.yml nach .github/workflows/
Erst nach beiden Uploads den gleichnamigen Workflow auf Branch main starten.
Niemals die originalen R13/R41 oder bisherigen R56-Archive überschreiben.

GEPRUEFTE FESTE REFERENZEN
 JackAltman Backport: bd505f994e255156e8233c399d6835641423bbf6
 Patches/Patch/susfs_patch_to_5.4.patch Git-Blob: 564d68cbe204421759d2c4d4da26527b326f900c
 Xiaomi/MiCode Original: 61397e524093d1ccb94769b5460825e2eaf8871e
 security/selinux/ss/services.c Git-Blob: 6559767d34444c54c03be4d821f64b9745c4ef54
 R13/R41: Original SHA256 (in tools/jack54_reference_gate.py fest verankert)
 R56-R3: aktuelle Main-SUSFS-RC-Fix-Version (hashgepinnte ZIP innerhalb dieser MAIN)

TECHNISCHE GRENZEN
 - Jack5.4 hat die SUSFS-Quelle fs/susfs.c als neue Datei im Patch.
   Unser Stock-R13-Kernel enthaelt diese Datei schon. Kein blindes git apply.
 - Jack5.4-Patch hat AVD-Registry-Funktion, aber keine services.c-Callsite.
 - R55 hat BakaSU AVD-Bridge; die MiCode-Services-Callsite wird separat
   durch den erhaltenen R56-Quellgenerator erstellt – nur als Review-Patch.
 - BakaSU, SUSFS, NoMount, OEM-ABI / RMNET / DTB sind NICHT neu gemeinsam kompiliert.
 - Keine Veraenderung an BReNE, Kernel, Telefon, Boot-Slots oder Root-Modulen.
 - Alle Referenzen werden auf dem GitHub-Runner anhand Git-Blob/SHA256 verifiziert.
 - Shell-Syntax/Unit-Tests lokal geprueft. GitHub actionlint und echte Referenz-
   Ausfuehrung dieser neuen YAML muessen noch auf GitHub nachgewiesen werden.

NO FLASH / NO AUTO-REBOOT / NO INSTALLER / NO USER SECRETS.
