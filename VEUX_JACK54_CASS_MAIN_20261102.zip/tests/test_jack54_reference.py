"""Fail-closed local unit tests. Mocked patch checks are NOT a real Jack donor download."""
import copy
import io
import json
import os
from pathlib import Path
import sys
import unittest
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
import jack54_reference_gate as g


def synthetic_patch():
    # Minimal synthetic skeleton; NOT submitted as a usable kernel patch.
    lines=[]
    for path in g.EXPECTED_FILES:
        lines.append(f'diff --git a/{path} b/{path}\n')
        if path == 'fs/susfs.c':
            lines.extend(['new file mode 100644\n','index 0000000..1111111\n',
                          '--- /dev/null\n','+++ b/fs/susfs.c\n','@@ -0,0 +1,5 @@\n',
                          '+#define SUSFS_VERSION "v2.3.0"\n',
                          '+void susfs_spoof_avd_allowed_rcu(void) {}\n',
                          '+static int srcu_check = srcu_read_lock(&susfs_srcu_open_redirect);\n',
                          '+' + ('x' * 55000) + '\n'])
    return ''.join(lines).encode()

class Jack54Tests(unittest.TestCase):
    def parse(self, raw):
        old=g.PINS['jack_blob']
        try:
            g.PINS['jack_blob']=g.blob(raw)
            return g.parse_patch(raw)
        finally:
            g.PINS['jack_blob']=old

    def test_exact_21_scope(self):
        self.assertEqual(len(g.EXPECTED_FILES),21)
        self.assertEqual(g.EXPECTED_FILES[-1],'security/selinux/avc.c')

    def test_synthetic_extract(self):
        paths, data=self.parse(synthetic_patch())
        self.assertEqual(paths,g.EXPECTED_FILES)
        self.assertIn(b'void susfs_spoof_avd_allowed_rcu',data)

    def test_wrong_pin_blocked(self):
        with self.assertRaisesRegex(g.Blocked,'JACK_GIT_BLOB_CHANGED'):
            g.parse_patch(synthetic_patch())

    def test_change_scope_rejected(self):
        x=synthetic_patch().replace(b'diff --git a/fs/super.c b/fs/super.c',b'diff --git a/fs/broken.c b/fs/broken.c')
        with self.assertRaisesRegex(g.Blocked,'PATCH_SCOPE_CHANGED'):self.parse(x)

    def test_avd_missing_rejected(self):
        x=synthetic_patch().replace(b'susfs_spoof_avd_allowed_rcu',b'not_an_avd_hook_abcdef')
        with self.assertRaisesRegex(g.Blocked,'AVD_SYMBOL_MISSING'):self.parse(x)

    def test_wrong_version_rejected(self):
        x=synthetic_patch().replace(b'v2.3.0',b'v2.2.0')
        with self.assertRaisesRegex(g.Blocked,'NOT_2_3'):self.parse(x)

    def test_no_srcu_rejected(self):
        x=synthetic_patch().replace(b'srcu_read_lock(&susfs_srcu_open_redirect)',b'not_srcu()')
        with self.assertRaisesRegex(g.Blocked,'OPEN_REDIRECT_SRCU_MISSING'):self.parse(x)

    def test_additional_services_scope_rejected(self):
        x=synthetic_patch()+b'diff --git a/security/selinux/ss/services.c b/security/selinux/ss/services.c\n'
        with self.assertRaisesRegex(g.Blocked,'PATCH_SCOPE_CHANGED'):self.parse(x)

    def test_r13_stock_hash(self):
        p=Path(os.environ['R58_INPUT_R13'])
        self.assertEqual(g.sha256(p.read_bytes()),g.PINS['r13'])
        with ZipFile(p) as z:
            self.assertEqual(g.sha256(z.read('r11/evidence/susfs/after/fs/susfs.c')),g.PINS['r13_susfs'])

    def test_r41_hash(self):
        self.assertEqual(g.sha256(Path(os.environ['R58_INPUT_R41']).read_bytes()),g.PINS['r41'])

    def test_current_main_and_nested_r55(self):
        b=Path(os.environ['R58_INPUT_R56']).read_bytes()
        self.assertEqual(g.sha256(b),g.PINS['old_r56'])
        z=g.zip_auth(b)
        self.assertEqual(g.sha256(z['references/VEUX_R55_AVD_QUELLSTUFE_NOFLASH.zip']),g.PINS['r55'])
        self.assertIn('patches/0001-native54-avd-cass-bridge.patch',
                      g.zip_auth(z['references/VEUX_R55_AVD_QUELLSTUFE_NOFLASH.zip'],manifest='SHA256SUMS.txt'))

    def test_manifest_hash_tampering_blocked(self):
        b=Path(os.environ['R58_INPUT_R56']).read_bytes()
        with ZipFile(io.BytesIO(b)) as z:
            mem={n:z.read(n) for n in z.namelist()}
        name='tools/r56_source_gate.py'
        mem[name]+=b'\n#altered\n'
        with io.BytesIO() as f:
            with ZipFile(f,'w') as z:
                for n,data in mem.items():z.writestr(n,data)
            with self.assertRaisesRegex(g.Blocked,'MANIFEST_HASH_MISMATCH'):g.zip_auth(f.getvalue())

    def test_originals_are_not_flashable(self):
        current=Path(os.environ['R58_INPUT_R56']).read_bytes()
        z=g.zip_auth(current)
        d=json.loads(z['MANIFEST_SHA256.json']) if 'MANIFEST_SHA256.json' in z else {}
        self.assertIs(d['flash_allowed'],False)
        self.assertIs(d['kernel_build_completed'],False)

if __name__=='__main__': unittest.main()
