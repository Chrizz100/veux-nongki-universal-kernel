#!/usr/bin/env python3
"""VEUX stock 5.4.274 / JackAltman 5.4 source-diff review, NEVER an installer.

Preserves R13/R41 and the latest R56-R3 source gate unchanged. The Jack patch
is for a *different* 5.4 kernel, so it must not be applied automatically.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import re
import stat
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

PINS = {
    'r13': '15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1',
    'r41': 'e9ea57fc1feb8d4d0e840a61b21174ad1d83d496216794bd9285b40f17026bff',
    'r55': '49deb03175fe5ce8411f76c10c405cc5f3f5b85c52d7c973463bd0bcc147e5ba',
    'old_r56': '7c78b9817b9247159354ec36c04818bde0c4ea4b203d121e1f723624b077e5a2',
    'r13_susfs': '4d6f73641fba90b422a0f3d787a5c220829ad6b99807bec843ba24e7f1d73172',
    'jack_blob': '564d68cbe204421759d2c4d4da26527b326f900c',
    'jack_commit': 'bd505f994e255156e8233c399d6835641423bbf6',
    'stock_services_blob': '6559767d34444c54c03be4d821f64b9745c4ef54',
    'stock_commit': '61397e524093d1ccb94769b5460825e2eaf8871e',
}
# Changed file list of the pinned v2.3.0 5.4 patch; avoids accidental scope expansion.
EXPECTED_FILES = (
    'block/ioprio.c', 'fs/Makefile', 'fs/namei.c', 'fs/namespace.c',
    'fs/notify/fdinfo.c', 'fs/proc/base.c', 'fs/proc/cmdline.c',
    'fs/proc/fd.c', 'fs/proc/task_mmu.c', 'fs/proc_namespace.c',
    'fs/readdir.c', 'fs/stat.c', 'fs/statfs.c', 'fs/super.c',
    'fs/susfs.c', 'include/linux/susfs.h', 'include/linux/susfs_def.h',
    'kernel/kallsyms.c', 'kernel/sys.c', 'mm/memory.c',
    'security/selinux/avc.c',
)

class Blocked(Exception):
    pass

def require(yes: bool, message: str) -> None:
    if not yes:
        raise Blocked(message)

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()

def file_bytes(file: Path, *, max_size: int = 2_000_000) -> bytes:
    require(file.is_file() and not file.is_symlink() and stat.S_ISREG(file.lstat().st_mode), 'NOT_REGULAR:' + file.name)
    require(file.stat().st_size <= max_size, 'FILE_TOO_LARGE:' + file.name)
    return file.read_bytes()

def zip_auth(data: bytes, *, manifest: str = 'MANIFEST_SHA256.json', max_unzip: int = 4_000_000):
    import io
    with ZipFile(io.BytesIO(data)) as z:
        info = z.infolist()
        names = [x.filename for x in info]
        require(names and len(names) == len(set(names)) and len(names) < 80, 'ZIP_DUPLICATE_OR_COUNT')
        require(sum(x.file_size for x in info) < max_unzip and z.testzip() is None, 'ZIP_CRC_OR_BOMB')
        for x in info:
            p = PurePosixPath(x.filename)
            require(p.parts and not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and '\\' not in x.filename
                    and not x.is_dir() and stat.S_IFMT(x.external_attr >> 16) in (0, stat.S_IFREG), 'UNSAFE_ZIP_PATH')
        rows = {n: z.read(n) for n in names}
    if manifest == 'MANIFEST_SHA256.json':
        m = json.loads(rows[manifest]); f = m['files']
        require(set(f) | {manifest} == set(rows), 'MANIFEST_SET_MISMATCH')
        require(m['flash_allowed'] is False, 'MANIFEST_FLASH_CONTRACT_CHANGED')
    else:
        f = dict(reversed(s.split('  ', 1)) for s in rows[manifest].decode().strip().splitlines())
        require(set(f) | {manifest} == set(rows), 'SHA_LIST_MISMATCH')
    for n, h in f.items():
        require(sha256(rows[n]) == h, 'MANIFEST_HASH_MISMATCH:' + n)
    return rows

def parse_patch(raw: bytes) -> tuple[tuple[str, ...], bytes]:
    require(blob(raw) == PINS['jack_blob'], 'JACK_GIT_BLOB_CHANGED')
    patch = raw.decode('utf-8')
    headers = re.findall(r'^diff --git a/(\S+) b/(\S+)$', patch, re.M)
    require(tuple(a for a, b in headers) == EXPECTED_FILES and all(a == b for a, b in headers), 'JACK_5_4_PATCH_SCOPE_CHANGED')
    require('+#define SUSFS_VERSION "v2.3.0"' in patch, 'JACK_SUSFS_NOT_2_3')
    require('susfs_spoof_avd_allowed_rcu' in patch, 'JACK_AVD_SYMBOL_MISSING')
    require('srcu_read_lock(&susfs_srcu_open_redirect)' in patch, 'JACK_OPEN_REDIRECT_SRCU_MISSING')
    require('diff --git a/security/selinux/ss/services.c' not in patch, 'JACK_SERVICES_SOURCE_SCOPE_CHANGED')
    # The Jack 5.4 patch ADDS fs/susfs.c. Extract its exact new file for a review-only diff.
    target = 'diff --git a/fs/susfs.c b/fs/susfs.c\n'
    require(patch.count(target) == 1, 'JACK_SUSFS_SOURCE_DIFF_MISSING')
    part = patch.split(target, 1)[1]
    section, sep, _rest = part.partition('\ndiff --git ')
    if sep:
        section += '\n'  # Keep final newline from prior +line when next diff follows.
    require('new file mode 100644' in section and '\n--- /dev/null\n+++ b/fs/susfs.c\n' in section,
            'JACK_SUSFS_NOT_ADDED_FILE')
    lines = section.splitlines(keepends=True)
    hunk = next((i for i, line in enumerate(lines) if line.startswith('@@ -0,0 +1,')), None)
    require(hunk is not None, 'JACK_SUSFS_HUNK_MISSING')
    result = []
    for line in lines[hunk+1:]:
        if line.startswith('+'):
            result.append(line[1:])
        elif line.startswith('\\ No newline'):
            if result:
                result[-1] = result[-1].rstrip('\n')
        else:
            require(False, 'JACK_NEWFILE_HAS_CONTEXT_OR_DELETION')
    parsed = ''.join(result).encode()
    require(len(parsed) > 50_000 and b'void susfs_spoof_avd_allowed_rcu' in parsed,
            'JACK_EXTRACTED_SUSFS_INCOMPLETE')
    return tuple(a for a, b in headers), parsed

def make_report(*, r13: Path, r41: Path, current: Path, jack: Path, stock: Path, output: Path) -> dict:
    require(output.is_dir() and not output.is_symlink(), 'OUTPUT_DIRECTORY_INVALID')
    orig = file_bytes(r13, max_size=27_000_000)
    prev = file_bytes(r41, max_size=27_000_000)
    keep = file_bytes(current, max_size=3_000_000)
    jack_data = file_bytes(jack)
    stock_data = file_bytes(stock, max_size=2_000_000)
    require(sha256(orig) == PINS['r13'], 'ORIGINAL_R13_CHANGED')
    require(sha256(prev) == PINS['r41'], 'ORIGINAL_R41_CHANGED')
    require(sha256(keep) == PINS['old_r56'], 'CURRENT_R56_BASE_CHANGED')
    require(blob(stock_data) == PINS['stock_services_blob'], 'XIAOMI_STOCK_SELINUX_BLOB_CHANGED')
    r56_files = zip_auth(keep)
    r55_bytes = r56_files['references/VEUX_R55_AVD_QUELLSTUFE_NOFLASH.zip']
    require(sha256(r55_bytes) == PINS['r55'], 'R55_AVD_SOURCE_PIN_CHANGED')
    r55_files = zip_auth(r55_bytes, manifest='SHA256SUMS.txt')
    r55_patch = r55_files['patches/0001-native54-avd-cass-bridge.patch']
    require(b'susfs_spoof_avd_allowed_rcu' in r55_patch and b'rcu_read_lock();' in r55_patch,
            'R55_BAKASU_AVD_BRIDGE_MISSING')
    r13_data = None
    import io
    with ZipFile(io.BytesIO(orig)) as z:
        require(z.testzip() is None, 'R13_ZIP_CRC')
        r13_data = z.read('r11/evidence/susfs/after/fs/susfs.c')
    require(sha256(r13_data) == PINS['r13_susfs'], 'STOCK_REFERENCE_FS_SUSFS_CHANGED')
    scope, donor = parse_patch(jack_data)
    require(donor != r13_data, 'JACK_DONOR_MATCHES_OLD_R13_UNEXPECTED')
    diff = ''.join(difflib.unified_diff(
        r13_data.decode('utf-8').splitlines(True), donor.decode('utf-8').splitlines(True),
        fromfile='a/fs/susfs.c__R13_STOCK_5.4.274', tofile='b/fs/susfs.c__JACK_5.4_REFERENCE', n=3))
    require(len(diff) > 100, 'EMPTY_REVIEW_DIFF')
    (output / 'JACK_5.4_REFERENCE.patch').write_bytes(jack_data)
    (output / 'R55_CASS_AVD_BRIDGE_REFERENCE.patch').write_bytes(r55_patch)
    (output / 'JACK_NATIVE54_SUSFS_REVIEW_ONLY.diff').write_text(diff)
    (output / 'JACK_FS_SUSFS_REFERENCE.c').write_bytes(donor)
    report = {
        'schema': 'VEUX_JACK54_STOCK_BRIDGE_V1',
        'status': 'REAL_REFERENCE_COMPARED__STOCK_5_4_274_MERGE_NOT_PROVEN__NO_BUILD_NO_FLASH',
        'provenance': {'kernel': 'stock 5.4.274 (R13/R41 preserved)', 'r56_main_sha256': sha256(keep),
          'r13_sha256': PINS['r13'], 'r41_sha256': PINS['r41'],
          'jack_commit': PINS['jack_commit'], 'jack_patch_git_blob': blob(jack_data),
          'stock_micode_commit': PINS['stock_commit'], 'stock_services_git_blob': blob(stock_data)},
        'jack_susfs': {'version': '2.3.0', 'diff_file_count': len(scope), 'diff_paths': scope,
          'extracted_susfs_sha256': sha256(donor), 'r13_existing_susfs_sha256': sha256(r13_data),
          'conflict': 'Jack patch creates fs/susfs.c; current R13 already provides this file',
          'source_review_diff_sha256': sha256(diff.encode('utf-8'))},
        'avd': {'symbol_in_jack_susfs': True, 'r55_bakasu_bridge_present': True,
          'jack_patch_contains_services_callsite': False,
          'stock_services_callsite_verified': False},
        'missing_checks': ['full stock 5.4.274 three-way merge', 'SELinux services.c and hooks.c bridge in compiled tree',
          'BakaSU+SUSFS+NoMount combined compilation', 'OEM vendor ABI 132 RMNET CRC imports',
          'vmlinux/Image/Module.symvers and DTB/DTBO', 'matching ROM boot.img and AK3 static checks'],
        'new_kernel_compiled': False, 'automatic_flash': False, 'flash_allowed': False,
        'original_r13_r41_modified': False, 'all_updates_integrated': False}
    (output / 'VEUX_JACK54_REFERENCE_GATE.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    return report

def main() -> int:
    p = argparse.ArgumentParser()
    for n in ('r13','r41','current','jack','stock','out'):
        p.add_argument('--' + n, required=True, type=Path)
    a = p.parse_args()
    try:
        row = make_report(r13=a.r13,r41=a.r41,current=a.current,jack=a.jack,stock=a.stock,output=a.out)
        print(row['status'])
        return 0
    except (Blocked, ValueError, OSError, KeyError, UnicodeError) as e:
        print('VEUX_JACK54_GATE_FAILED=' + str(e), flush=True)
        return 3
if __name__ == '__main__':
    raise SystemExit(main())
