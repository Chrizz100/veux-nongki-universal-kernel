#!/usr/bin/env bash
# Source-only compatibility inspection. No kernel build, flash, or device mutation.
set -Eeuo pipefail
umask 077
: "${GITHUB_WORKSPACE:?}" "${RUNNER_TEMP:?}" "${R58_PAYLOAD:?}" "${GITHUB_SHA:?}"
[[ "${GITHUB_REPOSITORY:-}" == 'Chrizz100/veux-nongki-universal-kernel' ]] || exit 3
[[ "${GITHUB_REF:-}" == refs/heads/main ]] || exit 3
[[ "${GITHUB_ACTIONS:-}" == true && "${RUNNER_OS:-}" == Linux ]] || exit 3
[[ "$(git -C "$GITHUB_WORKSPACE" rev-parse HEAD)" == "$GITHUB_SHA" ]] || exit 3
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || exit 3
STAGE="$RUNNER_TEMP/veux-jack54-stock-reference"
[[ ! -e "$STAGE" && ! -L "$STAGE" ]] || exit 3
mkdir -m 0700 "$STAGE"
mkdir -m 0700 "$STAGE/donor"
fetch_pinned() {
  local url="$1" dest="$2" blob="$3"
  curl --fail --location --silent --show-error --retry 3 --retry-delay 2 \
    --connect-timeout 20 --max-time 180 "$url" --output "$dest"
  [[ "$(git hash-object -- "$dest")" == "$blob" ]] || {
    echo "::error::PINNED_DONOR_BLOB_MISMATCH:$dest" >&2; exit 3;
  }
}
fetch_pinned \
 'https://raw.githubusercontent.com/JackA1ltman/NonGKI_Kernel_Build_2nd/bd505f994e255156e8233c399d6835641423bbf6/Patches/Patch/susfs_patch_to_5.4.patch' \
 "$STAGE/donor/JACK_SUSFS_5_4.patch" '564d68cbe204421759d2c4d4da26527b326f900c'
fetch_pinned \
 'https://raw.githubusercontent.com/MiCode/Xiaomi_Kernel_OpenSource/61397e524093d1ccb94769b5460825e2eaf8871e/security/selinux/ss/services.c' \
 "$STAGE/donor/XIAOMI_STOCK_5_4_services.c" '6559767d34444c54c03be4d821f64b9745c4ef54'
python3 -B "$R58_PAYLOAD/tools/jack54_reference_gate.py" \
 --r13 "$GITHUB_WORKSPACE/VEUX_R13_CASS_MAIN.zip" \
 --r41 "$GITHUB_WORKSPACE/VEUX_R41_NOMOUNT_SOURCE_MAIN.zip" \
 --current "$R58_PAYLOAD/refs/VEUX_R56_R3_UPDATED_CASS_MAIN_SUSFS_RC_FIX.zip" \
 --jack "$STAGE/donor/JACK_SUSFS_5_4.patch" \
 --stock "$STAGE/donor/XIAOMI_STOCK_5_4_services.c" \
 --out "$STAGE"
# Authenticate preserved R56 inner script before using it to generate a review-only
# change to a COPIED stock services.c. Never edit or flash a real device kernel.
python3 -I - "$R58_PAYLOAD/refs/VEUX_R56_R3_UPDATED_CASS_MAIN_SUSFS_RC_FIX.zip" "$STAGE" <<'PY_R58_R56'
from pathlib import Path
from zipfile import ZipFile
import hashlib, json, sys
p=Path(sys.argv[1]); dest=Path(sys.argv[2])
with ZipFile(p) as z:
    m=json.loads(z.read('MANIFEST_SHA256.json'))
    name='tools/r56_services_avd.py'
    src=z.read(name)
    assert m['files'][name]==hashlib.sha256(src).hexdigest()
    script=dest/'r56_services_avd.py'
    with script.open('xb') as f: f.write(src)
PY_R58_R56
python3 -B "$STAGE/r56_services_avd.py" \
 --services "$STAGE/donor/XIAOMI_STOCK_5_4_services.c" \
 --out "$STAGE/services_avd_REVIEW_ONLY"
# The gate deliberately reports a *BLOCKED* updated build, but success for the
# reference audit itself. This is not a kernel CI green pass.
python3 -I - "$STAGE/VEUX_JACK54_REFERENCE_GATE.json" "$STAGE/services_avd_REVIEW_ONLY/R56_SERVICES_AVD_GATE.json" <<'PY_R58_REPORT'
from pathlib import Path
import json,sys
r=json.loads(Path(sys.argv[1]).read_text())
a=json.loads(Path(sys.argv[2]).read_text())
assert r['new_kernel_compiled'] is False and r['flash_allowed'] is False
assert r['all_updates_integrated'] is False
assert a['compiled'] is False and a['flash_allowed'] is False
print('VEUX_JACK54_REVIEW_DATA_AUTHENTICATED=YES')
print('VEUX_CURRENT_KERNEL_NEW_BUILD=BLOCKED__NO_COMPILATION__NO_FLASH')
PY_R58_REPORT
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || exit 3
