# VEUX M60 · Xiaomi-Speicheranzeigen

## Stand nach dem GitHub-Lauf M59

Job 137295281817 bestand alle 13 Schritte. Die zwei heruntergeladenen Archive enthalten 68 Nachweisdateien und vier Dateien im Quellarchiv-Paket. Größen und SHA-256 aller 72 Archiveinträge stehen in `Nachweise/M59-Artefaktinventar.json`. `M59_KERNEL.json` nennt den tatsächlich auf GitHub gebauten Kernel `5.4.274-qgki-g82179e362f33`. Beim erneuten Vergleich stimmten 3.148 Importverwendungen aus 37 Vendor-Modulen, das statische Boot-Layout, beide PMIC-Exporte und die überprüften zRAM-, Speicher-, Atomik- und Thermikpfade. [GitHub-Lauf M59](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45050806254/job/137295281817)

Der M59-Gerätebericht für V816.0.12.0.TKCMIXM weist einen Samsung KM8F9001JM-B813 mit Revision 0700 aus. Keine der sechs festen Stock-Update-Regeln trifft auf ihn zu. Der Gerätecheck fand in der geprüften Partition sda8 keinen zusätzlichen FFU-Header. Für diesen erfassten Gerätestand ergibt sich kein anwendbares UFS-Firmwareupdate. Das Verhalten auf anderen VEUX-Speichervarianten bleibt in der offenen Gruppe zur Firmwarepflege dokumentiert.

## Reparatur in M60

Der Patch ergänzt den eingebauten Treiber für die Xiaomi-Speicherinformationen und bindet ihn an den vorhandenen Qualcomm-UFS-Treiber. `CONFIG_MI_MEMORY_SYSFS=y` ist der einzige geänderte Konfigurationswert. Im direkten Vergleich mit dem ausgelieferten Xiaomi-Kernel sinkt die Zahl der unterschiedlichen Konfigurationswerte von 48 auf 47. Funktionale Lücken können auch bei übereinstimmenden Konfigurationswerten bestehen. Die folgende Liste erfasst deshalb auch die fehlenden Dateien innerhalb dieser aktivierten Option. [Xiaomis VEUX-Quellstand](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/misc/mi-memory)

| Schnittstelle | Inhalt und Prüfung |
| --- | --- |
| `ddr/ddr_size`, `ddr/ddr_id`, `ddr/ddr_vendor` | Die Größenklassen beruhen auf Memblock. Herstellerangaben folgen Xiaomis Zuordnung der ausgelesenen UFS-Herstellerkennung. |
| `ufshcd0/dump_health_desc`, `ufshcd0/dump_device_desc` | Die Lesefunktionen lesen fünf Gesundheitsfelder und 35 Felder aus dem UFS-Gerätedeskriptor. Sie prüfen Deskriptortyp, zurückgegebene Länge und Feldgrenzen. |
| `ufshcd0/show_hba` | 40 Zustandsfelder und Zähler aus dem UFS-Controller, in der Reihenfolge des Stock-Images. |
| `/proc/mv` | Zwei Zeilen für RAM-Hersteller und Größe sowie UFS-Hersteller, Kapazität, Modell und Firmware-Revision. Das Modell ist wie bei Xiaomi auf 15, die Revision auf fünf Zeichen begrenzt. |
| Offen in `ufshcd0` | `dump_string_desc_serial`, der herstellerspezifische Gesundheitsbericht `hr` und das Paar `err_state` und `err_reason`. |
| Offen bei Millet | Binder-Ereignisse, Netlink, IPv4/IPv6, Signale und Prozess-Freezer. `Nachweise/Xiaomi-Millet-UFS-Aufrufe.json` benennt konkrete Stock-Aufrufstellen für den Anschluss an diese Dienste und die UFS-Fehlerhistorie. |

Die sechs eingebauten sysfs-Dateien liegen am Klassengerät `/sys/class/mi_memory/mi_memory_device/`. Die Geräteabfragen benutzen die Runtime-PM des vorhandenen Controllers. Beim Entfernen des Controllers wird der lesende Zugriff beendet. Fehler beim Lesen werden an den Aufrufer zurückgegeben. M60 schreibt keine Speicherfirmware. Die Hosttests überprüfen auch die ungewöhnlichen OEM-Größenklassen und die Rückgabe bei fehlendem Controller oder fehlgeschlagener Abfrage.

## Millet im ausgelieferten Kernel

Das VEUX-Stock-Image öffnet Netlink-Protokoll 30 und sendet 144 Byte Nutzdaten. Es legt `/proc/millet/millet_stat` und `/proc/millet/version` an. Der Paketdienst registriert vier Netfilter-Hooks. Die Binder-Kanäle haben die Nummern 2 und 3, Paketmeldungen die 5 und der Handshake die 6. Diese Kennungen und die ARM64-Nachrichtengröße stimmen mit Xiaomis veröffentlichtem Millet-Header aus dem Pissarro-Zweig überein. Der VEUX-Zweig von Xiaomi listet in `drivers/mihw/Makefile` ausschließlich MIGT. Für eine Übernahme müssen noch die Feldbelegung, die Binder-Anbindung und der Freezer-Pfad auf VEUX geprüft werden. [Xiaomis Millet-UAPI](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/e0c532e444800e0594e28ddd78e10b1978415314/include/uapi/linux/millet.h)

## GitHub

1. `VEUX_M60_MAIN.zip` als ZIP ins Hauptverzeichnis des Repositories hochladen.
2. `VEUX_M60_SPEICHER_NOFLASH.yml` nach `.github/workflows/` hochladen. Beide Dateien müssen auf demselben Branch liegen.
3. In GitHub Actions den M60-Workflow auf diesem Branch manuell starten. Er lädt den M59-Quellstand aus Artefakt 14766357664 und die Xiaomi-Referenz aus Artefakt 14706022228. Die ZIP-Dateien und der M59-Quellinhalt werden anhand ihrer SHA-256 geprüft. GitHub muss diese Eingangsartefakte beim Start noch vorhalten.

Der Workflow sichert Image, vmlinux, Konfigurationsvergleiche und die Ergebnisse der Schnittstellenprüfungen. Das Manifest nennt die vier gebauten Module. Der Aufbau eines Boot-Images mit der Stock-Ramdisk erfolgt zur statischen Layoutprüfung. Für einen Geräte-Pass stehen der Start des neuen Images und die Funktionsprüfung am VEUX aus. Der zuvor gesicherte aktive Bootslot und PC-Fastboot sind der vorgesehene Rückweg.

## Lokal verifiziert

Der M60-Vollbau aus dem authentifizierten GitHub-Quellstand hat den Kernel, vmlinux, den VEUX-Gerätebaum und vier Module erzeugt. Seine Image-SHA-256 lautet `29ff001edd82330251b79045b1230a07c801e86adb7b5207ccaba2168eb80005`. Die eingebetteten Konfigurationen in Image und vmlinux stimmen mit der Build-Konfiguration überein. Alle 3.148 geprüften Importverwendungen aus 37 Xiaomi-Modulen bestehen den CRC- und Anbieterabgleich. Das statisch gepackte Boot-Abbild hat 134.217.728 Bytes und dieselbe Ramdisk-Prüfsumme wie Stock.

Die Imageprüfung verfolgt die Zeiger der beiden sysfs-Gruppen bis zu den Lesefunktionen und die Registrierung von `/proc/mv` bis zu `mv_proc_show`. Vier Negativtests erkennen ein unzulässiges Schreibrecht, eine vertauschte Lesefunktion, eine entfernte Gruppe und einen geänderten Deskriptoroffset. Diese Prüfungen laufen auf dem Buildrechner. Ein Start auf dem Telefon und eine Flash-Freigabe stehen aus. Der zugehörige GitHub-Lauf für M60 startet nach dem Hochladen manuell.
