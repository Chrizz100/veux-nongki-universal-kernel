// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <errno.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#define SZ_1G (1ULL << 30)
#define PAGE_SIZE 4096
#define QUERY_DESC_MAX_SIZE 255
#define UPIU_QUERY_OPCODE_READ_DESC 1
#define SD_ASCII_STD 1
#define scnprintf snprintf
#define kfree free
struct ufs_hba { int dev; };
struct seq_file { char data[256]; };
static struct ufs_hba host, *ready_host, *bound_host;
static int memory_lock, pm_users, pm_error, desc_error, returned_len, string_error, wrong_type, declared_len;
static int fail_geometry;
static unsigned int get_ddr_size(void) { return 8; }
static void mutex_lock(int *lock) { assert(!(*lock)++); }
static void mutex_unlock(int *lock) { assert((*lock)-- == 1); }
static int pm_runtime_get_sync(int dev) { ++pm_users; return pm_error; }
static void pm_runtime_put_sync(int dev) { assert(pm_users-- == 1); }
static void pm_runtime_put_noidle(int dev) { assert(pm_users-- == 1); }
static u16 get_unaligned_be16(const u8 *p) { return (u16)p[0] << 8 | p[1]; }
static u32 get_unaligned_be32(const u8 *p) { return (u32)get_unaligned_be16(p) << 16 | get_unaligned_be16(p+2); }
static u64 get_unaligned_be64(const u8 *p) { return (u64)get_unaligned_be32(p) << 32 | get_unaligned_be32(p+4); }
static int ufshcd_query_descriptor_retry(struct ufs_hba *h, int op, int id, int index, int sel, u8 *data, int *len)
{
    assert(h == &host && op == 1 && !index && !sel && *len == 255);
    assert(pm_users == 1);
    if (desc_error) return desc_error;
    memset(data, 0, 255);
    *len = returned_len;
    data[0] = declared_len;
    data[1] = wrong_type ? 123 : id;
    if (id == 0) {
        data[21] = 3; data[24] = 1; data[25] = 0xce; data[42] = 4;
    } else if (id == 7) {
        if (fail_geometry) data[0] = 5;
        data[8] = 0x0c; /* 96 GiB in 512-byte sectors */
    }
    return 0;
}
static int ufshcd_read_string_desc(struct ufs_hba *h, int index, u8 **buf, int format)
{
    assert(pm_users == 1 && format == 1 && (index == 3 || index == 4));
    if (string_error == index) return -ETIMEDOUT;
    *buf = (u8 *)strdup(index == 3 ? "KM8F9001JM-B813-extra" : "0700");
    assert(*buf); return strlen((char *)*buf);
}
static void seq_printf(struct seq_file *m, const char *fmt, ...)
{
    va_list ap;
    size_t used = strlen(m->data);
    va_start(ap, fmt);
    vsnprintf(m->data+used, sizeof(m->data)-used, fmt, ap);
    va_end(ap);
}
#include "functions.inc"

static void test_classification(void)
{
    const int ddr[] = {0,2,3,4,6,6,8,8,10,10,12,12,16,16,16,16,18,18,16};
    for (unsigned i=0; i<ARRAY_SIZE(ddr); ++i) {
        assert(ddr_capacity(i*SZ_1G+1) == (unsigned)ddr[i]);
        if (i) assert(ddr_capacity(i*SZ_1G) == (unsigned)ddr[i-1]);
    }
    for (int i=0; i<=1100; ++i) {
        unsigned expected = i<=8?0:i<=16?8:i<=32?32:i<=64?64:i<=128?128:i<=256?256:
                            i<=512?512:i<=1024?1024:512;
        assert(ufs_capacity((u64)i<<21) == expected);
        assert(ufs_capacity(((u64)i<<21)+((1U<<21)-1)) == expected);
    }
    for (unsigned id=0; id<=65535; ++id) {
        int expected = id==0x1ce?1:id==0x1ad?6:id==0x12c?255:0;
        assert(ddr_id(id) == expected);
        assert(!strcmp(ddr_vendor(ddr_id(id)), expected==1?"SAMSUNG":
                       expected==6?"HYNIX":expected==255?"MICRON":"UNKNOWN"));
    }
}
static void test_descriptors(void)
{
    char buf[PAGE_SIZE];
    u8 fields[] = {0x12, 0x34, 0x56, 0x78};
    struct mi_field spec[] = {{"A",0,1},{"B",1,2},{"C",0,4}};
    assert(format_fields(buf,fields,4,spec,3)>0);
    assert(strstr(buf,"A = 0x12\n") && strstr(buf,"B = 0x3456\n") && strstr(buf,"C = 0x12345678\n"));
    assert(format_fields(buf,fields,3,spec,3) == -EIO);
    spec[2].width=3;
    assert(format_fields(buf,fields,4,spec,3) == -EINVAL);
    for (int i=0;i<=9;++i) {
        struct seq_file mv = {0};
        returned_len = 89; declared_len = 89; wrong_type = 0; desc_error=0; string_error=0; pm_error=0;
        ready_host=&host;
        int expected=0;
        switch (i) {
        case 0: break;
        case 1: ready_host=NULL; expected=-ENODEV; break;
        case 2: pm_error=-EBUSY; expected=-EBUSY; break;
        case 3: wrong_type=1; expected=-EIO; break;
        case 4: returned_len=1; expected=-EIO; break;
        case 5: declared_len=2; expected=-EIO; break;
        case 6: desc_error=-ETIMEDOUT; expected=-ETIMEDOUT; break;
        case 7: desc_error=1; expected=-EIO; break;
        case 8: returned_len=256; expected=-EIO; break;
        case 9: returned_len=10; expected=-EIO; break;
        }
        int rc=descriptor_show(buf,QUERY_DESC_IDN_DEVICE,device_fields,ARRAY_SIZE(device_fields));
        assert(!memory_lock && !pm_users);
        assert(expected ? rc==expected : rc>0);
        if (!expected) {
            assert(strstr(buf,"wManufactureID = 0x1ce\n"));
            assert(descriptor_show(buf,QUERY_DESC_IDN_HEALTH,health_fields,ARRAY_SIZE(health_fields))>0);
            assert(strstr(buf,"bDeviceLifeTimeEstB"));
        }
        assert(mv_proc_show(&mv,NULL)==expected);
        assert(!memory_lock && !pm_users);
        assert(!strcmp(mv.data,expected?"":"D: 0x01 8\nU: 0x01ce 128 KM8F9001JM-B813 0700\n"));
    }
    returned_len=89; desc_error=0; fail_geometry=1;
    struct seq_file mv={0};
    assert(mv_proc_show(&mv,NULL)==-EIO && !*mv.data && !memory_lock && !pm_users);
    fail_geometry=0;
    for (string_error=3;string_error<=4;++string_error) {
        struct seq_file mv={0};
        assert(mv_proc_show(&mv,NULL)==-ETIMEDOUT && !*mv.data && !memory_lock && !pm_users);
    }
}
int main(void)
{
    struct ufs_hba second = {0};
    mi_memory_ready(&host);
    assert(!bound_host && !ready_host);
    mi_memory_bind(&host);
    mi_memory_bind(&second);
    mi_memory_ready(&second);
    assert(bound_host==&host && !ready_host);
    mi_memory_ready(&host);
    mi_memory_unbind(&second);
    assert(ready_host==&host);
    mi_memory_unbind(&host);
    mi_memory_ready(&host);
    assert(!bound_host && !ready_host && !memory_lock);
    test_classification(); test_descriptors();
    puts("PASS DDR capacity edges, 65,536 vendor IDs, 2,202 UFS capacity cases, descriptor fields, /proc/mv and controller lifetime/read/power error paths");
    return 0;
}
