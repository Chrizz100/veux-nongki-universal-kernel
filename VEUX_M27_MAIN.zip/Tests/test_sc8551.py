import argparse
import contextlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('m27_tested', ROOT / 'Tools/m27_sc8551.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class AdcSourceTests(unittest.TestCase):
    def test_exact_historical_fix_changes_only_adc_driver_and_preserves_headers(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            shutil.copytree(ROOT / 'Before', source, dirs_exist_ok=True)
            before = m.source_check(source)
            after = m.apply_source(source)
            self.assertEqual({n for n in before if before[n] != after[n]}, {m.DRIVER})
            self.assertEqual(after[m.DRIVER], '035d1204b1a4796546c90ab1f448f9ba00889164c731719e3096e4fcafc5cd69')
            self.assertEqual(after, m.source_check(source, after=True))

    def test_last_header_drift_prevents_any_driver_write(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            shutil.copytree(ROOT / 'Before', source, dirs_exist_ok=True)
            header = source / 'include/dt-bindings/iio/qti_power_supply_iio.h'
            header.write_bytes(header.read_bytes() + b'/* drift */')
            before = (source / m.DRIVER).read_bytes()
            with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_CHANGED'):
                m.apply_source(source)
            self.assertEqual((source / m.DRIVER).read_bytes(), before)

    def test_already_fixed_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            shutil.copytree(ROOT / 'After', temp, dirs_exist_ok=True)
            with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_CHANGED'):
                m.apply_source(temp)

    def test_symlink_cannot_redirect_patch(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / 'source'
            shutil.copytree(ROOT / 'Before', source)
            path = source / m.DRIVER
            target = Path(temp) / 'elsewhere.c'
            path.rename(target)
            path.symlink_to(target)
            with self.assertRaisesRegex(ValueError, 'NOT_REGULAR'):
                m.apply_source(source)

    def test_native_original_error_and_iio_false_success_are_reproduced(self):
        script = ROOT / 'References/HISTORICAL/test_sc8551_adc.py'
        result = subprocess.run([sys.executable, '-B', str(script), str(ROOT / 'Before' / m.DRIVER), '--baseline'],
                                text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('SC8551_ORIGINAL_ERROR_OVERWRITE=REPRODUCED', result.stdout)
        self.assertIn('SC8551_ORIGINAL_IIO_FALSE_SUCCESS=REPRODUCED', result.stdout)

    def test_native_fixed_adc_iio_1599_assertions_with_ubsan(self):
        script = ROOT / 'References/HISTORICAL/test_sc8551_adc.py'
        result = subprocess.run([sys.executable, '-B', str(script), str(ROOT / 'After' / m.DRIVER)],
                                text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn('SC8551_ADC_HOST_TESTS=PASS; assertions=1599;', result.stdout)
        self.assertNotIn('runtime error:', result.stderr)

    def test_authentic_m26_callback_retains_rpm_fix_and_config_while_adding_adc_fix(self):
        parent_root = Path(os.environ.get('M26_DIR', str(ROOT.parent / 'm26-main')))
        parent = m.load_parent(parent_root / 'Tools/m26_rpm_sleep.py')
        original = parent.apply_source
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'candidate-source'
            shutil.copytree(parent_root / 'Before', source)
            shutil.copytree(ROOT / 'Before', source, dirs_exist_ok=True)
            config = root / '.config'
            config.write_bytes(b'CONFIG_TEST_SENTINEL=y\n')

            def stop(args):
                report = parent.apply_source(source)
                self.assertEqual(report, parent.source_check(source, after=True))
                m.source_check(source, after=True)
                self.assertEqual(config.read_bytes(), b'CONFIG_TEST_SENTINEL=y\n')
                raise RuntimeError('AUTHENTIC_RPM_AND_ADC_CALLBACK_PASS_STOPS_BEFORE_COMPILATION')

            with patch.object(m, 'load_parent', return_value=parent), patch.object(parent, 'build', side_effect=stop):
                with self.assertRaisesRegex(RuntimeError, 'CALLBACK_PASS'):
                    m.build(argparse.Namespace(m26_tool=str(parent_root / 'Tools/m26_rpm_sleep.py'), output=str(root)))
            self.assertIs(parent.apply_source, original)
            result = json.loads((root / 'M27_RESULT.json').read_text())
            self.assertFalse(result['kernel_compiled'])
            self.assertFalse(result['flash_allowed'])
            self.assertIn('applied_sc8551_source_hashes', result)

    def test_probe_iio_callback_and_initcall_required_with_lto_suffixes(self):
        lines = ['ffffffc0101a8b08 t sc8551_charger_probe.llvm.123',
                 'ffffffc0101aa9a8 t sc_iio_read_raw$123.cfi_jt',
                 'ffffffc0127ee880 d __initcall_218_2514_sc8551_charger_driver_init6']
        self.assertEqual(len(m.linked_proof('\n'.join(lines))), 3)
        for i in range(3):
            with self.subTest(i=i), self.assertRaisesRegex(ValueError, 'NOT_LINKED'):
                m.linked_proof('\n'.join(lines[:i] + lines[i + 1:]))

    def test_old_green_report_cannot_satisfy_new_adc_gate(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / 'M27_RESULT.json').write_text(json.dumps({'status': 'M26_GREEN', 'kernel_compiled': True}))
            with self.assertRaisesRegex(ValueError, 'FRESH_M27_FULL_ADC_BUILD_REQUIRED'):
                m.verify_fresh(temp, argparse.Namespace(), 'fixture')

    def test_parent_package_failure_is_reported_and_quarantined(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            (out / 'review').mkdir()
            (out / 'review/unverified_boot.img').write_bytes(b'unit fixture')

            def fail(args):
                raise RuntimeError('PARENT_PACKAGE_FAILED')

            parent = argparse.Namespace(package=fail)
            with patch.object(m, 'verify_package'), patch.object(m, 'load_parent', return_value=parent), patch.object(m, 'verify_fresh', return_value={}):
                with self.assertRaisesRegex(RuntimeError, 'PARENT_PACKAGE_FAILED'):
                    m.package(argparse.Namespace(m26_tool='fixture', m25_tool='fixture', build='fixture', output=temp))
            result = json.loads((out / 'M27_PACKAGE_RESULT.json').read_text())
            self.assertFalse(result['static_boot_path_pass'])
            self.assertFalse(result['device_pass'])
            self.assertFalse(result['flash_allowed'])
            self.assertFalse((out / 'review').exists())
            self.assertTrue((out / 'unverified-review/unverified_boot.img').is_file())


class ProductTests(unittest.TestCase):
    def fixture(self, build):
        shutil.copytree(ROOT / 'After', build / 'candidate-source')
        out = build / 'candidate-out'
        out.mkdir()
        (out / '.config').write_text('CONFIG_CHARGER_SC8551=y\n')
        (out / 'Module.symvers').write_text('SYNTHETIC UNIT FIXTURE\n')
        obj = out / (m.UNIT + '.o')
        obj.parent.mkdir(parents=True)
        obj.write_bytes(b'BC\xc0\xdeSYNTHETIC UNIT FIXTURE')
        (obj.parent / ('.' + obj.name + '.cmd')).write_text(m.DRIVER + ' -flto=thin -fsanitize=cfi')
        (out / 'vmlinux').write_bytes(b'SYNTHETIC UNIT FIXTURE')
        (out / 'System.map').write_text('ffffffc0101a8b08 t sc8551_charger_probe\n'
                                      'ffffffc0101aa9a8 t sc_iio_read_raw\n'
                                      'ffffffc0127ee880 d __initcall_218_2514_sc8551_charger_driver_init6\n')
        profile = dict(m.profile(), baseline_config_sha256=m.sha(out / '.config'),
                       full_symvers_sha256=m.sha(out / 'Module.symvers'))
        return out, profile

    def test_complete_driver_source_object_cfi_and_interfaces_proof(self):
        with tempfile.TemporaryDirectory() as temp:
            out, profile = self.fixture(Path(temp))
            with patch.object(m, 'profile', return_value=profile):
                proof = m.adc_proof(temp)
            self.assertEqual(len(proof['sc8551_source_hashes']), 3)
            self.assertEqual(len(proof['linked_sc8551_interfaces']), 3)
            self.assertEqual(proof['new_config_values_requested'], [])

    def test_wrong_object_cfi_symbol_or_export_table_blocks_gate(self):
        names = ['Module.symvers', m.UNIT + '.o',
                 str(Path(m.UNIT).parent / ('.' + Path(m.UNIT).name + '.o.cmd')), 'System.map']
        for name in names:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp:
                out, profile = self.fixture(Path(temp))
                (out / name).write_bytes(b'wrong or old product')
                with patch.object(m, 'profile', return_value=profile), self.assertRaises(ValueError):
                    m.adc_proof(temp)

    def test_fresh_green_product_is_rechecked_before_packaging(self):
        with tempfile.TemporaryDirectory() as temp:
            build = Path(temp)
            out, profile = self.fixture(build)
            with patch.object(m, 'profile', return_value=profile):
                result = dict(m.adc_proof(build), status=m.STATUS, kernel_compiled=True,
                              sc8551_adc_source_compiled_and_linked=True, runtime_charging_tested=False,
                              device_pass=False, flash_allowed=False,
                              kernel_product_hashes={'vmlinux': m.sha(out / 'vmlinux')})
                (build / 'M27_RESULT.json').write_text(json.dumps(result))
                parent = argparse.Namespace(verify_fresh=lambda b, p: None, load_parent=lambda p: None)
                self.assertEqual(m.verify_fresh(build, parent, 'fixture')['status'], m.STATUS)
                (out / 'vmlinux').write_bytes(b'changed after build')
                with self.assertRaisesRegex(ValueError, 'FRESH_KERNEL_PRODUCT_CHANGED'):
                    m.verify_fresh(build, parent, 'fixture')


class WorkflowTests(unittest.TestCase):
    def command(self, op):
        expected = (ROOT / ('References/M27_' + op.upper() + '_COMMAND.sh')).read_text()
        if 'M27_WORKFLOW' not in os.environ:
            return expected
        rows = Path(os.environ['M27_WORKFLOW']).read_text().splitlines()
        found = []
        for i, row in enumerate(rows):
            if row.strip() != 'run: |':
                continue
            indent = len(row) - len(row.lstrip())
            body = []
            for line in rows[i + 1:]:
                if line.strip() and len(line) - len(line.lstrip()) <= indent:
                    break
                body.append(line)
            script = textwrap.dedent('\n'.join(body)) + '\n'
            if 'python3 -B "$M27_DIR/Tools/m27_sc8551.py" ' + op in script:
                found.append(script)
        self.assertEqual(found, [expected])
        return found[0]

    def capture(self, op, broken=False):
        with tempfile.TemporaryDirectory(prefix='m26 argv spaces ') as temp:
            root = Path(temp)
            bindir = root / 'bin'
            bindir.mkdir()
            shim = bindir / 'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M27_CAPTURE"\n')
            shim.chmod(0o755)
            keys = ['M26_DIR', 'M25_DIR', 'R25_DIR', 'R24_DIR', 'R23_DIR', 'R21_SCHED_DIR', 'R19_RMNET_DIR',
                    'R18_IRQ_DIR', 'R17_CACHE_DIR', 'R16_REPAIR_DIR', 'R9_SNAPSHOT', 'R13_OBJOUT',
                    'R47_REPORT_DIR', 'R47_TOOLS_DIR', 'GITHUB_WORKSPACE', 'R16_REPAIR_OUTPUT',
                    'R21_PACK_DIR', 'R21_PACKAGE_OUTPUT']
            env = {k: str(root / (k + ' spaces')) for k in keys}
            env['M27_DIR'] = str(ROOT)
            command = self.command(op)
            if broken:
                command = command.replace(' ' + op + ' \\\n', ' ' + op + ' \\\n  + \\\n', 1)
            result = subprocess.run(['bash', '-c', command], env=dict(os.environ, **env,
                                    PATH=str(bindir) + os.pathsep + os.environ['PATH'], M27_CAPTURE=str(root / 'argv')),
                                    text=True, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            argv = (root / 'argv').read_bytes().decode().split('\0')
            self.assertEqual(argv.pop(), '')
            self.assertEqual(argv[:2], ['-B', str(ROOT / 'Tools/m27_sc8551.py')])
            return argv[1:], env

    def invoke(self, op, count):
        argv, env = self.capture(op)
        with patch.object(sys, 'argv', argv), patch.object(m, 'verify_package'), patch.object(m, op) as called:
            m.main()
        parsed = vars(called.call_args.args[0])
        self.assertEqual(len(parsed), count + 1)
        self.assertEqual(parsed['op'], op)
        self.assertEqual(parsed['m26_tool'], env['M26_DIR'] + '/Tools/m26_rpm_sleep.py')
        self.assertEqual(parsed['m25_tool'], env['M25_DIR'] + '/Tools/m25_config.py')
        self.assertEqual(parsed['r25_tool'], env['R25_DIR'] + '/Tools/r25_tzlog.py')
        self.assertEqual(parsed['output'], env['R16_REPAIR_OUTPUT'] if op == 'build' else env['R21_PACKAGE_OUTPUT'])
        return parsed, env

    def test_delivered_build_command_passes_real_parser_with_all_sixteen_paths(self):
        parsed, env = self.invoke('build', 16)
        self.assertEqual(parsed['source'], env['R9_SNAPSHOT'])
        self.assertEqual(parsed['project'], env['GITHUB_WORKSPACE'] + '/project')

    def test_delivered_package_command_passes_real_parser_with_all_ten_paths(self):
        parsed, env = self.invoke('package', 10)
        self.assertEqual(parsed['build'], env['R16_REPAIR_OUTPUT'])
        self.assertEqual(parsed['work'], env['GITHUB_WORKSPACE'] + '/r46-m27-pack-work')

    def test_original_plus_typo_is_rejected_before_either_operation(self):
        for op in ['build', 'package']:
            argv, _ = self.capture(op, broken=True)
            with self.subTest(op=op), patch.object(sys, 'argv', argv), patch.object(m, op) as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    m.main()
            self.assertEqual(error.exception.code, 2)
            called.assert_not_called()


if __name__ == '__main__':
    unittest.main()
