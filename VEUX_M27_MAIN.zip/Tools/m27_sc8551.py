#!/usr/bin/env python3
"""Propagate SC8551 ADC read errors and reject invalid channels; retain all M26 gates."""
import argparse
import hashlib
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/sc8551_charger.c'
UNIT = DRIVER[:-2]
STATUS = 'M27_FULL_SC8551_ADC_M26_RPM_CONFIG_1423_CRCS_37_MODULES_PASS_NOFLASH'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()


def profile():
    return json.loads((ROOT / 'References/PROFILE.json').read_text())


def pins():
    return json.loads((ROOT / 'References/SOURCE_PINS.json').read_text())


def verify_package():
    names = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in names, 'UNSAFE_MANIFEST')
        require(not (ROOT / path).is_symlink() and sha(ROOT / path) == digest, 'PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names and len(pins()) == 3, 'PACKAGE_SCOPE_CHANGED')
    for name, pin in pins().items():
        for side in ['Before', 'After']:
            require(sha(ROOT / side / name) == pin[side.lower() + '_sha256'], 'SOURCE_FIXTURE_CHANGED:' + name)
    historic = json.loads((ROOT / 'References/HISTORICAL/candidate.json').read_text())
    require(pins()[DRIVER]['before_sha256'] == historic['before_sha256']
            and pins()[DRIVER]['after_sha256'] == historic['after_sha256'], 'EXACT_HISTORICAL_ADC_FIX_REQUIRED')
    for name, digest in historic['test_assets_sha256'].items():
        require(sha(ROOT / 'References/HISTORICAL' / name) == digest, 'NATIVE_TEST_HEADER_CHANGED:' + name)


def source_check(source, after=False):
    source = Path(source).resolve(strict=True)
    result = {}
    for name, pin in pins().items():
        path = source / name
        require(path.is_file() and all(not p.is_symlink() for p in [path, *path.parents]
                if p.is_relative_to(source)), 'SOURCE_NOT_REGULAR:' + name)
        result[name] = sha(path)
        expected = pin['after_sha256' if after else 'before_sha256']
        require(result[name] == expected,
                'ADC_SOURCE_CONTEXT_CHANGED:' + name + ':expected=' + expected + ':actual=' + result[name])
    return result


def apply_source(source):
    source = Path(source).resolve(strict=True)
    source_check(source)
    for name, pin in pins().items():
        if pin['before_sha256'] != pin['after_sha256']:
            (source / name).write_bytes((ROOT / 'After' / name).read_bytes())
    return source_check(source, after=True)


def linked_proof(text):
    patterns = {'charger_probe': r'sc8551_charger_probe(?:[.$]\S+)?',
                'iio_read_callback': r'sc_iio_read_raw(?:[.$]\S+)?',
                'charger_initcall': r'__initcall_\S*sc8551_charger_driver_init6(?:\.llvm\.\S+)?'}
    result = {}
    for key, pattern in patterns.items():
        found = re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(' + pattern + r')$', text)
        require(found, 'SC8551_INTERFACE_NOT_LINKED:' + key)
        result[key] = sorted(set(found))
    return result


def adc_proof(build):
    build = Path(build).resolve(strict=True)
    out = build / 'candidate-out'
    sources = source_check(build / 'candidate-source', after=True)
    require(sha(out / '.config') == profile()['baseline_config_sha256'], 'ACTUAL_M26_CONFIG_CHANGED')
    require(sha(out / 'Module.symvers') == profile()['full_symvers_sha256'], 'FULL_M26_EXPORT_TABLE_CHANGED')
    require(re.search(r'(?m)^CONFIG_CHARGER_SC8551=y$', (out / '.config').read_text()), 'BUILTIN_SC8551_REQUIRED')
    obj = out / (UNIT + '.o')
    cmd = obj.parent / ('.' + obj.name + '.cmd')
    with obj.open('rb') as f:
        require(f.read(4) in [b'BC\xc0\xde', b'\xde\xc0\x17\x0b'], 'SC8551_OBJECT_NOT_LLVM_BITCODE')
    command = cmd.read_text()
    require(DRIVER in command and '-flto=thin' in command and '-fsanitize=cfi' in command,
            'ACTUAL_SC8551_CFI_COMMAND_REQUIRED')
    return {'sc8551_source_hashes': sources, 'sc8551_object_sha256': sha(obj),
            'sc8551_command_sha256': sha(cmd),
            'linked_sc8551_interfaces': linked_proof((out / 'System.map').read_text()),
            'new_config_values_requested': [], 'actual_config_sha256': sha(out / '.config'),
            'full_symvers_sha256': sha(out / 'Module.symvers')}


def load_parent(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['m26_tool_sha256'], 'AUTHENTIC_M26_TOOL_CHANGED')
    spec = importlib.util.spec_from_file_location('m27_original_m26', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def write_result(out, name, result):
    if out.is_dir():
        (out / name).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def build(args):
    verify_package()
    parent = load_parent(args.m26_tool)
    original = parent.apply_source
    out = Path(args.output).resolve()
    result = {'status': 'M27_BUILD_PENDING', 'kernel_compiled': False,
              'device_pass': False, 'flash_allowed': False, 'runtime_charging_tested': False,
              'baseline_run': profile()['baseline_run'], 'new_config_values_requested': []}

    def overlay(source):
        result['sc8551_preflight'] = source_check(source)
        prior = original(source)
        result['applied_sc8551_source_hashes'] = apply_source(source)
        return prior

    parent.apply_source = overlay
    try:
        parent.build(args)
        prior = parent.verify_fresh(out, parent.load_parent(args.m25_tool))
        require(prior['status'] == parent.STATUS and prior['kernel_compiled'] is True
                and prior['rpm_sleep_failure_path_compiled_and_linked'] is True, 'FULL_M26_RPM_BUILD_REQUIRED')
        result.update(adc_proof(out))
        require(result['sc8551_source_hashes'] == result['applied_sc8551_source_hashes'], 'ADC_SOURCE_CHANGED_DURING_BUILD')
        require(prior['fully_matching_modules'] == 37 and prior['qgki_counts'] ==
                {'MATCH': 1423, 'CRC_MISMATCH': 0, 'NOT_EXPORTED': 0}, 'COMPLETE_QGKI_COHORT_REQUIRED')
        result.update(status=STATUS, kernel_compiled=True, sc8551_adc_source_compiled_and_linked=True,
                      fully_matching_modules=37, qgki_counts=prior['qgki_counts'],
                      kernel_product_hashes=prior['kernel_product_hashes'], release=prior['release'])
    except Exception as error:
        result.update(status='M27_BUILD_OR_ADC_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.apply_source = original
        write_result(out, 'M27_RESULT.json', result)
    print(result['status'], 'DEVICE_PASS=NO FLASH=NO')


def verify_fresh(build, parent, m25_tool):
    build = Path(build).resolve(strict=True)
    result = json.loads((build / 'M27_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('sc8551_adc_source_compiled_and_linked') is True
            and result.get('runtime_charging_tested') is False
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_M27_FULL_ADC_BUILD_REQUIRED')
    parent.verify_fresh(build, parent.load_parent(m25_tool))
    proof = adc_proof(build)
    require(all(result.get(k) == v for k, v in proof.items()), 'FRESH_ADC_PROOF_CHANGED')
    for name, digest in result['kernel_product_hashes'].items():
        require(sha(build / 'candidate-out' / name) == digest, 'FRESH_KERNEL_PRODUCT_CHANGED:' + name)
    return result


def package(args):
    verify_package()
    parent = load_parent(args.m26_tool)
    result = verify_fresh(args.build, parent, args.m25_tool)
    out = Path(args.output).resolve()
    package_result = {'status': 'M27_PACKAGE_PENDING', 'static_boot_path_pass': False,
                      'device_pass': False, 'flash_allowed': False}
    try:
        parent.package(args)
        prior = json.loads((out / 'M26_PACKAGE_RESULT.json').read_text())
        require(prior['static_boot_path_pass'] is True and prior['device_pass'] is False, 'M26_STATIC_PACKAGE_GATES_REQUIRED')
        for path in sorted((out / 'review').iterdir()):
            require(path.is_file() and path.name.startswith('VEUX_M26_'), 'UNEXPECTED_REVIEW_FILE')
            target = path.with_name(path.name.replace('VEUX_M26_', 'VEUX_M27_', 1))
            require(not target.exists(), 'REVIEW_TARGET_EXISTS')
            path.rename(target)
        pair = parent.load_parent(args.m25_tool).audit_pair(args.build, out)
        verify_fresh(args.build, parent, args.m25_tool)
        package_result.update(status='M27_SC8551_RPM_CONFIG_BOOT_AK3_PAIR_PASS_NOFLASH',
                              static_boot_path_pass=True, review_pair_sha256=pair,
                              kernel_release=result['release']['verified_release'])
    except Exception as error:
        package_result.update(status='M27_PACKAGE_GATE_FAILED_NOFLASH', error=str(error))
        review = out / 'review'
        if review.exists():
            review.rename(out / 'unverified-review')
        raise
    finally:
        write_result(out, 'M27_PACKAGE_RESULT.json', package_result)
    print('M27_SC8551_RPM_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='op', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    b = sub.add_parser('build')
    for name in ('m26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-tool', 'r19-tool',
                 'r18-tool', 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + name, required=True)
    a = sub.add_parser('package')
    for name in ('m26-tool', 'm25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-package-tool',
                 'build', 'packager-tool', 'work', 'output'):
        a.add_argument('--' + name, required=True)
    args = p.parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'check-source':
        print(json.dumps(source_check(args.source), sort_keys=True))
    else:
        print('M27_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
