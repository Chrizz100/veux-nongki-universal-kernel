from __future__ import annotations
import csv,io, tempfile,unittest,zipfile
from pathlib import Path
import abi_reconcile as a
import compare_candidate as c
BASE=Path(__file__).resolve().parents[1]

class NewSymversCompareTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with zipfile.ZipFile(BASE/'inputs'/'R30_R2_ORIGINAL_REPORTS.zip') as z:
            cls.rows=a.csv_rows(z,'R30_R2_ALL_SYMBOLS.csv')
        symvers={r['symbol']:r['R13_crc'] for r in cls.rows if r['R13_crc']}
        cls.synthetic=''.join(f'{val} {symbol} vmlinux EXPORT_SYMBOL\n' for symbol,val in sorted(symvers.items()))

    def _run(self,data):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'Module.symvers';p.write_text(data)
            return c.compare(BASE/'inputs',p)

    def test_01_correct_original_r13_gki_qgki_reconstruction(self):
        x,_=self._run(self.synthetic)
        self.assertEqual(x['cohorts']['GKI']['candidate'],{'MATCH':4983,'CRC_MISMATCH':6075,'NOT_EXPORTED':442})
        self.assertEqual(x['cohorts']['QGKI']['candidate'],{'MATCH':1303,'CRC_MISMATCH':1752,'NOT_EXPORTED':93})

    def test_02_sha_is_measured_without_pretending_to_prove_compiler(self):
        x,_=self._run(self.synthetic)
        self.assertFalse(x['candidate_kernel_compile_proven_by_this_tool'])
        self.assertFalse(x['device_boot_verified'])
        self.assertFalse(x['flash_allowed'])

    def test_03_reproducible(self):
        a1,out1=self._run(self.synthetic);a2,out2=self._run(self.synthetic)
        self.assertEqual(a1,a2);self.assertEqual(out1,out2)

    def test_04_empty_rejected(self):
        with self.assertRaisesRegex(a.GateError,'SYMVERS_SIZE_INVALID'):self._run('')

    def test_05_duplicate_crc_conflict_rejected(self):
        with self.assertRaisesRegex(a.GateError,'CANDIDATE_SYMVERS_CONFLICTING_CRC'):
            self._run(self.synthetic+'0x00000001 module_layout vmlinux EXPORT_SYMBOL\n')

    def test_06_invalid_crc_rejected(self):
        with self.assertRaisesRegex(a.GateError,'MALFORMED_REAL_SYMVERS_LINE'):
            self._run(self.synthetic+'THIS_IS_NOT_CRC some_symbol vmlinux EXPORT_SYMBOL\n')

    def test_07_missing_module_layout_rejected(self):
        s='\n'.join(x for x in self.synthetic.splitlines() if ' module_layout ' not in x)
        with self.assertRaisesRegex(a.GateError,'SYMVERS_NO_MODULE_LAYOUT'):self._run(s)

    def test_08_tiny_fake_symvers_rejected(self):
        with self.assertRaisesRegex(a.GateError,'SYMVERS_TOO_SMALL_FOR_OEM_COMPARE'):
            self._run('0x00000001 module_layout vmlinux EXPORT_SYMBOL\n')

    def test_09_no_automatic_fully_compatible_module_claim(self):
        x,_=self._run(self.synthetic)
        self.assertFalse(x['nine_priority_modules_all_imports_compatible'])
        self.assertFalse(x['active_modules_binary_identity_proven'])

    def test_10_real_change_is_detected_as_deterioration(self):
        # flip one shared export; this cannot make BOTH historical cohorts identical.
        original=next(s for s in self.synthetic.splitlines() if ' module_layout ' in s)
        x,_=self._run(self.synthetic.replace(original,'0x945d02f2 module_layout vmlinux EXPORT_SYMBOL'))
        self.assertEqual(x['candidate_module_layout'],'0x945d02f2')
        self.assertTrue(x['cannot_claim_both_cohort_abi'])

if __name__=='__main__':unittest.main()
