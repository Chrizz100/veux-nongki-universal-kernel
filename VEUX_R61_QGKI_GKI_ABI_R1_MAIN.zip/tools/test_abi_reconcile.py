from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import csv
import io

import abi_reconcile as a

HERE = Path(__file__).resolve().parents[1]
INPUTS = HERE/'inputs'

class ABIReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r,cls.out=a.audit(INPUTS)

    def test_01_r61_is_frozen(self):
        self.assertEqual(self.r['r61']['module_symvers_sha256'],a.R61_SYMVERS_SHA)
        self.assertEqual(self.r['r61']['r61_image_sha256'],a.R61_IMAGE_SHA)
        self.assertEqual(self.r['r61']['config_sha256'],a.R61_CONFIG_SHA)

    def test_02_stable_bakasu_susfs_nomount(self):
        x=self.r['r61'];self.assertEqual((x['bakasu_version'],x['susfs_version'],x['nomount_version']),(35260,'2.3.0','22 (605)'))

    def test_03_kernel_already_compiled(self):
        self.assertTrue(self.r['r61']['compiler_pass'])
        self.assertTrue(self.r['r61']['rmnet_132_built_in_crc_pass'])

    def test_04_no_false_abi_boot_flash(self):
        self.assertFalse(self.r['r61']['boot_verified'])
        self.assertFalse(self.r['r61']['vendor_abi_proven'])
        self.assertFalse(self.r['flash_allowed'])
        self.assertTrue(self.r['no_flashable_artifact'])

    def test_05_imports_and_modules(self):
        self.assertEqual(self.r['overall']['historical_imports'],14648)
        self.assertEqual(self.r['overall']['module_catalog_count'],218)

    def test_06_exact_qgki(self):
        self.assertEqual(self.r['cohorts']['QGKI']['modules'],37)
        self.assertEqual(self.r['cohorts']['QGKI']['R61'],{'MATCH':1303,'CRC_MISMATCH':1752,'NOT_EXPORTED':93})

    def test_07_exact_gki(self):
        self.assertEqual(self.r['cohorts']['GKI']['modules'],181)
        self.assertEqual(self.r['cohorts']['GKI']['R61'],{'MATCH':4983,'CRC_MISMATCH':6075,'NOT_EXPORTED':442})

    def test_08_r30_a_only_101_more_matches(self):
        self.assertEqual(self.r['cohorts']['GKI']['a_match_gain'],78)
        self.assertEqual(self.r['cohorts']['QGKI']['a_match_gain'],23)
        self.assertEqual(self.r['overall']['R30_A_extra_match_occurrences'],101)

    def test_09_r30_b_no_match_gain(self):
        self.assertEqual(self.r['overall']['R30_B_extra_matches_over_A'],0)

    def test_10_no_fully_compatible_modules(self):
        self.assertTrue(all(self.r['cohorts'][c]['historical_complete_external_ko_modules']==0 for c in a.COHORTS))

    def test_11_836_conflicts(self):
        self.assertEqual(self.r['overall']['shared_name_conflicting_expected_crcs'],836)
        self.assertTrue(self.r['overall']['cannot_match_both_crc_cohorts_as_one_kernel_symvers'])

    def test_12_walt_candidate_strictly_separate(self):
        r=self.r['historical_R28_R38_independent_WALT_research']
        self.assertEqual((r['matches'],r['mismatches'],r['missing']),(6960,7653,35))
        self.assertFalse(r['kernel_built_by_R38'])
        self.assertFalse(r['source_directly_graftable_to_R61'])

    def test_13_failed_r28_config_variants_not_promoted(self):
        r=self.r['historical_R28_R38_independent_WALT_research']
        self.assertEqual((r['nrcpus_variant_lost_matches'],r['kabi_variant_lost_matches'],r['oemdata_variant_lost_matches']),(77,431,88))

    def test_14_root_capture_not_module_catalog_proof(self):
        d=self.r['device_runtime']
        self.assertEqual((d['observed_loaded_ko_count_at_capture'],d['sysfs_module_name_count']),(0,136))
        self.assertFalse(d['actually_used_binary_cohort_proven'])
        self.assertFalse(d['raw_personal_capture_included'])

    def test_15_symbol_matrix_4501(self):
        rows=list(csv.DictReader(io.StringIO(self.out['R61_QGKI_GKI_SYMBOL_MATRIX.csv'].decode())))
        self.assertEqual(len(rows),4501)
        self.assertEqual(sum(int(v['QGKI_GKI_EXPECTED_CRC_CONFLICT']=='YES') for v in rows),836*2)

    def test_16_module_matrix_218(self):
        rows=list(csv.DictReader(io.StringIO(self.out['R61_QGKI_GKI_PER_MODULE.csv'].decode())))
        self.assertEqual(len(rows),218)
        self.assertTrue(all(r['historical_R61_imports_all_match']=='NO' for r in rows))
        self.assertTrue(all(r['runtime_active_proven']=='NO' for r in rows))

    def test_17_nine_original_priority_paths(self):
        rows=list(csv.DictReader(io.StringIO(self.out['R61_NINE_RMNET_IPA_BLOCKERS.csv'].decode())))
        self.assertGreater(len(rows),200)
        self.assertEqual(len({(r['cohort'],r['module']) for r in rows}),9)

    def test_18_config_16_only(self):
        rows=list(csv.DictReader(io.StringIO(self.out['R61_R30A_CONFIG_CANDIDATE.csv'].decode())))
        self.assertEqual(len(rows),16)
        self.assertTrue(all(r['apply_to_R61'].startswith('NO__') for r in rows))

    def test_19_checksum_index_exact(self):
        checks=self.out['SHA256SUMS.txt'].decode().splitlines()
        self.assertEqual(len(checks),len(self.out)-1)
        for row in checks:
            digest,name=row.split('  ',1);self.assertEqual(a.sh(self.out[name]),digest)

    def test_20_deterministic_outputs(self):
        r2,o2=a.audit(INPUTS)
        self.assertEqual(o2,self.out)
        self.assertEqual(r2,self.r)

    def test_21_requires_distinct_cohorts(self):
        self.assertNotEqual(self.r['cohorts']['GKI']['modules'],self.r['cohorts']['QGKI']['modules'])
        self.assertEqual(self.r['overall']['kernel_candidate_matching'],6286)

    def test_22_no_source_tampering_or_crc_spoof(self):
        self.assertTrue(self.r['no_source_mutation'])
        self.assertTrue(self.r['no_config_mutation'])
        self.assertTrue(self.r['no_crc_forge'])

    def test_23_zip_origins_pinned(self):
        self.assertEqual(a.SHA['R30_R2_ORIGINAL_REPORTS.zip'],'b9fa160e9e0a2519ad960bdf5f158e2fc6dbe81702d0737971f9959cf5202480')
        self.assertEqual(a.SHA['R28_ORIGINAL_REPORTS.zip'],'44587f8a3c4e66222b9d26812c6e0f9200084dd4d6d1004c7e787bbe0943dbe0')

    def test_24_outputs_never_contain_raw_device_capture(self):
        self.assertNotIn('SU_UID=0',b'\n'.join(self.out.values()).decode())
        self.assertNotIn('ro.build.version.incremental=',b'\n'.join(self.out.values()).decode())

    def test_25_extra_file_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);self._copy(d);(d/'EXTRA.txt').write_text('invalid')
            with self.assertRaisesRegex(a.GateError,'EXACT_INPUT_FILESET_REQUIRED'):a.audit(d)

    def test_26_missing_file_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);self._copy(d);(d/'R30_R2_ORIGINAL_REPORTS.zip').unlink()
            with self.assertRaisesRegex(a.GateError,'EXACT_INPUT_FILESET_REQUIRED'):a.audit(d)

    def test_27_input_dir_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            link=Path(td)/'link';link.symlink_to(INPUTS, target_is_directory=True)
            with self.assertRaisesRegex(a.GateError,'INPUT_DIRECTORY_MISSING_OR_LINK'):a.audit(link)

    def test_28_output_rerun_refused(self):
        with tempfile.TemporaryDirectory() as td:
            q=Path(td)/'present';q.mkdir()
            # main enforces output immutability; test the exact guard expression.
            with self.assertRaisesRegex(a.GateError,'OUTPUT_ALREADY_EXISTS'):a.require(not q.exists(),'OUTPUT_ALREADY_EXISTS')

    def _copy(self,d:Path):
        for file in INPUTS.iterdir():shutil.copyfile(file,d/file.name)

# All 10 independent evidence files are SHA-locked, regardless of payload type.
for _filename in a.SHA:
    def check(self,name=_filename):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);self._copy(d);f=d/name
            f.write_bytes(f.read_bytes()+b'X')
            with self.assertRaisesRegex(a.GateError,'INPUT_SHA_MISMATCH:'):a.audit(d)
    setattr(ABIReconciliationTests,'test_29_tamper_'+_filename.replace('.','_').replace('-','_'),check)

if __name__=='__main__':unittest.main()
