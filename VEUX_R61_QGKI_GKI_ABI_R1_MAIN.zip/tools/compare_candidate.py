#!/usr/bin/env python3
"""Additional *read-only* OEM cohort comparison for a later REAL Module.symvers.

The user supplies Module.symvers from a newly compiled kernel candidate. This
compares the actual CRCs to historical imported .ko __versions, but never
asserts that those OEM binaries are currently loaded or that a boot is safe.
"""
from __future__ import annotations
import argparse,csv,hashlib,io,json,re
from pathlib import Path
import zipfile
import abi_reconcile as base

CRC=re.compile(r'^0x[0-9a-fA-F]{1,8}$')

def read_symvers(path:Path)->dict[str,str]:
    base.require(path.is_file() and not path.is_symlink(),'SYMVERS_NOT_REGULAR')
    data=path.read_bytes()
    base.require(0<len(data)<=20_000_000,'SYMVERS_SIZE_INVALID')
    rows={}
    for line in data.decode('utf-8').splitlines():
        if not line.strip():continue
        parts=line.split()
        base.require(len(parts)>=3 and bool(CRC.fullmatch(parts[0])),'MALFORMED_REAL_SYMVERS_LINE')
        code=f'0x{int(parts[0],16):08x}'
        k=parts[1]
        base.require(k not in rows or rows[k]==code,'CANDIDATE_SYMVERS_CONFLICTING_CRC:'+k)
        rows[k]=code
    base.require(len(rows)>=500,'SYMVERS_TOO_SMALL_FOR_OEM_COMPARE')
    base.require('module_layout' in rows,'SYMVERS_NO_MODULE_LAYOUT')
    return rows

def compare(inputs:Path,symvers:Path)->tuple[dict,dict[str,bytes]]:
    original,_=base.audit(inputs)
    new=read_symvers(symvers)
    with zipfile.ZipFile(inputs/'R30_R2_ORIGINAL_REPORTS.zip') as z:
        symbols=base.csv_rows(z,'R30_R2_ALL_SYMBOLS.csv')
        nine=base.csv_rows(z,'R30_R2_NINE_DEVICE_BLOCKERS.csv')
    counts={c:{'MATCH':0,'CRC_MISMATCH':0,'NOT_EXPORTED':0} for c in base.COHORTS}
    symbol_output=[]
    for row in symbols:
        observed=new.get(row['symbol'],'')
        expected=row['stock_import_expected_crc'].lower()
        state='NOT_EXPORTED' if not observed else ('MATCH' if observed==expected else 'CRC_MISMATCH')
        counts[row['cohort']][state]+=int(row['import_occurrences'])
        symbol_output.append({'cohort':row['cohort'],'symbol':row['symbol'],
                'historical_ko_import_occurrences':row['import_occurrences'],
                'historical_ko_expected_crc':row['stock_import_expected_crc'],
                'actual_compiled_candidate_crc':observed,'candidate_status':state,
                'r61_baseline_status':row['R13_status'],
                'candidate_change_vs_r61':row['R13_status']+'->'+state})
    for c in base.COHORTS:
        base.require(sum(counts[c].values())==original['cohorts'][c]['import_occurrences'],'CANDIDATE_IMPORT_CONSERVATION_FAILED:'+c)
    result={
        'schema':'VEUX_R61_QGKI_GKI_FUTURE_CANDIDATE_COMPARISON_V1',
        'input_module_symvers_sha256':hashlib.sha256(symvers.read_bytes()).hexdigest(),
        'status':'REAL_SYMVERS_BYTES_EVALUATED__SOURCE_AND_BUILD_PROVENANCE_NOT_INFERRED__NOFLASH',
        'candidate_exported_symbols':len(new),
        'candidate_module_layout':new['module_layout'],
        'baseline_module_symvers_sha256':base.R61_SYMVERS_SHA,
        'cohorts':{c:{'candidate':counts[c],'r61':original['cohorts'][c]['R61'],
                        'matched_gain_vs_R61':counts[c]['MATCH']-original['cohorts'][c]['R61']['MATCH']} for c in base.COHORTS},
        'cannot_claim_both_cohort_abi':True,
        'historical_complete_module_count_not_inferred_from_aggregated_table':True,
        'candidate_kernel_compile_proven_by_this_tool':False,
        'active_modules_binary_identity_proven':False,
        'device_boot_verified':False,'flash_allowed':False,'module_symvers_modified':False,
    }
    nresults=[]
    mods={}
    for row in nine:
        name=(row['cohort'],row['module'])
        want=row['expected_crc'].lower();actual=new.get(row['symbol'],'')
        state='NOT_EXPORTED' if not actual else ('MATCH' if want==actual else 'CRC_MISMATCH')
        nresults.append({**row,'candidate_actual_crc':actual,'candidate_status':state})
        mods.setdefault(name,[]).append(state)
    # Original R30 'nine blockers' file lists only imports failing at least one variant;
    # these records are insufficient for asserting all imports across nine modules.
    result['nine_priority_paths_with_remaining_known_blockers']=sum('MATCH'!=s for vals in mods.values() for s in vals)
    result['nine_priority_modules_all_imports_compatible']=False
    def j(obj):return (json.dumps(obj,indent=2,sort_keys=True)+'\n').encode()
    def c(rows):
        buf=io.StringIO(newline='');w=csv.DictWriter(buf,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);return buf.getvalue().encode()
    out={'CANDIDATE_COMPARE_RESULT.json':j(result),
         'CANDIDATE_QGKI_GKI_SYMBOL_MATRIX.csv':c(symbol_output),
         'CANDIDATE_NINE_KNOWN_RMNET_IPA_BLOCKERS.csv':c(nresults)}
    out['SHA256SUMS.txt']=''.join(f'{base.sh(x)}  {n}\n' for n,x in sorted(out.items())).encode()
    return result,out

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',required=True,type=Path);ap.add_argument('--candidate-symvers',required=True,type=Path);ap.add_argument('--out',required=True,type=Path)
    args=ap.parse_args();res,files=compare(args.inputs,args.candidate_symvers)
    base.require(not args.out.exists(),'OUTPUT_ALREADY_EXISTS')
    args.out.mkdir(parents=True)
    for name,data in files.items():(args.out/name).write_bytes(data)
    print('CANDIDATE_COHORT_COMPARE=PASS; CRCS_MEASURED=YES; COMPILER_PROVEN=NO; FLASH=NO')

if __name__=='__main__':main()
