#!/usr/bin/env python3
"""Reconcile immutable historical VEUX QGKI/GKI ABI observations with R61.

READ-ONLY: no kernel source mutation, Module.symvers rewrite, CRC spoof,
module loading, firmware writes, installer or flash instructions.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import zipfile

SHA = {
    'R30_R2_ORIGINAL_REPORTS.zip': 'b9fa160e9e0a2519ad960bdf5f158e2fc6dbe81702d0737971f9959cf5202480',
    'R28_ORIGINAL_REPORTS.zip': '44587f8a3c4e66222b9d26812c6e0f9200084dd4d6d1004c7e787bbe0943dbe0',
    'R38_ORIGINAL_REPORTS.zip': '51fb5117cf6b86337470af8e8f291bfef82b52467d355e947f4ae74eb84011c0',
    'R61_NOMOUNT22_COMPILED.json': '0f3d80f290ff35f9dc699990cb2cf4da34e2b106f5b1debe8450ecf9a3062a6d',
    'R59_VENDOR_ABI.json': 'd9b481d558e429ed7694caeaa529e6433452e41515659923f6cdc0a4ec4f3e36',
    'R60_ABI_COHORT_CONFLICTS.json': '8d752ea5512e305e42e1743d65a71eaf3caf6741189d61963c192bb8e87252aa',
    'R60_FINAL_RELEASE_GUARD.json': '62818242170e0f2892237b61e1f97f7f55692210c2b7a1c363ec3974e2fcfc87',
    'R58_COMPILE_STATUS.json': '5a89ee5ef63757e02665720e2a912230b19d2582fe1d9c61c3d1679fe25a669a',
    'R59_FULL_INTEGRATION_EVIDENCE.json': '7c9ef4db07dd3e1f76e462f6bc456b0553ad1b14d77874e24d0954be3166e7a8',
    'DEVICE_ROOT_AGGREGATE.json': 'fc973a62b49cf5d9e1160586647d9f6476b66601db3e9d7fb67b0bfb67149a08',
}
R61_RUN = 42204174279
R61_SOURCE_COMMIT = '5870fd9d5ff74991dc66abdab0e642fffeecba1e'
R61_IMAGE_SHA = '39743f9039e3bf2ef1298db750b7c40a7e142075ba92acf677cc404101565dba'
R61_SYMVERS_SHA = '0b5f909c68ec375533e961ac106da49c71b25f4fc99e6d13d0d093a52a540ec2'
R61_CONFIG_SHA = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
R30_FIELDS = {'R13','A','B'}
COHORTS = ('QGKI','GKI')
STATES = ('MATCH','CRC_MISMATCH','NOT_EXPORTED')
REPORTS = ('R61_QGKI_GKI_RESULT.json','R61_QGKI_GKI_PER_MODULE.csv',
           'R61_QGKI_GKI_SYMBOL_MATRIX.csv','R61_NINE_RMNET_IPA_BLOCKERS.csv',
           'R61_R30A_CONFIG_CANDIDATE.csv','R61_ABI_PRIORITIES.csv',
           'R61_ABI_ENTSCHEIDUNG_DE.md','R61_PROVENANCE.json','SHA256SUMS.txt')

class GateError(RuntimeError):
    pass

def require(test:bool, reason:str)->None:
    if not test:raise GateError(reason)

def sh(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def csv_rows(z:zipfile.ZipFile,name:str)->list[dict]:
    return list(csv.DictReader(io.StringIO(z.read(name).decode('utf-8'))))

def load_inputs(directory:Path)->dict:
    require(directory.is_dir() and not directory.is_symlink(),'INPUT_DIRECTORY_MISSING_OR_LINK')
    require({x.name for x in directory.iterdir()}==set(SHA),'EXACT_INPUT_FILESET_REQUIRED')
    for name,expected in SHA.items():
        p=directory/name
        require(p.is_file() and not p.is_symlink(),'INPUT_NOT_REGULAR:'+name)
        require(sh(p.read_bytes())==expected,'INPUT_SHA_MISMATCH:'+name)
    d={name:json.loads((directory/name).read_text()) for name in SHA if name.endswith('.json')}
    for short,full in [('r30','R30_R2_ORIGINAL_REPORTS.zip'),('r28','R28_ORIGINAL_REPORTS.zip'),('r38','R38_ORIGINAL_REPORTS.zip')]:
        z=zipfile.ZipFile(directory/full)
        require(z.testzip() is None,'ARCHIVE_CRC_FAILURE:'+short)
        require(len(z.namelist())==len(set(z.namelist())),'DUPLICATE_MEMBER:'+short)
        d[short+'_zip']=z
    return d

def audit(directory:Path)->tuple[dict,dict[str,bytes]]:
    d=load_inputs(directory)
    z=d['r30_zip'];r28=d['r28_zip'];r38=d['r38_zip']
    require(set(z.namelist())=={
        'R30_R2_ALL_MODULES.csv','R30_R2_ALL_SYMBOLS.csv',
        'R30_R2_CONFIG_DIFFERENCES.csv','R30_R2_NINE_DEVICE_BLOCKERS.csv',
        'R30_R2_NINE_DEVICE_MODULES.csv','R30_R2_OEM_COHORT_CRC_CONFLICTS.csv',
        'R30_R2_PRUEFBERICHT_DE.txt','R30_R2_RESULTS.json','R30_R2_TOP_PRIORITY_SYMBOLS.csv'},
        'R30_HISTORICAL_REPORT_MEMBER_DRIFT')
    m=csv_rows(z,'R30_R2_ALL_MODULES.csv')
    symbols=csv_rows(z,'R30_R2_ALL_SYMBOLS.csv')
    conflicts=csv_rows(z,'R30_R2_OEM_COHORT_CRC_CONFLICTS.csv')
    nine=csv_rows(z,'R30_R2_NINE_DEVICE_BLOCKERS.csv')
    flags=csv_rows(z,'R30_R2_CONFIG_DIFFERENCES.csv')
    rank=csv_rows(z,'R30_R2_TOP_PRIORITY_SYMBOLS.csv')
    r30=json.loads(z.read('R30_R2_RESULTS.json'))
    r28summary=json.loads(r28.read('R28_RESULT.json'))
    r38summary=json.loads(r38.read('R38_RESULT.json'))
    r61=d['R61_NOMOUNT22_COMPILED.json']
    vendor=d['R59_VENDOR_ABI.json'];cohort=d['R60_ABI_COHORT_CONFLICTS.json']
    guard=d['R60_FINAL_RELEASE_GUARD.json'];compile=d['R58_COMPILE_STATUS.json']
    integration=d['R59_FULL_INTEGRATION_EVIDENCE.json'];device=d['DEVICE_ROOT_AGGREGATE.json']
    require(r61.get('schema')=='VEUX_R61_NOMOUNT22_ONLY_COMPILE_V2','R61_COMPILE_SCHEMA_CHANGED')
    require(r61.get('status')=='NOMOUNT_V22_BUILT_WITH_FROZEN_R60_BAKASU35260_SUSFS230','R61_COMPILE_STATUS_CHANGED')
    require(r61.get('nomount_protocol')==22 and r61.get('bakasu_version')==35260 and r61.get('susfs_version')=='2.3.0','R61_COMPONENTS_DRIFT')
    require(r61.get('files',{}).get('MODULE_SYMVERS',{}).get('sha256')==R61_SYMVERS_SHA,'R61_SYMBOL_TABLE_CHANGED')
    require(r61.get('files',{}).get('ARM64_IMAGE',{}).get('sha256')==R61_IMAGE_SHA,'R61_IMAGE_CHANGED')
    require(r61.get('preserved_r60_config_sha256')==R61_CONFIG_SHA,'R61_CONFIG_CHANGED')
    require(r61.get('vendor_abi_proven') is False and r61.get('flash_allowed') is False and r61.get('device_test') is False,'R61_UNSUPPORTED_RELEASE_CLAIM')
    require(integration.get('source_and_compiler_pass') is True and integration.get('rmnet_132_all_match') is True,'R61_COMPILE_OR_RMNET_BASELINE_FAIL')
    require(compile.get('compile_link_proof') is True and compile.get('RMNET_132_matched')==132,'R61_LINK_OR_RMNET_PROOF_FAIL')
    require(compile.get('AK3_static_boot_proven') is False and compile.get('OEM_218_module_abi_proven') is False,'R61_FALSE_BOOT_OR_ABI_PROOF')
    require(vendor.get('schema')=='VEUX_R14_VENDOR_ABI_RESEARCH_ONLY_V1','VENDOR_REPORT_SCHEMA_CHANGED')
    require(vendor.get('sha256',{}).get('candidate_module_symvers')==R61_SYMVERS_SHA,'VENDOR_COMPARISON_NOT_SAME_R61_SYMVERS')
    require(vendor.get('module_layout',{}).get('candidate')=='0xbff14f69','R61_MODULE_LAYOUT_DIFFERENT')
    require(guard.get('vendor_imports_checked')==14648 and guard.get('historical_vendor_files')==218,'OEM_INVENTORY_CHANGED')
    require(guard.get('candidate_matching_imports')==6286 and guard.get('candidate_crc_mismatches')==7827 and guard.get('candidate_not_exported')==535,'R61_VENDOR_MATCH_COUNTS_CHANGED')
    require(guard.get('flash_allowed') is False and guard.get('full_component_release_approved') is False,'FALSE_RELEASE_GATE')
    require(cohort.get('historical_imports_by_cohort')=={'GKI':11500,'QGKI':3148},'OEM_IMPORT_COHORT_COUNT_CHANGED')
    require(cohort.get('installed_module_files_by_cohort')=={'GKI':181,'QGKI':37},'OEM_MODULE_COHORT_COUNT_CHANGED')
    require(cohort.get('module_layout')=={'GKI':'0x1e5b7ab7','QGKI':'0x945d02f2'},'OEM_LAYOUT_COHORT_CHANGED')
    require(cohort.get('conflicting_symbol_names')==836 and len(cohort.get('conflicting_symbols',[]))==836,'OEM_CRC_COHORT_CONFLICT_CHANGED')
    require(cohort.get('active_cohort_at_device_boot_proven') is False,'FALSE_ACTIVE_COHORT_PROOF')
    require(device.get('root_capture_succeeded') is True and device.get('loaded_module_count_at_capture')==0,'CAPTURE_OBSERVATION_CHANGED')
    require(device.get('live_binary_identity_of_active_oem_ko_proven') is False and device.get('raw_capture_embedded') is False,'UNSUPPORTED_RUNTIME_OR_PRIVACY_CLAIM')
    require(r30.get('status')=='OFFLINE_CRC_DIAG_PASS__FULL_OEM_ABI_BLOCKED__NO_FLASH','R30_REPORT_NOT_AUTHENTIC')
    require(len(m)==218 and len(symbols)==4501 and len(conflicts)==836,'R30_TABLE_COUNTS_CHANGED')
    require(len({(x['cohort'],x['module']) for x in m})==218,'DUPLICATE_OEM_MODULE')
    require(len({(x['cohort'],x['symbol']) for x in symbols})==4501,'DUPLICATE_OEM_COHORT_SYMBOL')
    require(len(nine)>0 and len(rank)>0 and len(flags)==934,'R30_AUXILIARY_TABLE_INCOMPLETE')
    require(set(x['cohort'] for x in m)==set(COHORTS),'UNKNOWN_COHORT')
    require(r28summary['schema']=='VEUX_R28_STRUCTURAL_ABI_EVIDENCE_V1' and r38summary['schema']=='VEUX_R38_OVERLAY_STRUCTURAL_VENDOR_ABI_TRIAGE_V1','R28_R38_EVIDENCE_CHANGED')
    require(r28summary['reference']=='R20-R11 WALT_ON' and r38summary['kernel_built'] is False,'R28_R38_NOT_COMPARABLE_BUILD')
    require(r28summary['r20_import_status']=={'MATCH':6960,'CRC_MISMATCH':7653,'ABSENT_IN_SYMVERS':35},'R28_RESEARCH_NUMBERS_CHANGED')
    require([r38summary['vendor_crc_matches'],r38summary['vendor_crc_mismatches'],r38summary['vendor_missing_exports']]==[6960,7653,35],'R38_VENDOR_COMPARISON_CHANGED')
    require(r38summary.get('vendor_abi_proven') is False and r38summary.get('flash_allowed') is False,'R38_FALSE_RELEASE_GATE')
    # Cross-check every one of the 14,648 import occurrences from an independent source.
    tally={cohort:{v:{s:0 for s in STATES} for v in R30_FIELDS} for cohort in COHORTS}
    mod_counts={}
    for row in m:
        cohort_name=row['cohort'];require(cohort_name in COHORTS,'UNKNOWN_MODULE_COHORT')
        mod_counts[cohort_name]=mod_counts.get(cohort_name,0)+1
        count=int(row['import_count'])
        for version in R30_FIELDS:
            sum_parts=sum(int(row[f'{version}_{state}']) for state in STATES)
            require(count==sum_parts,'INCOMPLETE_IMPORTS:'+row['module']+':'+version)
            for state in STATES:tally[cohort_name][version][state]+=int(row[f'{version}_{state}'])
            require(row[f'{version}_full_import_compatible']=='NO','HISTORICAL_MODULE_ABI_FALSELY_GREEN')
    require(mod_counts=={'GKI':181,'QGKI':37},'OEM_PER_MODULE_COHORT_COUNT_CHANGED')
    sum_by_symbol={name:{v:{s:0 for s in STATES} for v in R30_FIELDS} for name in COHORTS}
    for row in symbols:
        require(row['cohort'] in COHORTS,'UNKNOWN_SYMBOL_COHORT')
        n=int(row['import_occurrences'])
        for v in R30_FIELDS:
            state=row[f'{v}_status'];require(state in STATES,'INVALID_IMPORT_STATUS')
            sum_by_symbol[row['cohort']][v][state]+=n
    require(sum_by_symbol==tally,'PER_SYMBOL_AND_MODULE_TALLY_DIFFER')
    require(tally['QGKI']['R13']=={'MATCH':1303,'CRC_MISMATCH':1752,'NOT_EXPORTED':93},'R61_QGKI_COUNTS_CHANGED')
    require(tally['GKI']['R13']=={'MATCH':4983,'CRC_MISMATCH':6075,'NOT_EXPORTED':442},'R61_GKI_COUNTS_CHANGED')
    require(tally['QGKI']['A']=={'MATCH':1326,'CRC_MISMATCH':1792,'NOT_EXPORTED':30},'R30_A_QGKI_CHANGED')
    require(tally['GKI']['A']=={'MATCH':5061,'CRC_MISMATCH':6308,'NOT_EXPORTED':131},'R30_A_GKI_CHANGED')
    require(tally['QGKI']['B']=={'MATCH':1326,'CRC_MISMATCH':1805,'NOT_EXPORTED':17},'R30_B_QGKI_CHANGED')
    require(tally['GKI']['B']=={'MATCH':5061,'CRC_MISMATCH':6373,'NOT_EXPORTED':66},'R30_B_GKI_CHANGED')
    for coh in COHORTS:
        require(vendor['candidate']['groups'][coh]==tally[coh]['R13'],'R61_AND_R30_R13_COHORT_AGGREGATE_DIFFER:'+coh)
        require(sum(tally[coh]['R13'].values())==cohort['historical_imports_by_cohort'][coh],'R61_COHORT_SIZE_CHANGED')
    for cr in conflicts:
        require(cr['QGKI_expected_crc']!=cr['GKI_expected_crc'],'FALSE_COHORT_CONFLICT:'+cr['symbol'])
    require(len({x['symbol'] for x in conflicts})==836,'DUPLICATE_CONFLICT_SYMBOL')
    layout=[x for x in symbols if x['symbol']=='module_layout']
    require(len(layout)==2 and {x['cohort'] for x in layout}==set(COHORTS),'MISSING_LAYOUT_IN_COHORT_MATRIX')
    for v in R30_FIELDS:
        require(layout[0][f'{v}_crc']==layout[1][f'{v}_crc'],'CONTRADICTORY_SINGLE_CANDIDATE_SYMVERS')
        require(all(x[f'{v}_status']=='CRC_MISMATCH' for x in layout),'MODULE_LAYOUT_FALSELY_MATCHES')
    require({x['A_vs_R13'] for x in flags}=={'DIFFERENT','SAME'},'A_CONFIG_DIFF_REPORT_INVALID')
    diff_a=[x for x in flags if x['A_vs_R13']=='DIFFERENT']
    require(len(diff_a)==16 and sum(x['B_vs_A']=='DIFFERENT' for x in flags)==34,'CONFIG_VARIANTS_CHANGED')
    require(next(x for x in diff_a if x['config_flag']=='CONFIG_IPC_LOGGING')['A_value']=='y','R30_A_IPC_LOGGING_MISSING')
    require(next(x for x in flags if x['config_flag']=='CONFIG_SCHED_WALT')['STOCK_value']=='y','STOCK_SCHED_WALT_NOT_Y')
    require(next(x for x in flags if x['config_flag']=='CONFIG_NR_CPUS')['STOCK_value']=='32','STOCK_NR_CPUS_NOT_32')
    require(next(x for x in flags if x['config_flag']=='CONFIG_NR_CPUS')['R13_value']=='8','R61_NR_CPUS_DRIFT')
    for x in nine:
        require(x['R13_status'] in STATES and x['A_status'] in STATES and x['B_status'] in STATES,'NINE_MODULE_STATUS_INVALID')
    sums={coh:{v:{s:int(tally[coh][v][s]) for s in STATES} for v in sorted(R30_FIELDS)} for coh in COHORTS}
    source=R61_SYMVERS_SHA
    total={'MATCH':6286,'CRC_MISMATCH':7827,'NOT_EXPORTED':535}
    for state in STATES: require(sum(sums[c]['R13'][state] for c in COHORTS)==total[state],'R61_TOTALS_CHANGED')
    # Separate, noninterchangeable experimental builds are represented, never grafted.
    delta_a={coh:sums[coh]['A']['MATCH']-sums[coh]['R13']['MATCH'] for coh in COHORTS}
    require(delta_a=={'GKI':78,'QGKI':23},'R30_A_GAIN_CHANGED')
    require(all(sums[c]['A']['MATCH']==sums[c]['B']['MATCH'] for c in COHORTS),'R30_B_MATCH_GAIN_UNEXPECTED')
    result={
        'schema':'VEUX_R61_QGKI_GKI_IMMUTABLE_ABI_REFERENCE_V1',
        'status':'HISTORICAL_COHORTS_RECONCILED__R61_KERNEL_FROZEN__ABI_NOT_PROVEN__NOFLASH',
        'r61':{'run_id':R61_RUN,'source_commit':R61_SOURCE_COMMIT,'kernel_version':'5.4.274','compiler_pass':True,
                'r61_image_sha256':R61_IMAGE_SHA,'module_symvers_sha256':source,'config_sha256':R61_CONFIG_SHA,
                'bakasu_version':35260,'susfs_version':'2.3.0','nomount_version':'22 (605)',
                'scheduler':'CASS','walt_enabled':False,'rmnet_132_built_in_crc_pass':True,
                'boot_verified':False,'vendor_abi_proven':False,'flash_allowed':False},
        'cohorts':{c:{'modules':mod_counts[c],'import_occurrences':sum(sums[c]['R13'].values()),
                'R61':sums[c]['R13'],'R30_A_RESEARCH':sums[c]['A'],'R30_B_RESEARCH':sums[c]['B'],
                'a_match_gain':delta_a[c], 'b_match_gain':0,
                'historical_complete_external_ko_modules':0} for c in COHORTS},
        'overall':{'module_catalog_count':218,'historical_imports':14648,'kernel_candidate_matching':6286,
                   'kernel_candidate_crc_mismatches':7827,'kernel_candidate_missing_exports':535,
                   'R30_A_extra_match_occurrences':101,'R30_B_extra_matches_over_A':0,
                   'shared_name_conflicting_expected_crcs':836,'cannot_match_both_crc_cohorts_as_one_kernel_symvers':True},
        'historical_R28_R38_independent_WALT_research':{'label':'R20-R11 WALT_ON, NOT R61, NOT R30-A',
                   'matches':6960,'mismatches':7653,'missing':35,'kernel_built_by_R38':False,
                   'boot_verified':False,'nrcpus_variant_lost_matches':77,
                   'kabi_variant_lost_matches':431,'oemdata_variant_lost_matches':88,
                   'source_directly_graftable_to_R61':False},
        'device_runtime':{'observed_loaded_ko_count_at_capture':0,'sysfs_module_name_count':device['sysfs_module_names_count'],
                  'actually_used_binary_cohort_proven':False,'captured_from_original_root_report':True,
                  'raw_personal_capture_included':False,'provenance_sha256':device['source_sha256']},
        'no_source_mutation':True,'no_crc_forge':True,'no_config_mutation':True,'no_firmware_write':True,
        'no_flashable_artifact':True,'flash_allowed':False,
        'next_safe_gate':'Select one evidenced active cohort; compile a coherent kernel variant and compare its REAL Module.symvers, config, DTB/DTBO and boot evidence; never copy CRCs.',
    }
    modules=[]
    for row in sorted(m,key=lambda x:(x['cohort'],x['module'])):
        modules.append({'cohort':row['cohort'],'module':row['module'],'historical_imports':row['import_count'],
        'R61_matched':row['R13_MATCH'],'R61_crc_mismatched':row['R13_CRC_MISMATCH'],
        'R61_missing':row['R13_NOT_EXPORTED'], 'R30_A_matched':row['A_MATCH'],
        'R30_A_crc_mismatched':row['A_CRC_MISMATCH'],'R30_A_missing':row['A_NOT_EXPORTED'],
        'R30_A_match_gain':row['A_match_gain_vs_R13'], 'R30_B_matched':row['B_MATCH'],
        'historical_R61_imports_all_match':'NO',
        'runtime_binary_proven':'NO', 'runtime_active_proven':'NO',
        'priority':'HIGH_HISTORICAL_RMNET_IPA' if row['nine_device_module']=='YES' else 'REFERENCE_ONLY'})
    symbol_matrix=[]
    conflictset={x['symbol'] for x in conflicts}
    for x in sorted(symbols,key=lambda x:(x['cohort'],x['symbol'])):
        symbol_matrix.append({'cohort':x['cohort'],'symbol':x['symbol'],'import_occurrences':x['import_occurrences'],
        'stock_expected_crc':x['stock_import_expected_crc'],'R61_crc':x['R13_crc'],'R61_status':x['R13_status'],
        'R30_A_crc':x['A_crc'],'R30_A_status':x['A_status'],
        'R30_B_crc':x['B_crc'],'R30_B_status':x['B_status'],
        'QGKI_GKI_EXPECTED_CRC_CONFLICT':'YES' if x['symbol'] in conflictset else 'NO',
        'merge_source_allowed':'NO'})
    rr=[]
    for x in nine:rr.append({**x,'R61_compatible':'NO','module_currently_loaded_proven':'NO'})
    a_diff=[{'config_flag':x['config_flag'],'R61_R13_value':x['R13_value'],'R30_A_value':x['A_value'],
              'Stock_value':x['STOCK_value'],'apply_to_R61':'NO__BUILD_AND_ABI_VALIDATION_FIRST'} for x in diff_a]
    priorities=[]
    for x in rank:
        priorities.append({'cohort':x['cohort'],'symbol':x['symbol'],'imports':x['import_occurrences'],
            'nine_module_affected':x.get('nine_module_affected',''), 'R61_status':x['R13_status'],
            'R30_A_status':x['A_status'],'QGKI_GKI_EXPECTED_CRC_CONFLICT':'YES' if x['symbol'] in conflictset else 'NO',
            'source_fix':'REQUIRES_TYPES_KCONFIG_TOOLCHAIN_PROVENANCE'})
    decision=(
        '# VEUX R61 – QGKI/GKI-Kompatibilitaet: belegter Folgestand\n\n'
        '**Ergebnis:** Historische ABI-Daten reproduziert. R61 bleibt unveraendert. Kein Flash.\n\n'
        '## Bereits gesicherte Referenzen\n\n'
        '* R61-R4-R2: GitHub-Lauf 42204174279, ARM64 Image real gebaut, BakaSU 35260, SUSFS 2.3.0, NoMount 22 (605), CASS; WALT aus.\n'
        '* R30-R2: originale 218 OEM-Modulpfade, 14.648 CRC-Importe (37 QGKI, 181 GKI).\n'
        '* R28/R38: separater R20-R11-WALT-Forschungskandidat, **nicht** die R61-Quelle.\n\n'
        '## Historische Importmatrix (keine geladene-Modul-Garantie)\n\n'
        '| Kandidat | QGKI passend | GKI passend | Vollstaendige externe Modul-ABI |\n'
        '|---|---:|---:|---:|\n'
        '| R61 = R13 | 1303 / 3148 | 4983 / 11500 | 0 / 218 |\n'
        '| R30-A | 1326 / 3148 | 5061 / 11500 | 0 / 218 |\n'
        '| R30-B | 1326 / 3148 | 5061 / 11500 | 0 / 218 |\n'
        '| R20-R11 WALT_ON (andere Quelle) | **nur gesamt** 6960 / 14648 | - | NICHT bootgeprueft |\n\n'
        'R30-A lieferte gegenueber R61/R13 101 zusaetzliche korrekte Importvorkommen, '
        'aber **kein einziges** zusaetzlich komplett passendes externes OEM-Modul. '
        'R30-B bringt keine weiteren Matches. R28/R38 prueften einen **anderen** Kernel; dessen '
        'ABI-Zahlen duerfen nicht auf R61 oder ein Flashpaket uebertragen werden.\n\n'
        '## Warum nicht beide Kohorten blind zugleich?\n\n'
        '836 gleichnamige Imports erwarten unterschiedliche QGKI-/GKI-CRCs. '
        'Auch `module_layout`: QGKI 0x945d02f2, GKI 0x1e5b7ab7, R61 0xbff14f69. '
        'Ein einzelner unveraenderter Export kann nicht zugleich beide Erwartungen erfuellen.\n\n'
        '## Echte Geraeteevidenz (4.11.2026)\n\n'
        'Root-Leseprotokoll zeigte zu diesem Zeitpunkt `LOADED_MODULE_COUNT=0` in `/proc/modules`, '
        '136 Namen in `/sys/module`. Das beweist **nicht**, dass jedes historisch vorhandene `.ko` geladen '
        'oder zum Boot erforderlich ist. Die aktuelle binaere Herkunft geladener OEM-Module ist nicht nachgewiesen. '
        'Es muessen daher die ROM-Ladevorgaben, built-in-Treiber und tatsaechlich geladenen `.ko` getrennt bleiben.\n\n'
        '## Konkreter Weiterbau ohne erneuten R20-Quellenmix\n\n'
        '1. **R61-Basis eingefroren**: Image-/Symvers-/Config-Hashes und NoMount-Quellversion erhalten.\n'
        '2. **QGKI zuerst analysieren**, weil Stock-Identitaet `-qgki` lautet, aber erst nach aktivem Quellen-/Loaderbeleg freigeben.\n'
        '3. **R30-A-Konfigurationsdifferenz als separaten Versuch** (16 Aenderungen, davon IPC_LOGGING/Tracing): '
        'nicht in den funktionierenden R61-Baum einschreiben, bevor reale Neu-Kompilierung und Export-ABI pruefbar sind.\n'
        '4. **WALT-Quelle als getrennte Langfristoption**: nicht aus 5.4.61 ohne vollstaendige API-/Header-/Scheduler-Kohaerenz ueber R61 kopieren.\n'
        '5. **Nur echte CRCs aus einem neu kompilierten Module.symvers messen**. Keine Symvers-Manipulation, '
        'keine Modul-CRC-Spoofs, kein Root-Modul entfernen/deaktivieren.\n'
        '6. **Flash-Gate** bleibt bis OEM-Modul-/DTBO-/original Boot-Repack-/Boot-Checks und Geraeteergebnis gesperrt.\n\n'
        'Die CSV-Dateien enthalten alle 4.501 Kohorten-/Symbolkombinationen, 218 Module, '
        'neun priorisierte RMNET-/IPA-Pfade und die 16 exakten R30-A-Konfigurationsdifferenzen.\n'
    )
    prov={'schema':'VEUX_R61_GKI_QGKI_PROVENANCE_V1','r61_original_run':R61_RUN,'r61_commit':R61_SOURCE_COMMIT,
        'r61_logs_artifact_sha256':'e858359d5b17fd81824034250e639817408c1bf01aa8a45c09ef3fea906f3b03',
        'r61_image_artifact_sha256':'86ca7b35419654a026ef37e6e810a9c3dcf87f49004fef280d62633f13e8d5b4',
        'r30_reference_run':41228681481,'r28_reference_run':39980701048,'r38_reference_run':40080527188,
        'input_checksums':SHA,'device_private_capture_included':False,'no_build':True,'flash_allowed':False}
    def encode_json(data)->bytes:return (json.dumps(data,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
    def encode_csv(rows)->bytes:
        if not rows:raise GateError('EMPTY_CSV')
        obj=io.StringIO(newline='');w=csv.DictWriter(obj,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        return obj.getvalue().encode('utf-8')
    generated={
        'R61_QGKI_GKI_RESULT.json':encode_json(result),
        'R61_QGKI_GKI_PER_MODULE.csv':encode_csv(modules),
        'R61_QGKI_GKI_SYMBOL_MATRIX.csv':encode_csv(symbol_matrix),
        'R61_NINE_RMNET_IPA_BLOCKERS.csv':encode_csv(rr),
        'R61_R30A_CONFIG_CANDIDATE.csv':encode_csv(a_diff),
        'R61_ABI_PRIORITIES.csv':encode_csv(priorities),
        'R61_ABI_ENTSCHEIDUNG_DE.md':decision.encode('utf-8'),
        'R61_PROVENANCE.json':encode_json(prov)}
    generated['SHA256SUMS.txt']=''.join(f'{sh(v)}  {k}\n' for k,v in sorted(generated.items())).encode('utf-8')
    require(set(generated)==set(REPORTS),'OUTPUT_SET_CHANGED')
    for zi in (z,r28,r38):zi.close()
    return result,generated

def main():
    a=argparse.ArgumentParser();a.add_argument('--inputs',type=Path,required=True);a.add_argument('--out',type=Path,required=True)
    x=a.parse_args();r,files=audit(x.inputs)
    require(not x.out.exists(),'OUTPUT_ALREADY_EXISTS')
    x.out.mkdir(parents=True)
    for name,data in files.items():(x.out/name).write_bytes(data)
    print('R61_QGKI_GKI_HISTORICAL_RECONCILIATION=PASS',r['overall']['historical_imports'],'IMPORTS',r['overall']['shared_name_conflicting_expected_crcs'],'COHORT_CONFLICTS')
    print('R61_BASELINE=UNMODIFIED; OEM_ABI=UNPROVEN; FLASH=NO')

if __name__=='__main__':main()
