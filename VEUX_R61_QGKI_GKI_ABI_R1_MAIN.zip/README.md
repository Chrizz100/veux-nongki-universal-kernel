# VEUX R61 – QGKI/GKI OEM-ABI-Rekonstruktion aus vorhandenen Originalen

**Fester Ausgangspunkt:** GitHub R61-R4-R2, Lauf 42204174279 (grün), BakaSU 35260, SUSFS 2.3.0, NoMount 2.2.0 (22/605), CASS, Linux 5.4.274.

**Vollständig wiederverwendete Originalbelege:**
- R28 GitHub-Lauf 39980701048 (OEM-CRC-Konflikte, R20-R11 WALT-Forschung)
- R30-R2 GitHub-Lauf 41228681481 (218 Module, 14648 Symbolimporte, R13/R30-A/R30-B)
- R38 GitHub-Lauf 40080527188 (WALT-ABI/DTBO-Strukturanalyse; nicht R61)
- R60/R61-Originalberichte aus GitHub-Lauf 42204174279 (Config/Module.symvers/Image-Bau, ABI und Identitaet)
- Root-Geräteaufzeichnung vom 4.11.2026, in **aggregierter** Form ohne personenbezogene Rohdaten

**Zweck:** Alle alten QGKI/GKI-CRC-Werte und 218 Modulpfade mit der wirklich kompilierten R61-Basis verknuepfen und deren Provenienz/Abhaengigkeiten nachweisen. Fuer jeden Symbol-/Kohorteneintrag zeigt die Matrix den OEM-Import-CRC, R61/R13, R30-A und R30-B samt Konfliktmarkierung. Zusaetzlich sind historische RMNET/IPA-Blocker, 16 R30-A-Konfigurationsaenderungen, Quellenentscheidung, Pruefsummen und ein gerätebezogener Nachweisstatus enthalten.

**Bewiesene Grenzen:** 836 gleiche Symbolnamen erwarten unterschiedliche QGKI-/GKI-CRCs. Die originale aktive Modulbinary-Kohorte ist noch nicht nachgewiesen. R28/R38 mit 6960 Matches ist ein **anderer** WALT-On-Kernel und keine fertige R61-Abi-Reparatur. R30-A erzeugte 101 mehr passende Importvorkommen, aber NULL voll kompatible externe OEM-.ko. R30-B hat null zusaetzliche Matches gegen A. Die SHA-256 von R61 Module.symvers entspricht exakt der alten R13-Tabelle; es werden KEINE CRC-Werte gefaelscht oder ersetzt.

**Ergebnis der automatischen Action:** reproduzierbares ZIP der bereits bestehenden OEM-GKI/QGKI-Abhaengigkeiten als Grundlage fuer eine gezielte, isolierte **zukuenftige** Kandidatenkompilierung. Diese Action selbst baut **keinen** neuen Kernel und gibt **keine** Flashdateien aus.

Auf GitHub: Die beiden Dateien aus dem aeusseren READY-FOR-GITHUB-MAIN-ZIP in die enthaltenen Zielpfade auf Branch `main` hochladen, dann Actions > VEUX R61 QGKI GKI OEM ABI R1 - NOFLASH > Run workflow. Artefakt enthaelt `R61_QGKI_GKI_...`-CSV/JSON/Markdown plus CRC- und Quellprovenienz.

**Verbindlich:** Kein ReSukiSU/BakaSU-Update; keine SUSFS-/NoMount-Quellaenderung; kein Zwang zu WALT/Stock-Spoof; keine Root-Modul-Deaktivierung; keine vendor/init-Aenderung; keine Boot-/Flashfreigabe durch reine CRC-Diagnose.

## Reale neue Module.symvers fuer spaetere Kernel-Kandidaten

Der im Paket enthaltene *zusätzliche* Vergleich `tools/compare_candidate.py` kann eine **erst dann tatsaechlich neu kompilierte** `Module.symvers` direkt gegen dieselben 4.501 historischen Kohorten-/Symboleintraege pruefen:

```bash
python3 -B tools/compare_candidate.py --inputs inputs --candidate-symvers /PFAD/ZU/NEUER/Module.symvers --out /PFAD/ZU/LEEREM/ERGEBNISORDNER
```

Dazu muss die echte neue `Module.symvers` aus dem abgeschlossenen Kandidatenbuild uebergeben werden. Dieses Werkzeug veraendert die Datei niemals und behauptet nicht, aus Symvers allein einen Compiler-, OEM-ABI- oder Boot-Green-Pass beweisen zu koennen. Der Generator liefert Kandidaten-CRCs, echte MATCH-/MISMATCH-/ABSENT-Zahlen getrennt nach Kohorte, Vergleich mit dem erfolgreich gebauten R61, und die neun priorisierten historischen RMNET-/IPA-Blockersymbole. **Es wird kein neuer Kernel gebaut**, nur nachweisbares vorhandenes ABI-Wissen weiterverwendet.
