import importlib.util
import hashlib
from pathlib import Path
import os
import tempfile
import unittest
import zipfile
import sys
ROOT=Path(__file__).resolve().parents[1]

def module(name,file):
 spec=importlib.util.spec_from_file_location(name,ROOT/'tools'/file)
 obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj)
 return obj
source=module('r56_source','r56_source_gate.py')
services=module('r56_services','r56_services_avd.py')
R13=Path(os.environ.get('R56_TEST_R13','/mnt/data/files/VEUX_R13_CASS_MAIN.zip'))
R41=Path(os.environ.get('R56_TEST_R41','/mnt/data/files/VEUX_R41_NOMOUNT_SOURCE_MAIN.zip'))
R54=ROOT/'references/VEUX_R54_CASS_SOURCE_MAIN.zip'
R55=ROOT/'references/VEUX_R55_AVD_QUELLSTUFE_NOFLASH.zip'
WF=Path(os.environ.get('R56_TEST_R13_YAML','/mnt/data/files/VEUX_R13_CASS_BUILD.yml'))
FIXTURE='''#include <linux/errno.h>
#include "audit.h"

/* Old policy */
void security_compute_av_user(struct selinux_state *state,
                              u32 ssid, u32 tsid, u16 tclass,
                              struct av_decision *avd)
{
    struct context *scontext = NULL, *tcontext = NULL;
    read_lock(&state->ss->policy_rwlock);
    context_struct_compute_av(policydb, scontext, tcontext, tclass, avd,
                              NULL);
    /* irrelevant path */
\tcontext_struct_compute_av(policydb, scontext, tcontext, tclass, avd,
\t\t\t\t  NULL);
 out:
    read_unlock(&state->ss->policy_rwlock);
}

/* Next function */
'''.encode()

class StaticTests(unittest.TestCase):
 def test_01_known_archives(self):
  r=source.audit(R13,R41,R54,R55,WF)
  self.assertEqual(r['verified_zip_members'],{'R13':319,'R41':327,'R54':25,'R55':16})
  self.assertFalse(r['flash_allowed'])
 def test_02_invalid_r13_rejected(self):
  with self.assertRaises(source.Rejected):source.verify_zip(R13,'0'*64)
 def test_03_invalid_r41_rejected(self):
  with self.assertRaises(source.Rejected):source.verify_zip(R41,'0'*64)
 def test_04_new_compilation_not_inferred(self):
  self.assertFalse(source.audit(R13,R41,R54,R55,WF)['new_updated_kernel_built'])
 def test_05_old_r13_workflow_unchanged(self):
  self.assertEqual(source.blob(WF.read_bytes()),source.PINS['R13_BUILD_YAML_GIT_BLOB'])
 def test_06_tampered_yaml_refused(self):
  with tempfile.TemporaryDirectory() as d:
   f=Path(d)/'old.yml';f.write_bytes(WF.read_bytes()+b'#evil\n')
   with self.assertRaises(source.Rejected):source.audit(R13,R41,R54,R55,f)
 def test_07_no_fake_boot_pass(self):
  with tempfile.TemporaryDirectory() as d:
   r=source.audit_new_build(Path(d))
   self.assertEqual(r['status'],'NO_NEW_KERNEL_BUILD_RECEIPT')
   self.assertFalse(r['flash_allowed'])
 def test_08_no_fake_image_from_old(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d); (p/'Image').write_bytes(b'old');
   r=source.audit_new_build(p)
   self.assertEqual(r['status'],'NO_NEW_KERNEL_BUILD_RECEIPT')
 def test_09_false_gates_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'R56_NEW_BUILD_PROOF.json').write_text('{"gates":{}}')
   r=source.audit_new_build(p)
   self.assertEqual(r['status'],'NEW_CANDIDATE_BUILD_NOT_COMPLETE')
   self.assertFalse(r['flash_allowed'])
 def test_10_bundled_manifest_attested(self):
  with zipfile.ZipFile(R54) as z:self.assertIn('MANIFEST_SHA256.json',z.namelist())
 def test_11_missing_original_rejected(self):
  with self.assertRaises(source.Rejected):source.audit(Path('/nope'),R41,R54,R55,WF)
 def test_12_archive_bomb_paths_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'bad.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('../evil','hi')
   with self.assertRaises(source.Rejected):source.verify_zip(p,source.file_sha(p))
 def test_13_symlink_archive_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'r13.zip';p.symlink_to(R13)
   with self.assertRaises(source.Rejected):source.verify_zip(p,source.PINS['R13'])
 def test_14_services_patch_fixture(self):
  b,report=services.create(FIXTURE,require_xiaomi_blob=False)
  self.assertIn(b'susfs_spoof_avd_allowed_rcu(scontext->type',b)
  self.assertFalse(report['flash_allowed'])
 def test_15_services_reapply_rejected(self):
  b,_=services.create(FIXTURE,require_xiaomi_blob=False)
  with self.assertRaises(services.Blocked):services.create(b,require_xiaomi_blob=False)
 def test_16_services_bad_stock_hash(self):
  with self.assertRaises(services.Blocked):services.create(FIXTURE)
 def test_17_services_modification_outside_anchor(self):
  t=FIXTURE.replace(b' out:\n',b' out_A:\n')
  with self.assertRaises(services.Blocked):services.create(t,require_xiaomi_blob=False)
 def test_18_missing_lock_rejected(self):
  t=FIXTURE.replace(b'read_lock(&state->ss->policy_rwlock);',b'no_lock()')
  with self.assertRaises(services.Blocked):services.create(t,require_xiaomi_blob=False)
 def test_19_services_scope_only(self):
  before=FIXTURE.decode();after,_=services.create(FIXTURE,require_xiaomi_blob=False)
  self.assertIn('/* Next function */',after.decode())
  self.assertEqual(before.count('read_unlock(&state->ss->policy_rwlock);'),after.decode().count('read_unlock(&state->ss->policy_rwlock);'))
 def test_20_no_success_in_reports(self):
  row=source.audit(R13,R41,R54,R55,WF)
  self.assertEqual(row['oem_vendor_abi'],'BLOCKED')
  self.assertFalse(row['ak3_new_build_checked'])
if __name__=='__main__':unittest.main()
