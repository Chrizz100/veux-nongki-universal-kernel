"""Authenticate the M50 source and extract the matching Xiaomi reference image."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, write, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m50.zip') as archive:
    require(sha(work/'m50.zip')=='bef0f66afd021749eceeca6262eecff61d08d2b8c956346fe25541d7e064bc2c', 'M50 artifact digest')
    manifest=json.loads(archive.read('M50_KERNEL.json'))
    require(manifest['embedded_config']['image_sha256']==BASE_IMAGE,'M50 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M50 config identity')
    archive.extract('M50-kernel-source.tar.gz',work)
tar=work/'M50-kernel-source.tar.gz'
require(sha(tar)=='b090b43bc8b207ba0f5cb4d19c5bd4ed1df106bda9f149f84bff7c1da0a766c1','M50 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'bootinfo.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-e','BOOT_INFO'],check=True)
