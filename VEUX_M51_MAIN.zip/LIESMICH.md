# VEUX M51 · Kernelreparatur des Bootgrunds

Dieses Paket setzt unmittelbar auf den archivierten M50-R2-Quellstand aus Lauf 44994593500 auf. Es stellt die Xiaomi-Schnittstellen /sys/bootinfo/powerup_reason und /sys/bootinfo/powerup_reason_details wieder her. Das Stock-Image enthält die Device-Tree-Eigenschaft pureason, die Namen der PMIC-Abfragen und die dazugehörigen Ausgabetexte. Der M50-Kernel enthält diese Merkmale noch nicht.

## Upload und Start

1. VEUX_M51_MAIN.zip in das Hauptverzeichnis von Chrizz100/veux-nongki-universal-kernel hochladen.
2. VEUX_M51_BOOTINFO_NOFLASH.yml unter .github/workflows/ ablegen. Beide Dateien im selben Branch speichern.
3. In GitHub Actions „VEUX M51 – Bootgrund und PMIC, QGKI 5.4.274“ auf diesem Branch manuell starten.

## Herkunft und Umfang

- Hardware und ROM sind veux und V816.0.12.0.TKCMIXM. Die Zielkennung lautet 5.4.274-qgki-g82179e362f33.
- Die Umsetzung verwendet die Schnittstellen aus MiCodes öffentlichem veux-r-oss-Stand 61397e524093d1ccb94769b5460825e2eaf8871e (5.4.134), abgeglichen mit Xiaomis 5.4.274-Boot-Image. Der Bootloader liefert den Wert im frühen flachen Device Tree unter /chosen oder /chosen@0. Die Abfrage der PMIC-Bits für PS_HOLD und langen Tastendruck verwendet den vorhandenen Registerzugriff des PON-Treibers. Der Gerätebaum und der Code für Reset-Aktionen bleiben vom Patch unberührt.
- Der Port prüft die Länge der Big-Endian-Daten und akzeptiert 32 Bit sowie ein auf 64 Bit mit Nullen erweitertes Wort. Der Index für den ersten Reset-Grund wird innerhalb des 32-Bit-Werts bestimmt. Die PMIC-Abfrage berücksichtigt fehlende Geräte, fehlende Gen3-Grundregister, Lesefehler und das Entfernen eines Geräts. Die Detailausgabe umfasst auch bei acht Hexziffern den Zeilenumbruch. Eine Wiederherstellung des Geräts wurde damit nicht praktisch erprobt.
- Bei den 3.148 geprüften Importen stammen zwei Bluetooth-Symbole aus dem Modul btpower. Die Prüfung vergleicht CRC und Anbieter für jede Modul-Symbol-Kombination.
- Der Workflow prüft die zugrunde liegenden Quellen und den Hash der Xiaomi-Referenz vor dem Vollbau. Er übernimmt dazu die GitHub-Artefakte 14744629733 und 14706022228. GitHub muss diese Ausgangsartefakte beim Start noch bereitstellen.
- Die lokal ausgeführten Tests stehen in M51_LOKAL.json. Der Vollbau in GitHub prüft den tatsächlichen Link, Image, vmlinux, .config, Kernelkennung, Vendor-ABI, Module, DTB und Stock-Bootlayout. Seine Ergebnisse stehen im Artefakt KERNEL-NACHWEISE, die vollständigen erfolgreichen Quellen im Artefakt QUELLSTAND.

## Offene Reparaturgruppen

Das M50-Ergebnis enthält 54 Konfigurationsunterschiede zu Xiaomi 5.4.274. Das lokal erzeugte M51-olddefconfig enthält 53. Die Datei Restkonfiguration.csv listet die einzelnen Unterschiede. Dazu gehören Funktionspfade für Dateisysteme, Speicher, thermische CPU-Isolierung, Millet und UFS-Firmware sowie getrennt zu bewertende Compilermerkmale und deaktivierte Optionen. Das M51-Ergebnis am Gerät und ein praktischer Rückweg aus Fastboot stehen weiterhin aus.
