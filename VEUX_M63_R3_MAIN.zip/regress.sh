#!/usr/bin/env bash
# Compare previously repaired behaviour in the two linked ARM64 images.
set -euo pipefail
tools=$(realpath "$1")
stock=$(realpath "$2")
out=$(realpath "$3")
tc=$(realpath "$4")
results=$(realpath -m "$5")
mkdir -p "$results"
image="$out/arch/arm64/boot/Image"
for item in memory_image reaper_image thermal_image; do
    python3 -B "$tools/$item.py" stock "$tc" "$stock" "$results/stock-$item.json"
    python3 -B "$tools/$item.py" candidate "$tc" "$image" "$results/M63-R3-$item.json" --map "$out/System.map"
    cmp "$results/stock-$item.json" "$results/M63-R3-$item.json"
done
python3 -B "$tools/atomics.py" stock "$tc" "$stock" "$results/stock-atomics.json"
python3 -B "$tools/atomics.py" image "$tc" "$image" "$results/M63-R3-atomics.json" --system-map "$out/System.map"
cmp "$results/stock-atomics.json" "$results/M63-R3-atomics.json"
for mode in stock candidate; do
    if [[ $mode == stock ]]; then target=$stock; args=(); else target=$image; args=(--map "$out/System.map"); fi
    python3 -B "$tools/zram_image.py" "$mode" "$target" "$results/$mode-zram.json" "${args[@]}" --full --inventory "$results/$mode-zram.txt"
    python3 -B "$tools/zram_paths.py" "$mode" "$tc" "$target" "$results/$mode-zram-paths.json" "${args[@]}"
    python3 -B "$tools/ratio_contract.py" "$mode" "$tc" "$target" "$results/$mode-pages.json" "${args[@]}"
done
for item in zram.json zram.txt zram-paths.json pages.json; do cmp "$results/stock-$item" "$results/candidate-$item"; done
python3 -B "$tools/pmic_image.py" "$stock" "$image" "$out/System.map" "$out/Module.symvers" "$tc" "$results/PMIC.json"
python3 -B "$tools/mi_memory_image.py" "$stock" "$image" "$out/System.map" "$tc" "$results/UFS-Image.json"
python3 -B "$(dirname "$0")/check_events.py" "$tools" "$stock" "$out" "$tc" "$results/UFS-events.json"

python3 -B "$(dirname "$0")/features.py" "$tools" "$stock" "$image" "$out/System.map" "$tc" "$results/Millet-und-hr.json"
