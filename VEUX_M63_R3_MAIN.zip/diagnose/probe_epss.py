"""Measure Qualcomm EPSS policy creation and WALT core_ctl on a two-domain ARM64 fixture."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import zipfile

MACHINE = "virt-8.2,gic-version=3,virtualization=on"
BASE = 0x7c000000
INIT = r"""#!/bin/busybox sh
/bin/busybox mount -t sysfs sysfs /sys || exit 1
/bin/busybox mount -t proc proc /proc || exit 1
for dir in /sys/devices/system/cpu/cpufreq/policy*; do
  [ -f "$dir/related_cpus" ] || continue
  echo "VEUX_POLICY ${dir##*/} $(/bin/busybox cat "$dir/related_cpus")"
done
for i in 0 6; do
  p="/sys/devices/system/cpu/cpu$i/core_ctl"
  for attempt in 1 2 3; do
    [ -r "$p/max_cpus" ] && break
    /bin/busybox sleep 1
  done
  [ -r "$p/max_cpus" ] && echo "VEUX_CORE_CTL $i $(/bin/busybox cat "$p/max_cpus")"
done
echo VEUX_EPSS_FINISHED
echo b > /proc/sysrq-trigger
exec /bin/busybox sleep 120
"""

def model_tree(base, dtc, root, cpus):
    subprocess.run(base + ['-machine', f'{MACHINE},dumpdtb={root}/virt.dtb'], check=True, capture_output=True)
    dts = subprocess.check_output([dtc, '-qqq', '-I', 'dtb', '-O', 'dts', root/'virt.dtb'], text=True)
    fragments = ['&{/cpus} { /delete-node/ cpu-map; cpu-map {']
    for group in sorted(set(domain for domain, _ in cpus)):
        members = [i for i, (d, _) in enumerate(cpus) if d == group]
        fragments.append(f'cluster{group} {{')
        for core, cpu in enumerate(members):
            fragments.append(f'core{core} {{ cpu = <&{{/cpus/cpu@{cpu:x}}}>; }};')
        fragments.append('};')
    fragments.append('}; };')
    for i, (domain, capacity) in enumerate(cpus):
        size = sum(d == domain for d, _ in cpus)
        fragments.append(f'&{{/cpus/cpu@{i:x}}} {{ capacity-dmips-mhz = <{capacity}>; qcom,freq-domain = <&epss {domain} {size}>; }};')
    fragments.append(f"""/ {{
      xo: xo-clock {{ compatible = "fixed-clock"; #clock-cells = <0>; clock-frequency = <19200000>; }};
      alt: alternate-clock {{ compatible = "fixed-clock"; #clock-cells = <0>; clock-frequency = <600000000>; }};
      epss: cpufreq@{BASE:x} {{ compatible = "qcom,cpufreq-hw-epss";
        reg = <0 {BASE} 0 4096>, <0 {BASE+4096} 0 4096>;
        reg-names = "freq-domain0", "freq-domain1"; clocks = <&xo>, <&alt>;
        clock-names = "xo", "alternate"; #freq-domain-cells = <2>;
        qcom,lut-row-size = <4>; qcom,skip-enable-check;
      }};
    }};""")
    output = root/'epss.dtb'
    subprocess.run([dtc,'-qqq','-I','dts','-O','dtb','-o',output],
                   input=dts+'\n'+'\n'.join(fragments), text=True, check=True)
    return output

def registers(cpus):
    data = bytearray(8192)
    for domain in (0, 1):
        size = sum(d == domain for d, _ in cpus)
        for row, mul in enumerate((20, 40, 60, 60)):
            struct.pack_into('<I', data, 4096*domain + 0x100 + 4*row, (1<<30) | (size<<16) | mul)
            struct.pack_into('<I', data, 4096*domain + 0x200 + 4*row, 850)
    return data

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('image','out','kit','stock_dtb','dest'): p.add_argument(name, type=Path)
    a=p.parse_args()
    import sys
    sys.path.insert(0, str((a.kit/'tools').resolve()))
    from thermal_dtb import nodes, enabled
    dt=nodes(a.stock_dtb.read_bytes())
    def cells(v): return struct.unpack('>'+'I'*(len(v)//4),v)
    controller,=[(name,n) for name,n in dt.items() if enabled(dt,name) and b'qcom,cpufreq-hw-epss' in n.get('compatible',b'').split(b'\0')]
    phandle,=cells(controller[1]['phandle'])
    cpus=[]
    for i in range(8):
        path=f'/cpus/cpu@{i*256:x}'
        handle,domain,size=cells(dt[path]['qcom,freq-domain'])
        assert handle==phandle and enabled(dt,path) and size==(6 if i<6 else 2)
        cpus.append((domain,cells(dt[path]['capacity-dmips-mhz'])[0]))
    if [d for d,_ in cpus] != [0]*6+[1]*2: raise ValueError('Unexpected Xiaomi CPU grouping')
    base=[shutil.which('qemu-system-aarch64') or 'qemu-system-aarch64','-no-user-config','-nodefaults','-cpu','cortex-a76',
          '-smp','8','-m','1024M','-accel','tcg','-display','none','-monitor','none','-nic','none']
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        dtb=model_tree(base,a.out/'scripts/dtc/dtc',root,cpus)
        with zipfile.ZipFile(a.kit/'ak3-tools.zip') as z:
            (root/'busybox').write_bytes(z.read('tools/busybox'))
        (root/'init').write_text(INIT)
        (root/'cpio.list').write_text('dir /bin 0755 0 0\ndir /dev 0755 0 0\ndir /sys 0755 0 0\ndir /proc 0755 0 0\nnod /dev/console 0600 0 0 c 5 1\n'
                                     +f'file /bin/busybox {root}/busybox 0755 0 0\nfile /init {root}/init 0755 0 0\n')
        with (root/'initrd').open('wb') as f:
            subprocess.run([a.out/'usr/gen_init_cpio',root/'cpio.list'],stdout=f,check=True)
        bank=root/'epss.bin'; bank.write_bytes(registers(cpus))
        cmd=base+['-machine',MACHINE,'-serial','stdio','-no-reboot','-kernel',str(a.image),'-initrd',str(root/'initrd'),
                  '-dtb',str(dtb),'-device',f'loader,file={bank},addr={BASE:#x},force-raw=on',
                  '-append','console=ttyAMA0 earlycon=pl011,0x09000000 loglevel=7 mem=896M rdinit=/init panic=-1']
        try: result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
        except subprocess.TimeoutExpired as e:
            a.dest.with_suffix('.log').write_bytes(e.stdout or b'');raise
        data=result.stdout
    a.dest.with_suffix('.log').write_bytes(data)
    if (result.returncode != 0 or b'VEUX_EPSS_FINISHED' not in data or b'Kernel panic - not syncing' in data
            or not re.search(rb'(?i)sysrq:\s*Resetting',data)):
        raise RuntimeError('ARM64 test did not finish: '+str(a.dest.with_suffix('.log')))
    policies=re.findall(rb'(?m)^VEUX_POLICY policy(\d+) ([0-9 ]+)\r?$',data)
    groups=re.findall(rb'(?m)^VEUX_CORE_CTL (\d+) (\d+)\r?$',data)
    if policies!=[(b'0',b'0 1 2 3 4 5'),(b'6',b'6 7')]:raise ValueError('EPSS policies did not match: '+repr(policies))
    report={'image_sha256':hashlib.sha256(a.image.read_bytes()).hexdigest(),'policies':{k.decode():v.decode() for k,v in policies},
            'core_ctl_max_cpus':{k.decode():int(v) for k,v in groups},'model':'virt-8.2, eight ARM64 vCPUs, static EPSS lookup registers, two frequency domains'}
    a.dest.write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report))

if __name__=='__main__': main()
