"""Boot the candidate and factory kernels with the two original Xiaomi ramdisks."""
import concurrent.futures
import json
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

from fruehstart import MACHINE, STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot
from pstore_stock import HERE, signed_regions
from layout.boot import align

RAMDISK = '0bf746965aeade57d8c5c543a489f1c76f3ce8f9d4d1490da0d2a73374615abc'
EXPECTED = {'metadata', 'super', 'vbmeta_a', 'vbmeta_system_a'}


def main(work, dest):
    dest.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as directory:
        temp = Path(directory)
        vendor = signed_regions(temp)['vendor_boot']
        stock = (work / 'boot.img').read_bytes()
        kernel_size, ramdisk_size = struct.unpack_from('<2I', stock, 8)
        offset = 4096 + align(kernel_size)
        size, = struct.unpack_from('<I', vendor, 24)
        parts = [vendor[4096:4096 + size], stock[offset:offset + ramdisk_size]]
        with zipfile.ZipFile(HERE.parent / 'ak3-tools.zip') as archive:
            unpack = temp / 'magiskboot'
            unpack.write_bytes(archive.read('tools/magiskboot'))
            unpack.chmod(0o700)
        initrd = temp / 'initramfs.cpio'
        with initrd.open('wb') as output:
            for i, part in enumerate(parts):
                raw, cpio = temp / f'{i}.lz4', temp / f'{i}.cpio'
                raw.write_bytes(part)
                subprocess.run(['qemu-arm', unpack, 'decompress', raw, cpio], check=True)
                with cpio.open('rb') as stream:
                    shutil.copyfileobj(stream, output)
        require(digest(initrd.read_bytes()) == RAMDISK, 'Original vendor + boot ramdisk contents')
        flags = [s for s in vendor[28:2076].split(b'\0')[0].decode().split()
                 if not s.startswith(('console=', 'earlycon=', 'androidboot.console='))]
        flags.extend(['console=ttyAMA0', 'earlycon=pl011,0x09000000', 'androidboot.console=ttyAMA0',
                      'rdinit=/init', 'androidboot.force_normal_boot=1', 'androidboot.slot_suffix=_a',
                      'loglevel=7', 'ignore_loglevel', 'panic=-1', 'androidboot.fstab_suffix=default'])
        kernels = {'Xiaomi': unpack_boot(work / 'boot.img', STOCK_BOOT, STOCK_IMAGE),
                   'M63-R3': unpack_boot(work / 'pair/VEUX_M63-R3_boot_NOFLASH.img')}
        require(kernels['M63-R3'] == (work / 'out/arch/arm64/boot/Image').read_bytes(), 'Candidate identity')

        def boot(label):
            image = temp / (label + '.Image')
            image.write_bytes(kernels[label])
            log = dest / (label + '.log')
            with log.open('wb') as serial:
                subprocess.run(['qemu-system-aarch64', '-no-user-config', '-nodefaults', '-machine', MACHINE,
                                '-cpu', 'cortex-a76', '-accel', 'tcg', '-smp', '2', '-m', '1024M',
                                '-serial', 'stdio', '-display', 'none', '-monitor', 'none', '-nic', 'none',
                                '-no-reboot', '-seed', '1', '-kernel', image, '-initrd', initrd,
                                '-append', ' '.join(flags)], stdout=serial, stderr=subprocess.STDOUT,
                               timeout=65, check=True)
            raw = log.read_bytes()
            missing = re.findall(rb'partition\(s\) not found after polling timeout: ([^\r\n]+)', raw)
            require(b'init first stage started!' in raw and b'Failed to mount required partitions early' in raw
                    and len(missing) == 1 and set(missing[0].decode().split(', ')) == EXPECTED
                    and b'Kernel panic - not syncing' not in raw, 'Unexpected Android first-stage outcome for ' + label)
            return label, dict(kernel_sha256=digest(kernels[label]), serial_sha256=digest(raw),
                               first_stage_init=True, missing_partitions=sorted(EXPECTED))

        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            results = dict(pool.map(boot, kernels))
    report = dict(images=results, platform=MACHINE, ramdisk_sha256=RAMDISK, command_line=flags,
                  full_android_boot=False, device_pass=False, flash_allowed=False)
    (dest / 'Android-init.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS stock and candidate reach Android first-stage init and the same missing-partition boundary')


if __name__ == '__main__':
    main(*(Path(arg).resolve() for arg in sys.argv[1:]))
