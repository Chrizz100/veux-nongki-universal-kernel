# VEUX M63-R3 für HyperOS OS1.0.12.0.TKCMIXM

M63-R3 stellt zwei Verbindungen zwischen dem Qualcomm-Frequenztreiber und dem WALT-Scheduler wieder her. Der erste Aufruf initialisiert die CPU-Cluster nach der Einrichtung beider Frequenzdomänen. Der zweite registriert den Hardware-Taktzähler. Die Referenz bilden Xiaomis ausgeliefertes Kernel-Image und die beiden passenden Quellstellen in MiCodes veux-r-oss. Der Patch betrifft zwei C-Dateien.

Der Workflow liest das vorhandene VEUX_M63_R2_MAIN.zip und die neue Datei VEUX_M63_R3_MAIN.zip aus dem Hauptverzeichnis des Projekts. Die zugehörige YAML liegt unter .github/workflows/. Der Workflow prüft die SHA-256 beider Archive vor dem Entpacken und baut den Kandidaten einmal. Zur Kontrolle entnimmt er dem festgelegten früheren GitHub-Artefakt das unveränderte M63-R2-Image.

Die Vergleichsprobe startet Xiaomis Original, M63-R2 aus GitHub und M63-R3 mit acht emulierten ARM64-Kernen. Die CPU-Zuordnung und Kapazitäten stammen aus Xiaomis signierten Firmwarebereichen. Die EPSS-Register und Frequenzstufen sind modelliert. Die Messung erfasst die Frequenzrichtlinien sowie die von WALT angelegten core_ctl-Gruppen. Die Prüfung am Maschinencode vergleicht zusätzlich die Zielroutine und ihre Registrierung. Die Tests des Vorgängers für Hersteller-Module, Speicheranzeigen, pstore, Bootcontainer und Android-init laufen weiterhin.

Der Hardwarestart des Kandidaten ist offen. Das erzeugte Paar ist mit NOFLASH gekennzeichnet.

https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/61397e524093d1ccb94769b5460825e2eaf8871e
