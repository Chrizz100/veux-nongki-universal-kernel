"""Prepare the pinned M62 source, the factory boot and the WALT and pstore repairs."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = 'dd3a30ec719cf324a23298e5fb56a58d0c621fe5469a74130ab08e0ab64dbdd1'
TAR = '557dd8300935476e7e4ea87b10a9b7e343c67b397e30fa7ac16233121fbec33b'
CONFIG = 'c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54'
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
IMAGE = '39b3d5668e8c3117a6c5b8fcbb5e6f1c3b5e3de4890072b40f422a9fa4d040d0'
PATCH = 'ce35ad3f7fe1bf473d589ca9bbff64cbc8e159e2c941789a32c9faa2a6c44467'
FILES = {
    'fs/pstore/platform.c': ('87fa9e7a6656dd73b7fbcc3afd6084bc223970bc9aaf24871694858b85e97ec2',
        '8c40da064c28f656406d21797b513eda0edf6c5b2ff3addc73a0032bac2e1c31'),
    'fs/pstore/ram.c': ('fcd6b778ec4300c30e637f756533e9dfe0c9ecb337d74c2f6edc6ed8215126d9',
        '6cc13782098f106453fa0fb0ea25538ab033301736e18f49fa6820f68c9b7af7'),
    'arch/arm64/boot/dts/vendor/xiaomi/veux.dts': ('344b587e6c8b7522ef6527c8d404fd035cfe73698b7a807adfc86b08fbc7264e',
        '2f708e2cceec5ab245559f363ec5d1d021b1af7ce4139051dc7a370dd8549ae7'),
    'kernel/fork.c': ('fc38c78d743e9fce6f4739c72d6fc9e643a16760195db2384028d8101fa0a90e',
        '1071dcb777fb8b747933dda50aa260128e52ea5862dc8548029bae125025e188'),
    'kernel/sysctl.c': ('e36243c8cbb7c3e2f7c91744ae658faf6c3ca2cd1d857e9f5f119ee69790981e',
        '08f2a0990f30a9d241be25df61646dcc52a375fd323b0be43128dcf9ec30076d'),
    'kernel/sched/core.c': ('aae1031d3d3f0bb0362c3efc409e24e0cdb0ddc321d18aae0c040d8fdffde9da',
        'e86d9d1739f3d6b7877be46a731475c1f0e572d6a699b56994bab64523b0d8fb'),
    'kernel/sched/sched.h': ('acb46fea539892087c4198f49b0b4131490831d31ebc5b56a03f87c81ae4dd8e',
        'bc1ad442ec2058eb087e6c31a2bd633cffd9a514f1e04fc91f34f9380b558361'),
    'kernel/sched/fair.c': ('4441f87e67f0e6ea489a2a5206b8e27accb69469ff0abb9237e8a6a1cccdca6a',
        '5795101e846d2111e8aef1db99ec1152c221ea3de93cf28491291455378f8ce8'),
    'kernel/sched/rt.c': ('ef47ab4b693986fd8093612aed5aee209c1ff531e22e442e41915c5244507fc5',
        'ef8ea1d00178eac51a98ad13a0242d0565e165da5aa7a92acf1061e15f00693c'),
    'kernel/sched/deadline.c': ('bc8bafd5a45982af18073ae6b8a3dbd69fc2a524559949797de2b9a0361923ca',
        'a44753f80707664d35a48bbf869f32c19e1ac82b19363ddcabcf4b3c92e46a51'),
    'kernel/sched/stop_task.c': ('5791bf28f5c749ee2fd0e8d436c6dcfc34f53be203dcb9c969e6a57231503903',
        '7c4f21f2b3d436f2e8c31eede96e4a23f6362bceb8e8ba6b755be01ffecd9c79'),
}

def digest(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for block in iter(lambda:stream.read(1024*1024), b''):
            h.update(block)
        return h.hexdigest()

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def prepare(work, archive, stock):
    work.mkdir(parents=True, exist_ok=True)
    need(digest(archive)==SOURCE and digest(stock)==BOOT, 'Pinned M62 artifact and Xiaomi boot required')
    patch = ROOT/'veux-m63-r2-stock.patch'
    need(digest(patch)==PATCH, 'Kernel patch integrity')
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read('M62_KERNEL.json'))
        need(manifest['config_sha256']==CONFIG and manifest['image_sha256']==IMAGE, 'M62 manifest')
        config = z.read('kernel.config')
        need(hashlib.sha256(config).hexdigest()==CONFIG, 'M62 config')
        tar = Path(z.extract('M62-kernel-source.tar.gz',work))
    need(digest(tar)==TAR, 'Kernel source archive')
    src = work/'src'
    src.mkdir()
    subprocess.run(['tar','--no-same-owner','--no-same-permissions','-xzf',tar,'-C',src],check=True)
    need(all(digest(src/k)==v[0] for k,v in FILES.items()), 'Unmodified scheduler and pstore sources')
    subprocess.run(['git','apply','--check',patch],cwd=src,check=True)
    subprocess.run(['git','apply',patch],cwd=src,check=True)
    need(all(digest(src/k)==v[1] for k,v in FILES.items()), 'M63-R2 source result')

    bridge = ROOT/'veux-cpufreq-walt.patch'
    need(digest(bridge)=='e8b2b5ed5a0faeed7e53e187d8f6c705403056b9740b3348016d1318240ce69c', 'EPSS patch digest')
    bridge_files = {
        'drivers/base/arch_topology.c': ('3e09b20ee64f2ae301a9869f7b343d61b9d5b3ced74f8117d46e2af656d2bb2b', '9df1952f5b656d6052320b09b20e597a6384800bccf92876c7bb6eec99e89533'),
        'drivers/cpufreq/qcom-cpufreq-hw.c': ('bc7c7fe48cd848a23715a5a54d0b9ac751b2d693b0551afb2f8cbd532005c3d3', '0ba6ee537c58bd646b8b44f2ce34ed3e742e68c168a4dc414226930177030db0'),
    }
    need(all(digest(src/k)==v[0] for k,v in bridge_files.items()), 'Expected M63-R2 EPSS and topology sources')
    subprocess.run(['git','apply','--check',bridge],cwd=src,check=True)
    subprocess.run(['git','apply',bridge],cwd=src,check=True)
    need(all(digest(src/k)==v[1] for k,v in bridge_files.items()), 'M63-R3 EPSS and topology results')
    (work/'out').mkdir()
    (work/'out/.config').write_bytes(config)
    (work/'baseline.config').write_bytes(config)
    shutil.copyfile(stock,work/'boot.img')

if __name__=='__main__':
    prepare(*(Path(arg).resolve() for arg in sys.argv[1:]))
