#!/usr/bin/env python3
"""Fail-closed Linux 5.4 SELinux host wiring on a *separate* R58 candidate.

This is not a flashability statement. Only the in-memory / temp build source is
modified; R13 and the GitHub source checkout are protected by R58's checks.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

BASE = {
    'security/selinux/hooks.c': 'c30bdee06d992110fedb6a61f1c78e9d180a60af',
    'security/selinux/avc.c': 'f770ade87d83134e7174998dbdc36887127543eb',
    'security/selinux/selinuxfs.c': 'b5e8f527442a58ebc2dddd4bf39983556baaa062',
}

# Authenticated from R13 40921711051 and independently repeated by R60-R7.
# These are the *actual compiled-source* preimages, not pristine dereference23
# Git objects. The historical BASE map above is retained for provenance only.
R13_HOST_SHA256 = {
    'security/selinux/hooks.c': '57a84c1b0f41d108e9557314c0039e5bfd6fc4b15aa60532711d32e551cc2992',
    'security/selinux/avc.c': '785f2de8539906bad413e4f15e34f59c36873ec09d6bd4ececb66e8721a304e9',
    'security/selinux/selinuxfs.c': '16533ae84611ddc908759231a06ac09722cbeda3cba7ebc361baa1ee462729a1',
}
R13_INVENTORY_SHA256 = '009b910acfcc273377691c71a92c37ba795f7847d42b88379ba1b91cbc627867'
R13_HOST_PROVENANCE = Path(__file__).resolve().parents[1]/'refs/R13_HOST_PREIMAGE_PROVENANCE.json'

class GateError(RuntimeError): pass

def require(ok, message):
    if not ok: raise GateError(message)

def replace_one(text, a, b, name):
    require(text.count(a)==1, f'{name}:EXPECTED_EXACT_ANCHOR_ONE_FOUND_{text.count(a)}')
    return text.replace(a,b,1)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def gitblob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def port_hooks(text):
    require('ksu_selinux_hide_running' not in text,'HOOKS_ALREADY_MANUAL_OR_CHANGED')
    # This symbol also intentionally enables BakaSU's native SUSFS manual-hook
    # compatibility mode (tools/susfs_compat.mk). Without a functional handler,
    # BakaSU would stop installing its own LSM handler: do not split this patch.
    a='struct selinux_state selinux_state;\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       'extern bool ksu_selinux_hide_running;\n'
       'extern int my_setprocattr(const char *name, void *value, size_t size);\n'
       '#endif\n')
    text=replace_one(text,a,b,'HOOKS_DECL')
    anchor='\tLSM_HOOK_INIT(setprocattr, selinux_setprocattr),'
    text=replace_one(text,anchor,(
        '#ifdef CONFIG_KSU_SUSFS\n'
        '\tLSM_HOOK_INIT(setprocattr, r59_selinux_setprocattr),\n'
        '#else\n'+anchor+'\n'
        '#endif'), 'HOOKS_LSM')
    a='static int selinux_ismaclabel(const char *name)\n'
    wrapper=(
        '#ifdef CONFIG_KSU_SUSFS\n'
        '/* 5.4 policy/LSM ABI: BakaSU retains its native permission checks. */\n'
        'static int r59_selinux_setprocattr(const char *name, void *value, size_t size)\n'
        '{\n'
        '\tif (current_uid().val >= 10000 &&\n'
        '\t    READ_ONCE(ksu_selinux_hide_running) && !strcmp(name, "current"))\n'
        '\t\treturn my_setprocattr(name, value, size);\n'
        '\treturn selinux_setprocattr(name, value, size);\n'
        '}\n'
        '#endif\n\n')
    text=replace_one(text,a,wrapper+a,'HOOKS_WRAPPER')
    require(text.count('r59_selinux_setprocattr')==2,'HOOKS_WRAPPER_REFERENCE_COUNT')
    return text

def port_avc(text):
    require('r59_avc_context' not in text,'AVC_ALREADY_PORTED')
    a='#include "avc_ss.h"\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/jump_label.h>\n'
       'extern u32 susfs_ksu_sid, susfs_priv_app_sid;\n'
       'extern struct static_key_false susfs_is_avc_log_spoofing_enabled;\n'
       '#endif\n')
    text=replace_one(text,a,b,'AVC_INCLUDE')
    a=('\trc = security_sid_to_context(sad->state, sad->tsid, &scontext,\n'
       '\t\t\t\t     &scontext_len);\n'
       '\tif (rc)\n'
       '\t\taudit_log_format(ab, " tsid=%d", sad->tsid);\n'
       '\telse {\n'
       '\t\taudit_log_format(ab, " tcontext=%s", scontext);\n'
       '\t\tkfree(scontext);\n'
       '\t}\n')
    b=('\trc = security_sid_to_context(sad->state, sad->tsid, &scontext,\n'
       '\t\t\t\t     &scontext_len);\n'
       '#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Audit-only presentation; never alter the real access decision. */\n'
       '\tif (static_branch_unlikely(&susfs_is_avc_log_spoofing_enabled) &&\n'
       '\t    susfs_ksu_sid && susfs_priv_app_sid &&\n'
       '\t    sad->tsid == susfs_ksu_sid) {\n'
       '\t\tif (rc)\n'
       '\t\t\taudit_log_format(ab, " tsid=%u", susfs_priv_app_sid);\n'
       '\t\telse {\n'
       '\t\t\taudit_log_format(ab, " tcontext=%s",\n'
       '\t\t\t\t         "u:r:priv_app:s0:c512,c768");\n'
       '\t\t\tkfree(scontext);\n'
       '\t\t}\n'
       '\t} else\n'
       '#endif\n'
       '\tif (rc)\n'
       '\t\taudit_log_format(ab, " tsid=%d", sad->tsid);\n'
       '\telse {\n'
       '\t\taudit_log_format(ab, " tcontext=%s", scontext);\n'
       '\t\tkfree(scontext);\n'
       '\t}\n')
    text=replace_one(text,a,b,'AVC_AUDIT')
    require(text.count('susfs_is_avc_log_spoofing_enabled')==2,'AVC_FLAG_NOT_WIRED')
    return text

def port_selinuxfs(text):
    require('ksu_selinux_hide_running' not in text,'SELINUXFS_ALREADY_PORTED')
    a='#include "objsec.h"\n'
    b=(a+'#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/cred.h>\n'
       'extern struct page *fake_status;\n'
       'extern bool ksu_selinux_hide_running;\n'
       '#endif\n')
    text=replace_one(text,a,b,'SELINUXFS_HEADERS')
    a=('\tstruct page    *status = selinux_kernel_status_page(fsi->state);\n\n'
       '\tif (!status)\n')
    b=('\tstruct page    *status = selinux_kernel_status_page(fsi->state);\n\n'
       '#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* BakaSU manual-hook mode: serve its allocated fake page only to apps. */\n'
       '\tif (current_uid().val >= 10000 &&\n'
       '\t    READ_ONCE(ksu_selinux_hide_running) && READ_ONCE(fake_status)) {\n'
       '\t\tfilp->private_data = READ_ONCE(fake_status);\n'
       '\t\treturn 0;\n'
       '\t}\n'
       '#endif\n'
       '\tif (!status)\n')
    text=replace_one(text,a,b,'SELINUXFS_PAGE')
    return text

def scope_services(text):
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/rcupdate.h>\n'
       'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '#include <linux/rcupdate.h>\n'
       '#include <linux/cred.h>\n'
       'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
       'extern bool ksu_selinux_hide_running;\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_DECL')
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Exact native-5.4 type check, without replacing the policy parser. */\n'
       '\trcu_read_lock();\n'
       '\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
       '\t\trcu_read_unlock();\n'
       '\t\tgoto out;\n'
       '\t}\n'
       '\trcu_read_unlock();\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Restrict only app-facing SELinux-hide requests, not the global parser. */\n'
       '\tif (current_uid().val >= 10000 && READ_ONCE(ksu_selinux_hide_running)) {\n'
       '\t\trcu_read_lock();\n'
       '\t\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
       '\t\t\trcu_read_unlock();\n'
       '\t\t\tgoto out;\n'
       '\t\t}\n'
       '\t\trcu_read_unlock();\n'
       '\t}\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_SCOPE')
    a=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Called only after the real policy has computed the AVD. */\n'
       '\trcu_read_lock();\n'
       '\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
       '\t\t\t\t   tclass, &avd->allowed);\n'
       '\trcu_read_unlock();\n'
       '#endif\n')
    b=('#ifdef CONFIG_KSU_SUSFS\n'
       '\t/* Preserve genuine policy decisions outside the app-hide path. */\n'
       '\tif (current_uid().val >= 10000 && READ_ONCE(ksu_selinux_hide_running)) {\n'
       '\t\trcu_read_lock();\n'
       '\t\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
       '\t\t\t\t\t   tclass, &avd->allowed);\n'
       '\t\trcu_read_unlock();\n'
       '\t}\n'
       '#endif\n')
    text=replace_one(text,a,b,'SERVICES_AVD_SCOPE')
    return text

def attest_r13_host_preimages(root, inventory_path, paths, expected=None):
    """Require real, pinned R13 source bytes and matching build inventory.

    Never accept arbitrary hashes or fall back to a pristine source. Runtime
    does not expose the `expected` test-fixture argument via CLI.
    """
    pins = R13_HOST_SHA256 if expected is None else expected
    inv_path=Path(inventory_path)
    require(inv_path.is_file() and not inv_path.is_symlink(), 'R13_HOST_INVENTORY_MISSING_OR_SYMLINK')
    inv_bytes=inv_path.read_bytes()
    if expected is None:
        require(sha256(inv_bytes)==R13_INVENTORY_SHA256,'R13_HOST_INVENTORY_SHA256_CHANGED')
        p=json.loads(R13_HOST_PROVENANCE.read_text())
        require(p['source_inventory_sha256']==R13_INVENTORY_SHA256 and
                p['files']==R13_HOST_SHA256 and p['flash_allowed'] is False,
                'R13_HOST_PROVENANCE_NOT_AUTHENTICATED')
    inv=json.loads(inv_bytes)
    for rel in paths:
        require(rel in pins and rel in inv,'R13_HOST_PIN_MISSING:'+rel)
        require(inv[rel]['type']=='file' and inv[rel]['sha256']==pins[rel],
                'R13_HOST_INVENTORY_FILE_CHANGED:'+rel)
        f=root/rel
        require(f.is_file() and not f.is_symlink(),'R13_HOST_SOURCE_MISSING_OR_SYMLINK:'+rel)
        got=sha256(f.read_bytes())
        require(got==pins[rel], f'R13_HOST_PREIMAGE_CHANGED:{rel}:actual_sha256={got}')
    return True

def preflight(kernel, report):
    """Read-only compatibility probe before the long baseline compile.

    This only proves patch anchors. Exact source hashes are verified again
    against the R13 inventory after the baseline source is constructed.
    """
    root=Path(kernel).resolve(strict=True)
    transforms={'security/selinux/hooks.c':port_hooks,
                'security/selinux/avc.c':port_avc,
                'security/selinux/selinuxfs.c':port_selinuxfs}
    rows={}
    for rel,fn in transforms.items():
        f=root/rel
        require(f.is_file() and not f.is_symlink(),'R13_HOST_PREFLIGHT_MISSING_OR_SYMLINK:'+rel)
        raw=f.read_bytes()
        amended=fn(raw.decode('utf-8'))  # in memory only; fail on non-unique anchors
        require(amended!=raw.decode('utf-8'),'R13_HOST_PREFLIGHT_EMPTY_PATCH:'+rel)
        rows[rel]={'input_sha256':sha256(raw),'new_tokens_present':True,
                   'input_version':'SOURCE_AUDIT_NOT_FINAL_R13_BUILD'}
    dest=Path(report)
    require(dest.parent.is_dir() and not dest.exists() and not dest.is_symlink(),
            'R13_HOST_PREFLIGHT_REPORT_PATH_UNSAFE')
    dest.write_text(json.dumps({'schema':'VEUX_R60_R8_HOST_ANCHOR_PREFLIGHT_V1',
                                'preflight_passed':True, 'kernel_compiled':False,
                                'flash_allowed':False,'files':rows},indent=2,sort_keys=True)+'\n')
    print('R60_R8_HOST_ANCHORS_PREFLIGHT=PASS; SOURCE_NOT_MUTATED; FLASH=NO')
    return rows

def install(kernel, report, inventory_path):
    root=Path(kernel).resolve(strict=True)
    orig={}
    edited={}
    transforms={
      'security/selinux/hooks.c':port_hooks,
      'security/selinux/avc.c':port_avc,
      'security/selinux/selinuxfs.c':port_selinuxfs,
      'security/selinux/ss/services.c':scope_services,
    }
    attest_r13_host_preimages(root, inventory_path, list(R13_HOST_SHA256))
    for rel,fn in transforms.items():
        path=root/rel
        require(path.is_file() and not path.is_symlink(),'SOURCE_MISSING_OR_SYMLINK:'+rel)
        raw=path.read_bytes()
        # Read-only R13 inventory and file bytes were already hash-verified.
        if rel in R13_HOST_SHA256:
            require(sha256(raw)==R13_HOST_SHA256[rel],'R13_HOST_PREIMAGE_DRIFT:'+rel)
        orig[rel]=sha256(raw)
        edited[rel]=fn(raw.decode('utf-8'))
        require(edited[rel]!=raw.decode('utf-8'),'EMPTY_HOST_PATCH:'+rel)
    compat=root/'KernelSU/kernel/tools/susfs_compat.mk'
    require(compat.is_file() and not compat.is_symlink(),'BAKASU_SUSFS_COMPAT_MISSING')
    compat_text=compat.read_text()
    require('ksu_selinux_hide_running' in compat_text and
            'KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE' in compat_text,
            'BAKASU_MANUAL_HOOK_SWITCH_NOT_PROVEN')
    baksu=root/'KernelSU/kernel/feature/selinux_hide.c'
    require(baksu.is_file() and '#define ksu_handle_selinux_setprocattr my_setprocattr' in baksu.read_text(),
            'BAKASU_MANUAL_HOOK_FUNCTION_MISSING')
    core=root/'KernelSU/kernel/selinux/selinux.c'
    require(core.is_file() and 'susfs_priv_app_sid' in core.read_text() and 'susfs_ksu_sid' in core.read_text(),
            'BAKASU_AVC_SID_PROVIDER_MISSING')
    for rel,content in edited.items():(root/rel).write_text(content)
    # No implicit source tree or GitHub commit mutation: only isolate candidate.
    summary={
       'schema':'VEUX_R59_NATIVE54_SELINUX_HOST_V1',
       'status':'FOUR_NATIVE54_SELINUX_HOST_FILES_STAGED_FOR_REAL_COMPILER',
       'updated_host_files':{rel:{'preimage_sha256':orig[rel],
                        'postimage_sha256':sha256((root/rel).read_bytes())} for rel in transforms},
       'manual_hook_ksu_compiler_switch':'KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE',
       'manual_setprocattr_func':'my_setprocattr',
       'native_54_policy_rwlock_preserved':True,
       'selinux_app_scoped_type_filter':True,
       'avc_audit_only':True,
       'kernel_compiled':False,
       'module_vendor_abi_proven':False,
       'flash_allowed':False,
    }
    report=Path(report)
    require(report.parent.exists() and not report.exists(),'REPORT_DIR_NOT_CLEAN')
    report.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(summary['status'])
    return summary

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--kernel',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--inventory',type=Path)
    p.add_argument('--preflight',action='store_true')
    a=p.parse_args()
    try:
        if a.preflight:
            require(a.inventory is None,'PREFLIGHT_MUST_NOT_CLAIM_R13_INVENTORY')
            preflight(a.kernel,a.out)
        else:
            require(a.inventory is not None,'R13_HOST_INVENTORY_REQUIRED')
            install(a.kernel,a.out,a.inventory)
        return 0
    except (OSError,ValueError,GateError) as e:
        print('R59_FAIL_CLOSED='+str(e),file=sys.stderr)
        return 3
if __name__=='__main__':raise SystemExit(main())
