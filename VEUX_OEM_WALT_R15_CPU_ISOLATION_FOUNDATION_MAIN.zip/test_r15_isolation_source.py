#!/usr/bin/env python3
"""R15 source provenance, positive/negative staging and OEM semantics tests."""
import hashlib, importlib, json, os, pathlib, re, subprocess, tempfile, unittest, zipfile
from unittest.mock import patch
import r15_cpu_isolation_source as mod

ROOT=pathlib.Path(__file__).parent
BASE={
'include/linux/cpumask.h':'''extern struct cpumask __cpu_active_mask;
#define cpu_active_mask ((const struct cpumask *)&__cpu_active_mask)
#define cpu_active(cpu) cpumask_test_cpu((cpu), cpu_active_mask)
extern cpumask_t cpus_booted_once_mask;
static inline void set_cpu_active(unsigned int cpu, bool active)
{
    if (active)
        cpumask_set_cpu(cpu, &__cpu_active_mask);
    else
        cpumask_clear_cpu(cpu, &__cpu_active_mask);
}
''',
'kernel/cpu.c':'''struct cpumask __cpu_active_mask __read_mostly;
EXPORT_SYMBOL(__cpu_active_mask);
void init_cpu_online(const struct cpumask *src)
{
    cpumask_copy(&__cpu_online_mask, src);
}
''',
'include/linux/sched.h':(ROOT/'fixtures/R11_linux_sched.h').read_text(),
'include/linux/sched/stat.h':'''#ifndef _LINUX_SCHED_STAT_H
#define _LINUX_SCHED_STAT_H
extern unsigned long nr_iowait_cpu(int cpu);
#endif
''',
'include/linux/cpuhotplug.h':'''enum cpuhp_state {
	CPUHP_RCUTREE_PREP,
	CPUHP_CPUIDLE_COUPLED_PREPARE,
};
''',
}

class BridgeTests(unittest.TestCase):
 def test_01_paths_only_five(self):self.assertEqual(len(mod.PATHS),5)
 def test_02_unique_paths(self):self.assertEqual(len(set(mod.PATHS)),5)
 def test_03_r11_real_sched_sha(self):self.assertEqual(mod.sha(BASE['include/linux/sched.h']),mod.R11_SCHED_SHA)
 def test_04_canonical_tree_fixed(self):self.assertEqual(mod.P10_TREE,'04e3831b70ed3ba19a7bd59e3054b7df5418941d')
 def test_05_no_brene_paths(self):self.assertFalse(any('brene' in x.lower() for x in mod.PATHS))
 def test_06_proven_r14_gate(self):self.assertTrue(mod.gates_ok(self.r14gate(),self.r14result()) is None)
 def test_07_reject_r14_compiler_forgery(self):
  r=self.r14result();r['object_success_count']=10
  with self.assertRaises(mod.GateError):mod.gates_ok(self.r14gate(),r)
 def test_08_reject_r14_abi_forgery(self):
  r=self.r14result();r['vendor_abi_proven']=True
  with self.assertRaises(mod.GateError):mod.gates_ok(self.r14gate(),r)
 def test_09_reject_r14_wrong_source(self):
  g=self.r14gate();g['after_sha256']['kernel/sched/sched.h']='0'*64
  with self.assertRaises(mod.GateError):mod.gates_ok(g,self.r14result())
 def test_10_transform_all(self):
  for n,v in BASE.items():self.assertNotEqual(mod.TRANSFORM[n](v),v)
 def test_11_cpumask_extern(self):self.assertIn('extern struct cpumask __cpu_isolated_mask;',mod.patch_cpumask(BASE['include/linux/cpumask.h']))
 def test_12_cpumask_actual_bit(self):self.assertIn('cpumask_test_cpu((cpu), cpu_isolated_mask)',mod.patch_cpumask(BASE['include/linux/cpumask.h']))
 def test_13_cpumask_setters_real(self):
  s=mod.patch_cpumask(BASE['include/linux/cpumask.h']);self.assertIn('cpumask_set_cpu(cpu, &__cpu_isolated_mask)',s);self.assertIn('cpumask_clear_cpu(cpu, &__cpu_isolated_mask)',s)
 def test_14_cpumask_walt_disabled(self):self.assertIn('num_online_uniso_cpus() num_online_cpus()',mod.patch_cpumask(BASE['include/linux/cpumask.h']))
 def test_15_cpumask_guard_nr_cpus(self):self.assertIn('defined(CONFIG_SCHED_WALT) && NR_CPUS > 1',mod.patch_cpumask(BASE['include/linux/cpumask.h']))
 def test_16_cpumask_reapply_blocked(self):
  s=mod.patch_cpumask(BASE['include/linux/cpumask.h']);
  with self.assertRaises(mod.GateError):mod.patch_cpumask(s)
 def test_17_cpu_storage_export(self):self.assertIn('EXPORT_SYMBOL(__cpu_isolated_mask)',mod.patch_cpu(BASE['kernel/cpu.c']))
 def test_18_cpu_mask_initializer(self):self.assertIn('cpumask_copy(&__cpu_isolated_mask, src)',mod.patch_cpu(BASE['kernel/cpu.c']))
 def test_19_cpu_storage_walt_guard(self):self.assertIn('#ifdef CONFIG_SCHED_WALT',mod.patch_cpu(BASE['kernel/cpu.c']))
 def test_20_cpu_reapply_blocked(self):
  with self.assertRaises(mod.GateError):mod.patch_cpu(mod.patch_cpu(BASE['kernel/cpu.c']))
 def test_21_sched_real_extern(self):self.assertIn('extern int sched_isolate_cpu(int cpu)',mod.patch_sched(BASE['include/linux/sched.h']))
 def test_22_sched_unisolate_real(self):self.assertIn('extern int sched_unisolate_cpu_unlocked(int cpu)',mod.patch_sched(BASE['include/linux/sched.h']))
 def test_23_sched_no_dummy_success(self):self.assertNotIn('return 0;',mod.patch_sched(BASE['include/linux/sched.h']).split('extern int sched_isolate_cpu(int cpu);')[1].split('#endif')[0])
 def test_24_sched_walt_hotplug_guard(self):self.assertIn('defined(CONFIG_HOTPLUG_CPU) && defined(CONFIG_SCHED_WALT)',mod.patch_sched(BASE['include/linux/sched.h']))
 def test_25_sched_changed_preimage_fails(self):
  with self.assertRaises(mod.GateError):mod.patch_sched(BASE['include/linux/sched.h']+'\n')
 def test_26_stats_real_provider(self):self.assertIn('extern unsigned int sched_get_cpu_util(int cpu)',mod.patch_stats(BASE['include/linux/sched/stat.h']))
 def test_27_hotplug_correct_order(self):
  s=mod.patch_hotplug(BASE['include/linux/cpuhotplug.h']);self.assertLess(s.index('CPUHP_RCUTREE_PREP'),s.index('CPUHP_CORE_CTL_ISOLATION_DEAD'));self.assertLess(s.index('CPUHP_CORE_CTL_ISOLATION_DEAD'),s.index('CPUHP_CPUIDLE_COUPLED_PREPARE'))
 def test_28_missing_anchor_rejected(self):
  with self.assertRaises(mod.GateError):mod.patch_hotplug('enum cpu {X};\n')
 def test_29_missing_cpu_active_anchor_rejected(self):
  with self.assertRaises(mod.GateError):mod.patch_cpumask('extern cpumask_t cpus_booted_once_mask;\n')
 def test_30_duplicate_scheduler_proto_blocked(self):
  with self.assertRaises(mod.GateError):mod.patch_sched(BASE['include/linux/sched.h'].replace('extern void scheduler_tick(void);','extern int sched_isolate_cpu(int cpu);\nextern void scheduler_tick(void);'))
 def test_31_no_source_artifact_claims(self):
  s=pathlib.Path(mod.__file__).read_text();self.assertNotIn("'flash_allowed':True",s)
 def test_32_oem_cpu_setter_not_noop(self):self.assertNotIn('set_cpu_isolated(unsigned int cpu, bool isolated) {}',mod.patch_cpumask(BASE['include/linux/cpumask.h']))
 def test_33_r14_evidence_hash(self):self.assertEqual(self.r14result()['object_success_count'],8)
 def test_34_authorized_donor(self):self.assertIn('MiCode/',mod.DONOR)
 def test_35_snapshot_diff_gate(self):self.assertIn('P10_PREIMAGE_MISMATCH',pathlib.Path(mod.__file__).read_text())
 def test_36_git_tree_real(self):
  with self.fixture() as (snapshot,repo,r14_source,r14_compiler,_):
   old=mod.P10_TREE;mod.P10_TREE=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip()
   try:
    self.assertEqual(mod.git_show(repo,mod.P10_TREE,'kernel/cpu.c'),BASE['kernel/cpu.c'].encode())
   finally:mod.P10_TREE=old
 def test_37_real_stage_patch_roundtrip(self):
  with self.fixture() as (snapshot,repo,r14_source,r14_compiler,out):
   old=mod.P10_TREE;mod.P10_TREE=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip()
   try:
    result=mod.stage(snapshot,repo,r14_source,r14_compiler,out)
    self.assertEqual(result['modified_files'],list(mod.PATHS))
    self.assertEqual(len(result['after_sha256']),5)
    patch=out/'R15_CPU_ISOLATION_FOUNDATION.patch';self.assertTrue(patch.is_file())
    test=subprocess.run(['git','-C',str(snapshot),'apply','--reverse','--check',str(patch)],capture_output=True,text=True)
    self.assertEqual(test.returncode,0,test.stderr)
   finally:mod.P10_TREE=old
 def test_38_modified_source_refused_before_edits(self):
  with self.fixture() as (snap,repo,gs,gc,out):
   (snap/'kernel/cpu.c').write_text(BASE['kernel/cpu.c']+'// drift\n')
   old=mod.P10_TREE;mod.P10_TREE=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD^{tree}'],text=True).strip()
   try:
    with self.assertRaises(mod.GateError):mod.stage(snap,repo,gs,gc,out)
    self.assertFalse(out.exists());self.assertEqual((snap/'include/linux/sched.h').read_text(),BASE['include/linux/sched.h'])
   finally:mod.P10_TREE=old
 def test_39_wrong_gate_rejected(self):
  with self.fixture() as (snap,repo,gs,gc,out):
   j=json.loads(gs.read_text());j['status']='FAKE';gs.write_text(json.dumps(j))
   with self.assertRaises(mod.GateError):mod.stage(snap,repo,gs,gc,out)
 def test_40_no_duplicate_source_filenames(self):self.assertEqual(len(mod.TRANSFORM),5)
 @staticmethod
 def r14gate():return json.loads((ROOT/'fixtures/R14_SOURCE_GATE.json').read_text())
 @staticmethod
 def r14result():return json.loads((ROOT/'fixtures/R14_COMPILER_RESULT.json').read_text())
 from contextlib import contextmanager
 @contextmanager
 def fixture(self):
  with tempfile.TemporaryDirectory() as td:
   t=pathlib.Path(td);repo=t/'canonical';repo.mkdir();snap=t/'snapshot';snap.mkdir()
   for p,s in BASE.items():
    for root in (repo,snap):
     (root/p).parent.mkdir(parents=True,exist_ok=True);(root/p).write_text(s)
   subprocess.run(['git','init','-q',str(repo)],check=True)
   subprocess.run(['git','-C',str(repo),'add','.'],check=True)
   subprocess.run(['git','-C',str(repo),'-c','user.email=test@example.org','-c','user.name=R15 Test','commit','-qm','baseline'],check=True)
   subprocess.run(['git','init','-q',str(snap)],check=True)
   gs=t/'source.json';gc=t/'compiler.json';gs.write_text(json.dumps(self.r14gate()));gc.write_text(json.dumps(self.r14result()))
   yield snap,repo,gs,gc,t/'stage-result'

if __name__=='__main__':unittest.main()
