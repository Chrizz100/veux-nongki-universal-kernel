#!/usr/bin/env python3
"""Compiler gate must not confuse a green diagnostic workflow with a build."""
import json,pathlib,tempfile,unittest,hashlib
from types import SimpleNamespace
from unittest.mock import patch
import r15_cpu_isolation_compile as mod

ROOT=pathlib.Path(__file__).parent
SOURCE={'status':mod.R15_SOURCE_STATUS,'source_r14_proven':True,
 'modified_files':['include/linux/cpumask.h','kernel/cpu.c','include/linux/sched.h','include/linux/sched/stat.h','include/linux/cpuhotplug.h'],
 'canonical_p10_tree':'04e3831b70ed3ba19a7bd59e3054b7df5418941d',
 'after_sha256':{},'flash_allowed':False,'vendor_abi_proven':False,
 'brene_changed':False,'bakasusu_nomount_changed':False,'kernel_image_built':False,'vmlinux_linked':False}

class CompilerTests(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.t=pathlib.Path(self.temp.name)
 def tearDown(self):self.temp.cleanup()
 def q(self):
  p=self.t
  for n in ('snapshot','objout','toolchain/bin','r14-report','project'):(p/n).mkdir(parents=True,exist_ok=True)
  for n in ('toolchain/bin/clang','toolchain/bin/llvm-nm'):(p/n).write_text('clang\n')
  (p/'source.json').write_text(json.dumps(SOURCE))
  (p/'r14-report/R14_COMPILER_RESULT.json').write_text((ROOT/'fixtures/R14_COMPILER_RESULT.json').read_text())
  return SimpleNamespace(snapshot=p/'snapshot',objout=p/'objout',toolchain=p/'toolchain',r14_report=p/'r14-report',project=p/'project',source_gate=p/'source.json',driver=ROOT/'fixtures/r9_walt_real_object_compile.py',output=p/'r15-result',r12_config=ROOT/'fixtures/R9_EFFECTIVE_CONFIG.config')
 def test_01_target_count(self):self.assertEqual(len(mod.TARGETS),11)
 def test_02_target_uniqueness(self):self.assertEqual(len(set(mod.TARGETS)),11)
 def test_03_cpu_storage_target(self):self.assertEqual(mod.TARGETS[-1],'kernel/cpu.o')
 def test_04_original_ten(self):self.assertEqual(mod.TARGETS[:10],mod.R14_TARGETS)
 def test_05_previous_proof(self):self.assertEqual(mod.R14_SUCCESS,8)
 def test_06_pinned_driver_hash(self):self.assertEqual(mod.sha(ROOT/'fixtures/r9_walt_real_object_compile.py'),mod.DRIVER_SHA)
 def test_07_mock_classify_all_success(self):
  x={p:{'compiled':True} for p in mod.TARGETS}
  self.assertEqual(mod.result_status(x,{'cpu_isolated_symbol_defined':True})[0],'R15_ELEVEN_OBJECTS_COMPILED_LINK_STILL_UNPROVEN')
 def test_08_classify_no_fake_symbol_proof(self):
  x={p:{'compiled':True} for p in mod.TARGETS}
  self.assertNotEqual(mod.result_status(x,{'cpu_isolated_symbol_defined':False})[0],'R15_ELEVEN_OBJECTS_COMPILED_LINK_STILL_UNPROVEN')
 def test_09_classify_corectl_failure(self):
  x={p:{'compiled':True} for p in mod.TARGETS};x['kernel/sched/walt/core_ctl.o']['compiled']=False
  self.assertEqual(mod.result_status(x,{'cpu_isolated_symbol_defined':True})[0],'R15_GENUINE_CPU_ISOLATION_COMPILER_DIAGNOSTICS')
 def test_10_classify_old_eight_regression(self):
  x={p:{'compiled':True} for p in mod.TARGETS};x['kernel/sched/fair.o']['compiled']=False
  self.assertEqual(mod.result_status(x,{'cpu_isolated_symbol_defined':True})[0],'R15_PROVEN_EIGHT_OBJECT_REGRESSION')
 def test_11_reject_wrong_target_set(self):
  with self.assertRaises(mod.CompileGateError):mod.result_status({'wrong':{'compiled':True}},{})
 def test_12_reject_bad_driver(self):
  q=self.q();q.driver=self.t/'not-real';q.driver.write_text('hello')
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_13_reject_fake_r14_status(self):
  q=self.q();r=json.loads((q.r14_report/'R14_COMPILER_RESULT.json').read_text());r['object_success_count']=10;(q.r14_report/'R14_COMPILER_RESULT.json').write_text(json.dumps(r))
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_14_reject_abi_true(self):
  q=self.q();r=json.loads(q.source_gate.read_text());r['vendor_abi_proven']=True;q.source_gate.write_text(json.dumps(r))
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_15_reject_flash_true(self):
  q=self.q();r=json.loads(q.source_gate.read_text());r['flash_allowed']=True;q.source_gate.write_text(json.dumps(r))
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_16_reject_incorrect_walt_config(self):
  q=self.q();cfg=self.t/'bad.config';cfg.write_text('CONFIG_SCHED_WALT=n\n');q.r12_config=cfg
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_17_reject_unpinned_tree(self):
  q=self.q();r=json.loads(q.source_gate.read_text());r['canonical_p10_tree']='a'*40;q.source_gate.write_text(json.dumps(r))
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_18_reject_output_exists(self):
  q=self.q();q.output.mkdir()
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_19_source_sha_negative(self):
  q=self.q();r=json.loads(q.source_gate.read_text());r['after_sha256']={'kernel/cpu.c':'f'*64};q.source_gate.write_text(json.dumps(r))
  with self.assertRaises(mod.CompileGateError):mod.verify(q)
 def test_20_valid_input_gate(self):
  q=self.q();gate,r14=mod.verify(q);self.assertEqual(r14['object_success_count'],8)
 def test_21_no_full_kernel_link_claim(self):
  self.assertIn("'vmlinux_linked':False",pathlib.Path(mod.__file__).read_text())
 def test_22_real_object_required(self):
  s=pathlib.Path(mod.__file__).read_text();self.assertIn("d.get('exit_code')==0",s);self.assertIn("and yes",s)
 def test_23_symlink_source_forbidden(self):self.assertIn("source.is_symlink()",pathlib.Path(mod.__file__).read_text())
 def test_24_cpu_mask_provider_nm(self):self.assertIn("'--defined-only'",pathlib.Path(mod.__file__).read_text())
 def test_25_false_build_claim_guards(self):self.assertIn('qc_vas_compiled',pathlib.Path(mod.__file__).read_text())

if __name__=='__main__':unittest.main()
