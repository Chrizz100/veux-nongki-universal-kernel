#!/usr/bin/env python3
"""R15 ARM64 genuine WALT object rebuild incl. CPU isolation storage.

Records failures as diagnostics; SUCCESS only for actual fresh object file +
real zero Kbuild exit code. There is NO vmlinux, module ABI, Image or flash.
"""
import argparse, hashlib, importlib.util, json, os, pathlib, re, subprocess, sys

R14_TARGETS=('kernel/sched/walt/walt.o','kernel/sched/core.o','kernel/sched/fair.o','kernel/sysctl.o',
 'kernel/sched/walt/boost.o','kernel/sched/walt/sched_avg.o','kernel/sched/walt/qc_vas.o',
 'kernel/sched/walt/core_ctl.o','kernel/sched/walt/trace.o','kernel/sched/walt/cpu-boost.o')
TARGETS=R14_TARGETS+('kernel/cpu.o',)
R14_SUCCESS=8
R14_COMPILER_STATUS='R14_WALT_SUBSYSTEM_COMPILER_ERRORS_RECORDED'
R15_SOURCE_STATUS='R15_OEM_CPU_ISOLATION_FOUNDATION_STAGED_NOT_COMPILED'
DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
class CompileGateError(Exception):pass

def need(ok,reason):
 if not ok:raise CompileGateError(reason)

def sha(path):return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def load(path):return json.loads(pathlib.Path(path).read_text())

def verify(q):
 for p in (q.snapshot,q.objout,q.toolchain,q.r14_report):
  need(p.is_dir() and not p.is_symlink(),'DIR_BAD:'+str(p))
 need(q.project.is_dir(),'WORKSPACE_BAD')
 need(q.snapshot.resolve()!=q.project.resolve(),'SNAPSHOT_IS_WORKSPACE')
 need(q.objout.resolve()!=q.snapshot.resolve(),'SAME_OBJOUT_AS_SOURCE')
 need(q.objout.resolve()!=q.project.resolve(),'OBJOUT_IS_WORKSPACE')
 for p in (q.source_gate,q.driver):need(p.is_file() and not p.is_symlink(),'FILE_MISSING:'+str(p))
 need(not q.output.exists() and not q.output.is_symlink(),'OUTPUT_ALREADY_EXISTS')
 need(sha(q.driver)==DRIVER_SHA,'DRIVER_SHA_CHANGED')
 need((q.toolchain/'bin/clang').is_file() and (q.toolchain/'bin/llvm-nm').is_file(),'TOOLCHAIN_INVALID')
 gate=load(q.source_gate);r14=load(q.r14_report/'R14_COMPILER_RESULT.json')
 need(gate.get('status')==R15_SOURCE_STATUS and gate.get('source_r14_proven') is True,'R15_SOURCE_GATE_INVALID')
 need(len(gate.get('modified_files',[]))==5 and gate.get('canonical_p10_tree')=='04e3831b70ed3ba19a7bd59e3054b7df5418941d','SOURCE_PROVENANCE_DRIFT')
 need(r14.get('status')==R14_COMPILER_STATUS and r14.get('object_success_count')==R14_SUCCESS,'R14_NOT_EIGHT_OF_TEN')
 need(r14.get('baseline_objects_compiled')==4 and r14.get('real_arm64_make_attempted') is True,'R14_BASE_NOT_VERIFIED')
 for flag in ('flash_allowed','vendor_abi_proven','brene_changed','bakasusu_nomount_changed','kernel_image_built','vmlinux_linked'):
  need(gate.get(flag) is False and r14.get(flag) is False,'UNSAFE_STATUS:'+flag)
 for p, expected in gate.get('after_sha256',{}).items():
  f=q.snapshot/p
  need(f.is_file() and not f.is_symlink() and sha(f)==expected,'POSTIMAGE_CHANGED:'+p)
 config=q.r14_report.parent/'veux-oem-walt-r12-compiler-audit'/'R9_EFFECTIVE_CONFIG.config'
 # The effective config may reside in R12 report, supplied independently.
 cfile=q.r12_config
 need(cfile.is_file(),'EFFECTIVE_CONFIG_MISSING')
 config_text=cfile.read_text()
 for tok in ('CONFIG_SCHED_WALT=y','CONFIG_PROC_SYSCTL=y','CONFIG_QGKI=y','CONFIG_HOTPLUG_CPU=y'):
  need(re.search(r'(?m)^'+re.escape(tok)+r'$',config_text) is not None,'OEM_CONFIG_DRIFT:'+tok)
 return gate,r14

def record_one(target,q,driver,log_dir,env):
 need(target in TARGETS,'TARGET_OUT_OF_SCOPE')
 p=q.objout/target
 need(p.parent.is_dir() and not p.parent.is_symlink(),'OBJ_DIR_MISSING:'+target)
 source=q.snapshot/(target[:-1]+'c')
 log=log_dir/(target.replace('/','_')+'.log')
 if not source.is_file() or source.is_symlink():
  log.write_text('R15_SOURCE_FILE_MISSING:'+str(source)+'\n')
  return {'compiled':False,'exit_code':None,'object_file_present':False,'failure':'SOURCE_FILE_MISSING','log':str(log),'log_sha256':sha(log)}
 for f in (p,p.parent/('.'+p.name+'.cmd')):
  need(not f.is_symlink() and (not f.exists() or f.is_file()),'UNSAFE_OLD_BUILD_FILE:'+str(f))
  if f.exists():f.unlink()
 d=driver.run_cmd(driver.make_argv(q.snapshot,q.objout,q.toolchain,target,2),log,300,env=env)
 yes=p.is_file() and not p.is_symlink() and p.stat().st_size>0
 good=d.get('exit_code')==0 and d.get('timed_out') is False and yes
 return {**d,'compiled':bool(good),'object_file_present':yes,'object_bytes':p.stat().st_size if yes else 0,
         **({'object_sha256':sha(p)} if yes else {})}

def nm_probe(q,objects):
 cpu=q.objout/'kernel/cpu.o';core=q.objout/'kernel/sched/walt/core_ctl.o'
 nm=q.toolchain/'bin/llvm-nm'
 report={'real_nm_attempted':False,'cpu_isolated_symbol_defined':False,
 'core_ctl_compiled':objects['kernel/sched/walt/core_ctl.o']['compiled'],
 'qc_vas_compiled':objects['kernel/sched/walt/qc_vas.o']['compiled'],
 'not_a_vmlinux_link':True}
 if cpu.is_file() and objects['kernel/cpu.o']['compiled']:
  cmd=subprocess.run([str(nm),'--defined-only',str(cpu)],capture_output=True,text=True)
  report['real_nm_attempted']=True
  report['llvm_nm_exit_code']=cmd.returncode
  report['cpu_isolated_symbol_defined']=bool(cmd.returncode==0 and re.search(r'(?m)^[0-9a-fA-F]+\s+[BCDGRS]\s+__cpu_isolated_mask$',cmd.stdout))
  (q.output/'R15_CPU_MASK_DEFINED.nm.txt').write_text(cmd.stdout+cmd.stderr)
 if core.is_file() and objects['kernel/sched/walt/core_ctl.o']['compiled']:
  cmd=subprocess.run([str(nm),'--undefined-only',str(core)],capture_output=True,text=True)
  report['core_ctl_unresolved_symbols']=sorted(set(re.findall(r'(?m)^\s+U\s+([A-Za-z_][A-Za-z_0-9]*)$',cmd.stdout))) if cmd.returncode==0 else []
  (q.output/'R15_CORE_CTL_UNDEFINED.nm.txt').write_text(cmd.stdout+cmd.stderr)
 return report

def result_status(records,mask):
 need(set(records)==set(TARGETS),'WRONG_TARGET_SET')
 num=sum(t['compiled'] is True for t in records.values())
 base=sum(records[p]['compiled'] for p in R14_TARGETS if p not in ('kernel/sched/walt/core_ctl.o','kernel/sched/walt/qc_vas.o'))
 if num==len(TARGETS) and mask.get('cpu_isolated_symbol_defined') is True:
  return 'R15_ELEVEN_OBJECTS_COMPILED_LINK_STILL_UNPROVEN',num,base
 if base<8:return 'R15_PROVEN_EIGHT_OBJECT_REGRESSION',num,base
 return 'R15_GENUINE_CPU_ISOLATION_COMPILER_DIAGNOSTICS',num,base

def run(q):
 gate,r14=verify(q)
 spec=importlib.util.spec_from_file_location('veux_r9_driver',q.driver)
 need(spec and spec.loader,'PINNED_DRIVER_IMPORT_FAILED')
 lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
 need(callable(lib.make_argv) and callable(lib.run_cmd),'PINNED_DRIVER_METHOD_MISSING')
 q.output.mkdir(parents=True);logdir=q.output/'compiler_logs';logdir.mkdir()
 r={'status':'R15_STARTED','targets':list(TARGETS),'objects':{},'kernel_version':'5.4.274',
    'r14_eight_compiled_proven':True,'r15_exact_source_proven':True,'actual_arm64_make_attempted':True,
    'vendor_abi_proven':False,'kernel_image_built':False,'vmlinux_linked':False,
    'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False}
 out=q.output/'R15_COMPILER_RESULT.json';out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 env=os.environ.copy();env['PATH']=str(q.toolchain/'bin')+os.pathsep+env.get('PATH','')
 for target in TARGETS:
  r['objects'][target]=record_one(target,q,lib,logdir,env)
  out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 mask=nm_probe(q,r['objects']);status,count,base=result_status(r['objects'],mask)
 r.update({'status':status,'object_success_count':count,'prior_eight_compiled':base,'mask_symbol_proof':mask})
 out.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 print(f'R15_GENUINE_ARM64_OBJECTS={count}/11; R14_BASE={base}/8; CORE_CTL={int(r["objects"]["kernel/sched/walt/core_ctl.o"]["compiled"])}; QC_VAS={int(r["objects"]["kernel/sched/walt/qc_vas.o"]["compiled"])}; STATUS={status}; IMAGE=NO; ABI=NO; FLASH=NO')
 return r

def main():
 p=argparse.ArgumentParser()
 for n in ('snapshot','objout','toolchain','source-gate','r14-report','r12-config','driver','output','project'):
  p.add_argument('--'+n,type=pathlib.Path,required=True)
 q=p.parse_args()
 try:run(q)
 except (CompileGateError,OSError,ValueError,KeyError) as e:print('R15_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr);sys.exit(2)
if __name__=='__main__':main()
