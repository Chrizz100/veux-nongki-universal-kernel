#!/usr/bin/env python3
"""R15: source-proven Xiaomi WALT CPU isolation foundation (NO FLASH).

Not a complete hotplug port. Only genuine OEM WALT cpumask storage, accessors,
hotplug state and scheduler declarations; never pretend CPU isolation is
operational before qc_vas.o and link prove it.
"""
import argparse, difflib, hashlib, json, pathlib, re, subprocess, sys

P10_TREE='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
R11_SCHED_SHA='b9c7b4a39d4d5ed5a28cbe0513540f62c903f2db840dfdd2c792b4593f1c23da'
R14_SCHED_SHA='fe9743bb8d6f7e5be6b2a8df563924c59e6c7a84739181bb91d39047cd2673c6'
R14_STATUS='R14_REAL_XIAOMI_AVG_TRACE_HELPERS_STAGED_NOT_COMPILED'
R14_COMPILER_STATUS='R14_WALT_SUBSYSTEM_COMPILER_ERRORS_RECORDED'
DONOR='MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'
PATHS=('include/linux/cpumask.h','kernel/cpu.c','include/linux/sched.h',
       'include/linux/sched/stat.h','include/linux/cpuhotplug.h')
NEW_PATHS=tuple(p for p in PATHS if p != 'include/linux/sched.h')
class GateError(Exception): pass

def need(ok,msg):
    if not ok: raise GateError(msg)

def sha(b):
    return hashlib.sha256(b if isinstance(b,bytes) else b.encode()).hexdigest()

def replace_one(src,old,new,tag):
    need(src.count(old)==1,f'{tag}_ANCHOR_COUNT_{src.count(old)}')
    return src.replace(old,new,1)

def patch_cpumask(s):
    need('__cpu_isolated_mask' not in s and 'cpu_isolated(cpu)' not in s,'CPU_ISOLATED_ALREADY_PRESENT')
    a=re.search(r'^(#define cpu_active_mask[^\n]*\n)',s,re.M)
    need(a is not None,'CPU_ACTIVE_MASK_DEFINITION_MISSING')
    s=s[:a.end()] + ('\n#ifdef CONFIG_SCHED_WALT\n'
     'extern struct cpumask __cpu_isolated_mask;\n'
     '#define cpu_isolated_mask ((const struct cpumask *)&__cpu_isolated_mask)\n'
     '#endif\n') + s[a.end():]
    anchor='extern cpumask_t cpus_booted_once_mask;\n'
    block=('''#if defined(CONFIG_SCHED_WALT) && NR_CPUS > 1
#define num_isolated_cpus() cpumask_weight(cpu_isolated_mask)
#define num_online_uniso_cpus() ({ \\
    cpumask_t mask; \\
    cpumask_andnot(&mask, cpu_online_mask, cpu_isolated_mask); \\
    cpumask_weight(&mask); \\
})
#define cpu_isolated(cpu) cpumask_test_cpu((cpu), cpu_isolated_mask)
#else
#define num_isolated_cpus() 0U
#define num_online_uniso_cpus() num_online_cpus()
#define cpu_isolated(cpu) 0U
#endif

''')
    s=replace_one(s,anchor,block+anchor,'ISOLATION_READERS')
    regex=r'(static inline void\s+set_cpu_active\s*\(\s*unsigned int cpu\s*,\s*bool active\s*\)\s*\{[^}]*\}\n)'
    m=re.search(regex,s)
    need(m is not None,'SET_CPU_ACTIVE_ANCHOR_MISSING')
    setter=('''
#ifdef CONFIG_SCHED_WALT
/* Original Xiaomi CPU-isolation state writer; no success-return stub. */
static inline void set_cpu_isolated(unsigned int cpu, bool isolated)
{
    if (isolated)
        cpumask_set_cpu(cpu, &__cpu_isolated_mask);
    else
        cpumask_clear_cpu(cpu, &__cpu_isolated_mask);
}
#endif
''')
    s=s[:m.end()]+setter+s[m.end():]
    return s

def patch_cpu(s):
    need('__cpu_isolated_mask' not in s,'CPU_ISOLATED_STORAGE_ALREADY_PRESENT')
    anchor='EXPORT_SYMBOL(__cpu_active_mask);\n'
    storage=('''
#ifdef CONFIG_SCHED_WALT
struct cpumask __cpu_isolated_mask __read_mostly;
EXPORT_SYMBOL(__cpu_isolated_mask);
#endif
''')
    s=replace_one(s,anchor,anchor+storage,'CPU_ISOLATED_STORAGE')
    # Mirrors stock 5.4 WALT initializer and lets original callers pass a mask.
    m=re.search(r'(void init_cpu_online\s*\(const struct cpumask \*src\)\s*\{[^}]*\}\n)',s)
    need(m is not None,'INIT_CPU_ONLINE_ANCHOR_MISSING')
    init=('''
#ifdef CONFIG_SCHED_WALT
void init_cpu_isolated(const struct cpumask *src)
{
    cpumask_copy(&__cpu_isolated_mask, src);
}
#endif
''')
    return s[:m.end()]+init+s[m.end():]

def patch_sched(s):
    need(sha(s)==R11_SCHED_SHA,'R11_INCLUDE_SCHED_SHA_MISMATCH')
    need('enum migrate_types {' in s,'R11_MIGRATE_ENUM_MISSING')
    need('extern int sched_isolate_cpu(int cpu)' not in s,'ALREADY_HAS_ISOLATION_PROTOTYPES')
    m=re.search(r'(enum migrate_types\s*\{[^}]*\};\n)',s)
    need(m is not None,'R11_MIGRATE_ENUM_END_MISSING')
    # No WALT-OFF fake function; these are backed by real OEM qc_vas.c symbols.
    block=('''
#if defined(CONFIG_HOTPLUG_CPU) && defined(CONFIG_SCHED_WALT)
extern int sched_isolate_cpu(int cpu);
extern int sched_unisolate_cpu(int cpu);
extern int sched_unisolate_cpu_unlocked(int cpu);
#endif
''')
    return s[:m.end()]+block+s[m.end():]

def patch_stats(s):
    need('sched_get_cpu_util' not in s,'SCHED_UTIL_ALREADY_PRESENT')
    anchor='extern unsigned long nr_iowait_cpu(int cpu);\n'
    ext=('''
#ifdef CONFIG_SCHED_WALT
/* Provider: Xiaomi kernel/sched/walt/sched_avg.c, real busy percent. */
extern unsigned int sched_get_cpu_util(int cpu);
#endif
''')
    return replace_one(s,anchor,anchor+ext,'CPU_UTIL_DECL')

def patch_hotplug(s):
    need('CPUHP_CORE_CTL_ISOLATION_DEAD' not in s,'CORE_CTL_CPUHP_ALREADY_PRESENT')
    anchor='\tCPUHP_RCUTREE_PREP,\n'
    oem='''#ifdef CONFIG_SCHED_WALT
\tCPUHP_CORE_CTL_ISOLATION_DEAD,
#endif
'''
    return replace_one(s,anchor,anchor+oem,'HOTPLUG_STATE_ORDER')

TRANSFORM={'include/linux/cpumask.h':patch_cpumask,'kernel/cpu.c':patch_cpu,
           'include/linux/sched.h':patch_sched,'include/linux/sched/stat.h':patch_stats,
           'include/linux/cpuhotplug.h':patch_hotplug}

def git_show(repo,tree,relative):
    need(re.fullmatch('[a-f0-9]{40}',tree) is not None,'INVALID_CANONICAL_TREE')
    cmd=['git','-C',str(repo),'show',f'{tree}:{relative}']
    p=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    need(p.returncode==0,'PINNED_GIT_BLOB_NOT_FOUND:'+relative+':'+p.stderr.decode(errors='replace')[:130])
    return p.stdout

def gates_ok(r14gate,r14result):
    need(r14gate.get('status')==R14_STATUS,'BAD_R14_SOURCE_STATUS')
    need(r14gate.get('after_sha256',{}).get('kernel/sched/sched.h')==R14_SCHED_SHA,'R14_SCHED_PROVENANCE_DRIFT')
    need(r14result.get('status')==R14_COMPILER_STATUS,'R14_COMPILER_STATUS_DRIFT')
    need(r14result.get('object_success_count')==8 and r14result.get('baseline_objects_compiled')==4,'R14_EIGHT_OBJECTS_NOT_PROVEN')
    need(r14result.get('real_arm64_make_attempted') is True and r14result.get('walt_enabled') is True,'R14_NO_REAL_ARM64_WALT')
    need(all(r14result['objects'][p]['compiled'] for p in ('kernel/sched/core.o','kernel/sched/fair.o','kernel/sched/walt/walt.o','kernel/sysctl.o')),'R14_BASE_REGRESSION')
    for name in ('flash_allowed','kernel_image_built','vmlinux_linked','vendor_abi_proven','brene_changed','bakasusu_nomount_changed'):
        need(r14result.get(name) is False,'R14_UNSAFE_STATE:'+name)

def stage(snapshot,canonical_repo,r14source,r14compiler,output):
    need(snapshot.is_dir() and not snapshot.is_symlink(),'SNAPSHOT_INVALID')
    need(canonical_repo.is_dir() and not canonical_repo.is_symlink(),'CANONICAL_REPO_INVALID')
    need(snapshot.resolve()!=canonical_repo.resolve(),'WRONG_SNAPSHOT')
    for p in (r14source,r14compiler): need(p.is_file() and not p.is_symlink(),'MISSING_INPUT:'+str(p))
    need(not output.exists() and not output.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    gates_ok(json.loads(r14source.read_text()),json.loads(r14compiler.read_text()))
    data={};prior={};blob={}
    # Every untouched source must match the exact *post-P10* Git tree, not
    # the pre-274 dereference ancestor. The modified sched.h pins to R11.
    for name in PATHS:
        p=snapshot/name
        need(p.is_file() and not p.is_symlink(),'MISSING_OR_SYMLINK_SOURCE:'+name)
        b=p.read_bytes();data[name]=b.decode('utf-8');prior[name]=sha(b)
        if name in NEW_PATHS:
            expected=git_show(canonical_repo,P10_TREE,name)
            need(b==expected,'P10_PREIMAGE_MISMATCH:'+name)
            blob[name]=hashlib.sha1(('blob '+str(len(b))+'\x00').encode()+b).hexdigest()
        else: need(prior[name]==R11_SCHED_SHA,'R11_CURRENT_SCHED_DRIFT')
    changed={name:TRANSFORM[name](data[name]) for name in PATHS}
    need(all(changed[n]!=data[n] for n in PATHS),'R15_NO_CHANGE_TO_ONE_SOURCE')
    patch=''.join(''.join(difflib.unified_diff(data[n].splitlines(keepends=True),changed[n].splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n in PATHS)
    need(patch.count('--- a/')==len(PATHS) and patch.count('+++ b/')==len(PATHS),'R15_PATCH_SCOPE_DRIFT')
    # Real diff+whitespace validation before modifying any source file.
    chk=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=patch,text=True,capture_output=True)
    need(chk.returncode==0,'R15_GIT_APPLY_CHECK_FAILED:'+chk.stderr[:260])
    for name in PATHS: (snapshot/name).write_text(changed[name])
    after={n:sha(changed[n]) for n in PATHS}
    need(all(sha((snapshot/n).read_bytes())==after[n] for n in PATHS),'R15_POSTIMAGE_FAILED')
    output.mkdir(parents=True)
    (output/'R15_CPU_ISOLATION_FOUNDATION.patch').write_text(patch)
    result={'status':'R15_OEM_CPU_ISOLATION_FOUNDATION_STAGED_NOT_COMPILED',
       'canonical_p10_tree':P10_TREE,'donor_ref':DONOR,
       'source_r14_proven':True,'real_r14_eight_compiled':True,
       'before_sha256':prior,'after_sha256':after,'preimage_git_blobs':blob,
       'modified_files':list(PATHS),'patch_sha256':sha(patch),
       'kernel_version':'5.4.274','kernel_image_built':False,'vmlinux_linked':False,
       'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
       'bakasusu_nomount_changed':False,'cpu_isolation_linked':False,
       'qc_vas_runtime_proven':False,'kernel_object_build_attempted':False}
    (output/'R15_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R15_REAL_CPU_ISOLATION_SOURCE_GATE=PASS; PATHS=5; REAL_BUILD=PENDING; VENDOR_ABI=OPEN; FLASH=NO')
    return result

def main():
    a=argparse.ArgumentParser()
    for k in ('snapshot','canonical-repo','r14-source','r14-compiler','output'):
        a.add_argument('--'+k,type=pathlib.Path,required=True)
    q=a.parse_args()
    try:stage(q.snapshot,q.canonical_repo,q.r14_source,q.r14_compiler,q.output)
    except (GateError,KeyError,ValueError,OSError) as e:
        print('R15_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr);sys.exit(2)
if __name__=='__main__':main()
