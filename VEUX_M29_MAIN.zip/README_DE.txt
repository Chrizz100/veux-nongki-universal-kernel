VEUX M29 – Zwei BQ-Startfehler absichern – NOFLASH
Basis: erfolgreicher M28-R2-Lauf 43691305961, Commit 4647fc2bcf89e6804ad3e417626a116aa959cb7b.

UPLOAD AM SMARTPHONE
1. VEUX_M29_MAIN.zip unveraendert ins Hauptverzeichnis der GitHub-Repo hochladen.
   Die MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M29_YAML.zip entpacken. Die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml ersetzt dort
   die bisherige Workflow-Datei. Anschliessend den Workflow manuell starten.
3. VEUX_R25_MAIN.zip muss wie bisher im Hauptverzeichnis bleiben.
   M25-R2/M26/M27/M28-R2 werden aus unveraenderlichen Commit-Referenzen geladen.

BESTAETIGTER M28-R2-STAND
Alle 32 Artefakte heruntergeladen, SHA-256/ZIP-CRC und Berichte geprueft.
679 Dateien, 623 Textdateien, 135 JSON-Dateien, 33.971.213 dekodierte Textbytes.
Unabhaengig erneut geprueft: WT-Reporting-, ADC-, RPM-, Konfigurations- und ABI-Gates.
1.423 passende QGKI-Import-CRCs und 37 passende Module; komplette Exporttabelle
unveraendert. Boot.img und AK3 aus gepinnten Referenzen byteidentisch rekonstruiert.
Historische Teilfehler sind im Bericht spaeteren erfolgreichen Objektpruefungen
zugeordnet. Tiefe Binaer-/Boot-Pruefungen beziehen sich auf den finalen M28-R2.
Bericht: Reports/RUN43691305961_32_ARTEFAKTE.zip.

M29-REPARATUR
Genau zwei Aenderungen in bq2589x_charger_probe:
- devm_iio_device_alloc auf NULL pruefen, bevor iio_priv aufgerufen wird.
- Negative IIO-Registrierungsfehler unveraendert zurueckgeben, bevor weitere
  Ressourcen, GPIOs, Workqueues und IRQs aktiviert werden.
Die zwei Korrekturen sind aus der historischen BQ-Analyse abgeleitet. Der genaue
Diff liegt unter References/bq_probe_safety.patch. Alle anderen Treiberbytes und
beide BQ-Header bleiben identisch. Konfiguration und Kennung bleiben unveraendert:
5.4.274-qgki-g82179e362f33.

PRUEFUNGEN
156 native C-Assertions mit UBSan, Originalfehler reproduziert, vollstaendige
erfolgreiche Probe-Aufrufreihenfolgen und Argumente fuer BQ25890/SYV690 verglichen.
Speichermangel, IIO-Fehler und Deferred-Probe sowie bestehende spaetere Fehlerpfade
geprueft. Neuer Test mit GCC 11.4 und GCC 14; ARM64-Treiber mit Clang 12.0.5,
CFI/ThinLTO kompiliert. Kein vollstaendiger lokaler M29-Kernelbau.
M29 muss im naechsten CI-Lauf komplett gebaut werden. Alle vorherigen Build-,
ABI-, Konfigurations-, Release- und Boot-/AK3-Gates bleiben aktiv. Zusaetzlich
muessen BQ-Quellen/Objekt/CFI-Kommando sowie Probe, IIO-Callbacks und Initcall passen.

OFFENE ARBEIT
Weitere BQ-I2C-Fehlerpfade, spaetere Probe-Ressourcenaufraeumung und Shutdown-
Synchronisation sind noch zu pruefen. Danach folgen weitere offene Quellpunkte
und gezielte Tests am konkreten Geraet, einschliesslich Lade-/Suspend-/Boot-
und Wiederherstellungspruefung. Kein universeller GKI- oder Vollvergleich aller
historischen Quellabweichungen.
Device Pass: NEIN. Flashfreigabe: NEIN. Boot.img und AK3 bleiben NOFLASH.
