"""R20-R7 full source provenance and source ABI negative/positive cases."""
import importlib.util
import json
from pathlib import Path
import os
import shutil
import tempfile
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r20_r7_lpm_real_source',ROOT/'r20_r7_lpm_real_source.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

DRIVER='''#include <linux/kernel.h>
#include <linux/sched/stat.h>
// preserved Qualcomm consumer
#ifdef CONFIG_SCHED_WALT
static bool check_cpu_isolated(int cpu)
{
	return cpu_isolated(cpu);
}
#else
static bool check_cpu_isolated(int cpu)
{
	return false;
}

static inline uint64_t sched_lpm_disallowed_time(int cpu)
{
	return 0;
}
#endif
static bool qos_check(int cpu, struct lpm_cpu *pm_cpu)
{
	uint64_t bias_time = 0;
	bias_time = sched_lpm_disallowed_time(cpu);
	if (bias_time) {
		pm_cpu->bias = bias_time;
		return true;
	}
	return false;
}
'''
PROVIDER_TWO='''static DEFINE_PER_CPU(atomic64_t, busy_hyst_end_time) = ATOMIC64_INIT(0);
int sched_lpm_disallowed_time(int cpu, u64 *timeout)
{
	u64 now = sched_clock();
	u64 bias_end_time = atomic64_read(&per_cpu(busy_hyst_end_time, cpu));
	if (now < bias_end_time) {
		*timeout = bias_end_time - now;
		return 0;
	}
	return INT_MAX;
}
EXPORT_SYMBOL(sched_lpm_disallowed_time);
'''
PROVIDER_ONE='''static DEFINE_PER_CPU(atomic64_t, busy_hyst_end_time) = ATOMIC64_INIT(0);
u64 sched_lpm_disallowed_time(int cpu)
{
	u64 now = sched_clock();
	u64 bias_end_time = atomic64_read(&per_cpu(busy_hyst_end_time, cpu));
	if (now < bias_end_time)
		return bias_end_time - now;
	return 0;
}
EXPORT_SYMBOL_GPL(sched_lpm_disallowed_time);
'''

class R7Tests(unittest.TestCase):
    def setUp(self):
        self.pinner=mock.patch.object(m,'DRIVER_PIN_SHA256',m.shasum(DRIVER.encode()))
        self.pinner.start();self.addCleanup(self.pinner.stop)
        tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup)
        self.root=Path(tmp.name);self.snapshot=self.root/'snapshot';self.canonical=self.root/'kernel';self.project=self.root/'project';self.objects=self.root/'object-out';self.report=self.root/'report'
        for p in [self.snapshot,self.canonical,self.project,self.objects]:p.mkdir()
        self.config=self.root/'.config';self.config.write_text('CONFIG_SCHED_WALT=y\n')
        self.result=self.root/'R18_COMPILER_RESULT.json'
        self.nm=self.root/'llvm-nm'
        self.nm.write_text('#!/bin/sh\necho "000000000000a4b6 T sched_lpm_disallowed_time"\n')
        self.nm.chmod(0o755)
        self.mkfile(m.DRIVER,DRIVER,canonical=True)
        self.mkfile(m.INTERNAL,'#define WALT_INTERNAL 1\n')
        self.mkfile(m.STAT,'#ifndef STAT_H\n#define STAT_H\n#endif\n')
        self.mkfile(m.WALT_MAKE,'obj-$(CONFIG_SCHED_WALT) += sched_avg.o walt.o boost.o\n')
        self.mkfile(m.PROVIDERS[0],PROVIDER_TWO)
        self.objects.joinpath('kernel/sched/walt').mkdir(parents=True)
        self.rebuild()
    def mkfile(self,path,data,canonical=False):
        p=self.snapshot/path;p.parent.mkdir(parents=True,exist_ok=True)
        p.write_text(data)
        if canonical:
            q=self.canonical/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(data)
        return p
    def rebuild(self):
        obj=self.objects/'kernel/sched/walt/sched_avg.o'
        obj.write_bytes(b'ELF-arm64-sched-avg-mock')
        r={'object_success_count':15,'objects':{'kernel/sched/walt/sched_avg.o':{
            'compiled':True,'exit_code':0,'object_sha256':m.shasum(obj.read_bytes())}}}
        self.result.write_text(json.dumps(r))
    def check(self):return m.run(self.snapshot,self.canonical,self.project,self.config,self.result,self.report,self.objects,self.nm)
    def rejects(self,msg):
        original_canonical=(self.canonical/m.DRIVER).read_text()
        with self.assertRaisesRegex(m.ContractError,msg):self.check()
        if (self.report/'R20_R7_SOURCE_INSPECTION.json').is_file():
            j=json.loads((self.report/'R20_R7_SOURCE_INSPECTION.json').read_text())
            self.assertEqual(j['status'],'FAIL_CLOSED')
            self.assertFalse(j['flash_allowed'])
        self.assertEqual((self.canonical/m.DRIVER).read_text(),original_canonical)
    def test_01_two_argument_repair_no_public_walt_header(self):
        j=self.check();self.assertEqual(j['provider_abi']['kind'],'two-int-timeout');self.assertEqual(j['modified_paths'],[m.DRIVER])
        s=(self.snapshot/m.DRIVER).read_text();self.assertIn('extern int sched_lpm_disallowed_time(int cpu, u64 *timeout);',s)
        self.assertIn('if (!sched_lpm_disallowed_time(cpu, &bias_time))',s)
        self.assertIn('return INT_MAX;',s);self.assertIn('#include <linux/limits.h>',s)
        self.assertNotIn('linux/sched/walt.h',s)
        self.assertTrue((self.report/'R20_R7_SOURCE_DIFF.patch').is_file())
    def test_02_legacy_one_argument_preserved(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_ONE)
        j=self.check();self.assertEqual(j['provider_abi']['kind'],'one-u64')
        s=(self.snapshot/m.DRIVER).read_text();self.assertIn('extern u64 sched_lpm_disallowed_time(int cpu);',s)
        self.assertIn(m.OLD_CALL,s);self.assertIn(m.OLD_STUB,s)
    def test_03_only_driver_changed_for_two(self):
        hashes={p:m.shasum((self.snapshot/p).read_bytes()) for p in [m.INTERNAL,m.STAT,m.PROVIDERS[0],m.WALT_MAKE]}
        self.check()
        self.assertTrue(all(m.shasum((self.snapshot/p).read_bytes())==h for p,h in hashes.items()))
    def test_04_no_flash_flags(self):
        j=self.check()
        self.assertEqual((j['flash_allowed'],j['brene_changed'],j['bakasusu_nomount_changed'],j['full_build_proven']),(False,False,False,False))
    def test_05_real_abi_proof_has_sha(self):
        j=self.check();self.assertEqual(j['provider_abi']['object_sha256'],json.loads(self.result.read_text())['objects']['kernel/sched/walt/sched_avg.o']['object_sha256'])
    def test_06_genuine_internal_header_required(self):
        (self.snapshot/m.INTERNAL).unlink();self.rejects('MISSING_AUTHENTIC_SOURCE')
    def test_07_missing_public_walt_header_is_supported(self):
        self.assertFalse((self.snapshot/'include/linux/sched/walt.h').exists());self.check()
    def test_08_canonical_driver_stays(self):
        self.check();self.assertEqual((self.canonical/m.DRIVER).read_text(),DRIVER)
    def test_09_guard_rejects_external_symlink(self):
        f=self.snapshot/m.INTERNAL;f.unlink();f.symlink_to(self.canonical/m.DRIVER);self.rejects('UNSAFE_STAGE_INPUT')
    def test_10_guard_rejects_driver_symlink(self):
        f=self.snapshot/m.DRIVER;f.unlink();f.symlink_to(self.canonical/m.DRIVER);self.rejects('UNSAFE_STAGE_INPUT')
    def test_11_bad_config_fails(self):
        self.config.write_text('# CONFIG_SCHED_WALT is not set\n');self.rejects('CONFIG_WALT_ON_NOT_PROVEN')
    def test_12_bad_report_fails(self):
        d=json.loads(self.result.read_text());d['object_success_count']=14;self.result.write_text(json.dumps(d));self.rejects('R18_15_OBJECTS_NOT_PROVEN')
    def test_13_object_missing_in_report_fails(self):
        d=json.loads(self.result.read_text());d['objects']={};self.result.write_text(json.dumps(d));self.rejects('R18_PROVIDER_OBJECT_NOT_COMPILED')
    def test_14_object_sha_drift_fails(self):
        obj=self.objects/'kernel/sched/walt/sched_avg.o';obj.write_bytes(b'corrupted');self.rejects('REAL_ARM64_PROVIDER_OBJECT_SHA_DRIFT')
    def test_15_nm_undefined_symbol_fails(self):
        self.nm.write_text('#!/bin/sh\necho "                 U sched_lpm_disallowed_time"\n');self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_16_nm_missing_fails(self):
        self.nm.unlink();self.rejects('PINNED_LLVM_NM_MISSING')
    def test_17_nm_exit_error_fails(self):
        self.nm.write_text('#!/bin/sh\nexit 1\n');self.rejects('LLVM_NM_PROVIDER_OBJECT_FAILED')
    def test_18_no_function_fails(self):
        self.mkfile(m.PROVIDERS[0],'static void no_lpm(void){}\n');self.rejects('LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED')
    def test_19_duplicate_function_fails(self):
        self.mkfile(m.PROVIDERS[1],PROVIDER_TWO);self.rejects('LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED')
    def test_20_single_arg_int_wrong_abi_fails(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_ONE.replace('u64 sched_lpm_disallowed_time','int sched_lpm_disallowed_time'))
        self.rejects('LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED')
    def test_21_two_args_u64_wrong_abi_fails(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_TWO.replace('int sched_lpm_disallowed_time','u64 sched_lpm_disallowed_time'))
        self.rejects('LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED')
    def test_22_no_busy_hyst_fails(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_TWO.replace('bias_end_time','not_bias_time'))
        self.rejects('LPM_NOT_PROVEN_SCHEDULER_BUSY_HYST_BACKEND')
    def test_23_no_timeout_assignment_fails(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_TWO.replace('*timeout =','/* *timeout = */ unused ='))
        self.rejects('TWO_ARG_RETURN_SEMANTICS_UNPROVEN')
    def test_24_not_in_kbuild_makefile_fails(self):
        self.mkfile(m.WALT_MAKE,'obj-y += walt.o\n');self.rejects('LPM_PROVIDER_OBJECT_NOT_IN_WALT_MAKEFILE')
    def test_25_rejects_conflicting_header(self):
        self.mkfile(m.STAT,'extern u64 sched_lpm_disallowed_time(int cpu);\n');self.rejects('CONFLICTING_WALT_DECLARATION')
    def test_26_rejects_driver_pin_drift(self):
        self.mkfile(m.DRIVER,DRIVER+'extra\n');self.rejects('CANONICAL_DRIVER_DRIFT')
    def test_27_rejects_source_preimage_even_if_canonical_matches(self):
        self.mkfile(m.DRIVER,DRIVER+'extra\n',canonical=True);self.rejects('DRIVER_PINNED_PREIMAGE_SHA_DRIFT')
    def test_28_rejects_canonical_mutation(self):
        (self.canonical/m.DRIVER).write_text(DRIVER+'garbled');self.rejects('CANONICAL_DRIVER_DRIFT')
    def test_29_rejects_same_snapshot_and_canonical(self):
        self.snapshot=self.canonical
        with self.assertRaisesRegex(m.ContractError,'CANONICAL_OVERLAP'):self.check()
    def test_30_rejects_project_overlap(self):
        self.project=self.root
        with self.assertRaisesRegex(m.ContractError,'PROJECT_WRITE_PROHIBITED'):self.check()
    def test_31_rejects_report_inside_snapshot(self):
        self.report=self.snapshot/'diagnostics'
        with self.assertRaisesRegex(m.ContractError,'UNSAFE_DIAGNOSTIC_OUTPUT'):self.check()
    def test_32_rejects_existing_report(self):
        self.report.mkdir();self.rejects('UNSAFE_DIAGNOSTIC_OUTPUT')
    def test_33_rejects_extra_call_reference(self):
        self.mkfile(m.DRIVER,DRIVER+'/* sched_lpm_disallowed_time( */\n',canonical=True)
        with mock.patch.object(m,'DRIVER_PIN_SHA256',m.shasum((DRIVER+'/* sched_lpm_disallowed_time( */\n').encode())):
            self.rejects('LPM_SYMBOL_SCOPE_DRIFT')
    def test_34_rejects_broken_legacy_stub(self):
        modified=DRIVER.replace(m.OLD_STUB,'')
        self.mkfile(m.DRIVER,modified,canonical=True)
        with mock.patch.object(m,'DRIVER_PIN_SHA256',m.shasum(modified.encode())):
            self.rejects('ORIGINAL_NONWALT_STUB_DRIFT')
    def test_35_proves_gitblob_formula(self):
        self.assertEqual(m.gitblob(b''),'e69de29bb2d1d6434b8b29ae775ad8c2e48c5391')
    def test_36_rejects_missing_driver(self):
        (self.snapshot/m.DRIVER).unlink();self.rejects('MISSING_AUTHENTIC_SOURCE')
    def test_37_rejects_non_utf8_provider(self):
        (self.snapshot/m.PROVIDERS[0]).write_bytes(b'\xff')
        with self.assertRaises(UnicodeError):self.check()
        self.assertTrue((self.report/'R20_R7_SOURCE_INSPECTION.json').exists())
    def test_38_only_known_walt_provider_candidates(self):
        self.mkfile('kernel/sched/walt/unrelated.c',PROVIDER_TWO)
        self.mkfile(m.PROVIDERS[0],'no real symbol')
        self.rejects('LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED')
    def test_39_onearg_internal_header_matching_is_allowed(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_ONE)
        self.mkfile(m.INTERNAL,'extern u64 sched_lpm_disallowed_time(int cpu);\n')
        self.check()
    def test_40_twoarg_internal_header_matching_is_allowed(self):
        self.mkfile(m.INTERNAL,'extern int sched_lpm_disallowed_time(int cpu, u64 *timeout);\n')
        self.check()

    def test_41_actual_llvm_lto_sentinel_T_accepted(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- T sched_lpm_disallowed_time"\n')
        evidence=self.check()['provider_abi']['llvm_nm_symbol']
        self.assertTrue(evidence['llvm_bitcode_address'])
        self.assertEqual(evidence['type'],'T')
        self.assertTrue((self.report/'R20_R7_LLVM_NM_PROVIDER.txt').is_file())
        self.assertIn('---------------- T sched_lpm_disallowed_time',
                      (self.report/'R20_R7_LLVM_NM_PROVIDER.txt').read_text())
    def test_42_actual_llvm_lto_sentinel_U_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- U sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_43_local_lower_t_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- t sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_44_weak_global_W_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- W sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_45_global_data_D_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- D sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_46_wrong_sentinel_length_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "--------------- T sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_47_duplicate_T_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- T sched_lpm_disallowed_time"\necho "0000000000000010 T sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_48_unrelated_global_symbols_do_not_grant_permission(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- T some_other_function"\necho "---------------- U sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_49_normal_elf_hex_symbol_accepted(self):
        self.assertFalse(self.check()['provider_abi']['llvm_nm_symbol']['llvm_bitcode_address'])
    def test_50_empty_nm_response_rejected(self):
        self.nm.write_text('#!/bin/sh\nexit 0\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_51_missing_address_rejected(self):
        self.nm.write_text('#!/bin/sh\necho "T sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    def test_52_lto_sentinel_one_argument_preserved(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_ONE)
        self.nm.write_text('#!/bin/sh\necho "---------------- T sched_lpm_disallowed_time"\n')
        evidence=self.check()['provider_abi']
        self.assertEqual(evidence['kind'],'one-u64')
        self.assertTrue(evidence['llvm_nm_symbol']['llvm_bitcode_address'])
        self.assertIn(m.OLD_CALL,(self.snapshot/m.DRIVER).read_text())
    def test_53_nm_global_text_valid_with_unrelated_extra_symbols(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- T some_other_function"\necho "---------------- T sched_lpm_disallowed_time"\necho "---------------- U not_our_api"\n')
        self.assertTrue(self.check()['provider_abi']['llvm_nm_symbol']['llvm_bitcode_address'])
    def test_54_nm_log_written_on_missing_provider_symbol(self):
        self.nm.write_text('#!/bin/sh\necho "---------------- U sched_lpm_disallowed_time"\n')
        self.rejects('REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
        self.assertIn('---------------- U sched_lpm_disallowed_time',
                      (self.report/'R20_R7_LLVM_NM_PROVIDER.txt').read_text())

    def test_55_actual_reconstructed_veux_driver_sha256_pin(self):
        self.assertEqual(m.AUTHENTIC_P3_DRIVER_SHA256,
                         '6805651af0a60905ce04356df3a538be15e94b6c8599a1d35e414d0a50b67094')
    def test_56_ancestor_blob_is_documented_not_used_as_actual_driver_pin(self):
        self.assertEqual(m.REFERENCE_POSITRON_BLOB,'ef589378adf49fc78cf4adc2ac90ba7b9091d059')
        self.assertNotEqual(m.REFERENCE_POSITRON_BLOB,m.DRIVER_PIN_SHA256)
    def test_57_wrong_driver_pin_rejected_even_when_canonical_equals_snapshot(self):
        with mock.patch.object(m,'DRIVER_PIN_SHA256','0'*64):
            self.rejects('DRIVER_PINNED_PREIMAGE_SHA_DRIFT')
        j=json.loads((self.report/'R20_R7_SOURCE_INSPECTION.json').read_text())
        self.assertEqual(j['driver_actual_sha256'],m.shasum(DRIVER.encode()))
    def test_58_exact_hash_is_logged_to_diagnostic(self):
        self.check()
        j=json.loads((self.report/'R20_R7_SOURCE_INSPECTION.json').read_text())
        self.assertEqual(j['driver_expected_sha256'],m.shasum(DRIVER.encode()))
        self.assertEqual(j['driver_actual_sha256'],m.shasum(DRIVER.encode()))
    def test_59_one_argument_client_keeps_original_call_and_nonwalt_fallback(self):
        self.mkfile(m.PROVIDERS[0],PROVIDER_ONE)
        self.nm.write_text('#!/bin/sh\necho "---------------- T sched_lpm_disallowed_time"\n')
        j=self.check();self.assertEqual(j['provider_abi']['kind'],'one-u64')
        s=(self.snapshot/m.DRIVER).read_text()
        self.assertIn('extern u64 sched_lpm_disallowed_time(int cpu);',s)
        self.assertIn(m.OLD_STUB,s)
        self.assertIn(m.OLD_CALL,s)
        self.assertNotIn('extern int sched_lpm_disallowed_time(int cpu, u64 *timeout);',s)
    def test_60_wrong_original_stub_fails_even_if_hash_repinned(self):
        bad=DRIVER.replace('return 0;\n}', 'return 99;\n}',1)
        self.mkfile(m.DRIVER,bad,canonical=True)
        with mock.patch.object(m,'DRIVER_PIN_SHA256',m.shasum(bad.encode())):
            self.rejects('ORIGINAL_NONWALT_STUB_DRIFT')

if __name__=='__main__':unittest.main()
