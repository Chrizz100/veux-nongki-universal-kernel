VEUX 5.4.274 R6 + NoMount 2.1.1: R4 one-change SELinux status experimental BUILD

PARTIAL PORT: this does NOT update the three SUSFS 2.3.0 kernel core files,
NOR port all SUSFS upstream GKI-5.10 changes; official BakaSU SUSFS blocker
is NOT removed. It compiles the R3-reviewed single SELinux status guard,
original upstream BakaSU d726 + one explicitly documented edit.

Confirmed baselines: R2 full kernel build 38965488864 (green), R3 source-only
39004860053 (green). These original audit artifacts and the exact R2 source
bundle are cryptographically pinned. All staging occurs outside GitHub main.

Upload this one ZIP unchanged to GitHub repository ROOT. Upload separately the
VEUX_R6_SUSFS_SELINUX54_R4_EXPERIMENTAL_BUILD.yml to .github/workflows/.
Run the R4 workflow with enable_build=true for the isolated experiment.
No device test, no flash approval, no official full SUSFS upstream upgrade.
