#!/usr/bin/env python3
"""Offline negative regression tests; never builds/flashes kernel."""
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import veux_r6_susfs_selinux54_build_r4 as r4
import veux_r6_susfs_selinux54_port_r3 as r3

HERE=Path(__file__).resolve().parents[1]
ARTIFACT=HERE/'evidence/R3_GITHUB_AUDIT_39004860053.zip'

def source_images():
    with zipfile.ZipFile(ARTIFACT) as z:
        return (z.read('report/SUSFS_SELININUX54_R3/SELINUX_D726_ORIGINAL.c') if False else z.read('report/SUSFS_SELINUX54_R3/SELINUX_D726_ORIGINAL.c'),
                z.read('report/SUSFS_SELINUX54_R3/SELINUX_5_4_PORT_R3_STAGED.c'))

class R4Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.old,cls.new=source_images()

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)

    def fixture(self):
        root=self.root
        work=root/'builds/5.4.274'
        src=work/'source/kernel'
        dest=src/r4.STATUS_SOURCE
        dest.parent.mkdir(parents=True)
        dest.write_bytes(self.old)
        host=src/'security/selinux'
        host.mkdir(parents=True)
        (host/'hooks.c').write_bytes(b'FIXTURE_HOOKS_C\n')
        (host/'selinuxfs.c').write_bytes(b'FIXTURE_SELINUXFS_C\n')
        previous=(r3.KERNEL_HOOK_SHA,r3.KERNEL_SELINUXFS_SHA)
        r3.KERNEL_HOOK_SHA=r4.sha((host/'hooks.c').read_bytes())
        r3.KERNEL_SELINUXFS_SHA=r4.sha((host/'selinuxfs.c').read_bytes())
        self.addCleanup(setattr,r3,'KERNEL_HOOK_SHA',previous[0])
        self.addCleanup(setattr,r3,'KERNEL_SELINUXFS_SHA',previous[1])
        (root/'bundle').mkdir()
        (root/'bundle/targets.json').write_text(json.dumps({'components': {
            'nomount':{'commit':r3.NOMOUNT_R2},
            'resukisu':{'commit':r3.BAKASU_PIN},
            'susfs':{'commit':r3.SUSFS_R6}}}))
        (work/'BAKASU-OFFICIAL-D726-R6.json').write_text(json.dumps({
            'source_matches_official_bakasu_d726_byte_for_byte':True,
            'after_sha256':r3.BAKASU_OFFICIAL_HOOK_SHA,
            'source_provenance':{'upstream_commit':r3.BAKASU_EFFECTIVE_SOURCE}}))
        return src,root/'bundle',work,dest

    def fake_compile_evidence(self,src,work):
        self.assertEqual((src/r4.STATUS_SOURCE).read_bytes(),self.new)
        f=work/r4.BUILD_REL
        f.mkdir(parents=True)
        (f/'selinux_hide.o').write_bytes(b'ARM64 OBJECT')
        (f/'.selinux_hide.o.cmd').write_text('clang -flto=thin -fstack-protector-strong -c drivers/kernelsu/feature/selinux_hide.o\n')
        (work/'compile.log').write_text('  CC      drivers/kernelsu/feature/selinux_hide.o\n')
        cfg=work/'config-reports/actual-build.config'
        cfg.parent.mkdir(parents=True)
        cfg.write_text('\n'.join(('CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
                                   'CONFIG_STACKPROTECTOR_STRONG=y','CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y'))+'\n')
        return f

    def test_01_r3_original_sha(self):
        self.assertEqual(r4.sha(self.old),r3.BAKASU_OFFICIAL_HOOK_SHA)
    def test_02_r3_reproduced_exactly(self):
        self.assertEqual(r3.transform_status_guard(self.old)[0],self.new)
    def test_03_candidate_postimage_hash(self):
        self.assertEqual(r4.sha(self.new),r4.R3_POSTIMAGE)
    def test_04_candidate_git_blob(self):
        self.assertEqual(r3.git_blob(self.new),r4.R3_POST_BLOB)
    def test_05_candidate_has_only_one_line(self):
        a,b=self.old.decode().splitlines(),self.new.decode().splitlines()
        differing=[(x,y) for x,y in zip(a,b) if x!=y]
        self.assertEqual(len(differing),1)
        self.assertIn('ksu_selinux_hide_enabled',differing[0][0])
        self.assertIn('ksu_selinux_hide_running',differing[0][1])
    def test_06_worker_inject_exact(self):
        f=self.root/'worker.py'
        f.write_text('def run():\n'
          '        bakasu_official_r6 = apply_official_source(None)\n'
          +r4.SOURCE_ANCHOR+r4.COMPILE_ANCHOR+
          "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        proof=r4.inject_verified_r4(f)
        s=f.read_text()
        self.assertEqual(s.count('selinux54_r4_source = stage_r4('),1)
        self.assertEqual(s.count('result[\'selinux54_r4\']'),1)
        self.assertTrue(proof['R6_ORIGINAL_WORKER_UNCHANGED'])
    def test_07_worker_double_inject_fails(self):
        f=self.root/'worker.py'
        f.write_text('def run():\n'
          '        bakasu_official_r6 = apply_official_source(None)\n'
          +r4.SOURCE_ANCHOR+r4.COMPILE_ANCHOR+
          "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        r4.inject_verified_r4(f)
        with self.assertRaises(r4.BuildStop):r4.inject_verified_r4(f)
    def test_08_worker_missing_official_gate_fails(self):
        f=self.root/'worker.py'
        f.write_text('def run():\n'+r4.SOURCE_ANCHOR+r4.COMPILE_ANCHOR)
        with self.assertRaises(r4.BuildStop):r4.inject_verified_r4(f)
    def test_09_worker_duplicate_source_anchor_fails(self):
        f=self.root/'worker.py'
        f.write_text('def run():\n'
          '        bakasu_official_r6 = apply_official_source(None)\n'
          +r4.SOURCE_ANCHOR*2+r4.COMPILE_ANCHOR+
          "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        with self.assertRaises(r4.BuildStop):r4.inject_verified_r4(f)
    def test_10_stage_exact_scoped(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):
            p=r4.stage_r4(src,bundle,work)
        self.assertEqual(file.read_bytes(),self.new)
        self.assertEqual(p['exact_edits'],1)
        self.assertTrue((self.root/'report/SELINUX54_R4_STAGE.json').is_file())
    def test_11_stage_refuses_wrong_bakasu_pin(self):
        src,bundle,work,file=self.fixture()
        f=bundle/'targets.json'; d=json.loads(f.read_text());d['components']['resukisu']['commit']='0'*40;f.write_text(json.dumps(d))
        with self.assertRaises(r4.BuildStop),patch.object(r3,'verify_host',return_value={}):r4.stage_r4(src,bundle,work)
        self.assertEqual(file.read_bytes(),self.old)
    def test_12_stage_refuses_mangled_upstream(self):
        src,bundle,work,file=self.fixture();file.write_bytes(self.old+b'X')
        with self.assertRaises(r3.PortBlocked),patch.object(r3,'verify_host',return_value={}):r4.stage_r4(src,bundle,work)
    def test_13_stage_refuses_missing_official_proof(self):
        src,bundle,work,file=self.fixture();(work/'BAKASU-OFFICIAL-D726-R6.json').unlink()
        with self.assertRaises(FileNotFoundError):r4.stage_r4(src,bundle,work)
    def test_14_stage_refuses_prior_stage(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):r4.stage_r4(src,bundle,work)
        with self.assertRaises(r3.PortBlocked),patch.object(r3,'verify_host',return_value={}):r4.stage_r4(src,bundle,work)
    def test_15_stage_refuses_native_host_problem(self):
        src,bundle,work,file=self.fixture()
        with self.assertRaises(r3.PortBlocked),patch.object(r3,'verify_host',side_effect=r3.PortBlocked('HOST_DRIFT')):r4.stage_r4(src,bundle,work)
        self.assertEqual(file.read_bytes(),self.old)
    def test_16_compiled_evidence_positive(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}): stage=r4.stage_r4(src,bundle,work)
        self.fake_compile_evidence(src,work)
        p=r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
        self.assertEqual(p['status'],'COMPILED_R3_REVIEWED_SELINUX_STATUS_PORT')
    def test_17_compile_reject_unprotected(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        path=self.fake_compile_evidence(src,work)/'.selinux_hide.o.cmd'
        path.write_text(path.read_text().replace('-fstack-protector-strong',''))
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_18_compile_reject_missing_thinlto(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        path=self.fake_compile_evidence(src,work)/'.selinux_hide.o.cmd'
        path.write_text(path.read_text().replace('-flto=thin',''))
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_19_compile_reject_mangled_source(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        self.fake_compile_evidence(src,work)
        file.write_bytes(self.new+b'X')
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_20_compile_reject_missing_object(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        f=self.fake_compile_evidence(src,work)
        (f/'selinux_hide.o').unlink()
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_21_compile_reject_wrong_kernel(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        self.fake_compile_evidence(src,work)
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':'5.4.300'})
    def test_22_compile_reject_missing_config(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        self.fake_compile_evidence(src,work)
        f=work/'config-reports/actual-build.config';f.write_text(f.read_text().replace('CONFIG_CFI_CLANG=y',''))
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_23_compile_reject_missing_log_line(self):
        src,bundle,work,file=self.fixture()
        with patch.object(r3,'verify_host',return_value={}):stage=r4.stage_r4(src,bundle,work)
        self.fake_compile_evidence(src,work)
        (work/'compile.log').write_text('  CC      drivers/kernelsu/feature/sucompat.o\n')
        with self.assertRaises(r4.BuildStop):r4.verify_compiled_r4(src,work,stage,{'kernel':r4.TARGET_KERNEL})
    def test_24_build_requires_green_r3(self):
        root=self.root
        (root/'report/SUSFS_SELINUX54_R3').mkdir(parents=True)
        (root/'report/SUSFS_SELINUX54_R3/RESULT.json').write_text('{}')
        (root/'repo/.git').mkdir(parents=True)
        with self.assertRaises(r4.BuildStop):r4.build(root/'repo',root,4)
    def test_25_source_artifact_integrity(self):
        import hashlib
        self.assertEqual(hashlib.sha256(ARTIFACT.read_bytes()).hexdigest(),
              '70603805a9b0a7f374df245166441615d28d0a2f5328d7c29edf38be78868850')
    def test_26_bundle_contains_positive_status(self):
        with zipfile.ZipFile(ARTIFACT) as z:
            j=json.loads(z.read('report/SUSFS_SELINUX54_R3/RESULT.json'))
        self.assertEqual(j['status'],'TARGETED_5_4_SELINUX_SOURCE_STAGED_NOT_COMPILED')
        self.assertFalse(j['full_upstream_susfs_integration_applied'])
    def test_27_old_new_exact_sized(self):
        self.assertEqual(len(self.old),len(self.new))
    def test_29_worker_r2_r4_chain_has_exact_gate_order(self):
        f=self.root/'worker.py'
        f.write_text('def worker():\n'
          '        bakasu_official_r6 = apply_official_source(None)\n'
          +r4.SOURCE_ANCHOR+r4.COMPILE_ANCHOR+
          "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        r4.inject_verified_r4(f)
        r4.r2.inject_stack_gates(f)
        body=f.read_text()
        self.assertEqual(body.count('selinux54_r4_source = stage_r4'),1)
        self.assertEqual(body.count('nomount_r2_source = stage_stack_protection'),1)
        self.assertLess(body.index('selinux54_r4_source = stage_r4'),
                        body.index('nomount_r2_source = stage_stack_protection'))
        self.assertLess(body.index('nomount_r2_source = stage_stack_protection'),
                        body.index('overlay_hash = r.save_overlay'))
        self.assertLess(body.index('image, result = compat.compile_kernel'),
                        body.index('verify_compiled_stack'))
        self.assertLess(body.index('verify_compiled_stack'),body.index('verify_compiled_r4'))
    def test_30_build_reject_bad_existing_pin(self):
        # Even before loading a real upstream, the R3 source gate rejects
        # an unapproved source-identity claim.
        root=self.root
        (root/'report/SUSFS_SELINUX54_R3').mkdir(parents=True)
        (root/'report/SUSFS_SELINUX54_R3/RESULT.json').write_text(json.dumps({
            'status':'TARGETED_5_4_SELINUX_SOURCE_STAGED_NOT_COMPILED',
            'bakasu_status_guard':{'after_sha256':'0'*64},
            'reference_success_run':r4.R2_RUN,
            'full_upstream_susfs_integration_applied':False}))
        (root/'repo/.git').mkdir(parents=True)
        with self.assertRaises(r4.BuildStop):r4.build(root/'repo',root,4)

    def test_28_no_fake_version(self):
        self.assertNotIn('KSU_VERSION :=',r4.__doc__ or '')

if __name__=='__main__':unittest.main(verbosity=2)
