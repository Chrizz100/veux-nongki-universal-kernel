#!/usr/bin/env python3
"""Pure unit/negative tests for 5.4 R3: no kernel compilation claimed."""
import hashlib
import unittest
from pathlib import Path
import tempfile
from unittest.mock import patch

import veux_r6_susfs_selinux54_port_r3 as port

SAMPLE='''/* pinned test fixture not the real kernel */
__maybe_static bool ksu_selinux_hide_enabled;
__maybe_static bool ksu_selinux_hide_running;
static ssize_t my_write_context(struct file *file, char *buf, size_t size) {
  PROCESS__DYNTRANSITION;
  PROCESS__SETCURRENT;
  PROCESS__PTRACE;
  ksu_security_context_to_sid;
  backup_policydb;
  return 0;
}
static ssize_t my_write_access(struct file *file, char *buf, size_t size) {
  return 0;
}
static int my_sel_open_handle_status(struct inode *inode, struct file *filp)
{
  if (likely(ksu_get_uid_t(current_uid()) >= 10000 && ksu_selinux_hide_enabled)) {
     filp->private_data = fake_status;
  }
  return orig_sel_open_handle_status(inode, filp);
}
static void hook_selinux_status_open() { }
'''.encode()


class PortCases(unittest.TestCase):
    def transform(self,s=SAMPLE,**kw):
        return port.transform_status_guard(s,expected_sha=hashlib.sha256(s).hexdigest(),
                                           expected_blob=None,**kw)

    def test_scope_only_one_semantic_edit(self):
        new, info=self.transform()
        self.assertEqual(info['edits'],1)
        self.assertEqual(new.replace(port.AFTER.encode(),port.BEFORE.encode()),SAMPLE)
        self.assertIn(port.AFTER.encode(),new)
        self.assertFalse(info['compile_pass'])
        self.assertFalse(info['device_runtime_pass'])

    def test_old_guard_must_exist(self):
        with self.assertRaisesRegex(port.PortBlocked,'GUARD_ALREADY_CHANGED'):
            self.transform(SAMPLE.replace(port.BEFORE.encode(),port.AFTER.encode()))

    def test_original_byte_hash_is_pinned(self):
        with self.assertRaisesRegex(port.PortBlocked,'PREIMAGE_DRIFT'):
            port.transform_status_guard(SAMPLE,expected_sha='0'*64,expected_blob=None)

    def test_actual_official_blob_cannot_be_assumed_for_fixture(self):
        with self.assertRaisesRegex(port.PortBlocked,'GIT_BLOB_MISMATCH'):
            port.transform_status_guard(SAMPLE,expected_sha=hashlib.sha256(SAMPLE).hexdigest())

    def test_reject_duplicate_guard(self):
        text=SAMPLE.replace(port.BEFORE.encode(),(port.BEFORE+'\n  '+port.BEFORE).encode())
        with self.assertRaisesRegex(port.PortBlocked,'GUARD_ALREADY_CHANGED'):
            self.transform(text)

    def test_reject_missing_status_function(self):
        with self.assertRaisesRegex(port.PortBlocked,'STATUS_FUNCTION_MISSING'):
            self.transform(SAMPLE.replace(port.FUNCTION_START.encode(),b'static int renamed_status(void)'))

    def test_reject_unknown_function_boundary(self):
        with self.assertRaisesRegex(port.PortBlocked,'STATUS_FUNCTION_END_UNKNOWN'):
            self.transform(SAMPLE.replace(b'static void hook_selinux_status_open()',b'static void custom_open()'))

    def test_reject_enabled_state_removed(self):
        with self.assertRaisesRegex(port.PortBlocked,'BakaSU_HIDE_STATE_DECLARATION_MISSING'):
            self.transform(SAMPLE.replace(b'__maybe_static bool ksu_selinux_hide_enabled;\n__maybe_static bool ksu_selinux_hide_running;',
                    b'__maybe_static bool ksu_selinux_hide_running;'))

    def test_reject_extra_port_target_guard(self):
        s=SAMPLE + ('\n'+port.BEFORE+'\n').encode()
        with self.assertRaisesRegex(port.PortBlocked,'STATUS_GUARD_OUTSIDE_SCOPE'):
            self.transform(s)

    def test_modified_lsm_cannot_pass_host_gate(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'security/selinux';p.mkdir(parents=True)
            (p/'hooks.c').write_text('LSM_HOOK_INIT(setprocattr, my_setprocattr)')
            (p/'selinuxfs.c').write_text('sel_open_handle_status')
            with patch.dict(port.HOST_FILES,{ 'security/selinux/hooks.c':port.sha((p/'hooks.c').read_bytes()),
                         'security/selinux/selinuxfs.c':port.sha((p/'selinuxfs.c').read_bytes()) },clear=True):
                with self.assertRaisesRegex(port.PortBlocked,'UNEXPECTED_NATIVE_WRAPPER'):
                    port.verify_host(root)

    def test_native_code_must_match_reference_sha(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'security/selinux';p.mkdir(parents=True)
            (p/'hooks.c').write_text('LSM_HOOK_INIT(setprocattr, selinux_setprocattr)')
            (p/'selinuxfs.c').write_text('sel_open_handle_status sel_write_context sel_write_access')
            with self.assertRaisesRegex(port.PortBlocked,'PROVEN_HOST_SHA_DRIFT'):
                port.verify_host(root)

    def test_reject_native_running_flag(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'security/selinux';p.mkdir(parents=True)
            (p/'hooks.c').write_text('LSM_HOOK_INIT(setprocattr, selinux_setprocattr)\nksu_selinux_hide_running;')
            (p/'selinuxfs.c').write_text('sel_open_handle_status sel_write_context sel_write_access')
            with patch.dict(port.HOST_FILES,{ 'security/selinux/hooks.c':port.sha((p/'hooks.c').read_bytes()),
                         'security/selinux/selinuxfs.c':port.sha((p/'selinuxfs.c').read_bytes()) },clear=True):
                with self.assertRaisesRegex(port.PortBlocked,'NATIVE_SUSFS_MANUAL_HOOK_ALREADY_PRESENT'):
                    port.verify_host(root)

    def test_path_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'real').write_text('x');(root/'link').symlink_to(root/'real')
            with self.assertRaisesRegex(port.PortBlocked,'INVALID_OR_LINKED_FILE'):
                port.safe_path(root,'link')

    def test_path_rejects_traversal(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaisesRegex(port.PortBlocked,'UNSAFE_RELATIVE_PATH'):
                port.safe_path(Path(td),'../../etc/passwd')

    def test_report_has_no_release_claims(self):
        _,d=self.transform()
        self.assertFalse(d['device_runtime_pass'])
        self.assertFalse(d['compile_pass'])
        self.assertTrue(d['legacy_security_checks_unchanged'])

    def test_r2_pin_unchanged(self):
        self.assertEqual(port.KERNEL,'5.4.274')
        self.assertEqual(port.NOMOUNT_R2,'7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3')
        self.assertEqual(port.SUSFS_R6,'5326e21a7eb232f9e21debdd5164e99bee3d1e2f')
        self.assertEqual(port.SUSFS_CANDIDATE,'fec037cb8a0de768dd97d16fa65737cb6121b870')

    def test_symbol_pins_exact(self):
        self.assertEqual(len(port.NEW_SUSFS_BLOBS),3)
        self.assertEqual(len(port.CHANGED_PATCH_BLOBS),2)
        self.assertTrue(all(len(x)==40 for x in port.NEW_SUSFS_BLOBS.values()))


if __name__=='__main__':
    unittest.main(verbosity=2)
