#!/usr/bin/env python3
"""R4 experimental VEUX 5.4.274 BakaSU SELinux status-port build.

Reuses exact successful R6/NoMount-R2 worker. Applies only the R3-audited
one-line SELinux status guard after the proven official d726 source stage.
Never edits Github checkout, vendor SUSFS donor, or upstream BakaSU blocker.
Never claims runtime, full SUSFS update, or flash permission.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys

import veux_r6_nomount211_build_r2 as r2
import veux_r6_susfs_selinux54_port_r3 as r3

TARGET_KERNEL='5.4.274'
R2_RUN=38965488864
R3_RUN=39004860053
KNOWN_R2_IMAGE='2de30e4990ac789d6176f0416b197904fb45365e05323567e88c51a2f576a3ef'
R3_POSTIMAGE='3cb110f10df3f552620dbd7592d15270b8c45a0179c2bc0e34210ad6120bf0d6'
R3_POST_BLOB='d4b19f7989167f85f2f2c0373fef366bee762e01'
STATUS_SOURCE='KernelSU/kernel/feature/selinux_hide.c'
SOURCE_ANCHOR=r2.OVERLAY_ANCHOR
COMPILE_ANCHOR=r2.COMPILE_ANCHOR
BUILD_REL='build/drivers/kernelsu/feature'

class BuildStop(RuntimeError):
    pass

def need(test: bool, code: str):
    if not test:
        raise BuildStop(code)

def sha(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()

def safe_report(root: Path, relative: str, data: dict) -> Path:
    path=root/'report'/relative
    need(not path.exists() and not path.is_symlink(), 'AUDIT_ALREADY_EXISTS:'+relative)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    return path

def stage_r4(src: Path, bundle: Path, work: Path) -> dict:
    """Apply the R3-reviewed single source edit to the disposable build kernel.

    Called after official R6 d726 source restoration, and before the R2 stack
    hardening/overlay. Proves exact source and official SELinux file identities.
    """
    src=src.resolve(strict=True)
    bundle=bundle.resolve(strict=True)
    work=work.resolve(strict=True)
    need(src.name=='kernel' and work.name==TARGET_KERNEL and
         work.parent.name=='builds' and not src.is_relative_to(bundle),
         'R4_DISPOSABLE_WORKER_SCOPE_CHANGED')
    root=work.parent.parent
    need(src.is_relative_to(work) and bundle==root/'bundle',
         'R4_UNEXPECTED_DISPOSABLE_SOURCE')
    targets=json.loads((bundle/'targets.json').read_text())['components']
    need(targets['nomount']['commit']==r3.NOMOUNT_R2 and
         targets['resukisu']['commit']==r3.BAKASU_PIN and
         targets['susfs']['commit']==r3.SUSFS_R6,
         'R4_FROZEN_COMPONENTS_CHANGED')
    # Official R6 function was installed earlier in this exact temporary worker.
    official=json.loads((work/'BAKASU-OFFICIAL-D726-R6.json').read_text())
    need(official.get('source_matches_official_bakasu_d726_byte_for_byte') is True and
         official.get('after_sha256')==r3.BAKASU_OFFICIAL_HOOK_SHA and
         official.get('source_provenance',{}).get('upstream_commit')==r3.BAKASU_EFFECTIVE_SOURCE,
         'R4_R6_OFFICIAL_SOURCE_IDENTITY_ABSENT')
    r3.verify_host(src)
    file=r3.safe_path(src,STATUS_SOURCE)
    previous=file.read_bytes()
    candidate,proof=r3.transform_status_guard(previous)
    need(sha(candidate)==R3_POSTIMAGE and r3.git_blob(candidate)==R3_POST_BLOB,
         'R4_R3_REVIEWED_POSTIMAGE_MISMATCH')
    need(file.read_bytes()==previous,'R4_SOURCE_CONCURRENT_DRIFT')
    file.write_bytes(candidate)
    need(file.read_bytes()==candidate,'R4_DISPOSABLE_PORT_WRITE_FAILED')
    need(sha(r3.safe_path(src,'security/selinux/hooks.c').read_bytes())==r3.KERNEL_HOOK_SHA and
         sha(r3.safe_path(src,'security/selinux/selinuxfs.c').read_bytes())==r3.KERNEL_SELINUXFS_SHA,
         'R4_NATIVE_54_SELINUX_MUTATED')
    staged={
        'status':'STAGED_AFTER_EXACT_OFFICIAL_R6_AND_BEFORE_COMPILE',
        'kernel':TARGET_KERNEL,'official_baseline_git_blob':proof['before_git_blob'],
        'official_baseline_sha256':proof['before_sha256'],
        'compiled_candidate_git_blob':proof['after_git_blob'],
        'compiled_candidate_sha256':proof['after_sha256'],
        'changed_path':STATUS_SOURCE,'exact_edits':1,
        'r6_original_official_code_changed_by_explicit_reviewed_patch':True,
        'susfs_pin_unchanged':True,'nomount_r2_pin_unchanged':True,
        'full_susfs_port':False,'runtime_verified':False,'flash_release':False,
    }
    safe_report(root,'SELINUX54_R4_STAGE.json',staged)
    return staged

def verify_compiled_r4(src: Path, work: Path, staged: dict, result: dict) -> dict:
    """Prove that the R3 exact source is the source for compiled BakaSU object."""
    work=work.resolve(strict=True)
    src=src.resolve(strict=True)
    need(src.is_relative_to(work) and work.name==TARGET_KERNEL,'R4_BUILD_SOURCE_NOT_DISPOSABLE')
    file=r3.safe_path(src,STATUS_SOURCE)
    need(sha(file.read_bytes())==R3_POSTIMAGE and
         r3.git_blob(file.read_bytes())==R3_POST_BLOB,
         'R4_COMPILED_SOURCE_POSTIMAGE_CHANGED')
    need(staged.get('compiled_candidate_sha256')==R3_POSTIMAGE and
         staged.get('compiled_candidate_git_blob')==R3_POST_BLOB and
         staged.get('exact_edits')==1,
         'R4_STAGING_PROOF_CHANGED')
    obj=work/BUILD_REL/'selinux_hide.o'
    cmd=work/BUILD_REL/'.selinux_hide.o.cmd'
    compile_log=work/'compile.log'
    config=work/'config-reports/actual-build.config'
    for f in (obj,cmd,compile_log,config):
        need(f.is_file() and not f.is_symlink() and f.stat().st_size>0,
             'R4_MISSING_COMPILE_EVIDENCE:'+str(f.relative_to(work)))
    commands=cmd.read_text(errors='replace')
    cfg=config.read_text(errors='replace')
    log=compile_log.read_text(errors='replace')
    need('drivers/kernelsu/feature/selinux_hide.o' in commands,
         'R4_OBJECT_COMPILE_COMMAND_NOT_FOR_SELINUX_HIDE')
    need(bool(re.search(r'(?m)^\s*CC\s+drivers/kernelsu/feature/selinux_hide\.o\b',log)),
         'R4_BAKASU_SELINUX_OBJECT_NOT_COMPILED')
    for line in ('CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
                 'CONFIG_STACKPROTECTOR_STRONG=y','CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y'):
        need(bool(re.search(r'(?m)^'+re.escape(line)+'$',cfg)),
             'R4_KERNEL_CONFIG_CHANGED:'+line)
    need('-flto=thin' in commands and '-fstack-protector-strong' in commands,
         'R4_OBJECT_PROTECTION_FLAGS_MISSING')
    need(result.get('kernel')==TARGET_KERNEL,'R4_KERNEL_IDENTITY_DRIFT')
    proof={
        'status':'COMPILED_R3_REVIEWED_SELINUX_STATUS_PORT',
        'kernel':TARGET_KERNEL,'source_sha256':R3_POSTIMAGE,
        'source_git_blob':R3_POST_BLOB,'source_path':STATUS_SOURCE,
        'source_change_count':1,'object_path':BUILD_REL+'/selinux_hide.o',
        'object_sha256':sha(obj.read_bytes()),'command_sha256':sha(cmd.read_bytes()),
        'compile_log_sha256':sha(compile_log.read_bytes()),
        'config_sha256':sha(config.read_bytes()),
        'clang_thinlto':True,'strong_stack_protector':True,
        'R6_BakaSU_official_d726_provenance_preserved':True,
        'R6_BakaSU_official_d726_byte_identical_in_compiled_kernel':False,
        'changes_to_native_5_4_selinux_hosts':False,'full_susfs_upgrade':False,
        'device_pass':False,'flash_release':False,
    }
    safe_report(work.parent.parent,'SELINUX54_R4_COMPILED.json',proof)
    return proof

def inject_verified_r4(disposable_worker: Path) -> dict:
    """Add R4 checks to exact disposable R6 worker; original repo untouched."""
    need(disposable_worker.is_file() and not disposable_worker.is_symlink(),
         'R4_DISPOSABLE_R6_WORKER_MISSING')
    old=disposable_worker.read_text()
    need(old.count(SOURCE_ANCHOR)==1 and old.count(COMPILE_ANCHOR)==1,
         'R4_R6_WORKER_ANCHOR_CHANGED')
    need("bakasu_official_r6 = apply_official_source(" in old and
         "result['bakasu_official_r6'] = bakasu_official_r6" in old,
         'R4_OFFICIAL_BAKASU_STAGE_NOT_PRESENT')
    need('SELINUX54_R4_STAGE' not in old and 'stage_r4(' not in old,
         'R4_WORKER_ALREADY_MODIFIED')
    source_insert=(
        '        from veux_r6_susfs_selinux54_build_r4 import stage_r4\n'
        '        selinux54_r4_source = stage_r4(src, bundle, work)\n'
        + SOURCE_ANCHOR)
    compile_insert=(
        COMPILE_ANCHOR
        + '        from veux_r6_susfs_selinux54_build_r4 import verify_compiled_r4\n'
        + '        selinux54_r4_compiled = verify_compiled_r4(src, work, selinux54_r4_source, result)\n'
        + "        result['selinux54_r4'] = selinux54_r4_compiled\n"
    )
    new=old.replace(SOURCE_ANCHOR,source_insert,1).replace(COMPILE_ANCHOR,compile_insert,1)
    ast.parse(new,filename=str(disposable_worker))
    need(new.count('selinux54_r4_source = stage_r4(')==1 and
         new.count('verify_compiled_r4(src, work, selinux54_r4_source, result)')==1 and
         new.count('overlay_hash = r.save_overlay(')==1,
         'R4_WORKER_INJECTION_NOT_EXACT')
    disposable_worker.write_text(new)
    return {'status':'R4_DISPOSABLE_WORKER_INJECTED',
            'worker_before_sha256':sha(old.encode()),
            'worker_after_sha256':sha(new.encode()),
            'R6_ORIGINAL_WORKER_UNCHANGED':True}

def build(repo: Path, root: Path, jobs: int) -> dict:
    repo=repo.resolve(strict=True)
    root=root.resolve(strict=True)
    need(not root.is_relative_to(repo) and 1<=jobs<=16,
         'R4_UNSAFE_BUILD_WORKSPACE_OR_JOBS')
    src_report=root/'report/SUSFS_SELINUX54_R3/RESULT.json'
    need(src_report.is_file() and not src_report.is_symlink(),
         'R4_R3_SOURCE_PREFLIGHT_MISSING')
    prior=json.loads(src_report.read_text())
    need(prior.get('status')=='TARGETED_5_4_SELINUX_SOURCE_STAGED_NOT_COMPILED' and
         prior.get('bakasu_status_guard',{}).get('after_sha256')==R3_POSTIMAGE and
         prior.get('reference_success_run')==R2_RUN and
         prior.get('full_upstream_susfs_integration_applied') is False,
         'R4_R3_SOURCE_AUDIT_NOT_GREEN')
    # R2's original BakaSU/SUSFS/NoMount gates remain authoritative.
    r1=r2.r1
    r6=r1.load_r6(repo)
    # r2.build performs the ONLY temporary NoMount pin mutation; double
    # pinning would incorrectly reject the otherwise proven R6 base.
    previous_pins=r6.TARGETS
    need(previous_pins['resukisu']['commit']==r3.BAKASU_PIN and
         previous_pins['susfs']['commit']==r3.SUSFS_R6 and
         previous_pins['nomount']['commit']==r1.NOMOUNT_R6,
         'R4_R6_PROVEN_BASE_PINS_CHANGED')
    actual=json.loads((root/'bundle/targets.json').read_text())['components']
    need(actual['resukisu']==previous_pins['resukisu'] and
         actual['susfs']==previous_pins['susfs'] and
         actual['nomount']=={**previous_pins['nomount'],'commit':r3.NOMOUNT_R2},
         'R4_PREPARED_R2_COMPONENT_PINS_CHANGED')
    upstream_inject=r6.selinux_r3.inject_worker
    proofs=[]
    def guarded_inject(original: Path,dest: Path):
        value=upstream_inject(original,dest)
        proofs.append(inject_verified_r4(dest))
        return value
    r6.selinux_r3.inject_worker=guarded_inject
    previous_path=os.environ.get('PYTHONPATH','')
    scripts=str(Path(__file__).resolve().parent)
    os.environ['PYTHONPATH']=os.pathsep.join([scripts,previous_path])
    try:
        r2_audit=r2.build(repo,root,jobs)
    finally:
        r6.selinux_r3.inject_worker=upstream_inject
        os.environ['PYTHONPATH']=previous_path
    need(len(proofs)==1,'R4_DISPOSABLE_WORKER_NOT_INJECTED_ONCE')
    pub=root/'public'/TARGET_KERNEL
    row=json.loads((pub/'RESULT.json').read_text())
    r4=row.get('selinux54_r4') or {}
    need(r4.get('status')=='COMPILED_R3_REVIEWED_SELINUX_STATUS_PORT' and
         r4.get('source_sha256')==R3_POSTIMAGE and
         r4.get('source_change_count')==1 and
         r4.get('device_pass') is False,
         'R4_PUBLISHED_KERNEL_NOT_FROM_REVIEWED_SOURCE')
    need(row.get('targets')==r6.TARGETS and
         row.get('nomount211_r2',{}).get('strong_stack_protector_on_nomount_object') is True and
         all(row.get(k) is True for k in ('compile','package','static_boot')) and
         row.get('device') is False and
         row.get('image_sha256')!=KNOWN_R2_IMAGE,
         'R4_FINAL_R2_GATES_OR_KERNEL_IDENTITY_CHANGED')
    need(r2_audit.get('status')=='EXPERIMENTAL_BUILD_GATES_PASS_DEVICE_NOT_TESTED',
         'R2_BASE_AUDIT_NOT_RETAINED')
    summary={
        'status':'EXPERIMENTAL_R4_COMPILE_GATES_PASS_DEVICE_UNTESTED',
        'basis':f'R6/NoMount211 R2 Github Run {R2_RUN}',
        'reference_R3_source_only_run':R3_RUN,
        'kernel':TARGET_KERNEL,'kernel_image_sha256':row['image_sha256'],
        'r2_kernel_image_sha256':KNOWN_R2_IMAGE,
        'selinux_port':r4,'r2_nomount':row['nomount211_r2'],
        'worker_injection':proofs[0],
        'effective_bakasu':'d7260ca1 plus one explicitly reviewed R3 status condition',
        'susfs_component_pin':r3.SUSFS_R6,
        'upstream_susfs_5_10_patch_not_applied':True,
        'actual_kernel_build':True,'device_pass':False,
        'vendor_modules_fully_tested':False,'flash_release':False,
        'no_repository_changes':True,
    }
    safe_report(root,'SELINUX54_R4_FINAL.json',summary)
    print('R4_R6_NOMOUNT211_SELINUX54_SOURCE_AND_KERNEL_BUILD=PASS; DEVICE_PASS=NO; NO_FLASH',flush=True)
    return summary

def main()->int:
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=('build',))
    p.add_argument('--repo',required=True,type=Path)
    p.add_argument('--work',required=True,type=Path)
    p.add_argument('--jobs',type=int,default=4)
    args=p.parse_args()
    try:
        build(args.repo,args.work,args.jobs)
        return 0
    except Exception as exc:
        print(f'R4_EXPERIMENTAL_BUILD_BLOCKED:{type(exc).__name__}:{exc}',file=sys.stderr,flush=True)
        return 1

if __name__=='__main__':
    sys.exit(main())
