#!/usr/bin/env python3
"""Fail-closed source-only SUSFS/SELinux 5.4 compatibility staging for VEUX R6.

The R2 kernel (Run 38965488864) is the immutable reference.  The upstream
SUSFS core is unchanged; do not apply a 5.10 SELinux patch to 5.4.  One
small, reviewable condition from the new SELinux flow is ported into the
pre-existing BakaSU 5.4 status wrapper inside an ISOLATED CI WORKTREE.

No new SUSFS code is promoted, no BakaSU version is spoofed, and no compile,
AK3, release, Flash, SELinux policy relaxation or direct repository write occurs.
The rest of SUSFS/SELinux remains explicitly unapproved until verified.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

KERNEL = '5.4.274'
REPO = 'Chrizz100/veux-nongki-universal-kernel'
REFERENCE_RUN = 38965488864
BAKASU_PIN = '5b76b884c75f729a220bb317aa4a4fc78f0e0e9c'
BAKASU_EFFECTIVE_SOURCE = 'd7260ca1e5c128061122924d0d48754e361e135c'
BAKASU_OFFICIAL_HOOK_SHA = 'e4299d4db52b3e761413928d733076dc497104cee0cd5ab27e165364cd773c5c'
BAKASU_OFFICIAL_HOOK_BLOB = '9864c9cf5171311769564b682a42cc7eecc8a801'
SUSFS_R6 = '5326e21a7eb232f9e21debdd5164e99bee3d1e2f'
SUSFS_CANDIDATE = 'fec037cb8a0de768dd97d16fa65737cb6121b870'
NOMOUNT_R2 = '7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3'
KERNEL_HOOK_SHA = '57a84c1b0f41d108e9557314c0039e5bfd6fc4b15aa60532711d32e551cc2992'
KERNEL_SELINUXFS_SHA = '16533ae84611ddc908759231a06ac09722cbeda3cba7ebc361baa1ee462729a1'
NEW_SUSFS_BLOBS = {
    'kernel_patches/fs/susfs.c': '1e70f7f2487d1a4c3072f861c7725f733eb59d46',
    'kernel_patches/include/linux/susfs.h': '1e0ae04060839e1adba1db19b4d07638eaae0f95',
    'kernel_patches/include/linux/susfs_def.h': 'a021078ceaaaf6dc098dfdbed592c268c81f85b3',
}
CHANGED_PATCH_BLOBS = {
    'kernel_patches/50_add_susfs_in_gki-android13-5.10.patch': 'b63bcb2e17cb8d9b1dbd509499b19935f5e0783f',
    'kernel_patches/KernelSU/10_enable_susfs_for_ksu.patch': 'b7a5278e38096c77cacb7bbdd988ae2987ab0dec',
}
FEATURE_REL = 'KernelSU/kernel/feature/selinux_hide.c'
HOST_FILES = {
    'security/selinux/hooks.c': KERNEL_HOOK_SHA,
    'security/selinux/selinuxfs.c': KERNEL_SELINUXFS_SHA,
}
FUNCTION_START = 'static int my_sel_open_handle_status(struct inode *inode, struct file *filp)'
BEFORE = 'if (likely(ksu_get_uid_t(current_uid()) >= 10000 && ksu_selinux_hide_enabled)) {'
AFTER = 'if (likely(ksu_get_uid_t(current_uid()) >= 10000 && ksu_selinux_hide_running)) {'


class PortBlocked(RuntimeError):
    pass


def require(condition: bool, error: str) -> None:
    if not condition:
        raise PortBlocked(error)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()


def safe_path(root: Path, relative: str) -> Path:
    root = root.resolve(strict=True)
    require(not Path(relative).is_absolute() and '..' not in Path(relative).parts,
            'UNSAFE_RELATIVE_PATH')
    candidate=root/relative
    require(candidate.is_file() and not candidate.is_symlink() and
            candidate.resolve(strict=True).is_relative_to(root), 'INVALID_OR_LINKED_FILE:'+relative)
    return candidate


def git(donor: Path, *args: str) -> str:
    p=subprocess.run(['git','-C',str(donor),*args], stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE,text=True,timeout=90,check=False,
                     env={**os.environ,'GIT_TERMINAL_PROMPT':'0'})
    require(p.returncode == 0, 'GIT_PROVENANCE_FAILED '+str(args[:2])+':'+p.stderr[-180:])
    return p.stdout.strip()


def verify_upstream(donor: Path) -> dict:
    """Authoritative object comparisons; old donor stays checked out and clean."""
    donor=donor.resolve(strict=True)
    require(donor.name=='susfs' and (donor/'.git').exists(), 'WRONG_SUSFS_DONOR')
    require(git(donor,'rev-parse','HEAD')==SUSFS_R6,'R6_SUSFS_DONOR_MOVED')
    require(not git(donor,'status','--porcelain','--untracked-files=all'), 'DIRTY_SUSFS_DONOR')
    require(git(donor,'cat-file','-t',SUSFS_CANDIDATE)=='commit','NEW_SUSFS_COMMIT_UNKNOWN')
    git(donor,'merge-base','--is-ancestor',SUSFS_R6,SUSFS_CANDIDATE)
    count=int(git(donor,'rev-list','--count',SUSFS_R6+'..'+SUSFS_CANDIDATE))
    require(count==4,'SUSFS_EXPECTED_4_COMMIT_CHAIN_CHANGED')
    changes=set(git(donor,'diff','--name-only',SUSFS_R6,SUSFS_CANDIDATE).splitlines())
    require(changes==set(CHANGED_PATCH_BLOBS),'UNREVIEWED_SUSFS_CHANGE_SET')
    for path,blob in {**NEW_SUSFS_BLOBS, **CHANGED_PATCH_BLOBS}.items():
        new=git(donor,'rev-parse',SUSFS_CANDIDATE+':'+path)
        require(new==blob,'NEW_SUSFS_BLOB_DRIFT:'+path)
        if path in NEW_SUSFS_BLOBS:
            old=git(donor,'rev-parse',SUSFS_R6+':'+path)
            require(old==new,'SUSFS_COMPILED_CORE_DIFFERENT:'+path)
    return {'baseline':SUSFS_R6,'new_upstream':SUSFS_CANDIDATE,
            'new_commits_reviewed':count,'core_files_identical':3,
            'changed_integration_patches':sorted(changes),
            'kernel_5_10_host_patch_not_applied':True,
            'kernel_susfs_c_version_unchanged':'2.3.0',
            'published_component_pin_remains':SUSFS_R6}


def verify_host(source: Path) -> dict:
    data={}
    for relative,expected in HOST_FILES.items():
        raw=safe_path(source,relative).read_bytes()
        require(sha(raw)==expected,'R2_PROVEN_HOST_SHA_DRIFT:'+relative)
        txt=raw.decode('utf-8')
        # 5.4 does NOT have the new GKI inline hooks; inserting the 5.10 patch
        # would duplicate the existing BakaSU runtime hooks.
        require(not re.search(r'\bmy_(?:setprocattr|write_context|write_access|sel_open_handle_status)\b',txt),
                'UNEXPECTED_NATIVE_WRAPPER_IN_5_4:'+relative)
        require('ksu_selinux_hide_running' not in txt,
                'NATIVE_SUSFS_MANUAL_HOOK_ALREADY_PRESENT:'+relative)
        if relative.endswith('hooks.c'):
            require(re.search(r'LSM_HOOK_INIT\(setprocattr,\s*selinux_setprocattr\)',txt) is not None,
                    'NATIVE_LSM_SETATTR_REDIRECTED')
        else:
            for token in ('sel_open_handle_status','sel_write_context','sel_write_access'):
                require(token in txt,'NATIVE_SELINUXFS_API_MISSING:'+token)
        data[relative]={'sha256':expected,'unchanged':True,
                        'native_5_10_hooks_injected':False}
    return data


def transform_status_guard(original: bytes, *, expected_sha: str=BAKASU_OFFICIAL_HOOK_SHA,
                           expected_blob: str|None=BAKASU_OFFICIAL_HOOK_BLOB) -> tuple[bytes,dict]:
    """Scoped 5.4 port subset: only the fake-status open guard can change."""
    require(sha(original)==expected_sha,'BAKASU_D726_PREIMAGE_DRIFT')
    if expected_blob is not None:
        require(git_blob(original)==expected_blob, 'BAKASU_D726_GIT_BLOB_MISMATCH')
    text=original.decode('utf-8')
    require(text.count(FUNCTION_START)==1, 'STATUS_FUNCTION_MISSING_OR_DUPLICATED')
    fn=text.index(FUNCTION_START)
    end=text.find('\nstatic void hook_selinux_status_open()',fn)
    require(end>fn,'STATUS_FUNCTION_END_UNKNOWN')
    section=text[fn:end]
    require(section.count(BEFORE)==1 and section.count(AFTER)==0,
            'BakaSU_STATUS_GUARD_ALREADY_CHANGED_OR_AMBIGUOUS')
    require(text.count(BEFORE)==1,'STATUS_GUARD_OUTSIDE_SCOPE')
    require(re.search(r'(?m)^__maybe_static bool ksu_selinux_hide_enabled\b',text) is not None and
            re.search(r'(?m)^__maybe_static bool ksu_selinux_hide_running\b',text) is not None,
            'BakaSU_HIDE_STATE_DECLARATION_MISSING')
    changed=text[:fn]+section.replace(BEFORE,AFTER,1)+text[end:]
    result=changed.encode('utf-8')
    require(result!=original and changed.replace(AFTER,BEFORE,1)==text,
            'PORT_MODIFIED_UNRELATED_SOURCE')
    require(changed.count(AFTER)>=1 and changed.count(BEFORE)==0,
            'PORT_EFFECT_NOT_VERIFIED')
    # Existing permission, SID, credential and backup-policy handling must stay.
    for token in ('PROCESS__SETCURRENT','PROCESS__DYNTRANSITION','PROCESS__PTRACE',
                  'ksu_security_context_to_sid','backup_policydb',
                  'static int my_sel_open_handle_status', 'static ssize_t my_write_context',
                  'static ssize_t my_write_access'):
        require(text.count(token)==changed.count(token),'BakaSU_SECURITY_FLOW_CHANGED:'+token)
    return result, {'changed_path':FEATURE_REL,'before_sha256':sha(original),
                    'after_sha256':sha(result),'before_git_blob':git_blob(original),
                    'after_git_blob':git_blob(result),'edits':1,
                    'port_subset':'Use ksu_selinux_hide_running for SELinux status open; not just configured enabled',
                    'legacy_security_checks_unchanged':True,
                    'r6_host_selinux_hooks_unchanged':True,
                    'bakasu_version_not_changed':True,
                    'device_runtime_pass':False,'compile_pass':False}


def validate_environment(repo: Path,root: Path) -> tuple[Path,Path]:
    repo=repo.resolve(strict=True)
    root=root.resolve(strict=True)
    require((repo/'.git').exists(), 'REPO_GIT_MISSING')
    require(not root.is_relative_to(repo),'WORKSPACE_OVERLAPS_GITHUB_REPO')
    require(os.environ.get('GITHUB_REPOSITORY',REPO)==REPO,'WRONG_GITHUB_REPO')
    p=subprocess.run(['git','-C',str(repo),'rev-parse','HEAD'],capture_output=True,text=True)
    require(p.returncode==0 and re.fullmatch('[0-9a-f]{40}',p.stdout.strip()) is not None,
            'REPO_SHA_UNAVAILABLE')
    require(os.environ.get('GITHUB_SHA',p.stdout.strip())==p.stdout.strip(),'RUN_SHA_CHANGED')
    d=json.loads((root/'source-audit'/KERNEL/'source.json').read_text())
    src=Path(d['source']).resolve(strict=True)
    require(src.name=='kernel' and src.is_relative_to(root) and
            src.is_dir() and not src.is_symlink(), 'SOURCE_NOT_DISPOSABLE_KERNEL')
    mk=safe_path(src,'Makefile').read_text()
    require(bool(re.search(r'(?m)^VERSION\s*=\s*5$',mk)) and
            bool(re.search(r'(?m)^PATCHLEVEL\s*=\s*4$',mk)), 'NOT_VEUX_5_4')
    targets=json.loads((root/'bundle/targets.json').read_text())['components']
    require(targets['nomount']['commit']==NOMOUNT_R2 and
            targets['resukisu']['commit']==BAKASU_PIN and
            targets['susfs']['commit']==SUSFS_R6, 'R2_COMPONENT_BASE_DRIFT')
    proof=json.loads((root/'report/BAKASU-OFFICIAL-D726-R6.json').read_text())
    require(proof.get('source_provenance',{}).get('upstream_commit')==BAKASU_EFFECTIVE_SOURCE and
            proof.get('after_sha256')==BAKASU_OFFICIAL_HOOK_SHA and
            proof.get('source_matches_official_bakasu_d726_byte_for_byte') is True,
            'R6_OFFICIAL_D726_PROOF_MISSING')
    source_guard=json.loads((root/'report/NOMOUNT211_R6_SOURCE_ONLY.json').read_text())
    require(source_guard['status']=='SOURCE_PREFLIGHT_ONLY_PASS','R2_SOURCE_PREFLIGHT_NOT_GREEN')
    return src,root/'bundle/susfs'


def stage(repo: Path,root: Path) -> dict:
    src,donor=validate_environment(repo,root)
    path=safe_path(src,FEATURE_REL)
    original=path.read_bytes()
    report_dir=root/'report'/'SUSFS_SELINUX54_R3'
    require(not report_dir.exists() and not report_dir.is_symlink(),
            'R3_PORT_REPORT_ALREADY_EXISTS')
    upstream=verify_upstream(donor)
    host=verify_host(src)
    candidate,change=transform_status_guard(original)
    require(sha(path.read_bytes())==BAKASU_OFFICIAL_HOOK_SHA, 'SOURCE_CHANGED_DURING_AUDIT')
    report_dir.mkdir(parents=True,exist_ok=False)
    # Store verified source images/patch so the next build can validate the
    # actual same preimage. This makes the port reviewable and reproducible.
    (report_dir/'SELINUX_D726_ORIGINAL.c').write_bytes(original)
    (report_dir/'SELINUX_5_4_PORT_R3_STAGED.c').write_bytes(candidate)
    diff=''.join(difflib.unified_diff(original.decode().splitlines(True),
                   candidate.decode().splitlines(True),
                   fromfile='a/'+FEATURE_REL, tofile='b/'+FEATURE_REL, n=8))
    require(diff.count('@@')==2,'PORT_DIFF_NOT_SINGLE_HUNK')
    (report_dir/'SELINUX_5_4_PORT_R3.patch').write_text(diff)
    # Only the disposable reconstructed kernel source is changed. No checkout,
    # original donor, GitHub repository, or public release artifact is altered.
    try:
        path.write_bytes(candidate)
        require(path.read_bytes()==candidate,'DISPOSABLE_STAGE_WRITE_FAILED')
        require(all(sha(safe_path(src,p).read_bytes())==s for p,s in HOST_FILES.items()),
                'R3_SELINUX_HOST_MUTATED')
    except BaseException:
        if path.is_file() and path.read_bytes()!=original:
            path.write_bytes(original)
        raise
    report={'schema':3,'status':'TARGETED_5_4_SELINUX_SOURCE_STAGED_NOT_COMPILED',
            'kernel':KERNEL,'reference_success_run':REFERENCE_RUN,
            'upstream_susfs':upstream,'bakasu_status_guard':change,
            'r6_host_selinux_files':host,
            'no_5_10_host_hook_port':True,
            'full_upstream_susfs_integration_applied':False,
            'susfs_core_changed':False,
            'effective_kernel_source_only':True,
            'open_items':['Compile and link this exact postimage with R6 NoMount v2.1.1',
                          'Review BakaSU vs SUSFS execve/SELinux status behavior',
                          'Compare full Xiaomi vendor module ABI',
                          'Hardware/device tests before flash approval'],
            'kernel_built':False,'flash_permission':False,'device_pass':False,
            'repo_written':False,'manager_version_spoofed':False}
    (report_dir/'RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    (report_dir/'START_HIER.txt').write_text(
        'VEUX R6 / NoMount 2.1.1 / SUSFS-SELinux Linux 5.4 R3\n'
        'One targeted SELinux source-only port staged in disposable CI source.\n'
        'New SUSFS core files are IDENTICAL to compiled SUSFS 2.3.0.\n'
        'The full GKI-5.10 patch is intentionally NOT applied to the 5.4 host.\n'
        'BakaSU full SUSFS build blocker remains in upstream and was not removed.\n'
        'NOT BUILT, NOT A FLASHABLE KERNEL. See RESULT.json and .patch.\n')
    print('R3_SUSFS_UPSTREAM_BLOB_SCOPE=PASS; CORE_3_3_IDENTICAL=YES')
    print('R3_SELINUX_5_4_STATUS_GUARD_STAGED=PASS; EDITS=1; NO_FLASH=YES; NO_KERNEL_BUILD=YES')
    return report


def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('operation',choices=['stage'])
    p.add_argument('--repo',required=True,type=Path)
    p.add_argument('--work',required=True,type=Path)
    args=p.parse_args()
    try:
        stage(args.repo,args.work)
        return 0
    except (PortBlocked,ValueError,KeyError,OSError,subprocess.SubprocessError) as exc:
        print('R3_SELINUX_PORT_BLOCKED:'+str(exc),file=sys.stderr)
        return 1

if __name__=='__main__':
    sys.exit(main())
