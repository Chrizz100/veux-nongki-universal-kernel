#!/usr/bin/env python3
"""R20 source-coherent experimental trial, no OEM/stock promotion, NOFLASH.

Only touches the disposable donor trial worktree. No fake stubs, suppressed
compile errors, disabled WALT or fabricated vendor-module CRCs are permitted.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

# Immutable blobs verified directly from Git objects at the pinned commits.
PAIR_SOURCE = {
    "kernel/sched/core.c": "a1cd9d8754abaa392566d10b4b9b1507e1722080",
    "kernel/sched/pelt.h": "afff644da06500b4b817925e8f35824b8b69d0c5",
    "mm/vmscan.c": "d81fc723be0c1a127d4acb7079cad23a2ee0a543",
    "kernel/sched/rt.c": "0cfca9b00e97a0708171788e213a517d9540eb96",
    "kernel/sched/fair.c": "56200fa9a2e812f4f37863cf2e8bfb64b97a56f4",
    "kernel/sched/features.h": "16579ad03aaebd3dcab7cf763e7850c75bd0e68d",
    "include/linux/sched/wake_q.h": "3c04437a7a6f8fe636b47777b978901d7a392623",
    "include/trace/events/sched.h": "4726213b734e0150de4907560cecb2f095ff2a7c",
}
DONOR_SOURCE = {
    "kernel/sched/rt.c": "625977884e32e95cb366d53b969c63ff56619a32",
    "kernel/sched/fair.c": "a7e286eab23f32a1119d7075662aa302049ad008",
    "kernel/sched/features.h": "580a0d1c0aef45dae4ff8dffd2252679314c8840",
    "include/linux/sched/wake_q.h": "26a2013ac39c4480784a87297d72f02ae120a7cf",
    "mm/vmscan.c": "fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa",
    "include/trace/events/sched.h": "b85e11fdad3c4134d7650bcd9faee903cac14572",
    "include/trace/hooks/sched.h": "fa3636d255ef3fd207313728bf1879bd1ffe78a0",
}
PAIR_COMMIT = "01cb3a8824b7b4caf3e3540274e71abba5ade538"
DONOR_COMMIT = "b2b7a3bbc36d120ee523ebc8d68e0f13a97df632"
R17_SCHED_H_SHA256 = "a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111"
TARGETS = {
    "CORE": "kernel/sched/core.o", "RT": "kernel/sched/rt.o",
    "FAIR": "kernel/sched/fair.o", "VMSCAN": "mm/vmscan.o",
}
R17_REGRESSION = (
    "kernel/sched/walt.o", "techpack/sched/walt.o", "kernel/sysctl.o",
    "techpack/sched/boost.o", "techpack/sched/sched_avg.o",
    "techpack/sched/qc_vas.o", "techpack/sched/core_ctl.o",
    "techpack/sched/trace.o", "techpack/sched/cpu-boost.o",
    "kernel/watchdog.o", "kernel/time/hrtimer.o", "kernel/time/timer.o",
)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()


def checked_source(repo, commit, path, expected):
    proc = subprocess.run(["git", "-C", str(repo), "show", commit + ":" + path],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if proc.returncode or blob_sha(proc.stdout) != expected:
        raise ValueError("R20_SOURCE_BLOB_MISMATCH_OR_MISSING:" + path)
    return proc.stdout


def modify_vendor_hook(source):
    """Keep original SM6375 three-argument vendor hook, including its 'allowed' override semantics."""
    if source.count("trace_android_rvh_set_user_nice(p, &nice);") != 1:
        raise ValueError("R20_VENDOR_HOOK_SITE_AMBIGUOUS")
    pat = re.compile(
        r"(void set_user_nice\(struct task_struct \*p, long nice\)\s*\{\s*)"
        r"bool queued, running;(?P<middle>\s*int old_prio, delta;\s*struct rq_flags rf;\s*struct rq \*rq;\s*)"
        r"if \(task_nice\(p\) == nice \|\| nice < MIN_NICE \|\| nice > MAX_NICE\)\s*return;",
        re.MULTILINE)
    replacement = (
        r"\g<1>bool queued, running, allowed = false;\g<middle>"
        "trace_android_rvh_set_user_nice(p, &nice, &allowed);\n"
        "\tif ((task_nice(p) == nice || nice < MIN_NICE || nice > MAX_NICE) && !allowed)\n"
        "\t\treturn;")
    out, count = pat.subn(replacement, source)
    if count != 1:
        raise ValueError("R20_STOCK_VENDOR_HOOK_SEMANTICS_COULD_NOT_BE_APPLIED")
    out, removed = re.subn(r"^[ \t]*trace_android_rvh_set_user_nice\(p, &nice\);[ \t]*\n", "", out, count=1, flags=re.MULTILINE)
    if removed != 1:
        raise ValueError("R20_OLD_VENDOR_HOOK_CALL_COULD_NOT_BE_REMOVED")
    if out.count("trace_android_rvh_set_user_nice(p, &nice, &allowed);") != 1:
        raise ValueError("R20_VENDOR_HOOK_SEMANTICS_NOT_PRESERVED")
    return out


def extract_pair_trace_event(pair_trace, donor_trace):
    marker = "/*\n * Tracepoint for task enqueue/dequeue:\n */\n"
    end_marker = "/*\n * Tracepoint for waking up a task:\n */\n"
    if pair_trace.count(marker) != 1 or pair_trace.count(end_marker) != 1 or donor_trace.count(end_marker) != 1:
        raise ValueError("R20_TRACE_BLOCK_SOURCE_MISMATCH")
    if "TRACE_EVENT(sched_enq_deq_task," in donor_trace:
        raise ValueError("R20_EXISTING_TRACE_EVENT_DUPLICATE")
    start = pair_trace.index(marker)
    end = pair_trace.index(end_marker)
    if end <= start:
        raise ValueError("R20_QUALCOMM_TRACE_EVENT_NOT_IN_EXPECTED_LOCATION")
    fragment = pair_trace[start:end]
    if not (fragment.count("TRACE_EVENT(sched_enq_deq_task,") == 1 and
            "task_load(p)" in fragment and "task_pl(p)" in fragment and
            "TP_PROTO(struct task_struct *p, bool enqueue," in fragment):
        raise ValueError("R20_TRACE_EVENT_UNEXPECTED_SEMANTICS")
    return donor_trace.replace(end_marker, fragment + end_marker, 1)


def reconcile_vmscan(donor_vmscan):
    anchor = "static LIST_HEAD(shrinker_list);\n"
    if donor_vmscan.count(anchor) != 1 or re.search(r"(?:static\s+)?DECLARE_RWSEM\(shrinker_rwsem\)", donor_vmscan):
        raise ValueError("R20_VMSCAN_UNEXPECTED_LOCK_SITE")
    needed = ("down_write(&shrinker_rwsem)", "up_write(&shrinker_rwsem)",
              "down_read_trylock(&shrinker_rwsem)", "up_read(&shrinker_rwsem)")
    if any(item not in donor_vmscan for item in needed):
        raise ValueError("R20_VMSCAN_LOCK_USAGE_IS_NOT_STOCK_DONOR")
    return donor_vmscan.replace(anchor, anchor + "static DECLARE_RWSEM(shrinker_rwsem);\n", 1)


def ensure_identity(repo, commit, label):
    p = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True)
    if p.returncode or p.stdout.strip() != commit:
        raise ValueError("R20_SOURCE_COMMIT_CHANGED:"+label)
    p = subprocess.run(["git", "-C", str(repo), "status", "--porcelain"], capture_output=True, text=True)
    if p.returncode or p.stdout.strip():
        raise ValueError("R20_ORIGINAL_SOURCE_DIRTY:"+label)


def stage(pair, donor, trial, reports):
    pair, donor, trial, reports = map(Path, (pair, donor, trial, reports))
    reports.mkdir(parents=True, exist_ok=True)
    ensure_identity(pair, PAIR_COMMIT, "PAIR")
    ensure_identity(donor, DONOR_COMMIT, "DONOR")
    if not trial.is_dir() or not (trial/"Makefile").is_file():
        raise ValueError("R20_DISPOSABLE_TRIAL_MISSING")
    sched = trial/"include/linux/sched.h"
    if sha256(sched.read_bytes()) != R17_SCHED_H_SHA256:
        raise ValueError("R20_PINNED_STOCK_TASK_STRUCT_CHANGED")
    sources = {}
    for p, digest in PAIR_SOURCE.items():
        sources[("pair", p)] = checked_source(pair, PAIR_COMMIT, p, digest)
    for p, digest in DONOR_SOURCE.items():
        sources[("donor", p)] = checked_source(donor, DONOR_COMMIT, p, digest)
    if (trial/"kernel/sched/core.c").read_bytes() != sources[("pair", "kernel/sched/core.c")]:
        raise ValueError("R20_R19_CORE_STAGE_NOT_GENUINE")
    if (trial/"kernel/sched/pelt.h").read_bytes() != sources[("pair", "kernel/sched/pelt.h")]:
        raise ValueError("R20_R19_PELT_STAGE_NOT_GENUINE")
    if (trial/"mm/vmscan.c").read_bytes() != sources[("pair", "mm/vmscan.c")]:
        raise ValueError("R20_R19_VMSCAN_STAGE_NOT_GENUINE")
    # Never silently overwrite a prior R17 modification or another donor-local patch.
    for rel in (
        "kernel/sched/rt.c", "kernel/sched/fair.c", "kernel/sched/features.h",
        "include/linux/sched/wake_q.h", "include/trace/events/sched.h",
    ):
        if (trial/rel).read_bytes() != sources[("donor", rel)]:
            raise ValueError("R20_ORIGINAL_R17_TRIAL_SOURCE_IS_NOT_THE_DONOR:"+rel)
    original_hook = trial/"include/trace/hooks/sched.h"
    if original_hook.read_bytes() != sources[("donor", "include/trace/hooks/sched.h")]:
        raise ValueError("R20_STOCK_VENDOR_HOOK_HEADER_CHANGED")
    rewritten = {
        "kernel/sched/core.c": modify_vendor_hook(sources[("pair", "kernel/sched/core.c")].decode()),
        "kernel/sched/pelt.h": sources[("pair", "kernel/sched/pelt.h")].decode(),
        "kernel/sched/rt.c": sources[("pair", "kernel/sched/rt.c")].decode(),
        "kernel/sched/fair.c": sources[("pair", "kernel/sched/fair.c")].decode(),
        "kernel/sched/features.h": sources[("pair", "kernel/sched/features.h")].decode(),
        "include/linux/sched/wake_q.h": sources[("pair", "include/linux/sched/wake_q.h")].decode(),
        "include/trace/events/sched.h": extract_pair_trace_event(
            sources[("pair", "include/trace/events/sched.h")].decode(),
            sources[("donor", "include/trace/events/sched.h")].decode()),
        "mm/vmscan.c": reconcile_vmscan(sources[("donor", "mm/vmscan.c")].decode()),
    }
    # Prepare and validate ALL replacement sources before writing any target.
    replacements = []
    for rel, contents in rewritten.items():
        path = (trial/rel).resolve()
        if not path.is_relative_to(trial.resolve()) or not path.is_file():
            raise ValueError("R20_TRIAL_PATH_INVALID:" + rel)
        data = contents.encode("utf-8")
        if b"-Wno-error" in data or b"#define rt_entity_is_task" in data and rel != "kernel/sched/rt.c":
            raise ValueError("R20_STUB_OR_WARNING_BYPASS_REJECTED:" + rel)
        replacements.append((path, data, rel))
    manifest = {
        "schema": "VEUX_R20_QUELLKOHERENZ_COMPILER_TRIAL_NOFLASH",
        "stock_5_4_274_source_reproduced": False,
        "production_patch_approved": False, "flash_allowed": False,
        "boot_verified": False, "oem_abi_verified": False,
        "full_walt_runtime_verified": False, "stock_rtmm_implemented": False,
        "source_pair_commit": PAIR_COMMIT, "donor_commit": DONOR_COMMIT,
        "stock_sched_h_sha256": R17_SCHED_H_SHA256,
        "original_source_pins": {"pair": PAIR_SOURCE, "donor": DONOR_SOURCE},
        "changed_only_disposable_trial": True,
        "source_patches": [dict(path=rel, before_sha256=sha256(path.read_bytes()),
                                after_sha256=sha256(data)) for path, data, rel in replacements],
        "note": "Quellkompatibilitaetsprobe, keine produktive Stock-Kernel-Portierung.",
    }
    for path, data, _ in replacements:
        path.write_bytes(data)
    if sha256(sched.read_bytes()) != R17_SCHED_H_SHA256:
        raise ValueError("R20_STOCK_HEADER_MUTATION")
    ensure_identity(donor, DONOR_COMMIT, "DONOR")
    ensure_identity(pair, PAIR_COMMIT, "PAIR")
    (reports/"R20_SOURCE_STAGE.json").write_text(json.dumps(manifest, indent=2, sort_keys=True)+"\n")
    print(f"R20_PINNED_SOURCE_COHERENCE_STAGE=PASS; {len(replacements)} isolated source files; FLASH=NO")


def compile_objects(trial, build, reports, phase):
    trial, build, reports = map(Path, (trial, build, reports))
    if not (build/".config").is_file() or "CONFIG_SCHED_WALT=y" not in (build/".config").read_text().splitlines():
        raise ValueError("R20_WALT_CONFIG_NOT_ENABLED")
    if not (reports/"R20_SOURCE_STAGE.json").is_file():
        raise ValueError("R20_STAGED_SOURCE_MANIFEST_MISSING")
    if sha256((trial/"include/linux/sched.h").read_bytes()) != R17_SCHED_H_SHA256:
        raise ValueError("R20_STOCK_SCHED_H_MUTATED_DURING_STAGE")
    objects = TARGETS if phase == "targets" else {f"R17_{i+1:02d}":p for i,p in enumerate(R17_REGRESSION)}
    summary = {"schema":"VEUX_R20_TRUE_OBJECT_COMPILER", "phase":phase,
               "flash_allowed":False, "oem_abi_verified":False, "boot_verified":False,
               "production_patch_approved":False, "objects":{}, "success":False}
    reports.mkdir(parents=True, exist_ok=True)
    path = reports/("R20_TARGET_COMPILERS.json" if phase == "targets" else "R20_R17_REGRESSION_COMPILERS.json")
    for name, obj in objects.items():
        dst = build/obj
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            if dst.is_symlink() or not dst.is_file():
                raise ValueError("R20_UNSAFE_BUILD_ARTIFACT:" + obj)
            dst.unlink()
        cmdfile = dst.parent/("."+dst.name+".cmd")
        if cmdfile.is_file() and not cmdfile.is_symlink():
            cmdfile.unlink()
        command = ["timeout", "420s", "make", "-C", str(trial), "O="+str(build),
                   "ARCH=arm64", "CC=clang", "LD=ld.lld", "LLVM=1", "LLVM_IAS=1", "-j2", obj]
        logpath = reports/f"R20_{phase.upper()}_{name}_BUILD.log"
        with open(logpath, "wb") as o:
            proc = subprocess.run(command, stdout=o, stderr=subprocess.STDOUT, check=False)
        logtext = logpath.read_text(errors="replace")
        exists = dst.is_file() and not dst.is_symlink() and dst.stat().st_size > 0
        errors = [line.strip() for line in logtext.splitlines() if "error:" in line.lower() or "fatal error:" in line.lower()]
        entry = {"source_object":obj, "true_make_rc":proc.returncode,
                 "output_exists":exists, "size":dst.stat().st_size if exists else 0,
                 "compiler_errors_first":errors[:30],
                 "log_sha256":sha256(logpath.read_bytes()),
                 "actual_object_sha256":sha256(dst.read_bytes()) if exists else None,
                 "success":proc.returncode == 0 and exists and not errors}
        summary["objects"][name]=entry
        path.write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
        print(f"R20_{phase.upper()}_{name}: MAKE_RC={proc.returncode}, OBJECT={exists}", flush=True)
        if not entry["success"]:
            print("\n".join(logtext.splitlines()[-20:]), flush=True)
    summary["success"] = len(summary["objects"])==len(objects) and all(x["success"] for x in summary["objects"].values())
    path.write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
    if not summary["success"]:
        failures = [name for name, result in summary["objects"].items() if not result["success"]]
        raise ValueError("R20_REAL_OBJECT_COMPILATION_FAILED:"+",".join(failures))
    print(f"R20_{phase.upper()}_REAL_COMPILER_PASS={len(objects)}/{len(objects)}; OEM_ABI=UNKNOWN; NOFLASH")


def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="cmd", required=True)
    st=sub.add_parser("stage")
    for k in ("pair","donor","trial","reports"):
        st.add_argument("--"+k, required=True)
    co=sub.add_parser("compile")
    for k in ("trial","build","reports"):
        co.add_argument("--"+k, required=True)
    co.add_argument("--phase",choices=("targets","r17-regression"),required=True)
    args=ap.parse_args()
    try:
        if args.cmd=="stage": stage(args.pair,args.donor,args.trial,args.reports)
        else: compile_objects(args.trial,args.build,args.reports,args.phase)
    except Exception as e:
        print(f"::error::{e}",file=sys.stderr)
        return 1
    return 0

if __name__=="__main__":
    sys.exit(main())
