import unittest
from r20_compat import (PAIR_SOURCE, DONOR_SOURCE, TARGETS, R17_REGRESSION,
                        blob_sha, modify_vendor_hook, extract_pair_trace_event,
                        reconcile_vmscan)

CORE = '''void set_user_nice(struct task_struct *p, long nice)
{
    bool queued, running;
    int old_prio, delta;
    struct rq_flags rf;
    struct rq *rq;

    if (task_nice(p) == nice || nice < MIN_NICE || nice > MAX_NICE)
        return;
    rq = task_rq_lock(p, &rf);
    update_rq_clock(rq);
    trace_android_rvh_set_user_nice(p, &nice);
    something_else();
}
'''
PAIR_TRACE = '''/*
 * Tracepoint for task enqueue/dequeue:
 */
TRACE_EVENT(sched_enq_deq_task,
TP_PROTO(struct task_struct *p, bool enqueue,
  unsigned int cpus_allowed),
TP_ARGS(p, enqueue, cpus_allowed),
TP_fast_assign(__entry->demand = task_load(p);
 __entry->pred_demand = task_pl(p);),
);

/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_TRACE = '''/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_VM = '''static LIST_HEAD(shrinker_list);
static DEFINE_SPINLOCK(shrinker_lock);
static DEFINE_RWLOCK(shrinker_rwlock);
static void foo(void) {
down_write(&shrinker_rwsem);
up_write(&shrinker_rwsem);
if (!down_read_trylock(&shrinker_rwsem)) return;
up_read(&shrinker_rwsem);
}
'''

class R20SourceTests(unittest.TestCase):
    def test_01_pinned_source_count(self):
        self.assertEqual(len(PAIR_SOURCE),8)
        self.assertEqual(len(DONOR_SOURCE),7)
    def test_02_blob_sha(self):
        self.assertEqual(blob_sha(b"test\n"),"9daeafb9864cf43055ae93beb0afd6c7d144bfa4")
    def test_03_four_real_object_targets(self):
        self.assertEqual(set(TARGETS), {"CORE","RT","FAIR","VMSCAN"})
    def test_04_twelve_r17_distinct(self):
        self.assertEqual(len(R17_REGRESSION),12)
        self.assertEqual(len(set(R17_REGRESSION)),12)
    def test_05_vendor_hook_3args(self):
        x=modify_vendor_hook(CORE)
        self.assertIn("trace_android_rvh_set_user_nice(p, &nice, &allowed);",x)
        self.assertNotIn("trace_android_rvh_set_user_nice(p, &nice);",x)
    def test_06_vendor_hook_original_default_false(self):
        self.assertIn("allowed = false;",modify_vendor_hook(CORE))
    def test_07_vendor_hook_used_before_rejection(self):
        x=modify_vendor_hook(CORE)
        self.assertLess(x.index("trace_android_rvh_set_user_nice"),x.index("if ((task_nice"))
    def test_08_vendor_hook_preserves_override(self):
        self.assertIn("&& !allowed",modify_vendor_hook(CORE))
    def test_09_vendor_hook_rejects_bad_source(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("bool queued, running;", "bool queued;"))
    def test_10_vendor_hook_rejects_double_hook(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("something_else();", "trace_android_rvh_set_user_nice(p, &nice);"))
    def test_11_trace_integration_once(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertEqual(x.count("TRACE_EVENT(sched_enq_deq_task,"),1)
    def test_12_trace_retains_donor_wakeup(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertIn("DECLARE_EVENT_CLASS(sched_wakeup_template);",x)
    def test_13_trace_rejects_duplicate_event(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE+"\nTRACE_EVENT(sched_enq_deq_task,\n")
    def test_14_trace_requires_real_task_api(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE.replace("task_load(p)","zero(p)"),DONOR_TRACE)
    def test_15_donor_shrinker_lock(self):
        self.assertIn("static DECLARE_RWSEM(shrinker_rwsem);", reconcile_vmscan(DONOR_VM))
    def test_16_donor_shrinker_no_reset(self):
        x=reconcile_vmscan(DONOR_VM)
        self.assertIn("static DEFINE_SPINLOCK(shrinker_lock);",x)
        self.assertIn("static DEFINE_RWLOCK(shrinker_rwlock);",x)
    def test_17_donor_shrinker_reject_duplicate(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM+"\nstatic DECLARE_RWSEM(shrinker_rwsem);\n")
    def test_18_donor_shrinker_reject_removed_usage(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM.replace("up_read(&shrinker_rwsem)","up_read(&some_lock)"))
    def test_19_no_warning_bypass_flags_in_source(self):
        import inspect,r20_compat
        src=inspect.getsource(r20_compat)
        self.assertIn('"-j2"',src)
        self.assertIn('"LLVM=1"',src)
        self.assertIn('"flash_allowed": False',src)
    def test_20_unmodified_pin_bijection(self):
        self.assertIn("kernel/sched/core.c", PAIR_SOURCE)
        self.assertIn("mm/vmscan.c", DONOR_SOURCE)
        self.assertIn("mm/vmscan.c", PAIR_SOURCE)
        self.assertEqual(PAIR_SOURCE["mm/vmscan.c"], "d81fc723be0c1a127d4acb7079cad23a2ee0a543")

    def test_21_stage_all_constant_sources_are_pinned(self):
        """Catch the exact R20 KeyError before another GitHub run."""
        import ast, inspect, textwrap
        from r20_compat import stage
        tree=ast.parse(textwrap.dedent(inspect.getsource(stage)))
        keys=[]
        for node in ast.walk(tree):
            if not isinstance(node, ast.Subscript):
                continue
            if not (isinstance(node.value, ast.Name) and node.value.id == 'sources'):
                continue
            try:
                key=ast.literal_eval(node.slice)
            except (ValueError, TypeError, SyntaxError):
                continue  # Dynamic loop variables are handled by their own source list.
            if isinstance(key, tuple) and len(key)==2 and key[0] in {'pair','donor'}:
                keys.append(key)
        self.assertGreaterEqual(len(keys), 9)
        for origin, path in keys:
            self.assertIn(path, PAIR_SOURCE if origin=='pair' else DONOR_SOURCE,
                          f'Missing hard-coded source pin for {origin}:{path}')

    def test_22_vmscan_trial_matches_r19_original_provenance(self):
        self.assertEqual(PAIR_SOURCE['mm/vmscan.c'],
                         'd81fc723be0c1a127d4acb7079cad23a2ee0a543')
        self.assertEqual(DONOR_SOURCE['mm/vmscan.c'],
                         'fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa')

if __name__=="__main__":unittest.main()
