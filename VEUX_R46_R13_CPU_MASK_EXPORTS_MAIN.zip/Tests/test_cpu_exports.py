from pathlib import Path
import importlib.util
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('cpu_restore', ROOT / 'Tools/restore_cpu_exports.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class CPUExportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original_R12', self.source)

    def test_whole_optimization_reversed_preserving_walt(self):
        before = (self.source / 'include/linux/cpumask.h').read_text()
        result = m.apply_source(self.source)
        after = (self.source / 'include/linux/cpumask.h').read_text()
        self.assertEqual(result['changed_files'], 3)
        self.assertIn('extern unsigned int nr_cpu_ids;', after)
        self.assertNotIn('#define nr_cpu_ids\t\t((unsigned int)NR_CPUS)', after)
        self.assertIn('unsigned int cpumask_next(int n, const struct cpumask *srcp);', after)
        # The R15 WALT writers must survive byte-for-byte, including their guards.
        marker = '/* Original Xiaomi CPU-isolation state writer; no success-return stub. */'
        self.assertEqual(before[before.index(marker):], after[after.index(marker):])
        self.assertIn('void __init setup_nr_cpu_ids(void)',
                      (self.source / 'kernel/smp.c').read_text())
        self.assertNotIn('#if NR_CPUS > BITS_PER_LONG',
                         (self.source / 'lib/cpumask.c').read_text())

    def test_late_preimage_drift_rejected_before_any_write(self):
        path = self.source / 'lib/cpumask.c'
        path.write_text(path.read_text() + '\n/* drift */\n')
        before = {n: m.sha(self.source / n) for n in m.FILES}
        with self.assertRaisesRegex(ValueError, 'CPU_PREIMAGE_CHANGED'):
            m.apply_source(self.source)
        self.assertEqual(before, {n: m.sha(self.source / n) for n in m.FILES})

    def test_reapplication_rejected(self):
        m.apply_source(self.source)
        with self.assertRaisesRegex(ValueError, 'CPU_PREIMAGE_CHANGED'):
            m.apply_source(self.source)

    def test_symlink_rejected_before_outside_write(self):
        path = self.source / 'kernel/smp.c'
        outside = Path(self.temp.name) / 'outside.c'
        path.rename(outside)
        before = outside.read_bytes()
        path.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'UNSAFE_SOURCE'):
            m.apply_source(self.source)
        self.assertEqual(before, outside.read_bytes())

    def test_missing_or_wrong_export_cannot_pass_abi_gate(self):
        expected = {**m.EXPECTED_EXPORTS, 'old_good': '0x12345678'}
        reference = {'old_good': '0x12345678'}
        actual = dict(expected)
        self.assertEqual(m.verify_abi(actual, reference, expected)['gained_matching_symbols'],
                         sorted(m.EXPECTED_EXPORTS))
        for bad in ({'cpumask_next': '0x00000000'}, {'nr_cpu_ids': None}):
            with self.assertRaisesRegex(ValueError, 'RESTORED_EXPORT_NOT_STOCK_COMPATIBLE'):
                m.verify_abi({**actual, **bad}, reference, expected)

    def test_old_stock_match_cannot_silently_regress(self):
        expected = {**m.EXPECTED_EXPORTS, 'old_good': '0x12345678'}
        with self.assertRaisesRegex(ValueError, 'PREVIOUS_STOCK_MATCH_REGRESSED'):
            m.verify_abi({**expected, 'old_good': '0x87654321'},
                         {'old_good': expected['old_good']}, expected)

    def test_crc_entries_without_real_linked_code_rejected(self):
        path = Path(self.temp.name) / 'System.map'
        path.write_text('0000000000001000 r __ksymtab_cpumask_next\n'
                        '0000000000002000 r __ksymtab_nr_cpu_ids\n')
        with self.assertRaisesRegex(ValueError, 'NO_REAL_CPUMASK_NEXT_CODE'):
            m.prove_linked_exports(path)

    def test_two_spf_options_are_only_config_delta(self):
        r12, _ = m.dependency()
        before = {'CONFIG_NR_CPUS': '32', 'CONFIG_SMP': 'y'}
        after = {**before, **dict.fromkeys(r12.CONFIG_KEYS, 'y')}
        r12.verify_config(before, after)
        after['CONFIG_NR_CPUS'] = '64'
        with self.assertRaisesRegex(ValueError, 'UNEXPECTED_CONFIG_DELTA'):
            r12.verify_config(before, after)


if __name__ == '__main__':
    unittest.main()
