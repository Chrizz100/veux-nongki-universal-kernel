#!/usr/bin/env python3
"""Reproduce the bounded ARM64 CPU-unit/CRC proof; this is not a full build."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

import restore_cpu_exports as repair


def run(argv, **kwargs):
    result = subprocess.run(argv, text=True, capture_output=True, **kwargs)
    repair.require(result.returncode == 0, 'COMMAND_FAILED:' + repr(argv) + '\n' + result.stderr)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clang', required=True)
    parser.add_argument('--work-dir', required=True)
    parser.add_argument('--cc', default='cc')
    args = parser.parse_args()
    repair.verify_package()
    clang = Path(args.clang).resolve(strict=True)
    repair.require(repair.sha(clang) ==
                   'b2ce016755bddbab76549895bca07b1dc8d14a3e315b8b3567097fef04eadae1',
                   'NOT_THE_AUTHENTICATED_ANDROID_CLANG_BINARY')
    work = Path(args.work_dir).resolve()
    repair.require(not work.exists(), 'WORK_DIRECTORY_MUST_BE_NEW')
    work.mkdir(parents=True)
    with tarfile.open(repair.ROOT / 'References/R12_COMPILED_HEADER_CAPSULE.tar.xz') as archive:
        archive.extractall(work, filter='data')
    gen = work / 'genksyms'
    run([args.cc, '-O2', '-I' + str(gen), str(gen / 'genksyms.c'),
         str(gen / 'parse.tab.c'), str(gen / 'lex.lex.c'), '-o', str(gen / 'genksyms')])
    headers = work / 'include-tree'
    system_include = run([args.cc, '-print-file-name=include']).stdout.strip()
    command = [str(clang), '--target=aarch64-linux-gnu', '-D__KERNEL__', '-nostdinc',
               '-isystem', system_include]
    for name in ('arch/arm64/include', 'arch/arm64/include/generated', 'include',
                 'arch/arm64/include/uapi', 'arch/arm64/include/generated/uapi',
                 'include/uapi', 'include/generated/uapi'):
        command.append('-I' + str(headers / name))
    command += ['-include', str(headers / 'include/linux/kconfig.h')]

    def crc(source, label):
        processed = run(command + ['-E', '-D__GENKSYMS__', str(source)]).stdout
        result = run([str(gen / 'genksyms'), '-T', str(work / (label + '.symtypes'))], input=processed)
        (work / (label + '.ver')).write_text(result.stdout)
        return {line.split()[0].removeprefix('__crc_'): line.split()[2].rstrip(';')
                for line in result.stdout.splitlines() if line.startswith('__crc_')}

    baseline_layout = crc(work / 'module.c', 'r12-module')['module_layout']
    repair.require(baseline_layout == '0x71c13c49', 'GENUINE_R12_CRC_NOT_REPRODUCED')
    source = work / 'source'
    shutil.copytree(repair.ROOT / 'Original_R12', source)
    # This private declaration header is identical to the pinned donor version.
    (source / 'kernel/smpboot.h').write_text(
        '/* SPDX-License-Identifier: GPL-2.0 */\n#ifndef SMPBOOT_H\n#define SMPBOOT_H\n'
        'struct task_struct;\n#ifdef CONFIG_GENERIC_SMP_IDLE_THREAD\n'
        'struct task_struct *idle_thread_get(unsigned int cpu);\n'
        'void idle_thread_set_boot_cpu(void);\nvoid idle_threads_init(void);\n#else\n'
        'static inline struct task_struct *idle_thread_get(unsigned int cpu) { return NULL; }\n'
        'static inline void idle_thread_set_boot_cpu(void) { }\n'
        'static inline void idle_threads_init(void) { }\n#endif\n'
        'int smpboot_create_threads(unsigned int cpu);\nint smpboot_park_threads(unsigned int cpu);\n'
        'int smpboot_unpark_threads(unsigned int cpu);\nvoid __init cpuhp_threads_init(void);\n#endif\n')
    repair.apply_source(source)
    shutil.copyfile(source / 'include/linux/cpumask.h', headers / 'include/linux/cpumask.h')
    actual = {}
    for name in ('lib/cpumask.c', 'kernel/smp.c'):
        label = Path(name).stem
        actual.update(crc(source / name, label))
        invocation = command + ['-O2', '-mgeneral-regs-only', '-fno-pic', '-fno-stack-protector',
                                '-Wno-unused-value', '-Wno-pointer-sign',
                                '-Wno-gnu-variable-sized-type-not-at-end',
                                '-Wno-address-of-packed-member', '-DKBUILD_MODNAME="' + label + '"',
                                '-DKBUILD_BASENAME="' + label + '"', '-c', str(source / name),
                                '-o', str(work / (label + '.o'))]
        output = run(invocation)
        (work / (label + '-compile.log')).write_text(output.stdout + output.stderr)
        (work / (label + '-compile-command.json')).write_text(json.dumps(invocation, indent=2) + '\n')
    repair.require(all(actual.get(n) == crc for n, crc in repair.EXPECTED_EXPORTS.items()),
                   'CPU_CRC_DOES_NOT_MATCH_ORIGINAL_STOCK')
    after_layout = crc(work / 'module.c', 'r13-module')['module_layout']
    repair.require(after_layout == baseline_layout, 'UNEXPECTED_MODULE_LAYOUT_CHANGE')
    result = {'status': 'TWO_ARM64_C_UNITS_AND_EXACT_STOCK_CPU_CRCS_REPRODUCED',
              'stock_cpu_crc_matches': repair.EXPECTED_EXPORTS,
              'module_layout_unchanged': after_layout, 'full_kernel_built': False,
              'flash_allowed': False}
    repair.write_json(work / 'LOCAL_REPLAY_RESULT.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
