#!/usr/bin/env python3
"""Reverse the complete NR_CPUS word-size optimization on the proven R12 base.

Restore real implementations and exports, never symbol CRC values. Build in a
separate source/output tree and compare all 1,423 original QGKI imports.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
R12_ARCHIVE_SHA = '7ead3179e254d17ca2092f74be0b77737c0e007952d5f55598d220dcd39454b7'
R12_SYMVERS_SHA = '2d8a4b0978951afdac82020896ff5aa9f83530b041bcaef0ec1617dad3b0776b'
R12_CONFIG_SHA = '606c0c6ac975871d13e4f0f52914e07c661a4e6fd8cc59e48e5210c66691cdb2'
EXPECTED_EXPORTS = {'cpumask_next': '0x92ad1db9', 'nr_cpu_ids': '0x017de3d5'}
FILES = ('include/linux/cpumask.h', 'kernel/smp.c', 'lib/cpumask.c')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_package():
    listed = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts and name not in listed,
                'UNSAFE_MANIFEST')
        require(not (ROOT / rel).is_symlink() and sha(ROOT / rel) == digest,
                'PACKAGE_FILE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and 'runtime-r12' not in p.parts
              and p.name != 'MANIFEST_SHA256.txt'}
    require(listed == actual, 'PACKAGE_MANIFEST_SCOPE_CHANGED')
    require(sha(ROOT / 'Dependencies/R12_MAIN.zip') == R12_ARCHIVE_SHA, 'R12_DEPENDENCY_CHANGED')
    require(sha(ROOT / 'References/R12_Module.symvers') == R12_SYMVERS_SHA, 'R12_REFERENCE_CHANGED')
    require(sha(ROOT / 'References/R12.config') == R12_CONFIG_SHA, 'R12_CONFIG_CHANGED')


def dependency():
    archive = ROOT / 'Dependencies/R12_MAIN.zip'
    require(sha(archive) == R12_ARCHIVE_SHA, 'R12_DEPENDENCY_CHANGED')
    destination = ROOT / 'runtime-r12'
    if not destination.exists():
        with zipfile.ZipFile(archive) as z:
            items = z.infolist()
            require(len(items) < 200 and sum(p.file_size for p in items) < 32_000_000,
                    'R12_ARCHIVE_SCOPE_CHANGED')
            require(z.testzip() is None and len(items) == len({p.filename for p in items}),
                    'R12_BAD_ZIP')
            for item in items:
                rel = Path(item.filename)
                require(not rel.is_absolute() and '..' not in rel.parts
                        and '\\' not in item.filename and not item.is_dir()
                        and (item.external_attr >> 16 & 0o170000) != 0o120000,
                        'UNSAFE_R12_ZIP')
            z.extractall(destination)
    r12 = load(destination / 'Tools/restore_spf.py', 'r13_r12_helper')
    r12.verify_package()
    return r12, r12.helper()


def pins():
    result = json.loads((ROOT / 'References/CPU_FILE_PINS.json').read_text())
    require(set(result) == set(FILES), 'CPU_PATCH_SCOPE_CHANGED')
    return result


def apply_source(source):
    source = Path(source).resolve(strict=True)
    locked = pins()
    for name, item in locked.items():
        path = source / name
        require(path.is_file() and not path.is_symlink()
                and all(not p.is_symlink() for p in path.parents if p.is_relative_to(source)),
                'UNSAFE_SOURCE:' + name)
        require(sha(path) == item['before_sha256'], 'CPU_PREIMAGE_CHANGED:' + name)
    patch = (ROOT / 'References/RESTORE_CPU_MASK_EXPORTS.patch').resolve()
    for flags in (['--check'], []):
        run = subprocess.run(['git', 'apply', '--whitespace=error', *flags, str(patch)],
                             cwd=source, capture_output=True, text=True)
        require(run.returncode == 0, 'CPU_PATCH_FAILED:' + run.stderr)
    for name, item in locked.items():
        require(sha(source / name) == item['after_sha256'], 'CPU_POSTIMAGE_CHANGED:' + name)
    header = (source / 'include/linux/cpumask.h').read_text()
    require('extern unsigned int nr_cpu_ids;' in header
            and '#elif NR_CPUS <= BITS_PER_LONG' not in header, 'NR_CPU_IDS_NOT_DYNAMIC')
    require('cpumask_set_cpu(cpu, &__cpu_isolated_mask);' in header
            and 'cpumask_clear_cpu(cpu, &__cpu_isolated_mask);' in header,
            'WALT_ISOLATION_HELPERS_LOST')
    require('EXPORT_SYMBOL(nr_cpu_ids);' in (source / 'kernel/smp.c').read_text()
            and 'EXPORT_SYMBOL(cpumask_next);' in (source / 'lib/cpumask.c').read_text(),
            'REAL_EXPORT_DEFINITIONS_MISSING')
    return {'changed_files': 3, 'reversed_commit': 'eb53cd69fe9e420ec1684bcebc5429e9e59ed169',
            'dynamic_nr_cpu_ids_restored': True, 'walt_cpu_isolation_preserved': True,
            'source_pins': locked}


def verify_abi(actual, reference, expected):
    for name, crc in EXPECTED_EXPORTS.items():
        require(expected[name] == crc and actual.get(name) == crc,
                'RESTORED_EXPORT_NOT_STOCK_COMPATIBLE:' + name)
    lost = sorted(name for name, crc in expected.items()
                  if reference.get(name) == crc and actual.get(name) != crc)
    require(not lost, 'PREVIOUS_STOCK_MATCH_REGRESSED:' + repr(lost))
    return {'restored_stock_exports': EXPECTED_EXPORTS, 'lost_matching_symbols': lost,
            'gained_matching_symbols': sorted(name for name, crc in expected.items()
                                             if reference.get(name) != crc and actual.get(name) == crc)}


def prove_linked_exports(system_map):
    symbols = {}
    for line in Path(system_map).read_text().splitlines():
        fields = line.split()
        if len(fields) == 3:
            symbols[fields[2]] = fields[1]
    require(symbols.get('cpumask_next') in ('T', 't'), 'NO_REAL_CPUMASK_NEXT_CODE')
    require(symbols.get('nr_cpu_ids') in ('D', 'd', 'B', 'b'), 'NO_REAL_NR_CPU_IDS_DATA')
    require(all('__ksymtab_' + name in symbols for name in EXPECTED_EXPORTS),
            'RESTORED_EXPORT_TABLE_ENTRIES_MISSING')
    return {name: symbols[name] for name in EXPECTED_EXPORTS}


def build(args):
    verify_package()
    r12, h = dependency()
    r6 = load(Path(args.r6_tool), 'r13_r6_verifier')
    src = Path(args.source).resolve(strict=True)
    obj = Path(args.objout).resolve(strict=True)
    out = Path(args.output).resolve()
    ws = Path(os.environ['GITHUB_WORKSPACE']).resolve(strict=True)
    project = Path(args.project).resolve(strict=True)
    require(not out.exists() and out.is_relative_to(ws), 'OUTPUT_MUST_BE_NEW_IN_WORKSPACE')
    require(src.is_relative_to(ws) and obj.is_relative_to(ws)
            and not out.is_relative_to(src) and not out.is_relative_to(obj)
            and not out.is_relative_to(project) and not src.is_relative_to(project), 'UNSAFE_OUTPUT')
    base = json.loads(Path(args.r6_report).read_text())
    require(base['status'] == 'R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH', 'R6_NOT_GREEN')
    require(sha(obj / '.config') == h.CONFIG_SHA and sha(obj / 'Module.symvers') == h.SYMVERS_SHA,
            'R6_BASELINE_CHANGED')
    require(sha(obj / 'arch/arm64/boot/Image') == base['image_sha256'], 'R6_IMAGE_CHANGED')
    guards = {name: sha(obj / name) for name in ('.config', 'Module.symvers', 'arch/arm64/boot/Image')}
    expected, imports = h.references()
    r12_symbols = h.parse_symvers(ROOT / 'References/R12_Module.symvers')
    _, _, counts_before = h.compare(r12_symbols, expected, imports)
    require(counts_before == dict(MATCH=578, CRC_MISMATCH=841, NOT_EXPORTED=4), 'R12_COUNTS_CHANGED')
    original_config = r12.config_values((obj / '.config').read_text())
    commands = {row['target']: row['invocation'] for row in base['make_results']}
    require(set(commands) == {'Image', 'dtbs', 'modules'}, 'MISSING_BASELINE_MAKE_TARGETS')
    out.mkdir(parents=True)
    result = dict(status='R13_BUILD_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  flash_allowed=False, device_boot_tested=False, make_results=[],
                  baseline_run=43229618525, baseline_r12_qgki_counts=counts_before)
    try:
        candidate = out / 'candidate-source'
        candidate_out = out / 'candidate-out'
        shutil.copytree(src, candidate, ignore=shutil.ignore_patterns('.git'), symlinks=True)
        candidate_out.mkdir()
        shutil.copyfile(obj / '.config', candidate_out / '.config')
        result['r11_iommu'] = h.apply_scoped(candidate, h.generated_patches())
        result['r11_dependencies'] = h.audit_dependencies(candidate)
        result['r12_spf'] = r12.apply_source(candidate)
        result['r13_cpu_exports'] = apply_source(candidate)
        request = subprocess.run(['bash', str(candidate / 'scripts/config'), '--file',
                                  str(candidate_out / '.config'), '-e', 'SPECULATIVE_PAGE_FAULT'],
                                 capture_output=True, text=True)
        require(request.returncode == 0, 'SPF_CONFIG_REQUEST_FAILED:' + request.stderr)
        targets = (['olddefconfig'] + sorted(set(r12.object_targets(obj)
                   + ['kernel/smp.o', 'lib/cpumask.o'])) + ['Image', 'dtbs', 'modules'])
        resolved_sha = None
        for target in targets:
            argv = list(commands.get(target, commands['Image']))
            require(argv[0] == 'make' and argv.count('-C') == 1
                    and argv[argv.index('-C') + 1] == str(src), 'INVALID_BASE_SOURCE_COMMAND')
            require(argv.count('O=' + str(obj)) == 1, 'INVALID_BASE_OUTPUT_COMMAND')
            argv[argv.index('-C') + 1] = str(candidate)
            argv[argv.index('O=' + str(obj))] = 'O=' + str(candidate_out)
            argv[-1] = target
            row = h.run_make(argv, out, target.replace('/', '_'), r6.pinned_llvm_tool_env(argv))
            row['target'] = target
            result['make_results'].append(row)
            require(row['exit_code'] == 0, 'ARM64_BUILD_FAILED:' + target)
            if target == 'olddefconfig':
                result['config_delta_against_r6'] = r12.verify_config(original_config,
                    r12.config_values((candidate_out / '.config').read_text()))
                require((candidate_out / '.config').read_bytes()
                        == (ROOT / 'References/R12.config').read_bytes(), 'CONFIG_MUST_REMAIN_EXACT_R12')
                resolved_sha = sha(candidate_out / '.config')
            require(sha(candidate_out / '.config') == resolved_sha, 'CONFIG_DRIFT_DURING_BUILD')
        require(r6.is_arm64_image(candidate_out / 'arch/arm64/boot/Image')
                and r6.is_arm64_elf(candidate_out / 'vmlinux'), 'NOT_AN_ARM64_KERNEL')
        result['release'] = r6.verify_generated_release(candidate_out)
        result['rmnet_initcalls'] = r6.prove_real_linked_initcalls(candidate_out / 'System.map')
        result['real_build_log'] = r6.prove_build_log(out / 'Image.log')
        require(result['real_build_log']['linker_warning_free'], 'LINKER_WARNINGS')
        result['linked_cpu_exports'] = prove_linked_exports(candidate_out / 'System.map')
        actual = h.parse_symvers(candidate_out / 'Module.symvers')
        rows, modules, counts = h.compare(actual, expected, imports)
        h.save_csv(out / 'QGKI_1423_SYMBOL_RESULTS.csv', rows)
        h.save_csv(out / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result.update(kernel_compiled=True, qgki_counts=counts,
                      module_layout_crc=actual.get('module_layout'),
                      fully_matching_modules=sum(row['fully_compatible'] for row in modules),
                      artifacts={name: sha(candidate_out / name) for name in
                                 ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux')})
        result['abi_progress'] = verify_abi(actual, r12_symbols, expected)
        result['status'] = 'R13_FULL_ARM64_BUILD_AND_CPU_EXPORT_REPAIR_PROVEN_NOFLASH'
    except Exception as error:
        result.update(status='R13_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        result['r6_baseline_unchanged'] = all(sha(obj / name) == digest for name, digest in guards.items())
        write_json(out / 'R13_RESULT.json', result)
    require(result['r6_baseline_unchanged'], 'R6_BASELINE_MUTATED')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    patch = sub.add_parser('patch-source')
    patch.add_argument('--source', required=True)
    full = sub.add_parser('build')
    for name in ('source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        full.add_argument('--' + name, required=True)
    args = parser.parse_args()
    if args.operation == 'verify-package':
        verify_package()
        dependency()
        print('R13_PACKAGE_AND_R12_R11_DEPENDENCIES_AUTHENTICATED')
    elif args.operation == 'patch-source':
        verify_package()
        print(json.dumps(apply_source(args.source), sort_keys=True))
    else:
        build(args)


if __name__ == '__main__':
    main()
