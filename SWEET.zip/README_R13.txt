SWEET R13-Mobil-1 – R12-Konsolidierung und Stock-PD-Parserprüfung
04.10.2026

INSTALLATION AM HANDY
Nur diese SWEET.zip unentpackt im Repository-Hauptverzeichnis ersetzen.
Nicht nach .github/workflows hochladen. Keine YAML ersetzen.
Danach Actions -> SWEET -> Run workflow -> main.

INHALT
R12-B bleibt der direkte Elternstand. Acht R12-A-exklusive Quelldateiänderungen
werden wiederhergestellt. B-exklusive DisplayPort/Kamera-Korrekturen bleiben.
Der RNG-Code aus B bleibt unverändert; er enthält zusätzlich zu A die Rücksetzung
der lokalen Bus-Client-Kennung. Die gemeinsame SELinux-Korrektur ist identisch.
Konsolidierter Bereich: 13 Dateien / 17 unterschiedliche R12-Warnstellen.
R13 baut auf beiden geprüften R12-Ständen auf, nicht auf einer willkürlich als
"neuer" bezeichneten R12-Kopie. Die neuen Hash-/Dateimengenprüfungen verhindern
unbemerkten Verlust eines der hier konsolidierten Stände.

STOCK-LADEN
Die Original-DTBO wird NICHT verändert. Ein Rohfragment des SWEET-Overlays wird
nur als nicht flashbare Testreferenz mitgeführt. Der Test prüft die echte
pd_policy_parse_dt-Funktion mit simulierten Gerätebaumzugriffen. Die Werte aus
Stock (6000/3000, zweite Ladepumpe aus) und aus der K6A-Quelldatei (12000/6100,
zweite Ladepumpe an) werden getrennt getestet. Das sind Parameterwerte, keine
Freigabe dieser Ladeströme. Der vollständige Ladealgorithmus, Hardware und der
vom Bootloader ausgewählte zusammengesetzte Gerätebaum sind NICHT geprüft.

LOKALE PRÜFUNG
281 Selbsttests erfolgreich (211 bisher gemeinsam, 22 R12-B, 28 R12-A,
20 neue R13-Prüfungen). Historische A-Tests haben nur umbenannte Import-/Referenz-
pfade; zusätzlich werden ihre Verhaltenstests auf dem konsolidierten Code geprüft.
Bisherige Verhaltenstestgruppen erfolgreich; 17 neue PD-Parserfälle erfolgreich,
zwei absichtlich falsche PD-Varianten erkannt. Zwei echte olddefconfig-Aufrufe:
bytegleiche Konfiguration mit 4987 Einstellungen. Vollständige Quellbaumidentität
und alle Patch-/Quelldateihashes auf separater OEM-Kopie bestätigt.

KEIN NEUER LOKALER VOLLBUILD
In diesem Schritt wurde kein neuer vollständiger Kernel kompiliert und keine
neue Module.symvers erzeugt. Keine Aussage über bereits bestandenen R13-CI-Build.
Der nächste GitHub-Lauf soll mit der bisherigen Clang-14-Toolchain die gesamte
konsolidierte Basis bauen und Konfiguration, Export-CRC und alle Zielwarnungen
prüfen. Ein grüner Lauf ist keine Stock-/Hardware-/Flashfreigabe.

OFFEN
Stock-/Vendor-/DTB-/DTBO-Abgleich, kompletter Ladepfad, 13 aktive Stock-Abweichungen,
4.14.180 gegenüber Stock 4.14.190, Root-Integration. Kein ReSukiSU/SUSFS/NoMount,
kein AK3, keine boot.img. Nicht flashen. Die YAML und GitHub-Dateien wurden hier
nicht verändert. Alte Berichte unter docs sind historische Belege, keine
Ergebnisse dieses neuen Laufs.
