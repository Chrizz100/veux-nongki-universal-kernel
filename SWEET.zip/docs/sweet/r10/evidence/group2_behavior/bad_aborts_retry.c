
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
typedef uint8_t u8; typedef uint16_t u16;
enum FW_STATUS { FTS_RUN_IN_ERROR, FTS_RUN_IN_APP, FTS_RUN_IN_ROM, FTS_RUN_IN_PRAM, FTS_RUN_IN_BOOTLOADER };
struct fts_upgrade {int unused;};
#define FTS_UPGRADE_LOOP 30
#define FTS_DELAY_READ_ID 20
#define FTS_CMD_FLASH_STATUS 0x6a
#define FTS_CMD_FLASH_STATUS_LEN 2
#define FTS_ERROR(...) ((void)0)
static int pattern,read_calls,sleep_calls,ms_total,which_state;
static u16 wanted;
static unsigned cases;
static int next_mode(void){int index=read_calls++;return index<4?(pattern>>(index*2))&3:0;}
static void msleep(int ms){sleep_calls++;ms_total+=ms;}
/* Negative-return contents are unspecified; callers must not trust them. */
static int fts_fwupg_get_boot_state(struct fts_upgrade *upg,enum FW_STATUS *state){
 int mode=next_mode();(void)upg;
 if(mode==1 || mode==3)*state=(enum FW_STATUS)which_state;
 if(mode==2)*state=(enum FW_STATUS)((which_state+1)%5);
 return mode<2?-EIO:0;
}
static int fts_read(u8 *cmd,unsigned cmdlen,u8 *data,unsigned len){
 int mode=next_mode();u16 val;
 if(cmdlen!=1||*cmd!=FTS_CMD_FLASH_STATUS||len!=2)exit(20);
 if(mode==0)return -EIO;
 val=(mode==2)?(u16)(wanted^0x100):wanted;
 data[0]=val>>8;data[1]=val&255;
 return mode<2?-EIO:2;
}
static bool fts_fwupg_check_state(struct fts_upgrade *upg, enum FW_STATUS rstate)
{
	int ret = 0;
	int i = 0;
	enum FW_STATUS cstate = FTS_RUN_IN_ERROR;
	for (i = 0; i < FTS_UPGRADE_LOOP; i++) {
		ret = fts_fwupg_get_boot_state(upg, &cstate);
		if (ret < 0) return false;

		/* FTS_DEBUG("fw state=%d, retries=%d", cstate, i); */
		if (ret >= 0 && cstate == rstate)
			return true;
		msleep(FTS_DELAY_READ_ID);
	}
	return false;
}
static bool fts_fwupg_check_flash_status(u16 flash_status, int retries, int retries_delay)
{
	int ret = 0;
	int i = 0;
	u8 cmd = 0;
	u8 val[FTS_CMD_FLASH_STATUS_LEN] = { 0 };
	u16 read_status = 0;
	for (i = 0; i < retries; i++) {
		cmd = FTS_CMD_FLASH_STATUS;
		ret = fts_read(&cmd, 1, val, FTS_CMD_FLASH_STATUS_LEN);
		/* A failed read must not turn stale status bytes into success. */
		if (ret >= 0) {
			read_status = (((u16) val[0]) << 8) + val[1];
			if (flash_status == read_status) {
				/* FTS_DEBUG("[UPGRADE]flash status ok"); */
				return true;
			}
		}

		/* FTS_DEBUG("flash status fail,ok:%04x read:%04x, retries:%d", flash_status, read_status, i); */
		msleep(retries_delay);
	}
	FTS_ERROR("flash status fail,ok:%04x,read:%04x,retries:%d", flash_status, read_status, i);
	return false;
}
static void reset(int p){pattern=p;read_calls=sleep_calls=ms_total=0;}
static int first_good(int p,int limit){for(int i=0;i<limit;i++)if(i<4 && ((p>>(i*2))&3)==3)return i;return -1;}
static void verify(bool ok,int limit,int delay,const char *name){
 int first=first_good(pattern,limit);bool expected=first>=0;
 int reads=expected?first+1:(limit>0?limit:0);
 int sleeps=expected?first:reads;
 if(ok!=expected||read_calls!=reads||sleep_calls!=sleeps||ms_total!=sleeps*delay){
 fprintf(stderr,"%s case=%u pattern=%d target=%u limit=%d ok=%d expected=%d reads=%d/%d sleeps=%d/%d\n",
 name,cases,pattern,wanted,limit,ok,expected,read_calls,reads,sleep_calls,sleeps);exit(1);}
 cases++;
}
int main(void){struct fts_upgrade u={0};
 for(which_state=0;which_state<5;which_state++)for(int p=0;p<256;p++){
 reset(p);verify(fts_fwupg_check_state(&u,(enum FW_STATUS)which_state),FTS_UPGRADE_LOOP,FTS_DELAY_READ_ID,"boot");}
 const u16 desired[]={0,0xf0aa,0xf055,0xffff};const int retry[]={-1,0,1,2,4,8};
 for(unsigned t=0;t<4;t++)for(unsigned n=0;n<6;n++)for(int p=0;p<256;p++){
 wanted=desired[t];reset(p);verify(fts_fwupg_check_flash_status(wanted,retry[n],7),retry[n],7,"flash");}
 printf("PASS: %u polling scenarios; return values, retry count and delays matched.\n",cases);
 return 0;
}
