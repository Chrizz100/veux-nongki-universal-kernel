SWEET R12-Mobil-1

Nur diese SWEET.zip im Repo-Hauptverzeichnis ersetzen, nicht entpacken.
Actions -> SWEET -> Run workflow -> main. Keine neue YAML.

Sieben Warnstellen, RNG-Probe-Fehlerbehandlung, vollstaendiger Baseline-Build.
233 Selbsttests und 480 simulierte RNG-Szenarien.
Noch kein AK3 und keine boot.img; NICHT FLASHEN.
Lokaler Build: Clang17 mit dokumentierter lokaler HZ-Konstanten-Auswertung.
GitHub: Clang14 mit echtem bc; neuer CI-Pass steht aus.
Details: docs/sweet/r12/PRUEFBERICHT_R12.txt
