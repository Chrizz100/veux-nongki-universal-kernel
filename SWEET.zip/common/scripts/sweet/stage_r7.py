#!/usr/bin/env python3
"""R7: real ARM64 Kbuild preparation and a declared, limited object-build gate.

This is NOT a complete kernel build. No release images are produced.
The original OEM tree and the package are read-only inputs. No remote writes.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import traceback
from typing import Any
import audit
import prepare_candidate_r5 as r5
import stage_r6 as r6

ROOT = Path(__file__).resolve().parents[3]
LOCK_PATH = ROOT / 'lineages/sweet/candidates/r7.json'
OBJECTS = (
    'drivers/mihw/millet_core.o', 'drivers/mihw/millet_pkg.o',
    'drivers/mihw/millet_hs.o', 'kernel/signal.o',
    'drivers/android/binder.o', 'drivers/android/binder_alloc.o',
    'kernel/cgroup/freezer.o', 'drivers/input/fingerprint/fs_tee/sf_ctl.o',
    'drivers/input/fingerprint/fs_tee/sf_hw.o',
    'drivers/input/misc/aw8624_haptic/aw8624.o',
    'drivers/misc/perf_helper.o', 'drivers/power/supply/power_supply_sysfs.o',
)
VDSO_TARGET = 'arch/arm64/kernel/vdso/'
CLANG_FLAGS = '--target=aarch64-linux-gnu -integrated-as -Werror=unknown-warning-option'


def load_lock() -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text(encoding='utf-8'))
    if (lock.get('schema') != 1 or lock.get('stage') != 'r7_arm64_prepare_and_selected_objects'
            or lock.get('flashable') is not False):
        raise ValueError('Invalid R7 manifest or attempted flash approval')
    return lock


def run(argv: list[str], log: Path, *, env: dict[str, str] | None = None,
        timeout: int = 600) -> None:
    print('SWEET R7: ' + ' '.join(argv), flush=True)
    with log.open('ab') as stream:
        stream.write(('$ ' + ' '.join(argv) + '\n').encode()); stream.flush()
        # Kill the entire process group on timeout: make must not outlive its gate.
        import signal
        p = subprocess.Popen(argv, stdout=stream, stderr=subprocess.STDOUT,
                             env=env, start_new_session=True)
        try:
            result = p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid, signal.SIGTERM)
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL); p.wait()
            raise RuntimeError(f'Timeout; see {log.name}') from None
    if result:
        raise RuntimeError(f'Command exited {result}; see {log.name}')


def tools(stage: Path) -> dict[str, str]:
    local = os.environ.get('SWEET_LOCAL_TOOLCHAIN') == '1'
    if local and os.environ.get('GITHUB_ACTIONS') == 'true':
        raise ValueError('Local toolchain override is forbidden on GitHub Actions')
    if local:
        names = dict(cc='clang', ld='ld.lld', ar='llvm-ar', nm='nm',
                     objcopy='llvm-objcopy', objdump='llvm-objdump', readelf='readelf')
    else:
        # Distribution-maintained, explicit major version; not an exact stock compiler.
        names = dict(cc='clang-14', ld='ld.lld-14', ar='llvm-ar-14', nm='llvm-nm-14',
                     objcopy='llvm-objcopy-14', objdump='llvm-objdump-14', readelf='llvm-readelf-14')
    required = list(names.values()) + ['make', 'gcc', 'g++', 'git', 'bc']
    if not local or not all(shutil.which(t) for t in required):
        if local:
            raise RuntimeError('Local tools missing; no automatic replacement')
        run(['sudo','-n','apt-get','update'],stage/'tools.log')
        run(['sudo','-n','apt-get','install','--no-install-recommends','-y',
             'build-essential','clang-14','lld-14','llvm-14','binutils','bc',
             'flex','bison','libssl-dev','libelf-dev','git'],stage/'tools.log')
    if not all(shutil.which(t) for t in required):
        raise RuntimeError('Required compiler/build tools missing')
    version = subprocess.check_output([names['cc'],'--version'],text=True)
    if not local and not re.search(r'clang version 14\.',version):
        raise ValueError('Expected the explicit Clang 14 diagnostic toolchain')
    identity = {}
    for name in dict.fromkeys(required):
        path = Path(shutil.which(name)).resolve()
        identity[name] = {'path':str(path),'sha256':audit.sha256(path)}
    audit.write_json(stage/'tool_binaries.json',identity)
    for argv in ([names['cc'],'--version'],[names['ld'],'--version'],['gcc','--version'],
                 ['make','--version'],['bc','--version']):
        run(argv,stage/'environment.log')
    return names


def make_command(source: Path, build: Path, tool: dict[str,str]) -> list[str]:
    # This 4.14 Makefile unconditionally appends -no-integrated-as and has no
    # LLVM_IAS switch. Explicit CLANG_FLAGS is its existing override interface.
    return ['make','-C',str(source),f'O={build}','ARCH=arm64',
            f'CC={tool["cc"]}','HOSTCC=gcc','HOSTCXX=g++',f'LD={tool["ld"]}',
            f'AR={tool["ar"]}',f'NM={tool["nm"]}',f'OBJCOPY={tool["objcopy"]}',
            f'OBJDUMP={tool["objdump"]}',f'READELF={tool["readelf"]}',
            'CROSS_COMPILE=aarch64-linux-gnu-','CLANG_TRIPLE=aarch64-linux-gnu-',
            f'CLANG_FLAGS={CLANG_FLAGS}','HOSTCFLAGS=-O2 -fcommon', 'V=1']


def elf_check(path: Path, kind: int) -> dict[str, Any]:
    data = path.read_bytes()
    if len(data) < 64 or data[:7] != b'\x7fELF\x02\x01\x01':
        raise ValueError(f'Not ELF64 little endian: {path.name}')
    filetype, machine = struct.unpack_from('<HH', data, 16)
    if machine != 183 or filetype != kind:
        raise ValueError(f'Unexpected ELF architecture/type: {path.name}')
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'machine':'AArch64','elf_class':64,'type':filetype}


def config_gate(text: str, reference_text: str) -> dict[str, Any]:
    values = audit.parse_config(text)['values']
    ref = audit.parse_config(reference_text)['values']
    delta = audit.compare_configs(ref,values)
    if delta['changed'] or delta['added'] or delta['missing']:
        raise ValueError('R7 unexpectedly changes the resolved R6 configuration')
    return {'r6_values_preserved':len(values),'changed':0,'added':0,'removed':0}


def check_power_tables(source: Path, stage: Path, env: dict[str,str]) -> None:
    """Compile/run extracted declarations for both battery-verification settings.

    This checks index/table alignment, NOT the ABI of installed vendor binaries.
    """
    h=(source/'include/linux/power_supply.h').read_text()
    h=h.split('enum power_supply_property {',1)[1].split('};',1)[0]
    s=(source/'drivers/power/supply/power_supply_sysfs.c').read_text()
    s=s.split('static struct device_attribute power_supply_attrs[] = {',1)[1].split('};',1)[0]
    code=('#include <stdio.h>\n#include <string.h>\nenum power_supply_property {'+h+'};\n'
          '#define POWER_SUPPLY_ATTR(n) #n\nstatic const char *attrs[] = {'+s+'};\n'
          '_Static_assert(sizeof(attrs)/sizeof(attrs[0]) == POWER_SUPPLY_PROP_CYCLE_COUNTS + 1,"index/table count");\n'
          'int main(void){unsigned n=0;for(unsigned i=0;i<sizeof(attrs)/sizeof(attrs[0]);i++)'
          'n+=!strcmp(attrs[i],"chip_ok");if(n!=1||strcmp(attrs[POWER_SUPPLY_PROP_CHIP_OK],"chip_ok"))return 1;'
          'printf("entries=%zu CHIP_OK=%d MODEL_NAME=%d\\n",sizeof(attrs)/sizeof(attrs[0]),'
          'POWER_SUPPLY_PROP_CHIP_OK,POWER_SUPPLY_PROP_MODEL_NAME);return 0;}\n')
    c=stage/'power_table_test.c';c.write_text(code)
    for enabled in (False,True):
        exe=stage/f'power_table_{int(enabled)}'
        argv=['gcc','-std=gnu11','-Wall','-Wextra','-Werror']
        if enabled: argv+=['-DCONFIG_BATT_VERIFY_BY_DS28E16=1']
        run(argv+[str(c),'-o',str(exe)],stage/'power_table_test.log',env=env)
        run([str(exe)],stage/'power_table_test.log',env=env)
        exe.unlink()  # host-only helper is not an artifact


def run_stage(output: Path) -> dict[str,Any]:
    stage=output/'R7';stage.mkdir(exist_ok=False)
    work=Path(os.environ['SWEET_WORK']).resolve()
    if (work == ROOT or work.is_relative_to(ROOT) or ROOT.is_relative_to(work)
            or output.is_relative_to(work) or work.is_relative_to(output)):
        raise ValueError('Work/output/package directories must be disjoint')
    work.mkdir(parents=True,exist_ok=False)
    report={'stage':'R7 ARM64 prepare + 12 declared Kbuild objects','completed':False,
            'kernel_built':False,'full_kernel_build_executed':False,'flashable':False,
            'device_tested':False,'stock_vendor_abi_validated':False,
            'toolchain_is_stock':False,'new_oem_kconfig_run':False,
            'note':'PASS applies only to the declared preparation/object gate. Not a complete kernel build.'}
    source=None;candidate=None;before=None
    try:
        lock=load_lock();tool=tools(stage)
        report['toolchain']=tool
        source=Path(os.environ['SWEET_LOCAL_SOURCE']).resolve() if os.environ.get('SWEET_LOCAL_SOURCE') else work/'oem'
        if not os.environ.get('SWEET_LOCAL_SOURCE'):
            audit.acquire_source(r6.BASE_REPO,lock['base_commit'],source,stage/'fetch.log')
        combined=json.loads((ROOT/'lineages/sweet/candidates/r5.json').read_text())
        l6=r6.load_lock()
        combined['patches']+=l6['patches']+lock['patches']
        combined['changed_files']+=l6['changed_from_r5']+lock['changed_from_r6']
        candidate=work/'candidate'
        preparation=r5.prepare(source,candidate,combined,ROOT)
        if preparation['candidate_tree_before_make']!=lock['candidate_tree']:
            raise ValueError('Full R7 candidate tree mismatch')
        preparation['note']='R7 prepared source only; no release approval'
        audit.write_json(stage/'preparation.json',preparation)
        _,before=r5.tree_identity(candidate)
        build=work/'build';build.mkdir()
        (build/'.config').write_bytes((ROOT/'device/sweet/reference/stock.config').read_bytes())
        command=make_command(candidate,build,tool)
        env=dict(os.environ,PATH=str(Path(shutil.which(tool['cc'])).resolve().parent)+os.pathsep+os.environ['PATH'],KBUILD_BUILD_TIMESTAMP='Sat Oct 3 00:00:00 UTC 2026',
                 KBUILD_BUILD_USER='builder',KBUILD_BUILD_HOST='sweet',KBUILD_BUILD_VERSION='1')
        for i in (1,2):
            run(command+['olddefconfig'],stage/f'olddefconfig_{i}.log',env=env)
            if i==1: first=(build/'.config').read_bytes()
            elif (build/'.config').read_bytes()!=first:
                raise ValueError('Non-idempotent configuration')
        reference=(ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_text()
        report['config_gate']=config_gate(first.decode(),reference)
        report['new_oem_kconfig_run']=True
        for i in (1,2):
            if any('Kconfig' in l and 'warning:' in l for l in (stage/f'olddefconfig_{i}.log').read_text().splitlines()):
                raise ValueError('Kconfig parser warning')
        check_power_tables(candidate,stage,env)
        jobs=str(min(4,os.cpu_count() or 1))
        for target in ('prepare','scripts','modules_prepare'):
            run(command+['-j'+jobs,target],stage/f'{target}.log',env=env,timeout=900)
            report[target+'_passed']=True
        # prepare generates vdso.so.dbg/offsets; build the declared VDSO directory
        # explicitly to obtain its stripped .so and wrapper, without a full kernel.
        run(command+['-j'+jobs,VDSO_TARGET],stage/'vdso_build.log',env=env,timeout=900)
        report['vdso_build_passed']=True
        vdso=build/'arch/arm64/kernel/vdso/vdso.so'
        report['vdso']=elf_check(vdso,3)
        symbols=subprocess.check_output([tool['nm'],'-D',str(build/'arch/arm64/kernel/vdso/vdso.so.dbg')],text=True)
        for symbol in ('__kernel_clock_gettime','__kernel_gettimeofday','__kernel_clock_getres','__kernel_rt_sigreturn'):
            if not re.search(r'\b'+symbol+r'\b',symbols): raise ValueError('Missing VDSO export: '+symbol)
        (stage/'vdso_symbols.txt').write_text(symbols)
        shutil.copy2(vdso,stage/'vdso.so')
        run(command+['-j'+jobs,*OBJECTS],stage/'selected_objects.log',env=env,timeout=900)
        report['objects']={p:elf_check(build/p,1) for p in OBJECTS}
        objdir=stage/'objects';objdir.mkdir()
        for p in OBJECTS: shutil.copy2(build/p,objdir/p.replace('/','__'))
        # Isolate the original seven MILLET/IPC objects for their relocatable link.
        partial=stage/'millet_partial.o'
        run([tool['ld'],'-r',*[str(build/p) for p in OBJECTS[:7]],'-o',str(partial)],stage/'partial_link.log',env=env)
        report['partial_link']=elf_check(partial,1)
        undefined=subprocess.check_output([tool['nm'],'-u',str(partial)],text=True)
        if re.search(r'\b(?:millet_\w+|frozen_uid_min|(?:un)?register_millet_hook)\b',undefined):
            raise ValueError('MILLET symbol unresolved in partial link')
        (stage/'partial_undefined.txt').write_text(undefined)
        shutil.copy2(build/'.config',stage/'resolved.config')
        if (build/'.config').read_bytes()!=first:
            raise ValueError('Build changed the configuration')
        stock=audit.parse_config((ROOT/'device/sweet/reference/stock.config').read_text())['values']
        current=audit.parse_config(first.decode())['values']
        missing=[{'symbol':k,'stock':v,'candidate':current.get(k)} for k,v in sorted(stock.items()) if v in ('y','m') and current.get(k)!=v]
        if sorted(x['symbol'] for x in missing)!=sorted(l6['expected_active_missing']):
            raise ValueError('Unexpected change to remaining stock differences')
        audit.write_json(stage/'stock_gaps.json',missing)
        report['active_stock_missing']=len(missing)
        _,after=r5.tree_identity(candidate)
        audit.write_json(stage/'source_state.json',r6.generated_state(candidate,before,after))
        if r5.tree_identity(source)[0]!=lock['base_tree']:
            raise ValueError('OEM input tree changed')
        report.update(completed=True,source_unchanged=True,stock_compatibility_passed=False)
        print('::warning::SWEET R7: Build-Vorbereitung und 12 Kbuild-Objekte bestanden. Kein vollstaendiger Kernel; 13 Stock-Abweichungen bleiben offen.',flush=True)
        return report
    except Exception as exc:
        report['error']=str(exc)
        (stage/'failure.log').write_text(traceback.format_exc())
        raise
    finally:
        # Always preserve warnings, including warnings from failed invocations.
        warnings={p.name:[l for l in p.read_text(errors='replace').splitlines() if 'warning:' in l]
                  for p in stage.glob('*.log')}
        audit.write_json(stage/'warnings.json',warnings)
        audit.write_json(stage/'report.json',report)
        audit.save_checksums(stage)
