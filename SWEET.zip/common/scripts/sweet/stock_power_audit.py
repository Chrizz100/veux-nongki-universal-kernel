"""Read-only check of the selected original SWEET overlay and PD parser.
No DTB/DTBO installation, electrical test, or stock-compatibility approval.
"""
from __future__ import annotations
from pathlib import Path
import hashlib,json,struct,re,subprocess,os
from group3_validation import function
import stage_r7 as r7
ROOT=Path(__file__).resolve().parents[3]
REF=ROOT/'device/sweet/reference/r13'
DRIVER='drivers/power/supply/ti/pd_policy_manager.c'
DTS='arch/arm64/boot/dts/qcom/sweet-sdmmagpie.dtsi'
KEYS=('mi,pd-bat-volt-max','mi,pd-bat-curr-max','mi,pd-bus-volt-max',
      'mi,pd-bus-curr-max','mi,pd-bus-curr-compensate','mi,pd-ffc-bat-volt-max')
BOOLS=('mi,cp-sec-enable','mi,disable-taper-fcc')
FIELDS=('bat_volt_max','bat_curr_max','bus_volt_max','bus_curr_max','bus_curr_compensate','ffc_bat_volt_max')

def fdt_nodes(data:bytes)->dict:
    if len(data)<40: raise ValueError('Short FDT')
    magic,total,so,ss,rs,ver,last,cpu,slen,stlen=struct.unpack_from('>10I',data)
    if magic!=0xd00dfeed or total!=len(data) or so+stlen>total or ss+slen>total:
        raise ValueError('Bad FDT bounds')
    strings=data[ss:ss+slen];p=so;end=so+stlen;stack=[];nodes={};ended=False
    while p+4<=end:
        tok=struct.unpack_from('>I',data,p)[0];p+=4
        if tok==1:
            try:q=data.index(0,p,end)
            except ValueError:raise ValueError('Missing node terminator')
            stack.append(data[p:q].decode());p=(q+4)&~3
            name='/'+ '/'.join(x for x in stack if x)
            if name in nodes:raise ValueError('Duplicate node')
            nodes[name]={}
        elif tok==2:
            if not stack:raise ValueError('Unbalanced node')
            stack.pop()
        elif tok==3:
            if p+8>end or not stack:raise ValueError('Invalid property')
            n,i=struct.unpack_from('>2I',data,p);p+=8
            if p+n>end or i>=slen:raise ValueError('Invalid property bounds')
            q=strings.find(b'\0',i)
            if q<0:raise ValueError('Missing property name terminator')
            k=strings[i:q].decode();props=nodes['/'+ '/'.join(x for x in stack if x)]
            if k in props:raise ValueError('Duplicate property')
            props[k]=data[p:p+n];p=(p+n+3)&~3
        elif tok==4:pass
        elif tok==9:
            if stack:raise ValueError('Unclosed node')
            ended=True;break
        else:raise ValueError('Unknown FDT token')
    if not ended:raise ValueError('Missing FDT end')
    return nodes

def profile_from_overlay(data:bytes)->dict:
    nodes=fdt_nodes(data)
    if nodes.get('/',{}).get('model')!=b'SWEET\0':raise ValueError('Not SWEET')
    hits=[v for k,v in nodes.items() if k.endswith('/usbpd_pm') and v.get('compatible')==b'xiaomi,usbpd-pm\0']
    if len(hits)!=1:raise ValueError('Ambiguous PD node')
    p=hits[0];ret={}
    for k in KEYS:
        if len(p.get(k,b''))!=4:raise ValueError('Missing scalar '+k)
        ret[k]=struct.unpack('>I',p[k])[0]
    for k in BOOLS:
        if k in p and p[k]!=b'':raise ValueError('Non-boolean '+k)
        ret[k]=k in p
    return ret

def profile_from_dts(text:str)->dict:
    text=re.sub(r'/\*.*?\*/|//[^\n]*','',text,flags=re.S)
    m=re.search(r'\busbpd_pm\s*\{([^{}]*)\}',text)
    if not m:raise ValueError('Expected single literal PD node')
    b=m[1];ret={}
    for k in KEYS:
        hits=re.findall(re.escape(k)+r'\s*=\s*<\s*(0x[0-9a-fA-F]+|[0-9]+)\s*>\s*;',b)
        if len(hits)!=1:raise ValueError('Missing/ambiguous literal '+k)
        ret[k]=int(hits[0],0)
    for k in BOOLS:ret[k]=bool(re.search(re.escape(k)+r'\s*;',b))
    return ret

def parser_harness(driver:str,profiles:list[dict])->str:
    fields='; '.join('unsigned '+n for n in FIELDS)+';'
    keylist=','.join(json.dumps(x) for x in KEYS)
    table=',\n'.join('{ {'+','.join(str(p[k]) for k in KEYS)+'}, '+str(int(p[BOOLS[0]]))+', '+str(int(p[BOOLS[1]]))+'}' for p in profiles)
    code=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#define pr_info(...) ((void)0)
#define pr_err(...) ((void)0)
#define REQUIRE(x) do {if(!(x)){fprintf(stderr,"ORACLE PD line=%d\n",__LINE__);exit(1);}}while(0)
struct device_node {unsigned value[6];bool sec,taper;};
struct device {struct device_node *of_node;};
struct usbpd_pm {struct device *dev;FIELDS bool cp_sec_enable,disable_taper_fcc;};
struct cfg {unsigned bat_volt_lp_lmt,bat_curr_lp_lmt,bus_volt_lp_lmt,bus_curr_lp_lmt,bus_curr_compensate;bool cp_sec_enable;};
static struct cfg pm_config;
static const char *keys[6]={KEYLIST};
static int reads,bool_reads;
static int of_property_read_u32(struct device_node *n,const char *k,unsigned *out){reads++;for(int i=0;i<6;i++)if(!strcmp(k,keys[i])){*out=n->value[i];return 0;}return -EINVAL;}
static bool of_property_read_bool(struct device_node *n,const char *k){bool_reads++;if(!strcmp(k,"mi,cp-sec-enable"))return n->sec;if(!strcmp(k,"mi,disable-taper-fcc"))return n->taper;return false;}
'''.replace('FIELDS',fields).replace('KEYLIST',keylist)+function(driver,'pd_policy_parse_dt')+r'''
int main(void){
struct device_node profiles[]={TABLE};
unsigned cases=0;
for(unsigned k=0;k<sizeof(profiles)/sizeof(profiles[0]);k++)for(unsigned seed=0;seed<8;seed++){
struct device d={&profiles[k]};struct usbpd_pm pm={.dev=&d};
pm_config=(struct cfg){seed,seed,seed,seed,seed,seed&1};reads=bool_reads=0;
REQUIRE(pd_policy_parse_dt(&pm)==0);REQUIRE(reads==6&&bool_reads==2);
REQUIRE(pm_config.bat_volt_lp_lmt==profiles[k].value[0]);
REQUIRE(pm_config.bat_curr_lp_lmt==profiles[k].value[1]);
REQUIRE(pm_config.bus_volt_lp_lmt==profiles[k].value[2]);
REQUIRE(pm_config.bus_curr_lp_lmt==profiles[k].value[3]);
REQUIRE(pm_config.bus_curr_compensate==profiles[k].value[4]);
REQUIRE(pm.ffc_bat_volt_max==profiles[k].value[5]);
REQUIRE(pm.cp_sec_enable==profiles[k].sec&&pm_config.cp_sec_enable==profiles[k].sec);
REQUIRE(pm.disable_taper_fcc==profiles[k].taper);cases++;}
struct device d={0};struct usbpd_pm pm={.dev=&d};reads=bool_reads=0;
REQUIRE(pd_policy_parse_dt(&pm)==-EINVAL);REQUIRE(!reads&&!bool_reads);cases++;
printf("PASS pd_parser cases=%u\n",cases);return 0;}
'''.replace('TABLE',table)
    return code

def run(candidate:Path,stage:Path,tool:dict)->dict:
    out=stage/'stock_power';out.mkdir(exist_ok=False)
    receipt=json.loads((REF/'stock_receipt.json').read_text());data=(REF/'stock_sweet_overlay.dtb').read_bytes()
    if hashlib.sha256(data).hexdigest()!=receipt['overlay_sha256']:raise ValueError('Stock fixture integrity')
    stock=profile_from_overlay(data);oem=profile_from_dts((candidate/DTS).read_text())
    original=(REF/'pd_policy_parse_dt.c').read_text();driver=(candidate/DRIVER).read_text()
    if function(driver,'pd_policy_parse_dt')!=original:raise ValueError('Unexpected PD parser change')
    variants={'current':driver,'bad_ignores_stock_limit':driver.replace('pm_config.bat_curr_lp_lmt = pdpm->bat_curr_max;','pm_config.bat_curr_lp_lmt = 12000;'),'bad_forces_second_pump':driver.replace('pm_config.cp_sec_enable = pdpm->cp_sec_enable;','pm_config.cp_sec_enable = true;')}
    tests={}
    for name,text in variants.items():
        c=out/(name+'.c');exe=out/name;c.write_text(parser_harness(text,[stock,oem]))
        r7.run([tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-o',str(exe)],out/(name+'_build.log'),timeout=90)
        p=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
        text=p.stdout+p.stderr;(out/(name+'_run.log')).write_text(text);exe.unlink()
        if name=='current':
            if p.returncode or 'PASS pd_parser cases=17' not in text:raise ValueError('PD profile parsing failed: '+text)
        elif p.returncode!=1 or 'ORACLE PD' not in text:raise ValueError('Negative PD test missed: '+name)
        tests[name]={'exit_code':p.returncode,'expected_result':True}
    result={'stock_profile':stock,'k6a_source_profile':oem,'differences':{k:{'stock':stock[k],'k6a':oem[k]} for k in stock if stock[k]!=oem[k]},'parser_scenarios':17,'tests':tests,'stock_overlay_sha256':receipt['overlay_sha256'],'stock_parser_values_honoured':True,'dtb_dtbo_built':False,'runtime_selected_tree_known':False,'driver_electrical_behavior_validated':False,'stock_compatibility_passed':False,'action':'Preserve stock DTB/DTBO for candidate packaging; never substitute K6A trees without review.'}
    (out/'report.json').write_text(json.dumps(result,indent=2)+'\n');return result
