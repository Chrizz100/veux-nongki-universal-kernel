"""R12: extracted-function regression checks with mocked kernel APIs.
Tests probe unwind, hotplug failure, configuration-sensitive node/quota paths.
This is not a device test, entropy-quality test or concurrency audit.
"""
from __future__ import annotations
import hashlib,json,os,re,subprocess
from pathlib import Path
import stage_r7 as r7
from group3_validation import function
ROOT=Path(__file__).resolve().parents[3]
LOCK=ROOT/'lineages/sweet/candidates/r12a.json'
RNG='drivers/char/hw_random/msm_rng.c'
TRACE='arch/arm64/kernel/perf_trace_counters.c'
VMSCAN='mm/vmscan.c'
QUOTA='fs/quota/dquot.c'
COMMON=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
static unsigned cases;
#define REQUIRE(c) do {if(!(c)){fprintf(stderr,"ORACLE: line=%d case=%u: %s\n",__LINE__,cases,#c);exit(1);}}while(0)
#define __init
#define __iomem
#define pr_err(...) ((void)0)
#define dev_err(...) ((void)0)
#define ERR_PTR(e) ((void *)(intptr_t)(e))
#define PTR_ERR(p) ((long)(intptr_t)(p))
#define IS_ERR(p) ((uintptr_t)(p)>=(uintptr_t)-4095)
'''
def rng_harness(text:str)->str:
 return COMMON+r'''
#define IORESOURCE_MEM 1
#define GFP_KERNEL 0
#define DRIVER_NAME "msm_rng"
#define QRNG_IOC_MAGIC 113
#define THIS_MODULE NULL
#define MKDEV(a,b) (((a)<<8)|(b))
struct device {void *of_node;};
struct platform_device {struct device dev;void *data;};
struct resource {unsigned long start;};
struct clk {int unused;};
struct msm_bus_scale_pdata {int unused;};
struct msm_rng_device {struct platform_device *pdev;void *base;struct clk *prng_clk;uint32_t qrng_perf_client;int rng_lock;};
struct hwrng {unsigned long priv;};
static struct msm_rng_device storage,msm_rng_device_info,*msm_rng_dev_cached;
static struct hwrng msm_rng;
static int cached_rng_lock,msm_rng_fops,msm_rng_cdev;
static void *msm_rng_class;
static int which_fail,fail_code,no_clock,no_bus,skip_hw;
static bool allocated,mapped,clock_live,bus_live,hwrng_live,chr_live,class_live,device_live;
static int hw_calls,cdev_calls;
static struct resource resource={123};static struct clk clock_storage;
static struct device device_storage;static struct msm_bus_scale_pdata pdata;
static int reg_space,class_storage;
static struct resource *platform_get_resource(struct platform_device *p,int t,int n){(void)p;(void)t;(void)n;return which_fail==1?NULL:&resource;}
static void *kzalloc(size_t n,int f){(void)n;(void)f;if(which_fail==2)return NULL;REQUIRE(!allocated);allocated=1;memset(&storage,0,sizeof(storage));return &storage;}
static void kzfree(void *p){REQUIRE(p==&storage&&allocated&&!mapped&&!clock_live&&!bus_live&&!hwrng_live&&!chr_live&&!class_live&&!device_live);allocated=0;}
static unsigned long resource_size(struct resource *r){(void)r;return 1024;}
static void *ioremap(unsigned long a,unsigned long s){(void)a;(void)s;REQUIRE(allocated);if(which_fail==3)return NULL;mapped=1;return &reg_space;}
static void iounmap(void *p){REQUIRE(p==&reg_space&&mapped&&!clock_live&&!hwrng_live);mapped=0;}
static bool of_property_read_bool(void *node,const char *name){REQUIRE(node!=NULL);if(!strcmp(name,"qcom,no-clock-support"))return no_clock;if(!strcmp(name,"qcom,no-qrng-config"))return skip_hw;return false;}
static struct clk *clk_get(struct device *d,const char *name){(void)d;(void)name;if(which_fail==4)return ERR_PTR(fail_code);clock_live=1;return &clock_storage;}
static void clk_put(struct clk *c){REQUIRE(c==&clock_storage&&clock_live&&!hwrng_live);clock_live=0;}
static void platform_set_drvdata(struct platform_device *p,void *d){p->data=d;}
static struct msm_bus_scale_pdata *msm_bus_cl_get_pdata(struct platform_device *p){(void)p;return &pdata;}
static uint32_t msm_bus_scale_register_client(struct msm_bus_scale_pdata *p){REQUIRE(p==&pdata);if(no_bus)return 0;bus_live=1;return 42;}
static void msm_bus_scale_unregister_client(uint32_t c){REQUIRE(c==42&&bus_live&&!hwrng_live);bus_live=0;}
static int msm_rng_enable_hw(struct msm_rng_device *d){REQUIRE(d==&storage&&mapped);hw_calls++;return which_fail==5?fail_code:0;}
static void mutex_init(int *l){*l=1;}
static int hwrng_register(struct hwrng *r){REQUIRE(r==&msm_rng&&r->priv==(unsigned long)&storage&&storage.rng_lock==1);if(which_fail==6)return fail_code;hwrng_live=1;return 0;}
static void hwrng_unregister(struct hwrng *r){REQUIRE(r==&msm_rng&&hwrng_live&&allocated&&mapped&&!chr_live&&!class_live&&!device_live);hwrng_live=0;}
static int register_chrdev(int major,const char *name,int *ops){(void)name;REQUIRE(major==113&&ops==&msm_rng_fops&&hwrng_live);if(which_fail==7)return fail_code;chr_live=1;return 0;}
static void unregister_chrdev(int major,const char *name){(void)name;REQUIRE(major==113&&chr_live&&!class_live&&!device_live);chr_live=0;}
static void *class_create(void *owner,const char *name){(void)owner;(void)name;REQUIRE(chr_live);if(which_fail==8)return ERR_PTR(fail_code);class_live=1;return &class_storage;}
static void class_destroy(void *c){REQUIRE(c==&class_storage&&class_live&&!device_live);class_live=0;}
static struct device *device_create(void *c,void *p,int major,void *data,const char *name){(void)p;(void)major;(void)data;(void)name;REQUIRE(c==&class_storage&&class_live&&chr_live);if(which_fail==9)return ERR_PTR(fail_code);device_live=1;return &device_storage;}
static void cdev_init(int *c,int *ops){REQUIRE(c==&msm_rng_cdev&&ops==&msm_rng_fops&&device_live);cdev_calls++;}
'''+function(text,'msm_rng_probe')+r'''
int main(void){
 for(which_fail=0;which_fail<=9;which_fail++)for(int mode=0;mode<8;mode++){
  no_clock=mode&1;no_bus=mode&2;skip_hw=mode&4;fail_code=-EBUSY;
  allocated=mapped=clock_live=bus_live=hwrng_live=chr_live=class_live=device_live=false;
  memset(&storage,0,sizeof(storage));memset(&msm_rng_device_info,0,sizeof(msm_rng_device_info));msm_rng_dev_cached=NULL;msm_rng_class=NULL;msm_rng.priv=0;hw_calls=cdev_calls=0;
  struct platform_device p={{(void *)1},NULL};
  bool failing=which_fail!=0 && !(which_fail==4&&no_clock) && !(which_fail==5&&skip_hw);
  int expected=!failing?0:which_fail==1?-EFAULT:(which_fail==2||which_fail==3)?-ENOMEM:(which_fail==4||which_fail==6)?-EPERM:fail_code;
  int rc=msm_rng_probe(&p);REQUIRE(rc==expected);
  if(rc){REQUIRE(!allocated&&!mapped&&!clock_live&&!bus_live&&!hwrng_live&&!chr_live&&!class_live&&!device_live);REQUIRE(p.data==NULL&&msm_rng.priv==0&&msm_rng_device_info.qrng_perf_client==0&&msm_rng_dev_cached==NULL&&msm_rng_class==NULL);REQUIRE(cdev_calls==0);}
  else{REQUIRE(allocated&&mapped&&hwrng_live&&chr_live&&class_live&&device_live);REQUIRE(clock_live==!no_clock&&bus_live==!no_bus);REQUIRE(p.data==&storage&&msm_rng_dev_cached==&storage&&msm_rng.priv==(unsigned long)&storage);REQUIRE(cdev_calls==1&&hw_calls==!skip_hw);}
  cases++;
 }
 printf("PASS rng cases=%u\n",cases);return 0;
}
'''
def trace_harness(text:str)->str:
 return COMMON+r'''
struct dentry {int n;};struct file_operations {int n;};
static struct dentry directory,file_node;static struct file_operations fops_perftp;
static unsigned old_pid[4];static int mode,hotplug_rc,dir_live,file_live,hotplug_live,calls;
#define USE_CPUHP_STATE 5
#define per_cpu(a,n) a[n]
#define for_each_possible_cpu(n) for(n=0;n<4;n++)
static int tracectr_cpu_hotplug_coming_up(unsigned c){(void)c;return 0;}
static struct dentry *debugfs_create_dir(const char *n,void *p){(void)n;(void)p;if(mode==1)return NULL;dir_live=1;return &directory;}
static struct dentry *debugfs_create_file(const char *n,int mask,struct dentry *p,void *data,const struct file_operations *f){(void)n;(void)mask;(void)data;(void)f;REQUIRE(dir_live&&p==&directory);if(mode==2)return NULL;file_live=1;return &file_node;}
static void debugfs_remove(struct dentry *d){REQUIRE(d==&directory&&dir_live&&!file_live);dir_live=0;}
static void debugfs_remove_recursive(struct dentry *d){REQUIRE(d==&directory&&dir_live);dir_live=file_live=0;}
static int cpuhp_setup_state_nocalls(int state,const char *n,int (*up)(unsigned),void *down){(void)n;(void)up;(void)down;REQUIRE(state==USE_CPUHP_STATE&&file_live);calls++;if(hotplug_rc>=0)hotplug_live=1;return hotplug_rc;}
'''+function(text,'init_tracecounters')+r'''
int main(void){const int returns[]={0,-ENOMEM,-EINVAL,-EBUSY};
 for(mode=0;mode<3;mode++)for(unsigned e=0;e<4;e++){
  dir_live=file_live=hotplug_live=calls=0;hotplug_rc=returns[e];memset(old_pid,0,sizeof(old_pid));
  int expected=mode?-ENOMEM:hotplug_rc;int rc=init_tracecounters();REQUIRE(rc==expected);
  REQUIRE(calls==!mode);REQUIRE(dir_live==!rc&&file_live==!rc&&hotplug_live==!rc);
  if(!mode)for(int n=0;n<4;n++)REQUIRE(old_pid[n]==(unsigned)-1);cases++;
 }
 printf("PASS trace cases=%u\n",cases);return 0;}
'''
def node_harness(text:str,gfp:str)->str:
 f=function(text,'try_to_free_mem_cgroup_pages')
 a=re.search(r'\bnid = mem_cgroup_select_victim_node\(memcg\);',f)
 b=re.search(r'\bzonelist = [^;]+;',f)
 if not a or not b:raise ValueError('Reclaim node-selection lines missing')
 return COMMON+r'''
#ifndef TEST_NUMA
#define TEST_NUMA 0
#endif
#if TEST_NUMA
#define CONFIG_NUMA 1
#endif
#define GFP_KERNEL 0x1400
#define __GFP_THISNODE 0x100000
#define ZONELIST_FALLBACK 0
#define ZONELIST_NOFALLBACK 1
#define unlikely(x) (x)
typedef unsigned gfp_t;
struct zonelist {int identity;};struct node {struct zonelist node_zonelists[2];};
static struct node nodes[32],contig_page_data;static int calls;
#if TEST_NUMA
#define NODE_DATA(n) (&nodes[(n)])
#else
#define NODE_DATA(n) (&contig_page_data)
#endif
'''+function(gfp,'gfp_zonelist')+'\n'+function(gfp,'node_zonelist')+r'''
struct mem_cgroup {int target;};
static int mem_cgroup_select_victim_node(struct mem_cgroup *m){calls++;return m->target;}
static struct zonelist *select_list(struct mem_cgroup *memcg){int nid;struct zonelist *zonelist;
'''+a[0]+'\n'+b[0]+r'''
return zonelist;}
int main(void){for(int n=0;n<32;n++){struct mem_cgroup m={n};calls=0;
struct zonelist *p=select_list(&m);REQUIRE(p==(TEST_NUMA?&nodes[n].node_zonelists[0]:&contig_page_data.node_zonelists[0]));REQUIRE(calls==1);cases++;}
printf("PASS node cases=%u\n",cases);return 0;}
'''
def quota_harness(text:str)->str:
 return COMMON+r'''
#ifndef TEST_QUOTA
#define TEST_QUOTA 0
#endif
#if TEST_QUOTA
#define CONFIG_QUOTA_DEBUG 1
#endif
#define IS_ENABLED(x) (TEST_QUOTA)
#define KERN_WARNING ""
#define unlikely(x) (x)
struct inode {int i_sb_list,noquota,reserved,removed;};
struct list_head {int n;};
struct super_block {int s_inode_list_lock,s_inodes;char *s_id;};
static struct inode inodes[3];static int dq_data_lock,queried,messages,visited;
#define list_for_each_entry(p,head,field) for(p=inodes;p<inodes+3;p++)
#define IS_NOQUOTA(p) ((p)->noquota)
static void spin_lock(int *p){REQUIRE(!*p);*p=1;}
static void spin_unlock(int *p){REQUIRE(*p==1);*p=0;}
static int inode_get_rsv_space(struct inode *i){REQUIRE(dq_data_lock==1);queried++;return i->reserved;}
static void remove_inode_dquot_ref(struct inode *i,int type,struct list_head *h){(void)type;(void)h;REQUIRE(dq_data_lock==1&&!i->noquota&&!i->removed);i->removed=1;visited++;}
#define printk(...) (messages++)
'''+function(text,'remove_dquot_ref')+r'''
int main(void){
 for(unsigned mask=0;mask<8;mask++)for(unsigned res=0;res<8;res++){
  struct super_block sb={0,0,"test"};struct list_head h={0};queried=messages=visited=dq_data_lock=0;int expected=0,active=0;
  for(int n=0;n<3;n++){inodes[n]=(struct inode){0,(mask>>n)&1,(res>>n)&1,0};if(!inodes[n].noquota){active++;expected|=inodes[n].reserved;}}
  remove_dquot_ref(&sb,0,&h);REQUIRE(queried==active&&visited==active);REQUIRE(sb.s_inode_list_lock==0&&dq_data_lock==0);REQUIRE(messages==(TEST_QUOTA&&expected));
  for(int n=0;n<3;n++)REQUIRE(inodes[n].removed==!inodes[n].noquota);cases++;
 }printf("PASS quota cases=%u\n",cases);return 0;}
'''
def warning_gate(logs:list[Path])->dict:
 targets={(r['path'],r['variable'].split('@')[0]) for r in json.loads(LOCK.read_text())['targeted_variables']}
 found=[];pattern=re.compile(r"([^\s:]+\.c):\d+:\d+: warning: variable '([^']+)' set but not used")
 for log in logs:
  for line in log.read_text(errors='replace').splitlines():
   m=pattern.search(line)
   if m and any(m[1].endswith(p) and m[2]==v for p,v in targets):found.append({'log':log.name,'line':line})
 if found:raise ValueError('Targeted R12 warning remains: '+str(found[:4]))
 return {'targeted_source_sites':len(json.loads(LOCK.read_text())['targeted_variables']),'remaining_target_diagnostics':0,'logs_checked':[p.name for p in logs],'warnings_not_suppressed':True}
def run_behavior(candidate:Path,stage:Path,tool:dict)->dict:
 out=stage/'group4_behavior';out.mkdir(exist_ok=False)
 result={'mocked_kernel_apis':True,'hardware_test':False,'concurrency_test':False,'variants':{},'scenarios':{}}
 specs=[('rng',RNG,rng_harness),('trace',TRACE,trace_harness),('node',VMSCAN,lambda t:node_harness(t,(candidate/'include/linux/gfp.h').read_text())),('quota',QUOTA,quota_harness)]
 for area,path,harness in specs:
  before=(ROOT/'docs/sweet/r12a/reference/before'/path).read_text();after=(candidate/path).read_text()
  if after!=(ROOT/'docs/sweet/r12a/reference/after'/path).read_text():raise ValueError('Reviewed source mismatch: '+path)
  variants={'before':before,'after':after}
  if area=='rng':
   variants['bad_ignores_chrdev_error']=after.replace('if (error < 0)\n\t\tgoto unregister_hwrng;','if (false)\n\t\tgoto unregister_hwrng;')
   variants['bad_leaves_hwrng_registered']=after.replace('\thwrng_unregister(&msm_rng);','\t/* deliberate omitted cleanup */')
  elif area=='trace':variants['bad_leaves_debugfs']=after.replace('\t\tdebugfs_remove_recursive(dir);','\t\t/* deliberate leak */')
  for label,text in variants.items():
   configs=(0,1) if area in ('node','quota') else (None,)
   for config in configs:
    tag=area+'_'+label+('' if config is None else '_'+str(config));c=out/(tag+'.c');exe=out/tag;c.write_text(harness(text))
    flags=[] if config is None else ['-D'+('TEST_NUMA' if area=='node' else 'TEST_QUOTA')+'='+str(config)]
    r7.run([tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',*flags,str(c),'-o',str(exe)],out/(tag+'_build.log'),timeout=90)
    p=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
    content=p.stdout+p.stderr;(out/(tag+'_run.log')).write_text(content)
    expected_pass=label=='after' or (label=='before' and area in ('node','quota'))
    if expected_pass:
     m=re.search('PASS '+area+r' cases=(\d+)',content)
     if p.returncode or not m:raise ValueError('Behavior failed: '+tag+' '+content[:1000])
     result['scenarios'][tag]=int(m[1])
    elif p.returncode!=1 or not content.startswith('ORACLE:'):
     raise ValueError('Negative control missed: '+tag+' '+content[:500])
    result['variants'][tag]={'exit_code':p.returncode,'expected_pass':expected_pass,'expectation_met':True,'harness_sha256':hashlib.sha256(c.read_bytes()).hexdigest()}
    exe.unlink()
 (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');return result
