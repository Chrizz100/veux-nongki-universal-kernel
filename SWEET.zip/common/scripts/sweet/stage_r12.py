#!/usr/bin/env python3
"""R12: checked RNG/trace registration, configuration-dependent helpers and unused values plus full baseline build.

All build failures propagate. Generated kernels remain development artifacts:
no root integration, vendor ABI approval, boot.img, AK3, or flashing here.
"""
from __future__ import annotations
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import traceback
from typing import Any
import audit
import prepare_candidate_r5 as r5
import stage_r6 as r6
import stage_r7 as r7
import stage_r8 as r8
import group1_validation as group1
import group2_validation as group2
import stage_r9 as r9
import stage_r10 as r10
import group3_validation as group3
import stage_r11 as r11
import group4_validation as group4

ROOT = Path(__file__).resolve().parents[3]
LOCK_PATH = ROOT / 'lineages/sweet/candidates/r12.json'
AES_OBJECTS = ('arch/arm64/crypto/aes-ce.o', 'arch/arm64/crypto/aes-neon.o')
AES_VECTOR = (0x30000000200000001).to_bytes(16, 'little')
FULL_TARGETS = ('Image.gz',)  # separate from module/DT compilation and device tests


def load_lock() -> dict[str, Any]:
    lock = json.loads(LOCK_PATH.read_text())
    if (lock.get('schema') != 1 or lock.get('stage') != 'r12_registration_and_configuration_full_kernel'
            or lock.get('flashable') is not False
            or lock.get('r11_tree') != r11.load_lock()['candidate_tree']):
        raise ValueError('Invalid R12 stage, parent tree, or release claim')
    return lock


def combined_lock(lock: dict[str, Any]) -> dict[str, Any]:
    combined = r11.combined_lock(r11.load_lock())
    combined['patches'] += lock['patches']
    changed = {item['path']: item for item in combined['changed_files']}
    for item in lock['changed_from_r11']:
        changed[item['path']] = item
    combined['changed_files'] = [changed[p] for p in sorted(changed)]
    return combined


def elf_section(data: bytes, name: str) -> tuple[bytes, int]:
    """Read a bounded, ordinary ELF64 little-endian section; reject bad offsets."""
    if len(data) < 64 or data[:7] != b'\x7fELF\x02\x01\x01':
        raise ValueError('Not ELF64 little endian')
    offset = struct.unpack_from('<Q', data, 40)[0]
    stride, count, names_index = struct.unpack_from('<HHH', data, 58)
    if stride != 64 or not count or names_index >= count or offset+stride*count > len(data):
        raise ValueError('Invalid ELF section table')
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, offset+i*stride) for i in range(count)]
    names = sections[names_index]
    if names[4]+names[5] > len(data): raise ValueError('Invalid ELF names')
    strings = data[names[4]:names[4]+names[5]]
    for section in sections:
        pos = section[0]
        if pos >= len(strings): raise ValueError('Invalid section name offset')
        end = strings.find(b'\0', pos)
        if end == -1: raise ValueError('Unterminated section name')
        if strings[pos:end].decode() == name:
            if section[1] == 8 or section[4]+section[5] > len(data):
                raise ValueError('Invalid backed section data')
            return data[section[4]:section[4]+section[5]], section[3]
    raise ValueError('Missing ELF section: '+name)


def aes_object_check(path: Path) -> dict[str, Any]:
    info = r7.elf_check(path, 1)
    text, address = elf_section(path.read_bytes(), '.text')
    matching = []
    for i in range(0, len(text)-3, 4):
        opcode = struct.unpack_from('<I', text, i)[0]
        # A64 LDR literal into vector register q8. Decode signed imm19, scaled by 4.
        if opcode & 0xff00001f != 0x9c000008: continue
        disp = (opcode >> 5) & 0x7ffff
        if disp & 0x40000: disp -= 1 << 19
        target = i + disp*4
        if 0 <= target <= len(text)-16 and text[target:target+16] == AES_VECTOR:
            matching.append({'instruction_offset':i, 'pool_offset':target})
    if len(matching) != 1:
        raise ValueError(f'{path.name}: expected exactly one q8 load of original 128-bit constant')
    info.update(literal_load=matching[0], expected_lane_words=[1,2,3,0],
                constant_bytes=AES_VECTOR.hex(), runtime_cipher_test=False)
    return info


FIRMWARE_SHA256 = 'ffe0d0e1c3698c0f1689700b83575a849cda67268c9da50babbf2fab54d6d16b'
FIRMWARE_SIZE = 94480
FIRMWARE_OBJECT = 'drivers/input/touchscreen/k6_focaltech_3658u/focaltech_flash.o'
MEMORY_OBJECTS = ('arch/arm64/lib/memcpy.o','arch/arm64/lib/memmove.o','arch/arm64/lib/memset.o')


def elf_symbols(data: bytes) -> dict[str, dict[str, Any]]:
    """Bounded ELF64 symbol reading for ordinary relocatable Kbuild objects."""
    elf_section(data, '.text')  # shared structural checks
    offset=struct.unpack_from('<Q',data,40)[0]
    stride,count,_=struct.unpack_from('<HHH',data,58)
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*stride) for i in range(count)]
    result={}
    for section in sections:
        if section[1]!=2: continue
        if section[9]!=24 or section[5]%24 or section[6]>=count:
            raise ValueError('Bad symbol-table description')
        strings=sections[section[6]]
        if strings[4]+strings[5]>len(data) or section[4]+section[5]>len(data):
            raise ValueError('Truncated symbols or names')
        names=data[strings[4]:strings[4]+strings[5]]
        for pos in range(section[4],section[4]+section[5],24):
            ni,info,other,index,value,size=struct.unpack_from('<IBBHQQ',data,pos)
            if ni>=len(names): raise ValueError('Bad symbol name')
            end=names.find(b'\0',ni)
            if end<0: raise ValueError('Unterminated symbol name')
            name=names[ni:end].decode('utf-8')
            if not name or info>>4==0: continue  # local mapping symbols may repeat
            raw=None
            if 0<index<count:
                target=sections[index]
                local=value-target[3]
                if target[1]!=8:
                    if local<0 or local+size>target[5] or target[4]+target[5]>len(data):
                        raise ValueError('Symbol exceeds backed section')
                    raw=data[target[4]+local:target[4]+local+size]
            if name in result: raise ValueError('Duplicate named symbol: '+name)
            result[name]={'binding':info>>4,'type':info&15,'size':size,'index':index,'data':raw}
    return result


def firmware_object_check(path: Path) -> dict[str, Any]:
    result=r7.elf_check(path,1);symbols=elf_symbols(path.read_bytes());arrays=[]
    for name in ('fw_file','fw_file2','fw_file3'):
        symbol=symbols.get(name,{})
        data=symbol.get('data')
        if (symbol.get('size')!=FIRMWARE_SIZE or data is None
                or hashlib.sha256(data).hexdigest()!=FIRMWARE_SHA256):
            raise ValueError('Stock FocalTech bytes changed in compiled '+name)
        arrays.append({'symbol':name,'bytes':len(data),'sha256':FIRMWARE_SHA256})
    table=symbols.get('module_list',{}).get('data')
    if table is None or len(table)!=120:
        raise ValueError('Unexpected ARM64 firmware descriptor size')
    lengths=[struct.unpack_from('<I',table,i*40+32)[0] for i in range(3)]
    if lengths!=[FIRMWARE_SIZE]*3: raise ValueError('Firmware lengths do not match arrays')
    result.update(stock_arrays=arrays,module_list_lengths=lengths,runtime_device_test=False)
    return result


def memory_alias_check(path: Path) -> dict[str, Any]:
    result=r7.elf_check(path,1);symbols=elf_symbols(path.read_bytes());name=path.stem
    if symbols.get(name,{}).get('binding')!=2 or symbols.get('__'+name,{}).get('binding')!=1:
        raise ValueError('Weak/public memory alias or strong internal symbol changed')
    result.update(public_symbol=name,public_binding='WEAK',internal_binding='GLOBAL')
    return result


def image_check(path: Path) -> dict[str, Any]:
    data = path.read_bytes()
    if len(data)<64 or data[56:60]!=b'ARM\x64': raise ValueError('Invalid ARM64 Image header')
    offset, size, flags = struct.unpack_from('<QQQ', data, 8)
    if not size or size<len(data) or flags & 1: raise ValueError('Unexpected Image size or endianness')
    return {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'text_offset':offset,'declared_image_size':size,'flags':flags,
            'machine':'AArch64','flashable':False}


def validate_gzip(path: Path, image: Path) -> None:
    h = hashlib.sha256()
    length = 0
    with gzip.open(path,'rb') as stream:
        while True:
            block=stream.read(1024*1024)
            if not block: break
            length+=len(block)
            if length>image.stat().st_size: raise ValueError('Gzip exceeds Image size')
            h.update(block)
    if length!=image.stat().st_size or h.hexdigest()!=audit.sha256(image):
        raise ValueError('Image.gz is not byte-identical to Image after decompression')


def symvers_check(path: Path) -> dict[str, Any]:
    rows={}
    for line in path.read_text().splitlines():
        parts=line.split()
        if len(parts)<3 or not re.fullmatch(r'0x[0-9a-fA-F]{8}',parts[0]):
            raise ValueError('Malformed Module.symvers entry')
        if parts[1] in rows: raise ValueError('Duplicate exported name in Module.symvers')
        rows[parts[1]]=parts[0]
    critical='gsi_write_channel_scratch'
    if int(rows.get(critical,'0'),16)==0:
        raise ValueError('Required real GSI symbol version missing or zero')
    return {'exports':len(rows),'sha256':audit.sha256(path),
            'gsi_write_channel_scratch_crc':rows[critical],'vendor_abi_match_checked':False}


def check_config(data: bytes) -> dict[str, Any]:
    expected=(ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes()
    if data!=expected: raise ValueError('R12 must preserve the exact confirmed configuration')
    values=audit.parse_config(data.decode())['values']
    for key in ('CONFIG_CRYPTO_AES_ARM64_CE_BLK','CONFIG_CRYPTO_AES_ARM64_NEON_BLK',
                'CONFIG_SECURITY_SELINUX','CONFIG_MODVERSIONS','CONFIG_BATT_VERIFY_BY_DS28E16'):
        if values.get(key)!='y': raise ValueError('Required preserved stock option: '+key)
    return {'sha256':hashlib.sha256(data).hexdigest(),'unchanged_values':len(values)}


def run_stage(output: Path) -> dict[str, Any]:
    stage=output/'R12';stage.mkdir(exist_ok=False)
    work=Path(os.environ['SWEET_WORK']).resolve()
    if (work==ROOT or work.is_relative_to(ROOT) or ROOT.is_relative_to(work)
        or work.is_relative_to(output) or output.is_relative_to(work)):
        raise ValueError('Package, work and output must be disjoint')
    work.mkdir(parents=True,exist_ok=False)
    report={'stage':'R12 unused values and full Image.gz build','completed':False,
            'kernel_built':False,'full_kernel_build_executed':False,
            'flashable':False,'device_tested':False,'stock_vendor_abi_validated':False,
            'stock_compatibility_passed':False,'root_components_integrated':False,
            'ak3_produced':False,'boot_img_produced':False,'toolchain_is_stock':False}
    candidate=None; source=None; before=None
    report['modules_built']=False
    report['device_trees_built']=False
    try:
        lock=load_lock();tool=r7.tools(stage)
        # The behavioral tests link host AddressSanitizer/UBSan. Do not rely on
        # optional runner-image recommendations for the Clang runtime archive.
        runtime=subprocess.check_output([tool['cc'],'-print-file-name=libclang_rt.asan-x86_64.a'],text=True).strip()
        if not Path(runtime).is_file() and os.environ.get('SWEET_LOCAL_TOOLCHAIN') != '1':
            r7.run(['sudo','-n','apt-get','install','--no-install-recommends','-y',
                    'libclang-rt-14-dev'],stage/'tools.log')
            runtime=subprocess.check_output([tool['cc'],'-print-file-name=libclang_rt.asan-x86_64.a'],text=True).strip()
        if not Path(runtime).is_file():
            raise RuntimeError('Host AddressSanitizer runtime missing')
        report['sanitizer_runtime_sha256']=audit.sha256(Path(runtime))
        report['toolchain']=tool
        local=os.environ.get('SWEET_LOCAL_SOURCE')
        if local and os.environ.get('GITHUB_ACTIONS')=='true':
            raise ValueError('Local source override is forbidden on GitHub Actions')
        source=Path(local).resolve() if local else work/'oem'
        if not local: audit.acquire_source(r6.BASE_REPO,lock['base_commit'],source,stage/'fetch.log')
        candidate=work/'candidate'
        preparation=r5.prepare(source,candidate,combined_lock(lock),ROOT)
        if preparation['candidate_tree_before_make']!=lock['candidate_tree']:
            raise ValueError('R12 full source tree mismatch')
        preparation['note']='R12 source preparation; no stock or device approval'
        audit.write_json(stage/'preparation.json',preparation)
        report['group1_behavior']=group1.run_behavior(candidate,stage,tool)
        report['group2_behavior']=group2.run_behavior(candidate,stage,tool)
        report['group3_behavior']=group3.run_behavior(candidate,stage,tool)
        report['group4_behavior']=group4.run_behavior(candidate,stage,tool)
        _,before=r5.tree_identity(candidate)
        build=work/'build';build.mkdir()
        (build/'.config').write_bytes((ROOT/'device/sweet/reference/stock.config').read_bytes())
        command=r7.make_command(candidate,build,tool)
        env=dict(os.environ,KBUILD_BUILD_TIMESTAMP='Sat Oct 3 00:00:00 UTC 2026',
                 KBUILD_BUILD_USER='builder',KBUILD_BUILD_HOST='sweet',KBUILD_BUILD_VERSION='1')
        for i in (1,2):
            r7.run(command+['olddefconfig'],stage/f'olddefconfig_{i}.log',env=env)
            report['config_gate']=check_config((build/'.config').read_bytes())
        report['new_oem_kconfig_run']=True
        for log in (stage/'olddefconfig_1.log',stage/'olddefconfig_2.log'):
            if re.search(r'Kconfig[^\n]*warning:',log.read_text(errors='replace')):
                raise ValueError('Unexpected Kconfig parser warning')
        shutil.copy2(build/'.config',stage/'resolved.config')
        stock=audit.parse_config((ROOT/'device/sweet/reference/stock.config').read_text())['values']
        current=audit.parse_config((build/'.config').read_text())['values']
        gaps=[{'symbol':k,'stock':v,'candidate':current.get(k)} for k,v in sorted(stock.items())
              if v in ('y','m') and current.get(k)!=v]
        if [g['symbol'] for g in gaps]!=sorted(r6.load_lock()['expected_active_missing']):
            raise ValueError('Stock compatibility findings changed unexpectedly')
        audit.write_json(stage/'stock_gaps.json',gaps)
        report['active_stock_missing']=len(gaps)
        r7.check_power_tables(candidate,stage,env)
        jobs='-j'+str(min(4,os.cpu_count() or 1))
        for target in ('prepare','scripts','modules_prepare'):
            r7.run(command+[jobs,target],stage/f'{target}.log',env=env,timeout=900)
            report[target+'_passed']=True
        # Explicit objects, not a directory-only request that can select only modules.
        r7.run(command+[jobs,*AES_OBJECTS],stage/'aes_objects.log',env=env,timeout=900)
        report['aes_objects']={p:aes_object_check(build/p) for p in AES_OBJECTS}
        objdir=stage/'aes_objects';objdir.mkdir()
        for p in AES_OBJECTS: shutil.copy2(build/p,objdir/Path(p).name)
        r7.run(command+[jobs,*MEMORY_OBJECTS,FIRMWARE_OBJECT],stage/'memory_firmware_objects.log',env=env,timeout=900)
        report['memory_aliases']={p:memory_alias_check(build/p) for p in MEMORY_OBJECTS}
        report['focaltech_stock_firmware']=firmware_object_check(build/FIRMWARE_OBJECT)
        shutil.copy2(build/FIRMWARE_OBJECT,stage/'focaltech_flash.o')
        group1_objects = (
            'kernel/smp.o', 'block/blk-mq.o', 'drivers/input/touchscreen/of_touchscreen.o',
            'drivers/media/platform/msm/camera_v3/cam_icp/icp_hw/icp_hw_mgr/cam_icp_hw_mgr.o')
        r7.run(command+[jobs,*group1_objects],stage/'group1_objects.log',env=env,timeout=900)
        report['group1_objects']={p:r7.elf_check(build/p,1) for p in group1_objects}
        group1.warning_gate([stage/'group1_objects.log'])
        group2_objects=tuple(p['path'][:-2]+'.o' for p in r10.load_lock()['changed_from_r9'])
        r7.run(command+[jobs,*group2_objects],stage/'group2_objects.log',env=env,timeout=900)
        report['group2_objects']={p:r7.elf_check(build/p,1) for p in group2_objects}
        report['group2_warnings']=group2.warning_gate([stage/'memory_firmware_objects.log',stage/'group2_objects.log'])
        group3_objects=tuple(p['path'][:-2]+'.o' for p in r11.load_lock()['changed_from_r10'])
        # ss/services.c belongs to the composite SELinux Kbuild, not an ss/Makefile.
        group3_targets=tuple('security/selinux/' if p=='security/selinux/ss/services.o' else p for p in group3_objects)
        r7.run(command+[jobs,'KBUILD_BUILTIN=1',*group3_targets],stage/'group3_objects.log',env=env,timeout=900)
        report['group3_objects']={p:r7.elf_check(build/p,1) for p in group3_objects}
        report['group3_warnings']=group3.warning_gate([stage/'group3_objects.log'])
        # pcm_compat.c is included by pcm_native.c; SELinux uses composite Kbuild.
        group4_objects=tuple(dict.fromkeys(
            ('sound/core/pcm_native.o' if p['path']=='sound/core/pcm_compat.c' else p['path'][:-2]+'.o')
            for p in lock['changed_from_r11']))
        group4_targets=tuple('security/selinux/' if p=='security/selinux/hooks.o' else p for p in group4_objects)
        r7.run(command+[jobs,'KBUILD_BUILTIN=1',*group4_targets],stage/'group4_objects.log',env=env,timeout=900)
        report['group4_objects']={p:r7.elf_check(build/p,1) for p in group4_objects}
        report['group4_warnings']=group4.warning_gate([stage/'group2_objects.log',stage/'group3_objects.log',stage/'group4_objects.log'])
        report['full_kernel_build_executed']=True
        r7.run(command+[jobs,*FULL_TARGETS],stage/'full_kernel.log',env=env,timeout=5400)
        vmlinux=build/'vmlinux';image=build/'arch/arm64/boot/Image';packed=image.with_name('Image.gz')
        report['vmlinux']=r7.elf_check(vmlinux,3)  # CONFIG_RELOCATABLE=y links as ET_DYN
        report['image']=image_check(image)
        validate_gzip(packed,image)
        symbols=subprocess.check_output([tool['nm'],'--defined-only',str(vmlinux)],text=True)
        for symbol in ('start_kernel','millet_sendmsg','millet_sendto_user','millet_can_attach',
                       'ce_aes_ctr_encrypt','neon_aes_ctr_encrypt'):
            if not re.search(r'\b'+symbol+r'$',symbols,re.M):
                raise ValueError('Missing expected kernel symbol: '+symbol)
        (stage/'selected_kernel_symbols.txt').write_text('\n'.join(l for l in symbols.splitlines()
            if re.search(r'\b(?:start_kernel|millet_\w+|(?:ce|neon)_aes_\w+)$',l))+'\n')
        unresolved=subprocess.check_output([tool['nm'],'-u',str(vmlinux)],text=True).strip()
        if unresolved: raise ValueError('Undefined symbols remain in final vmlinux')
        report['final_link_undefined_symbols']=0
        report['module_versions']=symvers_check(build/'Module.symvers')
        report['group1_warnings']=group1.warning_gate([stage/'group1_objects.log',stage/'full_kernel.log'])
        report['group2_warnings']=group2.warning_gate([stage/'memory_firmware_objects.log',stage/'group2_objects.log',stage/'full_kernel.log'])
        report['group3_warnings']=group3.warning_gate([stage/'group3_objects.log',stage/'full_kernel.log'])
        report['group4_warnings']=group4.warning_gate([stage/'group2_objects.log',stage/'group3_objects.log',stage/'group4_objects.log',stage/'full_kernel.log'])
        def export_rows(path):
            return {p[1]:p[0] for p in (line.split() for line in path.read_text().splitlines()) if len(p)>=3}
        old_exports=export_rows(ROOT/'docs/sweet/r12/reference/R11.Module.symvers')
        new_exports=export_rows(build/'Module.symvers')
        changes=[{'symbol':n,'r11_crc':old_exports.get(n),'r12_crc':new_exports.get(n)}
                 for n in sorted(old_exports.keys()|new_exports.keys()) if old_exports.get(n)!=new_exports.get(n)]
        if changes:
            raise ValueError('Unexpected exported symbol version change in unused-variable cleanup: '+str(changes[:5]))
        report['r11_export_crc_comparison']={'changed':len(changes),'details':changes,
            'same':len(old_exports),'vendor_modules_checked':False}
        audit.write_json(stage/'r11_export_crc_comparison.json',report['r11_export_crc_comparison'])
        report['kernel_version']=subprocess.check_output(command+['-s','kernelrelease'],env=env,text=True).strip().splitlines()[-1]
        # Only baseline diagnostic artifacts, not a boot partition image.
        shutil.copy2(vmlinux,stage/'vmlinux')
        shutil.copy2(packed,stage/'Image.gz')
        shutil.copy2(build/'System.map',stage/'System.map')
        shutil.copy2(build/'Module.symvers',stage/'Module.symvers')
        shutil.copy2(build/'.config',stage/'resolved.config')
        check_config((build/'.config').read_bytes())
        stock=audit.parse_config((ROOT/'device/sweet/reference/stock.config').read_text())['values']
        current=audit.parse_config((build/'.config').read_text())['values']
        gaps=[{'symbol':k,'stock':v,'candidate':current.get(k)} for k,v in sorted(stock.items())
              if v in ('y','m') and current.get(k)!=v]
        if [g['symbol'] for g in gaps]!=sorted(r6.load_lock()['expected_active_missing']):
            raise ValueError('Stock compatibility findings changed unexpectedly')
        audit.write_json(stage/'stock_gaps.json',gaps)
        report.update(completed=True,kernel_built=True,active_stock_missing=len(gaps))
        print('::warning::SWEET R12: 12 weitere bearbeitete Warnstellen und Baseline-Build bestanden. Weitere Warnungen offen; kein AK3/boot.img und keine Flashfreigabe.',flush=True)
        return report
    except Exception as exc:
        report['error']=str(exc);(stage/'failure.log').write_text(traceback.format_exc())
        raise
    finally:
        # Integrity checks also run when compilation fails; never turn failure into PASS.
        try:
            if candidate is not None and before is not None:
                _,after=r5.tree_identity(candidate)
                state=r6.generated_state(candidate,before,after)
                audit.write_json(stage/'source_state.json',state)
                report['candidate_source_unchanged']=True
            if source is not None and source.is_dir():
                report['oem_source_unchanged']=r5.tree_identity(source)[0]==load_lock()['base_tree']
                if not report['oem_source_unchanged']: raise ValueError('OEM source mutated')
        except Exception as exc:
            report['integrity_error']=str(exc);report['completed']=False
            raise
        finally:
            audit.write_json(stage/'warnings.json',{p.name:[l for l in p.read_text(errors='replace').splitlines()
                if 'warning:' in l.lower() or 'no such file' in l.lower()] for p in stage.glob('*.log')})
            audit.write_json(stage/'report.json',report);audit.save_checksums(stage)
