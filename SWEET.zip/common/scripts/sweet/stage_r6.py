#!/usr/bin/env python3
"""R6: reproduce the pinned MILLET candidate and resolve its stock configuration.

No kernel build or flash. A local OEM source override is accepted only after
complete Git-tree validation; the default is a pinned read-only GitHub fetch.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import traceback
from typing import Any
import audit
import prepare_candidate_r5 as r5

ROOT = Path(__file__).resolve().parents[3]
LOCK_PATH = ROOT / 'lineages/sweet/candidates/r6.json'
BASE_REPO = 'https://github.com/MiCode/Xiaomi_Kernel_OpenSource.git'
OEM_LINKS = {'include/linux/rtmm.h': 'include/dum/rtmm.h',
             'include/linux/ktrace.h': 'include/dum/ktrace.h'}
OEM_EMPTY = ('drivers/staging/rtmm/Kconfig', 'drivers/staging/rtmm/Makefile',
             'drivers/staging/ktrace/Kconfig', 'drivers/staging/ktrace/Makefile')


def load_lock() -> dict[str, Any]:
    value = json.loads(LOCK_PATH.read_text())
    if value['schema'] != 1 or value['stage'] != 'r6_millet_source_kconfig_only':
        raise ValueError('Unsupported R6 source manifest')
    if value['flashable'] is not False:
        raise ValueError('This stage cannot grant a flash release')
    return value


def apply_delta(candidate: Path, lock: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    before, previous = r5.tree_identity(candidate)
    if before != lock['r5_tree']:
        raise ValueError('R6 requires the exact prepared R5 tree')
    patches = []
    for item in lock['patches']:
        patch = (root / item['path']).resolve()
        if not patch.is_relative_to(root.resolve()) or r5.digest_file(patch) != item['sha256']:
            raise ValueError('R6 patch integrity mismatch')
        patches.append(patch)
    for patch in patches:
        for options in (['--check'], ['--whitespace=nowarn']):
            subprocess.run(['git', 'apply', *options, str(patch)], cwd=candidate,
                           check=True, capture_output=True, timeout=120)
    tree, current = r5.tree_identity(candidate)
    if tree != lock['candidate_tree']:
        raise ValueError('R6 candidate tree mismatch')
    changed = sorted(k for k in previous.keys() | current.keys() if previous.get(k) != current.get(k))
    if changed != sorted(i['path'] for i in lock['changed_from_r5']):
        raise ValueError('Unexpected R6 changed-file set')
    for item in lock['changed_from_r5']:
        if r5.digest_file(candidate / item['path']) != item['after_sha256']:
            raise ValueError('R6 changed file mismatch')
    uapi = (candidate / 'include/uapi/linux/millet.h').read_bytes()
    if audit.git_blob(uapi) != lock['uapi_blob']:
        raise ValueError('MILLET UAPI changed unexpectedly')
    return {'r5_tree': before, 'r6_tree': tree, 'changed_files': changed,
            'uapi_unchanged': True, 'flashable': False}


def generated_state(source: Path, before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    changed = [p for p in sorted(before) if after.get(p) != before[p]]
    extra = sorted(after.keys() - before.keys())
    expected = set(OEM_LINKS) | set(OEM_EMPTY)
    if changed or set(extra) != expected:
        raise ValueError(f'Unexpected source mutation: changed={changed}, extra={extra}')
    for p in OEM_EMPTY:
        path = source / p
        if path.is_symlink() or not path.is_file() or path.stat().st_size:
            raise ValueError('OEM generated placeholder is not an empty regular file')
    for p, target in OEM_LINKS.items():
        path = source / p
        if not path.is_symlink() or os.readlink(path) != str(source.resolve()/target):
            raise ValueError('OEM header link target mismatch')
    return {'passed': True, 'tracked_content_changes': [], 'accepted_oem_outputs': extra}


def check_configs(stock: dict[str, str], r5_values: dict[str, str], current: dict[str, str]) -> dict[str, Any]:
    delta = audit.compare_configs(r5_values, current)
    if delta['changed'] or delta['missing'] or delta['added'] != [{'symbol': 'CONFIG_MILLET', 'candidate':'y'}]:
        raise ValueError('R6 must add only MILLET=y relative to the resolved R5 reference')
    missing = [{'symbol': k, 'stock': v, 'candidate':current.get(k)}
               for k,v in sorted(stock.items()) if v in ('y','m') and current.get(k)!=v]
    gate = audit.critical_gate(stock, current)
    return {'r5_to_r6': delta, 'active_stock_missing': missing, 'critical_gate': gate,
            'stock_compatibility_passed': not missing and gate['passed']}


def command(argv: list[str], log: Path, timeout: int=600) -> None:
    print('SWEET R6: ' + ' '.join(argv), flush=True)
    with log.open('ab') as stream:
        stream.write(('$ '+' '.join(argv)+'\n').encode()); stream.flush()
        result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT,
                                timeout=timeout, check=False)
    if result.returncode:
        raise RuntimeError(f'{argv[0]} exited {result.returncode}; see {log.name}')


def run_stage(output: Path) -> dict[str, Any]:
    lock = load_lock()
    stage = output / 'R6'; stage.mkdir(exist_ok=False)
    work = Path(os.environ['SWEET_WORK']).resolve()
    if work == ROOT or work.is_relative_to(ROOT) or output.is_relative_to(work) or work.is_relative_to(output):
        raise ValueError('Working and output directories must be separate from each other and the package')
    work.mkdir(exist_ok=False, parents=True)
    report: dict[str, Any] = {'stage':'R6 MILLET source/Kconfig', 'completed':False,
                              'kernel_built':False, 'device_tested':False, 'flashable':False,
                              'new_oem_kconfig_run':False, 'baseline_full_compile':False,
                              'note':'A completed source audit is NOT a kernel or ROM compatibility pass.'}
    try:
        host_only = os.environ.get('SWEET_HOST_KCONFIG_ONLY') == '1'
        cc = 'gcc' if host_only else 'aarch64-linux-gnu-gcc'
        cross = '' if host_only else 'aarch64-linux-gnu-'
        tools = ['git','make','gcc',cc]
        if not all(shutil.which(t) for t in tools):
            if host_only:
                raise RuntimeError('Missing local Kconfig tools')
            command(['sudo','-n','apt-get','update'],stage/'tools.log')
            command(['sudo','-n','apt-get','install','--no-install-recommends','-y',
                     'build-essential','gcc-aarch64-linux-gnu','bc','flex','bison'],stage/'tools.log')
        if not all(shutil.which(t) for t in tools):
            raise RuntimeError('Required Kconfig tools not available')
        report['configuration_compiler'] = cc
        command([cc,'--version'],stage/'environment.log')
        local = os.environ.get('SWEET_LOCAL_SOURCE')
        if local:
            source = Path(local).resolve()
        else:
            source = work/'oem'
            audit.acquire_source(BASE_REPO,lock['base_commit'],source,stage/'fetch.log')
        candidate = work/'candidate'
        r5_lock = json.loads((ROOT/'lineages/sweet/candidates/r5.json').read_text())
        print('SWEET R6: Pruefe OEM-Quelle und wende alle sechs Patches an.',flush=True)
        combined = dict(r5_lock)
        combined['patches'] = r5_lock['patches'] + lock['patches']
        combined['changed_files'] = r5_lock['changed_files'] + lock['changed_from_r5']
        prep = r5.prepare(source,candidate,combined,ROOT)
        if prep['candidate_tree_before_make'] != lock['candidate_tree']:
            raise ValueError('Combined R5/R6 candidate tree mismatch')
        prep['note'] = 'R6 MILLET source candidate only; no full kernel build.'
        audit.write_json(stage/'R6_preparation.json',prep)
        # Record all file identities before make to distinguish OEM-generated outputs.
        _, initial = r5.tree_identity(candidate)
        if audit.git_blob((candidate/'include/uapi/linux/millet.h').read_bytes()) != lock['uapi_blob']:
            raise ValueError('MILLET UAPI identity mismatch')
        build = work/'config'; build.mkdir()
        stock_path = ROOT/'device/sweet/reference/stock.config'
        (build/'.config').write_bytes(stock_path.read_bytes())
        argv = ['make','-C',str(candidate),f'O={build}','ARCH=arm64',f'CC={cc}',
                'HOSTCC=gcc',f'CROSS_COMPILE={cross}','olddefconfig']
        command(argv,stage/'olddefconfig_1.log')
        first = (build/'.config').read_bytes(); (stage/'resolved.config').write_bytes(first)
        command(argv,stage/'olddefconfig_2.log')
        if first != (build/'.config').read_bytes():
            raise ValueError('Non-idempotent olddefconfig')
        for log in ['olddefconfig_1.log','olddefconfig_2.log']:
            # Only Kconfig diagnostics; host compiler diagnostics remain in the log.
            text=(stage/log).read_text(errors='replace')
            if any('Kconfig' in line and 'warning:' in line for line in text.splitlines()):
                raise ValueError('Kconfig parser warning remains')
        stock = audit.parse_config(stock_path.read_text())['values']
        ref = audit.parse_config((ROOT/'docs/sweet/r5/evidence/r5.resolved.config').read_text())['values']
        current = audit.parse_config(first.decode())['values']
        progress = check_configs(stock,ref,current)
        if sorted(i['symbol'] for i in progress['active_stock_missing']) != sorted(lock['expected_active_missing']):
            raise ValueError('Unexpected change to remaining stock differences')
        audit.write_json(stage/'config_progress.json',progress)
        _, after = r5.tree_identity(candidate)
        audit.write_json(stage/'source_state.json',generated_state(candidate,initial,after))
        if r5.tree_identity(source)[0] != lock['base_tree']:
            raise ValueError('Original OEM checkout changed')
        report.update(completed=True,new_oem_kconfig_run=True,olddefconfig_idempotent=True,
                      source_unchanged=True,millet_enabled=True,stock_compatibility_passed=False,
                      active_stock_missing=len(progress['active_stock_missing']),
                      critical_stock_missing=len(progress['critical_gate']['failures']))
        print('::warning::SWEET R6: MILLET eingebunden; 13 aktive Stock-Optionen weiterhin offen. Kein Kernelbuild.',flush=True)
        return report
    except Exception as exc:
        report['error']=str(exc)
        (stage/'failure.log').write_text(traceback.format_exc())
        raise
    finally:
        audit.write_json(stage/'report.json',report)
        audit.save_checksums(stage)
