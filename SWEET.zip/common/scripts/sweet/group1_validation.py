"""R9 group-1 checks on extracted real source functions; mocked kernel APIs, no device test."""
from __future__ import annotations
import hashlib,json,os,re,subprocess
from pathlib import Path
import stage_r7 as r7

CAMERA='drivers/media/platform/msm/camera_v3/cam_icp/icp_hw/icp_hw_mgr/cam_icp_hw_mgr.c'
TOUCH='drivers/input/touchscreen/of_touchscreen.c'
TARGET_CATEGORIES=('-Wunsequenced','-Walign-mismatch','-Wbitwise-instead-of-logical')

def function(text: str,name: str)->str:
    m=re.search(r'^(?:static )?(?:int|void|bool)\s+'+re.escape(name)+r'\(',text,re.M)
    if not m:raise ValueError('Function not found: '+name)
    start=text.index('{',m.start());depth=1;i=start+1
    # These selected function bodies contain no brace characters in strings/comments.
    while depth and i<len(text):
        depth+=(text[i]=='{')-(text[i]=='}');i+=1
    if depth:raise ValueError('Unbalanced function: '+name)
    return text[m.start():i]

def camera_harness(text: str)->str:
    return r'''
#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define CAM_ERR(...) ((void)0)
#define CAM_DBG(...) ((void)0)
#define CAM_WARN(...) ((void)0)
#define CAM_CMD_BUF_FW 1
#define CAM_ICP_RES_TYPE_BPS 7
#define IPE_IO_IMAGES_MAX 2
#define BPS_IO_IMAGES_MAX 2
#define MAX_NUM_OF_IMAGE_PLANES 2
struct cam_cmd_buf_desc {int mem_handle;unsigned type,offset,size,length;};
struct cam_packet {unsigned num_cmd_buf,cmd_buf_offset;uint32_t payload[256];};
struct cam_icp_hw_mgr {int iommu_hdl;};
struct acquire {int dev_type;};
struct cam_icp_hw_ctx_data {struct acquire *icp_dev_acquire_info;};
struct frame_buffer {uint32_t buf_ptr[2],meta_buf_ptr[2];};
struct frame_set {struct frame_buffer buffers[2];};
struct ipe_frame_process_data {unsigned max_num_cores,target_time,frames_in_batch;
unsigned strip_lib_out_addr,iq_settings_addr,scratch_buffer_addr,ubwc_stats_buffer_addr,cdm_buffer_addr,cdm_prog_base;
struct frame_set framesets[2];};
struct bps_frame_process_data {unsigned max_num_cores,target_time,ubwc_stats_buffer_addr,cdm_buffer_addr,iq_settings_addr,strip_lib_out_addr,cdm_prog_addr;
struct frame_buffer buffers[2];};
static union {max_align_t alignment;unsigned char bytes[4096];} storage;
static int fail_index,fail_kind,current_index,get_calls,put_calls,bad_put;
static int acquired[32],released[32];
static int cam_mem_get_io_buf(int h,int iommu,uint64_t *addr,size_t *len) {
(void)iommu;current_index=get_calls++;*addr=(uint64_t)0x10000;*len=sizeof(storage);
if(current_index==fail_index&&fail_kind==1)return -EIO;
(void)h;return 0;}
static int cam_mem_get_cpu_buf(int h,uintptr_t *addr,size_t *len){
if(current_index==fail_index&&fail_kind==4)return -EIO;
acquired[h]++;*addr=(uintptr_t)storage.bytes;*len=sizeof(storage);
if(current_index==fail_index&&fail_kind==5)*addr=0;
if(current_index==fail_index&&fail_kind==6)*len=0;
if(current_index==fail_index&&fail_kind==8)*len=32;
return 0;}
static int cam_mem_put_cpu_buf(int h){put_calls++;released[h]++;
if(released[h]>acquired[h])bad_put++;return 0;}
''' + function(text,'cam_icp_mgr_put_cmd_buf')+'\n'+function(text,'cam_icp_mgr_process_cmd_desc')+r'''
static unsigned cases;
static void check(int condition,const char *s){if(!condition){fprintf(stderr,"case %u kind %d index %d: %s\n",cases,fail_kind,fail_index,s);exit(1);}}
static void one(unsigned n,unsigned mask,int failure,int kind,int duplicate,int bps){
struct cam_packet p={0};struct cam_icp_hw_mgr mgr={1};struct acquire ac={bps?7:0};struct cam_icp_hw_ctx_data ctx={&ac};
struct cam_cmd_buf_desc *d=(void *)p.payload;unsigned i;int fw=0;uint32_t result=0xdeadbeef;int rc;
cases++;memset(&storage,0,sizeof(storage));memset(acquired,0,sizeof(acquired));memset(released,0,sizeof(released));
get_calls=put_calls=bad_put=0;current_index=-1;fail_index=failure;fail_kind=kind;p.num_cmd_buf=n;
for(i=0;i<n;i++){
 d[i]=(struct cam_cmd_buf_desc){duplicate?1:(int)i+1,(mask>>i)&1,0,128,64};
 if(d[i].type){
  if(fw==failure){if(kind==2)d[i].offset=sizeof(storage);if(kind==3)d[i].size=sizeof(storage)+1;if(kind==7)d[i].length=129;}
  fw++;
 }
}
rc=cam_icp_mgr_process_cmd_desc(&mgr,&p,&ctx,&result);
if(failure>=0||!fw){
 check(rc<0,"failure path returned success");check(result==0,"failure exposed stale IOVA");
 for(i=0;i<32;i++)check(acquired[i]==released[i],"unbalanced CPU buffer access");
 check(!bad_put,"released CPU buffer without acquired access");
}else{
 check(rc==0&&result!=0,"valid frame failed");check(put_calls==0,"success prematurely released CPU buffer");
 cam_icp_mgr_put_cmd_buf(&p);
 for(i=0;i<32;i++)check(acquired[i]==released[i],"caller release did not balance success");
 check(!bad_put,"duplicate release on success");
}}
int main(void){unsigned n,mask;int bps,dup,k,f;for(n=0;n<=5;n++)for(mask=0;mask<(1u<<n);mask++)
for(bps=0;bps<2;bps++)for(dup=0;dup<2;dup++){
 int fw=0;for(unsigned i=0;i<n;i++)fw+=(mask>>i)&1;
 one(n,mask,-1,0,dup,bps);
 for(f=0;f<fw;f++)for(k=1;k<=8;k++)one(n,mask,f,k,dup,bps);
}
printf("camera_cases=%u PASS\n",cases);return 0;}
'''

def touch_harness(text: str)->str:
    return r'''
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint32_t u32;
#define ABS_X 0
#define ABS_Y 1
#define ABS_PRESSURE 2
#define ABS_MT_POSITION_X 3
#define ABS_MT_POSITION_Y 4
#define ABS_MT_PRESSURE 5
#define dev_warn(...) ((void)0)
#define swap(a,b) do {__typeof__(a) temp=(a);(a)=(b);(b)=temp;}while(0)
struct device {struct device *parent;};
struct input_absinfo {int maximum,fuzz;};
struct input_dev {struct device dev;struct input_absinfo *absinfo;unsigned long absbit[1];};
struct touchscreen_properties {unsigned max_x,max_y;bool invert_x,invert_y,swap_x_y;};
static unsigned property_mask,reads[6];
static int device_property_read_u32(struct device *dev,const char *key,u32 *val){
(void)dev;const char *keys[]={"touchscreen-size-x","touchscreen-fuzz-x","touchscreen-size-y","touchscreen-fuzz-y","touchscreen-max-pressure","touchscreen-fuzz-pressure"};
for(unsigned i=0;i<6;i++)if(!strcmp(key,keys[i])){reads[i]++;if(!(property_mask&(1u<<i)))return -1;*val=100+i;return 0;}abort();}
static bool device_property_read_bool(struct device *d,const char *n){(void)d;(void)n;return false;}
static void input_alloc_absinfo(struct input_dev *d){(void)d;}
static int test_bit(unsigned long bit,const unsigned long *p){return !!(*p&(1ul<<bit));}
static unsigned input_abs_get_max(struct input_dev *d,unsigned i){return d->absinfo[i].maximum;}
static unsigned input_abs_get_fuzz(struct input_dev *d,unsigned i){return d->absinfo[i].fuzz;}
'''+'\n'.join(function(text,n) for n in ('touchscreen_get_prop_u32','touchscreen_set_params','touchscreen_parse_properties'))+r'''
int main(void){unsigned cases=0;for(unsigned mask=0;mask<64;mask++)for(unsigned mt=0;mt<2;mt++){
 struct device dev={0};struct input_absinfo abs[6];struct input_dev in={{&dev},abs,{63}};
 for(unsigned i=0;i<6;i++){abs[i].maximum=20+i;abs[i].fuzz=3+i;}
 property_mask=mask;memset(reads,0,sizeof(reads));touchscreen_parse_properties(&in,mt,NULL);
 for(unsigned i=0;i<6;i++)if(reads[i]!=1){fprintf(stderr,"property %u not read exactly once\n",i);return 1;}
 for(unsigned i=0;i<6;i++){
  unsigned local=i%3;bool changed=(i/3==mt);unsigned a=local*2;
  int max=20+i,fuzz=3+i;
  if(changed){if(mask&(1u<<a))max=100+a-(local!=2);if(mask&(1u<<(a+1)))fuzz=101+a;}
  if(abs[i].maximum!=max||abs[i].fuzz!=fuzz){fprintf(stderr,"touch values changed mask %u axis %u\n",mask,i);return 1;}
 }
 cases++;}
printf("touch_cases=%u PASS\n",cases);return 0;}
'''

def alignment_harness(text: str)->str:
    a=text.index('struct __call_single_data {');b=text.index(';',text.index('__aligned(sizeof(struct __call_single_data))',a))+1
    proto=re.search(r'^int smp_call_function_single_async\([^;]+;',text,re.M)
    if not proto:raise ValueError('SMP prototype missing')
    return '#include <stddef.h>\n#define __aligned(x) __attribute__((aligned(x)))\nstruct llist_node {struct llist_node *next;};\ntypedef void (*smp_call_func_t)(void *);\n'+text[a:b]+'\n'+proto[0]+r'''
_Static_assert(sizeof(struct __call_single_data)==32,"natural object size changed");
_Static_assert(_Alignof(struct __call_single_data)==8,"natural alignment changed");
_Static_assert(_Alignof(call_single_data_t)==32,"default allocation alignment changed");
struct request_like {char padding[24];struct __call_single_data csd;};
_Static_assert(offsetof(struct request_like,csd)==24,"request field offset changed");
int natural(struct request_like *r){return smp_call_function_single_async(0,&r->csd);}
int aligned(call_single_data_t *p){return smp_call_function_single_async(0,p);}
'''

def warning_gate(logs: list[Path])->dict:
    matches=[(p.name,l) for p in logs for l in p.read_text(errors='replace').splitlines()
             if 'warning:' in l and any(c in l for c in TARGET_CATEGORIES)]
    if matches:raise ValueError('Target group-1 warnings remain: '+str(matches[:5]))
    return {'target_categories':list(TARGET_CATEGORIES),'remaining_target_diagnostics':0,
            'scope':'only specified compiler warning categories; not zero total warnings'}

def run_behavior(source: Path,stage: Path,tool: dict)->dict:
    refs=Path(__file__).resolve().parents[3]/'docs/sweet/r9/reference'
    out=stage/'group1_behavior';out.mkdir()
    env=dict(os.environ)
    results={'mocked_kernel_apis':True,'device_tested':False,'cases':{}}
    for name,path,emit in [('camera',CAMERA,camera_harness),('touch',TOUCH,touch_harness),('alignment','include/linux/smp.h',alignment_harness)]:
        for version in ('before','after'):
            text=(refs/version/path).read_text()
            if version=='after' and text!=(source/path).read_text():raise ValueError('Fixture is not compiled source: '+path)
            c=out/f'{name}_{version}.c';c.write_text(emit(text))
            extra={'camera':['-Werror=unsequenced'],'touch':['-Werror=bitwise-instead-of-logical'],'alignment':['-Werror=align-mismatch']}[name]
            command=[tool['cc'],'-std=gnu11','-O1','-Wall','-Wextra',*extra,'-c',str(c),'-o',str(out/'probe.o')]
            done=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
            (out/f'{name}_{version}_diagnostic.log').write_text(done.stdout)
            if (version=='before')!=(done.returncode!=0):raise ValueError('Warning reproduction/gate failed: '+name+' '+version)
            # Old sources must fail for the expected diagnostic, not another compiler error.
            diag=extra[0].replace('-Werror=', '-W')
            if version=='before' and diag not in done.stdout:raise ValueError('Unexpected baseline diagnostic')
            if name=='alignment':continue
            exe=out/f'{name}_{version}'
            run_cmd=[tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-o',str(exe)]
            r7.run(run_cmd,out/f'{name}_{version}_build.log',env=env)
            done=subprocess.run([str(exe)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60,env=env)
            (out/f'{name}_{version}_run.log').write_text(done.stdout)
            expected_fail=(name=='camera' and version=='before')
            if (done.returncode!=0)!=expected_fail:raise ValueError('Behavior test failed: '+name+' '+version)
            if not expected_fail:
                match=re.search(rf'{name}_cases=(\d+) PASS',done.stdout)
                if not match:raise ValueError('Missing behavior result')
                results['cases'][name+'_'+version]=int(match[1])
            exe.unlink()
        results[name]={'original_diagnostic_reproduced':True,'fixed_diagnostic_absent':True}
    # Ensure the behavioral tests reject tempting but incorrect partial fixes.
    mutants = [
        ('camera_range_off_by_one', camera_harness((source/CAMERA).read_text().replace(
            'cpu_buf_end = i + 1;', 'cpu_buf_end = i;'))),
        ('touch_short_circuit', touch_harness((refs/'before'/TOUCH).read_text().replace(
            '&maximum) |', '&maximum) ||'))),
    ]
    results['negative_controls'] = []
    for name, code in mutants:
        c=out/(name+'.c');c.write_text(code);exe=out/name
        r7.run([tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined',
                '-fno-omit-frame-pointer',str(c),'-o',str(exe)],out/(name+'_build.log'),env=env)
        done=subprocess.run([str(exe)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                            text=True,timeout=60,env=env)
        (out/(name+'_run.log')).write_text(done.stdout)
        expected='unbalanced CPU buffer access' if name.startswith('camera') else 'not read exactly once'
        if done.returncode == 0 or expected not in done.stdout:
            raise ValueError('Behavior test missed deliberately incorrect repair: '+name)
        results['negative_controls'].append({'name':name,'rejected_as_expected':True})
        exe.unlink()
    (out/'probe.o').unlink(missing_ok=True)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    return results
