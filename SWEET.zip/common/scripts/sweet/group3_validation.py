"""R11 error-path regression checks: extracted C, mocked kernel APIs, ASan/UBSan.
These are not hardware tests. The frozen references are compared before executing.
"""
from __future__ import annotations
import hashlib,json,os,re,subprocess
from pathlib import Path
import stage_r7 as r7
ROOT=Path(__file__).resolve().parents[3]
LOCK=ROOT/'lineages/sweet/candidates/r11.json'
XLOG='drivers/char/xlogchar.c'
BOOST='drivers/cpufreq/cpu-boost.c'
HW='arch/arm64/kernel/hwconf_manager.c'
def function(text:str,name:str)->str:
    m=re.search(r'^[^\n;{}]*\b'+re.escape(name)+r'\([^;{}]*\)\s*\{',text,re.M)
    if not m:raise ValueError('Function definition missing: '+name)
    start=text.index('{',m.start());j=start+1;depth=1
    while depth and j<len(text):
        depth+=(text[j]=='{')-(text[j]=='}');j+=1
    if depth:raise ValueError('Unbalanced function: '+name)
    return text[m.start():j]
def warning_gate(logs:list[Path])->dict:
    targets={(r['path'],r['variable'].split('@')[0]) for r in json.loads(LOCK.read_text())['targeted_variables']}
    found=[]
    pattern=re.compile(r"([^\s:]+\.c):\d+:\d+: warning: variable '([^']+)' set but not used")
    for log in logs:
        for line in log.read_text(errors='replace').splitlines():
            m=pattern.search(line)
            if m and any(m[1].endswith(p) and m[2]==v for p,v in targets):found.append({'log':log.name,'line':line})
    if found:raise ValueError('Targeted R11 warning remains: '+str(found[:4]))
    return {'targeted_source_sites':12,'remaining_target_diagnostics':0,'logs_checked':[p.name for p in logs], 'warnings_not_suppressed':True}
COMMON=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#define __user
#define pr_err(...) ((void)0)
#define pr_info(...) ((void)0)
#define pr_debug(...) ((void)0)
static unsigned cases;
#define REQUIRE(c) do { if(!(c)){fprintf(stderr,"ORACLE: line=%d case=%u: %s\n",__LINE__,cases,#c);exit(1);} }while(0)
struct file {int unused;};
'''
def xlog_harness(text:str)->str:
    return COMMON+r'''
typedef uint64_t u64;
#define ERESTARTSYS 512
#define XLOGBUF_SIZE 2048
#define XLOGPKG_SIZE 512
struct xlogchar_dev {size_t readindex,writeindex,free_size;int xlog_mutex,wait_q;char *buf;};
static char ring[XLOGBUF_SIZE],user[2*XLOGBUF_SIZE],saved[XLOGBUF_SIZE];
static struct xlogchar_dev device,*xlogdriver=&device;
static int copies,fault_at,partial,wakes,waits,wait_error;
static unsigned do_div_impl(u64 *n,unsigned d){unsigned r=*n%d;*n/=d;return r;}
#define do_div(n,d) do_div_impl(&(n),d)
static void mutex_lock(int *m){REQUIRE(*m==0);*m=1;}
static void mutex_unlock(int *m){REQUIRE(*m==1);*m=0;}
static unsigned long cp(void *to,const void *from,size_t n){
 copies++;REQUIRE(device.xlog_mutex==1);if(!n)return 0;
 if(!to||!from)return n;
 if(copies==fault_at){size_t k=partial?n/2:0;if(k)memcpy(to,from,k);return n-k;}
 memcpy(to,from,n);return 0;
}
#define copy_to_user(a,b,n) cp(a,b,n)
#define copy_from_user(a,b,n) cp(a,b,n)
static void wake_up_interruptible(int *q){(void)q;REQUIRE(device.xlog_mutex==0);wakes++;}
static int wait_mock(int condition){(void)condition;REQUIRE(device.xlog_mutex==0);waits++;REQUIRE(waits==1);if(!wait_error)device.free_size=0;return wait_error;}
#define wait_event_interruptible(q,c) wait_mock(c)
'''+function(text,'xlogchar_read')+'\n'+function(text,'xlogchar_write')+r'''
static void reset(size_t pos,bool write){
 copies=wakes=waits=wait_error=0;device=(struct xlogchar_dev){pos,pos,write?XLOGBUF_SIZE:0,0,0,ring};
 for(size_t i=0;i<sizeof(ring);i++)ring[i]=(char)(i^(i>>8));
 for(size_t i=0;i<sizeof(user);i++)user[i]=(char)(i^(i>>7)^0x55);
 memcpy(saved,ring,sizeof(ring));
}
static void trial(bool write,size_t pos,size_t n,int fail,int part){
 reset(pos,write);fault_at=fail;partial=part;
 size_t oldfree=device.free_size;bool split=pos+n>XLOGBUF_SIZE;
 int calls=split?2:1;size_t first=split?XLOGBUF_SIZE-pos:n;
 bool fails=(fail==1&&first>0)||(fail==2&&split&&n-first>0);
 ssize_t rc=write?xlogchar_write(NULL,user,n,NULL):xlogchar_read(NULL,user,n,NULL);
 REQUIRE(rc==(fails?-EFAULT:(ssize_t)n));REQUIRE(device.xlog_mutex==0);
 REQUIRE(copies==(fails?fail:calls));REQUIRE(waits==0);REQUIRE(wakes==(write&&!fails));
 REQUIRE(device.free_size==(fails?oldfree:(write?oldfree-n:oldfree+n)));
 size_t next=split?n-first:pos+n;
 REQUIRE((write?device.writeindex:device.readindex)==(fails?pos:next));
 REQUIRE((write?device.readindex:device.writeindex)==pos);
 if(!fails)for(size_t i=0;i<n;i++){
  size_t slot=(pos+i)%XLOGBUF_SIZE;
  REQUIRE(write?ring[slot]==user[i]:user[i]==saved[slot]);
 }
 cases++;
}
int main(void){
 for(int write=0;write<2;write++)for(size_t pos=0;pos<=XLOGBUF_SIZE;pos+=512)
  for(size_t n=0;n<=XLOGBUF_SIZE;n+=512)for(int f=0;f<=2;f++)for(int part=0;part<2;part++)trial(write,pos,n,f,part);
 for(int e=0;e<3;e++){
  reset(0,false);device.free_size=XLOGBUF_SIZE;wait_error=(int[]){-ERESTARTSYS,-EINTR,0}[e];fault_at=0;
  ssize_t rc=xlogchar_read(NULL,user,512,NULL);REQUIRE(rc==(wait_error?wait_error:512));
  REQUIRE(device.xlog_mutex==0);REQUIRE(waits==1);REQUIRE(copies==(wait_error?0:1));cases++;
 }
 for(int w=0;w<2;w++)for(int invalid=0;invalid<2;invalid++){
  reset(0,w);size_t n=invalid?XLOGBUF_SIZE+512:1;
  ssize_t rc=w?xlogchar_write(NULL,user,n,NULL):xlogchar_read(NULL,user,n,NULL);
  REQUIRE(rc==-EBADMSG);REQUIRE(copies==0&&wakes==0&&device.xlog_mutex==0);cases++;
 }
 reset(0,true);device.free_size=0;REQUIRE(xlogchar_write(NULL,user,512,NULL)==-EIO);REQUIRE(device.xlog_mutex==0&&copies==0);cases++;
 printf("PASS xlog cases=%u\n",cases);return 0;
}
'''
def boost_harness(text:str)->str:
    return COMMON+r'''
struct cpu_sync {int cpu;};static struct cpu_sync sync_info[4];
static int queue_storage,boost_adjust_nb,cpuboost_input_handler,input_boost_work,powerkey_input_boost_work,input_boost_rem;
static int *cpu_boost_wq;static int fail_alloc,notifier_rc,input_rc,notifier_live,handler_live,destroyed,notifier_calls,input_calls,unregister_calls;
#define WQ_HIGHPRI 1
#define CPUFREQ_POLICY_NOTIFIER 2
#define INIT_WORK(a,b) ((void)(a))
#define INIT_DELAYED_WORK(a,b) ((void)(a))
#define per_cpu(x,c) (x[c])
#define for_each_possible_cpu(c) for(c=0;c<4;c++)
static int *alloc_workqueue(const char *n,int flags,int max){(void)n;(void)flags;(void)max;return fail_alloc?NULL:&queue_storage;}
static int cpufreq_register_notifier(int *n,int which){(void)n;REQUIRE(which==2);notifier_calls++;if(!notifier_rc)notifier_live=1;return notifier_rc;}
static int cpufreq_unregister_notifier(int *n,int which){(void)n;(void)which;REQUIRE(notifier_live);notifier_live=0;unregister_calls++;return 0;}
static int input_register_handler(int *h){(void)h;input_calls++;if(!input_rc)handler_live=1;return input_rc;}
static void destroy_workqueue(int *q){REQUIRE(q==&queue_storage&&!notifier_live&&!handler_live);destroyed++;}
'''+function(text,'cpu_boost_init')+r'''
int main(void){const int errors[]={0,-EINVAL,-ENOMEM,-EINTR};
 for(fail_alloc=0;fail_alloc<=1;fail_alloc++)for(unsigned i=0;i<4;i++)for(unsigned j=0;j<4;j++){
 notifier_rc=errors[i];input_rc=errors[j];notifier_live=handler_live=destroyed=notifier_calls=input_calls=unregister_calls=0;cpu_boost_wq=NULL;
 int expected=fail_alloc?-EFAULT:(notifier_rc?notifier_rc:input_rc);int result=cpu_boost_init();
 REQUIRE(result==expected);REQUIRE(notifier_calls==!fail_alloc);REQUIRE(input_calls==(!fail_alloc&&!notifier_rc));
 REQUIRE(destroyed==(!fail_alloc&&expected!=0));REQUIRE(notifier_live==(!expected));REQUIRE(handler_live==(!expected));
 REQUIRE(unregister_calls==(!fail_alloc&&!notifier_rc&&input_rc!=0));REQUIRE((cpu_boost_wq!=NULL)==(!expected));
 if(!fail_alloc)for(int c=0;c<4;c++)REQUIRE(sync_info[c].cpu==c);
 cases++;}
 printf("PASS boost cases=%u\n",cases);return 0;}
'''
def hw_harness(text:str)->str:
    return COMMON+r'''
struct kobject {int x;};struct kobj_attribute {int x;};
static int called;static char last[32];
static const char *skip_spaces(const char *s){while(isspace((unsigned char)*s))s++;return s;}
static void unregister_hw_monitor_info(const char *s){REQUIRE(strlen(s)<32);strcpy(last,s);called++;}
'''+function(text,'hw_mon_store')+r'''
static void trial(const char *s,bool valid,int on,const char *name){
 called=0;last[0]=0;size_t count=strlen(s);ssize_t rc=hw_mon_store(NULL,NULL,s,count);
 REQUIRE(rc==(valid?(ssize_t)count:-EINVAL));REQUIRE(called==(valid&&on==0));
 if(called)REQUIRE(!strcmp(last,name));cases++;
}
int main(void){
 const char *invalid[]={"", " ","component", "component x", "  component", "\t\n"};
 for(unsigned i=0;i<sizeof(invalid)/sizeof(invalid[0]);i++)trial(invalid[i],false,0,"");
 char name[600],line[700];const int values[]={-1,0,1,99};const char *spaces[]={"","  ","\t"};
 for(int n=1;n<=31;n++)for(int val=0;val<4;val++)for(int sp=0;sp<3;sp++){
  memset(name,'a',n);name[n]=0;snprintf(line,sizeof(line),"%s%s %d\n",spaces[sp],name,values[val]);trial(line,true,values[val],name);}
 for(int n=32;n<=512;n+=1){
  memset(name,'a',n);name[n]=0;snprintf(line,sizeof(line),"%s 0\n",name);trial(line,false,0,"");
 }
 /* Truncation must not turn a trailing digit of the token into the second field. */
 memset(name,'a',31);name[31]='0';name[32]=0;trial(name,false,0,"");
 printf("PASS hwmon cases=%u\n",cases);return 0;}
'''
def run_behavior(candidate:Path,stage:Path,tool:dict)->dict:
    out=stage/'group3_behavior';out.mkdir(exist_ok=False)
    result={'mocked_kernel_apis':True,'hardware_test':False,'variants':{},'scenarios':{}}
    specs=[('xlog',XLOG,xlog_harness),('boost',BOOST,boost_harness),('hwmon',HW,hw_harness)]
    for area,path,harness in specs:
        before=(ROOT/'docs/sweet/r11/reference/before'/path).read_text()
        after=(candidate/path).read_text();expected=(ROOT/'docs/sweet/r11/reference/after'/path).read_text()
        if after!=expected:raise ValueError('Source differs from reviewed reference: '+path)
        variants={'before':before,'after':after}
        if area=='xlog':
            variants['bad_wait_unlock']=after.replace('if (err) {','if (err) {\n\t\t\tmutex_unlock(&xlogdriver->xlog_mutex);',1)
            variants['bad_commit_on_fault']=after.replace('copy_fault:\n','copy_fault:\n\txlogdriver->free_size = 0;\n')
        elif area=='boost':variants['bad_missing_unregister']=after.replace('\tcpufreq_unregister_notifier(&boost_adjust_nb, CPUFREQ_POLICY_NOTIFIER);','\t/* deliberately omitted */')
        else:variants['bad_ignore_parse_result']=after.replace('len != 2 || ','')
        for label,text in variants.items():
            c=out/f'{area}_{label}.c';exe=out/f'{area}_{label}';c.write_text(harness(text))
            r7.run([tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-o',str(exe)],out/f'{area}_{label}_build.log',timeout=90)
            p=subprocess.run([str(exe)],capture_output=True,text=True,timeout=30,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1'))
            content=p.stdout+p.stderr;(out/f'{area}_{label}_run.log').write_text(content)
            if label=='after':
                m=re.search('PASS '+area+r' cases=(\d+)',content)
                if p.returncode or not m:raise ValueError('Behavior failed: '+area+' '+content[:1000])
                result['scenarios'][area]=int(m[1])
            elif p.returncode!=1 or not content.startswith('ORACLE:'):
                raise ValueError('Negative control did not fail in the behavioral oracle: '+area+' '+label+' '+content[:500])
            result['variants'][area+'_'+label]={'exit_code':p.returncode,'expected_pass':label=='after','expectation_met':True,'harness_sha256':hashlib.sha256(c.read_bytes()).hexdigest()}
            exe.unlink()
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');return result
