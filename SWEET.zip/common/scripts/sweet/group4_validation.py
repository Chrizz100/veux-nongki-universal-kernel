"""R12: fault-injection tests of the actual MSM RNG probe, with mocked kernel APIs.
No hardware, entropy-quality, concurrency, module-unload or vendor ABI approval.
"""
from __future__ import annotations
import hashlib,json,os,re,subprocess
from pathlib import Path
import stage_r7 as r7
from group3_validation import function
ROOT=Path(__file__).resolve().parents[3]
LOCK=ROOT/'lineages/sweet/candidates/r12.json'
RNG='drivers/char/hw_random/msm_rng.c'
def warning_gate(logs:list[Path])->dict:
 targets={(x['path'],x['variable'].split('@')[0]) for x in json.loads(LOCK.read_text())['targeted_variables']}
 found=[]
 pattern=re.compile(r"([^\s:]+\.c):\d+:\d+: warning: variable '([^']+)' set but not used")
 for path in logs:
  for line in path.read_text(errors='replace').splitlines():
   m=pattern.search(line)
   if m and any(m[1].endswith(p) and m[2]==v for p,v in targets):found.append(line)
 if found:raise ValueError('R12 targeted warning returned: '+str(found[:3]))
 return {'targeted_source_sites':7,'remaining_target_diagnostics':0,'logs_checked':[p.name for p in logs],'warnings_not_suppressed':True}
def rng_harness(text:str)->str:
 return r'''
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#define __iomem
#define GFP_KERNEL 0
#define IORESOURCE_MEM 0
#define QRNG_IOC_MAGIC 0x100
#define DRIVER_NAME "msm_rng"
#define THIS_MODULE 0
#define MKDEV(a,b) (((a)<<8)|(b))
#define pr_err(...) ((void)0)
#define dev_err(...) ((void)0)
#define IS_ERR(p) ((uintptr_t)(p)>=(uintptr_t)-4095)
#define PTR_ERR(p) ((long)(intptr_t)(p))
#define ERR_PTR(e) ((void*)(intptr_t)(e))
static unsigned cases;
static int fault,errcode,expected,tripped,node,no_clock,no_cfg,bus_absent;
static int live_mem,live_map,live_clk,live_bus,live_hr,live_chr,live_class,live_device;
static int seq,hr_unreg_seq,chr_unreg_seq,bus_unreg_seq,free_seq;
#define CHECK(c) do{if(!(c)){fprintf(stderr,"ORACLE case=%u fault=%d line=%d: %s\n",cases,fault,__LINE__,#c);exit(1);}}while(0)
struct device {void *of_node;};
struct platform_device {struct device dev;void *data;};
struct resource {unsigned long start;};
struct clk {int x;};
struct msm_rng_device {struct platform_device *pdev;void *base;struct clk *prng_clk;uint32_t qrng_perf_client;int rng_lock;};
struct msm_bus_scale_pdata {int x;};
struct hwrng {unsigned long priv;};
struct class {int x;};
struct cdev {int x;};
static struct resource res_obj;
static struct clk clk_obj;
static struct class class_obj,*msm_rng_class;
static struct device dev_obj;
static struct cdev msm_rng_cdev;
static struct msm_bus_scale_pdata pdata_obj;
static struct msm_rng_device msm_rng_device_info,*msm_rng_dev_cached;
static struct hwrng msm_rng;
static int cached_rng_lock,msm_rng_fops;
static char regs[32];
static int hit(int n,int e){if(fault==n){tripped=1;expected=e;return 1;}return 0;}
static struct resource *platform_get_resource(struct platform_device*p,int t,int n){(void)p;(void)t;(void)n;return hit(1,-EFAULT)?NULL:&res_obj;}
static void *kzalloc(size_t n,int f){(void)f;if(hit(2,-ENOMEM))return NULL;CHECK(!live_mem);void*p=calloc(1,n);CHECK(p);live_mem=1;return p;}
static void kzfree(void*p){CHECK(live_mem&&!live_hr&&!live_chr&&!live_class&&!live_device&&!live_bus&&!live_clk&&!live_map);live_mem=0;free_seq=++seq;free(p);}
static size_t resource_size(struct resource*p){(void)p;return sizeof(regs);}
static void *ioremap(unsigned long s,size_t n){(void)s;(void)n;CHECK(live_mem);if(hit(3,-ENOMEM))return NULL;live_map=1;return regs;}
static void iounmap(void*p){CHECK(p==regs&&live_map&&!live_hr);live_map=0;}
static bool of_property_read_bool(void*n,const char*s){CHECK(n);if(!strcmp(s,"qcom,no-clock-support"))return no_clock;if(!strcmp(s,"qcom,no-qrng-config"))return no_cfg;return false;}
static struct clk *clk_get(struct device*d,const char*s){(void)d;(void)s;CHECK(live_map);if(hit(4,-EPERM))return ERR_PTR(errcode);live_clk=1;return &clk_obj;}
static void clk_put(struct clk*p){CHECK(p==&clk_obj&&live_clk&&!live_hr);live_clk=0;}
static void platform_set_drvdata(struct platform_device*p,void*d){p->data=d;}
static struct msm_bus_scale_pdata*msm_bus_cl_get_pdata(struct platform_device*p){(void)p;return &pdata_obj;}
static uint32_t msm_bus_scale_register_client(struct msm_bus_scale_pdata*p){CHECK(p==&pdata_obj);if(bus_absent)return 0;live_bus=1;return 37;}
static void msm_bus_scale_unregister_client(uint32_t h){CHECK(h==37&&live_bus&&!live_hr&&!live_chr);live_bus=0;bus_unreg_seq=++seq;}
static int msm_rng_enable_hw(struct msm_rng_device*d){CHECK(d->base==regs);return hit(5,errcode)?errcode:0;}
static void mutex_init(int*p){*p=0;}
static int hwrng_register(struct hwrng*p){CHECK(p->priv&&live_mem&&live_map);if(hit(6,-EPERM))return errcode;live_hr=1;return 0;}
static void hwrng_unregister(struct hwrng*p){CHECK(p->priv&&live_hr&&live_map&&!live_chr);live_hr=0;hr_unreg_seq=++seq;}
static int register_chrdev(int major,const char*n,const void*f){CHECK(major==QRNG_IOC_MAGIC&&!strcmp(n,DRIVER_NAME)&&f==&msm_rng_fops&&live_hr);if(hit(7,errcode))return errcode;live_chr=1;return 0;}
static void unregister_chrdev(int major,const char*n){CHECK(major==QRNG_IOC_MAGIC&&!strcmp(n,DRIVER_NAME)&&live_chr&&!live_class&&!live_device);live_chr=0;chr_unreg_seq=++seq;}
static struct class*class_create(int owner,const char*n){(void)owner;CHECK(!strcmp(n,"msm-rng")&&live_chr);if(hit(8,errcode))return ERR_PTR(errcode);live_class=1;return &class_obj;}
static void class_destroy(struct class*p){CHECK(p==&class_obj&&live_class&&!live_device);live_class=0;}
static struct device*device_create(struct class*c,void*p,unsigned d,void*x,const char*n){(void)p;(void)d;(void)x;CHECK(c==&class_obj&&live_class&&!strcmp(n,"msm-rng"));if(hit(9,errcode))return ERR_PTR(errcode);live_device=1;return &dev_obj;}
static void cdev_init(struct cdev*c,const void*f){CHECK(c==&msm_rng_cdev&&f==&msm_rng_fops&&live_device);}
'''+function(text,'msm_rng_probe')+r'''
static void reset(void){
 CHECK(!live_mem);live_map=live_clk=live_bus=live_hr=live_chr=live_class=live_device=0;
 tripped=expected=seq=hr_unreg_seq=chr_unreg_seq=bus_unreg_seq=free_seq=0;
 msm_rng=(struct hwrng){0};msm_rng_device_info=(struct msm_rng_device){0};msm_rng_dev_cached=NULL;msm_rng_class=NULL;
}
int main(void){
 for(node=0;node<2;node++)for(no_clock=0;no_clock<2;no_clock++)for(no_cfg=0;no_cfg<2;no_cfg++)for(bus_absent=0;bus_absent<2;bus_absent++)
 for(fault=0;fault<=9;fault++)for(int ec=0;ec<3;ec++){
  reset();errcode=(int[]){-EIO,-ENOMEM,-517}[ec];struct platform_device p={{node?&res_obj:NULL},NULL};
  int rc=msm_rng_probe(&p);
  if(tripped){
   CHECK(rc==expected);CHECK(!live_mem&&!live_map&&!live_clk&&!live_bus&&!live_hr&&!live_chr&&!live_class&&!live_device);
   CHECK(!p.data&&!msm_rng.priv&&!msm_rng_dev_cached&&!msm_rng_device_info.qrng_perf_client);
   CHECK(!msm_rng_class);if(hr_unreg_seq)CHECK(free_seq>hr_unreg_seq);
   if(chr_unreg_seq)CHECK(hr_unreg_seq>chr_unreg_seq);
   if(bus_unreg_seq)CHECK(free_seq>bus_unreg_seq);
  }else{
   CHECK(rc==0&&live_mem&&live_map&&live_hr&&live_chr&&live_class&&live_device);
   CHECK(live_clk==(node&&!no_clock));CHECK(live_bus==(node&&!bus_absent));
   CHECK(p.data==msm_rng_dev_cached&&msm_rng.priv==(unsigned long)p.data&&msm_rng_class==&class_obj);
   /* Teardown of the test fixture, not a claim to test the driver's remove path. */
   free(p.data);live_mem=0;
  }
  cases++;
 }
 printf("MSM RNG probe: %u scenarios passed\n",cases);return 0;
}
'''
def run_behavior(candidate:Path,stage:Path,tool:dict)->dict:
 out=stage/'group4_behavior';out.mkdir(exist_ok=False)
 before=(ROOT/'docs/sweet/r12/reference/before'/RNG).read_text()
 after=(candidate/RNG).read_text()
 if after!=(ROOT/'docs/sweet/r12/reference/after'/RNG).read_text():raise ValueError('R12 RNG differs from reviewed source')
 variants={'before':before,'after':after,
  'bad_ignores_chrdev_error':after.replace('if (error < 0)\n\t\tgoto unregister_hwrng;', 'if (false)\n\t\tgoto unregister_hwrng;'),
  'bad_missing_hwrng_cleanup':after.replace('unregister_hwrng:\n\thwrng_unregister(&msm_rng);','unregister_hwrng:\n\t/* deliberately wrong */'),
  'bad_missing_class_cleanup':after.replace('\tclass_destroy(msm_rng_class);','\t/* deliberately wrong */'),
  'bad_stale_driver_data':after.replace('\tplatform_set_drvdata(pdev, NULL);\n\tif (msm_rng_dev->prng_clk)','\t/* deliberately wrong */\n\tif (msm_rng_dev->prng_clk)')}
 result={'hardware_tested':False,'scope':'probe registration and rollback only; remove/concurrency not tested','variants':{}}
 env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
 for label,text in variants.items():
  if label not in ('before','after') and text==after:raise ValueError('Mutation did not apply: '+label)
  c=out/(label+'.c');exe=out/label;c.write_text(rng_harness(text))
  r7.run([tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-o',str(exe)],out/(label+'_build.log'))
  p=subprocess.run([str(exe)],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=env,timeout=60)
  (out/(label+'_run.log')).write_bytes(p.stdout);exe.unlink()
  want=label=='after'
  if (p.returncode==0)!=want:raise ValueError('RNG fault-injection expectation failed: '+label)
  if want and b'480 scenarios passed' not in p.stdout:raise ValueError('Wrong test count')
  if not want and b'ORACLE' not in p.stdout:raise ValueError('Negative test failed for an unrelated reason: '+label)
  result['variants'][label]={'exit_code':p.returncode,'expected_pass':want,'expectation_met':True,'harness_sha256':hashlib.sha256(c.read_bytes()).hexdigest()}
 result['scenarios']=480;(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');return result
