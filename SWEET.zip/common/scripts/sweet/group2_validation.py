"""R10: checks for selected unused values and negative FocalTech polling results.

Tests compile extracted C functions with mocked device I/O. Not hardware tests.
"""
from __future__ import annotations
import hashlib,json,os,re,subprocess
from pathlib import Path
import stage_r7 as r7
def function(text:str,name:str)->str:
    # Select a definition, never the earlier forward declaration.
    m=re.search(r'^static bool\s+'+re.escape(name)+r'\([^;{}]*\)\s*\{',text,re.M)
    if not m:raise ValueError('Polling definition not found: '+name)
    start=text.index('{',m.start());depth=1;i=start+1
    while depth and i<len(text):
        depth+=(text[i]=='{')-(text[i]=='}');i+=1
    if depth:raise ValueError('Unbalanced polling definition')
    return text[m.start():i]

ROOT=Path(__file__).resolve().parents[3]
FTS='drivers/input/touchscreen/k6_focaltech_3658u/focaltech_flash.c'
LOCK=ROOT/'lineages/sweet/candidates/r10.json'

def warning_gate(logs:list[Path])->dict:
    targets={(r['path'],r['variable'].split('@')[0]) for r in json.loads(LOCK.read_text())['targeted_variables']}
    found=[]
    pattern=re.compile(r"([^\s:]+\.c):\d+:\d+: warning: variable '([^']+)' set but not used")
    for log in logs:
        for line in log.read_text(errors='replace').splitlines():
            m=pattern.search(line)
            if m and any(m[1].endswith(p) and m[2]==v for p,v in targets):
                found.append({'log':log.name,'line':line})
    if found:raise ValueError('Targeted R10 warning remains: '+str(found[:4]))
    return {'targeted_source_sites':15,'remaining_target_diagnostics':0,'logs_checked':[p.name for p in logs],
            'all_other_warnings_remain_visible':True}

def harness(text:str)->str:
    # Same loop/delay constants as the pinned header. No actual sleeping or I2C.
    return r'''
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
typedef uint8_t u8; typedef uint16_t u16;
enum FW_STATUS { FTS_RUN_IN_ERROR, FTS_RUN_IN_APP, FTS_RUN_IN_ROM, FTS_RUN_IN_PRAM, FTS_RUN_IN_BOOTLOADER };
struct fts_upgrade {int unused;};
#define FTS_UPGRADE_LOOP 30
#define FTS_DELAY_READ_ID 20
#define FTS_CMD_FLASH_STATUS 0x6a
#define FTS_CMD_FLASH_STATUS_LEN 2
#define FTS_ERROR(...) ((void)0)
static int pattern,read_calls,sleep_calls,ms_total,which_state;
static u16 wanted;
static unsigned cases;
static int next_mode(void){int index=read_calls++;return index<4?(pattern>>(index*2))&3:0;}
static void msleep(int ms){sleep_calls++;ms_total+=ms;}
/* Negative-return contents are unspecified; callers must not trust them. */
static int fts_fwupg_get_boot_state(struct fts_upgrade *upg,enum FW_STATUS *state){
 int mode=next_mode();(void)upg;
 if(mode==1 || mode==3)*state=(enum FW_STATUS)which_state;
 if(mode==2)*state=(enum FW_STATUS)((which_state+1)%5);
 return mode<2?-EIO:0;
}
static int fts_read(u8 *cmd,unsigned cmdlen,u8 *data,unsigned len){
 int mode=next_mode();u16 val;
 if(cmdlen!=1||*cmd!=FTS_CMD_FLASH_STATUS||len!=2)exit(20);
 if(mode==0)return -EIO;
 val=(mode==2)?(u16)(wanted^0x100):wanted;
 data[0]=val>>8;data[1]=val&255;
 return mode<2?-EIO:2;
}
''' + function(text,'fts_fwupg_check_state')+'\n'+function(text,'fts_fwupg_check_flash_status')+r'''
static void reset(int p){pattern=p;read_calls=sleep_calls=ms_total=0;}
static int first_good(int p,int limit){for(int i=0;i<limit;i++)if(i<4 && ((p>>(i*2))&3)==3)return i;return -1;}
static void verify(bool ok,int limit,int delay,const char *name){
 int first=first_good(pattern,limit);bool expected=first>=0;
 int reads=expected?first+1:(limit>0?limit:0);
 int sleeps=expected?first:reads;
 if(ok!=expected||read_calls!=reads||sleep_calls!=sleeps||ms_total!=sleeps*delay){
 fprintf(stderr,"%s case=%u pattern=%d target=%u limit=%d ok=%d expected=%d reads=%d/%d sleeps=%d/%d\n",
 name,cases,pattern,wanted,limit,ok,expected,read_calls,reads,sleep_calls,sleeps);exit(1);}
 cases++;
}
int main(void){struct fts_upgrade u={0};
 for(which_state=0;which_state<5;which_state++)for(int p=0;p<256;p++){
 reset(p);verify(fts_fwupg_check_state(&u,(enum FW_STATUS)which_state),FTS_UPGRADE_LOOP,FTS_DELAY_READ_ID,"boot");}
 const u16 desired[]={0,0xf0aa,0xf055,0xffff};const int retry[]={-1,0,1,2,4,8};
 for(unsigned t=0;t<4;t++)for(unsigned n=0;n<6;n++)for(int p=0;p<256;p++){
 wanted=desired[t];reset(p);verify(fts_fwupg_check_flash_status(wanted,retry[n],7),retry[n],7,"flash");}
 printf("PASS: %u polling scenarios; return values, retry count and delays matched.\n",cases);
 return 0;
}
'''

def run_behavior(candidate:Path,stage:Path,tool:dict)->dict:
    out=stage/'group2_behavior';out.mkdir(exist_ok=False)
    ref=ROOT/'docs/sweet/r10/reference/before'/FTS
    original=ref.read_text();fixed=(candidate/FTS).read_text()
    expected=(ROOT/'docs/sweet/r10/reference/after'/FTS).read_text()
    if fixed!=expected:raise ValueError('Polling function source differs from reviewed R10 source')
    variants={'before':original,'after':fixed,
              'bad_ignores_errors':fixed.replace('if (ret >= 0 && cstate == rstate)','if (cstate == rstate)'),
              'bad_aborts_retry':fixed.replace('ret = fts_fwupg_get_boot_state(upg, &cstate);','ret = fts_fwupg_get_boot_state(upg, &cstate);\n\t\tif (ret < 0) return false;'),
              'bad_flash_accepts_error':fixed.replace('if (ret >= 0) {','if (1) {')}
    results={}
    for name,text in variants.items():
        c=out/(name+'.c');exe=out/name;c.write_text(harness(text))
        argv=[tool['cc'],'-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(c),'-o',str(exe)]
        r7.run(argv,out/(name+'_build.log'),timeout=120)
        env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1')
        p=subprocess.run([str(exe)],env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
        (out/(name+'_run.log')).write_text(p.stdout)
        # Nonzero must be the deliberate behavioral oracle failure, not a crash.
        if name=='after':
            if p.returncode!=0 or '7424 polling scenarios' not in p.stdout:
                raise ValueError('R10 polling regression test failed: '+p.stdout[:1000])
        elif p.returncode!=1 or not p.stdout.startswith('boot case=') and not p.stdout.startswith('flash case='):
            raise ValueError('Negative control did not fail through the behavioral oracle: '+name)
        results[name]={'exit_code':p.returncode,'expected_pass':name=='after','expectation_met':True,
                       'harness_sha256':hashlib.sha256(c.read_bytes()).hexdigest()}
        exe.unlink()
    result={'scenarios':7424,'mocked_kernel_io':True,'hardware_test':False,
            'negative_read_results_checked':True,'partial_i2c_transfer_semantics_changed':False,'variants':results}
    (out/'results.json').write_text(json.dumps(result,indent=2)+'\n');return result
