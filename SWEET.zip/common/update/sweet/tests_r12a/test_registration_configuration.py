from pathlib import Path
import hashlib,json,re,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r12a as r12,stage_r11 as r11,group4a_validation as g
class R12Tests(unittest.TestCase):
 def text(self,kind,path):return (ROOT/'docs/sweet/r12a/reference'/kind/path).read_text()
 def test_01_parent(self):self.assertEqual(r12.load_lock()['r11_tree'],r11.load_lock()['candidate_tree'])
 def test_02_no_flash(self):self.assertIs(r12.load_lock()['flashable'],False)
 def test_03_patch_hashes(self):
  for p in r12.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/p['path']).read_bytes()).hexdigest(),p['sha256'])
 def test_04_before_hashes(self):
  for p in r12.load_lock()['changed_from_r11']:self.assertEqual(hashlib.sha256(self.text('before',p['path']).encode()).hexdigest(),p['before_sha256'])
 def test_05_after_hashes(self):
  for p in r12.load_lock()['changed_from_r11']:self.assertEqual(hashlib.sha256(self.text('after',p['path']).encode()).hexdigest(),p['after_sha256'])
 def test_06_expected_scope(self):
  l=r12.load_lock();self.assertEqual(len(l['patches']),2);self.assertEqual(len(l['changed_from_r11']),10);self.assertEqual(len(l['targeted_variables']),12)
 def test_07_combined_no_duplicate_files(self):
  v=r12.combined_lock(r12.load_lock())['changed_files'];self.assertEqual(len(v),len({p['path'] for p in v}))
 def test_08_old_patches_unchanged(self):
  old=r11.combined_lock(r11.load_lock())['patches'];self.assertEqual(r12.combined_lock(r12.load_lock())['patches'][:len(old)],old)
 def test_09_tree_fingerprint(self):self.assertRegex(r12.load_lock()['candidate_tree'],r'^[0-9a-f]{40}$')
 def test_10_no_diagnostic_suppression(self):
  for p in r12.load_lock()['patches']:
   s=(ROOT/p['path']).read_text()
   for token in ['-Wno-','diagnostic ignored','__maybe_unused','__attribute__((unused))']:self.assertNotIn(token,s)
 def test_11_registrations_retained(self):
  b=g.function(self.text('before',g.RNG),'msm_rng_probe');a=g.function(self.text('after',g.RNG),'msm_rng_probe')
  for token in ['hwrng_register(','register_chrdev(','class_create(','device_create(','msm_rng_enable_hw(']:self.assertEqual(a.count(token),b.count(token))
 def test_12_chrdev_result_checked(self):
  a=g.function(self.text('after',g.RNG),'msm_rng_probe');self.assertIn('if (error < 0)\n\t\tgoto unregister_hwrng;',a)
 def test_13_class_error_unwinds(self):
  a=g.function(self.text('after',g.RNG),'msm_rng_probe');self.assertIn('error = PTR_ERR(msm_rng_class);\n\t\tmsm_rng_class = NULL;\n\t\tgoto unregister_chrdev;',a)
 def test_14_device_error_unwinds(self):
  a=g.function(self.text('after',g.RNG),'msm_rng_probe');self.assertIn('error = PTR_ERR(dev);\n\t\tgoto destroy_class;',a)
 def test_15_cleanup_order(self):
  a=g.function(self.text('after',g.RNG),'msm_rng_probe').split('destroy_class:')[1]
  ops=['class_destroy(','unregister_chrdev(','hwrng_unregister(','msm_bus_scale_unregister_client(','clk_put(','iounmap(','kzfree('];v=[a.index(x) for x in ops];self.assertEqual(v,sorted(v))
 def test_16_failed_probe_clears_pointers(self):
  a=g.function(self.text('after',g.RNG),'msm_rng_probe');self.assertIn('platform_set_drvdata(pdev, NULL);',a);self.assertIn('msm_rng.priv = 0;',a);self.assertIn('msm_rng_device_info.qrng_perf_client = 0;',a)
 def test_17_rng_generation_unchanged(self):
  for fn in ['msm_rng_direct_read','msm_rng_enable_hw','qrng_get_random']:self.assertEqual(g.function(self.text('before',g.RNG),fn),g.function(self.text('after',g.RNG),fn))
 def test_18_hotplug_error_returns_and_cleans(self):
  a=g.function(self.text('after',g.TRACE),'init_tracecounters');self.assertIn('if (rc < 0) {\n\t\tdebugfs_remove_recursive(dir);\n\t\treturn rc;',a)
 def test_19_hotplug_parameters_unchanged(self):
  b=g.function(self.text('before',g.TRACE),'init_tracecounters');a=g.function(self.text('after',g.TRACE),'init_tracecounters');self.assertEqual(b.split('cpuhp_setup_state_nocalls(')[1].split(');')[0],a.split('cpuhp_setup_state_nocalls(')[1].split(');')[0])
 def test_20_node_selection_retains_call(self):
  a=g.function(self.text('after',g.VMSCAN),'try_to_free_mem_cgroup_pages');self.assertIn('nid = mem_cgroup_select_victim_node(memcg);',a);self.assertIn('zonelist = node_zonelist(nid, GFP_KERNEL);',a)
 def test_21_quota_debug_and_operations_preserved(self):
  a=g.function(self.text('after',g.QUOTA),'remove_dquot_ref');b=g.function(self.text('before',g.QUOTA),'remove_dquot_ref');self.assertIn('IS_ENABLED(CONFIG_QUOTA_DEBUG) && reserved',a)
  for token in ['inode_get_rsv_space(','remove_inode_dquot_ref(','spin_lock(','spin_unlock(','printk(']:self.assertEqual(a.count(token),b.count(token))
 def test_22_sctp_zeroing_kept(self):
  a=g.function(self.text('after','net/sctp/sm_make_chunk.c'),'sctp_make_auth');self.assertIn('skb_put_zero(retval->skb, hmac_desc->hmac_len);',a)
 def test_23_selinux_decisions_preserved(self):
  p='security/selinux/hooks.c';a=g.function(self.text('after',p),'selinux_inode_init_security');b=g.function(self.text('before',p),'selinux_inode_init_security')
  self.assertEqual(b.replace('u32 sid, newsid, clen;','u32 newsid, clen;').replace('\tsid = tsec->sid;\n',''),a)
 def test_24_pcm_checks_and_callbacks_retained(self):
  for p,names in [('sound/core/pcm_native.c',['snd_compressed_ioctl','snd_user_ioctl']),('sound/core/pcm_compat.c',['snd_compressed_ioctl32','snd_user_ioctl32'])]:
   for fn in names:
    a=g.function(self.text('after',p),fn);b=g.function(self.text('before',p),fn);self.assertEqual(a,b.replace('\tstruct snd_pcm_runtime *runtime;\n','').replace('\truntime = substream->runtime;\n',''))
 def test_25_target_warning_fails(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'w.log';p.write_text("/tmp/candidate/mm/vmscan.c:1:3: warning: variable 'nid' set but not used [-Wunused-but-set-variable]\n")
   with self.assertRaises(ValueError):g.warning_gate([p])
 def test_26_other_warning_stays_visible(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'w.log';text="/tmp/candidate/other.c:1:3: warning: variable 'nid' set but not used [-Wunused-but-set-variable]\n";p.write_text(text);self.assertEqual(g.warning_gate([p])['remaining_target_diagnostics'],0);self.assertEqual(p.read_text(),text)
 def test_27_stage_build_checks(self):
  s=(ROOT/'common/scripts/sweet/stage_r12a.py').read_text();self.assertEqual(r12.FULL_TARGETS,('Image.gz',))
  for token in ['group1.warning_gate','group2.warning_gate','group3.warning_gate','group4.warning_gate','group4.run_behavior',"'KBUILD_BUILTIN=1'","'sound/core/pcm_native.o'","'security/selinux/'",'if changes:']:self.assertIn(token,s)
 def test_28_config_and_crc_reference(self):
  self.assertEqual(r12.check_config((ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes())['unchanged_values'],4987)
  a=(ROOT/'docs/sweet/r12a/reference/R11.Module.symvers').read_bytes();b=(ROOT/'docs/sweet/r11/reference/R10.Module.symvers').read_bytes();self.assertEqual(a,b);self.assertEqual(len(a.splitlines()),11742)
if __name__=='__main__':unittest.main()
