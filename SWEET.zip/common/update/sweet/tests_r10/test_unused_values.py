from pathlib import Path
import hashlib,json,re,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r10 as r10
import stage_r9 as r9
import group2_validation as g

class UnusedValueTests(unittest.TestCase):
    def text(self,kind,path):return (ROOT/'docs/sweet/r10/reference'/kind/path).read_text()
    def test_01_parent(self):self.assertEqual(r10.load_lock()['r9_tree'],r9.load_lock()['candidate_tree'])
    def test_02_no_flash(self):self.assertIs(r10.load_lock()['flashable'],False)
    def test_03_two_patches(self):self.assertEqual(len(r10.load_lock()['patches']),2)
    def test_04_twelve_paths(self):self.assertEqual(len(r10.load_lock()['changed_from_r9']),12)
    def test_05_fifteen_warning_sites(self):self.assertEqual(len(r10.load_lock()['targeted_variables']),15)
    def test_06_patch_hashes(self):
        for p in r10.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/p['path']).read_bytes()).hexdigest(),p['sha256'])
    def test_07_before_hashes(self):
        for p in r10.load_lock()['changed_from_r9']:self.assertEqual(hashlib.sha256(self.text('before',p['path']).encode()).hexdigest(),p['before_sha256'])
    def test_08_after_hashes(self):
        for p in r10.load_lock()['changed_from_r9']:self.assertEqual(hashlib.sha256(self.text('after',p['path']).encode()).hexdigest(),p['after_sha256'])
    def test_09_combined_unique(self):
        p=[x['path'] for x in r10.combined_lock(r10.load_lock())['changed_files']];self.assertEqual(len(p),len(set(p)))
    def test_10_original_patch_prefix(self):
        old=r9.combined_lock(r9.load_lock())['patches'];new=r10.combined_lock(r10.load_lock())['patches'];self.assertEqual(new[:len(old)],old)
    def test_11_no_warning_suppression(self):
        for p in r10.load_lock()['patches']:
            t=(ROOT/p['path']).read_text()
            for token in ('-Wno-', 'diagnostic ignored','__maybe_unused','__attribute__((unused))'):
                self.assertNotIn(token,t)
    def test_12_config_same(self):self.assertEqual(r10.check_config((ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes())['unchanged_values'],4987)
    def test_13_bpf_rules_unchanged(self):
        p='kernel/bpf/cgroup.c';b=self.text('before',p)
        self.assertEqual(b.replace('\tu32 old_flags;\n','').replace('\told_flags = cgrp->bpf.flags[type];\n',''),self.text('after',p))
    def test_14_crypto_validation_retained(self):
        for p in ('crypto/seqiv.c','crypto/echainiv.c'):
            b=self.text('before',p);a=self.text('after',p)
            for call in ('aead_geniv_alloc(', 'IS_ERR(', 'PTR_ERR(', 'aead_register_instance(', 'aead_geniv_free('):self.assertEqual(a.count(call),b.count(call))
            self.assertIn('goto free_inst;',a);self.assertNotIn('struct crypto_aead_spawn *spawn;',a)
    def test_15_cpuset_counter_and_lock(self):
        a=self.text('after','kernel/cgroup/cpuset.c')
        self.assertIn('mutex_lock(&cpuset_mutex);\n\tcss_cs(css)->attach_in_progress--;\n\tmutex_unlock(&cpuset_mutex);',a)
    def test_16_shmem_error_checks(self):
        p='mm/shmem.c';a=self.text('after',p);b=self.text('before',p)
        for call in ('security_inode_init_security(', 'shmem_get_inode(', 'shmem_getpage(', 'iput(', 'put_page('):self.assertEqual(a.count(call),b.count(call))
    def test_17_scheduler_operations(self):
        p='kernel/sched/fair.c';a=self.text('after',p);b=self.text('before',p)
        for call in ('detach_task(', 'attach_one_task(', 'rq_lock_irq(', 'rq_unlock(', 'detach_one_task(', 'trace_sched_find_best_target('):self.assertEqual(a.count(call),b.count(call))
        self.assertNotIn('target_util',a);self.assertNotIn('moved = true;',a)
    def test_18_binder_transport(self):
        a=self.text('after','drivers/android/binder.c')
        self.assertIn('data->owner = BINDER_ST_TYPE;',a);self.assertIn('ret = millet_sendto_user(tsk, data, sk);',a)
        self.assertNotIn('task_node = (struct task_struct *)(data->mod.k_priv.binder.stat.task)',a)
    def test_19_definition_not_prototype(self):
        a=self.text('after',g.FTS);f=g.function(a,'fts_fwupg_check_state')
        self.assertIn('if (ret >= 0 && cstate == rstate)',f);self.assertNotIn('static int fts_fwupg_get_boot_state',f)
        self.assertEqual(f.count('static bool fts_fwupg_check_state'),1)
    def test_20_poll_delay_and_retry(self):
        b=self.text('before',g.FTS);a=self.text('after',g.FTS)
        for name in ('fts_fwupg_check_state','fts_fwupg_check_flash_status'):
            bf=g.function(b,name);af=g.function(a,name)
            for term in ('for (i = 0;', 'msleep(', 'return true;', 'return false;'):self.assertEqual(af.count(term),bf.count(term))
        self.assertIn('#define FTS_UPGRADE_LOOP 30',g.harness(a))
    def test_21_target_warning_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.log';p.write_text("/tmp/candidate/mm/shmem.c:1:2: warning: variable 'info' set but not used [-Wunused-but-set-variable]\n")
            with self.assertRaises(ValueError):g.warning_gate([p])
    def test_22_other_warnings_not_hidden(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.log';line="/tmp/candidate/mm/vmscan.c:1:2: warning: variable 'nid' set but not used [-Wunused-but-set-variable]\n";p.write_text(line)
            self.assertEqual(g.warning_gate([p])['remaining_target_diagnostics'],0);self.assertEqual(p.read_text(),line)
    def test_23_full_build_remains(self):
        self.assertEqual(r10.FULL_TARGETS,('Image.gz',));s=(ROOT/'common/scripts/sweet/stage_r10.py').read_text()
        self.assertIn("if changes:",s);self.assertIn("group2.warning_gate",s);self.assertNotIn('continue-on-error',s)
    def test_24_export_reference(self):
        rows=[l.split() for l in (ROOT/'docs/sweet/r10/reference/R9.Module.symvers').read_text().splitlines()]
        self.assertEqual(len(rows),11742);self.assertEqual({r[1]:r[0] for r in rows}['smp_call_function_single_async'],'0xc6a27775')

if __name__=='__main__':unittest.main()
