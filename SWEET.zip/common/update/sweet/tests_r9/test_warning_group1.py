from pathlib import Path
import hashlib,json,re,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r9 as r9
import stage_r8 as r8
import group1_validation as g

class Group1Tests(unittest.TestCase):
    def text(self,kind,path):return (ROOT/'docs/sweet/r9/reference'/kind/path).read_text()
    def test_parent_tree(self):self.assertEqual(r9.load_lock()['r8_tree'],r8.load_lock()['candidate_tree'])
    def test_no_flash_approval(self):self.assertIs(r9.load_lock()['flashable'],False)
    def test_three_patches(self):self.assertEqual(len(r9.load_lock()['patches']),3)
    def test_patch_hashes(self):
        for p in r9.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/p['path']).read_bytes()).hexdigest(),p['sha256'])
    def test_five_changed_paths(self):self.assertEqual(len(r9.load_lock()['changed_from_r8']),5)
    def test_before_source_hashes(self):
        for p in r9.load_lock()['changed_from_r8']:self.assertEqual(hashlib.sha256(self.text('before',p['path']).encode()).hexdigest(),p['before_sha256'])
    def test_after_source_hashes(self):
        for p in r9.load_lock()['changed_from_r8']:self.assertEqual(hashlib.sha256(self.text('after',p['path']).encode()).hexdigest(),p['after_sha256'])
    def test_combined_unique(self):
        p=[p['path'] for p in r9.combined_lock(r9.load_lock())['changed_files']];self.assertEqual(len(p),len(set(p)))
    def test_no_warning_suppression(self):
        for p in r9.load_lock()['patches']:
            text=(ROOT/p['path']).read_text();self.assertNotIn('-Wno-',text);self.assertNotIn('diagnostic ignored',text)
    def test_same_config(self):
        data=(ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes();self.assertEqual(r9.check_config(data)['unchanged_values'],4987)
    def test_camera_actual_function(self):
        text=self.text('after',g.CAMERA);f=g.function(text,'cam_icp_mgr_process_cmd_desc');self.assertIn(f,g.camera_harness(text));self.assertIn('for (i = cpu_buf_end - 1; i >= 0; i--)',f)
    def test_camera_no_bad_decrement(self):
        f=g.function(self.text('after',g.CAMERA),'cam_icp_mgr_process_cmd_desc');self.assertNotIn('num_cmd_buf--',f);self.assertEqual(f.count('rc = -EINVAL;'),3)
    def test_touch_no_short_circuit_read(self):
        t=self.text('after',g.TOUCH);self.assertEqual(t.count('fuzz_present = touchscreen_get_prop_u32'),3);self.assertEqual(t.count('if (data_present || fuzz_present)'),3)
    def test_aligned_allocations_preserved(self):
        for p in ('include/linux/smp.h','kernel/smp.c'):
            before=self.text('before',p);after=self.text('after',p)
            if p.endswith('.h'):self.assertIn('__aligned(sizeof(struct __call_single_data))',after)
            else:
                self.assertIn('alloc_percpu(call_single_data_t)',after)
                self.assertIn('DEFINE_PER_CPU_SHARED_ALIGNED(call_single_data_t, csd_data)',after)
    def test_up_definition_consistent(self):self.assertIn('int smp_call_function_single_async(int cpu, struct __call_single_data *csd)',self.text('after','kernel/up.c'))
    def test_warning_gate_rejects(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'build.log';p.write_text('x.c:2: warning: sample [-Wunsequenced]\n')
            with self.assertRaises(ValueError):g.warning_gate([p])
    def test_warning_gate_other_category_not_hidden(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'build.log';p.write_text('x.c:2: warning: other [-Wunused-but-set-variable]\n')
            self.assertEqual(g.warning_gate([p])['remaining_target_diagnostics'],0)
            self.assertIn('warning:',p.read_text())
    def test_six_targeted_baseline_diagnostics(self):
        rows=json.loads((ROOT/'docs/sweet/r9/targeted_r8_warnings.json').read_text());self.assertEqual(len(rows),6)
        self.assertEqual(set(x['category'] for x in rows),set(g.TARGET_CATEGORIES))

if __name__=='__main__':unittest.main()
