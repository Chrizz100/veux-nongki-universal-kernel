from pathlib import Path
import json, os, struct, sys, tempfile, unittest
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r7 as r7
import stage_r6 as r6
import audit

class R7Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)
    def elf(self,kind=1,machine=183,klass=2):
        data=bytearray(64);data[:7]=b'\x7fELF'+bytes([klass,1,1]);struct.pack_into('<HH',data,16,kind,machine)
        p=self.path/'test.o';p.write_bytes(data);return p
    def test_lock_extends_exact_r6(self):
        self.assertEqual(r7.load_lock()['r6_tree'],r6.load_lock()['candidate_tree'])
    def test_patch_hashes(self):
        patches=r7.load_lock()['patches'];self.assertEqual(len(patches),2)
        for patch in patches:self.assertEqual(audit.sha256(ROOT/patch['path']),patch['sha256'])
    def test_vdso_patch_changes_three_calls_only(self):
        t=(ROOT/r7.load_lock()['patches'][0]['path']).read_text()
        removed=[l for l in t.splitlines() if l.startswith('-') and not l.startswith('---')]
        added=[l for l in t.splitlines() if l.startswith('+') and not l.startswith('+++')]
        self.assertEqual(removed,['-\tclock_gettime_return, shift=1']*3)
        self.assertEqual(added,['+\tclock_gettime_return shift=1']*3)
    def test_property_patch_changes_both_tables(self):
        t=(ROOT/r7.load_lock()['patches'][1]['path']).read_text()
        self.assertIn('--- a/include/linux/power_supply.h',t)
        self.assertIn('--- a/drivers/power/supply/power_supply_sysfs.c',t)
        removed=[l for l in t.splitlines() if l.startswith('-') and not l.startswith('---')]
        self.assertEqual(removed,['-\tPOWER_SUPPLY_PROP_CHIP_OK,','-\tPOWER_SUPPLY_ATTR(chip_ok),'])
    def test_config_preserved(self):
        self.assertEqual(r7.config_gate('CONFIG_X=y\n','CONFIG_X=y\n')['changed'],0)
    def test_config_changed_rejected(self):
        with self.assertRaises(ValueError):r7.config_gate('CONFIG_X=n\n','CONFIG_X=y\n')
    def test_config_missing_rejected(self):
        with self.assertRaises(ValueError):r7.config_gate('CONFIG_X=y\n','CONFIG_X=y\nCONFIG_Y=y\n')
    def test_config_added_rejected(self):
        with self.assertRaises(ValueError):r7.config_gate('CONFIG_X=y\nCONFIG_Y=y\n','CONFIG_X=y\n')
    def test_elf_object(self):self.assertEqual(r7.elf_check(self.elf(),1)['machine'],'AArch64')
    def test_elf_shared(self):self.assertEqual(r7.elf_check(self.elf(3),3)['type'],3)
    def test_wrong_elf_machine_rejected(self):
        with self.assertRaises(ValueError):r7.elf_check(self.elf(machine=62),1)
    def test_wrong_elf_class_rejected(self):
        with self.assertRaises(ValueError):r7.elf_check(self.elf(klass=1),1)
    def test_wrong_elf_type_rejected(self):
        with self.assertRaises(ValueError):r7.elf_check(self.elf(3),1)
    def test_truncated_elf_rejected(self):
        p=self.path/'bad';p.write_bytes(b'\x7fELF')
        with self.assertRaises(ValueError):r7.elf_check(p,1)
    def test_explicit_ias_override(self):
        tc=dict(cc='clang-14',ld='ld.lld-14',ar='llvm-ar-14',nm='llvm-nm-14',objcopy='llvm-objcopy-14',objdump='llvm-objdump-14',readelf='llvm-readelf-14')
        cmd=r7.make_command(Path('/src'),Path('/out'),tc)
        self.assertIn('CLANG_FLAGS=--target=aarch64-linux-gnu -integrated-as -Werror=unknown-warning-option',cmd)
        self.assertIn('HOSTCFLAGS=-O2 -fcommon',cmd)
    def test_no_disable_failure_switch(self):
        self.assertNotIn('-Wno-error',r7.CLANG_FLAGS)
        self.assertNotIn('-no-integrated-as',r7.CLANG_FLAGS)
        self.assertFalse(r7.load_lock()['full_kernel_build'])
        self.assertFalse(r7.load_lock()['flashable'])
    def test_explicit_vdso_build_target(self):
        self.assertEqual(r7.VDSO_TARGET,'arch/arm64/kernel/vdso/')
    def test_declared_unique_objects(self):
        self.assertEqual(len(r7.OBJECTS),12);self.assertEqual(len(set(r7.OBJECTS)),12)
        self.assertTrue(all(p.endswith('.o') and '..' not in p for p in r7.OBJECTS))
    def test_hardware_and_power_paths_in_gate(self):
        self.assertIn('drivers/input/misc/aw8624_haptic/aw8624.o',r7.OBJECTS)
        self.assertIn('drivers/power/supply/power_supply_sysfs.o',r7.OBJECTS)
        self.assertIn('drivers/input/fingerprint/fs_tee/sf_ctl.o',r7.OBJECTS)
    def test_local_toolchain_forbidden_in_ci(self):
        from unittest.mock import patch
        with patch.dict(os.environ,{'SWEET_LOCAL_TOOLCHAIN':'1','GITHUB_ACTIONS':'true'}):
            with self.assertRaises(ValueError):r7.tools(self.path)
    def test_command_failure_retains_log(self):
        with self.assertRaises(RuntimeError):r7.run([sys.executable,'-c','print("expected failure");raise SystemExit(7)'],self.path/'failure.log')
        self.assertIn('expected failure',(self.path/'failure.log').read_text())

if __name__=='__main__':unittest.main()
