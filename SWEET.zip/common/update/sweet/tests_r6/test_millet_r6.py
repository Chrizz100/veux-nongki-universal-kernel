from pathlib import Path
import hashlib
import json
import os
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r6 as stage
import prepare_candidate_r5 as r5
import audit

class R6Tests(unittest.TestCase):
    def test_pinned_base(self):
        self.assertEqual(stage.load_lock()['base_tree'],'5f23e786f02e80d181217ece9355f5702af23fbe')
    def test_pinned_official_donor(self):
        self.assertEqual(stage.load_lock()['donor_commit'],'de8d0006e5c9c7aeae530438813a019e4df5e21f')
    def test_patch_integrity(self):
        for item in stage.load_lock()['patches']:
            self.assertEqual(r5.digest_file(ROOT/item['path']),item['sha256'])
    def test_uapi_identity(self):
        self.assertEqual(stage.load_lock()['uapi_blob'],'faceabaee8d1f619c1e33737e1d5af678471b206')
    def test_no_flash_approval(self):
        self.assertIs(stage.load_lock()['flashable'],False)
    def test_eleven_changed_paths(self):
        self.assertEqual(len(stage.load_lock()['changed_from_r5']),11)
    def test_only_millet_config_delta(self):
        stock=audit.parse_config((ROOT/'device/sweet/reference/stock.config').read_text())['values']
        before=audit.parse_config((ROOT/'docs/sweet/r5/evidence/r5.resolved.config').read_text())['values']
        after=dict(before,CONFIG_MILLET='y')
        p=stage.check_configs(stock,before,after)
        self.assertEqual(len(p['active_stock_missing']),13)
        self.assertFalse(p['stock_compatibility_passed'])
    def test_selinux_drop_rejected(self):
        stock=audit.parse_config((ROOT/'device/sweet/reference/stock.config').read_text())['values']
        before=dict(stock);before.pop('CONFIG_MILLET');after=dict(stock,CONFIG_SECURITY_SELINUX='n')
        with self.assertRaises(ValueError):stage.check_configs(stock,before,after)
    def make_generated(self,root):
        (root/'original').write_text('unchanged')
        for dest in stage.OEM_LINKS.values():
            p=root/dest;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('OEM stub')
        _,before=r5.tree_identity(root)
        for rel in stage.OEM_EMPTY:
            p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.touch()
        for name,dest in stage.OEM_LINKS.items():
            p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(root/dest)
        return before
    def test_exact_generated_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);b=self.make_generated(root)
            self.assertTrue(stage.generated_state(root,b,r5.tree_identity(root)[1])['passed'])
    def test_nonempty_generated_output(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);b=self.make_generated(root);(root/stage.OEM_EMPTY[0]).write_text('changed')
            with self.assertRaises(ValueError):stage.generated_state(root,b,r5.tree_identity(root)[1])
    def test_unexpected_link(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);b=self.make_generated(root);p=root/'include/linux/rtmm.h';p.unlink();p.symlink_to('/tmp/wrong')
            with self.assertRaises(ValueError):stage.generated_state(root,b,r5.tree_identity(root)[1])
    def test_extra_generated_file(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);b=self.make_generated(root);(root/'extra').write_text('extra')
            with self.assertRaises(ValueError):stage.generated_state(root,b,r5.tree_identity(root)[1])
    def test_tracked_source_changed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);b=self.make_generated(root);(root/'original').write_text('modified')
            with self.assertRaises(ValueError):stage.generated_state(root,b,r5.tree_identity(root)[1])
    def test_wrong_source_refused(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError):stage.apply_delta(Path(d),stage.load_lock())
    def test_two_deltas_have_no_empty_header(self):
        first=(ROOT/stage.load_lock()['patches'][0]['path']).read_text()
        self.assertIn('int millet_sendto_user',first)
        self.assertIn('netlink_kernel_create',first)
        self.assertIn('millet_can_attach',first)
    def test_millet_guards_present_in_delta(self):
        s=(ROOT/stage.load_lock()['patches'][1]['path']).read_text()
        for term in ['!nlmsg_ok(nlh, skb->len)', 'struct millet_data data = {0};',
                     '!atomic_read(&millet_sk.has_init)', 'if (get_user(tmp[0], buf))']:
            self.assertIn(term,s)

if __name__=='__main__': unittest.main()
