from pathlib import Path
import gzip, hashlib, json, re, struct, sys, tempfile, unittest
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r8 as r8
import stage_r7 as r7
import audit

class R8Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)
    def elf(self,text=b'\xc0\x03\x5f\xd6'):
        # Three ELF sections: NULL, section-name table and text.
        names=b'\0.shstrtab\0.text\0';data=bytearray(64+192)
        data[:7]=b'\x7fELF\x02\x01\x01';struct.pack_into('<HH',data,16,1,183)
        struct.pack_into('<Q',data,40,64);struct.pack_into('<HHH',data,58,64,3,1)
        struct.pack_into('<IIQQQQIIQQ',data,128,1,3,0,0,len(data),len(names),0,0,1,0)
        struct.pack_into('<IIQQQQIIQQ',data,192,11,1,6,0,len(data)+len(names),len(text),0,0,4,0)
        data+=names+text;p=self.path/'aes.o';p.write_bytes(data);return p
    def aes(self,constant=None):
        return self.elf(struct.pack('<I',0x9c000008 | (4<<5))+b'\0'*12+(constant or r8.AES_VECTOR))
    def image(self,size=64,flags=0):
        data=bytearray(64);data[56:60]=b'ARM\x64';struct.pack_into('<QQQ',data,8,0x80000,size,flags)
        p=self.path/'Image';p.write_bytes(data);return p
    def test_parent_and_nonflashable(self):
        lock=r8.load_lock();self.assertEqual(lock['r7_tree'],r7.load_lock()['candidate_tree']);self.assertFalse(lock['flashable'])
    def test_all_patch_hashes(self):
        for item in r8.load_lock()['patches']:
            self.assertEqual(audit.sha256(ROOT/item['path']),item['sha256'])
    def test_combined_paths_unique(self):
        lock=r8.combined_lock(r8.load_lock());names=[r['path'] for r in lock['changed_files']]
        self.assertEqual(len(names),len(set(names)));self.assertGreater(len(lock['patches']),8)
    def test_config_is_exact_reference(self):
        data=(ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes()
        self.assertEqual(r8.check_config(data)['unchanged_values'],4987)
    def test_config_mutation_rejected(self):
        data=(ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes()
        with self.assertRaises(ValueError): r8.check_config(data.replace(b'CONFIG_MODVERSIONS=y',b'CONFIG_MODVERSIONS=n'))
    def test_aes_lane_constant(self):
        self.assertEqual(struct.unpack('<4I',r8.AES_VECTOR),(1,2,3,0))
    def test_aes_real_load_target(self):
        self.assertEqual(r8.aes_object_check(self.aes())['literal_load']['pool_offset'],16)
    def test_aes_changed_constant_rejected(self):
        with self.assertRaises(ValueError):r8.aes_object_check(self.aes(b'\x01'*16))
    def test_aes_missing_load_rejected(self):
        with self.assertRaises(ValueError):r8.aes_object_check(self.elf(r8.AES_VECTOR))
    def test_elf_truncation_rejected(self):
        with self.assertRaises(ValueError):r8.elf_section(b'\x7fELF','.text')
    def test_elf_bad_section_offset_rejected(self):
        data=bytearray(self.elf().read_bytes());struct.pack_into('<Q',data,40,2**63)
        with self.assertRaises(ValueError):r8.elf_section(data,'.text')
    def test_elf_missing_section_rejected(self):
        with self.assertRaises(ValueError):r8.elf_section(self.elf().read_bytes(),'.data')
    def test_arm64_image_header(self):
        self.assertEqual(r8.image_check(self.image())['machine'],'AArch64')
    def test_short_declared_image_rejected(self):
        with self.assertRaises(ValueError):r8.image_check(self.image(size=32))
    def test_big_endian_image_rejected(self):
        with self.assertRaises(ValueError):r8.image_check(self.image(flags=1))
    def test_gzip_roundtrip(self):
        p=self.image();g=self.path/'Image.gz';g.write_bytes(gzip.compress(p.read_bytes()));r8.validate_gzip(g,p)
    def test_gzip_mismatch_rejected(self):
        p=self.image();g=self.path/'Image.gz';g.write_bytes(gzip.compress(b'x'*64))
        with self.assertRaises(ValueError):r8.validate_gzip(g,p)
    def test_user_stock_firmware_patch_bytes(self):
        p=next(x for x in r8.load_lock()['patches'] if 'stock-focaltech' in x['path'])
        data=bytes(int(x,16) for x in re.findall(r'0x([0-9a-f]{2}),',(ROOT/p['path']).read_text()))
        self.assertEqual(len(data),r8.FIRMWARE_SIZE);self.assertEqual(hashlib.sha256(data).hexdigest(),r8.FIRMWARE_SHA256)
    def test_no_disabling_to_obtain_green(self):
        source=(ROOT/'common/scripts/sweet/stage_r8.py').read_text()
        self.assertNotIn('continue-on-error',source);self.assertNotIn('-Wno-error',source)
        self.assertEqual(r8.FULL_TARGETS,('Image.gz',))
        self.assertIn("report['full_kernel_build_executed']=True",source)
    def test_expected_firmware_origin(self):
        fw=r8.load_lock()['firmware']
        self.assertEqual(fw['boot_sha256'],'4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015')
        self.assertTrue(fw['firmware_arrays_identical']);self.assertEqual(len(fw['regions']),3)
        self.assertFalse(fw['runtime_device_test'])

    def test_symvers_requires_real_crc(self):
        p=self.path/'Module.symvers';p.write_text('0x477d71bc\tgsi_write_channel_scratch\tvmlinux\tEXPORT_SYMBOL\n')
        self.assertEqual(r8.symvers_check(p)['exports'],1)
    def test_symvers_missing_crc_rejected(self):
        p=self.path/'Module.symvers';p.write_text('0x00000000\tgsi_write_channel_scratch\tvmlinux\n')
        with self.assertRaises(ValueError):r8.symvers_check(p)
    def test_symvers_duplicate_rejected(self):
        p=self.path/'Module.symvers';p.write_text('0x477d71bc\tgsi_write_channel_scratch\tvmlinux\n'*2)
        with self.assertRaises(ValueError):r8.symvers_check(p)

if __name__=='__main__':unittest.main()
