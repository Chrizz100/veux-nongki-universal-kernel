from pathlib import Path
import hashlib,json,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r13 as r13,stage_r12 as b,stage_r12a as a,stock_power_audit as pd
class ConsolidationTests(unittest.TestCase):
 def test_01_b_parent(self):self.assertEqual(r13.load_lock()['r12b_tree'],b.load_lock()['candidate_tree'])
 def test_02_a_parent(self):self.assertEqual(r13.load_lock()['r12a_tree'],a.load_lock()['candidate_tree'])
 def test_03_union_files(self):self.assertEqual(len(r13.load_lock()['consolidated_file_sha256']),13)
 def test_04_target_union(self):
  expected={(x['path'],x['variable']) for x in a.load_lock()['targeted_variables']+b.load_lock()['targeted_variables']}
  actual={(x['path'],x['variable']) for x in r13.load_lock()['targeted_variables']}
  self.assertEqual(expected,actual);self.assertEqual(len(actual),17)
 def test_05_eight_restored_files(self):self.assertEqual(len(r13.load_lock()['changed_from_r12b']),8)
 def test_06_patch_integrity(self):
  for x in r13.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest(),x['sha256'])
 def test_07_b_fixes_all_retained(self):
  for x in b.load_lock()['changed_from_r11']:self.assertEqual(r13.load_lock()['consolidated_file_sha256'][x['path']],x['after_sha256'])
 def test_08_a_fixes_retained_except_reviewed_rng(self):
  for x in a.load_lock()['changed_from_r11']:
   if x['path']!='drivers/char/hw_random/msm_rng.c':self.assertEqual(r13.load_lock()['consolidated_file_sha256'][x['path']],x['after_sha256'])
 def test_09_rng_difference_is_extra_reset(self):
  p='drivers/char/hw_random/msm_rng.c';x=(ROOT/'docs/sweet/r12a/reference/after'/p).read_text();y=(ROOT/'docs/sweet/r12/reference/after'/p).read_text()
  self.assertEqual(x.replace('if (msm_rng_dev->qrng_perf_client)\n\t\tmsm_bus_scale_unregister_client(msm_rng_dev->qrng_perf_client);','if (msm_rng_dev->qrng_perf_client) {\n\t\tmsm_bus_scale_unregister_client(msm_rng_dev->qrng_perf_client);\n\t\tmsm_rng_dev->qrng_perf_client = 0;\n\t}',1),y)
 def test_10_entire_b_series_prefix(self):
  old=b.combined_lock(b.load_lock())['patches'];new=r13.combined_lock(r13.load_lock())['patches'];self.assertEqual(new[:-1],old)
 def test_11_all_restored_bytes(self):
  for x in r13.load_lock()['changed_from_r12b']:self.assertEqual(hashlib.sha256((ROOT/'docs/sweet/r12a/reference/after'/x['path']).read_bytes()).hexdigest(),x['after_sha256'])
 def test_12_file_guard_rejects_loss(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);lock=r13.load_lock()
   for n in lock['expected_file_union']:
    source=ROOT/('docs/sweet/r12/reference/after' if n in {x['path'] for x in b.load_lock()['changed_from_r11']} else 'docs/sweet/r12a/reference/after')/n
    dst=p/n;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(source.read_bytes())
   self.assertEqual(r13.verify_consolidation(p,lock)['verified_files'],13)
   (p/'mm/vmscan.c').write_text('lost previous patch')
   with self.assertRaises(ValueError):r13.verify_consolidation(p,lock)
 def test_13_source_paths_no_collision(self):
  xs=r13.combined_lock(r13.load_lock())['changed_files'];self.assertEqual(len(xs),len({x['path'] for x in xs}))
 def test_14_no_charge_or_dt_changes(self):
  paths=[x['path'] for x in r13.load_lock()['changed_from_r12b']]
  self.assertFalse(any('/power/' in p or '/dts/' in p for p in paths))
 def test_15_original_fixture_hash(self):
  j=json.loads((pd.REF/'stock_receipt.json').read_text());self.assertEqual(hashlib.sha256((pd.REF/'stock_sweet_overlay.dtb').read_bytes()).hexdigest(),j['overlay_sha256'])
 def test_16_bad_fdt_rejected(self):
  data=(pd.REF/'stock_sweet_overlay.dtb').read_bytes()
  for bad in (b'',data[:-8],b'BAD!'+data[4:]):
   with self.assertRaises(ValueError):pd.fdt_nodes(bad)
 def test_17_stock_current_values(self):
  p=pd.profile_from_overlay((pd.REF/'stock_sweet_overlay.dtb').read_bytes());self.assertEqual((p['mi,pd-bat-curr-max'],p['mi,pd-bus-curr-max']),(6000,3000));self.assertFalse(p['mi,cp-sec-enable'])
 def test_18_oem_not_equal_stock(self):
  p=pd.profile_from_dts((pd.REF/'k6a-sweet-sdmmagpie.dtsi').read_text());self.assertEqual((p['mi,pd-bat-curr-max'],p['mi,pd-bus-curr-max']),(12000,6100));self.assertTrue(p['mi,cp-sec-enable'])
 def test_19_stage_retains_all_gates(self):
  s=(ROOT/'common/scripts/sweet/stage_r13.py').read_text()
  for x in ('verify_consolidation(candidate,lock)','group5.run_behavior','group5.warning_gate','stock_power_audit.run','if changes:',"'Image.gz'"):self.assertIn(x,s)
  self.assertIs(r13.load_lock()['flashable'],False)
 def test_20_unique_version_and_parents(self):
  j=json.loads((ROOT/'PAKET.json').read_text());self.assertEqual(j['version'],'R13-Mobil-1');self.assertEqual(len({p['sha256'] for p in r13.load_lock()['parents']}),2)
if __name__=='__main__':unittest.main()
