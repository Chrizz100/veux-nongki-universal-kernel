from pathlib import Path
import hashlib,json,re,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r11 as r11, stage_r10 as r10,group3_validation as g
class R11Tests(unittest.TestCase):
 def text(self,kind,path):return (ROOT/'docs/sweet/r11/reference'/kind/path).read_text()
 def test_01_parent(self):self.assertEqual(r11.load_lock()['r10_tree'],r10.load_lock()['candidate_tree'])
 def test_02_no_flash(self):self.assertIs(r11.load_lock()['flashable'],False)
 def test_03_two_patches(self):self.assertEqual(len(r11.load_lock()['patches']),2)
 def test_04_nine_paths(self):self.assertEqual(len(r11.load_lock()['changed_from_r10']),9)
 def test_05_twelve_warning_sites(self):self.assertEqual(len(r11.load_lock()['targeted_variables']),12)
 def test_06_patch_integrity(self):
  for p in r11.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/p['path']).read_bytes()).hexdigest(),p['sha256'])
 def test_07_before_integrity(self):
  for p in r11.load_lock()['changed_from_r10']:self.assertEqual(hashlib.sha256(self.text('before',p['path']).encode()).hexdigest(),p['before_sha256'])
 def test_08_after_integrity(self):
  for p in r11.load_lock()['changed_from_r10']:self.assertEqual(hashlib.sha256(self.text('after',p['path']).encode()).hexdigest(),p['after_sha256'])
 def test_09_combined_no_duplicate_paths(self):
  paths=[p['path'] for p in r11.combined_lock(r11.load_lock())['changed_files']];self.assertEqual(len(paths),len(set(paths)))
 def test_10_parent_patches_unchanged(self):
  parent=r10.combined_lock(r10.load_lock())['patches'];self.assertEqual(r11.combined_lock(r11.load_lock())['patches'][:len(parent)],parent)
 def test_11_no_suppression(self):
  for p in r11.load_lock()['patches']:
   s=(ROOT/p['path']).read_text()
   for tok in ['-Wno-','diagnostic ignored','__maybe_unused','__attribute__((unused))']:self.assertNotIn(tok,s)
 def test_12_config_preserved(self):self.assertEqual(r11.check_config((ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes())['unchanged_values'],4987)
 def test_13_xlog_copy_calls_preserved(self):
  b=self.text('before',g.XLOG);a=self.text('after',g.XLOG)
  for op in ['copy_from_user(','copy_to_user(']:self.assertEqual(a.count(op),b.count(op))
 def test_14_write_checks_every_copy(self):
  s=g.function(self.text('after',g.XLOG),'xlogchar_write');self.assertEqual(s.count('if (copy_from_user('),3);self.assertEqual(s.count('goto copy_fault;'),3)
 def test_15_read_checks_every_copy(self):
  s=g.function(self.text('after',g.XLOG),'xlogchar_read');self.assertEqual(s.count('if (copy_to_user('),3);self.assertEqual(s.count('goto copy_fault;'),3)
 def test_16_interrupt_has_no_double_unlock(self):
  s=g.function(self.text('after',g.XLOG),'xlogchar_read');part=s.split('if (err) {')[1].split('}',1)[0];self.assertNotIn('mutex_unlock',part);self.assertIn('return err;',part)
 def test_17_copy_fault_preserves_metadata(self):
  for f in ['xlogchar_read','xlogchar_write']:
   s=g.function(self.text('after',g.XLOG),f).split('copy_fault:')[1]
   for name in ['readindex','writeindex','free_size','wake_up']:self.assertNotIn(name,s)
   self.assertIn('return -EFAULT;',s)
 def test_18_boost_checks_registration(self):
  s=g.function(self.text('after',g.BOOST),'cpu_boost_init');self.assertIn('if (ret)\n\t\tgoto destroy_wq;',s);self.assertIn('if (ret)\n\t\tgoto unregister_notifier;',s)
 def test_19_boost_cleanup_sequence(self):
  s=g.function(self.text('after',g.BOOST),'cpu_boost_init');self.assertLess(s.index('cpufreq_unregister_notifier'),s.index('destroy_workqueue'));self.assertIn('cpu_boost_wq = NULL;',s)
 def test_20_hwmon_width_and_boundary(self):
  s=g.function(self.text('after',g.HW),'hw_mon_store');self.assertIn('"%31s %d"',s);self.assertIn('len != 2',s);self.assertIn('!isspace(name[strlen(component_name)])',s)
 def test_21_selinux_operations_preserved(self):
  p='security/selinux/ss/services.c';b=self.text('before',p);a=self.text('after',p)
  for op in ['read_lock(','read_unlock(','context_struct_to_sid(','__security_genfs_sid(']:self.assertEqual(a.count(op),b.count(op))
 def test_22_no_io_or_unmap_calls_removed(self):
  for p,ops in {'block/blk-core.c':['blk_queue_enter(','blk_queue_exit(','bio_io_error('],'net/ipv4/inet_hashtables.c':['spin_lock_bh(','spin_unlock_bh(','reuseport_detach_sock('],'drivers/char/adsprpc.c':['hyp_assign_phys(','dma_buf_unmap_attachment(','dma_buf_detach(','dma_buf_put('],'drivers/char/hw_random/msm_rng.c':['readl_relaxed(','clk_prepare_enable(','mutex_unlock(']}.items():
   for op in ops:self.assertEqual(self.text('after',p).count(op),self.text('before',p).count(op))
 def test_23_target_warning_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'w.log';p.write_text("/tmp/candidate/drivers/char/xlogchar.c:87:6: warning: variable 'err' set but not used [-Wunused-but-set-variable]\n")
   with self.assertRaises(ValueError):g.warning_gate([p])
 def test_24_other_warning_not_hidden(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'w.log';s="/tmp/candidate/drivers/char/hw_random/msm_rng.c:262:6: warning: variable 'ret' set but not used [-Wunused-but-set-variable]\n";p.write_text(s);self.assertEqual(g.warning_gate([p])['remaining_target_diagnostics'],0);self.assertEqual(p.read_text(),s)
 def test_25_composite_selinux_target(self):
  s=(ROOT/'common/scripts/sweet/stage_r11.py').read_text();self.assertIn("'KBUILD_BUILTIN=1'",s);self.assertIn("'security/selinux/'",s)
 def test_26_full_build_and_all_gates(self):
  self.assertEqual(r11.FULL_TARGETS,('Image.gz',));s=(ROOT/'common/scripts/sweet/stage_r11.py').read_text()
  for op in ['group1.warning_gate','group2.warning_gate','group3.warning_gate','group3.run_behavior','if changes:']:self.assertIn(op,s)
 def test_27_export_reference(self):
  p=ROOT/'docs/sweet/r11/reference/R10.Module.symvers';r={l.split()[1]:l.split()[0] for l in p.read_text().splitlines()};self.assertEqual(len(r),11742);self.assertEqual(r['smp_call_function_single_async'],'0xc6a27775')
 def test_28_c_harnesses_use_actual_functions(self):
  for p,f,h in [(g.XLOG,'xlogchar_read',g.xlog_harness),(g.BOOST,'cpu_boost_init',g.boost_harness),(g.HW,'hw_mon_store',g.hw_harness)]:
   s=self.text('after',p);self.assertIn(g.function(s,f),h(s))
if __name__=='__main__':unittest.main()
