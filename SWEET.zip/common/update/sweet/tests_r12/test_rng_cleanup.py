from pathlib import Path
import hashlib,json,re,sys,tempfile,unittest
ROOT=Path(__file__).resolve().parents[4];sys.path.insert(0,str(ROOT/'common/scripts/sweet'))
import stage_r12 as r12,stage_r11 as r11,group4_validation as g
class R12Tests(unittest.TestCase):
 def text(self,kind,path):return (ROOT/'docs/sweet/r12/reference'/kind/path).read_text()
 def fn(self,kind,path,name):return g.function(self.text(kind,path),name)
 def test_01_parent(self):self.assertEqual(r12.load_lock()['r11_tree'],r11.load_lock()['candidate_tree'])
 def test_02_no_flash(self):self.assertIs(r12.load_lock()['flashable'],False)
 def test_03_two_patches(self):self.assertEqual(len(r12.load_lock()['patches']),2)
 def test_04_five_source_files(self):self.assertEqual(len(r12.load_lock()['changed_from_r11']),5)
 def test_05_seven_sites(self):self.assertEqual(len(r12.load_lock()['targeted_variables']),7)
 def test_06_hashes_before(self):
  for x in r12.load_lock()['changed_from_r11']:self.assertEqual(hashlib.sha256(self.text('before',x['path']).encode()).hexdigest(),x['before_sha256'])
 def test_07_hashes_after(self):
  for x in r12.load_lock()['changed_from_r11']:self.assertEqual(hashlib.sha256(self.text('after',x['path']).encode()).hexdigest(),x['after_sha256'])
 def test_08_patch_hashes(self):
  for x in r12.load_lock()['patches']:self.assertEqual(hashlib.sha256((ROOT/x['path']).read_bytes()).hexdigest(),x['sha256'])
 def test_09_parent_patches_unchanged(self):
  old=r11.combined_lock(r11.load_lock())['patches'];new=r12.combined_lock(r12.load_lock())['patches'];self.assertEqual(new[:len(old)],old)
 def test_10_combined_paths_unique(self):
  p=[x['path'] for x in r12.combined_lock(r12.load_lock())['changed_files']];self.assertEqual(len(p),len(set(p)))
 def test_11_no_suppressions(self):
  for x in r12.load_lock()['patches']:
   text=(ROOT/x['path']).read_text()
   for token in ['-Wno-','diagnostic ignored','__maybe_unused','__attribute__((unused))']:self.assertNotIn(token,text)
 def test_12_chrdev_error_checked(self):
  s=self.fn('after',g.RNG,'msm_rng_probe');self.assertIn('if (error < 0)\n\t\tgoto unregister_hwrng;',s)
 def test_13_class_failure_cleanup(self):
  s=self.fn('after',g.RNG,'msm_rng_probe');self.assertNotIn('return PTR_ERR(msm_rng_class)',s);self.assertIn('error = PTR_ERR(msm_rng_class);',s)
 def test_14_ordered_rollback(self):
  s=self.fn('after',g.RNG,'msm_rng_probe');pos=[s.index(x) for x in ['class_destroy(msm_rng_class)','unregister_chrdev(QRNG_IOC_MAGIC','hwrng_unregister(&msm_rng)','msm_bus_scale_unregister_client','clk_put(','iounmap(','kzfree(']];self.assertEqual(pos,sorted(pos))
 def test_15_clear_dangling_references(self):
  s=self.fn('after',g.RNG,'msm_rng_probe')
  for x in ['msm_rng.priv = 0;','msm_rng_device_info.qrng_perf_client = 0;','platform_set_drvdata(pdev, NULL);']:self.assertIn(x,s)
 def test_16_hardware_logic_unchanged(self):
  for fn in ['msm_rng_enable_hw','msm_rng_direct_read','msm_rng_remove','qrng_get_random','msm_rng_init','msm_rng_exit']:self.assertEqual(self.fn('before',g.RNG,fn),self.fn('after',g.RNG,fn))
 def test_17_non_rng_function_calls_preserved(self):
  call=lambda s:re.findall(r'\b([A-Za-z_]\w*)\s*\(',s)
  for x in r12.load_lock()['targeted_variables']:
   if x['path']==g.RNG:continue
   name=x['variable'].split('@')[1];self.assertEqual(call(self.fn('before',x['path'],name)),call(self.fn('after',x['path'],name)))
 def test_18_harness_uses_real_function(self):
  s=self.text('after',g.RNG);self.assertIn(g.function(s,'msm_rng_probe'),g.rng_harness(s))
 def test_19_target_warning_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.log';p.write_text("/tmp/drivers/char/hw_random/msm_rng.c:260:6: warning: variable 'ret' set but not used [-Wunused-but-set-variable]\n")
   with self.assertRaises(ValueError):g.warning_gate([p])
 def test_20_other_warning_visible(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'a.log';s="/tmp/drivers/other.c:1:1: warning: variable 'ret' set but not used [-Wunused-but-set-variable]\n";p.write_text(s);self.assertEqual(g.warning_gate([p])['remaining_target_diagnostics'],0);self.assertEqual(p.read_text(),s)
 def test_21_config_and_exports(self):
  self.assertEqual(r12.check_config((ROOT/'docs/sweet/r6/evidence/r6_config_1.config').read_bytes())['unchanged_values'],4987)
  self.assertEqual((ROOT/'docs/sweet/r12/reference/R11.Module.symvers').read_bytes(),(ROOT/'docs/sweet/r11/reference/R10.Module.symvers').read_bytes())
 def test_22_full_build_inherited_guards(self):
  s=(ROOT/'common/scripts/sweet/stage_r12.py').read_text();self.assertEqual(r12.FULL_TARGETS,('Image.gz',))
  for x in ['group1.warning_gate','group2.warning_gate','group3.warning_gate','group4.warning_gate','group4.run_behavior','if changes:']:self.assertIn(x,s)
  self.assertNotIn("command+[jobs,'drivers/gpu/drm/msm/dp/dp_power.o']",s)
if __name__=='__main__':unittest.main()
