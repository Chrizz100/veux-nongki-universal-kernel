# SWEET: isolierte Prüfung

Tests: `python3 -m unittest discover -s common/update/sweet/tests -p 'test_*.py' -v`
Programm: `common/scripts/sweet/audit.py`
Quell-Pins: `lineages/sweet/source_lock.json`
Stock-Referenz: `device/sweet/reference/stock.config`

Bestehende VEUX-Updater, `common/update/source-recipes.json`, Flottenverträge
und `common/upstream/` werden von diesem Paket nicht geändert oder importiert.
