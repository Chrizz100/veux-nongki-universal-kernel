#!/usr/bin/env python3
"""SWEET package entrypoint, runner ABI 1. Current stage: R5 package validation.

No OEM re-download, no kernel compilation, no repository writes and no flashing.
Later reviewed packages may replace this entrypoint without changing the starter.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
import unittest

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or output.is_relative_to(ROOT):
        raise ValueError('Ausgabe muss ausserhalb des entpackten Pakets liegen.')
    output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / 'PAKET.json').read_text())
    status = {'package_version': manifest['version'], 'package_check_passed': False,
              'test_runs': [], 'kernel_built': False, 'device_tested': False,
              'flashable': False, 'new_oem_kconfig_run': False,
              'purpose': 'Mobile Verpackung des vorhandenen R5-Stands; kein neuer Kernelstand.'}
    exit_code = 1
    try:
        if os.environ.get('SWEET_RUNNER_ABI') != '1':
            raise ValueError('Bitte mit dem SWEET-Starter ABI 1 ausfuehren.')
        for name, expected in manifest['files'].items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError(f'Paketdatei stimmt nicht: {name}')
        for directory, count, label in (
                ('common/update/sweet/tests', 72, 'R4.2'),
                ('common/update/sweet/tests_r5', 9, 'R5')):
            logfile = output / f'Tests_{label}.txt'
            with logfile.open('w', encoding='utf-8') as stream:
                with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                    suite = unittest.TestLoader().discover(str(ROOT / directory), pattern='test_*.py')
                    found = suite.countTestCases()
                    if found != count:
                        raise ValueError(f'{label}: {found} statt {count} Tests gefunden.')
                    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
            row = {'suite': label, 'found': found, 'executed': result.testsRun,
                   'passed': result.wasSuccessful() and not result.skipped,
                   'failures': len(result.failures), 'errors': len(result.errors),
                   'skipped': len(result.skipped)}
            status['test_runs'].append(row)
            if not row['passed']:
                raise RuntimeError(f'{label}: Tests nicht bestanden; siehe {logfile.name}.')
            print(f'{label}: {result.testsRun} Tests bestanden.', flush=True)
        for name, expected in manifest['files'].items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError(f'Paketdatei waehrend Tests veraendert: {name}')
        status['package_check_passed'] = True
        exit_code = 0
    except Exception as exc:
        status['error'] = str(exc)
        (output / 'FEHLER.txt').write_text(traceback.format_exc(), encoding='utf-8')
        print(f'SWEET: {exc}', file=sys.stderr)
    finally:
        summary = ('# SWEET\n\n'
                   f"Paketpruefung: {'BESTANDEN' if status['package_check_passed'] else 'FEHLGESCHLAGEN'}\n\n"
                   'Stand: R5-Quellkandidat, jetzt als eine ZIP-Datei verpackt.\n\n'
                   '**Kein neuer Kernelbuild, kein AK3 und keine neue boot.img.**\n\n'
                   'MILLET-, MIUI-, UFS-, Versions-, Compile- und Geraetepruefungen bleiben offen.\n\n'
                   'Die historischen Belege im Paket sind keine Ergebnisse dieses Laufs.\n')
        (output / 'ERGEBNIS.md').write_text(summary, encoding='utf-8')
        (output / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
        if os.environ.get('GITHUB_STEP_SUMMARY'):
            with Path(os.environ['GITHUB_STEP_SUMMARY']).open('a', encoding='utf-8') as stream:
                stream.write(summary)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
