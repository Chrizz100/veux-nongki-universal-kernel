SWEET R5 – SEPARATER QUELLKANDIDAT, NICHT FLASHBAR

Dieses Paket enthält vier überprüfte Quellpatches, einen lokalen Quellen-Assembler,
neun Selbsttests und vollständige Prüfbelege. Es enthält KEIN AK3, keine neue
boot.img und KEINE neue Workflow-YAML. Bestehendes R4.2 bleibt unverändert.
Zum Aufbewahren genügt dieses ZIP; aktuell kein weiterer GitHub-Lauf erforderlich.

Nach Entpacken (Python 3.10+, git):
python3 -m unittest discover -s common/update/sweet/tests_r5 -p 'test_*.py' -v

Optionale lokale Quellvorbereitung:
python3 common/scripts/sweet/prepare_candidate_r5.py --source /pfad/zum/unveraenderten/sweet_k6a-r-oss --output /pfad/zu/NEUEM/kandidaten

Der Assembler prüft den gesamten Original-Git-Tree, kopiert in ein neues Verzeichnis
und wendet die vier integritätsgeprüften Patches an. Er verwendet weder Netzwerk,
make, Flash-Befehle noch Remote-Schreiboperationen. Er braucht ca. 1 GB zusätzlichen
Speicher. Ein falscher oder bereits veränderter OEM-Quellbaum wird abgewiesen.

Alle Dateien liegen in getrennten SWEET-Pfaden. Trotzdem dieses Paket jetzt nicht
als Ersatz für den vorhandenen Referenzaudit verstehen: eine eigene Anbindung
an den späteren Baseline-Build ist noch erforderlich.

Verbindlicher Status: docs/sweet/r5/PRUEFBERICHT_R5.txt
Quell-Lizenz: docs/sweet/r5/COPYING-Linux-GPL-2.0.txt; Herkunft in r5.json und Patches.
Grenzwerttests unter evidence/ enthalten extrahierte C-Funktionen mit simulierten
Kernel-API-Aufrufen. Sie sind keine Gerätetests. Originaltests sind teils bewusst
fehlgeschlagen, um den Fehler nachzuweisen.
