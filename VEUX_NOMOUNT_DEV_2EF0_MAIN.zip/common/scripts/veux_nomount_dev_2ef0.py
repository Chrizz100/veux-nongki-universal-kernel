#!/usr/bin/env python3
"""Exact-source isolated NoMount dev port for the VEUX R5S2/35234 pipeline.

This does not change a checked-out repository; it stages only two verified
NoMount kernel source files inside an ephemeral Linux 5.4.274 build tree.
It does not change VINTF declarations, attested Keymaster versions, or TEE.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path

REPO='https://github.com/maxsteeel/nomount.git'
BASE='7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3'
DEV='2ef0b153d85cfa67408b520f8c66e1c5952de594'
BASE_IMAGE='df92b8b21f3cc3f5b76a0456b0c565a1aa7ad84a995e3eab27a078015d2d16ea'
BLOB={
 'nomount.c':('e698b2a93fbd77b5f390613e22237c4c8454c3de','dde345b618cade72c988308c98f8da3553862e82'),
 'nomount.h':('95deecac12db6b6680df3c8db54b0bb3dbbfbc08','560256c8f4fcffb9569629797efbf24d5b0bbc0c'),
}
MAKEFILE_BLOB='35710cda171161578e498e809d89be9a673ea2d3'
KCONFIG_BLOB='638b9427ef638f786d288d0a93f731676cf32c62'
STAGE='        nomount_r2_source = stage_stack_protection(src, bundle / "nomount", work)\n'
OVERLAY='        overlay_hash = r.save_overlay(src, before, args.overlays / label, label, targets)\n'
POST='        nomount_r2_compiled = verify_compiled_stack(work, nomount_r2_source, result)\n'

class PortBlocked(RuntimeError): pass

def need(ok, reason):
    if not ok: raise PortBlocked(reason)

def digest(b): return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()

def run_git(root,*args):
    p=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,timeout=120)
    need(p.returncode==0,'GIT_'+str(args[:2])+':'+p.stderr[-230:]);return p.stdout.strip()

def donor_check(donor:Path,*,base=BASE,dev=DEV,count=23,blobs=BLOB):
    donor=donor.resolve(strict=True)
    need((donor/'.git').is_dir() and not (donor/'.git/shallow').exists(), 'DEV_GIT_FULL_HISTORY_REQUIRED')
    need(run_git(donor,'rev-parse','HEAD')==dev,'DEV_HEAD_DRIFT')
    need(run_git(donor,'remote','get-url','origin').rstrip('/') in
         (REPO,REPO[:-4]),'DEV_NONOFFICIAL_ORIGIN')
    need(run_git(donor,'status','--porcelain','--untracked-files=all')=='','DEV_DIRTY_DONOR')
    run_git(donor,'merge-base','--is-ancestor',base,dev)
    need(int(run_git(donor,'rev-list','--count',base+'..'+dev))==count,'DEV_COMMIT_DISTANCE_DRIFT')
    for name,(_,expected) in blobs.items():
        path=donor/'kernel/src'/name
        need(path.is_file() and not path.is_symlink(),'DEV_DONOR_FILE_MISSING_'+name)
        need(gitblob(path.read_bytes())==expected,'DEV_GIT_BLOB_DRIFT_'+name)
    for f,sha in [('Makefile',MAKEFILE_BLOB),('Kconfig',KCONFIG_BLOB)]:
        need(gitblob((donor/'kernel/src'/f).read_bytes())==sha, 'DEV_NONPORT_FILE_CHANGED_'+f)
    return {'upstream_dev':dev,'stable_base':base,'ahead_by':count,'official_origin':REPO,
            'kernel_source_files':['fs/nomount/'+x for x in blobs],
            'userland_module_updated':False,'vintf_attestation_changed':False}

def _stage(src:Path,work:Path,donor:Path,*,blobs=BLOB,review_donor=True):
    src=src.resolve(strict=True);work=work.resolve(strict=True);donor=donor.resolve(strict=True)
    need(src.name=='kernel' and work.name=='5.4.274' and work.parent.name=='builds' and
         src.is_relative_to(work),'DISPOSABLE_KERNEL_WORK_ROOT_REQUIRED')
    if review_donor: donor_check(donor)
    root=work.parent.parent
    need(not (root/'report/NOMOUNT_DEV_2EF0_STAGE.json').exists(), 'DEV_ALREADY_STAGED')
    mk=src/'Makefile'
    need(mk.is_file() and not mk.is_symlink(), 'KERNEL_MAKEFILE_MISSING')
    k=mk.read_text()
    need(re.search(r'(?m)^VERSION\s*=\s*5$',k) and re.search(r'(?m)^PATCHLEVEL\s*=\s*4$',k)
         and re.search(r'(?m)^SUBLEVEL\s*=\s*274$',k),'WRONG_KERNEL_BASE')
    nm=src/'fs/nomount'
    need(nm.is_dir() and not nm.is_symlink(), 'NOMOUNT_KERNEL_SOURCE_MISSING')
    # The inherited R2 stack gate MUST have removed the opt-out first.
    makefile=(nm/'Makefile').read_bytes()
    need(b'-fno-stack-protector' not in makefile and b'-O3' in makefile,
         'NOMOUNT_R2_STACK_HARDENING_NOT_APPLIED_FIRST')
    need(gitblob((nm/'Kconfig').read_bytes())==KCONFIG_BLOB, 'NOMOUNT_KCONFIG_DRIFT')
    pairs=[]
    for name,(old,new) in blobs.items():
        path=nm/name; ref=donor/'kernel/src'/name
        need(path.is_file() and not path.is_symlink(),'TARGET_NOT_REGULAR_'+name)
        b=path.read_bytes();n=ref.read_bytes()
        need(gitblob(b)==old,'STABLE_NOMOUNT_PREIMAGE_DRIFT_'+name)
        need(gitblob(n)==new,'DEV_NOMOUNT_SOURCE_DRIFT_'+name)
        need(old!=new,'DEV_SOURCE_NOT_NEW_'+name)
        pairs.append((path,b,n,name))
    # All validation completes before *either* file is replaced; no partial mix.
    for path,_,n,_ in pairs:path.write_bytes(n)
    for path,_,n,name in pairs:
        need(path.read_bytes()==n,'DEV_SOURCE_WRITE_FAIL_'+name)
    proof={'status':'NOMOUNT_DEV_2EF0_SOURCE_STAGED','dev_commit':DEV,'base_commit':BASE,
           'kernel':'5.4.274','modified_kernel_files':[], 'source_hash_pins':True,
           'vintf_fixed':False,'module_userspace_version':'UNCHANGED',
           'build_complete':False,'device_test':False,'flash_approved':False}
    for _,o,n,name in pairs:
        proof['modified_kernel_files'].append({'path':'fs/nomount/'+name,
            'stable_git_blob':gitblob(o),'dev_git_blob':gitblob(n),
            'stable_sha256':digest(o),'dev_sha256':digest(n)})
    out=root/'report/NOMOUNT_DEV_2EF0_STAGE.json';out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
    print('NOMOUNT_DEV_2EF0_5_4_SOURCE_STAGED=PASS; NO_VINTF_FIX_CLAIM',flush=True)
    return proof

def stage_dev(src,work,donor):return _stage(Path(src),Path(work),Path(donor))

def verify_dev(src,work,proof,result):
    src=Path(src).resolve(strict=True); work=Path(work).resolve(strict=True)
    need(proof.get('status')=='NOMOUNT_DEV_2EF0_SOURCE_STAGED' and
         len(proof['modified_kernel_files'])==2,'DEV_STAGE_PROOF_MISSING')
    need(result.get('compile') is True and result.get('image_sha256')!=BASE_IMAGE,
         'DEV_NO_NEW_KERNEL_IMAGE')
    for row in proof['modified_kernel_files']:
        f=src/row['path']
        need(gitblob(f.read_bytes())==row['dev_git_blob'] and
             digest(f.read_bytes())==row['dev_sha256'],'DEV_PREIMAGE_MODIFIED_AFTER_STAGE')
    build=work/'build'
    obj=build/'fs/nomount/nomount.o';cmd=build/'fs/nomount/.nomount.o.cmd'
    need(obj.is_file() and obj.stat().st_size>64,'DEV_OBJECT_NOT_COMPILED')
    need(cmd.is_file() and '-fstack-protector-strong' in cmd.read_text(errors='replace'),
         'DEV_STACK_PROTECTOR_NOT_IN_COMPILE')
    img=build/'arch/arm64/boot/Image'
    need(img.is_file() and digest(img.read_bytes())==result['image_sha256'],
         'DEV_IMAGE_HASH_MISMATCH')
    report={'status':'NOMOUNT_DEV_2EF0_KERNEL_COMPILED_NOT_DEVICE_TESTED',
            'dev_commit':DEV,'stable_pin':BASE,'kernel':'5.4.274',
            'compiled_image_sha256':digest(img.read_bytes()),
            'compiled_object_sha256':digest(obj.read_bytes()),
            'source_verified_count':2,'source_git_blobs':[r['dev_git_blob'] for r in proof['modified_kernel_files']],
            'stack_protector_strong':True,'module_abi_external_pending':True,
            'userland_module_not_upgraded':True,'vintf_attestation_not_changed':True,
            'device_test':False,'flash_approved':False}
    out=work.parent.parent/'report/NOMOUNT_DEV_2EF0_COMPILED.json'
    need(not out.exists(),'DEV_BUILD_REPORT_COLLISION')
    out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print('NOMOUNT_DEV_2EF0_KERNEL_COMPILED_SOURCE_VERIFIED=PASS; NO_FLASH',flush=True)
    return report

def inject_after_stack(original,worker:Path,donor:Path):
    out=original(worker)
    content=worker.read_text()
    need(content.count(STAGE)==1 and content.count(OVERLAY)==1 and
         content.count(POST)==1,'DEV_COMPOSITE_WORKER_ANCHORS_MISSING')
    need(content.index(STAGE)<content.index(OVERLAY)<content.index(POST),
         'DEV_COMPOSITE_WORKER_STAGE_ORDER_WRONG')
    need('nomount_dev_2ef0' not in content,'DEV_ALREADY_IN_WORKER')
    d=str(donor.resolve(strict=True))
    content=content.replace(STAGE,STAGE+
           '        from veux_nomount_dev_2ef0 import stage_dev\n'
           +f'        nomount_dev_2ef0_stage = stage_dev(src, work, Path({d!r}))\n',1)
    content=content.replace(POST,POST+
           '        from veux_nomount_dev_2ef0 import verify_dev\n'
           +'        result["nomount_dev_2ef0"] = verify_dev(src, work, nomount_dev_2ef0_stage, result)\n',1)
    ast.parse(content,filename=str(worker))
    need(content.count('nomount_dev_2ef0_stage = stage_dev(')==1 and
         content.count('result["nomount_dev_2ef0"] = verify_dev(')==1 and
         content.index(STAGE)<content.index('nomount_dev_2ef0_stage = stage_dev(')<content.index(OVERLAY),
         'DEV_INJECT_PRE_COMPILE_ORDER_FAILURE')
    worker.write_text(content)
    need(out['worker_source_modified_only_in_temp'] is True,'PREVIOUS_R2_GATE_WAS_NOT_USED')
    return {**out,'dev_injected_after_unchanged_r2_stack_gate':True,
            'driver_compiled_before_result_checks':True}

def build(repo,work,reference,donor522,sync,donor_dev,jobs):
    import veux_r5s2_true_version as ver
    import veux_r6_nomount211_build_r2 as r2
    need(1<=jobs<=12,'INVALID_BUILD_JOBS')
    donor_check(Path(donor_dev))
    old=r2.inject_stack_gates;calls=[]
    def wrapped(worker):
        proof=inject_after_stack(old,worker,Path(donor_dev));calls.append(proof);return proof
    r2.inject_stack_gates=wrapped
    try:
        ver.build(Path(repo),Path(work),Path(reference),Path(donor522),Path(sync),jobs)
    finally:
        r2.inject_stack_gates=old
    need(len(calls)==1 and calls[0]['dev_injected_after_unchanged_r2_stack_gate'],
         'DEV_BUILD_WORKER_NOT_INSERTED_EXACTLY_ONCE')
    result=json.loads((Path(work)/'public/5.4.274/RESULT.json').read_text())
    dev=result.get('nomount_dev_2ef0') or {}
    need(dev.get('status')=='NOMOUNT_DEV_2EF0_KERNEL_COMPILED_NOT_DEVICE_TESTED' and
         dev.get('dev_commit')==DEV and result.get('bakasu_true_version',{}).get('version')==35234,
         'DEV_35234_FULL_BUILD_PROOF_MISSING')
    print('VEUX_NOMOUNT_DEV2EF0_BAKASU35234_KERNEL=PASS; FLASH_TEST_PENDING',flush=True)
    return result

def package(work):
    import veux_r5s2_true_version as ver
    root=Path(work).resolve(strict=True)
    result=json.loads((root/'public/5.4.274/RESULT.json').read_text())
    nm=result.get('nomount_dev_2ef0') or {}
    need(nm.get('status')=='NOMOUNT_DEV_2EF0_KERNEL_COMPILED_NOT_DEVICE_TESTED' and
         nm.get('dev_commit')==DEV,'DEV_PUBLISH_COMPAT_PROOF_MISSING')
    need(result.get('bakasu_true_version',{}).get('version')==35234,'BAKASU_VERSION_NOT_35234')
    meta=ver.package_versioned(root)
    artifact=Path(meta['versioned_ak3'])
    labeled=artifact.with_name('NMDEV_2ef0b153_'+artifact.name)
    need(not labeled.exists(),'DEV_AK3_ALREADY_EXISTS')
    artifact.rename(labeled)
    report_file=root/'versioned-public/5.4.274/RESULT.json'
    data=json.loads(report_file.read_text())
    data['nomount_dev_release_scope']='EXPERIMENTAL_DEV_2ef0b153_NOT_STABLE_NO_VINTF_CLAIM'
    data['artifact_name']=labeled.name
    report_file.write_text(json.dumps(data,sort_keys=True,indent=2)+'\n')
    dest=report_file.parent
    sums=''.join(f'{digest(p.read_bytes())}  {p.name}\n' for p in sorted(dest.iterdir()) if p.name!='SHA256SUMS.txt')
    (dest/'SHA256SUMS.txt').write_text(sums)
    need(set(x.name for x in dest.iterdir())=={labeled.name,'RESULT.json','SHA256SUMS.txt','RMNET-INSTALLATION.txt',next(p.name for p in dest.iterdir() if p.name.endswith('boot.img'))},
         'DEV_RELEASE_UNEXPECTED_FILES')
    with zipfile.ZipFile(labeled) as z:
        need(z.testzip() is None and len(z.namelist())==20,'DEV_AK3_ZIP_CORRUPT')
        need(digest(z.read('Image'))==data['image_sha256'],'DEV_AK3_IMAGE_NOT_COMPILED_IMAGE')
    print('NOMOUNT_DEV_2EF0_BAKASU35234_EXPERIMENTAL_AK3=PASS; NO_FLASH',flush=True)
    return {'ak3':labeled.name,'sha256':digest(labeled.read_bytes()),'kernel_image_sha256':data['image_sha256']}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('action',choices=['donor','build','package'])
    p.add_argument('--repo',type=Path);p.add_argument('--work',type=Path)
    p.add_argument('--reference',type=Path);p.add_argument('--donor522',type=Path)
    p.add_argument('--sync',type=Path);p.add_argument('--nmdev',type=Path)
    p.add_argument('--jobs',type=int,default=4)
    a=p.parse_args()
    if a.action=='donor':
        need(a.nmdev is not None,'NMDEV_DONOR_REQUIRED')
        print(json.dumps(donor_check(a.nmdev),sort_keys=True))
    elif a.action=='build':
        need(all((a.repo,a.work,a.reference,a.donor522,a.sync,a.nmdev)), 'BUILD_ARGS_MISSING')
        build(a.repo,a.work,a.reference,a.donor522,a.sync,a.nmdev,a.jobs)
    else:
        need(a.work is not None,'WORK_ARG_MISSING');print(json.dumps(package(a.work),sort_keys=True))

if __name__=='__main__':
    try: main()
    except (PortBlocked,OSError,subprocess.SubprocessError,ValueError,KeyError) as e:
        print('VEUX_NOMOUNT_DEV_2EF0_BLOCKED:'+type(e).__name__+':'+str(e),file=sys.stderr)
        raise SystemExit(1)
