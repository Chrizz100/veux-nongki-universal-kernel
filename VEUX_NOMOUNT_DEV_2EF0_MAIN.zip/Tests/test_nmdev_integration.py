import sys,ast,json, tempfile,unittest, pathlib,shutil,io,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'ref_scripts'
sys.path[:0]=[str(ROOT),str(REF)]
import veux_nomount_dev_2ef0 as nm
import veux_r6_nomount211_build_r2 as r2

class NoMountDevUnit(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory()
    self.addCleanup(self.tmp.cleanup)
    self.base=Path(self.tmp.name)
    self.work=self.base/'builds/5.4.274'
    self.root=self.work/'kernel'
    self.nomount=self.root/'fs/nomount'
    self.donor=self.base/'donor'
    self.nomount.mkdir(parents=True)
    (self.donor/'kernel/src').mkdir(parents=True)
    (self.root/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n')
    (self.nomount/'Makefile').write_text('ccflags-y += -O3 -fstack-protector-strong\n')
    ck='config NOMOUNT\n'
    (self.nomount/'Kconfig').write_text(ck)
    self.old={'nomount.c':b'/* stable c */\n','nomount.h':b'/* stable h */\n'}
    self.new={'nomount.c':b'/* dev c */\n','nomount.h':b'/* dev h */\n'}
    for name in self.old:
      (self.nomount/name).write_bytes(self.old[name])
      (self.donor/'kernel/src'/name).write_bytes(self.new[name])
    self.pins={n:(nm.gitblob(self.old[n]),nm.gitblob(self.new[n])) for n in self.old}
    self.orig_kconfig=nm.KCONFIG_BLOB
    nm.KCONFIG_BLOB=nm.gitblob(ck.encode())
    self.addCleanup(lambda: setattr(nm,'KCONFIG_BLOB',self.orig_kconfig))
  def stage(self):return nm._stage(self.root,self.work,self.donor,review_donor=False,blobs=self.pins)
  def test_positive_source_staging_exactly_two(self):
    x=self.stage()
    self.assertEqual(x['status'],'NOMOUNT_DEV_2EF0_SOURCE_STAGED')
    self.assertFalse(x['vintf_fixed'])
    self.assertEqual([z['path'] for z in x['modified_kernel_files']],['fs/nomount/nomount.c','fs/nomount/nomount.h'])
    self.assertEqual((self.nomount/'nomount.c').read_bytes(),self.new['nomount.c'])
    self.assertTrue((self.base/'report/NOMOUNT_DEV_2EF0_STAGE.json').is_file())
  def test_repeat_stage_rejected(self):
    self.stage()
    with self.assertRaises(nm.PortBlocked):self.stage()
  def test_preimage_drift_fails_before_writing_any_file(self):
    (self.nomount/'nomount.h').write_bytes(b'rogue')
    c=(self.nomount/'nomount.c').read_bytes()
    with self.assertRaisesRegex(nm.PortBlocked,'PREIMAGE_DRIFT'): self.stage()
    self.assertEqual(c,(self.nomount/'nomount.c').read_bytes())
  def test_bad_donor_rejected_before_modification(self):
    (self.donor/'kernel/src/nomount.h').write_bytes(b'rogue')
    with self.assertRaisesRegex(nm.PortBlocked,'DEV_NOMOUNT_SOURCE_DRIFT'):self.stage()
    self.assertEqual((self.nomount/'nomount.c').read_bytes(),self.old['nomount.c'])
  def test_symlink_preimage_refused(self):
    (self.nomount/'nomount.h').unlink()
    (self.nomount/'nomount.h').symlink_to(self.donor/'kernel/src/nomount.h')
    with self.assertRaises(nm.PortBlocked):self.stage()
  def test_no_r2_hardening_blocks(self):
    (self.nomount/'Makefile').write_text('ccflags-y += -O3 -fno-stack-protector\n')
    with self.assertRaisesRegex(nm.PortBlocked,'STACK_HARDENING'):self.stage()
  def test_wrong_kernel_refused(self):
    (self.root/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 10\nSUBLEVEL = 274\n')
    with self.assertRaisesRegex(nm.PortBlocked,'WRONG_KERNEL'):self.stage()
  def test_dev_donor_not_git_refused(self):
    with self.assertRaises(nm.PortBlocked):nm.donor_check(self.donor)
  def _worker(self):
    w=self.base/'worker.py'
    w.write_text('def worker():\n'+r2.OVERLAY_ANCHOR+r2.COMPILE_ANCHOR+
                 "        result['bakasu_official_r6'] = bakasu_official_r6\n")
    return w
  def test_actual_r2_injection_then_dev_order(self):
    w=self._worker()
    x=nm.inject_after_stack(r2.inject_stack_gates,w,self.donor)
    t=w.read_text()
    self.assertTrue(x['worker_source_modified_only_in_temp'])
    self.assertEqual(t.count('stage_stack_protection('),1)
    self.assertEqual(t.count('nomount_dev_2ef0_stage = stage_dev('),1)
    self.assertTrue(t.index('stage_stack_protection(')<t.index('nomount_dev_2ef0_stage = stage_dev(')<t.index('overlay_hash ='))
    self.assertTrue(t.index('verify_compiled_stack(')<t.index('result["nomount_dev_2ef0"] = verify_dev('))
    ast.parse(t)
  def test_full_version_r2_dev_worker_injection(self):
    import veux_r5s2_true_version as ver
    w=self.base/'combo_worker.py'
    def parent(p,q,ref,donor):
      q.write_text('def workfn():\n'
          '        compat_522_staged = stage_522(src, bundle, work, Path("/tmp/ref"))\n'
          +r2.OVERLAY_ANCHOR+r2.COMPILE_ANCHOR
          +"        result['bakasu_official_r6'] = bakasu_official_r6\n")
      return {'status':'R5S2_INJECTED'}
    res=ver.inject_version_worker(parent,self.base,w,self.base,self.base,self.donor)
    self.assertTrue(res['real_version_worker_staged'])
    nm.inject_after_stack(r2.inject_stack_gates,w,self.donor)
    s=w.read_text();ast.parse(s)
    self.assertEqual(s.count('real_version = install_lineage('),1)
    self.assertEqual(s.count('nomount_dev_2ef0_stage = stage_dev('),1)
    self.assertTrue(s.index('stage_stack_protection(')<s.index('nomount_dev_2ef0_stage = stage_dev(')<s.index('overlay_hash ='))
    self.assertTrue(s.index('real_version = install_lineage(')<s.index('compat.compile_kernel('))
    self.assertTrue(s.index('verify_compiled_stack(')<s.index('verify_dev('))

  def test_double_inject_fails_closed(self):
    w=self._worker()
    nm.inject_after_stack(r2.inject_stack_gates,w,self.donor)
    with self.assertRaises(nm.PortBlocked):nm.inject_after_stack(lambda p:{'worker_source_modified_only_in_temp':True},w,self.donor)
  def test_missing_anchor_refused(self):
    w=self._worker();w.write_text('def worker():\n    pass\n')
    with self.assertRaises(Exception):nm.inject_after_stack(r2.inject_stack_gates,w,self.donor)
  def test_compiled_bad_result_rejected(self):
    x=self.stage()
    with self.assertRaisesRegex(nm.PortBlocked,'NO_NEW_KERNEL_IMAGE'):
      nm.verify_dev(self.root,self.work,x,{'compile':False,'image_sha256':nm.BASE_IMAGE})
  def test_pack_no_compilation_rejected(self):
    with self.assertRaises(FileNotFoundError):nm.package(self.base)
  def test_external_gitblob_formula(self):
    self.assertEqual(nm.gitblob(b''),'e69de29bb2d1d6434b8b29ae775ad8c2e48c5391')
  def test_no_vintf_integration_code(self):
    script=ROOT/'common/scripts/veux_nomount_dev_2ef0.py'
    if not script.is_file():script=ROOT/'veux_nomount_dev_2ef0.py'
    s=script.read_text()
    self.assertIn("'vintf_attestation_not_changed':True",s)
    self.assertNotIn('override_vintf',s)

if __name__=='__main__':unittest.main()
