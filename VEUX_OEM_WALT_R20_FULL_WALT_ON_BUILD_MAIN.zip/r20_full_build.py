#!/usr/bin/env python3
"""R20 actual WALT-ON ARM64 full link attempt on proven R19 source.

NO source patching, NO flash packaging, NO vendor ABI approval. Full links and
module/DTB builds are *attempted*, never inferred from object compilation.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import struct
import subprocess
import sys
import time

R19_PASS = 'R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK'
R20_COMPLETE = 'R20_WALT_ON_VMLINUX_IMAGE_DTB_AND_MODULE_BUILD_PROVEN_NO_FLASH'
R20_DIAGNOSTIC = 'R20_WALT_ON_FULL_BUILD_DIAGNOSTICS_RECORDED_NO_FLASH'
SHA = re.compile(r'^[0-9a-f]{64}$')
REQUIRED_FLAGS = ('CONFIG_SCHED_WALT=y', 'CONFIG_SMP=y', 'CONFIG_HOTPLUG_CPU=y', 'CONFIG_QGKI=y')
FORBIDDEN = ('vendor_abi_proven', 'flash_allowed', 'runtime_tested',
             'brene_changed', 'bakasusu_nomount_changed')

class GateError(RuntimeError):
    pass

def need(condition: bool, reason: str) -> None:
    if not condition:
        raise GateError(reason)

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def read_json(path: Path, maxsize: int = 250000) -> dict:
    need(path.is_file() and not path.is_symlink() and
         0 < path.stat().st_size <= maxsize, 'INVALID_INPUT_JSON:'+str(path))
    data = json.loads(path.read_text())
    need(isinstance(data, dict), 'INVALID_JSON_OBJECT')
    return data

def verify_preflight(snapshot:Path, canonical:Path, objout:Path, toolchain:Path,
                     config:Path, r18:dict, r19:dict, r18_source:dict,
                     r9_driver:Path, project:Path, output:Path) -> dict:
    for tag,path in [('snapshot',snapshot),('canonical',canonical),('objout',objout),
                     ('toolchain',toolchain),('project',project)]:
        need(path.is_dir() and not path.is_symlink(), 'INVALID_DIRECTORY:'+tag)
    need(not output.exists() and not output.is_symlink(), 'OUTPUT_ALREADY_EXISTS')
    need(output.resolve() != objout.resolve(), 'OUTPUT_EQUALS_KERNEL_OBJOUT')
    need(snapshot.resolve() != canonical.resolve(), 'CANONICAL_SOURCE_NOT_DISPOSABLE')
    need(not snapshot.resolve().is_relative_to(project.resolve()) and
         not objout.resolve().is_relative_to(project.resolve()), 'BUILD_IN_READONLY_PROJECT')
    need((snapshot/'Makefile').is_file() and not (snapshot/'Makefile').is_symlink(), 'SNAPSHOT_MAKEFILE_MISSING')
    need(r9_driver.is_file() and not r9_driver.is_symlink() and
         r9_driver.stat().st_size>2000, 'R9_BUILD_DRIVER_MISSING')
    need(r19.get('status')==R19_PASS and r19.get('all_verified') is True and
         r19.get('type_aware_symbol_count')==13 and
         r19.get('r18_real_arm64_compiled')==15 and
         r19.get('r18_objects_sha_verified')==15 and
         r19.get('r18_eight_source_postimages_verified')==8 and
         r19.get('qc_vas_undefined_cpu_mask_reference_proven') is True and
         r19.get('llvm_nm_invocations')==9, 'R19_TYPED_PROVIDER_GATE_NOT_GREEN')
    need(r18.get('kernel_version')=='5.4.274' and
         r18.get('object_success_count')==15 and
         r18.get('qc_vas_compiled') is True and
         r18.get('three_support_objects_compiled')==3 and
         r18.get('real_arm64_make_attempted') is True, 'R18_15_OBJECT_PROOF_MISSING')
    objects=r18.get('objects',{})
    need(isinstance(objects,dict) and len(objects)==15, 'R18_OBJECT_SCOPE_INVALID')
    for name,item in objects.items():
        need(isinstance(name,str) and name.endswith('.o') and '..' not in Path(name).parts,
             'R18_UNSAFE_OBJECT_PATH')
        path=objout/name
        need(path.is_file() and not path.is_symlink() and item.get('compiled') is True and
             SHA.fullmatch(item.get('object_sha256','')) and
             path.stat().st_size==item.get('object_bytes') and
             digest(path)==item.get('object_sha256'), 'R18_OBJECT_HASH_DRIFT:'+name)
    post=r18_source.get('after_sha256',{})
    need(set(post)==set(r18.get('r18_postimages',{})) and len(post)==8, 'R18_EIGHT_SOURCES_INVALID')
    for name,checksum in post.items():
        p=snapshot/name
        need(p.is_file() and not p.is_symlink() and digest(p)==checksum and
             r18['r18_postimages'].get(name)==checksum, 'R18_SOURCE_DRIFT:'+name)
    for claim in FORBIDDEN:
        need(r19.get(claim) is False and r18.get(claim) is False and
             r18_source.get(claim) is False, 'UNSAFE_PREVIOUS_STAGE_CLAIM:'+claim)
    need(config.is_file() and not config.is_symlink(), 'CONFIG_FILE_MISSING')
    cfg=config.read_text().splitlines()
    need(all(needed in cfg for needed in REQUIRED_FLAGS), 'WALT_CONFIG_MISSING_REQUIRED_FLAG')
    need((objout/'.config').is_file() and not (objout/'.config').is_symlink(), 'OBJOUT_CONFIG_MISSING')
    obj_cfg=(objout/'.config').read_text().splitlines()
    need(all(needed in obj_cfg for needed in REQUIRED_FLAGS), 'ACTUAL_OBJOUT_WALT_CONFIG_DRIFT')
    for tool in ('clang','ld.lld','llvm-nm'):
        need((toolchain/'bin'/tool).is_file(), 'PINNED_TOOLCHAIN_MISSING:'+tool)
    module_enabled='CONFIG_MODULES=y' in obj_cfg
    of_enabled='CONFIG_OF=y' in obj_cfg
    return {'config_sha256':digest(config),'actual_objout_config_sha256':digest(objout/'.config'),'modules_enabled':module_enabled,
            'dtbs_enabled':of_enabled,'source_sha256':dict(post),
            'pinned_toolchain':str(toolchain/'bin/clang'),
            'r18_object_count':len(objects)}

def load_r9_driver(path:Path):
    spec=importlib.util.spec_from_file_location('r20_pinned_r9_driver',path)
    need(spec is not None and spec.loader is not None, 'R9_DRIVER_IMPORT_FAILED')
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    need(callable(getattr(module,'make_argv',None)), 'R9_MAKE_ARGV_MISSING')
    return module

def validate_command(argv:list[str], snapshot:Path, objout:Path, target:str) -> None:
    need(isinstance(argv,list) and 4 <= len(argv) <= 45 and
         all(isinstance(x,str) and 0<len(x)<2048 for x in argv), 'INVALID_MAKE_ARGV')
    need(Path(argv[0]).name == 'make', 'R9_DRIVER_NOT_MAKE')
    need(argv.count(target)==1 and all(x not in ('clean','mrproper','distclean','modules_install',
                                                'install','flash','menuconfig') for x in argv), 'DANGEROUS_MAKE_TARGET')
    need(any(x == '-C' or x.startswith('-C') for x in argv) and
         any(x == 'ARCH=arm64' for x in argv), 'R9_MAKE_ARCH_OR_DIRECTORY_MISSING')

def execute(argv:list[str], log:Path, timeout:int, env:dict) -> dict:
    start=time.monotonic()
    timed_out=False
    ret=125
    with log.open('wb') as sink:
        try:
            proc=subprocess.Popen(argv,stdout=sink,stderr=subprocess.STDOUT,
                                  env=env,start_new_session=True)
            try:
                ret=proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out=True
                os.killpg(proc.pid,signal.SIGKILL)
                proc.wait()
                ret=124
        except OSError as error:
            sink.write(('R20_PROCESS_START_FAILED: '+str(error)+'\n').encode())
    return {'exit_code':ret,'timed_out':timed_out,
            'elapsed_seconds':round(time.monotonic()-start,2),
            'log_sha256':digest(log),'log_bytes':log.stat().st_size}

def inspect_image(path:Path) -> dict:
    obj={'exists':path.is_file() and not path.is_symlink()}
    if obj['exists']:
        obj['bytes']=path.stat().st_size
        if obj['bytes'] >= 60:
            with path.open('rb') as f:head=f.read(64)
            obj['arm64_header_ok']=head[56:60]==b'ARMd'
        else:obj['arm64_header_ok']=False
        obj['sha256']=digest(path)
    return obj

def inspect_vmlinux(path:Path) -> dict:
    obj={'exists':path.is_file() and not path.is_symlink()}
    if obj['exists']:
        obj['bytes']=path.stat().st_size
        with path.open('rb') as f:head=f.read(64)
        obj['aarch64_elf_ok']=(len(head)>=20 and head[:4]==b'\x7fELF'
                                and head[4]==2 and head[5]==1 and
                                struct.unpack_from('<H',head,18)[0]==183)
        obj['sha256']=digest(path)
    return obj

def collected_files(root:Path, globstr:str, minbytes:int=100) -> list[dict]:
    found=[]
    for f in root.glob(globstr):
        if f.is_symlink() or not f.is_file() or f.stat().st_size<minbytes:
            continue
        found.append({'path':str(f.relative_to(root)),'bytes':f.stat().st_size,
                      'sha256':digest(f)})
    return sorted(found,key=lambda d:d['path'])

def check_postimages(snapshot:Path, recorded:dict) -> bool:
    return all((snapshot/name).is_file() and not (snapshot/name).is_symlink() and
               digest(snapshot/name)==sha for name,sha in recorded.items())

def driver_run(q) -> dict:
    snapshot=Path(q.snapshot);canonical=Path(q.canonical);objout=Path(q.objout)
    toolchain=Path(q.toolchain);config=Path(q.config);output=Path(q.output)
    project=Path(q.project);r9_driver=Path(q.r9_driver)
    r18=read_json(Path(q.r18_report));r19=read_json(Path(q.r19_report))
    r18_source=read_json(Path(q.r18_source))
    pin=verify_preflight(snapshot,canonical,objout,toolchain,config,r18,r19,
                         r18_source,r9_driver,project,output)
    r9=load_r9_driver(r9_driver)
    output.mkdir(parents=True)
    (output/'make_logs').mkdir()
    reportpath=output/'R20_BUILD_RESULT.json'
    report={'status':R20_DIAGNOSTIC,'kernel_version':'5.4.274',
            'real_arm64_make_attempted':False,'r19_typed_providers_proven':True,
            'r19_objects_proven':15,'r19_type_aware_providers_proven':13,
            'source_read_only':True,'original_project_read_only':True,
            'full_image_proven':False,'vmlinux_linked':False,
            'kernel_image_built':False,'dtbs_built':False,'modules_built':False,
            'module_symvers_generated':False,'vendor_crc_matched':False,
            'vendor_abi_proven':False,'flash_allowed':False,'runtime_tested':False,
            'brene_changed':False,'bakasusu_nomount_changed':False,
            'make_targets':{},'provenance':pin,
            'notice':'No boot.img/AnyKernel ZIP is generated. GitHub workflow completion does not imply full-build success.'}
    def save():reportpath.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    save()
    env=os.environ.copy()
    env['PATH']=str(toolchain/'bin')+os.pathsep+env.get('PATH','')
    env['KBUILD_BUILD_USER']='veux-r20'
    env['KBUILD_BUILD_HOST']='github-actions'
    stages=[('Image',5400),('dtbs',1500),('modules',2400)]
    for target,timeout in stages:
        if target=='dtbs' and not pin['dtbs_enabled']:
            report['make_targets'][target]={'skipped':'CONFIG_OF is not enabled'}
            save();continue
        if target=='modules' and not pin['modules_enabled']:
            report['make_targets'][target]={'skipped':'CONFIG_MODULES is not enabled'}
            save();continue
        # Use EXACT proven R9 Android-Clang invocation, not a newly improvised compiler setup.
        argv=r9.make_argv(snapshot,objout,toolchain,target,2)
        validate_command(argv,snapshot,objout,target)
        log=output/'make_logs'/('R20_'+target+'_make.log')
        report['real_arm64_make_attempted']=True
        outcome=execute(argv,log,timeout,env)
        report['make_targets'][target]={**outcome,'invocation':argv}
        save()
        if outcome['exit_code']!=0 or outcome['timed_out']:
            report['failed_target']=target
            break
    image=inspect_image(objout/'arch/arm64/boot/Image')
    vmlinux=inspect_vmlinux(objout/'vmlinux')
    dtbs=collected_files(objout/'arch/arm64/boot/dts','**/*.dtb') if pin['dtbs_enabled'] else []
    modules=collected_files(objout,'**/*.ko') if pin['modules_enabled'] else []
    symvers=objout/'Module.symvers'
    report['image']=image;report['vmlinux']=vmlinux
    report['dtb_files']=dtbs;report['module_files']=modules
    report['module_symvers_generated']=symvers.is_file() and not symvers.is_symlink() and symvers.stat().st_size>0
    if report['module_symvers_generated']:
        report['module_symvers_sha256']=digest(symvers)
    ok_image=report['make_targets'].get('Image',{}).get('exit_code')==0 and image.get('arm64_header_ok') is True and image.get('bytes',0)>1_000_000
    ok_vmlinux=ok_image and vmlinux.get('aarch64_elf_ok') is True and vmlinux.get('bytes',0)>1_000_000
    ok_dtb=(not pin['dtbs_enabled']) or (report['make_targets'].get('dtbs',{}).get('exit_code')==0 and len(dtbs)>0)
    ok_mod=(not pin['modules_enabled']) or (report['make_targets'].get('modules',{}).get('exit_code')==0 and bool(modules))
    report['kernel_image_built']=ok_image
    report['vmlinux_linked']=ok_vmlinux
    report['dtbs_built']=bool(pin['dtbs_enabled'] and ok_dtb)
    report['modules_built']=bool(pin['modules_enabled'] and ok_mod)
    report['source_read_only']=check_postimages(snapshot,pin['source_sha256'])
    report['full_image_proven']=bool(ok_image and ok_vmlinux and ok_dtb and ok_mod and report['source_read_only'])
    report['status']=R20_COMPLETE if report['full_image_proven'] else R20_DIAGNOSTIC
    save()
    print('R20_REAL_MAKE='+str(report['real_arm64_make_attempted'])+
          '; IMAGE='+str(report['kernel_image_built'])+
          '; VMLINUX='+str(report['vmlinux_linked'])+
          '; DTBS='+str(len(dtbs))+'; MODULES='+str(len(modules))+
          '; FULL_BUILD='+str(report['full_image_proven'])+
          '; STATUS='+report['status']+'; ABI=UNPROVEN; FLASH=NO')
    return report

def main():
    parser=argparse.ArgumentParser()
    for name in ('snapshot','canonical','objout','toolchain','config','output',
                 'r18-report','r19-report','r18-source','r9-driver','project'):
        parser.add_argument('--'+name,required=True)
    q=parser.parse_args()
    try:driver_run(q)
    except (GateError,ValueError,OSError,KeyError,TypeError,ImportError) as error:
        print('R20_FATAL_PRECONDITION_OR_DRIVER_ERROR:'+str(error),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
