import json
import pathlib
import struct
import sys
import tempfile
from types import SimpleNamespace
from unittest import TestCase, main, mock

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import r20_full_build as r20

FLAGS = {key: False for key in r20.FORBIDDEN}
SRC_FILES = ('kernel/sched/core.c', 'kernel/sched/sched.h', 'kernel/watchdog.c',
             'include/linux/nmi.h', 'kernel/time/hrtimer.c','include/linux/hrtimer.h',
             'kernel/time/timer.c','include/linux/timer.h')

class TestR20(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)
        for label in ('snapshot','canonical','objout','toolchain','project'):
            (self.root/label).mkdir()
        self.snapshot=self.root/'snapshot';self.canonical=self.root/'canonical'
        self.objout=self.root/'objout';self.toolchain=self.root/'toolchain'
        self.project=self.root/'project';self.output=self.root/'report'
        (self.snapshot/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n')
        (self.toolchain/'bin').mkdir()
        for t in ('clang','ld.lld','llvm-nm'):
            (self.toolchain/'bin'/t).write_text('tool')
        self.cfg=self.root/'effective.config'
        self.cfg.write_text('\n'.join(r20.REQUIRED_FLAGS)+
                            '\nCONFIG_OF=y\nCONFIG_MODULES=y\n')
        (self.objout/'.config').write_bytes(self.cfg.read_bytes())
        self.r9=self.root/'pinned-r9.py';self.r9.write_text('def make_argv(a,b,c,d,e):\n    return ["make","-C",str(a),"ARCH=arm64",d]\n'+('#' * 2100))
        self.r18={**FLAGS,'kernel_version':'5.4.274',
                  'object_success_count':15,'real_arm64_make_attempted':True,
                  'qc_vas_compiled':True,'three_support_objects_compiled':3,
                  'objects':{},'r18_postimages':{}}
        for i in range(15):
            name=f'kernel/fake{i}.o';p=self.objout/name;p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(f'object_{i}'.encode())
            self.r18['objects'][name]={'compiled':True,'object_bytes':p.stat().st_size,
                                      'object_sha256':r20.digest(p)}
        self.source={**FLAGS,'after_sha256':{}}
        for i,name in enumerate(SRC_FILES):
            p=self.snapshot/name;p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(f'source {i}\n')
            self.source['after_sha256'][name]=r20.digest(p)
            self.r18['r18_postimages'][name]=r20.digest(p)
        self.r19={**FLAGS,'status':r20.R19_PASS,'all_verified':True,
                  'type_aware_symbol_count':13,'r18_real_arm64_compiled':15,
                  'r18_objects_sha_verified':15,'r18_eight_source_postimages_verified':8,
                  'qc_vas_undefined_cpu_mask_reference_proven':True,
                  'llvm_nm_invocations':9}
        self.r18f=self.root/'r18.json';self.r19f=self.root/'r19.json';self.srcf=self.root/'source.json'
        self.sync()
    def sync(self):
        for p,d in ((self.r18f,self.r18),(self.r19f,self.r19),(self.srcf,self.source)):
            p.write_text(json.dumps(d))
    def preflight(self):
        return r20.verify_preflight(self.snapshot,self.canonical,self.objout,self.toolchain,
                                    self.cfg,self.r18,self.r19,self.source,
                                    self.r9,self.project,self.output)
    def args(self):
        return SimpleNamespace(snapshot=self.snapshot,canonical=self.canonical,
          objout=self.objout,toolchain=self.toolchain,config=self.cfg,output=self.output,
          project=self.project,r9_driver=self.r9,r18_report=self.r18f,
          r19_report=self.r19f,r18_source=self.srcf)
    def assertGate(self):
        with self.assertRaises(r20.GateError):self.preflight()
    def test_01_verified_sources_and_15_objects(self):
        x=self.preflight();self.assertEqual(len(x['source_sha256']),8)
        self.assertEqual(x['r18_object_count'],15)
    def test_02_r19_must_be_completely_proven(self):
        self.r19['all_verified']=False;self.assertGate()
    def test_03_r19_symbol_count_check(self):
        self.r19['type_aware_symbol_count']=12;self.assertGate()
    def test_04_r19_qc_ref_required(self):
        self.r19['qc_vas_undefined_cpu_mask_reference_proven']=False;self.assertGate()
    def test_05_r19_must_match_exact_status(self):
        self.r19['status']='DIAGNOSTIC';self.assertGate()
    def test_06_real_elf_hash_mismatch(self):
        (self.objout/'kernel/fake0.o').write_bytes(b'tamper');self.assertGate()
    def test_07_r18_compiler_scope_tamper(self):
        self.r18['object_success_count']=14;self.assertGate()
    def test_08_source_sha_tamper(self):
        (self.snapshot/SRC_FILES[0]).write_text('tamper\n');self.assertGate()
    def test_09_brene_claim_blocked(self):
        self.source['brene_changed']=True;self.assertGate()
    def test_10_vendor_abi_claim_blocked(self):
        self.r19['vendor_abi_proven']=True;self.assertGate()
    def test_11_walt_y_config_gate(self):
        self.cfg.write_text(self.cfg.read_text().replace('CONFIG_SCHED_WALT=y','# CONFIG_SCHED_WALT is not set'))
        (self.objout/'.config').write_bytes(self.cfg.read_bytes());self.assertGate()
    def test_12_config_drift_gate(self):
        (self.objout/'.config').write_text('CONFIG_OTHER=y\n');self.assertGate()
    def test_13_build_inside_checkout_blocked(self):
        with self.assertRaises(r20.GateError):
            r20.verify_preflight(self.snapshot,self.canonical,self.project,self.toolchain,
                self.cfg,self.r18,self.r19,self.source,self.r9,self.project,self.output)
    def test_14_output_must_not_preexist(self):
        self.output.mkdir();self.assertGate()
    def test_15_image_magic_valid(self):
        p=self.root/'Image';p.write_bytes(b'0'*56+b'ARMd'+b'0'*20)
        self.assertTrue(r20.inspect_image(p)['arm64_header_ok'])
    def test_16_image_magic_rejects_corruption(self):
        p=self.root/'Image';p.write_bytes(b'bad'*30)
        self.assertFalse(r20.inspect_image(p)['arm64_header_ok'])
    def test_17_vmlinux_machine_valid(self):
        p=self.root/'vmlinux';h=bytearray(64);h[:4]=b'\x7fELF';h[4]=2;h[5]=1
        struct.pack_into('<H',h,18,183);p.write_bytes(h)
        self.assertTrue(r20.inspect_vmlinux(p)['aarch64_elf_ok'])
    def test_18_vmlinux_x86_rejected(self):
        p=self.root/'vmlinux';h=bytearray(64);h[:4]=b'\x7fELF';h[4]=2;h[5]=1
        struct.pack_into('<H',h,18,62);p.write_bytes(h)
        self.assertFalse(r20.inspect_vmlinux(p)['aarch64_elf_ok'])
    def test_19_make_driver_command(self):
        r20.validate_command(['make','-C',str(self.snapshot),'ARCH=arm64','Image'],self.snapshot,self.objout,'Image')
    def test_20_fatal_target_forbidden(self):
        with self.assertRaises(r20.GateError):
            r20.validate_command(['make','-C',str(self.snapshot),'ARCH=arm64','clean','Image'],self.snapshot,self.objout,'Image')
    def test_21_no_missing_arch(self):
        with self.assertRaises(r20.GateError):
            r20.validate_command(['make','-C',str(self.snapshot),'Image'],self.snapshot,self.objout,'Image')
    def test_22_corrupt_manifest_input(self):
        p=self.root/'bad.json';p.write_text('[]')
        with self.assertRaises(r20.GateError):r20.read_json(p)
    def test_23_symlink_source_rejected(self):
        p=self.snapshot/SRC_FILES[0];p.unlink();p.symlink_to(self.root/'r19.json');self.assertGate()
    def mock_build(self,rcs=None,modules=True,dtbs=True,change_source=False):
        rcs=rcs or {'Image':0,'dtbs':0,'modules':0}
        def fake_run(argv,log,timeout,env):
            stage=argv[-1];log.write_text('FAKE_TEST_ONLY\n')
            if stage=='Image' and rcs[stage]==0:
                v=bytearray(1024*1024+1);v[:4]=b'\x7fELF';v[4]=2;v[5]=1
                struct.pack_into('<H',v,18,183)
                (self.objout/'vmlinux').write_bytes(v)
                raw=self.objout/'arch/arm64/boot/Image';raw.parent.mkdir(parents=True,exist_ok=True)
                img=bytearray(1024*1024+1);img[56:60]=b'ARMd';raw.write_bytes(img)
            if stage=='dtbs' and dtbs:
                d=self.objout/'arch/arm64/boot/dts/vendor/test.dtb';d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b'X'*128)
            if stage=='modules' and modules:
                k=self.objout/'drivers/x.ko';k.parent.mkdir(parents=True,exist_ok=True);k.write_bytes(b'K'*128)
                (self.objout/'Module.symvers').write_text('a'*128)
            if change_source:(self.snapshot/SRC_FILES[0]).write_text('DIFFERENT')
            return {'exit_code':rcs[stage],'timed_out':False,'elapsed_seconds':0,
                    'log_sha256':r20.digest(log),'log_bytes':log.stat().st_size}
        mock_driver=SimpleNamespace(make_argv=lambda a,b,c,t,j:['make','-C',str(a),'ARCH=arm64',t])
        with mock.patch.object(r20,'load_r9_driver',return_value=mock_driver),mock.patch.object(r20,'execute',side_effect=fake_run):
            return r20.driver_run(self.args())
    def test_24_end_to_end_real_gate_simulated_success(self):
        x=self.mock_build();self.assertEqual(x['status'],r20.R20_COMPLETE)
        self.assertTrue(x['full_image_proven']);self.assertFalse(x['flash_allowed'])
        self.assertFalse(x['vendor_abi_proven']);self.assertTrue(x['module_symvers_generated'])
    def test_25_failed_image_not_green(self):
        x=self.mock_build(rcs={'Image':2,'dtbs':0,'modules':0})
        self.assertEqual(x['status'],r20.R20_DIAGNOSTIC)
        self.assertEqual(x['failed_target'],'Image');self.assertNotIn('dtbs',x['make_targets'])
    def test_26_missing_dtb_not_green(self):
        x=self.mock_build(dtbs=False);self.assertFalse(x['full_image_proven'])
    def test_27_modules_expected_if_configured(self):
        x=self.mock_build(modules=False);self.assertFalse(x['full_image_proven'])
    def test_28_no_modules_config_skip(self):
        self.cfg.write_text(self.cfg.read_text().replace('CONFIG_MODULES=y',''))
        (self.objout/'.config').write_bytes(self.cfg.read_bytes())
        x=self.mock_build(modules=False);self.assertTrue(x['full_image_proven'])
        self.assertIn('skipped',x['make_targets']['modules'])
    def test_29_postimage_modified_fails_result(self):
        x=self.mock_build(change_source=True);self.assertFalse(x['source_read_only'])
        self.assertFalse(x['full_image_proven'])
    def test_30_report_written_on_diagnostic(self):
        self.mock_build(rcs={'Image':2,'dtbs':0,'modules':0})
        j=json.loads((self.output/'R20_BUILD_RESULT.json').read_text())
        self.assertFalse(j['flash_allowed']);self.assertEqual(j['status'],r20.R20_DIAGNOSTIC)

if __name__=='__main__':main()
