#!/usr/bin/env bash
# Restore pinned actionlint v1.7.12 for a Linux x86_64 host.
# Offline: ACTIONLINT_ARCHIVE=/absolute/path/to/actionlint_1.7.12_linux_amd64.tar.gz
set -euo pipefail
version='1.7.12'
expected='8aca8db96f1b94770f1b0d72b6dddcb1ebb8123cb3712530b08cc387b349a3d8'
destination="${1:-$PWD/actionlint-v1.7.12}"
archive="${ACTIONLINT_ARCHIVE:-}"
if [[ "$(uname -sm)" != 'Linux x86_64' ]]; then
  echo 'ACTIONLINT_UNSUPPORTED_LOCAL_PLATFORM: require Linux x86_64' >&2
  exit 2
fi
if [[ -z "$archive" ]]; then
  archive="$(mktemp -t actionlint-r20-XXXXXX.tar.gz)"
  trap 'rm -f "$archive"' EXIT
  curl --fail --location --retry 3 --connect-timeout 20 --max-time 180 \
    "https://github.com/rhysd/actionlint/releases/download/v${version}/actionlint_${version}_linux_amd64.tar.gz" \
    --output "$archive"
fi
[[ -f "$archive" && ! -L "$archive" ]] || { echo 'ACTIONLINT_ARCHIVE_MISSING' >&2;exit 3; }
printf '%s  %s\n' "$expected" "$archive" | sha256sum -c -
[[ ! -e "$destination" && ! -L "$destination" ]] || { echo 'DESTINATION_EXISTS' >&2; exit 4; }
mkdir -p "$destination"
tar -xzf "$archive" -C "$destination" actionlint
"$destination/actionlint" -version
echo "ACTIONLINT_RESTORED=$destination/actionlint"
