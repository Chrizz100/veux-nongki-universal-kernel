#!/usr/bin/env python3
"""R5S1: verified official BakaSU f308 sync-susfs semantics on VEUX 5.4.

Keep the newer d726 context_add_hash protection and R3/R5 SELinux runtime
fixes. Stage ONLY the single BakaSU selinux_hide.c into disposable CI source.
Retain the immutable R6 kernel + NoMount 2.1.1 and SUSFS 2.3.0 donors.
Strictly NO flash/release and NO change to the GitHub source checkout.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import difflib

import veux_r6_nomount211_build_r2 as r2
import veux_r6_susfs_selinux54_port_r3 as r3
import veux_r5_susfs_selinux_hook_port as r5
import veux_r6_sync_f308_reconstruct as sync

KERNEL = '5.4.274'
BAKASU_PIN = '5b76b884c75f729a220bb317aa4a4fc78f0e0e9c'
SUSFS_PIN = '5326e21a7eb232f9e21debdd5164e99bee3d1e2f'
NOMOUNT_PIN = '7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3'
EXPECTED_FINAL_SHA = '78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78'
EXPECTED_FINAL_BLOB = '0698d24d3cb3b98945886bc3aff66e02b6735fe9'
R4_IMAGE_SHA = 'e11853f4f98eb8a4231b9a02c52a5ca099dbead0e577d7934e7dc49c5e8ccb57'
R5_SOURCE_SHA = r5.TARGET_SHA
REL = r5.REL

class SyncPortError(RuntimeError):
    pass

def need(ok: bool, reason: str):
    if not ok: raise SyncPortError(reason)

def write_report(root: Path, rel: str, data: dict) -> None:
    target=root/'report'/rel
    need(not target.exists() and not target.is_symlink(),'REPORT_COLLISION:'+rel)
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def compose_from_d726(original: bytes) -> tuple[bytes,dict]:
    need(sync.sha(original)==sync.OFFICIAL_D726_SHA and sync.git_blob(original)==sync.OFFICIAL_D726_BLOB,
        'D726_INPUT_NOT_AUTHENTIC')
    # Route A: the already proven R5 intermediate, cryptographically pinned.
    r4,_=r3.transform_status_guard(original)
    r5source,proof5=r5.guard_r4_text(r4)
    r5.verify_target(r5source)
    # Route B: reconstruct exact public f308 original, REAPPLY newer security
    # protection, then reapply the proven R3 and R5 runtime guards.
    reviewed_sync,original_f308=sync.reconstruct(original)
    need(sync.git_blob(original_f308)==sync.OFFICIAL_SYNC_BLOB,
        'NOT_ACTUAL_OFFICIAL_SYNC_F308_COMMIT')
    stage3,_=r3.transform_status_guard(reviewed_sync,
        expected_sha=sync.sha(reviewed_sync),expected_blob=sync.git_blob(reviewed_sync))
    staged, proof=r5.guard_r4_text(stage3,
        expected_sha=r5.sha(stage3), expected_blob=r5.git_blob(stage3))
    need(sync.sha(staged)==EXPECTED_FINAL_SHA and sync.git_blob(staged)==EXPECTED_FINAL_BLOB,
        'SYNC_PLUS_D726_PLUS_R5_GOLDEN_POSTIMAGE_DRIFT')
    need(staged.count(b'context_add_hash(policydb, &context)')==1 and
         staged.count(b'context_add_hash(orig_policydb, &orig_context)')==1,
         'D726_CONTEXT_HASH_SECURITY_REGRESSION')
    need(staged.count(r5.NEW.encode())==3 and staged.count(r3.AFTER.encode())==1,
         'R3_R5_SELINUX_FALLBACK_GUARDS_NOT_UNIQUE')
    need(b'#error BakaSU does NOT support susfs selinux_hide feature in nongki' in staged,
         'UPSTREAM_EXPLICIT_5_4_FEATURE_BOUNDARY_REMOVED')
    need(b'fake_state.policy = backup_sepolicy;' in staged,
         'OFFICIAL_SYNC_SELINUX_CODE_NOT_PRESENT')
    need(r5.sha(r5source)==R5_SOURCE_SHA,'R5_BASELINE_SOURCE_REPLACED')
    patch=''.join(difflib.unified_diff(r5source.decode().splitlines(keepends=True),
        staged.decode().splitlines(keepends=True),fromfile='a/'+REL,tofile='b/'+REL,n=3))
    need(patch.count('@@')>=8 and len(patch)<12500,'SYNC_DIFF_SCOPE_DRIFT')
    return staged, {'status':'SOURCE_COMPOSED_NOT_COMPILED',
        'kernel':KERNEL,'changed_path':REL,'upstream_branch':'Baka-SU/BakaSU:sync-susfs',
        'upstream_exact_commit':sync.OFFICIAL_SYNC_COMMIT,
        'upstream_blob_verified':sync.OFFICIAL_SYNC_BLOB,
        'official_d726_security_commit':'d7260ca1e5c128061122924d0d48754e361e135c',
        'upstream_f308_lacks_d726_security_fix':True,
        'd726_security_fix_retained':True,
        'baseline_r5_sha256':r5.sha(r5source),
        'candidate_sha256':sync.sha(staged),'candidate_git_blob':sync.git_blob(staged),
        'f308_5_4_unsupported_manual_hooks_unchanged':True,
        'native_susfs_selinux_manual_hook_not_enabled':True,
        'new_bakasu_32bit_syscall_522_not_included':True,
        'susfs_kernel_version':'2.3.0',
        'r3_r5_runtime_guards_retained':True,
        'upstream_diff':patch,'proof_r5':proof5,
        'device_pass':False,'flash_release':False}

def stage(src: Path,bundle: Path,work: Path,reference: Path) -> dict:
    src=src.resolve(strict=True);bundle=bundle.resolve(strict=True)
    work=work.resolve(strict=True);reference=reference.resolve(strict=True)
    need(work.name==KERNEL and work.parent.name=='builds' and src.is_relative_to(work),
         'SYNC_SOURCE_NOT_DISPOSABLE_5_4')
    root=work.parent.parent
    need(bundle==root/'bundle' and reference.is_file() and not reference.is_symlink() and
         not reference.is_relative_to(src),'SYNC_BAD_REFERENCE_OR_BUNDLE_SCOPE')
    targets=json.loads((bundle/'targets.json').read_text())['components']
    need(targets['resukisu']['commit']==BAKASU_PIN and
         targets['susfs']['commit']==SUSFS_PIN and
         targets['nomount']['commit']==NOMOUNT_PIN,
         'SYNC_FROZEN_SOURCE_COMPONENTS_CHANGED')
    prior=json.loads((work/'BAKASU-OFFICIAL-D726-R6.json').read_text())
    need(prior.get('source_matches_official_bakasu_d726_byte_for_byte') is True and
         prior.get('after_sha256')==sync.OFFICIAL_D726_SHA,
         'SYNC_ORIGINAL_UPSTREAM_D726_NOT_APPLIED')
    host=r3.verify_host(src)
    target=r3.safe_path(src,REL)
    original=target.read_bytes()
    final,report=compose_from_d726(original)
    need(sync.sha(reference.read_bytes())==EXPECTED_FINAL_SHA and
         reference.read_bytes()==final,'SYNC_PACKAGE_GOLDEN_REFERENCE_NOT_IDENTICAL')
    need(target.read_bytes()==original,'SYNC_CONCURRENT_SOURCE_MUTATION')
    target.write_bytes(final)
    need(target.read_bytes()==final,'SYNC_STAGE_WRITEBACK_FAILED')
    r3.verify_host(src)
    report['native_selinux_source_hashes']=host
    report['source_staged_only_in_runner_temp']=True
    report.pop('upstream_diff')
    write_report(root,'BAKASU_SYNC_F308_D726_R5_STAGE.json',report)
    (root/'report/BAKASU_SYNC_F308_D726_R5.patch').write_text(compose_from_d726(original)[1]['upstream_diff'])
    print('VEUX_SYNC_F308_D726_R5_SOURCE=PASS; CURRENT_5_4_MANUAL_HOOK_DISABLED; DEVICE_PASS=NO',flush=True)
    return report

def verify_compiled(src: Path,work: Path,source:dict,result:dict)->dict:
    src=src.resolve(strict=True);work=work.resolve(strict=True)
    need(src.is_relative_to(work) and work.name==KERNEL,'SYNC_VERIFY_NOT_BUILT_SOURCE')
    need(source.get('candidate_sha256')==EXPECTED_FINAL_SHA and
         source.get('d726_security_fix_retained') is True,
         'SYNC_SOURCE_PROOF_MISSING')
    effective=r3.safe_path(src,REL).read_bytes()
    need(sync.sha(effective)==EXPECTED_FINAL_SHA and
         sync.git_blob(effective)==EXPECTED_FINAL_BLOB,'SYNC_OBJECT_SOURCE_CHANGED_DURING_BUILD')
    r3.verify_host(src)
    proofpath=work/'build/drivers/kernelsu/feature/selinux_hide.o'
    cmdpath=work/'build/drivers/kernelsu/feature/.selinux_hide.o.cmd'
    configpath=work/'config-reports/actual-build.config'
    log=work/'compile.log'
    for f in (proofpath,cmdpath,configpath,log):
        need(f.is_file() and not f.is_symlink() and f.stat().st_size>0,
             'SYNC_COMPILE_PROOF_FILE_MISSING_'+f.name)
    cmd=cmdpath.read_text(errors='replace')
    cfg=configpath.read_text(errors='replace')
    cl=log.read_text(errors='replace')
    need('drivers/kernelsu/feature/selinux_hide.o' in cmd and
         '-fstack-protector-strong' in cmd and '-flto=thin' in cmd and
         '-fno-stack-protector' not in cmd,'SYNC_OBJECT_SECURITY_FLAGS_MISSING')
    need(re.search(r'(?m)^\s*CC\s+drivers/kernelsu/feature/selinux_hide\.o\b',cl) is not None,
         'SYNC_OBJECT_NOT_RECOMPILED')
    for opt in ('CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
                'CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y','CONFIG_STACKPROTECTOR_STRONG=y'):
        need(re.search(r'(?m)^'+re.escape(opt)+r'$',cfg) is not None,
             'SYNC_KERNEL_CONFIG_INCOMPATIBLE_'+opt)
    need(result.get('kernel')==KERNEL,'SYNC_COMPILED_WRONG_KERNEL')
    report={'status':'EXPERIMENTAL_COMPILED_SYNC_SUSFS_R5S1_WITH_D726',
       'source_sha256':EXPECTED_FINAL_SHA,'source_blob':EXPECTED_FINAL_BLOB,
       'compiled_object_sha256':sync.sha(proofpath.read_bytes()),
       'compile_command_sha256':sync.sha(cmdpath.read_bytes()),
       'config_sha256':sync.sha(configpath.read_bytes()),
       'status_guard_r3_and_r5_retained':True,
       'official_f308_reconstructed_and_reconciled':True,
       'retained_d726_context_hash_safety':True,
       'build_flags_strong_stack_protector_and_thinlto':True,
       'no_explicit_5_4_susfs_manual_hook':True,
       'device_pass':False,'flash_release':False}
    write_report(work.parent.parent,'BAKASU_SYNC_F308_D726_R5_COMPILED.json',report)
    return report

def inject_worker(worker:Path,reference:Path)->dict:
    need(worker.is_file() and not worker.is_symlink(), 'SYNC_WORKER_NOT_DISPOSABLE')
    source=worker.read_text()
    anchor=r2.OVERLAY_ANCHOR
    post=r2.COMPILE_ANCHOR
    need(source.count(anchor)==1 and source.count(post)==1 and
        "result['bakasu_official_r6'] = bakasu_official_r6" in source,
        'SYNC_KNOWN_R6_WORKER_ANCHOR_DRIFT')
    need('sync_staged = stage(' not in source and 'sync_compiled = verify_compiled(' not in source,
        'SYNC_DOUBLE_INJECTION_FORBIDDEN')
    # Reference lives in immutable extracted verified R5S1 source, not the repo.
    ref=str(reference.resolve(strict=True))
    before=source.replace(anchor,
        '        from veux_sync_susfs_r1_build import stage\n'
        +f'        sync_staged = stage(src, bundle, work, Path({ref!r}))\n'
        +anchor,1)
    final=before.replace(post,post+
        '        from veux_sync_susfs_r1_build import verify_compiled\n'
        +'        sync_compiled = verify_compiled(src, work, sync_staged, result)\n'
        +"        result['bakasu_sync_f308_d726_r5'] = sync_compiled\n",1)
    need(final.count('sync_staged = stage(')==1 and
         final.count('sync_compiled = verify_compiled(')==1,
         'SYNC_WORKER_EDITS_DUPLICATED')
    ast.parse(final,filename=str(worker))
    worker.write_text(final)
    need(worker.read_text()==final,'SYNC_WORKER_WRITEBACK_FAILED')
    return {'status':'SYNC_ONLY_DISPOSABLE_WORKER_INJECTED',
            'worker_before_sha256':sync.sha(source.encode()),
            'worker_after_sha256':sync.sha(final.encode()),
            'repository_worker_unchanged':True}

def build(repo:Path,root:Path,jobs:int,reference:Path)->dict:
    repo=repo.resolve(strict=True);root=root.resolve(strict=True)
    reference=reference.resolve(strict=True)
    need(not root.is_relative_to(repo) and 1<=jobs<=16,'SYNC_INVALID_BUILD_SCOPE')
    need(sync.sha(reference.read_bytes())==EXPECTED_FINAL_SHA,
         'SYNC_FINAL_REFERENCE_MISMATCH')
    prior=json.loads((root/'report/NOMOUNT211_R6_SOURCE_ONLY.json').read_text())
    need(prior.get('status')=='SOURCE_PREFLIGHT_ONLY_PASS' and
         prior.get('bakasu_or_susfs_upgraded') is False,
         'SYNC_SOURCE_PREFLIGHT_NOT_GREEN')
    old_load=r2.r1.load_r6
    original_pythonpath=os.environ.get('PYTHONPATH','')
    proof=[]
    def new_loader(path):
        r6=old_load(path)
        earlier=r6.selinux_r3.inject_worker
        def inject(original,dest):
            info=earlier(original,dest)
            proof.append(inject_worker(dest,reference))
            return info
        r6.selinux_r3.inject_worker=inject
        return r6
    r2.r1.load_r6=new_loader
    os.environ['PYTHONPATH']=os.pathsep.join([str(Path(__file__).resolve().parent),original_pythonpath])
    try:
        base=r2.build(repo,root,jobs)
    finally:
        r2.r1.load_r6=old_load
        os.environ['PYTHONPATH']=original_pythonpath
    need(len(proof)==1 and proof[0]['repository_worker_unchanged'],
         'SYNC_WORKER_INJECTION_NOT_EXACTLY_ONCE')
    row=json.loads((root/'public'/KERNEL/'RESULT.json').read_text())
    rp=row.get('bakasu_sync_f308_d726_r5') or {}
    need(rp.get('status')=='EXPERIMENTAL_COMPILED_SYNC_SUSFS_R5S1_WITH_D726' and
         rp.get('source_sha256')==EXPECTED_FINAL_SHA,
         'SYNC_WORKER_COMPILE_REPORT_MISSING')
    need(row.get('targets',{}).get('resukisu',{}).get('commit')==BAKASU_PIN and
         row['targets']['nomount']['commit']==NOMOUNT_PIN and
         row['targets']['susfs']['commit']==SUSFS_PIN,
         'SYNC_BACKPORT_COMPONENT_PIN_DRIFT')
    need(all(row.get(k) is True for k in ('compile','package','static_boot')) and
         row.get('device') is False and row.get('image_sha256')!=R4_IMAGE_SHA,
         'SYNC_RESULT_NOT_A_NEW_COMPILED_KERNEL')
    need(base.get('status')=='EXPERIMENTAL_BUILD_GATES_PASS_DEVICE_NOT_TESTED',
         'SYNC_R2_HARDENED_KERNEL_BUILD_GATES_MISSING')
    report={'status':'EXPERIMENTAL_SYNC_F308_D726_R5_KERNEL_BUILT_NOT_DEVICE_TESTED',
       'r4_reference_kernel_sha256':R4_IMAGE_SHA,'candidate_sha256':row['image_sha256'],
       'official_sync_git_commit':sync.OFFICIAL_SYNC_COMMIT,
       'd726_security_fix_kept':True,'r3_r5_runtime_guards_kept':True,
       'bakasu_32bit_522_not_integrated':True,
       'full_susfs_510_host_patch_not_integrated':True,
       'source_component_pins_unchanged':True,
       'compile':True,'package':True,'static_boot':True,
       'device_pass':False,'flash_release':False}
    write_report(root,'BAKASU_SYNC_F308_D726_R5_FINAL.json',report)
    print('VEUX_SYNC_F308_D726_R5_BUILD_GATES=PASS; DEVICE_PASS=NO; NO_FLASH',flush=True)
    return report

def main()->int:
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=('audit','build'))
    p.add_argument('--repo',type=Path)
    p.add_argument('--work',type=Path)
    p.add_argument('--jobs',type=int,default=4)
    p.add_argument('--reference',type=Path,required=True)
    p.add_argument('--d726',type=Path)
    args=p.parse_args()
    try:
        if args.command=='audit':
            need(args.d726 is not None,'D726_AUDIT_INPUT_REQUIRED')
            out,proof=compose_from_d726(args.d726.read_bytes())
            need(out==args.reference.read_bytes(),'SOURCE_AUDIT_GOLDEN_FILE_CHANGED')
            print('VEUX_SYNC_F308_D726_R5_SOURCE_AUDIT=PASS; ONLY_SOURCE_NOT_COMPILED')
        else:
            need(args.repo is not None and args.work is not None,'SYNC_BUILD_ARGUMENTS_MISSING')
            build(args.repo,args.work,args.jobs,args.reference)
    except Exception as exc:
        print('VEUX_SYNC_BUILD_OR_PORT_BLOCKED:'+type(exc).__name__+':'+str(exc),file=sys.stderr)
        return 1
    return 0

if __name__=='__main__':
    raise SystemExit(main())
