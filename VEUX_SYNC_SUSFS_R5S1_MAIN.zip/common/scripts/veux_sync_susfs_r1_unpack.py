#!/usr/bin/env python3
"""Unpack SHA-bound R5S1 and nested R5/R4/R2 verified archives to temp only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

R5_SHA='7ae99c9b8650e30289576eb9a46f7e1fdb4821bb723036acc51adef179452870'
R4_AUDIT_SHA='9d0a58fc8deafebade097b6cf8ddc4de333b08d2ae7c82edc470895236d7a0c8'
R5_AUDIT_SHA='746f997e85d6bad27c957dc99215c3d192550839257b72d2d527c88b52d660c7'
FINAL_SHA='78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78'
MEMBERS={
 'MANIFEST_SHA256.json','README_START_HIER_DE.txt',
 'baseline/VEUX_R6_SUSFS_SELINUX54_R5_MAIN.zip',
 'evidence/D726_ORIGINAL_REFERENCE_SELINUX.c',
 'evidence/R4_COMPILED_REFERENCE_SELINUX.c',
 'evidence/VEUX_R5_RUN39104446746_AUDIT_ORIGINAL.zip',
 'common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c',
 'common/scripts/veux_r6_sync_f308_reconstruct.py',
 'common/scripts/veux_sync_susfs_r1_build.py',
 'common/scripts/veux_sync_susfs_r1_unpack.py',
 'common/scripts/veux_sync_susfs_r1_verify_result.py',
 'Tests/test_veux_sync_susfs_r1.py',
 'docs/VEUX_SYNC_SUSFS_F308_D726_R5_5_4_STATUS_DE.md',
}

class UnsafeArchive(ValueError):pass

def ensure(ok:bool,msg:str):
    if not ok:raise UnsafeArchive(msg)

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()

def safe_unpack(main:Path,workspace:Path)->dict:
    main=main.resolve(strict=True)
    workspace=workspace.resolve()
    ensure(main.is_file() and not main.is_symlink(),'MAIN_SOURCE_ZIP_NOT_PLAIN_FILE')
    ensure(not workspace.exists() and not workspace.is_symlink() and
           workspace.parent.is_dir(),'WORKSPACE_COLLISION_OR_PARENT_ABSENT')
    with zipfile.ZipFile(main) as z:
        infos=z.infolist()
        ensure(len(infos)==len(MEMBERS) and {q.filename for q in infos}==MEMBERS,
               'ZIP_SCOPE_OR_MEMBERS_DRIFT')
        ensure(z.testzip() is None,'ZIP_CRC_FAILURE')
        manifest=json.loads(z.read('MANIFEST_SHA256.json'))
        ensure(manifest.get('schema')==6 and manifest.get('approved_for_flash') is False and
               set(manifest.get('files',{}))==MEMBERS-{'MANIFEST_SHA256.json'},
               'BAD_MANIFEST_SCOPE_OR_FALSE_FLASH')
        ensure(manifest.get('bakasu_full_32bit_upstream_522_integrated') is False and
               manifest.get('susfs_complete_510_host_patch_integrated') is False and
               manifest.get('official_sync_f308_plus_official_d726') is True,
               'INVALID_UPSTREAM_CLAIMS')
        blobs={}
        for info in infos:
            path=PurePosixPath(info.filename)
            mode=info.external_attr>>16
            ensure(not path.is_absolute() and '..' not in path.parts and
                   '\\' not in info.filename and stat.S_ISREG(mode),
                   'ZIP_UNSAFE_MEMBER_MODE_OR_PATH')
            raw=z.read(info.filename)
            if info.filename!='MANIFEST_SHA256.json':
                ensure(sha(raw)==manifest['files'][info.filename],
                       'ZIP_MEMBER_HASH_MISMATCH_'+info.filename)
            blobs[info.filename]=raw
    ensure(sha(blobs['baseline/VEUX_R6_SUSFS_SELINUX54_R5_MAIN.zip'])==R5_SHA,
           'NESTED_R5_NOT_APPROVED_GREEN_SOURCE')
    ensure(sha(blobs['common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c'])==FINAL_SHA,
           'SYNC_GOLDEN_C_SOURCE_MISMATCH')
    ensure(sha(blobs['evidence/VEUX_R5_RUN39104446746_AUDIT_ORIGINAL.zip'])==R5_AUDIT_SHA,
           'NEW_GREEN_R5_BUILD_EVIDENCE_DRIFT')
    with zipfile.ZipFile(__import__('io').BytesIO(blobs['evidence/VEUX_R5_RUN39104446746_AUDIT_ORIGINAL.zip'])) as r5audit:
        ensure(r5audit.testzip() is None,'R5_NEW_AUDIT_CRC_MISMATCH')
        verified=json.loads(r5audit.read('veux-r5-susfs-work/report/SUSFS_SELINUX54_R5_FINAL.json'))
        ensure(verified.get('status')=='EXPERIMENTAL_R5_THREE_HOOK_KERNEL_BUILD_PASS_DEVICE_UNTESTED' and
               verified.get('compiled_proof',{}).get('source_sha256')=='8f17c3588e10a1d5d607a098ae51075d36ed5792e1e62e3886ede14f3e7d73df' and
               verified.get('flash_release') is False and verified.get('device_pass') is False,
               'NEW_GREEN_R5_KERNEL_OR_SOURCE_PROVENANCE_FAILED')
    workspace.mkdir(parents=True)
    for name,body in blobs.items():
        out=workspace.joinpath(*PurePosixPath(name).parts)
        out.parent.mkdir(parents=True,exist_ok=True)
        ensure(not out.exists() and not out.is_symlink(),'UNPACK_DESTINATION_EXISTS')
        out.write_bytes(body)
    scripts=workspace/'common/scripts'
    sys.path.insert(0,str(scripts))
    from veux_r6_sync_f308_reconstruct import OFFICIAL_SYNC_BLOB
    ensure(OFFICIAL_SYNC_BLOB=='756fd5ef99db1c870ad737b3076c0e5510b09e68',
           'PINNED_OFFICIAL_BRANCH_DRIFT')
    # R5's own verified nested archive validation preserves original R4/R2
    # CI and original SUSFS GitLab patch evidence.
    r5zip=workspace/'baseline/VEUX_R6_SUSFS_SELINUX54_R5_MAIN.zip'
    with zipfile.ZipFile(r5zip) as z:
        ensure(z.testzip() is None,'NESTED_R5_CORRUPT')
        inner='common/scripts/veux_r5_safe_unpack.py'
        raw=z.read(inner)
        m=json.loads(z.read('MANIFEST_SHA256.json'))
        ensure(sha(raw)==m['files'][inner] and m['schema']==5,
               'NESTED_BOOTSTRAP_NOT_AUTHENTICATED')
    # This code is permitted because both its container and member SHA are
    # independently checked BEFORE it is loaded.
    imported=scripts/'r5_authenticated_unpack.py'
    ensure(not imported.exists(),'BOOTSTRAP_COLLISION')
    imported.write_bytes(raw)
    import importlib.util
    spec=importlib.util.spec_from_file_location('authenticated_r5',imported)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    nested=workspace/'nested_r5_r4_r2'
    evidence=module.perform(r5zip,nested)
    ensure(evidence.get('status')=='R5_IMMUTABLE_NESTED_SOURCE_AND_GITHUB_EVIDENCE_PASS',
           'R5_R4_R2_EVIDENCE_NOT_GREEN')
    ensure((workspace/'evidence/D726_ORIGINAL_REFERENCE_SELINUX.c').read_bytes()==
           (nested/'D726_ORIGINAL_REFERENCE_SELINUX.c').read_bytes() and
           (workspace/'evidence/R4_COMPILED_REFERENCE_SELINUX.c').read_bytes()==
           (nested/'R4_COMPILED_REFERENCE_SELINUX.c').read_bytes(),
           'EFFECTIVE_R4_OR_D726_EVIDENCE_MISMATCH')
    # Only now, after full verification, load the stage helper.
    for d in ('r5','r4','r2'):
        path=str(nested/d/'common/scripts')
        if path not in sys.path:sys.path.append(path)
    from veux_sync_susfs_r1_build import compose_from_d726
    out,_=compose_from_d726(blobs['evidence/D726_ORIGINAL_REFERENCE_SELINUX.c'])
    ensure(out==blobs['common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c'],
           'UPSTREAM_F308_D726_R5_COMPOSITION_NOT_BIT_IDENTICAL')
    result={'status':'R5S1_EXACT_F308_AND_D726_PLUS_R5_NESTED_ARCHIVES_PASS',
        'r5_sha256':R5_SHA,'verified_r5_full_kernel_audit_sha256':R5_AUDIT_SHA,'main_sha256':sha(main.read_bytes()),
        'candidate_sha256':FINAL_SHA,'nested_green_evidence':evidence,
        'no_kernel_build':True,'flash_release':False,'no_main_write':True}
    (workspace/'ZIP_VALIDATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R5S1_SOURCE_ARCHIVES_AND_F308_D726_R5=PASS; NO_KERNEL_BUILD',flush=True)
    return result

def main()->int:
    p=argparse.ArgumentParser()
    p.add_argument('--main',type=Path,required=True)
    p.add_argument('--work',type=Path,required=True)
    a=p.parse_args()
    try:safe_unpack(a.main,a.work)
    except Exception as exc:
        print('R5S1_ARCHIVE_UNSAFE:'+type(exc).__name__+':'+str(exc),file=sys.stderr)
        return 1
    return 0
if __name__=='__main__':raise SystemExit(main())
