#!/usr/bin/env python3
"""Exact authenticated reconstruction of official BakaSU sync-susfs f308
*plus* the newer d726 SELinux context_add_hash fix on Linux 5.4.

This is a source-only transformation, not an official merged upstream commit.
No guard is bypassed; the BakaSU fallback remains responsible for the
unsupported <5.10 manual hooks. The upstream unmodified f308 is independently
reconstructed byte-for-byte before accepting the candidate.
"""
from __future__ import annotations
import hashlib
from pathlib import Path

OFFICIAL_D726_SHA = 'e4299d4db52b3e761413928d733076dc497104cee0cd5ab27e165364cd773c5c'
OFFICIAL_D726_BLOB = '9864c9cf5171311769564b682a42cc7eecc8a801'
OFFICIAL_SYNC_COMMIT = 'f308ed0936bdd31163cb53da3f42bc7a698f5512'
OFFICIAL_SYNC_BLOB = '756fd5ef99db1c870ad737b3076c0e5510b09e68'
SYNC_PLUS_D726_SHA = '2a90c407c2c1e8ab46f8cb0acf4262f64ff61a006d4a84491a7e7d898b7cdd28'
SYNC_PLUS_D726_BLOB = '63ac06fe82ef69c1a97e74da7a1598f67ac70150'
D726_FIX_POST = '    if (!rc) {\n#ifdef KSU_COMPAT_HAS_CONTEXT_ADD_HASH\n        rc = context_add_hash(policydb, &context);\n#endif\n        if (!rc)\n            rc = sidtab_context_to_sid(sidtab, &context, sid);\n        // rc should not be frozen\n        context_destroy(&context);\n        // removed: if (rc == -ESTALE)\n        if (!orig_rc) {\n#ifdef KSU_COMPAT_HAS_CONTEXT_ADD_HASH\n            orig_rc = context_add_hash(orig_policydb, &orig_context);\n#endif\n            if (!orig_rc) {\n                // sync to global sidtab\n                orig_rc = sidtab_context_to_sid(orig_sidtab, &orig_context, &orig_sid);\n                if (orig_sid_p)\n                    *orig_sid_p = orig_sid;\n            }\n            context_destroy(&orig_context);\n'
D726_FIX_PRE = '    if (!rc) {\n        rc = sidtab_context_to_sid(sidtab, &context, sid);\n        // rc should not be frozen\n        context_destroy(&context);\n        // removed: if (rc == -ESTALE)\n        if (!orig_rc) {\n            // sync to global sidtab\n            orig_rc = sidtab_context_to_sid(orig_sidtab, &orig_context, &orig_sid);\n            if (orig_sid_p)\n                *orig_sid_p = orig_sid;\n            context_destroy(&orig_context);\n'

class ScopeError(RuntimeError):
    pass

def require(test: bool, why: str):
    if not test: raise ScopeError(why)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def reconstruct(d726: bytes) -> tuple[bytes, bytes]:
    require(sha(d726)==OFFICIAL_D726_SHA and git_blob(d726)==OFFICIAL_D726_BLOB,
            'OFFICIAL_D726_PREIMAGE_NOT_AUTHENTIC')
    t = d726.decode('utf-8')
    def sub(old: str, new: str):
        nonlocal t
        require(t.count(old)==1,'SYNC_UPSTREAM_HUNK_NOT_EXACTLY_ONCE:'+old[:65])
        t=t.replace(old,new,1)
    require(t.count(D726_FIX_POST)==1,'D726_SECURITY_FIX_MISSING')
    sub('#ifdef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n#define __maybe_static\n#else\n',
        '#ifdef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n#define __maybe_static\n\n#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)\n#error BakaSU does NOT support susfs selinux_hide feature in nongki, Please remove the susfs selinux_hide related code in selinuxfs.c / services.c, selinux_hide still working, but it will handle in BakaSU instead of susfs.\n#endif\n#else\n')
    sub('static write_op_fn *selinux_write_op;\n\n#endif // #ifndef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n',
        'static write_op_fn *selinux_write_op;\n')
    sub('// remove static in susfs\n#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0) || defined(KSU_COMPAT_HAS_SELINUX_POLICY_STRUCT)\n__maybe_static int security_context_to_sid_with_policy(struct selinux_policy *policy, const char *scontext,\n                                                       u32 scontext_len, u32 *sid, u32 def_sid, gfp_t gfp_flags,\n                                                       u32 *orig_sid_p, int *orig_rc_p);\n\n__maybe_static int security_sid_to_context_with_policy(struct selinux_policy *policy, u32 sid, char **scontext,\n                                                       u32 *scontext_len)\n',
        '#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0) || defined(KSU_COMPAT_HAS_SELINUX_POLICY_STRUCT)\nstatic int security_context_to_sid_with_policy(struct selinux_policy *policy, const char *scontext, u32 scontext_len,\n                                               u32 *sid, u32 def_sid, gfp_t gfp_flags, u32 *orig_sid_p, int *orig_rc_p);\n\nstatic int security_sid_to_context_with_policy(struct selinux_policy *policy, u32 sid, char **scontext,\n                                               u32 *scontext_len)\n')
    sub('__maybe_static void security_compute_av_user_with_policy(struct selinux_policy *policy, u32 ssid, u32 tsid, u16 tclass,\n                                                         struct av_decision *avd)',
        'static void security_compute_av_user_with_policy(struct selinux_policy *policy, u32 ssid, u32 tsid, u16 tclass,\n                                                 struct av_decision *avd)')
    sub('#endif\n\n#ifndef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n\nstatic write_op_fn *context_write, *access_write;',
        '#endif\n\nstatic write_op_fn *context_write, *access_write;')
    sub('extern void ksu_register_setprocattr_lsm_hook();\n#else\n#define ksu_selinux_hide_unhook()',
        'extern void ksu_register_setprocattr_lsm_hook();\n#else\n// susfs selinux_hide\n#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)\nstruct selinux_state fake_state;\n#endif\n\n#define ksu_selinux_hide_unhook()')
    sub('#ifndef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n    hook_selinux_status_open();\n#endif\n\n    // clang-format off',
        '#ifdef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n\n#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 6, 0)\n    fake_state.initialized = true;\n    fake_state.policy = backup_sepolicy;\n#endif\n\n#else\n    hook_selinux_status_open();\n\n    // clang-format off')
    sub('    // clang-format on\n\n#ifndef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n#ifdef CONFIG_KALLSYMS_ALL',
        '    // clang-format on\n\n#ifdef CONFIG_KALLSYMS_ALL')
    sub('    mutex_unlock(ksu_selinux_status_lock);\n}\n\n/*\n * Caveat:  Mutates scontext.\n */',
        '    mutex_unlock(ksu_selinux_status_lock);\n}\n\n#ifndef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE\n/*\n * Caveat:  Mutates scontext.\n */')
    sub('// remove static in susfs\n#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0) || defined(KSU_COMPAT_HAS_SELINUX_POLICY_STRUCT)\n__maybe_static int security_context_to_sid_with_policy(struct selinux_policy *policy, const char *scontext,\n                                                       u32 scontext_len, u32 *sid, u32 def_sid, gfp_t gfp_flags,\n                                                       u32 *orig_sid_p, int *orig_rc_p)\n',
        '#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 10, 0) || defined(KSU_COMPAT_HAS_SELINUX_POLICY_STRUCT)\nstatic int security_context_to_sid_with_policy(struct selinux_policy *policy, const char *scontext, u32 scontext_len,\n                                               u32 *sid, u32 def_sid, gfp_t gfp_flags, u32 *orig_sid_p, int *orig_rc_p)\n')

    appended = t + '#endif\n'
    out = appended.encode('utf-8')
    require(sha(out)==SYNC_PLUS_D726_SHA and git_blob(out)==SYNC_PLUS_D726_BLOB,
            'OFFICIAL_SYNC_BACKPORT_POSTIMAGE_MISMATCH')
    raw = appended.replace(D726_FIX_POST,D726_FIX_PRE,1).encode('utf-8')
    require(len(raw)==65165 and git_blob(raw)==OFFICIAL_SYNC_BLOB,
            'SYNC_F308_OFFICIAL_COMMIT_BLOB_NOT_RECONSTRUCTED')
    return out, raw
