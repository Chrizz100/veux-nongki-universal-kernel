"""Read-only positive/negative regression tests for official f308 + d726 + R5.

No kernel, no build, no repository writes. Fixtures use the archived green R4
source from GitHub Actions run 39008125408 and the pinned d726 raw source.
"""
import ast
import hashlib
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import veux_r5_susfs_selinux_hook_port as r5
import veux_r6_susfs_selinux54_port_r3 as r3
import veux_r6_sync_f308_reconstruct as rec
import veux_sync_susfs_r1_build as mod

HERE=Path(__file__).resolve().parents[1]
D726=HERE/'evidence/D726_ORIGINAL_REFERENCE_SELINUX.c'
R4=HERE/'evidence/R4_COMPILED_REFERENCE_SELINUX.c'
GOLD=HERE/'common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c'

class SyncCases(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source=D726.read_bytes()
        cls.r4=R4.read_bytes()
        cls.gold=GOLD.read_bytes()
    def test_01_official_d726_git_sha_exact(self):
        self.assertEqual(rec.sha(self.source),rec.OFFICIAL_D726_SHA)
        self.assertEqual(rec.git_blob(self.source),rec.OFFICIAL_D726_BLOB)
    def test_02_actual_official_f308_git_blob(self):
        combo,official=rec.reconstruct(self.source)
        self.assertEqual(rec.git_blob(official),'756fd5ef99db1c870ad737b3076c0e5510b09e68')
        self.assertEqual(len(official),65165)
    def test_03_newer_d726_security_fix_not_lost(self):
        combo,_=rec.reconstruct(self.source)
        self.assertEqual(combo.count(b'context_add_hash(policydb, &context)'),1)
        self.assertEqual(combo.count(b'context_add_hash(orig_policydb, &orig_context)'),1)
    def test_04_official_sync_plus_d726_source_hash(self):
        a,_=rec.reconstruct(self.source)
        self.assertEqual(rec.sha(a),rec.SYNC_PLUS_D726_SHA)
        self.assertEqual(rec.git_blob(a),rec.SYNC_PLUS_D726_BLOB)
    def test_05_pinned_r4_reference_matches_ci(self):
        self.assertEqual(rec.sha(self.r4),r5.R4_SHA)
    def test_06_existing_r3_r5_source_reconstructed(self):
        s,_=r5.guard_r4_text(self.r4)
        self.assertEqual(rec.sha(s),r5.TARGET_SHA)
    def test_07_candidate_exact_hash(self):
        result,_=mod.compose_from_d726(self.source)
        self.assertEqual(rec.sha(result),mod.EXPECTED_FINAL_SHA)
        self.assertEqual(rec.git_blob(result),mod.EXPECTED_FINAL_BLOB)
        self.assertEqual(result,self.gold)
    def test_08_security_hash_fix_present_after_integration(self):
        self.assertEqual(self.gold.count(b'context_add_hash(policydb, &context)'),1)
        self.assertEqual(self.gold.count(b'context_add_hash(orig_policydb, &orig_context)'),1)
    def test_09_r3_status_guard_retained(self):
        self.assertEqual(self.gold.count(r3.AFTER.encode()),1)
        self.assertEqual(self.gold.count(r3.BEFORE.encode()),0)
    def test_10_r5_three_fallback_guards_retained(self):
        self.assertEqual(self.gold.count(r5.NEW.encode()),3)
        self.assertEqual(self.gold.count(r5.OLD.encode()),0)
    def test_11_sync_susfs_explicit_kernel54_boundary_retained(self):
        self.assertIn(b'#error BakaSU does NOT support susfs selinux_hide feature in nongki',self.gold)
        self.assertIn(b'#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)',self.gold)
    def test_12_security_permissions_not_silently_bypassed(self):
        for x in (b'PROCESS__DYNTRANSITION',b'PROCESS__PTRACE',b'PROCESS__SETCURRENT',
                  b'ksu_security_context_to_sid',b'commit_creds(new)',b'fake_status'):
            self.assertEqual(self.source.count(x),self.gold.count(x),x.decode())
    def test_13_fail_changed_d726_source(self):
        changed=self.source.replace(b'PROCESS__DYNTRANSITION',b'PROCESS__DYN_TRANSITION',1)
        with self.assertRaises(rec.ScopeError): rec.reconstruct(changed)
    def test_14_fail_deleted_d726_fix(self):
        mutated=self.source.replace(b'context_add_hash(policydb, &context)',b'context_add_hesh(policydb, &context)',1)
        with self.assertRaises(rec.ScopeError): rec.reconstruct(mutated)
    def test_15_fail_double_sync_pass(self):
        synced,_=rec.reconstruct(self.source)
        with self.assertRaises(rec.ScopeError):rec.reconstruct(synced)
    def test_16_scope_only_selinux_feature(self):
        self.assertEqual(mod.REL,'KernelSU/kernel/feature/selinux_hide.c')
        self.assertEqual(mod.KERNEL,'5.4.274')
    def test_17_original_r5_version_remains_no_false_bump(self):
        self.assertEqual(mod.BAKASU_PIN,'5b76b884c75f729a220bb317aa4a4fc78f0e0e9c')
        self.assertEqual(mod.NOMOUNT_PIN,'7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3')
        self.assertEqual(mod.SUSFS_PIN,'5326e21a7eb232f9e21debdd5164e99bee3d1e2f')
    def test_18_golden_changed_by_byte_fails(self):
        self.assertNotEqual(rec.sha(self.gold[:-1]),mod.EXPECTED_FINAL_SHA)
        self.assertNotEqual(rec.sha(self.gold.replace(b'context_add_hash',b'context_remove_hash',1)),mod.EXPECTED_FINAL_SHA)
    def test_19_worker_injection_valid_compilable_ast(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'worker.py'
            p.write_text('from pathlib import Path\n'+
             "def worker(args):\n        result['bakasu_official_r6'] = bakasu_official_r6\n"+
             mod.r2.OVERLAY_ANCHOR+mod.r2.COMPILE_ANCHOR)
            proof=mod.inject_worker(p,GOLD)
            self.assertEqual(proof['status'],'SYNC_ONLY_DISPOSABLE_WORKER_INJECTED')
            ast.parse(p.read_text())
            self.assertEqual(p.read_text().count('sync_staged = stage('),1)
            self.assertEqual(p.read_text().count('sync_compiled = verify_compiled('),1)
    def test_20_reject_double_worker_injection(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'worker.py'
            p.write_text('from pathlib import Path\n'+
             "def worker(args):\n        result['bakasu_official_r6'] = bakasu_official_r6\n"+
             mod.r2.OVERLAY_ANCHOR+mod.r2.COMPILE_ANCHOR)
            mod.inject_worker(p,GOLD)
            with self.assertRaises(mod.SyncPortError):mod.inject_worker(p,GOLD)
    def test_21_reject_missing_worker_anchor(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'worker.py';p.write_text('print(1)\n')
            with self.assertRaises(mod.SyncPortError):mod.inject_worker(p,GOLD)
    def test_22_reject_duplicate_worker_anchor(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'worker.py'
            p.write_text('from pathlib import Path\n'+"def worker(args):\n        result['bakasu_official_r6'] = bakasu_official_r6\n"+
                         mod.r2.OVERLAY_ANCHOR*2+mod.r2.COMPILE_ANCHOR)
            with self.assertRaises(mod.SyncPortError):mod.inject_worker(p,GOLD)
    def test_23_reject_unsafe_symlink_worker(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)/'original.py';target.write_text('print(1)')
            link=Path(td)/'link.py';link.symlink_to(target)
            with self.assertRaises(mod.SyncPortError):mod.inject_worker(link,GOLD)
    def test_24_negative_component_pins(self):
        self.assertNotEqual(mod.BAKASU_PIN,rec.OFFICIAL_SYNC_COMMIT)
    def test_25_sync_vs_main_not_full_latest_32bit(self):
        report=mod.compose_from_d726(self.source)[1]
        self.assertTrue(report['new_bakasu_32bit_syscall_522_not_included'])
        self.assertTrue(report['upstream_f308_lacks_d726_security_fix'])
    def test_26_new_port_no_upstream_zip_security_guard_bypass(self):
        s=self.gold.decode()
        self.assertIn('BakaSU does NOT support susfs selinux_hide feature in nongki',s)
        self.assertNotIn('$(error Please wait susfs update.)',s)
    def test_27_r5_source_only_status_not_flash(self):
        proof=mod.compose_from_d726(self.source)[1]
        self.assertFalse(proof['device_pass'])
        self.assertFalse(proof['flash_release'])
    def test_28_refuse_missing_work_root(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            with self.assertRaises(mod.SyncPortError):mod.stage(root,root,root,GOLD)
    def test_29_reconstruct_deterministic(self):
        x,y=mod.compose_from_d726(self.source),mod.compose_from_d726(self.source)
        self.assertEqual(x,y)
    def test_30_patch_scope_unified_only_feature_file(self):
        m=mod.compose_from_d726(self.source)[1]
        d=m['upstream_diff']
        self.assertIn('--- a/'+mod.REL,d)
        self.assertIn('+++ b/'+mod.REL,d)
        self.assertNotIn('security/selinux/hooks.c',d)
        self.assertNotIn('security/selinux/selinuxfs.c',d)

    def _stage_fixture(self,td):
        base=Path(td)
        work=base/'builds'/mod.KERNEL
        src=work/'source'/'kernel'
        src.mkdir(parents=True)
        x=src/mod.REL;x.parent.mkdir(parents=True);x.write_bytes(self.source)
        (work/'BAKASU-OFFICIAL-D726-R6.json').write_text(__import__('json').dumps({
            'source_matches_official_bakasu_d726_byte_for_byte':True,
            'after_sha256':rec.OFFICIAL_D726_SHA}))
        b=base/'bundle';b.mkdir()
        (b/'targets.json').write_text(__import__('json').dumps({'components':{
             'resukisu':{'commit':mod.BAKASU_PIN},
             'susfs':{'commit':mod.SUSFS_PIN},
             'nomount':{'commit':mod.NOMOUNT_PIN}}}))
        return work,src,b,x
    def test_31_stage_scoped_positive(self):
        with tempfile.TemporaryDirectory() as td:
            work,src,b,x=self._stage_fixture(td)
            with patch.object(mod.r3,'verify_host',return_value={'trusted_host':True}):
                proof=mod.stage(src,b,work,GOLD)
            self.assertTrue(proof['d726_security_fix_retained'])
            self.assertEqual(x.read_bytes(),self.gold)
            self.assertEqual(proof['candidate_sha256'],mod.EXPECTED_FINAL_SHA)
            self.assertTrue((work.parent.parent/'report/BAKASU_SYNC_F308_D726_R5.patch').is_file())
    def test_32_stage_refuses_wrong_nomount_pin(self):
        with tempfile.TemporaryDirectory() as td:
            work,src,b,x=self._stage_fixture(td)
            q=__import__('json').loads((b/'targets.json').read_text())
            q['components']['nomount']['commit']='0'*40
            (b/'targets.json').write_text(__import__('json').dumps(q))
            with patch.object(mod.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(mod.SyncPortError,'COMPONENTS_CHANGED'):
                    mod.stage(src,b,work,GOLD)
            self.assertEqual(x.read_bytes(),self.source)
    def _compile_fixture(self,td):
        work,src,b,x=self._stage_fixture(td)
        x.write_bytes(self.gold)
        d=work/'build/drivers/kernelsu/feature';d.mkdir(parents=True)
        (d/'selinux_hide.o').write_bytes(b'ELF-synthetic-not-a-kernel')
        (d/'.selinux_hide.o.cmd').write_text('CC drivers/kernelsu/feature/selinux_hide.o -fstack-protector-strong -flto=thin')
        q=work/'config-reports';q.mkdir()
        (q/'actual-build.config').write_text('\n'.join((
             'CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
             'CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y',
             'CONFIG_STACKPROTECTOR_STRONG=y'))+'\n')
        (work/'compile.log').write_text(' CC drivers/kernelsu/feature/selinux_hide.o\n')
        return work,src,d
    def test_33_compiled_source_proof_synthetic_fixture(self):
        with tempfile.TemporaryDirectory() as td:
            work,src,d=self._compile_fixture(td)
            with patch.object(mod.r3,'verify_host',return_value={}):
                proof=mod.verify_compiled(src,work,
                     {'candidate_sha256':mod.EXPECTED_FINAL_SHA,
                     'd726_security_fix_retained':True},
                     {'kernel':mod.KERNEL})
            self.assertTrue(proof['retained_d726_context_hash_safety'])
            self.assertFalse(proof['flash_release'])
    def test_34_compiled_source_proof_rejects_stack_optout(self):
        with tempfile.TemporaryDirectory() as td:
            work,src,d=self._compile_fixture(td)
            f=d/'.selinux_hide.o.cmd'
            f.write_text(f.read_text()+' -fno-stack-protector')
            with patch.object(mod.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(mod.SyncPortError,'SECURITY_FLAGS'):
                    mod.verify_compiled(src,work,
                     {'candidate_sha256':mod.EXPECTED_FINAL_SHA,
                     'd726_security_fix_retained':True},
                     {'kernel':mod.KERNEL})
    def test_35_compiled_source_proof_rejects_changed_effective_source(self):
        with tempfile.TemporaryDirectory() as td:
            work,src,d=self._compile_fixture(td)
            x=src/mod.REL;x.write_bytes(self.gold+b'CHANGED')
            with patch.object(mod.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(mod.SyncPortError,'SOURCE_CHANGED'):
                    mod.verify_compiled(src,work,
                     {'candidate_sha256':mod.EXPECTED_FINAL_SHA,
                     'd726_security_fix_retained':True},
                     {'kernel':mod.KERNEL})

if __name__=='__main__': unittest.main()
