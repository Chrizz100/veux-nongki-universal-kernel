# VEUX R5S1 – BakaSU sync-susfs offizieller Vergleich und integrierter Quellkandidat

**Gerät:** VEUX, Kernel 5.4.274, BakaSU 35222 als Build-Pin, SUSFS 2.3.0, NoMount 2.1.1.

**Offizielle BakaSU-Quelle:** [BakaSU sync-susfs @ f308ed09](https://github.com/Baka-SU/BakaSU/tree/f308ed0936bdd31163cb53da3f42bc7a698f5512), Git-Blob `kernel/feature/selinux_hide.c = 756fd5ef99db1c870ad737b3076c0e5510b09e68`. Der konkrete Quelltext wird in R5S1 vollständig aus GitHub-geprüften d726-Dateien rekonstruiert und hashverifiziert.

**Divergierende Sicherheitsreparatur:** `d7260ca1` aus BakaSU main fügt zwei `context_add_hash`-Prüfungen vor `sidtab_context_to_sid` ein. Der sync-susfs-Zweig enthält diese Reparatur nicht. R5S1 erhält sie ausdrücklich und prüft beide Vorkommen. Dadurch ist R5S1 ein geprüfter *Kombinationsstand*, kein offizielles einzelnes Upstream-Commit.

**R3/R5-Fixes:** Status-Open und drei SELinux-Hide-Wrapper verwenden `ksu_selinux_hide_running` statt allein den Aktivierungswunsch. Exakt vier Kontrollen geprüft und bei der Integration erhalten.

**Kritische Linux-5.4-Grenze:** Der offizielle Zweig `sync-susfs` fordert bei `KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE` für Linux unter 5.10 einen Compile-Fehler. R5S1 belässt diesen Schutz absichtlich. Der aktuell geprüfte 5.4-Host hat kein natives SUSFS-Manual-Hook-Symbol in `security/selinux/hooks.c` und verwendet stattdessen die BakaSU-Hooks. Vor jedem Build werden die Hostdateien erneut exakt geprüft. Bei einem künftigen unautorisierten nativen Hook muss der Build rot werden, nicht trotzdem durchlaufen.

**BakaSU-Versionsnummer:** Noch 35222, weil die komplette KernelSU-Upstream-Commitstruktur **nicht** ausgetauscht wurde. Kein künstliches Erhöhen; der offizielle Quellcode-Commit wird im Audit separat dokumentiert.

**Unverändert:** SUSFS-2.3.0-Kerndateien, originale 5.4-SELinux-Hostdateien, NoMount-v2.1.1-Quellcode und Stackschutz, R6-Gerätefixes, ursprüngliche Repo-Dateien.

**Offene echte Updates:** Das spätere BakaSU-main-Commit `522081c5` für 32-Bit-Userspace auf ARM64 ist im sync-susfs-Zweig nicht vorhanden. Ebenso wurden die vollumfänglichen SUSFS-5.10-Integrationshunks nicht auf 5.4 portiert. Eine Behauptung „vollständiger Upstream Green Pass“ wäre damit falsch.

**Tests:** Der neue GitHub-Lauf muss den source-only-Rekonstruktionsbeweis, den Kernel-Compile, die CFI/ThinLTO/Stack-Schutzgates, bytegleichen `Module.symvers` und `.config` gegen den bewährten R4, Boot-/AK3-Prüfungen und Artefakt-Upload abschließen. Bis dahin: **kein Build PASS, keine Flashfreigabe**.

**Neuer kompletter R5-Buildnachweis:** Run `39104446746` ist `SUCCESS`; der R5-Quellhash ist `8f17c358...`. Originale R5-`Module.symvers` und `.config` stimmen bytegenau mit dem R4-Audit überein. Der nächste R5S1-Build wird gegen beide Referenzen geprüft.
