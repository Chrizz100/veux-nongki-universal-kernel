VEUX 5.4.274 – R5S1 offizieller BakaSU sync-susfs f308 Port + d726 + R5
==========================================================================
Keine Flashfreigabe, kein Gerätetest. Der bisher laufende R5 GitHub-Lauf wird
NICHT abgebrochen und durch diesen experimentellen Kandidaten NICHT verändert.

Ablauf:
  A) VEUX_SYNC_SUSFS_R5S1_MAIN.zip ins Repository-Hauptverzeichnis hochladen.
  B) VEUX_SYNC_SUSFS_R5S1_EXPERIMENTAL_BUILD.yml separat nach .github/workflows/.
  C) workflow_dispatch, enable_build=true. Nur die benannte YAML starten.
  D) Kompletten GitHub-Lauf einschließlich Audit-Artefakt prüfen.

R5S1 integriert nur die OFFIZIELLE sync-susfs-BakaSU-SELinux-Hookstruktur
von f308ed09 (nachgewiesener Git Blob 756fd5ef...) in den bewährten Kernel,
unter Beibehaltung der d726-Sicherheitskorrektur, aller R3/R5-Schutzpfade,
NoMount 2.1.1, SUSFS Kern 2.3.0 sowie aller R6-Gerätereparaturen.

WICHTIG: f308 selbst enthält d726 NICHT. Unser Kandidat ist deshalb
absichtlich NICHT bytegleich mit f308. Auch nicht enthalten:
- BakaSU main-32bit-Hook-Update 522081c5 (mehrere Syscall-Dateien)
- volle GKI 5.10 SUSFS-SELinux-Hostpatches (auf 5.4 nicht direkt portierbar)
- künstliche KSU-Versionsanhebung.

Die neue 5.4-Quellpatch-Matrix ist source-only authentifiziert. Für einen
faktischen grünen R5S1-Kernel-Build muss der neue GitHub-Run alle Gates
bestehen. Keinen FLASH ohne echte Gerätefreigabe.

Zusaetzlicher Originalnachweis: R5 GitHub Run 39104446746 ist ebenfalls
vollstaendig SUCCESS, die verifizierte Original-Audit-ZIP ist beigepackt.
