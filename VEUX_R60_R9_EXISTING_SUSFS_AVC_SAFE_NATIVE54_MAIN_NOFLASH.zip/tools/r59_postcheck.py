#!/usr/bin/env python3
"""R59/R60: verify real native54 objects, source SHA, symbols and OEM research.

A pass here proves kernel compilation and the named linked symbols only.
The separate R60 final release guard must still block unresolved vendor ABI.
"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys
import re

REQUIRED = ('my_setprocattr','ksu_selinux_hide_running','fake_status',
            'susfs_ksu_sid','susfs_priv_app_sid',
            'susfs_is_avc_log_spoofing_enabled','susfs_add_sus_type',
            'susfs_spoof_avd_allowed_rcu','nomount_init')
HOST_FILES = ('security/selinux/avc.c','security/selinux/hooks.c',
              'security/selinux/ss/services.c','security/selinux/selinuxfs.c')

class GateError(ValueError):pass

def require(cond,why):
    if not cond:raise GateError(why)

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()

def extract_defined_symbols(nm_output):
    result=set()
    for line in nm_output.splitlines():
        fields=line.split()
        if len(fields)>=2 and len(fields[-2])==1 and fields[-2].isalpha():
            result.add(fields[-1])
    return result

def run(a):
    report=a.report;source=a.source;obj=a.objects
    host=json.loads((report/'R59_HOST_STATUS.json').read_text())
    kernel=json.loads((report/'R58_COMPILE_STATUS.json').read_text())
    vendor=json.loads(a.vendor_report.read_text())
    require(host.get('status')=='FOUR_NATIVE54_SELINUX_HOST_FILES_STAGED_FOR_REAL_COMPILER','NATIVE_HOST_STAGE_MISSING')
    entries=host.get('updated_host_files',{})
    require(set(entries)==set(HOST_FILES),'HOST_FILE_SET_CHANGED')
    for rel in HOST_FILES:
        file=source/rel;proof=entries[rel]
        require(file.is_file() and not file.is_symlink(),'HOST_SOURCE_MISSING_OR_SYMLINK:'+rel)
        require(digest(file)==proof.get('postimage_sha256'),'HOST_POSTIMAGE_SHA_CHANGED:'+rel)
        object_file=obj/rel.replace('.c','.o')
        require(object_file.is_file() and object_file.stat().st_size>100,'HOST_OBJECT_NOT_BUILT:'+rel)
    require(kernel.get('compile_link_proof') is True and kernel.get('RMNET_132_CRC_proven') is True,'R58_COMPILE_OR_RMNET_NOT_GREEN')
    require(kernel.get('native54_sus_type_hash_collision_guard') is True,
            'SUSFS_TYPE_HASH_COLLISION_FIX_NOT_COMPILED')
    require(kernel.get('RMNET_132_matched')==132 and kernel.get('R13_original_image_reused') is False,'R13_IMAGE_REUSE_OR_RMNET_MISMATCH')
    config_gates=kernel.get('gates',{})
    for token in ('CONFIG_SCHED_CASS','CONFIG_MODVERSIONS','CONFIG_MODULES','CONFIG_KSU','CONFIG_KSU_SUSFS','CONFIG_NOMOUNT','WALT_OFF'):
        require(config_gates.get(token) is True,'REQUIRED_KCONFIG_NOT_PROVEN:'+token)
    require(a.nm.is_file() and (obj/'vmlinux').is_file(),'NM_OR_VMLINUX_MISSING')
    output=subprocess.check_output([str(a.nm),'--defined-only',str(obj/'vmlinux')],text=True)
    actual=extract_defined_symbols(output)
    got=[sym for sym in REQUIRED if any(re.fullmatch(re.escape(sym)+r'(?:\.llvm\.[0-9]+)?',x) for x in actual)]
    missing=sorted(set(REQUIRED)-set(got))
    totals=vendor.get('candidate',{}).get('totals',{})
    checked=sum(int(totals.get(k,0)) for k in ('MATCH','CRC_MISMATCH','NOT_EXPORTED'))
    require(checked==14648 and vendor.get('original_vendor_file_count')==218,'OEM_ABI_INPUT_COUNT_CHANGED')
    groups=vendor['candidate']['groups']
    require(set(groups)=={'QGKI','GKI'},'OEM_COHORT_GROUPS_CHANGED')
    require(sum(groups['QGKI'].values())==3148 and sum(groups['GKI'].values())==11500,'OEM_COHORT_IMPORT_COUNTS_CHANGED')
    full_matches=int(totals.get('MATCH',0))==14648
    result={
      'schema':'VEUX_R59_FULL_COMPONENTS_BUILD_EVIDENCE_V1',
      'source_hooks_native54_host_compiled':True,
      'linked_symbols_found':got,'linked_symbols_missing':missing,
      'rmnet_132_all_match':True,'vendor_module_files':218,
      'vendor_imports':14648,'vendor_matches':int(totals.get('MATCH',0)),
      'vendor_crc_mismatches':int(totals.get('CRC_MISMATCH',0)),
      'vendor_not_exported':int(totals.get('NOT_EXPORTED',0)),
      'full_vendor_crc_match':full_matches,
      'full_source_compile_gate':len(missing)==0,
      'source_and_compiler_pass':len(missing)==0,
      'oem_abi_green':full_matches and not missing,
      'status':'KERNEL_AND_SYMBOLS_COMPILED__OEM_ABI_REVIEW_REQUIRED' if not missing else 'LINKED_SYMBOLS_MISSING',
      'active_oem_modules_verified':False,
      'device_test':False,'ak3_static_boot_proven':False,'flash_allowed':False}
    out=report/'R59_FULL_INTEGRATION_EVIDENCE.json'
    require(not out.exists() and not out.is_symlink(),'R59_REPORT_ALREADY_EXISTS')
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R59_COMPILER_SYMBOLS='+('PASS' if not missing else 'BLOCKED:'+','.join(missing)))
    print('R59_HISTORICAL_VENDOR_ABI='+('ALL_MATCH' if full_matches else 'MISMATCH__VERIFY_ACTIVE_MODULE_SET'))
    print('R59_FLASH_ALLOWED=NO')
    return 0 if not missing else 3

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--objects',type=Path,required=True)
    p.add_argument('--report',type=Path,required=True)
    p.add_argument('--nm',type=Path,required=True)
    p.add_argument('--vendor-report',type=Path,required=True)
    a=p.parse_args(argv)
    try:return run(a)
    except (GateError,KeyError,ValueError,OSError,subprocess.CalledProcessError) as e:
        print('R59_POSTCHECK_BLOCKED='+str(e),file=sys.stderr)
        return 3

if __name__=='__main__':raise SystemExit(main())
