#!/usr/bin/env python3
"""Fail-closed olddefconfig regression guard for the real R13->BakaSU-35259 build.

Never accept changes to existing R13 kernel configuration settings. A newer
BakaSU Kconfig can introduce only explicitly allowlisted, *disabled* new
options. Every change is recorded; this script doesn't modify config files.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import sys

# Read against pinned BakaSU 516d3e87 kernel/Kconfig. No wildcard KSU_* pass.
ADDED_ALLOWED_OFF = frozenset({
    'CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER',
    'CONFIG_KSU_MANUAL_HOOK_AUTO_SETUID_HOOK',
    'CONFIG_KSU_MANUAL_HOOK_AUTO_INITRC_HOOK',
    'CONFIG_KSU_MANUAL_HOOK_AUTO_INPUT_HOOK',
    'CONFIG_SCHED_WALT',  # absent in the genuine R13 .config; may newly appear as 'not set'
})
CRITICAL = {
    'CONFIG_SCHED_CASS': 'y',
    'CONFIG_MODULES': 'y',
    'CONFIG_MODVERSIONS': 'y',
    'CONFIG_KSU': 'y',
    'CONFIG_KSU_SUSFS': 'y',
    'CONFIG_NOMOUNT': 'y',
    'CONFIG_SECURITY_SELINUX': 'y',
}
ON = re.compile(r'^(CONFIG_[A-Za-z0-9_]+)=(.*)$')
OFF = re.compile(r'^# (CONFIG_[A-Za-z0-9_]+) is not set$')

class ConfigurationError(ValueError):
    pass

def parse_config(path: Path) -> dict[str, str]:
    result = {}
    for number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        on = ON.fullmatch(line)
        off = OFF.fullmatch(line)
        if on or off:
            key, value = (on.group(1), on.group(2)) if on else (off.group(1), 'n')
            if key in result:
                raise ConfigurationError(f'DUPLICATE_CONFIG:{key}:line_{number}')
            result[key] = value
        elif line.startswith('CONFIG_') or line.startswith('# CONFIG_'):
            raise ConfigurationError(f'UNRECOGNIZED_CONFIG_SYNTAX:line_{number}')
    if len(result) < 1000:
        raise ConfigurationError('KERNEL_CONFIG_INCOMPLETE')
    return result

def compare(before: dict[str,str], after: dict[str,str]) -> dict:
    for key, value in CRITICAL.items():
        if before.get(key) != value or after.get(key) != value:
            raise ConfigurationError(f'DEVICE_CRITICAL_CONFIG_NOT_PRESERVED:{key}')
    if before.get('CONFIG_SCHED_WALT','n')!='n' or after.get('CONFIG_SCHED_WALT','n')!='n':
        raise ConfigurationError('WALT_MUST_STAY_DISABLED')
    removed = sorted(set(before)-set(after))
    changed = {k:{'before':before[k],'after':after[k]} for k in before.keys() & after.keys() if before[k]!=after[k]}
    added = {k:after[k] for k in sorted(set(after)-set(before))}
    unacceptable = {k:v for k,v in added.items() if k not in ADDED_ALLOWED_OFF or v!='n'}
    if removed or changed or unacceptable:
        raise ConfigurationError('OLDDEFCONFIG_UNAUTHORIZED_DELTA:'+json.dumps({
            'removed':removed[:15], 'changed':dict(list(sorted(changed.items()))[:15]),
            'added_not_allowed':unacceptable},sort_keys=True))
    return {
        'schema':'VEUX_R60_STRICT_CONFIG_DELTA_V1',
        'result':'R13_ALL_EXISTING_FLAGS_PRESERVED',
        'baseline_settings':len(before), 'candidate_settings':len(after),
        'allowed_new_disabled_ksu_options':added,
        'device_critical_flags':CRITICAL,
        'all_baseline_options_unchanged':True,
        'warnings': [] if not added else ['Only allowlisted new disabled KSU options were introduced'],
        'kernel_compiled':False,'release_allowed':False,'flash_allowed':False,
    }

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--actual',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    try:
        if not a.out.parent.is_dir() or a.out.exists() or a.out.is_symlink():
            raise ConfigurationError('REPORT_TARGET_NOT_NEW')
        result=compare(parse_config(a.baseline),parse_config(a.actual))
        import hashlib
        result['baseline_sha256']=hashlib.sha256(a.baseline.read_bytes()).hexdigest()
        result['candidate_sha256']=hashlib.sha256(a.actual.read_bytes()).hexdigest()
        result['original_config_byte_equal']=result['baseline_sha256']==result['candidate_sha256']
        a.out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        print('R60_OLDDEFCONFIG_PROTECTED_DELTA=PASS; FLASH=NO')
        return 0
    except (OSError,ValueError,KeyError) as e:
        print('R60_CONFIG_BLOCKED='+str(e),file=sys.stderr)
        return 3

if __name__=='__main__':
    sys.exit(main())
