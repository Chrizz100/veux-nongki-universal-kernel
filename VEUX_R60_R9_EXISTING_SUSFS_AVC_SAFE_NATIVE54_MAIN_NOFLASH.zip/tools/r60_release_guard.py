#!/usr/bin/env python3
"""R60 final fail-closed OEM-ABI release gate, after a real source compiler pass.

Never substitutes test fixtures for OEM modules or authorizes a flash.
Writes a decision report before returning a failing status for unresolved ABI.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys

class InvalidReport(ValueError):pass

def require(ok, message):
    if not ok:raise InvalidReport(message)

def evaluate(compiler:dict, cohorts:dict):
    require(cohorts.get('schema')=='VEUX_R60_HISTORICAL_OEM_COHORT_CONFLICT_V1','COHORT_REPORT_SCHEMA_CHANGED')
    require(cohorts.get('conflicting_symbol_names')==836,'COHORT_CONFLICT_NOT_VERIFIED')
    require(cohorts.get('installed_module_files_by_cohort')=={'GKI':181,'QGKI':37},'HISTORICAL_MODULE_INVENTORY_CHANGED')
    require(cohorts.get('module_layout')=={'GKI':'0x1e5b7ab7','QGKI':'0x945d02f2'},'MODULE_LAYOUT_CONFLICT_MISSING')
    require(cohorts.get('active_cohort_at_device_boot_proven') is False,'UNPROVEN_ACTIVE_COHORT_FLAG_CHANGED')
    require(compiler.get('schema')=='VEUX_R59_FULL_COMPONENTS_BUILD_EVIDENCE_V1','R59_COMPILER_REPORT_SCHEMA_CHANGED')
    require(compiler.get('source_and_compiler_pass') is True and compiler.get('rmnet_132_all_match') is True,'KERNEL_COMPILE_LINK_OR_RMNET_MISSING')
    require(compiler.get('vendor_imports')==14648 and compiler.get('vendor_module_files')==218,'OEM_VENDOR_INVENTORY_NOT_COMPLETE')
    require(compiler.get('device_test') is False and compiler.get('flash_allowed') is False,'REPORT_FLASH_POLICY_CHANGED')
    expected_sum=compiler.get('vendor_matches',0)+compiler.get('vendor_crc_mismatches',0)+compiler.get('vendor_not_exported',0)
    require(expected_sum==14648,'OEM_ABI_COUNTS_NOT_COMPLETE')
    # Even a mathematically impossible total-match claim is rejected rather than
    # interpreted as device compatibility. Provenance must first isolate the
    # actual device-loaded, boot-critical vendor module cohort.
    require(compiler.get('oem_abi_green') is False and compiler.get('full_vendor_crc_match') is False,
            'CONTRADICTS_ORIGINAL_COHORT_CRC_CONFLICTS')
    return {'schema':'VEUX_R60_CASS_NATIVE54_ISSUE_GATE_V1',
            'source_kernel_compiler_verified':True,'rmnet_132_crcs_verified':True,
            'historical_vendor_files':218,'vendor_imports_checked':14648,
            'historical_conflicting_symbol_names':836,
            'candidate_matching_imports':compiler['vendor_matches'],
            'candidate_crc_mismatches':compiler['vendor_crc_mismatches'],
            'candidate_not_exported':compiler['vendor_not_exported'],
            'status':'BLOCKED_ACTIVE_OEM_MODULE_SET_AND_VENDOR_ABI_NOT_PROVEN',
            'note':'A successful full compiler run remains valid evidence, but is not an OEM or flash green pass.',
            'full_component_release_approved':False,'flash_allowed':False}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--compile-report',required=True,type=Path)
    p.add_argument('--cohorts',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    a=p.parse_args(argv)
    require(not a.out.exists() and not a.out.is_symlink() and a.out.parent.is_dir(),'OUTPUT_REPORT_ALREADY_EXISTS')
    x=evaluate(json.loads(a.compile_report.read_text()),json.loads(a.cohorts.read_text()))
    a.out.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print('R60_NATIVE54_CASS_COMPILER='+('PASS' if x['source_kernel_compiler_verified'] else 'BLOCKED'))
    print('R60_VENDOR_ABI='+x['status']+'; FLASH=NO')
    # Unresolved external OEM module compatibility must never be a green job.
    return 3

if __name__=='__main__':
    try:raise SystemExit(main())
    except (InvalidReport,KeyError,ValueError,OSError) as e:
        print('R60_RELEASE_GUARD_BLOCKED='+str(e),file=sys.stderr)
        raise SystemExit(3)
