#!/usr/bin/env python3
"""Read-only, SHA-pinned diagnosis of incompatible VEUX QGKI/GKI OEM cohorts.

This program does NOT choose a cohort, alter CRCs, or approve a kernel.
It records the mathematical incompatibility of the two historical vendor sets.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

IMPORT_SHA256 = 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394'
EXPECTED_IMPORTS = 14648
EXPECTED_MODULES = {'GKI': 181, 'QGKI': 37}
EXPECTED_CONFLICTING_NAMES = 836
MODULE_LAYOUT = {'GKI': '0x1e5b7ab7', 'QGKI': '0x945d02f2'}

class InvalidCohorts(ValueError):
    pass

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()

def read_rows(path: Path, verify_sha: bool=True):
    if verify_sha and digest(path)!=IMPORT_SHA256:
        raise InvalidCohorts('R21_IMPORT_CSV_HASH_CHANGED')
    with path.open(encoding='utf-8',newline='') as f:
        reader=csv.DictReader(f)
        if not {'path','symbol','module_crc'}.issubset(reader.fieldnames or []):
            raise InvalidCohorts('R21_IMPORT_HEADER_CHANGED')
        rows=[]
        for r in reader:
            path_name=r['path'];symbol=r['symbol'];crc=r['module_crc'].lower()
            if path_name.startswith('/vendor/lib/modules/5.4-gki/'):
                cohort='GKI'
            elif path_name.startswith('/vendor/lib/modules/') and path_name.count('/')==4:
                cohort='QGKI'
            else:raise InvalidCohorts('UNKNOWN_COHORT_PATH:'+path_name)
            if not path_name.endswith('.ko') or not re.fullmatch(r'0x[0-9a-f]{8}',crc) or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9.$]*',symbol):
                raise InvalidCohorts('INVALID_OEM_IMPORT_ROW')
            rows.append((cohort,path_name,symbol,crc))
    return rows

def summarize(rows, strict: bool=True):
    symbols=collections.defaultdict(lambda:collections.defaultdict(set))
    module_sets=collections.defaultdict(set)
    imports=collections.Counter()
    for cohort,path,symbol,crc in rows:
        if cohort not in ('GKI','QGKI'):raise InvalidCohorts('UNKNOWN_COHORT')
        symbols[symbol][cohort].add(crc)
        module_sets[cohort].add(path)
        imports[cohort]+=1
    inconsistent_within={f'{name}@{c}':sorted(crcs) for name,v in symbols.items() for c,crcs in v.items() if len(crcs)!=1}
    if inconsistent_within:raise InvalidCohorts('INTERNAL_COHORT_CRC_CONFLICT')
    cross=[]
    for symbol,groups in symbols.items():
        if 'GKI' in groups and 'QGKI' in groups and groups['GKI'] != groups['QGKI']:
            cross.append({'symbol':symbol,'GKI':next(iter(groups['GKI'])),'QGKI':next(iter(groups['QGKI']))})
    cross.sort(key=lambda r:r['symbol'])
    if strict:
        if len(rows)!=EXPECTED_IMPORTS or {k:len(v) for k,v in module_sets.items()}!=EXPECTED_MODULES:
            raise InvalidCohorts('R21_HISTORICAL_INVENTORY_CHANGED')
        if len(cross)!=EXPECTED_CONFLICTING_NAMES:
            raise InvalidCohorts('R30_COHORT_CONFLICT_COUNT_CHANGED')
        m={r['symbol']:r for r in cross}
        if 'module_layout' not in m or {g:m['module_layout'][g] for g in ('GKI','QGKI')}!=MODULE_LAYOUT:
            raise InvalidCohorts('ORIGINAL_OEM_MODULE_LAYOUT_CRC_CHANGED')
    return {'schema':'VEUX_R60_HISTORICAL_OEM_COHORT_CONFLICT_V1',
            'original_import_csv_sha256':IMPORT_SHA256 if strict else None,
            'historical_imports':len(rows),'installed_module_files_by_cohort':{k:len(v) for k,v in sorted(module_sets.items())},
            'historical_imports_by_cohort':dict(sorted(imports.items())),
            'conflicting_symbol_names':len(cross),
            'module_layout':MODULE_LAYOUT,
            'conflicting_symbols':cross,
            'conclusion':'NO_SINGLE_MODULE_SYMVERS_CAN_MATCH_BOTH_HISTORICAL_COHORT_CRC_SETS',
            'note':'Installed modules are not proof of which modules are actually loaded. Verify real boot-critical module set before device-specific ABI release.',
            'active_cohort_at_device_boot_proven':False,
            'kernel_compiled':False,'flash_allowed':False}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--imports',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args(argv)
    if a.out.exists() or a.out.is_symlink() or not a.out.parent.is_dir():
        raise InvalidCohorts('OUTPUT_NOT_NEW_OR_PARENT_MISSING')
    result=summarize(read_rows(a.imports))
    a.out.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    print('R60_COHORT_CONFLICTS_VERIFIED='+str(result['conflicting_symbol_names']))
    print('R60_ACTIVE_OEM_COHORT_VERIFIED=NO; FLASH=NO')
    return 0

if __name__=='__main__':
    try:raise SystemExit(main())
    except (InvalidCohorts,ValueError,OSError) as e:
        print('R60_COHORT_REVIEW_BLOCKED='+str(e),file=sys.stderr)
        raise SystemExit(3)
