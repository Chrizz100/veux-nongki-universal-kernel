#!/usr/bin/env python3
"""Strict, read-only VEUX R14 OEM vendor ABI research gate.

Inputs are 218 original R21 .ko imports and a candidate's *actual* Module.symvers.
Never modifies kernel files or authorizes a flash. No CRC overrides or bypasses.
"""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import re
import sys

EXPECTED = {
    'r21_imports_sha256': 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394',
    'r13_symvers_sha256': '0b5f909c68ec375533e961ac106da49c71b25f4fc99e6d13d0d093a52a540ec2',
    'r13_config_sha256': '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4',
    'import_rows': 14648,
    'vendor_files': 218,
    'r13_matches': 6286,
    'r13_mismatches': 7827,
    'r13_missing': 535,
    'qgki_files': 37,
    'gki_files': 181,
    'module_layout_qgki': '0x945d02f2',
    'module_layout_gki': '0x1e5b7ab7',
    'module_layout_r13': '0xbff14f69',
}
CONFIG_FLAGS = (
    'CONFIG_ANDROID_KABI_RESERVE', 'CONFIG_ANDROID_VENDOR_OEM_DATA',
    'CONFIG_FTRACE', 'CONFIG_KPROBES', 'CONFIG_BPF_EVENTS',
    'CONFIG_TRACING', 'CONFIG_TRACEPOINTS', 'CONFIG_MODVERSIONS',
    'CONFIG_CFI_CLANG', 'CONFIG_SCHED_CASS', 'CONFIG_SCHED_WALT',
)


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 19), b''):
            h.update(chunk)
    return h.hexdigest()


def parse_symvers(path):
    symbols = {}
    rows = 0
    with open(path, encoding='utf-8', newline='') as stream:
        for line in stream:
            rows += 1
            parts = line.rstrip('\n').split('\t')
            if len(parts) != 5:
                raise ValueError(f'Bad 5-column symvers row at line {rows}')
            crc, symbol, provider, exported, namespace = parts
            if not re.fullmatch(r'0x[0-9a-fA-F]{8}', crc):
                raise ValueError(f'Bad CRC for {symbol} at line {rows}')
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.$]*', symbol):
                raise ValueError(f'Bad symbol at line {rows}')
            if symbol in symbols:
                raise ValueError('Duplicate export symbol: ' + symbol)
            if exported not in ('EXPORT_SYMBOL', 'EXPORT_SYMBOL_GPL', 'EXPORT_SYMBOL_GPL_FUTURE', 'EXPORT_UNUSED_SYMBOL', 'EXPORT_UNUSED_SYMBOL_GPL'):
                raise ValueError('Unknown symbol export type: ' + exported)
            symbols[symbol] = dict(crc=crc.lower(), provider=provider, export=exported, namespace=namespace)
    if not symbols:
        raise ValueError('Empty Module.symvers')
    return symbols


def parse_imports(path, enforce_full=True):
    rows = []
    with open(path, encoding='utf-8', newline='') as stream:
        reader = csv.DictReader(stream)
        if not {'path', 'symbol', 'module_crc'}.issubset(reader.fieldnames or []):
            raise ValueError('Invalid R21 import CSV header')
        for row in reader:
            p = row['path']
            if p.startswith('/vendor/lib/modules/5.4-gki/'):
                group = 'GKI'
            elif p.startswith('/vendor/lib/modules/') and p.count('/') == 4:
                group = 'QGKI'
            else:
                raise ValueError('Unrecognized vendor path: ' + p)
            if not p.endswith('.ko') or not re.fullmatch(r'0x[0-9a-fA-F]{8}', row['module_crc']):
                raise ValueError('Bad original module import')
            if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_.$]*', row['symbol']):
                raise ValueError('Bad original import symbol')
            rows.append(dict(group=group, path=p, symbol=row['symbol'], crc=row['module_crc'].lower()))
    if enforce_full:
        if len(rows) != EXPECTED['import_rows']:
            raise ValueError('R21 import row count changed')
        p = {r['path'] for r in rows}
        if len(p) != EXPECTED['vendor_files']:
            raise ValueError('R21 module count changed')
        if len([x for x in p if x.startswith('/vendor/lib/modules/5.4-gki/')]) != 181:
            raise ValueError('Original GKI module count changed')
        if len([x for x in p if x.startswith('/vendor/lib/modules/') and not x.startswith('/vendor/lib/modules/5.4-gki/')]) != 37:
            raise ValueError('Original QGKI module count changed')
    return rows


def parse_config(path):
    cfg = {}
    with open(path, encoding='utf-8') as f:
        for line in f:
            if line.startswith('CONFIG_') and '=' in line:
                key, val = line.strip().split('=', 1)
            elif line.startswith('# CONFIG_') and line.rstrip().endswith(' is not set'):
                key, val = line[2:].rstrip()[:-len(' is not set')], 'n'
            else:
                continue
            if key in cfg:
                raise ValueError('Duplicate config key: ' + key)
            cfg[key] = val
    return {f: cfg.get(f, 'NOT_DEFINED') for f in CONFIG_FLAGS}


def summarize(imports, symbols):
    counts = collections.defaultdict(collections.Counter)
    modules = collections.defaultdict(lambda: collections.Counter())
    missing_names = collections.Counter()
    for row in imports:
        found = symbols.get(row['symbol'])
        if found is None:
            result = 'NOT_EXPORTED'
            missing_names[row['symbol']] += 1
        elif found['crc'] != row['crc']:
            result = 'CRC_MISMATCH'
        else:
            result = 'MATCH'
        counts[row['group']][result] += 1
        modules[row['path']][result] += 1
    all_counts = sum((v for v in counts.values()), collections.Counter())
    return {
        'totals': dict(all_counts),
        'groups': {k: dict(v) for k, v in sorted(counts.items())},
        'modules': {k: dict(v) for k,v in sorted(modules.items())},
        'top_missing': missing_names.most_common(30),
    }


def run(import_path, baseline_symvers, candidate_symvers, baseline_cfg, candidate_cfg, allow_modified_imports=False):
    if not allow_modified_imports:
        for path,pin in ((import_path,EXPECTED['r21_imports_sha256']),
                         (baseline_symvers,EXPECTED['r13_symvers_sha256']),
                         (baseline_cfg,EXPECTED['r13_config_sha256'])):
            if sha(path) != pin:
                raise ValueError('Pinned original input checksum mismatch: '+path.name)
    imports = parse_imports(import_path, not allow_modified_imports)
    base = parse_symvers(baseline_symvers)
    base_out = summarize(imports, base)
    if not allow_modified_imports:
        x = base_out['totals']
        if (x.get('MATCH', 0), x.get('CRC_MISMATCH', 0), x.get('NOT_EXPORTED', 0)) != (6286, 7827, 535):
            raise ValueError('R13 reference CRC counts changed')
        if base.get('module_layout', {}).get('crc') != EXPECTED['module_layout_r13']:
            raise ValueError('R13 module_layout reference changed')
    candidate = parse_symvers(candidate_symvers)
    cand_out = summarize(imports, candidate)
    bc, cc = parse_config(baseline_cfg), parse_config(candidate_cfg)
    if bc['CONFIG_MODVERSIONS'] != 'y' or cc['CONFIG_MODVERSIONS'] != 'y':
        raise ValueError('CONFIG_MODVERSIONS is not enabled')
    improvement = {k: cand_out['totals'].get(k,0)-base_out['totals'].get(k,0)
                   for k in ('MATCH','CRC_MISMATCH','NOT_EXPORTED')}
    return {
        'schema': 'VEUX_R14_VENDOR_ABI_RESEARCH_ONLY_V1',
        'source': 'R21 actual device original vendor .ko import inventory',
        'baseline_identity': 'R13 GitHub Actions run 40921711051 / 0c891296',
        'sha256': {'original_vendor_import_csv':sha(import_path),
                   'r13_module_symvers':sha(baseline_symvers),
                   'candidate_module_symvers':sha(candidate_symvers),
                   'r13_config':sha(baseline_cfg), 'candidate_config':sha(candidate_cfg)},
        'baseline_exports': len(base), 'candidate_exports':len(candidate),
        'original_vendor_file_count':len(set(x['path'] for x in imports)),
        'original_vendor_import_count':len(imports),
        'baseline':base_out, 'candidate':cand_out,
        'improvement_candidate_minus_r13':improvement,
        'module_layout':{
            'r13':base['module_layout']['crc'],
            'candidate':candidate.get('module_layout', {}).get('crc'),
            'original_gki':EXPECTED['module_layout_gki'],
            'original_qgki':EXPECTED['module_layout_qgki']},
        'config': {'r13':bc,'candidate':cc},
        'evaluation': {
            'candidate_is_better_global':improvement['MATCH']>0,
            'candidate_fully_covers_qgki':len(cand_out['groups'].get('QGKI',{})) == 1 and 'MATCH' in cand_out['groups']['QGKI'],
            'candidate_fully_covers_gki':len(cand_out['groups'].get('GKI',{})) == 1 and 'MATCH' in cand_out['groups']['GKI'],
            'external_xiaomi_vendor_abi_verified':False,
            'flash_allowed':False,
            'device_test':False,
            'warning':'ABI comparison and compile test never imply vendor module loading, hardware functionality or flash permission.',
        },
    }


def main(argv=None):
    a = argparse.ArgumentParser(description=__doc__)
    default = Path(__file__).resolve().parent / 'evidence'
    a.add_argument('--r21-imports', type=Path, default=default/'R21_IMPORTS.csv')
    a.add_argument('--r13-symvers', type=Path, default=default/'R13_CI_Module.symvers')
    a.add_argument('--candidate-symvers', type=Path)
    a.add_argument('--r13-config', type=Path, default=default/'R13_BUILD.config')
    a.add_argument('--candidate-config', type=Path)
    a.add_argument('--out', type=Path, default=None)
    args=a.parse_args(argv)
    d = run(args.r21_imports,args.r13_symvers,args.candidate_symvers or args.r13_symvers,
            args.r13_config,args.candidate_config or args.r13_config)
    s=json.dumps(d,indent=2,ensure_ascii=False,sort_keys=True)
    if args.out:
        if args.out.exists():
            raise SystemExit('Refuse overwrite of existing report: '+str(args.out))
        args.out.write_text(s+'\n',encoding='utf-8')
    else:
        print(s)
    return 0

if __name__ == '__main__':
    try:sys.exit(main())
    except (ValueError,OSError) as e:
        print('ABI AUDIT FAIL CLOSED:',e,file=sys.stderr)
        sys.exit(2)
