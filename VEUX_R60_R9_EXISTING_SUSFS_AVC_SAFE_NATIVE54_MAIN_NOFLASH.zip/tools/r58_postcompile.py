#!/usr/bin/env python3
"""Read-only, fail-closed postcompile proof. NO BOOT/AK3/FLASH approval."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def run(a):
 root=Path(a.output);obj=Path(a.objects);tool=Path(a.nm);ref=Path(a.reference)
 stage=json.loads((root/'R58_SOURCE_STAGE.json').read_text())
 if stage.get('kernel_compiled') is not False or stage.get('bakasu_real_git_count')!=4560:
  raise ValueError('SOURCE_STAGE_PROVENANCE_CHANGED')
 if stage.get('native54_sus_type_hash_collision_guard') is not True:
  raise ValueError('SUSFS_TYPE_HASH_KEY_GUARD_NOT_VERIFIED')
 cfg=(obj/'.config').read_text();required={'CONFIG_SCHED_CASS':'y','CONFIG_MODULES':'y','CONFIG_MODVERSIONS':'y',
       'CONFIG_KSU':'y','CONFIG_KSU_SUSFS':'y','CONFIG_NOMOUNT':'y','CONFIG_SECURITY_SELINUX':'y'}
 config_gates={k:(f'{k}={v}\n' in cfg) for k,v in required.items()}
 config_gates['WALT_OFF']='CONFIG_SCHED_WALT=y\n' not in cfg
 files={'Image':obj/'arch/arm64/boot/Image','vmlinux':obj/'vmlinux',
       'Module.symvers':obj/'Module.symvers','veux.dtb':obj/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb',
       '.config':obj/'.config'}
 for n,p in files.items():
  if not p.is_file() or p.stat().st_size<100:raise ValueError('COMPILE_OUTPUT_MISSING:'+n)
 original=json.loads(ref.read_text())
 if len(original['imports'])!=132:raise ValueError('R13_RMNET_EXPECTED_132_NOT_FOUND')
 crc={}
 for line in (obj/'Module.symvers').read_text().splitlines():
  c=line.split()
  if len(c)>=2 and re.fullmatch(r'0x[0-9a-fA-F]{8}',c[0]):crc[c[1]]=c[0].lower()
 details=[]
 for x in original['imports']:
  observed=crc.get(x['symbol'])
  expected=x['original_module_crc'].lower()
  details.append({'module':x['module'],'symbol':x['symbol'],'oem_expected':expected,
                  'observed':observed,'match':expected==observed})
 text=subprocess.check_output([str(tool),'--defined-only',str(obj/'vmlinux')],text=True)
 defined=set()
 for ln in text.splitlines():
  fields=ln.split()
  if len(fields)>=2 and len(fields[-2])==1 and fields[-2].isalpha():defined.add(fields[-1])
 expected=['susfs_add_sus_type','susfs_is_sus_type_rcu',
          'susfs_add_sus_avd_allowed_by_type','susfs_spoof_avd_allowed_rcu','nomount_init']
 symbols=[x for x in expected if any(re.fullmatch(re.escape(x)+r'(?:\.llvm\.[0-9]+)?',d) for d in defined)]
 image=(obj/'arch/arm64/boot/Image').read_bytes()
 elf=(obj/'vmlinux').open('rb').read(20)
 abi_pass=len(details)==132 and all(x['match'] for x in details)
 comp_pass=(all(config_gates.values()) and len(symbols)==5 and
      image[0x38:0x3c]==b'ARM\x64' and elf[:4]==b'\x7fELF' and elf[18:20]==b'\xb7\x00')
 result={'schema':'VEUX_R58_REAL_COMPILE_AND_RMNET_V1','compile_link_proof':bool(comp_pass),
         'gates':config_gates,'symbols':symbols,
         'native54_sus_type_hash_collision_guard':True,
         'RMNET_132_matched':sum(x['match'] for x in details),
         'RMNET_132_total':132,'RMNET_132_CRC_proven':abi_pass,
         'status':'COMPILE_AND_RMNET_REVIEW_PASS_NOFLASH' if comp_pass and abi_pass else 'COMPILE_OR_RMNET_BLOCKED',
         'files':{k:{'size':p.stat().st_size,'sha256':digest(p)} for k,p in files.items()},
         'R13_original_image_reused':digest(files['Image'])=='434f36efa102262896767734263c104c4a3e5fb028add310783768cca5ee1c37',
         'OEM_218_module_abi_proven':False,'DTBO_compatible':False,
         'CASS_device_runtime_proven':False,'AK3_static_boot_proven':False,
         'susfs_latest_8a120081_integrated':False,'new_bakasu_full_integration_review_required':True,
         'device_test':False,'boot_img_generated':False,'flash_allowed':False}
 (root/'R58_COMPILE_STATUS.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 (root/'R58_RMNET_132_DETAIL.json').write_text(json.dumps(details,indent=2,sort_keys=True)+'\n')
 print(result['status'])
 # Note: success here only means compile+RMNET, not OEM/vendor/boot approval.
 if not comp_pass or not abi_pass or result['R13_original_image_reused']:return 3
 return 0

def main():
 p=argparse.ArgumentParser()
 p.add_argument('--output',required=True);p.add_argument('--objects',required=True)
 p.add_argument('--nm',required=True);p.add_argument('--reference',required=True)
 a=p.parse_args()
 try:return run(a)
 except (ValueError,AssertionError,KeyError,OSError,subprocess.CalledProcessError) as e:
  print('R58_BUILD_BLOCKED='+str(e),file=sys.stderr);return 3
if __name__=='__main__':sys.exit(main())
