import hashlib, json, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import r59_host as p

class R60R8RealHostProvenance(unittest.TestCase):
    def test_01_source_manifest_full_sha(self):
        data=json.loads((ROOT/'refs/R13_HOST_PREIMAGE_PROVENANCE.json').read_text())
        self.assertEqual(data['source_inventory_sha256'],p.R13_INVENTORY_SHA256)
        self.assertEqual(data['files'],p.R13_HOST_SHA256)
        self.assertEqual(data['original_github_r13_run'],40921711051)
        self.assertEqual(data['repeat_github_r60_run'],41635325597)
        self.assertFalse(data['flash_allowed'])
    def test_02_all_exact_64_char_pins(self):
        self.assertEqual(set(p.R13_HOST_SHA256),{
            'security/selinux/hooks.c','security/selinux/avc.c','security/selinux/selinuxfs.c'})
        for sha in p.R13_HOST_SHA256.values():
            self.assertEqual(len(sha),64)
            int(sha,16)
    def _fixture(self):
        temp=tempfile.TemporaryDirectory()
        root=Path(temp.name)
        rel='security/selinux/hooks.c'
        src=root/rel; src.parent.mkdir(parents=True)
        src.write_bytes(b'R13 simulated compiled source')
        inventory=root/'r13-inventory.json'
        inventory.write_text(json.dumps({rel:{'type':'file','sha256':hashlib.sha256(src.read_bytes()).hexdigest()}}))
        return temp,root,rel,src,inventory
    def test_03_positive_with_matching_authenticated_synthetic_fixture(self):
        tmp,root,rel,src,inventory=self._fixture()
        try:
            self.assertTrue(p.attest_r13_host_preimages(root,inventory,[rel],{rel:hashlib.sha256(src.read_bytes()).hexdigest()}))
        finally:tmp.cleanup()
    def test_04_changed_source_bytes_blocked(self):
        tmp,root,rel,src,inventory=self._fixture()
        try:
            sha=hashlib.sha256(src.read_bytes()).hexdigest()
            src.write_bytes(src.read_bytes()+b'!')
            with self.assertRaisesRegex(p.GateError,'R13_HOST_PREIMAGE_CHANGED'):
                p.attest_r13_host_preimages(root,inventory,[rel],{rel:sha})
        finally:tmp.cleanup()
    def test_05_forged_inventory_blocked(self):
        tmp,root,rel,src,inventory=self._fixture()
        try:
            sha=hashlib.sha256(src.read_bytes()).hexdigest()
            inventory.write_text(json.dumps({rel:{'type':'file','sha256':'0'*64}}))
            with self.assertRaisesRegex(p.GateError,'R13_HOST_INVENTORY_FILE_CHANGED'):
                p.attest_r13_host_preimages(root,inventory,[rel],{rel:sha})
        finally:tmp.cleanup()
    def test_06_source_symlink_blocked(self):
        tmp,root,rel,src,inventory=self._fixture()
        try:
            sha=hashlib.sha256(src.read_bytes()).hexdigest()
            moved=root/'real.c';src.rename(moved);src.symlink_to(moved)
            with self.assertRaisesRegex(p.GateError,'MISSING_OR_SYMLINK'):
                p.attest_r13_host_preimages(root,inventory,[rel],{rel:sha})
        finally:tmp.cleanup()
    def test_07_false_pristine_54_sha_not_accepted(self):
        self.assertEqual(len(p.BASE),3)
        self.assertEqual(set(p.BASE),set(p.R13_HOST_SHA256))
        self.assertNotEqual(p.BASE['security/selinux/hooks.c'],p.R13_HOST_SHA256['security/selinux/hooks.c'])
    def test_08_inventory_sha_pinned_in_code_and_manifest(self):
        s=(ROOT/'tools/r59_host.py').read_text()
        self.assertIn('attest_r13_host_preimages(root, inventory_path',s)
        self.assertIn('R13_INVENTORY_SHA256',s)
        self.assertIn("require(sha256(inv_bytes)==R13_INVENTORY_SHA256",s)
    def test_09_compiler_receives_verified_inventory(self):
        s=(ROOT/'tools/r59_build_no_flash.sh').read_text()
        self.assertIn('--inventory "$R13_ROOT/evidence/BASELINE_SOURCE_INVENTORY.json"',s)
        self.assertIn('R59_HOST_INTEGRATION',s)
    def test_10_early_prescan_never_modifies_source(self):
        s=(ROOT/'tools/r59_host.py').read_text()
        pre=s.split('def preflight(kernel, report):',1)[1].split('\ndef install(',1)[0]
        self.assertNotIn('.write_text(content)',pre)
        self.assertNotIn('.write_bytes(',pre)
        self.assertIn('amended=fn(raw.decode',pre)
    def test_11_early_prescan_precedes_expensive_r13_compile(self):
        # Workflow's new pre-scan step is extracted separately by package validator.
        s=(ROOT/'README_ZUERST_DE.txt').read_text()
        self.assertIn('R60-R8',s)
        self.assertIn('Vorpruefung',s)
    def _host_source_fixture(self):
        import test_r59_host as fixtures
        tmp=tempfile.TemporaryDirectory()
        root=Path(tmp.name)
        content={'security/selinux/hooks.c':fixtures.HEADERS,
                 'security/selinux/avc.c':fixtures.AVC,
                 'security/selinux/selinuxfs.c':fixtures.SELINUXFS}
        for rel,data in content.items():
            file=root/rel;file.parent.mkdir(parents=True,exist_ok=True)
            file.write_text(data)
        return tmp,root,content
    def test_12b_early_preflight_success_changes_no_source(self):
        tmp,root,content=self._host_source_fixture()
        try:
            report=root/'out'/ 'proof.json';report.parent.mkdir()
            before={k:(root/k).read_bytes() for k in content}
            rows=p.preflight(root,report)
            self.assertEqual(set(rows),set(content))
            self.assertTrue(json.loads(report.read_text())['preflight_passed'])
            self.assertEqual(before,{k:(root/k).read_bytes() for k in content})
        finally:tmp.cleanup()
    def test_12c_early_preflight_rejects_changed_anchor_no_writes(self):
        tmp,root,content=self._host_source_fixture()
        try:
            f=root/'security/selinux/hooks.c'
            f.write_text(f.read_text().replace('struct selinux_state selinux_state;',
                                               'struct selinux_state bad;'))
            report=root/'blocked.json'
            before={k:(root/k).read_bytes() for k in content}
            with self.assertRaises(p.GateError):p.preflight(root,report)
            self.assertFalse(report.exists())
            self.assertEqual(before,{k:(root/k).read_bytes() for k in content})
        finally:tmp.cleanup()
    def test_12d_early_preflight_symlink_is_rejected(self):
        tmp,root,content=self._host_source_fixture()
        try:
            f=root/'security/selinux/avc.c';real=root/'real.c'
            f.rename(real);f.symlink_to(real)
            with self.assertRaisesRegex(p.GateError,'PREFLIGHT_MISSING_OR_SYMLINK'):
                p.preflight(root,root/'blocked.json')
        finally:tmp.cleanup()
    def test_12_no_flash_or_kernel_package_changes(self):
        s=(ROOT/'tools/r59_build_no_flash.sh').read_text()
        for dangerous in ('fastboot flash','adb reboot','reboot ','set-active-boot-slot'):
            self.assertNotIn(dangerous,s)
if __name__=='__main__':unittest.main()
