#!/usr/bin/env python3
"""R60-R4: ensure R13's actual compiled SELinux services.c is pinned.

Tests use the two source witnesses from the successful R13 artifact and
exercise the strict gate against alternate digests. No fake build assertions.
"""
import hashlib, importlib.util, json, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r58_integrate_r4', ROOT/'tools/r58_integrate.py')
r58=importlib.util.module_from_spec(spec);spec.loader.exec_module(r58)

class R60R4Services(unittest.TestCase):
    def setUp(self):
        self.pin=json.loads((ROOT/'refs/R13_COMPILED_SERVICES_PROVENANCE.json').read_text())

    def test_01_source_sha_from_successful_r13_report(self):
        self.assertEqual(self.pin['run_id'],40921711051)
        self.assertEqual(self.pin['artifact_sha256'], '8313423a53d14881df07a5f20b5236818b182bfc10dff946f1288fc443f84e3c')
        self.assertEqual(self.pin['r13_compiled_services_sha256'],r58.R13_COMPILED_SERVICES_SHA256)

    def test_02_exact_verified_baseline_digest_allowed(self):
        self.assertEqual(r58.R13_COMPILED_SERVICES_SHA256,'5e96d63c90cd102c6a92a4173430d44a44d5f86cf63345b39c678a842bad1e19')
        self.assertEqual(len(r58.R13_COMPILED_SERVICES_SHA256),64)

    def test_03_older_stock_blobs_are_not_substituted_for_compiled_r13(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertNotIn('VENDOR_SERVICES_BLOBS',s)
        self.assertNotIn('git_blob(before) in',s)
        self.assertIn("hashlib.sha256(before).hexdigest()==R13_COMPILED_SERVICES_SHA256",s)

    def test_04_compiler_is_blocked_before_copy_on_mismatch(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertLess(s.index('R13_COMPILED_SERVICES_PREIMAGE_MISMATCH'),s.index('out.mkdir(mode=0o700)'))
        self.assertIn('before=orig_services.read_bytes()',s)

    def test_05_no_generic_fallback_check(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertNotIn('R13_STOCK54_SERVICES_REVIEW_REQUIRED',s)
        self.assertNotIn('or True',s)
        self.assertNotIn('|| true',s)
        self.assertNotIn('CONFIG_MODVERSIONS=n',s)

    def test_06_negative_mutation_fails_digest_pin(self):
        good=bytes.fromhex(self.pin['r13_compiled_services_sha256'])
        self.assertNotEqual(hashlib.sha256(good).hexdigest(),r58.R13_COMPILED_SERVICES_SHA256)
        self.assertNotEqual(hashlib.sha256(good+b'bad').hexdigest(),r58.R13_COMPILED_SERVICES_SHA256)

    def test_07_source_stage_receipts_preimage_pin(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertIn("'r13_compiled_services_preimage_sha256':hashlib.sha256(before).hexdigest()",s)
        self.assertIn("'flash_allowed':False",s)

    def test_08_original_r13_proofs_agree_when_available(self):
        path=Path('/mnt/data/VEUX_R13_PRUEFBERICHTE_40921711051.zip')
        if not path.exists(): self.skipTest('R13 historical CI artifact not mounted on this runner')
        from zipfile import ZipFile
        self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),self.pin['artifact_sha256'])
        with ZipFile(path) as z:
            inventory=json.loads(z.read('veux-r55h17-r4/evidence/BASELINE_SOURCE_INVENTORY.json'))
            witness=json.loads(z.read('veux-r5s2-work/report/BAKASU-CONTEXT-HASH-D726-R3.json'))
            self.assertEqual(inventory['security/selinux/ss/services.c']['sha256'],r58.R13_COMPILED_SERVICES_SHA256)
            self.assertEqual(witness['host']['services_c_sha256'],r58.R13_COMPILED_SERVICES_SHA256)

if __name__=='__main__':unittest.main()
