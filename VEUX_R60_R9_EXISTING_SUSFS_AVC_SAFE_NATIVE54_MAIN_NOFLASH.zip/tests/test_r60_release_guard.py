import json, tempfile,unittest,sys,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
import r60_release_guard as g
import r60_abi_cohorts as c

class R60GuardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cohorts=c.summarize(c.read_rows(BASE/'refs/R21_IMPORTS.csv'))
    def compiler(self,match=9000):
        return {'schema':'VEUX_R59_FULL_COMPONENTS_BUILD_EVIDENCE_V1',
          'source_and_compiler_pass':True,'rmnet_132_all_match':True,
          'vendor_module_files':218,'vendor_imports':14648,
          'vendor_matches':match,'vendor_crc_mismatches':14648-match-100,
          'vendor_not_exported':100,
          'oem_abi_green':False,'full_vendor_crc_match':False,
          'device_test':False,'flash_allowed':False}
    def test_01_creates_blocking_report(self):
        result=g.evaluate(self.compiler(),self.cohorts)
        self.assertFalse(result['flash_allowed']);self.assertFalse(result['full_component_release_approved'])
        self.assertEqual(result['historical_conflicting_symbol_names'],836)
    def test_02_unproven_compiler_fails(self):
        r=self.compiler();r['source_and_compiler_pass']=False
        with self.assertRaises(g.InvalidReport):g.evaluate(r,self.cohorts)
    def test_03_unproven_rmnet_fails(self):
        r=self.compiler();r['rmnet_132_all_match']=False
        with self.assertRaises(g.InvalidReport):g.evaluate(r,self.cohorts)
    def test_04_false_vendor_all_green_rejected(self):
        r=self.compiler();r['oem_abi_green']=True;r['full_vendor_crc_match']=True
        with self.assertRaises(g.InvalidReport):g.evaluate(r,self.cohorts)
    def test_05_any_wrong_cohort_count_fails(self):
        c2={**self.cohorts,'conflicting_symbol_names':835}
        with self.assertRaises(g.InvalidReport):g.evaluate(self.compiler(),c2)
    def test_06_real_run_returns_block(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'compile.json').write_text(json.dumps(self.compiler()))
            (p/'cohorts.json').write_text(json.dumps(self.cohorts))
            proc=subprocess.run([sys.executable,'-O',str(BASE/'tools/r60_release_guard.py'),
              '--compile-report',str(p/'compile.json'),'--cohorts',str(p/'cohorts.json'),
              '--out',str(p/'decision.json')],capture_output=True,text=True)
            self.assertEqual(proc.returncode,3)
            self.assertFalse(json.loads((p/'decision.json').read_text())['flash_allowed'])
    def test_07_import_counts_strict(self):
        r=self.compiler();r['vendor_crc_mismatches']-=1
        with self.assertRaises(g.InvalidReport):g.evaluate(r,self.cohorts)
    def test_08_flash_true_rejected(self):
        r=self.compiler();r['flash_allowed']=True
        with self.assertRaises(g.InvalidReport):g.evaluate(r,self.cohorts)
