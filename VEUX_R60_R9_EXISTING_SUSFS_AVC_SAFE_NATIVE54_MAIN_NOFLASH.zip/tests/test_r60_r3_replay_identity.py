"""R60-R3: run-bound BakaSU replay identity gate.

Git commit metadata is allowed to vary; ancestry, tree, changed paths,
protected blobs, R13 provenance, and local receipt coherence are not.
"""
import importlib.util
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r60_r3_integrate',ROOT/'tools/r58_integrate.py')
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

HISTORICAL_COMMIT='cf354d9ec796a414dc040b58b1882589e6768fc9'
FRESH_COMMIT='042827849e1b24fed1b2918b036b316ee6b639d5'

def valid_receipt(commit=FRESH_COMMIT):
    return {
        'schema':'VEUX_R56_R3_BAKASU_TREE_RECOVERY_V1',
        'status':'HISTORICAL_R13_TREE_VERIFIED__CURRENT_BAKASU_CONTENT_REPLAYED__NO_BUILD_NO_FLASH',
        'official_head':m.R56_BAKASU_OFFICIAL_HEAD,
        'five_official_upstream_commits':list(m.R56_OFFICIAL_SEQUENCE),
        'historical_original_commit':m.R56_R13_ORIGINAL_COMMIT,
        'historical_original_parent':m.R56_R13_ORIGINAL_PARENT,
        'historical_reconstructed_tree':m.R56_R13_RECONSTRUCTED_TREE,
        'historical_tree_byte_identical':True,
        'original_commit_SHA_recreated':False,
        'genuine_git_commit_count':4559,
        'calculated_source_version':35259,
        'kernel_compiled':False,
        'flash_allowed':False,
        'changed_paths':list(m.R56_ALL_CHANGED_PATHS),
        'protected_port_blobs':dict(m.R56_PROTECTED_BLOBS),
        'result_tree':m.R56_BAKASU_TREE,
        'result_commit':commit,
    }

def emulated_git(commit=FRESH_COMMIT, tree=None, parent=None, count='4559', delta=None, bad_blob=None, dirty=False):
    tree=tree or m.R56_BAKASU_TREE
    parent=parent or m.R56_BAKASU_OFFICIAL_HEAD
    paths=sorted(m.R56_PROTECTED_BLOBS) if delta is None else delta
    def call(repo,*args):
        cmd=args
        if cmd==('rev-parse','HEAD'):return commit
        if cmd==('rev-parse','HEAD^{tree}'):return tree
        if cmd==('rev-parse','HEAD~2'):return parent
        if cmd==('rev-list','--count','HEAD'):return count
        if cmd==('status','--porcelain','--untracked-files=all'):return '?? injected' if dirty else ''
        if cmd==('diff','--name-only',m.R56_BAKASU_OFFICIAL_HEAD+'..HEAD'):
            return '\n'.join(paths)
        if len(cmd)==2 and cmd[0]=='rev-parse' and cmd[1].startswith('HEAD:'):
            key=cmd[1][5:]
            if bad_blob==key:return '0000000000000000000000000000000000000000'
            return m.R56_PROTECTED_BLOBS[key]
        raise AssertionError('Unexpected git command: '+str(cmd))
    return call

class R60R3ReplayIdentity(unittest.TestCase):
    def receipt(self,d,data):
        p=Path(d)/'receipt.json'
        p.write_text(json.dumps(data,sort_keys=True)+'\n')
        return p

    def run_proof(self,data,**changes):
        with tempfile.TemporaryDirectory() as d:
            path=self.receipt(d,data)
            with patch.object(m,'git',side_effect=emulated_git(**changes)):
                return m.ensure_git_replay(Path(d),path)

    def test_old_git_commit_accepted_only_for_pinned_tree(self):
        d=valid_receipt(HISTORICAL_COMMIT)
        self.assertEqual(self.run_proof(d,commit=HISTORICAL_COMMIT)['result_commit'],HISTORICAL_COMMIT)

    def test_new_git_commit_accepted_for_identical_tree_and_ancestry(self):
        d=valid_receipt(FRESH_COMMIT)
        self.assertEqual(self.run_proof(d)['result_commit'],FRESH_COMMIT)

    def test_reject_receipt_commit_disagreeing_with_real_git(self):
        with self.assertRaisesRegex(m.Blocked,'COMMIT_MISMATCH'):
            self.run_proof(valid_receipt(HISTORICAL_COMMIT))

    def test_reject_wrong_pinned_tree_in_receipt(self):
        d=valid_receipt();d['result_tree']='0'*40
        with self.assertRaisesRegex(m.Blocked,'SOURCE_TREE_CHANGED'):
            self.run_proof(d)

    def test_reject_wrong_tree_in_actual_git(self):
        with self.assertRaisesRegex(m.Blocked,'ACTUAL_GIT_TREE_CHANGED'):
            self.run_proof(valid_receipt(),tree='0'*40)

    def test_reject_changed_upstream_commit(self):
        d=valid_receipt();d['official_head']='0'*40
        with self.assertRaisesRegex(m.Blocked,'UPSTREAM_LINEAGE_CHANGED'):
            self.run_proof(d)

    def test_reject_incorrect_original_r13_tree(self):
        d=valid_receipt();d['historical_reconstructed_tree']='0'*40
        with self.assertRaisesRegex(m.Blocked,'R13_RECONSTRUCTION_CHANGED'):
            self.run_proof(d)

    def test_reject_changed_replay_parent(self):
        with self.assertRaisesRegex(m.Blocked,'REPLAY_PARENT_CHANGED'):
            self.run_proof(valid_receipt(),parent='0'*40)

    def test_reject_changed_git_history_length(self):
        with self.assertRaisesRegex(m.Blocked,'REAL_GIT_COUNT_CHANGED'):
            self.run_proof(valid_receipt(),count='4558')

    def test_reject_changed_local_port_scope(self):
        with self.assertRaisesRegex(m.Blocked,'LOCAL_PORT_SCOPE_CHANGED'):
            self.run_proof(valid_receipt(),delta=['kernel/feature/sucompat.c','kernel/evil.c'])

    def test_reject_modified_protected_blob(self):
        with self.assertRaisesRegex(m.Blocked,'PROTECTED_PORT_BLOB_CHANGED'):
            self.run_proof(valid_receipt(),bad_blob='kernel/feature/selinux_hide.c')

    def test_reject_dirty_replay_tree(self):
        with self.assertRaisesRegex(m.Blocked,'SOURCE_DIRTY'):
            self.run_proof(valid_receipt(),dirty=True)

    def test_reject_forged_source_version(self):
        d=valid_receipt();d['calculated_source_version']=35260
        with self.assertRaisesRegex(m.Blocked,'REPLAY_RECEIPT_CHANGED'):
            self.run_proof(d)

    def test_reject_unexpected_protected_blob_receipt(self):
        d=valid_receipt();d['protected_port_blobs']['kernel/feature/selinux_hide.c']='0'*40
        with self.assertRaisesRegex(m.Blocked,'PROTECTED_SOURCE_RECEIPT_CHANGED'):
            self.run_proof(d)

    def test_reject_flashable_status_in_source_receipt(self):
        d=valid_receipt();d['flash_allowed']=True
        with self.assertRaisesRegex(m.Blocked,'REPLAY_RECEIPT_CHANGED'):
            self.run_proof(d)

    def test_no_git_timestamp_as_source_identity(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertIn("git(replay,'rev-parse','HEAD^{tree}')",s)
        self.assertIn('R56_BAKASU_PROTECTED_SOURCE_RECEIPT_CHANGED',s)
        self.assertNotIn('cf354d9ec796a414dc040b58b1882589e6768fc9',s)
        self.assertNotIn('R56_BAKASU_SHA',s)

if __name__=='__main__': unittest.main()
