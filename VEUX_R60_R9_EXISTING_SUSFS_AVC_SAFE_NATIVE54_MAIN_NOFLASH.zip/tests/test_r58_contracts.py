"""Deterministic local R58 contracts, including real archived R13 config.

Requires only Python stdlib. Does not compile or touch a user device.
"""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]

def load(name):
    s=importlib.util.spec_from_file_location(name,ROOT/'tools'/f'{name}.py')
    m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
    return m

src=load('r58_integrate')
post=load('r58_postcompile')
REPO=Path(__file__).resolve().parents[3]
R13=Path('/mnt/data/VEUX_R13_CASS_MAIN.zip')
R56=Path('/mnt/data/VEUX_R56_R4_STOCK_AVD_PATH_MAIN_NOFLASH.zip')
# Also works on a GitHub runner without /mnt/data; tests skip real full archive if absent.
class R58Contracts(unittest.TestCase):
    def test_01_literal_r13_and_r56_pins(self):
        self.assertEqual(src.R13_MAIN_SHA,'15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1')
        self.assertEqual(src.R56_MAIN_SHA,'b745ba93ebf92482fa3fcfa10a27b08c62fc72e07479e029dbae685949ae6117')
    def test_02_susfs_snapshot_is_not_claimed_latest(self):
        self.assertNotEqual(src.SUSFS_SNAPSHOT,src.SUSFS_LATEST_OBSERVED)
    def test_03_source_bridge_no_dummy_version(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertIn("git(b,'rev-list','--count','HEAD')=='4560'",s)
        self.assertIn('R56_BAKASU_REAL_GIT_COUNT_CHANGED',s)
        self.assertIn('protected_port_blobs',s)
    def test_04_no_automatic_flashing_paths(self):
        for p in [ROOT/'tools/r58_integrate.py', ROOT/'tools/r58_postcompile.py', ROOT/'tools/r58_build_no_flash.sh']:
            data=p.read_text()
            for term in ['fastboot flash','adb reboot','dd if=','magiskboot repack','bootctl set-active-boot-slot']:
                self.assertNotIn(term,data)
    def test_05_real_r56_patches_match_staged_reference(self):
        a=(ROOT/'refs/0001-bakasu-native54-avd-bridge.patch').read_text()
        self.assertEqual(a.count('--- a/kernel/'),2)
        self.assertEqual(a.count('+++ b/kernel/'),2)
        b=(ROOT/'refs/0002-xiaomi-services-native54-avd.patch').read_text()
        self.assertEqual(b.count('--- a/security/selinux/ss/services.c'),1)
        self.assertIn('susfs_spoof_avd_allowed_rcu',b)
    def test_06_type_bridge_exact_native54_input(self):
        text=('prefix\n#include "audit.h"\n\n'
              'static int string_to_context_struct(struct policydb *pol) {\n'
              '\ttypdatum = hashtab_search(pol->p_types.table, scontextp);\n'
              '\tif (!typdatum || typdatum->attribute)\n'
              '\t\tgoto out;\n\n'
              '\tctx->type = typdatum->value;\n}\n')
        out=src.type_bridge(text)
        self.assertIn('rcu_read_lock();',out)
        self.assertIn('rcu_read_unlock();',out)
        self.assertIn('ctx->type = typdatum->value;',out)
        self.assertIn('goto out;',out)
        self.assertIn('CONFIG_KSU_SUSFS',out)
        self.assertEqual(out.count('susfs_is_sus_type_rcu('),2)
        with self.assertRaises(src.Blocked):src.type_bridge(out)
    def fake_susfs_hash_source(self):
        return (
           '#include <linux/hash.h>\n'
           'static DEFINE_HASHTABLE(SUS_TYPE_HLIST, 10);\n'
           'struct st_susfs_sus_type_hlist {\n'
           '\tstruct hlist_node                       node;\n};\n'
           'hash_for_each_possible_safe(SUS_TYPE_HLIST, tmp_entry, tmp_hlist_node, node, type_value) {\n'
           '\tSUSFS_LOGE("was added before");\n}\n'
           'new_entry = kzalloc(sizeof(*new_entry), GFP_KERNEL);\n'
           '\thash_add_rcu(SUS_TYPE_HLIST, &new_entry->node, type_value);\n'
           'hash_for_each_possible_rcu(SUS_TYPE_HLIST, entry, node, type_value) {\n'
           '\t\treturn true;\n\t}\n'
           'static DEFINE_HASHTABLE(SUS_AVD_ALLOWED_HLIST, 18);\n')
    def test_06b_native54_hashtable_header_required(self):
        original=self.fake_susfs_hash_source()
        result=src.native_hashtable_header(original)
        self.assertIn('#include <linux/hashtable.h>\n',result)
        self.assertIn('u32 type_value;',result)
        self.assertIn('new_entry->type_value = type_value;',result)
        self.assertIn('tmp_entry->type_value != type_value',result)
        self.assertIn('entry->type_value == type_value',result)
        with self.assertRaises(src.Blocked):src.native_hashtable_header(result)
        with self.assertRaises(src.Blocked):src.native_hashtable_header(original.replace('static DEFINE_HASHTABLE(SUS_AVD_ALLOWED_HLIST, 18);',''))
        self.assertEqual(src.NATIVE54_HASHTABLE_BLOB,'417d2c4bc60db4b80b29d1a7f78d1273b600b258')
    def test_06bb_missing_type_hash_struct_blocks(self):
        s=self.fake_susfs_hash_source().replace('struct hlist_node                       node;','struct hlist_node missing;')
        with self.assertRaises(src.Blocked):src.native_hashtable_header(s)
    def test_06bc_missing_lookup_anchor_blocks(self):
        s=self.fake_susfs_hash_source().replace('return true;','return false;')
        with self.assertRaises(src.Blocked):src.native_hashtable_header(s)
    def test_06bd_type_hash_collision_regression(self):
        # A hash-bucket iterator is not an exact-key lookup. The exact-key
        # guard must distinguish an unrelated key from the queried type.
        source=src.native_hashtable_header(self.fake_susfs_hash_source())
        self.assertIn('if (entry->type_value == type_value)',source)
        self.assertIn('if (tmp_entry->type_value != type_value)',source)
        self.assertNotIn('hash_for_each_possible_rcu(SUS_TYPE_HLIST, entry, node, type_value) {\n\t\treturn true;',source)
    def test_06be_no_change_to_base_susfs_bytes(self):
        # Runtime stage only changes the isolated candidate AFTER R52 sha256 pin.
        program=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertIn('sha(susfs)==R52_SUSFS_SHA',program)
        self.assertIn("(target/'fs/susfs.c').write_text(native_hashtable_header(susfs.read_text()))",program)
    def test_06bf_allows_realistic_tabs(self):
        s=self.fake_susfs_hash_source().replace('node;','node;')
        self.assertIn('type_value',src.native_hashtable_header(s))
    def test_06c_new_local_git_commit_reproducible(self):
        s=(ROOT/'tools/r58_integrate.py').read_text()
        self.assertIn("'GIT_AUTHOR_DATE':'2026-11-03T00:00:00+00:00'",s)
        self.assertIn("'GIT_COMMITTER_DATE':'2026-11-03T00:00:00+00:00'",s)
        self.assertIn("git(b,'rev-list','--count','HEAD')=='4560'",s)
    def test_07_changed_native54_type_anchor_blocks(self):
        with self.assertRaises(src.Blocked):src.type_bridge('#include "audit.h"\n\nwrong body')
        with self.assertRaises(src.Blocked):src.type_bridge('not a SELinux source')
    def test_08_rejects_input_file_as_symlink(self):
        with tempfile.TemporaryDirectory() as d:
            x=Path(d);(x/'raw').write_text('x');(x/'alias').symlink_to(x/'raw')
            with self.assertRaises(src.Blocked):src.required_file(x/'alias')
    def test_09_preflight_rejects_fake_archive(self):
        with tempfile.TemporaryDirectory() as d:
            x=Path(d);r13=x/'r13.zip';r56=x/'r56.zip';config=x/'r13.config'
            r13.write_bytes(b'definitely not original');r56.write_bytes(b'also fake');config.write_bytes(b'CONFIG_SCHED_CASS=y\n')
            with self.assertRaises(src.Blocked):src.preflight(r13,r56,config)
    def test_10_postcompile_has_deny_release(self):
        s=(ROOT/'tools/r58_postcompile.py').read_text()
        self.assertIn("'flash_allowed':False",s)
        self.assertIn("'OEM_218_module_abi_proven':False",s)
        self.assertIn("'AK3_static_boot_proven':False",s)
        self.assertIn("'RMNET_132_CRC_proven':abi_pass",s)
    def test_11_kernel_build_does_not_publish_images(self):
        s=(ROOT/'tools/r58_build_no_flash.sh').read_text()
        self.assertIn('R58_KERNEL_COMPILER_EXIT=0',s)
        self.assertNotIn('anykernel.sh',s)
        self.assertNotIn('mkbootimg',s)
        self.assertNotIn('upload-artifact',s)
    def test_12_postcompile_fails_no_outputs(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); (root/'out').mkdir();(root/'obj').mkdir()
            (root/'out/R58_SOURCE_STAGE.json').write_text(json.dumps({'kernel_compiled':False,'bakasu_real_git_count':4560}))
            (root/'ref.json').write_text(json.dumps({'imports':[{'symbol':'x','original_module_crc':'0x00000000','module':'rmnet_shs'}]*132}))
            class A:pass
            a=A();a.output=str(root/'out');a.objects=str(root/'obj');a.nm='/usr/bin/false';a.reference=str(root/'ref.json')
            with self.assertRaises((ValueError, OSError)):post.run(a)
    def test_13_r13_archived_config_real(self):
        if not R13.exists() or not R56.exists():self.skipTest('Archive fixtures not bundled; tested in local builder')
        with zipfile.ZipFile('/mnt/data/VEUX_R13_PRUEFBERICHTE_40921711051.zip') as z:
            b=z.read('veux-r55h17-r4/evidence/BASELINE.config')
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'config'; f.write_bytes(b)
            data=src.preflight(R13,R56,f)
            self.assertTrue(data['cass'] and data['modules'] and data['modversions'])
            self.assertFalse(data['flash_allowed'])
    def test_14_r13_config_missing_modules_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'config';f.write_text('CONFIG_SCHED_CASS=y\nCONFIG_MODULES=n\n')
            if R13.exists() and R56.exists():
                with self.assertRaises(src.Blocked):src.preflight(R13,R56,f)
    def test_15_zip_member_manifest(self):
        if not R56.exists():self.skipTest('Current R56 MAIN not available')
        with zipfile.ZipFile(R56) as z:
            self.assertIsNone(z.testzip())
            man=json.loads(z.read('MANIFEST_SHA256.json'))
            self.assertEqual(set(z.namelist()),set(man['files'])|{'MANIFEST_SHA256.json'})
            self.assertFalse(man['flash_allowed'])

if __name__=='__main__':unittest.main()
