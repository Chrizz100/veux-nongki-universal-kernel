#!/usr/bin/env python3
"""Offline positive/negative regression tests for the VEUX R14 research gate."""
import copy
import csv
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import r14_vendor_abi_gate as v

ROOT=Path(__file__).resolve().parents[1] / 'refs'

class R14Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.im=ROOT/'R21_IMPORTS.csv'
        cls.sy=ROOT/'R13_CI_Module.symvers'
        cls.cf=ROOT/'R13_BUILD.config'
        cls.real=v.run(cls.im,cls.sy,cls.sy,cls.cf,cls.cf)

    def test_01_exact_original_import_count(self):
        self.assertEqual(self.real['original_vendor_import_count'],14648)
    def test_02_exact_original_module_count(self):
        self.assertEqual(self.real['original_vendor_file_count'],218)
    def test_03_r13_real_crc_counts(self):
        self.assertEqual(self.real['baseline']['totals'],{'MATCH':6286,'CRC_MISMATCH':7827,'NOT_EXPORTED':535})
    def test_04_r13_real_export_count(self):
        self.assertEqual(self.real['baseline_exports'],12947)
    def test_05_module_layout_reference_pins(self):
        self.assertEqual(self.real['module_layout'],dict(r13='0xbff14f69',candidate='0xbff14f69',original_gki='0x1e5b7ab7',original_qgki='0x945d02f2'))
    def test_06_baseline_never_claims_flash(self):
        self.assertFalse(self.real['evaluation']['flash_allowed'])
        self.assertFalse(self.real['evaluation']['device_test'])
        self.assertFalse(self.real['evaluation']['external_xiaomi_vendor_abi_verified'])
    def test_07_kabi_disabled_in_r13(self):
        self.assertEqual(self.real['config']['r13']['CONFIG_ANDROID_KABI_RESERVE'],'n')
        self.assertEqual(self.real['config']['r13']['CONFIG_ANDROID_VENDOR_OEM_DATA'],'n')
    def test_08_two_cohorts_unmerged(self):
        self.assertEqual(sum(self.real['baseline']['groups']['GKI'].values()),11500)
        self.assertEqual(sum(self.real['baseline']['groups']['QGKI'].values()),3148)
    def test_09_symvers_bad_columns_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'sym';p.write_text('0x12345678\tx\tvmlinux\tEXPORT_SYMBOL\n')
            with self.assertRaises(ValueError):v.parse_symvers(p)
    def test_10_symvers_duplicate_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'sym';p.write_text('0x12345678\tx\tvmlinux\tEXPORT_SYMBOL\t\n0x12345678\tx\tvmlinux\tEXPORT_SYMBOL\t\n')
            with self.assertRaises(ValueError):v.parse_symvers(p)
    def test_11_bad_crc_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'sym';p.write_text('0xff\tx\tvmlinux\tEXPORT_SYMBOL\t\n')
            with self.assertRaises(ValueError):v.parse_symvers(p)
    def test_12_unrecognized_export_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'sym';p.write_text('0x12345678\tx\tvmlinux\tDANGER_EXPORT\t\n')
            with self.assertRaises(ValueError):v.parse_symvers(p)
    def test_13_unrecognized_vendor_path_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'im.csv';p.write_text('path,symbol,module_crc\n/data/adb/x.ko,x,0x12345678\n')
            with self.assertRaises(ValueError):v.parse_imports(p,False)
    def test_14_import_count_tampering_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'im.csv';p.write_text('path,symbol,module_crc\n/vendor/lib/modules/x.ko,x,0x12345678\n')
            with self.assertRaises(ValueError):v.parse_imports(p,True)
    def test_15_duplicate_config_fail_closed(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'c';p.write_text('CONFIG_MODVERSIONS=y\n# CONFIG_MODVERSIONS is not set\n')
            with self.assertRaises(ValueError):v.parse_config(p)
    def test_16_invalid_modversions_blocked(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'c';p.write_text('CONFIG_MODVERSIONS=n\n')
            with self.assertRaises(ValueError):v.run(self.im,self.sy,self.sy,self.cf,p)
    def test_17_modified_provenance_detected(self):
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'im.csv'
            with self.im.open(newline='') as f, p.open('w',newline='') as o:
                r=csv.DictReader(f);w=csv.DictWriter(o,fieldnames=r.fieldnames);w.writeheader()
                for k,x in enumerate(r):
                    if k==0:x['module_crc']='0x00000000'
                    w.writerow(x)
            with self.assertRaises(ValueError):v.run(p,self.sy,self.sy,self.cf,self.cf)
    def test_18_comparison_never_infers_green(self):
        res=v.summarize([{'group':'GKI','path':'/vendor/lib/modules/5.4-gki/a.ko','symbol':'foo','crc':'0x11111111'}],{'foo':{'crc':'0x11111111'}})
        self.assertEqual(res['totals'],{'MATCH':1})
    def test_19_synthetic_candidate_crc_improvement(self):
        im=[{'group':'GKI','path':'/vendor/lib/modules/5.4-gki/a.ko','symbol':'foo','crc':'0x11111111'}]
        bad=v.summarize(im,{'foo':{'crc':'0x22222222'}})
        good=v.summarize(im,{'foo':{'crc':'0x11111111'}})
        self.assertEqual(bad['totals']['CRC_MISMATCH'],1)
        self.assertEqual(good['totals']['MATCH'],1)
    def test_20_missing_symbols_not_overlooked(self):
        im=[{'group':'QGKI','path':'/vendor/lib/modules/a.ko','symbol':'xyz','crc':'0x11111111'}]
        self.assertEqual(v.summarize(im,{})['totals']['NOT_EXPORTED'],1)

if __name__=='__main__': unittest.main(verbosity=2)
