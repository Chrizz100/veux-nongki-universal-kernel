import hashlib,json,stat,sys,tempfile,unittest,subprocess
from pathlib import Path
from types import SimpleNamespace
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
import r59_postcheck as p

class R60PostcheckTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        r=Path(self.temp.name)
        self.source=r/'src';self.objects=r/'obj';self.reports=r/'reports'
        for folder in (self.source,self.objects,self.reports):folder.mkdir()
        self.host={'status':'FOUR_NATIVE54_SELINUX_HOST_FILES_STAGED_FOR_REAL_COMPILER','updated_host_files':{}}
        for rel in p.HOST_FILES:
            b=(rel*20).encode();src=self.source/rel;src.parent.mkdir(parents=True,exist_ok=True);src.write_bytes(b)
            self.host['updated_host_files'][rel]={'postimage_sha256':hashlib.sha256(b).hexdigest()}
            obj=self.objects/rel.replace('.c','.o');obj.parent.mkdir(parents=True,exist_ok=True);obj.write_bytes(b'\x00'*128)
        self.kernel={'native54_sus_type_hash_collision_guard':True, 'compile_link_proof':True,'RMNET_132_CRC_proven':True,'RMNET_132_matched':132,
           'R13_original_image_reused':False,'gates':{k:True for k in ('CONFIG_SCHED_CASS','CONFIG_MODVERSIONS','CONFIG_MODULES','CONFIG_KSU','CONFIG_KSU_SUSFS','CONFIG_NOMOUNT','WALT_OFF')}}
        self.vendor={'original_vendor_file_count':218,'candidate':{'totals':{'MATCH':6286,'CRC_MISMATCH':7827,'NOT_EXPORTED':535},
           'groups':{'QGKI':{'MATCH':1303,'CRC_MISMATCH':1752,'NOT_EXPORTED':93},
                     'GKI':{'MATCH':4983,'CRC_MISMATCH':6075,'NOT_EXPORTED':442}}}}
        (self.objects/'vmlinux').write_bytes(b'A'*1024)
        nm=self.objects/'llvm-nm'
        nm.write_text('#!/bin/sh\ncat "'+str(self.objects/'nm_output')+'"\n')
        nm.chmod(nm.stat().st_mode|stat.S_IXUSR)
        self.nm=nm
        (self.objects/'nm_output').write_text(''.join('00000000 T '+s+'\n' for s in p.REQUIRED))
        self.save()
    def save(self):
        (self.reports/'R59_HOST_STATUS.json').write_text(json.dumps(self.host))
        (self.reports/'R58_COMPILE_STATUS.json').write_text(json.dumps(self.kernel))
        (self.reports/'vendor.json').write_text(json.dumps(self.vendor))
    def run_check(self):
        args=SimpleNamespace(source=self.source,objects=self.objects,report=self.reports,nm=self.nm,vendor_report=self.reports/'vendor.json')
        return p.run(args)
    def test_01_valid_compile_vs_unproven_abi(self):
        self.assertEqual(self.run_check(),0)
        d=json.loads((self.reports/'R59_FULL_INTEGRATION_EVIDENCE.json').read_text())
        self.assertTrue(d['source_and_compiler_pass']);self.assertFalse(d['oem_abi_green']);self.assertFalse(d['flash_allowed'])
    def test_02_missing_link_symbol_blocked(self):
        (self.objects/'nm_output').write_text(''.join('00000000 T '+s+'\n' for s in p.REQUIRED[:-1]))
        self.assertEqual(self.run_check(),3)
    def test_03_postimage_mutation_blocked(self):
        (self.source/p.HOST_FILES[0]).write_bytes(b'UNEXPECTED SOURCE')
        with self.assertRaises(p.GateError):self.run_check()
    def test_04_missing_host_object_blocked(self):
        (self.objects/p.HOST_FILES[1].replace('.c','.o')).unlink()
        with self.assertRaises(p.GateError):self.run_check()
    def test_05_missing_abi_imports_blocked(self):
        self.vendor['candidate']['totals']['MATCH']-=1;self.save()
        with self.assertRaises(p.GateError):self.run_check()
    def test_06_config_unproven_blocked_under_python_optimized(self):
        self.kernel['gates']['CONFIG_MODULES']=False;self.save()
        cp=subprocess.run([sys.executable,'-O',str(BASE/'tools/r59_postcheck.py'),
            '--source',str(self.source),'--objects',str(self.objects),'--report',str(self.reports),
            '--nm',str(self.nm),'--vendor-report',str(self.reports/'vendor.json')],capture_output=True,text=True)
        self.assertEqual(cp.returncode,3);self.assertIn('REQUIRED_KCONFIG_NOT_PROVEN',cp.stderr)
    def test_07_wrong_symbol_name_blocked(self):
        (self.objects/'nm_output').write_text(''.join('00000000 T prefix_'+s+'\n' for s in p.REQUIRED))
        self.assertEqual(self.run_check(),3)
    def test_08_missing_sus_type_hash_correction_is_blocked(self):
        self.kernel['native54_sus_type_hash_collision_guard']=False;self.save()
        with self.assertRaises(p.GateError):self.run_check()
    def test_09_hidden_fake_host_proof_fails(self):
        self.host['updated_host_files'].pop(p.HOST_FILES[0]);self.save()
        with self.assertRaises(p.GateError):self.run_check()
