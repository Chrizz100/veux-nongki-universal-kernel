import sys
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tools'))
import r60_config_guard as guard

class ConfigGuardTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reference=guard.parse_config(ROOT/'refs/R13_BUILD.config')
        cls.assert_baseline=cls.reference

    def test_01_real_reference(self):
        self.assertGreater(len(self.reference),1000)
        self.assertEqual(guard.compare(self.reference,self.reference)['result'], 'R13_ALL_EXISTING_FLAGS_PRESERVED')

    def test_02_exact_denylist_case(self):
        candidate={**self.reference,'CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER':'n'}
        outcome=guard.compare(self.reference,candidate)
        self.assertTrue(outcome['all_baseline_options_unchanged'])
        self.assertEqual(outcome['allowed_new_disabled_ksu_options']['CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER'],'n')

    def test_03_existing_option_change_rejected(self):
        candidate={**self.reference,'CONFIG_LOCALVERSION':'"-nope"'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_04_switch_off_modules_rejected(self):
        candidate={**self.reference,'CONFIG_MODULES':'n'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_05_switch_on_walt_rejected(self):
        candidate={**self.reference,'CONFIG_SCHED_WALT':'y'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_06_new_enabled_option_rejected(self):
        candidate={**self.reference,'CONFIG_KSU_X86_PATCH_SYSCALL_DISPATCHER':'y'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_07_unknown_new_ksu_option_rejected(self):
        candidate={**self.reference,'CONFIG_KSU_SKIP_ALL_KERNEL_CHECKS':'n'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_08_unknown_new_vendor_option_rejected(self):
        candidate={**self.reference,'CONFIG_SUSFS_SKIP_KERNEL_GATE':'n'}
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_09_removed_baseline_flag_rejected(self):
        candidate=dict(self.reference); candidate.pop('CONFIG_KSU')
        with self.assertRaises(guard.ConfigurationError): guard.compare(self.reference,candidate)

    def test_10_dup_config_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'c'
            p.write_text((ROOT/'refs/R13_BUILD.config').read_text()+'\nCONFIG_KSU=y\n')
            with self.assertRaises(guard.ConfigurationError): guard.parse_config(p)

    def test_11_cli_real_config(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            result=subprocess.run([sys.executable,'-O',str(ROOT/'tools/r60_config_guard.py'),
                '--baseline',str(ROOT/'refs/R13_BUILD.config'),
                '--actual',str(ROOT/'refs/R13_BUILD.config'),
                '--out',str(d/'result.json')],capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('R13_ALL_EXISTING_FLAGS_PRESERVED',(d/'result.json').read_text())

    def test_12_semantic_not_byte_identity_is_recorded(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            modified=d/'reordered.config'
            modified.write_text((ROOT/'refs/R13_BUILD.config').read_text()+'\n# harmless comment\n')
            result=subprocess.run([sys.executable,str(ROOT/'tools/r60_config_guard.py'),
                '--baseline',str(ROOT/'refs/R13_BUILD.config'),
                '--actual',str(modified), '--out',str(d/'result.json')],
                capture_output=True,text=True)
            self.assertEqual(result.returncode,0,result.stderr)
            import json
            data=json.loads((d/'result.json').read_text())
            self.assertFalse(data['original_config_byte_equal'])
            self.assertTrue(data['all_baseline_options_unchanged'])

    def test_13_cli_duplicate_output_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);(d/'result.json').write_text('{}')
            result=subprocess.run([sys.executable,str(ROOT/'tools/r60_config_guard.py'),
                '--baseline',str(ROOT/'refs/R13_BUILD.config'),
                '--actual',str(ROOT/'refs/R13_BUILD.config'),
                '--out',str(d/'result.json')],capture_output=True,text=True)
            self.assertEqual(result.returncode,3)

if __name__=='__main__':unittest.main()
