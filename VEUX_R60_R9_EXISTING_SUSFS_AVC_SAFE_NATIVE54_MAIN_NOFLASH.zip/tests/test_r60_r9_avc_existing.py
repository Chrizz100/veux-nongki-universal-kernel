"""R9: regression tests for an ALREADY-PATCHED genuine R13 SUSFS AVC hook.

The real 33,681 byte R13 avc.c was independently reconstructed from the
pinned dereference23 tree + JackA1ltman SUSFS-5.4 patch and its SHA-256
was confirmed separately. These fixtures test the isolated replacement
contract; they are not falsely presented as a full kernel compiler test.
"""
import hashlib
import json
import sys
from pathlib import Path
import unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import r59_host as host

# Faithful relevant excerpt from JackA1ltman 5.4 patch, including externs.
AVC_R13_EXISTING='''
#ifdef CONFIG_KSU_SUSFS
extern u32 susfs_ksu_sid;
extern u32 susfs_priv_app_sid;
extern struct static_key_false susfs_is_avc_log_spoofing_enabled;
#endif
static void avc_audit_post_callback(struct audit_buffer *ab, void *a)
{
	rc = security_sid_to_context(sad->state, sad->tsid, &scontext,
				     &scontext_len);
#ifdef CONFIG_KSU_SUSFS
	if (static_branch_likely(&susfs_is_avc_log_spoofing_enabled)) {
		if (unlikely(sad->tsid == susfs_ksu_sid)) {
			if (rc)
				audit_log_format(ab, " tsid=%d", susfs_priv_app_sid);
			else
				audit_log_format(ab, " tcontext=%s", "u:r:priv_app:s0:c512,c768");
			goto bypass_orig_flow;
		}
	}
#endif
	if (rc)
		audit_log_format(ab, " tsid=%d", sad->tsid);
	else {
		audit_log_format(ab, " tcontext=%s", scontext);
		kfree(scontext);
	}
#ifdef CONFIG_KSU_SUSFS
bypass_orig_flow:
#endif
	audit_log_format(ab, " tclass=%s", secclass_map[sad->tclass-1].name);
}
'''

class R9AlreadyPatchedAVCTests(unittest.TestCase):
    def edit(self,source=AVC_R13_EXISTING):
        # Only the unit fixture's exact known bytes get this temporary pin.
        # The production R13 pinned SHA is never substituted at runtime.
        with patch.dict(host.R13_HOST_SHA256, {'security/selinux/avc.c':host.sha256(source.encode())}):
            return host.port_avc(source)
    def test_01_proven_real_r13_digest_pinned_in_code(self):
        self.assertEqual(host.R13_HOST_SHA256['security/selinux/avc.c'],
          '785f2de8539906bad413e4f15e34f59c36873ec09d6bd4ececb66e8721a304e9')
        p=json.loads((ROOT/'refs/R60_R9_AVC_EXISTING_SOURCE_PROOF.json').read_text())
        self.assertEqual(p['sha256_after_external_54_patch'],host.R13_HOST_SHA256['security/selinux/avc.c'])
        self.assertFalse(p['kernel_compiled'])
        self.assertFalse(p['flash_allowed'])
    def test_02_existing_hook_upgraded_instead_of_double_insert(self):
        s=self.edit()
        self.assertEqual(s.count('extern u32 susfs_ksu_sid;'),1)
        self.assertEqual(s.count('bypass_orig_flow:'),1)
        self.assertEqual(s.count('susfs_is_avc_log_spoofing_enabled'),2)
        self.assertEqual(s.count('avc_audit_post_callback('),1)
    def test_03_successful_conversion_releases_context_before_bypass(self):
        s=self.edit()
        block=s.split('static_branch_unlikely',1)[1].split('goto bypass_orig_flow',1)[0]
        self.assertEqual(block.count('kfree(scontext);'),1)
        self.assertIn('else {',block)
        self.assertLess(block.index('audit_log_format(ab, " tcontext=%s"'),block.index('kfree(scontext);'))
    def test_04_failed_conversion_does_not_free_uninitialized_context(self):
        s=self.edit()
        branch=s.split('if (rc)',1)[1].split('goto bypass_orig_flow',1)[0]
        self.assertLess(branch.index('else {'),branch.index('kfree(scontext);'))
    def test_05_missing_sid_cache_does_not_spoof(self):
        s=self.edit()
        self.assertIn('susfs_ksu_sid && susfs_priv_app_sid &&',s)
        self.assertIn('sad->tsid == susfs_ksu_sid',s)
    def test_06_compiled_false_key_uses_unlikely(self):
        s=self.edit()
        self.assertIn('static_branch_unlikely(&susfs_is_avc_log_spoofing_enabled)',s)
        self.assertNotIn('static_branch_likely(&susfs_is_avc_log_spoofing_enabled)',s)
    def test_07_core_audit_decision_and_original_cleanup_preserved(self):
        s=self.edit()
        self.assertIn('audit_log_format(ab, " tsid=%d", sad->tsid);',s)
        self.assertIn('audit_log_format(ab, " tclass=%s", secclass_map[sad->tclass-1].name)',s)
        self.assertNotIn('avd->allowed',s)
        self.assertEqual(s.count('kfree(scontext);'),AVC_R13_EXISTING.count('kfree(scontext);')+1)
    def test_08_no_unexpected_bytes_outside_one_verified_replacement(self):
        s=self.edit()
        before=AVC_R13_EXISTING.split('static_branch_likely',1)[0]
        after=AVC_R13_EXISTING.split('goto bypass_orig_flow;',1)[1]
        self.assertTrue(s.startswith(before))
        self.assertTrue(s.endswith(after))
    def test_09_unpinned_existing_patch_refused_by_default(self):
        with self.assertRaisesRegex(host.GateError,'INPUT_NOT_AUTHENTIC_R13'):
            host.port_avc(AVC_R13_EXISTING)
    def test_10_unknown_mutation_stays_blocked_even_test_pin(self):
        with patch.dict(host.R13_HOST_SHA256,{'security/selinux/avc.c':host.sha256(AVC_R13_EXISTING.encode())}):
            with self.assertRaisesRegex(host.GateError,'INPUT_NOT_AUTHENTIC_R13'):
                host.port_avc(AVC_R13_EXISTING+'\n// surprise change')
    def test_11_duplicate_label_blocked(self):
        s=AVC_R13_EXISTING.replace('bypass_orig_flow:', 'bypass_orig_flow:\nbypass_orig_flow:')
        with patch.dict(host.R13_HOST_SHA256,{'security/selinux/avc.c':host.sha256(s.encode())}):
            with self.assertRaisesRegex(host.GateError,'HOOK_MALFORMED'):
                host.port_avc(s)
    def test_12_missing_existing_hook_blocked(self):
        s=AVC_R13_EXISTING.replace('goto bypass_orig_flow;','goto no_such_label;')
        with patch.dict(host.R13_HOST_SHA256,{'security/selinux/avc.c':host.sha256(s.encode())}):
            with self.assertRaisesRegex(host.GateError,'EXISTING_HOOK'):
                host.port_avc(s)
    def test_13_double_application_not_accepted(self):
        candidate=self.edit()
        with patch.dict(host.R13_HOST_SHA256,{'security/selinux/avc.c':host.sha256(candidate.encode())}):
            with self.assertRaises(host.GateError):host.port_avc(candidate)
    def test_14_original_5_4_pristine_fallback_remains(self):
        from test_r59_host import AVC
        candidate=host.port_avc(AVC)
        self.assertIn('susfs_is_avc_log_spoofing_enabled',candidate)
        self.assertNotIn('bypass_orig_flow',candidate)
    def test_15_no_unverified_legacy_patch_applied(self):
        code=(ROOT/'tools/r59_host.py').read_text()
        self.assertIn("sha256(text.encode()) == R13_HOST_SHA256['security/selinux/avc.c']",code)
        self.assertNotIn('patch -p1',code)
        self.assertNotIn('git apply --reject',code)

if __name__=='__main__':unittest.main()
