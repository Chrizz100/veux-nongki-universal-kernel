#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import io
import os
from pathlib import Path
import random
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
import veux_r60_clang_transport as b


def create_fake_tar(path: Path, *, traversal=False, damaged=False):
    rng=random.Random(47)
    with tarfile.open(path,"w:gz",compresslevel=1) as z:
        content=b'12.0.5\nbased on r416183b\n'
        version=tarfile.TarInfo('AndroidVersion.txt');version.size=len(content)
        z.addfile(version,io.BytesIO(content))
        for name in sorted(b.TOOLS):
            body=(name + '\n').encode()
            info=tarfile.TarInfo(name)
            info.size=len(body)
            info.mode=0o755
            z.addfile(info,io.BytesIO(body))
        info=tarfile.TarInfo('../../danger' if traversal else 'lib/libplaceholder.so')
        # 1.5 MiB of deterministic non-compressible data for size threshold.
        rand = rng.randbytes(1_700_000)
        info.size=len(rand);info.mode=0o644
        z.addfile(info,io.BytesIO(rand))
    if damaged:
        data=path.read_bytes();path.write_bytes(data[:100])
    return path


class TransportTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='r60-test-')
        self.addCleanup(self.temp.cleanup)
        self.base=Path(self.temp.name)
        self.cache=self.base/'veux-r60-clang-cache';self.cache.mkdir()
        self.fixture=create_fake_tar(self.base/'fixture.tar.gz')
        self.assertGreater(self.fixture.stat().st_size,1_000_000)

    def test_real_original_engine_hash_is_pinned(self):
        # Independent exact GitHub content-API blob SHA verified for pinned
        # repository commit 96d2a1148d708e7fa9de634b85f60b1f303477e3.
        expected = "1b59c48392fa63af9640dce47b111057ab237b31"
        self.assertEqual(len(expected), 40)
        self.assertEqual(len(b.ENGINE_GIT_BLOB), 40)
        self.assertEqual(b.ENGINE_GIT_BLOB, expected)
        # On the real Actions checkout, verify the ACTUAL bytes too; do not
        # rely on GitHub metadata, a fixture, or an arbitrary 40-char value.
        repo_root=os.environ.get("GITHUB_WORKSPACE")
        if repo_root:
            candidate=Path(repo_root)/"common/scripts/veux_update_engine.py"
            self.assertTrue(candidate.is_file() and not candidate.is_symlink())
            data=candidate.read_bytes()
            real=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
            self.assertEqual(real, expected)
            with patch.dict(os.environ,{"VEUX_R60_REPO":str(repo_root)}):
                self.assertEqual(b.original_engine().resolve(),candidate.resolve())

    def test_original_engine_guard_accepts_real_sha_and_rejects_false_sha(self):
        root=self.base/"mockrepo";root.mkdir();(root/".git").mkdir()
        src=root/"common"/"scripts"/"veux_update_engine.py"
        src.parent.mkdir(parents=True)
        src.write_text("# independently reconstructed fixture\n")
        data=src.read_bytes()
        correct=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        with patch.dict(os.environ,{"VEUX_R60_REPO":str(root)}):
            with patch.object(b,"ENGINE_GIT_BLOB",correct):
                self.assertEqual(b.original_engine(),src)
            with patch.object(b,"ENGINE_GIT_BLOB",correct[:-1]):
                with self.assertRaisesRegex(b.PinError,"ORIGINAL_SOURCE_ENGINE_GIT_BLOB_CHANGED"):
                    b.original_engine()
            with patch.object(b,"ENGINE_GIT_BLOB","0"*40):
                with self.assertRaisesRegex(b.PinError,"ORIGINAL_SOURCE_ENGINE_GIT_BLOB_CHANGED"):
                    b.original_engine()

    def test_valid_archive_accepts_realistic_tool_names(self):
        b.validate_archive(self.fixture)

    def test_mismatched_android_version_pin_rejected(self):
        path=self.base/'mismatched.tar.gz'
        with tarfile.open(path, 'w:gz', compresslevel=1) as z:
            v=b'clang-other\n'
            ti=tarfile.TarInfo('AndroidVersion.txt');ti.size=len(v)
            z.addfile(ti, io.BytesIO(v))
            for name in b.TOOLS:
                ti=tarfile.TarInfo(name);ti.size=3
                z.addfile(ti,io.BytesIO(b'foo'))
            rng=random.Random(97).randbytes(1_700_000)
            ti=tarfile.TarInfo('lib/random');ti.size=len(rng)
            z.addfile(ti,io.BytesIO(rng))
        with self.assertRaisesRegex(b.PinError, 'VERSION_GIT_BLOB_CHANGED'):
            b.validate_archive(path)

    def test_corrupted_archive_rejected(self):
        corrupt=create_fake_tar(self.base/'damaged.gz',damaged=True)
        with self.assertRaises((tarfile.TarError,EOFError,OSError,b.PinError)):
            b.validate_archive(corrupt)

    def test_archive_traversal_rejected(self):
        path=create_fake_tar(self.base/'traversal.tar.gz',traversal=True)
        with self.assertRaisesRegex(b.PinError,'TRAVERSAL'):
            b.validate_archive(path)

    def test_cdn_failure_next_pinned_source_success_and_cache_reuse(self):
        urls=[]
        def fetch(url,out):
            urls.append(url)
            if len(urls)==1:raise b.PinError('sample HTTP 503')
            out.write_bytes(self.fixture.read_bytes());b.validate_archive(out)
        with patch.object(b,'try_cdn',side_effect=fetch),patch.object(b,'try_git_tree',side_effect=AssertionError('git should be unused')):
            archive=b.obtain_tar(self.cache)
            self.assertEqual(archive.read_bytes(),self.fixture.read_bytes())
            self.assertEqual(urls,list(b.AOSP_URLS[:2]))
            receipt=(self.cache/(b.VERSION+'.sha256')).read_text().strip()
            self.assertEqual(receipt, hashlib.sha256(self.fixture.read_bytes()).hexdigest())
            self.assertEqual(b.obtain_tar(self.cache),archive)
            self.assertEqual(len(urls),2)

    def test_all_cdn_fail_verified_git_fallback(self):
        calls=[]
        def git(remote,out):
            calls.append(remote);out.write_bytes(self.fixture.read_bytes());b.validate_archive(out)
        with patch.object(b,'try_cdn',side_effect=b.PinError('offline')),patch.object(b,'try_git_tree',side_effect=git):
            self.assertTrue(b.obtain_tar(self.cache).is_file())
        self.assertEqual(calls,list(b.GIT_REMOTES[:1]))

    def test_all_sources_fail_closed_without_archive(self):
        with patch.object(b,'try_cdn',side_effect=b.PinError('offline')),patch.object(b,'try_git_tree',side_effect=b.PinError('offline')):
            with self.assertRaisesRegex(b.PinError,'ALL_PINNED_CLANG_TRANSPORTS_FAILED'):
                b.obtain_tar(self.cache)
        self.assertFalse((self.cache/(b.VERSION+'.tar.gz')).exists())

    def test_cache_corruption_blocks_without_redownloading(self):
        arc=self.cache/(b.VERSION+'.tar.gz');arc.write_bytes(self.fixture.read_bytes())
        receipt=self.cache/(b.VERSION+'.sha256');receipt.write_text(b.sha256(arc)+'\n')
        arc.write_bytes(b'changed contents')
        with patch.object(b,'try_cdn',side_effect=AssertionError('should not network')):
            with self.assertRaisesRegex(b.PinError,'CACHE_TAMPERED'):b.obtain_tar(self.cache)

    def test_missing_cache_pair_blocks_not_silently_refetch(self):
        (self.cache/(b.VERSION+'.sha256')).write_text('x'*64)
        with self.assertRaisesRegex(b.PinError,'CACHED_FILES_INCOMPLETE'):b.obtain_tar(self.cache)

    def test_output_path_guard_and_symlink(self):
        work=self.base/'source';work.mkdir();transport=self.base/'transport';transport.mkdir()
        env={'VEUX_SOURCE_WORK':str(work),'VEUX_TRANSPORT_WORK':str(transport)}
        with patch.dict(os.environ,env):
            p=work/'clang.tar.gz'
            self.assertEqual(b.safe_output_arg(['--fail',b.PIN_URL,'-o',str(p)]),p)
            with self.assertRaisesRegex(b.PinError,'ESCAPES'):b.safe_output_arg(['-o',str(self.base/'outside.tar.gz')])
            p.symlink_to(self.fixture)
            with self.assertRaisesRegex(b.PinError,'ALREADY_EXISTS'):b.safe_output_arg(['-o',str(p)])

    def test_cache_location_guard(self):
        bad=self.base/'bad';bad.mkdir()
        with patch.dict(os.environ,{'VEUX_R60_BASE_TEMP':str(self.base),'VEUX_R60_CLANG_CACHE_DIR':str(bad)}):
            with self.assertRaisesRegex(b.PinError,'OUTSIDE_RUNNER_TEMP'):b.safe_cache_dir()
        with patch.dict(os.environ,{'VEUX_R60_BASE_TEMP':str(self.base),'VEUX_R60_CLANG_CACHE_DIR':str(self.cache)}):
            self.assertEqual(b.safe_cache_dir(),self.cache)

    def test_nonpinned_command_passed_to_unmodified_engine(self):
        recorded=[]
        with patch.object(b,'delegate_to_original',side_effect=lambda x:recorded.append(x)):
            b.transport_curl(['--','-o','foo','https://example.com/one'])
        self.assertEqual(recorded, [['transport-curl','--','-o','foo','https://example.com/one']])

    def test_unknown_command_delegated(self):
        with patch.object(b,'delegate_to_original') as old:
            b.main(['capture-make','--','O=/tmp/build','Image'])
        old.assert_called_once_with(['capture-make','--','O=/tmp/build','Image'])

    def test_real_git_archive_tree_pins_and_tamper_rejection(self):
        src=self.base/'upstream';src.mkdir()
        subprocess.run(['git','init','-q',str(src)],check=True)
        subprocess.run(['git','-C',str(src),'config','user.name','Test'],check=True)
        subprocess.run(['git','-C',str(src),'config','user.email','test@example.invalid'],check=True)
        dst=src/b.VERSION;dst.mkdir()
        (dst/'AndroidVersion.txt').write_text('12.0.5\nbased on r416183b\n')
        for name in b.TOOLS:
            p=dst/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(name.encode())
        (dst/'lib').mkdir();(dst/'lib'/'data').write_bytes(self.fixture.read_bytes())
        subprocess.run(['git','-C',str(src),'add','.'],check=True)
        subprocess.run(['git','-C',str(src),'commit','-qm','fixture'],check=True)
        sha=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()
        root=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD^{tree}'],text=True).strip()
        subtree=subprocess.check_output(['git','-C',str(src),'rev-parse',f'HEAD:{b.VERSION}'],text=True).strip()
        real=b.PIN_ROOT_TREE
        with patch.object(b,'PIN_COMMIT',sha),patch.object(b,'PIN_ROOT_TREE',root),patch.object(b,'PIN_CLANG_TREE',subtree),patch.object(b,'GIT_REMOTES',(str(src),)):
            dest=self.base/'from-git.tar.gz';b.try_git_tree(str(src),dest);b.validate_archive(dest)
            with patch.object(b,'PIN_CLANG_TREE','0'*40):
                with self.assertRaisesRegex(b.PinError,'SUBTREE_MISMATCH'):
                    b.try_git_tree(str(src),self.base/'wrong.tar.gz')

    def test_real_child_worker_command_redirected_not_other_subprocesses(self):
        script_dir=self.base/'dummychild';script_dir.mkdir()
        fake_engine=script_dir/'veux_update_engine.py'
        fake_engine.write_text('from pathlib import Path\nHERE=Path(__file__)\n')
        worker=script_dir/'release_worker_selinux_r3.py';worker.write_text('pass\n')
        legacy=script_dir/'parent.py'
        legacy.write_text('import subprocess,sys,os\nsubprocess.run([sys.executable,"-u",os.environ["TEST_R60_WORKER"],"worker","--kernel","5.4.274"])\nsubprocess.run(["true"])\n')
        from unittest.mock import Mock
        recorded=[]
        def record(argv,*args,**kwargs):
            recorded.append(argv)
            return Mock(returncode=0)
        oldpath=sys.path[:]
        prior=sys.modules.pop('veux_update_engine',None)
        try:
            with patch.object(b,'original_engine',return_value=fake_engine), patch.object(b.subprocess,'run',side_effect=record), patch.dict(os.environ,{'TEST_R60_WORKER':str(worker),'VEUX_R60_BASE_TEMP':str(self.base)}):
                b.launch_legacy([str(legacy)])
        finally:
            sys.path[:]=oldpath
            sys.modules.pop('veux_update_engine',None)
            if prior is not None:sys.modules['veux_update_engine']=prior
        self.assertEqual(recorded[0][0],sys.executable)
        self.assertEqual(recorded[0][1:4],['-B','-u',str(Path(b.__file__).resolve())])
        self.assertEqual(recorded[0][4:7],['launch',str(worker),'worker'])
        self.assertEqual(recorded[1],['true'])

    def test_untrusted_child_worker_outside_root_rejected(self):
        script_dir=self.base/'dummyexternal';script_dir.mkdir()
        fake_engine=script_dir/'veux_update_engine.py'
        fake_engine.write_text('from pathlib import Path\nHERE=Path(__file__)\n')
        worker=script_dir/'release_worker_selinux_r3.py';worker.write_text('pass\n')
        legacy=script_dir/'parent.py'
        legacy.write_text('import subprocess,sys,os\nsubprocess.run([sys.executable,"-u",os.environ["TEST_R60_WORKER"],"worker"])\n')
        safe_dir=self.base/'safe';safe_dir.mkdir()
        oldpath=sys.path[:]
        prior=sys.modules.pop('veux_update_engine',None)
        try:
            with patch.object(b,'original_engine',return_value=fake_engine), patch.dict(os.environ,{'TEST_R60_WORKER':str(worker),'VEUX_R60_BASE_TEMP':str(safe_dir)}):
                with self.assertRaisesRegex(b.PinError,'OUTSIDE_VERIFIED_TEMP'):
                    b.launch_legacy([str(legacy)])
        finally:
            sys.path[:]=oldpath
            sys.modules.pop('veux_update_engine',None)
            if prior is not None:sys.modules['veux_update_engine']=prior

    def test_legacy_launcher_temporarily_redirects_only_curl_wrapper(self):
        script_dir=self.base/'dummy';script_dir.mkdir()
        fake_engine=script_dir/'veux_update_engine.py'
        fake_engine.write_text('from pathlib import Path\nHERE=Path(__file__)\n')
        legacy=script_dir/'old.py'
        legacy.write_text('import veux_update_engine\nassert veux_update_engine.HERE.name=="veux_r60_clang_transport.py"\n')
        oldpath=sys.path[:]
        prior=sys.modules.pop('veux_update_engine',None)
        try:
            with patch.object(b,'original_engine',return_value=fake_engine):
                b.launch_legacy([str(legacy)])
        finally:
            sys.path[:]=oldpath
            sys.modules.pop('veux_update_engine',None)
            if prior is not None:sys.modules['veux_update_engine']=prior

if __name__=='__main__':
    unittest.main(verbosity=2)
