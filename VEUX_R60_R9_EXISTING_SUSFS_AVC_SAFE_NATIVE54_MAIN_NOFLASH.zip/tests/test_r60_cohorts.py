import tempfile,unittest,csv,sys,json
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
import r60_abi_cohorts as a

class R60CohortTests(unittest.TestCase):
    def test_01_real_file_pin(self):
        self.assertEqual(a.digest(BASE/'refs/R21_IMPORTS.csv'),a.IMPORT_SHA256)
    def test_02_real_oem_conflict(self):
        d=a.summarize(a.read_rows(BASE/'refs/R21_IMPORTS.csv'))
        self.assertEqual(d['conflicting_symbol_names'],836)
        self.assertEqual(d['historical_imports'],14648)
    def test_03_37_181_files(self):
        d=a.summarize(a.read_rows(BASE/'refs/R21_IMPORTS.csv'))
        self.assertEqual(d['installed_module_files_by_cohort'],{'GKI':181,'QGKI':37})
    def test_04_module_layout_opposite(self):
        d=a.summarize(a.read_rows(BASE/'refs/R21_IMPORTS.csv'))
        s={e['symbol']:e for e in d['conflicting_symbols']}
        self.assertEqual(s['module_layout']['GKI'],'0x1e5b7ab7')
        self.assertEqual(s['module_layout']['QGKI'],'0x945d02f2')
    def test_05_sha_mismatch_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'altered.csv'
            p.write_bytes((BASE/'refs/R21_IMPORTS.csv').read_bytes()+b'\n')
            with self.assertRaises(a.InvalidCohorts):a.read_rows(p)
    def test_06_same_cohort_different_crcs_fail(self):
        with self.assertRaises(a.InvalidCohorts):a.summarize([
          ('GKI','/vendor/lib/modules/5.4-gki/a.ko','foo','0xaaaaaaaa'),
          ('GKI','/vendor/lib/modules/5.4-gki/b.ko','foo','0xbbbbbbbb')],strict=False)
    def test_07_different_cohorts_conflict(self):
        d=a.summarize([('GKI','/vendor/lib/modules/5.4-gki/a.ko','foo','0xaaaaaaaa'),
                       ('QGKI','/vendor/lib/modules/a.ko','foo','0xbbbbbbbb')],strict=False)
        self.assertEqual(d['conflicting_symbol_names'],1)
        self.assertFalse(d['flash_allowed'])
    def test_08_exact_output_required(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'status.json'
            self.assertEqual(a.main(['--imports',str(BASE/'refs/R21_IMPORTS.csv'),'--out',str(p)]),0)
            with self.assertRaises(a.InvalidCohorts):a.main(['--imports',str(BASE/'refs/R21_IMPORTS.csv'),'--out',str(p)])
