#!/usr/bin/env python3
"""R56 immutable source + post-build attestation; NO FLASH.

This tool cannot infer BOOT_READY from a successful diagnostic job. No device
or partition I/O is performed. A kernel with unproved vendor module ABI is
never flash-approved.
"""
import argparse,hashlib,json,os,re,stat,sys,zipfile
from pathlib import Path,PurePosixPath

PINS={
 'R13':'15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1',
 'R41':'e9ea57fc1feb8d4d0e840a61b21174ad1d83d496216794bd9285b40f17026bff',
 'R54':'2e40d3e75d5ce68f19d10a62d54406dab0b5aa5845ee6253830d1d117d1f3bf1',
 'R55':'49deb03175fe5ce8411f76c10c405cc5f3f5b85c52d7c973463bd0bcc147e5ba',
 'R13_BUILD_YAML_GIT_BLOB':'32748cc6ef88263adffdd1060f929a7186a82033',
 'BAKASU_OFFICIAL_HEAD':'516d3e87fbc986ccefdde2c2765f1700612441a9',
 'BAKASU_LOCAL_R13':'d2537b13ab15fce72e8c0d99e7788805f071aeb4',
 'SUSFS_CANDIDATE':'937232ce8c4bdcbe4216e99a1b3d7b5cf633f7c6',
 'JACK_5_4_REFERENCE':'bd505f994e255156e8233c399d6835641423bbf6',
 'MIDORI_QGKI_5_4_REFERENCE':'a6d0fe36e51fe0136fe5733ca42f737d564e6f33',
}
REQUIRED_GATES=(
 'true_bakasu_git_replay',
 'native54_susfs_type_avd_compiled',
 'native54_susfs_headers_and_ksu_registry_compiled',
 'native54_services_avd_hook_compiled',
 'native54_selinux_hooks_and_avc_compat_compiled',
 'no_unresolved_symbols',
 'original_42_regressions_reexecuted',
 'r41_12_contracts_4_negative_reexecuted',
 'all_new_r51_r52_r54_r55_regressions_reexecuted',
 'fresh_kernel_build',
 'fresh_image_vmlinux_dtb_symvers',
 'r13_132_rmnet_abi_checks_reexecuted',
 'updated_bakasu_susfs_version_evidence',
 'r41_ak3_installer_and_hashes_checked',
)
class Rejected(RuntimeError):pass

def need(x,y):
 if not x:raise Rejected(y)

def file_sha(p):
 h=hashlib.sha256();
 with Path(p).open('rb') as f:
  for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
 return h.hexdigest()

def blob(raw):
 return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()

def verify_zip(p,expected,expected_count=None):
 p=Path(p);need(p.is_file() and not p.is_symlink(),'ARCHIVE_MISSING:'+str(p))
 need(file_sha(p)==expected,'ARCHIVE_SHA256_MISMATCH:'+p.name)
 with zipfile.ZipFile(p) as z:
  members=z.infolist();names=[m.filename for m in members]
  need(names and len(set(names))==len(names),'ZIP_DUPLICATES')
  if expected_count is not None:need(len(names)==expected_count,'ZIP_MEMBER_COUNT_CHANGED')
  need(z.testzip() is None,'ZIP_CRC_ERROR')
  need(len(names)<600,'ZIP_TOO_MANY_ENTRIES')
  need(sum(m.file_size for m in members)<200_000_000,'ZIP_EXPANSION_CAP')
  for m in members:
   path=PurePosixPath(m.filename)
   need(path.parts and not path.is_absolute() and '..' not in path.parts and '\\' not in m.filename
     and not m.is_dir() and stat.S_IFMT(m.external_attr>>16) in (0,stat.S_IFREG),'UNSAFE_ZIP_MEMBER:'+m.filename)
 return len(names)

def audit(r13,r41,r54,r55,workflow):
 paths={'R13':r13,'R41':r41,'R54':r54,'R55':r55}
 verified={k:verify_zip(v,PINS[k],{'R13':319,'R41':327,'R54':28,'R55':16}[k]) for k,v in paths.items()}
 need(workflow.is_file() and not workflow.is_symlink(),'R13_WORKFLOW_NOT_FOUND')
 need(blob(workflow.read_bytes())==PINS['R13_BUILD_YAML_GIT_BLOB'],'HISTORICAL_R13_BUILD_WORKFLOW_CHANGED')
 with zipfile.ZipFile(r54) as z:
  m=json.loads(z.read('MANIFEST_SHA256.json'))
  need(m.get('schema')=='VEUX_R54_PAYLOAD_V1' and m.get('flash_allowed') is False,'R54_MANIFEST_INVALID')
  need(set(m['files'])|{'MANIFEST_SHA256.json'}==set(z.namelist()),'R54_MANIFEST_FILE_SET_CHANGED')
  for n,h in m['files'].items():
   need(hashlib.sha256(z.read(n)).hexdigest()==h,'R54_FILE_CHANGED:'+n)
 with zipfile.ZipFile(r55) as z:
  sums=dict((line.strip().split('  ',1)[1],line.strip().split('  ',1)[0]) for line in z.read('SHA256SUMS.txt').decode().splitlines() if '  ' in line)
  need(set(sums)|{'SHA256SUMS.txt'}==set(z.namelist()),'R55_MANIFEST_FILE_SET_CHANGED')
  for n,h in sums.items(): need(hashlib.sha256(z.read(n)).hexdigest()==h,'R55_FILE_CHANGED:'+n)
  proof=json.loads(z.read('receipts/R55_BUILD_GATE.json'))
  need(proof.get('required_not_executed',{}).get('flash_allowed') is False and proof.get('kernel_built') is False,
       'R55_REFERENCE_SHOULD_NOT_CONTAIN_NEW_BUILD')
 with zipfile.ZipFile(r41) as z:
  c=json.loads(z.read('r41/INSTALLER_SOURCE_CONTRACT.json'))
  need(c['flash_allowed'] is False and c['kernel_build'] is False,'R41_CONTRACT_CHANGED')
 return {'schema':'VEUX_R56_INPUT_AUDIT_V1', 'status':'ORIGINALS_AUTHENTICATED__NEW_FULL_INTEGRATION_NOT_PROVEN',
   'verified_zip_members':verified,'r13_workflow_git_blob':PINS['R13_BUILD_YAML_GIT_BLOB'],
   'expected_upstreams':{k:PINS[k] for k in ('BAKASU_OFFICIAL_HEAD','SUSFS_CANDIDATE','JACK_5_4_REFERENCE','MIDORI_QGKI_5_4_REFERENCE')},
   'historical_test_chain_preserved':True, 'new_updated_kernel_built':False,
   'source_integration_complete':False, 'required_new_kernel_gates':list(REQUIRED_GATES),
   'oem_vendor_abi':'BLOCKED','device_boot_test':'NOT_PERFORMED',
   'boot_img_generated':False,'ak3_new_build_checked':False,'flash_allowed':False}

def audit_new_build(folder):
 folder=Path(folder)
 result={'schema':'VEUX_R56_POSTBUILD_GATE_V2','flash_allowed':False,
   'device_boot_test':'NOT_PERFORMED','oem_vendor_abi':'BLOCKED',
   'boot_img_approved':False,'bootloop_guarantee':False}
 proof=folder/'R56_NEW_BUILD_PROOF.json'
 if not proof.is_file():
  result['status']='NO_NEW_KERNEL_BUILD_RECEIPT';return result
 data=json.loads(proof.read_text())
 result['gate_results']={g:data.get('gates',{}).get(g,False) for g in REQUIRED_GATES}
 artifacts=('Image','vmlinux','Module.symvers','veux.dtb','AnyKernel3.zip')
 result['artifacts']={n:{'exists':(folder/n).is_file(),
   'sha256':file_sha(folder/n) if (folder/n).is_file() else None} for n in artifacts}
 status_ok=data.get('status')=='GITHUB_R56_FRESH_UPDATED_CASS_BUILD_COMPILED_AND_VERIFIED'
 source=data.get('source_identity',{})
 source_ok=(bool(re.fullmatch('[0-9a-f]{40}',str(source.get('new_bakasu_git_commit',''))))
   and source.get('new_bakasu_git_commit') not in (PINS['BAKASU_LOCAL_R13'],PINS['BAKASU_OFFICIAL_HEAD'])
   and isinstance(source.get('genuine_git_count'),int) and source['genuine_git_count']>=4560
   and source.get('official_base')==PINS['BAKASU_OFFICIAL_HEAD']
   and source.get('susfs_upstream')==PINS['SUSFS_CANDIDATE']
   and source.get('linux_version')=='5.4.274')
 old_image_sha='434f36efa102262896767734263c104c4a3e5fb028add310783768cca5ee1c37'
 image_ok=(result['artifacts']['Image']['exists'] and
   result['artifacts']['Image']['sha256']!=old_image_sha and
   result['artifacts']['Image']['sha256']==data.get('files',{}).get('Image',{}).get('sha256'))
 all_file_hashes=all(r['exists'] and r['sha256']==data.get('files',{}).get(n,{}).get('sha256')
                      for n,r in result['artifacts'].items())
 result['actual_build_identity_proven']=bool(status_ok and source_ok and image_ok and all_file_hashes)
 result['old_R13_Image_reused']=result['artifacts']['Image']['sha256']==old_image_sha
 complete=all(v is True for v in result['gate_results'].values()) and result['actual_build_identity_proven']
 if complete:
  # Source/build identity is not sufficient to approve an external OEM/ROM boot.
  # No private matching stock boot image is available for actual boot.img checks.
  result['status']='NEW_UPDATED_KERNEL_OFFLINE_GATES_PASS_DEVICE_BOOT_UNTESTED'
 else:
  result['status']='NEW_CANDIDATE_BUILD_NOT_COMPLETE'
 result['flash_allowed']=False
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--r13',type=Path);p.add_argument('--r41',type=Path)
 p.add_argument('--r54',type=Path);p.add_argument('--r55',type=Path)
 p.add_argument('--r13-workflow',type=Path);p.add_argument('--postbuild',type=Path)
 p.add_argument('--out',type=Path,required=True)
 a=p.parse_args()
 try:
  need(a.out.parent.is_dir() and not a.out.exists(),'OUTPUT_MUST_BE_NEW')
  if a.postbuild:row=audit_new_build(a.postbuild)
  else:
   need(all((a.r13,a.r41,a.r54,a.r55,a.r13_workflow)),'SOURCE_ARGUMENTS_MISSING')
   row=audit(a.r13,a.r41,a.r54,a.r55,a.r13_workflow)
  a.out.write_text(json.dumps(row,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
  print(row['status'])
  return 0
 except (Rejected,ValueError,OSError,KeyError,zipfile.BadZipFile) as e:
  print('R56_FAIL_CLOSED='+str(e),file=sys.stderr);return 3
if __name__=='__main__':sys.exit(main())
