VEUX R56 – KERNELBUILD-SCHUTZGATE / AVD/SUSFS/BAKASU
Stand: 01.11.2026. Zweck: GitHub-Quellintegration, Nachweis alter Tests und sichere Build-Vorbereitung.

WARNUNG: DIESES PAKET IST KEIN FLASHBARES KERNELIMAGE UND NOCH KEIN ERFOLGREICHER NEUBUILD.
Der erste GitHub-Lauf wird solange FAIL-CLOSED gesperrt, wie der komplette SUSFS-5.4-
SELinux-/KernelSU-Hook samt echtem Build und 9 OEM-Modul-ABI-Pfaden nicht belegt ist.

INSTALLATION GITHUB:
1. Die eine Datei VEUX_R56_UPDATED_CASS_MAIN.zip unveraendert im Repo-Hauptverzeichnis hochladen.
2. Die YAML nur in .github/workflows/VEUX_R56_UPDATED_CASS_BUILD_GATE_NOFLASH.yml ablegen.
3. In Actions den Workflow manuell starten. Kein Handy-/Termux-Skript, keine Secrets.
4. Erst die CI-Lint-, Quell- und BakaSU-Git-Replay-Berichte auswerten. Kein Flash.

Es werden die bereits im GitHub-Hauptverzeichnis vorhandenen ORIGINALDATEIEN verwendet:
- VEUX_R13_CASS_MAIN.zip (SHA256=15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1)
- VEUX_R41_NOMOUNT_SOURCE_MAIN.zip (SHA256=e9ea57fc1feb8d4d0e840a61b21174ad1d83d496216794bd9285b40f17026bff)
- .github/workflows/VEUX_R13_CASS_BUILD.yml (Git blob 32748cc6ef88263adffdd1060f929a7186a82033)
Diese Dateien NIEMALS ueberschreiben.

QUELLEN:
- Baka-SU/BakaSU 516d3e87fbc986ccefdde2c2765f1700612441a9
- SUSFS GitLab gki-android13-5.10 937232ce8c4bdcbe4216e99a1b3d7b5cf633f7c6
- JackA1ltman/NonGKI_Kernel_Build_2nd bd505f994e255156e8233c399d6835641423bbf6
- midori01/susfs4ksu qgki-android11-5.4 a6d0fe36e51fe0136fe5733ca42f737d564e6f33
- Xiaomi/MiCode veux-r-oss 61397e524093d1ccb94769b5460825e2eaf8871e

ERHALTENE TESTS:
- R12/R13: 42/42 Regressionen, R41: 12/12 Vertrags- und 4/4 Negativtests
- R51: 19/19, R52: 22/22 + 18/18, R54: 44/44, R55: 20/20, R56: 20/20
- Kernel-Compiler/Image, 132 RMNET-CRC, neun OEM-Modulpfade, DTB/DTBO, AK3,
  boot.img und SELinux Runtime sind NACH NEUEM BUILD ERNEUT zu pruefen.

AVD-QUELLSCHRITT:
- R55 enthaelt gepruefte native CASS selinux_hide + BakaSU sepolicy AVD-Deltas.
- R56 enthaelt zusaetzlich einen an das Xiaomi-Quellblob gebundenen
  security/selinux/ss/services.c AVD-Quellpatchgenerator.
- R52/R54 enthalten pruefbare native fs/susfs.c Typ-/AVD-Codevorstufen.
- Die vollstaendige Zusammenfuehrung von security/selinux/hooks.c,
  services.c/ss und KernelSU UAPI/AVD in einem CASS-5.4-Build ist noch NICHT fertig.

BOOTLOOP-GEFAHR:
Offline-/CI-Pruefungen koennen Bootloop-Risiko senken, niemals ausschliessen.
Kein automatischer Flash, kein automatischer Reboot, kein Boot-Image-Ersatz,
keine Veraenderung an BReNE, NoMount, Root-Modulen oder dem Geraet.
Fuer ein neues boot.img braucht es ein autentifiziertes, zum konkreten Geraet/
ROM/Slot passendes Stock-Boot-Image und eine sichere Rueckfallmoeglichkeit.
Keine privaten boot_a-/Logs in das oeffentliche GitHub hochladen.

WICHTIG: Die YAML ist statisch geprueft; OFFIZIELLES actionlint auf EXAKT
DIESEN YAML-BYTES laeuft ZUERST auf dem GitHub-Runner und ist hier lokal
noch nicht nachgewiesen. Bis zu dessen PASS ist dies keine Buildfreigabe.

R56-R3 HOTFIX 02.11.2026: Obsoleten R54 Git-Diff zum alten d253-Commit entfernt, historisch
rekonstruierten Diff SHA256-gesichert. Alle Vorher-Berichte im reports/-Ordner sind historische
Belege; den neuen Hotfix-Testbeleg separat lesen. Kernel wird weiterhin NICHT gebaut/geflasht.
