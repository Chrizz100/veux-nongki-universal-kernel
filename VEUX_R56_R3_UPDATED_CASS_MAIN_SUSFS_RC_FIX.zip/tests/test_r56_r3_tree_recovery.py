from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import unittest
ROOT=Path(__file__).resolve().parents[1]
R54=ROOT/'references/VEUX_R54_CASS_SOURCE_MAIN.zip'
class VerifiedHistory(unittest.TestCase):
 def test_new_runner_uses_reconstructed_immutable_tree(self):
  with ZipFile(R54) as z:s=z.read('tools/r54/R54_GITHUB_REAL_SOURCE_PREBUILD_NOFLASH.sh').decode()
  self.assertIn('r54_verified_port_recovery.py',s)
  self.assertNotIn('LOCAL_PORT_BUNDLE_FETCH',s)
  self.assertNotIn('|| fail BAKASU_DELTA_EXPORT',s)
  self.assertNotIn("'d2537b13ab15fce72e8c0d99e7788805f071aeb4' HEAD -- kernel/",s)
  self.assertIn('test_r54_delta_export.py',s)
 def test_both_historical_tree_hashes_pinned(self):
  with ZipFile(R54) as z:s=z.read('tools/r54/r54_verified_port_recovery.py').decode()
  self.assertIn('47a1e2dda53c5852a5360b9c5be2a815fb7146ce',s)
  self.assertIn('a0fb073cc22c7cba0fce0fff5dfb33e99669cb36',s)
 def test_new_r54_tests_included(self):
  with ZipFile(R54) as z:
   self.assertIn('tests/r54/test_r54_port_recovery.py',z.namelist())
   script=z.read('tools/r54/R54_GITHUB_REAL_SOURCE_PREBUILD_NOFLASH.sh').decode()
  self.assertIn('test_r54_port_recovery.py',script)
  self.assertIn('test_r54_workflow.py',script)
 def test_sha256_references_exact(self):
  import importlib.util
  f=ROOT/'tools/r56_source_gate.py';spec=importlib.util.spec_from_file_location('testhash',f)
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  self.assertEqual(m.PINS['R54'],sha256(R54.read_bytes()).hexdigest())
 def test_still_source_only(self):
  with ZipFile(R54) as z:s=z.read('tools/r54/R54_GITHUB_REAL_SOURCE_PREBUILD_NOFLASH.sh').decode()
  self.assertIn('R54_BUILD_ALLOWED=NO',s)
  self.assertIn('R54_FLASH_ALLOWED=NO',s)
 def test_expected_rc2_is_guarded_in_actual_r54_source(self):
  with ZipFile(R54) as z:s=z.read('tools/r54/R54_GITHUB_REAL_SOURCE_PREBUILD_NOFLASH.sh').decode()
  self.assertIn('if python3 -B "$PAYLOAD/tools/r52/r52_native54_susfs_port.py"',s)
  self.assertIn('R54_SUSFS_EXPECTED_PARTIAL_RC2=PASS',s)
  self.assertIn('R54_SUSFS_UNEXPECTED_EXIT=',s)
  self.assertIn('R54_SUSFS_STDOUT.txt',s)
  self.assertNotIn('\nRC=$?\nset -e\n',s)
 def test_nested_r54_regression_fixtures_cover_all_exit_codes(self):
  with ZipFile(R54) as z:t=z.read('tests/r54/test_r54_delta_export.py').decode()
  for name in ('test_05_expected_rc2_reaches_following_step',
               'test_06_zero_rc_is_not_misreported_as_partial',
               'test_07_actual_rc3_is_rejected_and_reported',
               'test_08_expected_rc2_without_receipt_is_rejected'):
   self.assertIn(name,t)

if __name__=='__main__':unittest.main()
