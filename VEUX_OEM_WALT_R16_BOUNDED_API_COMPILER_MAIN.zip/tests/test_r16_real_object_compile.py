#!/usr/bin/env python3
import importlib.util,json,hashlib,pathlib,subprocess,sys,tempfile,types,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r16compiler',ROOT/'r16_real_object_compile.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
FIX=ROOT/'fixtures'

class GateTests(unittest.TestCase):
 def test_01_exact_target_count(self):self.assertEqual(len(m.TARGETS),11)
 def test_02_exact_walt_source(self):self.assertIn('kernel/sched/walt/qc_vas.o',m.TARGETS)
 def test_03_no_arbitrary_target(self):self.assertNotIn('arch/arm64/boot/Image',m.TARGETS)
 def test_04_eight_previous_baseline(self):self.assertEqual(len(m.BASELINE),8)
 def test_05_provider_symbols(self):self.assertEqual(m.OBJECTS_WITH_SYMBOLS['kernel/sysctl.o'],'proc_douintvec_capacity')
 def test_06_no_link_or_abi_in_driver(self):
  s=(ROOT/'r16_real_object_compile.py').read_text()
  self.assertIn("'vmlinux_linked':False",s);self.assertIn("'flash_allowed':False",s)
 def test_07_symbol_B(self):self.assertIn(('B','__cpu_isolated_mask'),m.nm_symbols('00000000 B __cpu_isolated_mask\n'))
 def test_08_symbol_D(self):self.assertIn(('D','__cpu_isolated_mask'),m.nm_symbols('001122334455 D __cpu_isolated_mask\n'))
 def test_09_symbol_T(self):self.assertIn(('T','migrate_swap'),m.nm_symbols('00000001 T migrate_swap\n'))
 def test_10_symbol_U(self):self.assertIn(('U','migrate_swap'),m.nm_symbols('                 U migrate_swap\n'))
 def test_11_fake_named_symbol_rejected(self):self.assertNotIn(('T','migrate_swap'),m.nm_symbols('migrate_swap anything else\n'))
 def test_12_empty_nm_returns_nothing(self):self.assertFalse(m.nm_symbols(''))
 def test_13_all_eleven_real_but_not_nm_cannot_prove(self):
  x={p:{'compiled':True} for p in m.TARGETS}
  state,n,b=m.make_status(x,{'symbol_scope_checked':False})
  self.assertEqual(n,11);self.assertNotIn('COMPILED_NO_LINK',state)
 def test_14_all_eleven_with_providers_still_no_link(self):
  x={p:{'compiled':True} for p in m.TARGETS}
  state,n,b=m.make_status(x,{'symbol_scope_checked':True})
  self.assertEqual(state,'R16_ALL_ELEVEN_OBJECTS_AND_PROVIDER_SYMBOLS_COMPILED_NO_LINK')
 def test_15_ten_eleven_diagnostic(self):
  x={p:{'compiled':True} for p in m.TARGETS}
  x['kernel/sched/walt/qc_vas.o']['compiled']=False
  state,n,b=m.make_status(x,{'symbol_scope_checked':True})
  self.assertEqual((n,b),(10,8));self.assertIn('DIAGNOSTICS',state) if False else self.assertIn('RECORDED',state)
 def test_16_baseline_regression_blocks(self):
  x={p:{'compiled':True} for p in m.TARGETS}
  x['kernel/sched/fair.o']['compiled']=False
  state,n,b=m.make_status(x,{'symbol_scope_checked':True})
  self.assertEqual(b,7);self.assertEqual(state,'R16_PREVIOUS_EIGHT_OBJECT_REGRESSION')
 def test_17_missing_target_rejected(self):
  x={p:{'compiled':True} for p in m.TARGETS[:-1]}
  with self.assertRaises(m.GateError):m.make_status(x,{'symbol_scope_checked':True})
 def test_18_unknown_target_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy: pass
   q=Dummy();q.objout=pathlib.Path(d);q.snapshot=pathlib.Path(d);q.toolchain=pathlib.Path(d)
   with self.assertRaises(m.GateError):m.fresh_make('arch/arm64/boot/Image',q,None,q.objout,{})
 def test_19_missing_source_returns_no_success(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy: pass
   q=Dummy();q.objout=pathlib.Path(d);q.snapshot=pathlib.Path(d);q.toolchain=pathlib.Path(d)
   (q.objout/'kernel/sched/walt').mkdir(parents=True)
   o=m.fresh_make('kernel/sched/walt/qc_vas.o',q,None,pathlib.Path(d),{})
   self.assertFalse(o['compiled']);self.assertEqual(o['failure'],'MISSING_SOURCE')
 def test_20_success_requires_object_file(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy: pass
   q=Dummy();q.objout=pathlib.Path(d)/'objects';q.objout.mkdir();q.snapshot=pathlib.Path(d)/'kernel';q.snapshot.mkdir();q.toolchain=pathlib.Path(d);q.toolchain=pathlib.Path(d);
   (q.objout/'kernel/sched').mkdir(parents=True);(q.snapshot/'kernel/sched').mkdir(parents=True)
   (q.snapshot/'kernel/sched/core.c').write_text('int x;')
   driver=types.SimpleNamespace(run_cmd=lambda *a,**k:{'exit_code':0,'timed_out':False},make_argv=lambda *a:['make'])
   o=m.fresh_make('kernel/sched/core.o',q,driver,pathlib.Path(d),{})
   self.assertFalse(o['compiled']);self.assertFalse(o['object_file_present'])
 def test_21_success_with_fresh_object(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy: pass
   q=Dummy();q.objout=pathlib.Path(d)/'objs';q.objout.mkdir();q.snapshot=pathlib.Path(d)/'kernel';q.snapshot.mkdir();q.toolchain=pathlib.Path(d)
   for b in (q.objout,q.snapshot):(b/'kernel/sched').mkdir(parents=True)
   (q.snapshot/'kernel/sched/core.c').write_text('int x;')
   def fake(*a,**k):
    (q.objout/'kernel/sched/core.o').write_bytes(b'OBJECT')
    return {'exit_code':0,'timed_out':False}
   driver=types.SimpleNamespace(run_cmd=fake,make_argv=lambda *a:['make'])
   o=m.fresh_make('kernel/sched/core.o',q,driver,pathlib.Path(d),{})
   self.assertTrue(o['compiled']);self.assertGreater(o['object_bytes'],0)
 def test_22_nonzero_exit_always_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy:pass
   q=Dummy();q.objout=pathlib.Path(d)/'objs';q.objout.mkdir();q.snapshot=pathlib.Path(d)/'kernel';q.snapshot.mkdir();q.toolchain=pathlib.Path(d)
   for b in (q.objout,q.snapshot):(b/'kernel/sched').mkdir(parents=True)
   (q.snapshot/'kernel/sched/core.c').write_text('int x;')
   def fake(*a,**k):
    (q.objout/'kernel/sched/core.o').write_bytes(b'OBJECT')
    return {'exit_code':2,'timed_out':False}
   driver=types.SimpleNamespace(run_cmd=fake,make_argv=lambda *a:['make'])
   self.assertFalse(m.fresh_make('kernel/sched/core.o',q,driver,pathlib.Path(d),{})['compiled'])
 def test_23_stale_object_deleted(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy:pass
   q=Dummy();q.objout=pathlib.Path(d)/'objs';q.objout.mkdir();q.snapshot=pathlib.Path(d)/'kernel';q.snapshot.mkdir();q.toolchain=pathlib.Path(d)
   for b in (q.objout,q.snapshot):(b/'kernel/sched').mkdir(parents=True)
   (q.snapshot/'kernel/sched/core.c').write_text('int x;')
   (q.objout/'kernel/sched/core.o').write_bytes(b'STALE')
   driver=types.SimpleNamespace(run_cmd=lambda *a,**k:{'exit_code':0,'timed_out':False},make_argv=lambda *a:['make'])
   o=m.fresh_make('kernel/sched/core.o',q,driver,pathlib.Path(d),{})
   self.assertFalse(o['compiled']);self.assertFalse((q.objout/'kernel/sched/core.o').exists())
 def test_24_symlink_old_object_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   class Dummy:pass
   q=Dummy();q.objout=pathlib.Path(d)/'objs';q.objout.mkdir();q.snapshot=pathlib.Path(d)/'kernel';q.snapshot.mkdir();q.toolchain=pathlib.Path(d)
   for b in (q.objout,q.snapshot):(b/'kernel/sched').mkdir(parents=True)
   (q.snapshot/'kernel/sched/core.c').write_text('int x;')
   (q.objout/'kernel/sched/core.o').symlink_to('/etc/passwd')
   driver=types.SimpleNamespace(run_cmd=lambda *a,**k:{'exit_code':0,'timed_out':False},make_argv=lambda *a:['make'])
   with self.assertRaises(m.GateError):m.fresh_make('kernel/sched/core.o',q,driver,pathlib.Path(d),{})
 def test_25_real_github_prior_json(self):
  d=json.loads((FIX/'R15_COMPILER_RESULT.json').read_text())
  self.assertEqual(d['object_success_count'],10)
  self.assertFalse(d['objects']['kernel/sched/walt/qc_vas.o']['compiled'])
 def test_26_original_oem_config_enabled(self):
  s=(FIX/'R9_EFFECTIVE_CONFIG.config').read_text()
  self.assertIn('CONFIG_SCHED_WALT=y\n',s);self.assertNotIn('CONFIG_SPRD_ROTATION_TASK=y',s)
 def test_27_source_stage_has_negative_hash(self):
  p=(ROOT/'r16_walt_api_foundation.py').read_text()
  self.assertIn('EXACT_R15_SOURCE_SHA_DRIFT',p)
 def test_28_driver_sha_pinned(self):self.assertEqual(m.PINNED_R9_DRIVER_SHA,'3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66')

if __name__=='__main__':unittest.main()
