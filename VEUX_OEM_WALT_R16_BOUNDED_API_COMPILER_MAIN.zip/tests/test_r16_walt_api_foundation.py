#!/usr/bin/env python3
import hashlib, importlib.util, json, pathlib, subprocess, sys, tempfile, unittest, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r16',ROOT/'r16_walt_api_foundation.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

FIX=ROOT/'fixtures'
D_R15=json.loads((FIX/'R15_SOURCE_GATE.json').read_text())
D_C15=json.loads((FIX/'R15_COMPILER_RESULT.json').read_text())
D_R12=json.loads((FIX/'R12_SOURCE_GATE.json').read_text())
D_R14=json.loads((FIX/'R14_SOURCE_GATE.json').read_text())

FAKE_CORE='''#include "sched.h"
#if defined(CONFIG_NUMA_BALANCING) || defined(CONFIG_SPRD_ROTATION_TASK)
static void __migrate_swap_task(struct task_struct *p, int cpu) {}
void trace_sched_swap_numa(struct task_struct *p);
int migrate_swap(struct task_struct *cur, struct task_struct *p,
 int cpu, int scpu) { trace_sched_swap_numa(cur); return 0; }
#endif /* CONFIG_NUMA_BALANCING || CONFIG_SPRD_ROTATION_TASK */
'''
FAKE_HEADER='''extern int proc_douintvec_minmax(struct ctl_table *table, int write,
   void __user *buffer, size_t *lenp, loff_t *ppos);
extern int proc_douintvec_ravg_window(struct ctl_table *table, int write,
   void __user *buffer, size_t *lenp, loff_t *ppos);
'''
FAKE_SYSCTL='''#include <linux/sched.h>
#ifdef CONFIG_PROC_SYSCTL
static int do_proc_dointvec(struct ctl_table *table, int write,
 void __user *buffer, size_t *lenp, loff_t *ppos,
 int (*conv)(bool *,unsigned long *,int *,int,void *),void *data)
{ return 0; }
static int do_proc_douintvec_rwin(bool *negp,unsigned long *lvalp,int *valp,int write,void *data)
{ return 0; }
int proc_douintvec_ravg_window(struct ctl_table *table, int write,
 void __user *buffer, size_t *lenp, loff_t *ppos)
{ return do_proc_dointvec(table,write,buffer,lenp,ppos,do_proc_douintvec_rwin,NULL); }
#else /* CONFIG_PROC_SYSCTL */
int proc_douintvec_ravg_window(struct ctl_table *table, int write,
 void __user *buffer, size_t *lenp, loff_t *ppos)
{ return -ENOSYS; }
#endif /* CONFIG_PROC_SYSCTL */
'''

def fixture_source():
 src={}
 s=(FIX/'R11_linux_sched.h').read_text()
 sys.path.insert(0,str(FIX))
 from r15_cpu_isolation_source import patch_sched
 src['include/linux/sched.h']=patch_sched(s)
 src['kernel/sched/sched.h']=(FIX/'R14_sched.h').read_text()
 src['kernel/sched/core.c']=FAKE_CORE
 src['include/linux/sysctl.h']=FAKE_HEADER
 src['kernel/sysctl.c']=FAKE_SYSCTL
 return src

class R16Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.src=fixture_source()
 def test_01_original_r15_gate(self):m.validate_gates(D_R15,D_C15,D_R12,D_R14)
 def test_02_pins_scope(self):self.assertEqual(len(m.PINS),5)
 def test_03_l16_real_r15_fixture_matches_sha(self):self.assertEqual(m.sha(self.src['include/linux/sched.h']),m.PINS['include/linux/sched.h'])
 def test_04_s14_real_sched_fixture_matches_sha(self):self.assertEqual(m.sha(self.src['kernel/sched/sched.h']),m.PINS['kernel/sched/sched.h'])
 def test_05_original_r15_real_make(self):self.assertTrue(D_C15['actual_arm64_make_attempted'])
 def test_06_r15_qc_vas_failed(self):self.assertFalse(D_C15['objects']['kernel/sched/walt/qc_vas.o']['compiled'])
 def test_07_original_r15_ten_of_eleven(self):self.assertEqual(D_C15['object_success_count'],10)
 def test_08_original_r12_p10_pinned(self):self.assertEqual(D_R12['canonical_p10_tree'],m.P10_TREE)
 def test_09_donor_is_pinned(self):self.assertIn('61397e5',m.DONOR)
 def test_10_only_safe_paths(self):self.assertEqual(set(m.ORDER),set(m.TRANSFORM))
 def test_11_wakeup_task_member_real(self):self.assertIn('wake_up_idle;',self.src['include/linux/sched.h'])
 def test_12_wakeup_current_pinned(self):self.assertIn('current->wts.wake_up_idle',m.WALT_WAKE)
 def test_13_wakeup_getter_reads_field(self):self.assertIn('return p->wts.wake_up_idle;',m.WALT_WAKE)
 def test_14_wakeup_setter_sets_field(self):self.assertIn('p->wts.wake_up_idle = !!wake_up_idle;',m.WALT_WAKE)
 def test_15_wakeup_api_on_test(self):self.assertIn('sched_get_wake_up_idle(',m.patch_linux_sched(self.src['include/linux/sched.h']))
 def test_16_wakeup_api_no_double(self):
  with self.assertRaises(m.GateError):m.patch_linux_sched(m.patch_linux_sched(self.src['include/linux/sched.h']))
 def test_17_wakeup_placed_at_end(self):self.assertGreater(m.patch_linux_sched(self.src['include/linux/sched.h']).find('sched_get_wake_up_idle'),self.src['include/linux/sched.h'].find('struct task_struct'))
 def test_18_wakeup_missing_task_field_fails(self):
  with self.assertRaises(m.GateError):m.patch_linux_sched(self.src['include/linux/sched.h'].replace('wake_up_idle;','wake_up_idle_missing;'))
 def test_19_wakeup_missing_anchor_fails(self):
  with self.assertRaises(m.GateError):m.patch_linux_sched(self.src['include/linux/sched.h'].replace('sched_trace_rd_span','sched_trace_rd_span_fake'))
 def test_20_sched_migrate_prototype_exists(self):self.assertIn('extern int migrate_swap',self.src['kernel/sched/sched.h'])
 def test_21_sched_migrate_walt_guard(self):self.assertIn(m.NEW_GUARD,m.patch_sched_h(self.src['kernel/sched/sched.h']))
 def test_22_sched_no_duplicate_guard(self):
  with self.assertRaises(m.GateError):m.patch_sched_h(m.patch_sched_h(self.src['kernel/sched/sched.h']))
 def test_23_core_real_provider_expected(self):self.assertIn('int migrate_swap(',self.src['kernel/sched/core.c'])
 def test_24_core_provides_walt_gate(self):self.assertIn(m.NEW_GUARD,m.patch_core(FAKE_CORE))
 def test_25_core_preserves_migration_logic(self):self.assertIn('trace_sched_swap_numa(cur)',m.patch_core(FAKE_CORE))
 def test_26_core_missing_provider_rejected(self):
  with self.assertRaises(m.GateError):m.patch_core(FAKE_CORE.replace('int migrate_swap(', 'int migrate_sham('))
 def test_27_core_wrong_guard_rejected(self):
  with self.assertRaises(m.GateError):m.patch_core(FAKE_CORE.replace(m.OLD_GUARD,'#ifdef CONFIG_SMP'))
 def test_28_core_second_patch_rejected(self):
  with self.assertRaises(m.GateError):m.patch_core(m.patch_core(FAKE_CORE))
 def test_29_header_capacity_decl_present(self):self.assertIn('proc_douintvec_capacity(',m.patch_sysctl_header(FAKE_HEADER))
 def test_30_header_ravg_unchanged(self):self.assertIn('proc_douintvec_ravg_window(',m.patch_sysctl_header(FAKE_HEADER))
 def test_31_header_missing_ravg_rejected(self):
  with self.assertRaises(m.GateError):m.patch_sysctl_header(FAKE_HEADER.replace('proc_douintvec_ravg_window','fake'))
 def test_32_header_second_patch_rejected(self):
  with self.assertRaises(m.GateError):m.patch_sysctl_header(m.patch_sysctl_header(FAKE_HEADER))
 def test_33_capacity_enforces_1_to_100(self):self.assertIn('*lvalp == 0 || *lvalp > 100',m.CAPACITY_IMPL)
 def test_34_capacity_negative_rejected(self):self.assertIn('if (*negp',m.CAPACITY_IMPL)
 def test_35_capacity_reads_back_real(self):self.assertIn('SCHED_FIXEDPOINT_SCALE * 100 / *valp',m.CAPACITY_IMPL)
 def test_36_capacity_writes_real(self):self.assertIn('SCHED_FIXEDPOINT_SCALE * 100 / *lvalp',m.CAPACITY_IMPL)
 def test_37_proc_off_returns_enosys(self):self.assertIn('return -ENOSYS;',m.CAPACITY_NO_PROC)
 def test_38_sysctl_ravg_preserved(self):self.assertIn('do_proc_douintvec_rwin',m.patch_sysctl(FAKE_SYSCTL))
 def test_39_sysctl_capacity_call_real(self):self.assertIn('do_proc_dointvec(table, write, buffer, lenp, ppos,',m.patch_sysctl(FAKE_SYSCTL))
 def test_40_sysctl_no_duplicate(self):
  with self.assertRaises(m.GateError):m.patch_sysctl(m.patch_sysctl(FAKE_SYSCTL))
 def test_41_sysctl_no_converter_rejected(self):
  with self.assertRaises(m.GateError):m.patch_sysctl(FAKE_SYSCTL.replace('static int do_proc_dointvec(','static int missing('))
 def test_42_sysctl_no_proc_off_rejected(self):
  with self.assertRaises(m.GateError):m.patch_sysctl(FAKE_SYSCTL.replace('#endif /* CONFIG_PROC_SYSCTL */','#endif /* OTHER */'))
 def test_43_r15_source_gate_rejects_bad_hash(self):
  g=dict(D_R15);g['after_sha256']=dict(g['after_sha256']);g['after_sha256']['include/linux/sched.h']='0'*64
  with self.assertRaises(m.GateError):m.validate_gates(g,D_C15,D_R12,D_R14)
 def test_44_r15_compiler_count_negative(self):
  c=dict(D_C15);c['object_success_count']=11
  with self.assertRaises(m.GateError):m.validate_gates(D_R15,c,D_R12,D_R14)
 def test_45_r15_false_flash_negative(self):
  c=dict(D_C15);c['flash_allowed']=True
  with self.assertRaises(m.GateError):m.validate_gates(D_R15,c,D_R12,D_R14)
 def test_46_r12_pin_negative(self):
  g=dict(D_R12);g['after_sha256']={**g['after_sha256'],'kernel/sysctl.c':'0'*64}
  with self.assertRaises(m.GateError):m.validate_gates(D_R15,D_C15,g,D_R14)
 def test_47_r14_pin_negative(self):
  g=dict(D_R14);g['after_sha256']={**g['after_sha256'],'kernel/sched/sched.h':'0'*64}
  with self.assertRaises(m.GateError):m.validate_gates(D_R15,D_C15,D_R12,g)
 def test_48_no_kernel_flash_or_brene_paths(self):self.assertFalse(any('brene' in x.lower() or 'anykernel' in x.lower() or 'bakasusu' in x.lower() for x in m.ORDER))
 def test_49_source_transform_scope(self):self.assertTrue(all(m.TRANSFORM[x](self.src[x])!=self.src[x] for x in m.ORDER))
 def test_50_idempotence_rejected(self):
  for x in m.ORDER:
   with self.subTest(x=x):
    with self.assertRaises(m.GateError):m.TRANSFORM[x](m.TRANSFORM[x](self.src[x]))
 def test_51_header_capacity_signature(self):self.assertRegex(m.CAPACITY_PROTO,r'proc_douintvec_capacity\(')
 def test_52_original_config_walt_on(self):self.assertIn('CONFIG_SCHED_WALT=y',(FIX/'R9_EFFECTIVE_CONFIG.config').read_text())
 def test_53_original_config_no_rotation(self):self.assertIn('# CONFIG_SPRD_ROTATION_TASK is not set',(FIX/'R9_EFFECTIVE_CONFIG.config').read_text())
 def test_54_pinned_before_sha_each_file(self):self.assertEqual(len(set(m.PINS.values())),5)
 def test_55_source_no_model_abi_claim(self):self.assertNotIn('vendor_abi_proven\':True',pathlib.Path(m.__file__).read_text())
 def test_56_semantic_migrate_guard(self):
  fixture='''#ifdef CONFIG_SCHED_WALT\n#define WALT_ACTIVE 1\n#endif\n'''
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td)/'t.c';p.write_text('''#if defined(CONFIG_NUMA_BALANCING) || defined(CONFIG_SPRD_ROTATION_TASK) || defined(CONFIG_SCHED_WALT)\nint genuine_walt_migrate_swap;\n#endif\n''')
   for defs,expected in ((['-DCONFIG_SCHED_WALT'],True),([],False),(['-DCONFIG_SPRD_ROTATION_TASK'],True)):
    proc=subprocess.run(['clang','-E','-P',*defs,str(p)],capture_output=True,text=True)
    self.assertEqual(proc.returncode,0)
    self.assertEqual('genuine_walt_migrate_swap' in proc.stdout,expected)
 def test_57_wakeup_clang_model(self):
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td)/'t.c';p.write_text('''#include <stdbool.h>\ntypedef unsigned int u32;\nstruct task_struct {struct {bool wake_up_idle;} wts;};\nextern struct task_struct *current;\n'''+m.WALT_WAKE+'''\nint main(void){struct task_struct t={{false}};return sched_set_wake_up_idle(&t,1) || !sched_get_wake_up_idle(&t);}\n''')
   for defs in (['-DCONFIG_SCHED_WALT'],[]):
    proc=subprocess.run(['clang','-std=gnu11','-Werror','-fsyntax-only',*defs,str(p)],capture_output=True,text=True)
    self.assertEqual(proc.returncode,0,proc.stderr)
 def test_58_capacity_clang_model(self):
  with tempfile.TemporaryDirectory() as td:
   p=pathlib.Path(td)/'t.c';p.write_text('''#include <stdbool.h>\n#include <stddef.h>\n#include <errno.h>\n#define SCHED_FIXEDPOINT_SCALE 1024\n#define __user\nstruct ctl_table{int val;};\ntypedef long long loff_t;\nstatic int do_proc_dointvec(struct ctl_table *t,int wr,void *b,size_t *l,loff_t *p,int (*c)(bool*,unsigned long*,int*,int,void*),void*d){return 0;}\n'''+m.CAPACITY_IMPL)
   proc=subprocess.run(['clang','-std=gnu11','-Werror','-fsyntax-only',str(p)],capture_output=True,text=True)
   self.assertEqual(proc.returncode,0,proc.stderr)

 def test_59_synthetic_git_patch_reapply_and_reverse(self):
  # This proves only the exact patch algorithm on synthetic core/sysctl
  # fixtures. It is NOT the yet-unavailable complete P10 runtime snapshot.
  from unittest import mock
  src=dict(self.src)
  newpins={name:m.sha(src[name]) for name in m.ORDER}
  g12=json.loads(json.dumps(D_R12))
  for name in ('include/linux/sysctl.h','kernel/sysctl.c'):
   g12['after_sha256'][name]=newpins[name]
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp)/'kernel';root.mkdir()
   subprocess.run(['git','-C',str(root),'init','-q'],check=True)
   for name,body in src.items():
    f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
   subprocess.run(['git','-C',str(root),'add','.'],check=True)
   subprocess.run(['git','-C',str(root),'-c','user.email=a@b.c','-c','user.name=test','commit','-qm','fixture'],check=True)
   gates=[]
   for i,j in enumerate((D_R15,D_C15,g12,D_R14)):
    pp=pathlib.Path(tmp)/('gate'+str(i)+'.json');pp.write_text(json.dumps(j));gates.append(pp)
   with mock.patch.dict(m.PINS,newpins,clear=True):
    report=m.stage(root,*gates,pathlib.Path(tmp)/'output')
    patch=pathlib.Path(tmp)/'output/R16_GENUINE_OEM_FOCUSED_APIS.patch'
    self.assertEqual(len(report['modified_files']),5)
    rev=subprocess.run(['git','-C',str(root),'apply','--reverse','--check',str(patch)],capture_output=True,text=True)
    self.assertEqual(rev.returncode,0,rev.stderr)
    subprocess.run(['git','-C',str(root),'apply','--reverse',str(patch)],check=True)
    changed=subprocess.run(['git','-C',str(root),'diff','--exit-code'],capture_output=True,text=True)
    self.assertEqual(changed.returncode,0,changed.stdout+changed.stderr)
 def test_60_synthetic_stage_drift_rejected_before_mutation(self):
  from unittest import mock
  src=dict(self.src)
  newpins={name:m.sha(src[name]) for name in m.ORDER}
  g12=json.loads(json.dumps(D_R12))
  for name in ('include/linux/sysctl.h','kernel/sysctl.c'):g12['after_sha256'][name]=newpins[name]
  with tempfile.TemporaryDirectory() as tmp:
   root=pathlib.Path(tmp)/'kernel';root.mkdir()
   for name,body in src.items():
    f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(body)
   bad=root/'kernel/sysctl.c';bad.write_text(bad.read_text()+'\n// invalid mutation\n')
   gates=[]
   for i,j in enumerate((D_R15,D_C15,g12,D_R14)):
    pp=pathlib.Path(tmp)/('gate'+str(i)+'.json');pp.write_text(json.dumps(j));gates.append(pp)
   before={name:(root/name).read_bytes() for name in m.ORDER}
   with mock.patch.dict(m.PINS,newpins,clear=True):
    with self.assertRaisesRegex(m.GateError,'EXACT_R15_SOURCE_SHA_DRIFT'):
     m.stage(root,*gates,pathlib.Path(tmp)/'output')
   self.assertFalse((pathlib.Path(tmp)/'output').exists())
   self.assertTrue(all((root/name).read_bytes()==before[name] for name in m.ORDER))

if __name__=='__main__':unittest.main()
