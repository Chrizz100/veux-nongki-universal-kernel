#!/usr/bin/env python3
"""R16: actual Clang/Kbuild recheck of eleven WALT/CPU objects.

A diagnostics-only tool: nonzero make exits are captured, never relabeled as a
successful compilation. No vmlinux, Image, ABI or flash artifact is produced.
"""
import argparse
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import subprocess
import sys

TARGETS=(
 'kernel/sched/walt/walt.o', 'kernel/sched/core.o', 'kernel/sched/fair.o',
 'kernel/sysctl.o', 'kernel/sched/walt/boost.o',
 'kernel/sched/walt/sched_avg.o', 'kernel/sched/walt/qc_vas.o',
 'kernel/sched/walt/core_ctl.o', 'kernel/sched/walt/trace.o',
 'kernel/sched/walt/cpu-boost.o', 'kernel/cpu.o')
BASELINE=tuple(x for x in TARGETS if x not in (
 'kernel/sched/walt/qc_vas.o','kernel/sched/walt/core_ctl.o','kernel/cpu.o'))
OBJECTS_WITH_SYMBOLS={
 'kernel/sched/core.o':'migrate_swap',
 'kernel/sysctl.o':'proc_douintvec_capacity',
 'kernel/cpu.o':'__cpu_isolated_mask',
}
R16_STATUS='R16_OEM_BOUNDED_API_STAGE_NOT_KERNEL_COMPILED'
R15_STATUS='R15_GENUINE_CPU_ISOLATION_COMPILER_DIAGNOSTICS'
PINNED_R9_DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'

class GateError(Exception):pass

def need(cond,msg):
 if not cond:raise GateError(msg)

def hashbytes(b):return hashlib.sha256(b).hexdigest()
def hashfile(p):return hashbytes(pathlib.Path(p).read_bytes())
def load(p):return json.loads(pathlib.Path(p).read_text())

def verify_args(q):
 for p in (q.snapshot,q.objout,q.toolchain,q.project):
  need(p.is_dir() and not p.is_symlink(),'BAD_DIRECTORY:'+str(p))
 need(q.snapshot.resolve()!=q.project.resolve(),'SOURCE_IS_GITHUB_PROJECT')
 need(q.objout.resolve()!=q.snapshot.resolve(),'OUTPUT_IS_SOURCE')
 need(not q.output.exists() and not q.output.is_symlink(),'REPORT_ALREADY_EXISTS')
 for p in (q.source_gate,q.r15_result,q.driver,q.config):
  need(p.is_file() and not p.is_symlink(),'BAD_INPUT_FILE:'+str(p))
 need(hashfile(q.driver)==PINNED_R9_DRIVER_SHA,'PINNED_R9_MAKE_DRIVER_CHANGED')
 clang=q.toolchain/'bin/clang'; nm=q.toolchain/'bin/llvm-nm'
 need(clang.is_file() and nm.is_file(),'ANDROID_CLANG_OR_LLVM_NM_MISSING')
 g=load(q.source_gate);r=load(q.r15_result)
 need(g.get('status')==R16_STATUS and g.get('source_r15_verified') is True,'R16_SOURCE_UNAUTHENTICATED')
 need(g.get('modified_files')==[
  'include/linux/sched.h','kernel/sched/sched.h','kernel/sched/core.c',
  'include/linux/sysctl.h','kernel/sysctl.c'],'UNEXPECTED_R16_PATCH_SCOPE')
 need(r.get('status')==R15_STATUS and r.get('object_success_count')==10 and r.get('actual_arm64_make_attempted') is True,'R15_PREVIOUS_OBJECT_GATE_INVALID')
 need(r.get('objects',{}).get('kernel/sched/walt/qc_vas.o',{}).get('compiled') is False,'R15_QC_VAS_WAS_NOT_FAILING')
 for v in (g,r):
  for key in ('vendor_abi_proven','kernel_image_built','vmlinux_linked','flash_allowed','brene_changed','bakasusu_nomount_changed'):
   need(v.get(key) is False,'FALSE_BUILD_OR_ABI_CLAIM:'+key)
 for name,h in g.get('after_sha256',{}).items():
  p=q.snapshot/name
  need(p.is_file() and not p.is_symlink() and hashfile(p)==h,'R16_POSTIMAGE_CHANGED:'+name)
 data=q.config.read_text()
 for v in ('CONFIG_SCHED_WALT=y','CONFIG_QGKI=y','CONFIG_HOTPLUG_CPU=y','CONFIG_PROC_SYSCTL=y'):
  need(re.search('(?m)^'+re.escape(v)+'$',data) is not None,'EFFECTIVE_CONFIG_MISMATCH:'+v)
 for v in ('CONFIG_SPRD_ROTATION_TASK=y','CONFIG_NUMA_BALANCING=y'):
  need(re.search('(?m)^'+re.escape(v)+'$',data) is None,'UNEXPECTED_MIGRATION_CONFIGURATION:'+v)
 return g,r

def fresh_make(target,q,driver,logdir,env):
 need(target in TARGETS,'UNAPPROVED_KBUILD_TARGET')
 p=q.objout/target;source=q.snapshot/(target[:-1]+'c')
 log=logdir/(target.replace('/','_')+'.log')
 if not source.is_file() or source.is_symlink():
  log.write_text('R16_INPUT_C_FILE_MISSING:'+str(source)+'\n')
  return {'compiled':False,'exit_code':None,'object_file_present':False,'failure':'MISSING_SOURCE','log':str(log),'log_sha256':hashfile(log)}
 need(p.parent.is_dir() and not p.parent.is_symlink(),'OUTPUT_DIRECTORY_MISSING:'+target)
 for stale in (p,p.parent/('.'+p.name+'.cmd')):
  need(not stale.is_symlink() and (not stale.exists() or stale.is_file()),'OLD_BUILD_FILE_IS_UNSAFE:'+str(stale))
  if stale.exists():stale.unlink()
 response=driver.run_cmd(driver.make_argv(q.snapshot,q.objout,q.toolchain,target,2),log,300,env=env)
 present=p.is_file() and not p.is_symlink() and p.stat().st_size>0
 result=bool(response.get('exit_code')==0 and response.get('timed_out') is False and present)
 return {**response,'compiled':result,'object_file_present':bool(present),
  'object_bytes':p.stat().st_size if present else 0,
  **({'object_sha256':hashfile(p)} if present else {})}

def nm_symbols(text):
 """Actual llvm-nm symbol table, no symbolic-success if the tool fails."""
 got=[]
 for ln in text.splitlines():
  m=re.search(r'^\s*(?:[0-9a-fA-F]+\s+)?([A-Za-z])\s+([A-Za-z_][A-Za-z_0-9]*)\s*$',ln)
  if m:got.append((m.group(1),m.group(2)))
 return got

def nm_probe(q,objects):
 result={'tool_invoked':False,'provider_objects':{},'qc_vas_undefined':[],
         'symbol_scope_checked':False,'not_a_vmlinux_link':True}
 nm=q.toolchain/'bin/llvm-nm'
 for obj,symbol in OBJECTS_WITH_SYMBOLS.items():
  p=q.objout/obj
  if objects[obj]['compiled'] and p.is_file():
   command=subprocess.run([str(nm),'--defined-only',str(p)],capture_output=True,text=True,timeout=30)
   result['tool_invoked']=True
   symbols=nm_symbols(command.stdout) if command.returncode==0 else []
   found=[kind for kind,name in symbols if name==symbol and kind in 'BCDRSGT']
   result['provider_objects'][obj]={'symbol':symbol,'found':bool(found),
          'kind':found[0] if found else None,'exit_code':command.returncode}
   (q.output/(obj.replace('/','_')+'.nm.txt')).write_text(command.stdout+command.stderr)
 qc=q.objout/'kernel/sched/walt/qc_vas.o'
 if qc.is_file() and objects['kernel/sched/walt/qc_vas.o']['compiled']:
  command=subprocess.run([str(nm),'--undefined-only',str(qc)],capture_output=True,text=True,timeout=30)
  result['tool_invoked']=True
  if command.returncode==0:
   result['qc_vas_undefined']=sorted(name for kind,name in nm_symbols(command.stdout) if kind=='U')
  result['qc_vas_nm_exit_code']=command.returncode
  (q.output/'R16_QC_VAS_UNDEFINED.nm.txt').write_text(command.stdout+command.stderr)
 expected=('migrate_swap','proc_douintvec_capacity','__cpu_isolated_mask')
 result['symbol_scope_checked']=all(any(r['symbol']==sym and r['found'] for r in result['provider_objects'].values()) for sym in expected)
 return result

def make_status(results,symbols):
 need(set(results)==set(TARGETS),'INCOMPLETE_RESULT_OBJECTS')
 count=sum(v['compiled'] is True for v in results.values())
 base=sum(results[n]['compiled'] is True for n in BASELINE)
 if base<8:return 'R16_PREVIOUS_EIGHT_OBJECT_REGRESSION',count,base
 if count==11 and symbols['symbol_scope_checked']:
  return 'R16_ALL_ELEVEN_OBJECTS_AND_PROVIDER_SYMBOLS_COMPILED_NO_LINK',count,base
 return 'R16_COMPILER_ERRORS_OR_PROVIDER_SYMBOL_GAPS_RECORDED',count,base

def run(q):
 gate,prev=verify_args(q)
 spec=importlib.util.spec_from_file_location('r16_pinned_r9_driver',q.driver)
 need(spec is not None and spec.loader is not None,'DRIVER_IMPORT_UNAVAILABLE')
 driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
 need(callable(driver.run_cmd) and callable(driver.make_argv),'DRIVER_INTERFACE_CHANGED')
 q.output.mkdir(parents=True); logs=q.output/'compiler_logs';logs.mkdir()
 r={'status':'R16_IN_PROGRESS','objects':{},'targets':list(TARGETS),
 'object_success_count':0,'real_arm64_make_attempted':False,
 'source_r16_verified':True,'r15_ten_of_eleven_proven':True,
 'kernel_version':'5.4.274','vendor_abi_proven':False,'kernel_image_built':False,
 'vmlinux_linked':False,'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False,
 'runtime_tested':False,'source_postimages':gate['after_sha256']}
 path=q.output/'R16_COMPILER_RESULT.json'
 path.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 env=os.environ.copy();env['PATH']=str(q.toolchain/'bin')+os.pathsep+env.get('PATH','')
 for target in TARGETS:
  r['real_arm64_make_attempted']=True
  r['objects'][target]=fresh_make(target,q,driver,logs,env)
  path.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 symbols=nm_probe(q,r['objects'])
 state,num,base=make_status(r['objects'],symbols)
 r.update({'status':state,'object_success_count':num,'previous_eight_compiled':base,
           'qc_vas_compiled':r['objects']['kernel/sched/walt/qc_vas.o']['compiled'],
           'symbol_evidence':symbols})
 path.write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
 print(f'R16_GENUINE_ARM64_OBJECTS={num}/11; BASE={base}/8; QC_VAS={int(r["qc_vas_compiled"])}; '
       f'PROVIDERS={int(symbols["symbol_scope_checked"])}; STATUS={state}; IMAGE=NO; ABI=OPEN; FLASH=NO')
 return r

def main():
 parser=argparse.ArgumentParser()
 for key in ('snapshot','objout','toolchain','source-gate','r15-result','driver','config','project','output'):
  parser.add_argument('--'+key,required=True,type=pathlib.Path)
 q=parser.parse_args()
 try:run(q)
 except (GateError,KeyError,ValueError,OSError,subprocess.TimeoutExpired) as ex:
  print('R16_COMPILER_GATE_ERROR:'+str(ex),file=sys.stderr);return 2
 return 0
if __name__=='__main__':sys.exit(main())
