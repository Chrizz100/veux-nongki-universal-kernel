VEUX M44 · Fehlerbehandlung des BQ2589x-Ladereglers · NOFLASH

Ausgangspunkt ist der grüne M43-Lauf 44872341251. Die Zahlen und Prüfsummen
aller 32 Archive stehen unter Reports/M43_RUN44872341251.json.

Beide Fehlerbits zusammen lösten in M43 zwei Resets aus. Bei der anschließenden
Initialisierung konnte der IRQ-Handler eine zuvor ausgeschaltete Ladung wieder
einschalten. Der Test benutzt die Treiberfunktionen und modelliert den I²C-Bus.
M44 verarbeitet die beiden Bits mit einer gemeinsamen Fehlerbehandlung. Nach
der Wartezeit sichert der Treiber zuerst die Ladesperre und eine ausdrücklich
angeforderte HiZ-Eingangssperre. Erst nach erfolgreichen Einstellungszugriffen
darf er eine bestehende Ladeanforderung wieder anwenden. Bei aktiv gemeldetem
OTG bleibt diese Freigabe aus. Die Startinitialisierung bleibt separat.

Für GitHub VEUX_M44_MAIN.zip unverändert im Repo-Hauptverzeichnis ablegen.
Aus VEUX_M44_YAML.zip die Workflow-Datei unter .github/workflows ersetzen.
Den Workflow manuell auf main starten. Er prüft die bisherigen Generationen
und baut Image, vmlinux und den statisch zu prüfenden boot.img/AK3-Satz aus
dem M44-Kandidaten. Die Kernelkennung lautet 5.4.274-qgki-g82179e362f33.

Offen bleiben das reale Verhalten während des Hardware-Resets, die tatsächliche
Registerlage nach mehrdeutigen I²C-Fehlern, OTG-Wiederanlauf, Stromgrenzen
und die WT/BQ-Abschaltreihenfolge. Ein fehlerhafter Schreibzugriff garantiert
keinen Hardwarezustand. Das Paket enthält keinen Flash-Installer. Kein Gerätetest
und keine Flash-Freigabe.
