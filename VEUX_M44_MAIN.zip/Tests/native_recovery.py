"""Compile the shipped IRQ, init and register functions against the pinned M40 bus harness."""

import ast
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DRIVER = Path("drivers/power/supply/qcom/bq2589x_charger.c")


def function(src, name):
    match = re.search(r"^(?:static\s+)?[^\n;]+\b" + name + r"\([^;]+?\n\{", src, re.M)
    if not match:
        raise ValueError(name)
    return src[match.start() : src.index("\n}", match.end()) + 2]


def render(source, old):
    parent = Path(os.environ["M40_DIR"])
    src = source.read_text()
    parent_test = ast.parse((parent / "Tests/native_bq_init_errors.py").read_text())
    literals = {
        node.targets[0].id: ast.literal_eval(node.value)
        for node in ast.walk(parent_test)
        if isinstance(node, ast.Assign)
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id in ("names", "const")
    }
    names = literals["names"][:]
    names[:0] = ["bq2589x_resolve_supply", "bq2589x_usb_changed"]
    names[names.index("bq2589x_enable_charger") : names.index("bq2589x_enable_charger")] = [
        "__bq2589x_set_charger",
        "bq2589x_set_charger_request",
        "__bq2589x_set_hiz",
        "bq2589x_set_hiz_request",
    ]
    if not old:
        names.insert(names.index("bq2589x_charger_irq_workfunc"), "bq2589x_recover_settings")
    stub = (parent / "References/native_bq_init_stubs.h").read_text()

    def replace(a, b):
        nonlocal stub
        if stub.count(a) != 1:
            raise ValueError(a)
        stub = stub.replace(a, b)

    replace(
        "struct mutex io_lock;",
        "struct mutex io_lock, charge_lock; unsigned long long charge_request_seq, hiz_request_seq; bool charge_requested, hiz_requested;",
    )
    replace(
        "static void fake_msleep(int ms);",
        "static void fake_msleep(int ms);\nstatic void during_reset(void);\nstatic bool failed_write_applied;",
    )
    replace(
        "if (fail_write &&(fail_write_at<=0||write_calls==fail_write_at)) return fail_write;",
        """bool failed = fail_write && (fail_write_at <= 0 || write_calls == fail_write_at);
 if (failed && !failed_write_applied) return fail_write;
 if (reg == 0x14 && (data & 0x80)) { registers[0x00] &= ~0x80; registers[3] = (registers[3] & ~0x20) | 0x10; }
 if (failed) { registers[reg] = data; return fail_write; }""",
    )
    replace(
        "event(3,ms,0);if(stop_on_sleep)", "event(3,ms,0);if(ms==5)during_reset();if(stop_on_sleep)"
    )
    defs = [
        line
        for line in (parent / "Before" / DRIVER.with_name("bq2589x_reg.h")).read_text().splitlines()
        if line.startswith("#define BQ2589X_")
    ]
    defs.extend(re.findall(r"^#define\s+BQ2589X_STATUS_.*", src, re.M))
    enum = src[src.index("enum bq2589x_vbus_type {") : src.index("enum bq2589x_part_no {")]
    return "\n".join(
        [
            literals["const"],
            stub,
            enum,
            *defs,
            "#define OLD_SOURCE " + str(int(old)),
            *(function(src, name) for name in names),
            (ROOT / "Tests/recovery_cases.c").read_text(),
        ]
    )


def run(source, old=False):
    with tempfile.TemporaryDirectory() as tmp:
        c = Path(tmp) / "recovery.c"
        exe = Path(tmp) / "recovery"
        c.write_text(render(Path(source), old))
        subprocess.run(
            [
                "cc",
                "-std=gnu11",
                "-O2",
                "-Wall",
                "-Wextra",
                "-Werror",
                "-Wno-unused-parameter",
                "-Wno-unused-function",
                "-pthread",
                "-fsanitize=undefined",
                "-fno-sanitize-recover=all",
                str(c),
                "-o",
                str(exe),
            ],
            check=True,
        )
        return subprocess.check_output([str(exe)], text=True, timeout=25)


if __name__ == "__main__":
    print(run(ROOT / "Before" / DRIVER, True), end="")
    print(run(ROOT / "After" / DRIVER), end="")
