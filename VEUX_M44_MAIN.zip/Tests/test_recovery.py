import argparse, contextlib, importlib.util, json, os, re, shutil, subprocess, sys, tempfile, unittest, yaml
from pathlib import Path
from unittest.mock import patch
from native_recovery import run

ROOT = Path(__file__).resolve().parents[1]
s = importlib.util.spec_from_file_location("m44_tested", ROOT / "Tools/m44_fault_recovery.py")
m = importlib.util.module_from_spec(s)
s.loader.exec_module(m)
BASE = ROOT.parent / "m42-success-run"
P42 = Path(os.environ.get("M42_DIR", str(ROOT.parent / "m42-main")))
P41 = Path(os.environ.get("M41_DIR", str(ROOT.parent / "m41-main")))
P40 = Path(os.environ.get("M40_DIR", str(ROOT.parent / "current-m40-r2-main")))
P28 = Path(os.environ.get("M28_DIR", str(BASE / "veux-m28-wt-tools")))
P27 = Path(os.environ.get("M27_DIR", str(BASE / "veux-m27-sc8551-tools")))
P26 = Path(os.environ.get("M26_DIR", str(BASE / "veux-m26-rpm-tools")))


def args():
    return argparse.Namespace(
        m42_tool=P42 / "Tools/m42_charge_order.py",
        m41_tool=P41 / "Tools/m41_wt_current.py",
        m40_tool=P40 / "Tools/m40_bq_numeric_inputs.py",
        m28_tool=P28 / "Tools/m28_wt_reporting.py",
    )


def refresh(root):
    fs = sorted(
        p
        for p in root.rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and p.name != "MANIFEST_SHA256.txt"
    )
    (root / "MANIFEST_SHA256.txt").write_text(
        "".join(m.sha(p) + "  " + p.relative_to(root).as_posix() + "\n" for p in fs)
    )


def native(script, source):
    return subprocess.run(
        [sys.executable, "-B", str(Path(os.environ["M43_DIR"]) / "Tests" / script), str(source)],
        text=True,
        capture_output=True,
        timeout=45,
        env=dict(os.environ, M42_DIR=str(P42), M41_DIR=str(P41), M40_DIR=str(P40)),
    )


class SourceTests(unittest.TestCase):
    def test_recovery(self):
        m.verify_package()
        self.assertIn("M43 reproduced", run(ROOT / "Before" / m.BQ, True))
        self.assertIn(
            "20480 IRQ cases, 136 injected recovery bus errors", run(ROOT / "After" / m.BQ)
        )

    def test_current_monitor_unchanged(self):
        r = native("native_hiz_order.py", ROOT / "After" / m.BQ)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("assertions=7378;", r.stdout)

    def test_preserved_m42_charge_order_on_real_new_hiz_helpers(self):
        r = native("compat_m42_charge.py", ROOT / "After" / m.BQ)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("assertions=2895; sequential=32; concurrent=350; bus_faults=32;", r.stdout)

    def test_preserved_all_iio_writer_success_and_fault_cases(self):
        r = native("compat_native_writes.py", ROOT / "After" / m.BQ)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("assertions=37577; success_cases=416; fault_cases=6960;", r.stdout)

    def test_self_consistent_thermal_change_is_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t)
            shutil.copytree(
                ROOT, p, dirs_exist_ok=True, ignore=shutil.ignore_patterns("__pycache__")
            )
            c = p / "After" / m.BQ
            c.write_text(c.read_text().replace("temperature > 480", "temperature > 481"))
            j = json.loads((p / "References/PROFILE.json").read_text())
            j["after_sha256"] = m.sha(c)
            (p / "References/PROFILE.json").write_text(json.dumps(j))
            refresh(p)
            with (
                patch.object(m, "ROOT", p),
                self.assertRaisesRegex(ValueError, "INDEPENDENT_SOURCE"),
            ):
                m.verify_package()

    def test_actual_immutable_chain_new_postimage_and_unrelated_header_checks(self):
        with tempfile.TemporaryDirectory() as t, m.engine(args()) as p42:
            source = Path(t)
            for p in [P28, P40]:
                shutil.copytree(p / "Before", source, dirs_exist_ok=True)
            with (
                p42.engine(args()) as p41,
                p41.engine(args().m40_tool, args().m28_tool) as (bq, wt),
            ):
                wt.apply_source(source)
                bq.apply_source(source)
                self.assertEqual(m.check_file(source), {m.BQ: m.AFTER})
                p41.check_source(source, after=True)
                p42.check_file(source)
                (source / "include/linux/power_supply.h").write_bytes(b"changed unrelated header")
                with self.assertRaises(ValueError):
                    wt.source_check(source, after=True)

    def test_actual_lower_build_chain_before_compilation(self):
        with tempfile.TemporaryDirectory() as t, m.engine(args()) as p42:
            source = Path(t) / "candidate-source"
            for p in [P26, P27, P28, P40]:
                shutil.copytree(p / "Before", source, dirs_exist_ok=True)
            with (
                p42.engine(args()) as p41,
                p41.engine(args().m40_tool, args().m28_tool) as (bq, wt),
            ):
                sc = wt.load_parent(P27 / "Tools/m27_sc8551.py")
                rpm = sc.load_parent(P26 / "Tools/m26_rpm_sleep.py")
                saved = wt.apply_source

                def stop(a):
                    rpm.apply_source(source)
                    rpm.source_check(source, after=True)
                    sc.source_check(source, after=True)
                    wt.source_check(source, after=True)
                    bq.source_check(source, after=True)
                    p41.check_source(source, after=True)
                    p42.check_file(source)
                    m.check_file(source)
                    raise RuntimeError("ACTUAL_M44_CHAIN_BEFORE_COMPILER")

                a = args()
                a.output = t
                a.m27_tool = "fixture"
                a.m26_tool = "fixture"
                with (
                    patch.object(wt, "load_parent", return_value=sc),
                    patch.object(sc, "load_parent", return_value=rpm),
                    patch.object(rpm, "build", side_effect=stop),
                    patch.object(p41, "engine", return_value=contextlib.nullcontext((bq, wt))),
                    patch.object(p42, "engine", return_value=contextlib.nullcontext(p41)),
                    patch.object(m, "engine", return_value=contextlib.nullcontext(p42)),
                ):
                    with self.assertRaisesRegex(RuntimeError, "ACTUAL_M44_CHAIN"):
                        m.build(a)
                self.assertIs(wt.apply_source, saved)
                self.assertFalse(
                    json.loads((Path(t) / "M44_RESULT.json").read_text())["kernel_compiled"]
                )

    def test_old_source_and_stale_product_markers_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p = Path(t)
            shutil.copytree(ROOT / "Before", p / "candidate-source")
            (p / "candidate-out/arch/arm64/boot").mkdir(parents=True)
            with self.assertRaisesRegex(ValueError, "M44_FAULT_RECOVERY_SOURCE"):
                m.proof(p)
            shutil.copytree(ROOT / "After", p / "candidate-source", dirs_exist_ok=True)
            for n in ["arch/arm64/boot/Image", "vmlinux"]:
                (p / "candidate-out" / n).write_bytes(
                    b"bq2589x: monitor hiz snapshot failed\0bq2589x: monitor hiz restore superseded"
                )
            with self.assertRaisesRegex(ValueError, "FAULT_RECOVERY_BRANCH_NOT_LINKED"):
                m.proof(p)

    def test_package_failure_quarantines_pair(self):
        with tempfile.TemporaryDirectory() as t:
            out = Path(t)
            (out / "review").mkdir()
            (out / "review/bad").write_bytes(b"bad")
            a = args()
            a.output = out
            with (
                patch.object(m, "verify_fresh", return_value={"release": {}}),
                patch.object(m, "engine") as e,
            ):
                e.return_value.__enter__.return_value.package.side_effect = RuntimeError(
                    "pack failed"
                )
                with self.assertRaisesRegex(RuntimeError, "pack failed"):
                    m.package(a)
            self.assertFalse((out / "review").exists())
            self.assertTrue((out / "unverified-review").is_dir())
            self.assertFalse(
                json.loads((out / "M44_PACKAGE_RESULT.json").read_text())["static_boot_path_pass"]
            )

    def test_stale_proof_quarantines_previous_review(self):
        with tempfile.TemporaryDirectory() as t:
            out = Path(t)
            for name in ["review", "unverified-review"]:
                (out / name).mkdir()
            (out / "review/old.img").write_bytes(b"stale")
            a = args()
            a.output = t
            a.build = out / "absent-build"
            with self.assertRaises(FileNotFoundError):
                m.package(a)
            self.assertFalse((out / "review").exists())
            self.assertEqual(len(list(out.glob("unverified-review-*/old.img"))), 1)
            self.assertFalse(
                json.loads((out / "M44_PACKAGE_RESULT.json").read_text())["static_boot_path_pass"]
            )


@unittest.skipUnless(os.environ.get("M44_WORKFLOW"), "M44_WORKFLOW required")
class WorkflowTests(unittest.TestCase):
    def workflow(self):
        return yaml.safe_load(Path(os.environ["M44_WORKFLOW"]).read_text())

    def test_twenty_real_checkout_preflight_commands(self):
        r = next(iter(self.workflow()["jobs"].values()))["steps"][11]["run"]
        self.assertEqual(r.count('--source "$GITHUB_WORKSPACE/kernel"'), 20)
        self.assertNotIn("$R9_SNAPSHOT", r)

    def test_current_commands_cli_and_quoted_paths(self):
        for op, index, count in [("build", 114, 21), ("package", 115, 15)]:
            with (
                self.subTest(op=op),
                tempfile.TemporaryDirectory(prefix="m44 paths with spaces ") as t,
            ):
                root = Path(t)
                (root / "bin").mkdir()
                capture = root / "capture"
                p = root / "bin/python3"
                p.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M44_CAPTURE"\n')
                p.chmod(0o755)
                command = next(iter(self.workflow()["jobs"].values()))["steps"][index]["run"]
                self.assertEqual(
                    command, (ROOT / f"References/M44_{op.upper()}_COMMAND.sh").read_text()
                )
                names = set(re.findall(r"\$([A-Z][A-Z0-9_]*)", command))
                env = dict(
                    os.environ,
                    **{n: str(root / (n + " spaces")) for n in names},
                    PATH=str(root / "bin") + os.pathsep + os.environ["PATH"],
                    M44_CAPTURE=str(capture),
                )
                r = subprocess.run(
                    ["bash", "-c", command], env=env, text=True, capture_output=True, timeout=10
                )
                self.assertEqual(r.returncode, 0, r.stderr)
                argv = capture.read_bytes().decode().split("\0")
                self.assertEqual(argv.pop(), "")
                self.assertEqual(argv.pop(0), "-B")
                a = m.parser().parse_args(argv[1:])
                self.assertEqual(len(vars(a)), count + 1)
                self.assertEqual(a.m42_tool, env["M42_DIR"] + "/Tools/m42_charge_order.py")


if __name__ == "__main__":
    unittest.main()
