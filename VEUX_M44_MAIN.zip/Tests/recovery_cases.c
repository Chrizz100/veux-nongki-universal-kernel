static struct bq2589x bq;
static struct i2c_client client;
static int late, cases, failures;
static bool initialized;
#define EXPECT(expr) do { if (!(expr)) { fprintf(stderr, "%d: %s\n", __LINE__, #expr); abort(); } } while (0)

static void reset_case(int chip, int flags, bool charge, bool hiz)
{
	if (initialized) {
		pthread_mutex_destroy(&bq.io_lock.value);
		pthread_mutex_destroy(&bq.charge_lock.value);
	}
	memset(&bq, 0, sizeof(bq));
	memset(registers, 0, sizeof(registers));
	mutex_init(&bq.io_lock);
	mutex_init(&bq.charge_lock);
	initialized = true;
	g_bq = &bq;
	bq.dev = &client.dev;
	bq.client = &client;
	bq.startup_ready = true;
	bq.is_bq25890h = chip;
	bq.cfg.charge_voltage = 4450;
	bq.cfg.charge_current = 2000;
	bq.cfg.term_current = 256;
	bq.cfg.otg_vol = 5300;
	bq.cfg.otg_current = 1800;
	bq.charge_requested = charge;
	bq.hiz_requested = hiz;
	registers[3] = charge ? 0x10 : 0;
	registers[0] = hiz ? 0x80 : 0;
	registers[0x0b] = BQ2589X_VBUS_OTG << BQ2589X_VBUS_STAT_SHIFT;
	registers[0x0c] = flags;
	fail_read = fail_write = fail_write_at = read_calls = write_calls = event_count = 0;
	fail_reg = fail_count = -1;
	fail_from_call = late = 0;
	stop_on_sleep = failed_write_applied = false;
}

static void during_reset(void)
{
	EXPECT(!pthread_mutex_trylock(&bq.io_lock.value));
	mutex_unlock(&bq.io_lock);
	EXPECT(!pthread_mutex_trylock(&bq.charge_lock.value));
	mutex_unlock(&bq.charge_lock);
	if (late == 1 || late == 2)
		EXPECT(!bq2589x_set_charger_request(&bq, late == 2));
	if (late == 3 || late == 4)
		EXPECT(!bq2589x_set_hiz_request(&bq, late == 3));
}

static int count_event(int kind, int reg)
{
	int total = 0;
	for (int i = 0; i < event_count; i++)
		if (events[i].kind == kind && events[i].a == reg)
			total++;
	return total;
}

#if !OLD_SOURCE
static atomic_int writer_started;
static void *recover_thread(void *unused)
{
	EXPECT(!bq2589x_recover_settings(&bq));
	return NULL;
}
static void *disable_thread(void *unused)
{
	atomic_store(&writer_started, 1);
	EXPECT(!bq2589x_disable_charger(&bq));
	return NULL;
}
static void check_waiting_request(int chip)
{
	pthread_t recovery, writer;

	reset_case(chip, 0xc0, true, false);
	atomic_store(&hold_read, 1);
	atomic_store(&read_entered, 0);
	atomic_store(&release_read, 0);
	atomic_store(&writer_started, 0);
	EXPECT(!pthread_create(&recovery, NULL, recover_thread, NULL));
	while (!atomic_load(&read_entered)) sched_yield();
	EXPECT(pthread_mutex_trylock(&bq.io_lock.value) == EBUSY);
	EXPECT(pthread_mutex_trylock(&bq.charge_lock.value) == EBUSY);
	EXPECT(!pthread_create(&writer, NULL, disable_thread, NULL));
	while (!atomic_load(&writer_started)) sched_yield();
	atomic_store(&release_read, 1);
	EXPECT(!pthread_join(recovery, NULL));
	EXPECT(!pthread_join(writer, NULL));
	atomic_store(&hold_read, 0);
	EXPECT(!bq.charge_requested && !(registers[3] & 0x10));
}
#endif

int main(void)
{
	(void)saved_events;
#if OLD_SOURCE
	(void)cases; (void)failures;
	reset_case(1, 0xc0, false, true);
	bq2589x_charger_irq_workfunc(&bq.irq_work);
	EXPECT(count_event(2, 0x14) == 2 && count_event(3, 5) == 2);
	EXPECT(bq.charge_requested && (registers[3] & 0x10));
	EXPECT(bq.hiz_requested && !(registers[0] & 0x80));
	reset_case(1, 0x80, true, false);
	late = 1;
	bq2589x_charger_irq_workfunc(&bq.irq_work);
	EXPECT(bq.charge_requested && (registers[3] & 0x10));
	puts("M43 reproduced: two resets, charge-off overwritten (including a late request), explicit HiZ lost in reset model");
#else
	for (int chip = 0; chip < 2; chip++)
	for (int flags = 0; flags < 256; flags++)
	for (int modes = 0; modes < 8; modes++)
	for (int action = 0; action < 5; action++) {
		bool recover = flags & 0xc0;
		bool charge = modes & 1, hiz = modes & 2, otg = modes & 4;
		reset_case(chip, flags, charge, hiz);
		bq.cfg.otg_status = otg;
		late = action;
		bq2589x_charger_irq_workfunc(&bq.irq_work);
		EXPECT(count_event(2, 0x14) == recover);
		EXPECT(count_event(3, 5) == recover);
		if (recover && (action == 1 || action == 2)) charge = action == 2;
		if (recover && (action == 3 || action == 4)) hiz = action == 3;
		EXPECT(bq.charge_requested == charge && bq.hiz_requested == hiz);
		EXPECT(!!(registers[3] & 0x10) == (charge && !(recover && otg)));
		EXPECT(!!(registers[0] & 0x80) == hiz);
		cases++;
	}
	for (int chip = 0; chip < 2; chip++) {
		check_waiting_request(chip);
		reset_case(chip, 0xc0, true, true);
		EXPECT(!bq2589x_recover_settings(&bq));
		int reads = read_calls, writes = write_calls;
		for (int kind = 0; kind < 2; kind++)
		for (int at = 1; at <= (kind ? writes : reads); at++)
		for (int applied = 0; applied < 2; applied++) {
			reset_case(chip, 0xc0, true, true);
			if (kind) { fail_write = -EIO; fail_write_at = at; }
			else { fail_read = -EIO; fail_count = 3; fail_from_call = at; }
			failed_write_applied = applied;
			EXPECT(bq2589x_recover_settings(&bq) == -EIO);
			EXPECT(bq.charge_requested && bq.hiz_requested);
			/* A failed protective or final write may still reach the chip. */
			if (at > 1 && !(kind && at == writes && applied))
				EXPECT(!(registers[3] & 0x10));
			failures++;
		}
		reset_case(chip, 0xc0, false, true);
		stop_on_sleep = true;
		bq2589x_charger_irq_workfunc(&bq.irq_work);
		EXPECT(bq.stopping && write_calls == 1 && !bq.charge_requested);
		reset_case(chip, 0x40, false, false);
		fail_write = -EIO; fail_write_at = 1;
		bq2589x_charger_irq_workfunc(&bq.irq_work);
		EXPECT(!count_event(3, 5) && write_calls == 1);
		reset_case(chip, 0, false, false);
		EXPECT(!bq2589x_init_device(&bq, false));
		EXPECT(bq.charge_requested && (registers[3] & 0x10));
	}
	printf("M44 PASS: %d IRQ cases, %d injected recovery bus errors, startup and shutdown gates\n", cases, failures);
#endif
	return 0;
}
