# VEUX R46-R6 – Positron-Kennung an der Quelle entfernen + QGKI-ABI-Prüfung

**STATUS: NUR CI-PRÜFKANDIDAT / NOFLASH.** Die vorhandenen P13-, R13-, R46-R5- und Stock-Originaldateien bleiben unverändert.

## Aus R46-R5 bestätigt
- GitHub-Run 42451608450: ARM64 WALT-Image, vmlinux, VEUX-DTB und RMNET-SHS/Offload als Built-ins erfolgreich kompiliert.
- `R47_RESULT.json`: 0 Linkerwarnungen und 0 fehlende llvm-nm-Aufrufe. Der echte Kernel meldet noch `5.4.274~positron`.

## Nachgewiesene Herkunft der falschen Kennung
Im unveränderten Upstream `dereference23/kernel_xiaomi_sm6375@b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`:
- Datei `localversion`, Git-Blob `368a9b8886959cf5114c689a581c51428f61ee9d`, Inhalt `~positron`.
- `scripts/setlocalversion`, Git-Blob `a597dd918c74e121e2a55aebcad0da216992e1c6`, beachtet `CONFIG_LOCALVERSION` beim Zusammensetzen der Kennung nicht.
- Die effektiv gebaute `.config` hat `CONFIG_LOCALVERSION="-qgki"` und `CONFIG_LOCALVERSION_AUTO=y`.

## Gezielte R46-R6-Korrektur
Das Prüfskript verändert *ausschließlich in der temporären Kernelquellkopie* genau zwei nach Git-Blob authentifizierte Dateien:
1. `localversion`: entfernt den Upstream-Brandinginhalt `~positron` (Datei bleibt leer erhalten).
2. `scripts/setlocalversion`: verwendet den bereits vorhandenen `CONFIG_LOCALVERSION`-Wert aus `include/config/auto.conf`. Kein willkürlicher Kernel-Commit wird ergänzt.

Erwarteter **eigener** Kernelrelease ist `5.4.274-qgki` – **NICHT** das originale Xiaomi `5.4.274-qgki-g82179e362f33`. Nach einem echten Build werden `kernel.release`, `utsrelease.h`, `Image`, `vmlinux` und der `vermagic` aller vier externen Module streng geprüft. Unpassende Versionen und verbliebenes `~positron` stoppen die CI.

## Separater Xiaomi-Vendor-ABI-Nachweis
Im **gleichen** erfolgreichen ARM64-Build wird `Module.symvers` auf `module_layout` geprüft: Für Xiaomis QGKI-Kohorte ist historisch `0x945d02f2` überliefert; der Wert der getrennten GKI-Kohorte `0x1e5b7ab7` darf nicht mit QGKI vermischt werden. Auch bei gleicher einzelner CRC bleibt die vollständige OEM-ABI ungeprüft. Es werden keine CRC-Werte geschrieben, gefälscht oder modifiziert.

Historischer R46-R2-Abgleich (nicht neu kompiliert): QGKI 1.423 unterschiedliche importierte Symbole; 578 passende CRC, 841 abweichende, 4 fehlend. Für echten OEM-PASS müssen die tatsächlich benötigten Xiaomi-QGKI-Module mit allen Importen gegen den *neuen* Kandidaten abgeglichen werden; die originale vollständige Xiaomi-5.4.274-Quelle ist weiter nicht gesichert.

## Installation
- `VEUX_R46_R6_CONFIG_RELEASE_VENDOR_ABI_MAIN.zip` **als Datei** in das Hauptverzeichnis der GitHub-Repository `main`.
- `VEUX_R46_R6_CONFIG_RELEASE_VENDOR_ABI_NOFLASH.yml` nach `.github/workflows/`.
- Actions → **VEUX R46-R6** → Run workflow.

R13-Built-in-Hunks, WALT, LTO-Linkerreparatur und alle ursprünglichen Buildschritte bleiben erhalten. Keine automatische Flashdatei und keine Flashfreigabe. actionlint und ShellCheck laufen verpflichtend im GitHub-Preflight.
