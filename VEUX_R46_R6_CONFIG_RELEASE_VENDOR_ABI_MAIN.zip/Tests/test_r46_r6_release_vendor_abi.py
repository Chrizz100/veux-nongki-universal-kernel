"""R46-R6: positional/negative tests for config-derived kernelrelease and OEM ABI block."""
import hashlib
import importlib.util
import pathlib
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r46r6',ROOT/'Tools/veux_r47_r13_on_r46.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

ORIG_SH=b'''#!/bin/sh
srctree=$1
collect_files() {
    local file res=
    for file; do
        case "$file" in *\\~*) continue;; esac
        if test -e "$file"; then res="$res$(cat "$file")"; fi
    done
    echo "$res"
}
if test -e include/config/auto.conf; then . include/config/auto.conf; else exit 2; fi
res="$(collect_files localversion*)"
if test ! "$srctree" -ef .; then res="$res$(collect_files "$srctree"/localversion*)"; fi
echo "$res"
'''

class TestReleaseSource(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=pathlib.Path(self.tmp.name)
        self.src=self.root/'src';self.src.mkdir()
        self.obj=self.root/'obj';self.obj.mkdir()
        (self.obj/'.config').write_bytes((ROOT/'References/R46_EFFECTIVE.config').read_bytes())
        (self.src/'scripts').mkdir()
        (self.src/'localversion').write_bytes(g.LOCALVERSION_BLOB)
        (self.src/'scripts/setlocalversion').write_bytes(ORIG_SH)
    def tearDown(self):self.tmp.cleanup()
    def plan(self):
        with mock.patch.object(g,'SETLOCALVERSION_BLOB_SHA1',g.git_blob_sha1(ORIG_SH)):
            return g.release_source_plan(self.src,self.obj)
    def patch(self):
        with mock.patch.object(g,'SETLOCALVERSION_BLOB_SHA1',g.git_blob_sha1(ORIG_SH)):
            return g.apply_config_based_release(self.src,self.obj)
    def test_84_upstream_marker_has_genuine_git_blob(self):
        self.assertEqual(g.git_blob_sha1(g.LOCALVERSION_BLOB),g.LOCALVERSION_BLOB_SHA1)
    def test_85_actual_effective_config_suffix_from_file(self):
        c=g.config_assert(g.kernel_config(self.obj/'.config'))
        self.assertEqual(c['CONFIG_LOCALVERSION'],'"-qgki"')
        self.assertEqual(c['CONFIG_LOCALVERSION_AUTO'],'y')
    def test_86_plan_reads_two_pinned_sources(self):
        self.assertEqual(len(self.plan()),2)
    def test_87_new_script_keeps_all_others_bytes(self):
        p=self.plan()
        self.assertEqual(p[0][2],b'')
        self.assertEqual(p[1][2].replace(g.SETLOCALVERSION_NEW,g.SETLOCALVERSION_OLD),ORIG_SH)
    def test_88_modifies_only_two_temp_paths(self):
        row=self.patch()
        self.assertEqual([x['path'] for x in row['changes']],['localversion','scripts/setlocalversion'])
        self.assertEqual((self.src/'localversion').read_bytes(),b'')
        self.assertNotIn(b'~positron',(self.src/'scripts/setlocalversion').read_bytes())
    def test_89_patched_script_returns_config_suffix(self):
        self.patch()
        (self.obj/'include/config').mkdir(parents=True)
        (self.obj/'include/config/auto.conf').write_text('CONFIG_LOCALVERSION="-qgki"\n')
        r=subprocess.run(['/bin/sh',str(self.src/'scripts/setlocalversion'),str(self.src)],cwd=self.obj,capture_output=True,text=True)
        self.assertEqual((r.returncode,r.stdout.strip()),(0,'-qgki'),r.stderr)
    def test_90_old_script_yields_upstream_marker(self):
        (self.obj/'include/config').mkdir(parents=True)
        (self.obj/'include/config/auto.conf').write_text('CONFIG_LOCALVERSION="-qgki"\n')
        r=subprocess.run(['/bin/sh',str(self.src/'scripts/setlocalversion'),str(self.src)],cwd=self.obj,capture_output=True,text=True)
        self.assertEqual(r.stdout.strip(),'~positron')
    def test_91_unknown_localversion_marker_rejected(self):
        (self.src/'localversion').write_text('-fake-kernel\n')
        with self.assertRaisesRegex(g.GateError,'R6_LOCALVERSION_SOURCE_PIN_MISMATCH'):self.plan()
    def test_92_unknown_script_rejected(self):
        (self.src/'scripts/setlocalversion').write_text('echo bad')
        with self.assertRaisesRegex(g.GateError,'R6_SETLOCALVERSION_SOURCE_PIN_MISMATCH'):self.plan()
    def test_93_wrong_config_suffix_rejected(self):
        (self.obj/'.config').write_text((self.obj/'.config').read_text().replace('CONFIG_LOCALVERSION="-qgki"','CONFIG_LOCALVERSION="~positron"'))
        with self.assertRaisesRegex(g.GateError,'R6_CONFIG_LOCALVERSION_NOT_QGKI'):self.plan()
    def test_94_other_source_marker_blocks(self):
        (self.src/'localversion-other').write_text('other')
        with self.assertRaisesRegex(g.GateError,'R6_UNKNOWN_SOURCE_LOCALVERSION_FILE'):self.plan()
    def test_95_output_marker_blocks(self):
        (self.obj/'localversion-custom').write_text('other')
        with self.assertRaisesRegex(g.GateError,'R6_UNKNOWN_OUTPUT_LOCALVERSION_FILE'):self.plan()
    def test_96_symlink_source_not_allowed(self):
        (self.src/'localversion').unlink();(self.src/'localversion').symlink_to(self.root/'missing')
        with self.assertRaisesRegex(g.GateError,'R6_SOURCE_FILE_UNSAFE'):self.plan()
    def test_97_no_double_patch(self):
        self.patch()
        with self.assertRaisesRegex(g.GateError,'R6_LOCALVERSION_SOURCE_PIN_MISMATCH'):self.plan()
    def test_98_does_not_clone_xiaomi_oem_revision(self):
        self.assertNotEqual(g.CANDIDATE_RELEASE,g.STOCK_RELEASE)
        self.assertEqual(g.CANDIDATE_RELEASE,'5.4.274-qgki')
    def test_99_wrong_setlocalversion_content_fails_closed(self):
        v=ORIG_SH.replace(g.SETLOCALVERSION_OLD,b'res="$(collect_files x*)"')
        (self.src/'scripts/setlocalversion').write_bytes(v)
        with mock.patch.object(g,'SETLOCALVERSION_BLOB_SHA1',g.git_blob_sha1(v)):
            with self.assertRaisesRegex(g.GateError,'R6_SETLOCALVERSION_RULE_NOT_EXACT'):g.release_source_plan(self.src,self.obj)

class TestVersionProof(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.obj=pathlib.Path(self.tmp.name)
        (self.obj/'include/config').mkdir(parents=True)
        (self.obj/'include/generated').mkdir(parents=True)
        (self.obj/'include/config/kernel.release').write_text('5.4.274-qgki\n')
        (self.obj/'include/generated/utsrelease.h').write_text('#define UTS_RELEASE "5.4.274-qgki"\n')
        p=self.obj/'arch/arm64/boot/Image';p.parent.mkdir(parents=True);p.write_bytes(b'Linux version 5.4.274-qgki ')
        (self.obj/'vmlinux').write_bytes(b'Linux version 5.4.274-qgki ')
        for m in g.OTHER_MODULE_PATHS:
            p=self.obj/m;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'whatever\0vermagic=5.4.274-qgki SMP preempt mod_unload modversions\0')
    def tearDown(self):self.tmp.cleanup()
    def test_100_all_six_binaries_and_release_match(self):
        p=g.verify_generated_release(self.obj)
        self.assertEqual(len(p['artifacts']),6)
    def test_101_release_string_leftover_rejected(self):
        (self.obj/'include/config/kernel.release').write_text('5.4.274~positron')
        with self.assertRaisesRegex(g.GateError,'R6_CANDIDATE_RELEASE_NOT_CONFIG_BASED'):g.verify_generated_release(self.obj)
    def test_102_utsrelease_not_rebuilt_rejected(self):
        (self.obj/'include/generated/utsrelease.h').write_text('#define UTS_RELEASE "5.4.274~positron"\n')
        with self.assertRaisesRegex(g.GateError,'R6_UTSRELEASE_MISMATCH'):g.verify_generated_release(self.obj)
    def test_103_image_branding_leftover_rejected(self):
        (self.obj/'arch/arm64/boot/Image').write_bytes(b'Linux version 5.4.274~positron')
        with self.assertRaisesRegex(g.GateError,'R6_POSITRON_STILL_IN_BINARY'):g.verify_generated_release(self.obj)
    def test_104_module_stale_vermagic_rejected(self):
        p=self.obj/next(iter(sorted(g.OTHER_MODULE_PATHS)))
        p.write_bytes(b'vermagic=5.4.274~positron SMP')
        with self.assertRaisesRegex(g.GateError,'R6_POSITRON_STILL_IN_BINARY'):g.verify_generated_release(self.obj)
    def test_105_unrelated_module_vermagic_rejected(self):
        p=self.obj/next(iter(sorted(g.OTHER_MODULE_PATHS)))
        p.write_bytes(b'vermagic=5.4.274-other SMP')
        with self.assertRaisesRegex(g.GateError,'R6_VENDOR_MODULE_VERMAGIC_NOT_REBUILT'):g.verify_generated_release(self.obj)
    def test_106_oem_stock_hash_must_not_be_claimed(self):
        (self.obj/'include/config/kernel.release').write_text(g.STOCK_RELEASE+'\n')
        with self.assertRaisesRegex(g.GateError,'R6_CANDIDATE_RELEASE_NOT_CONFIG_BASED'):g.verify_generated_release(self.obj)

class TestVendorABI(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.sym=pathlib.Path(self.tmp.name)/'Module.symvers'
    def tearDown(self):self.tmp.cleanup()
    def test_107_wide_oem_qgki_crc_is_separate_from_gki(self):
        self.assertNotEqual(g.OEM_QGKI_LAYOUT_CRC,g.OEM_GKI_LAYOUT_CRC)
    def test_108_known_non_oem_crc_blocks_vendor_claim(self):
        self.sym.write_text('0x0bcef28c\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n')
        j=g.module_layout_abi_diagnostic(self.sym)
        self.assertFalse(j['oem_qgki_module_layout_matches'])
        self.assertIs(j['full_vendor_abi_proven'],False)
    def test_109_matching_single_crc_still_no_oem_abi_pass(self):
        self.sym.write_text('0x945d02f2\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n')
        j=g.module_layout_abi_diagnostic(self.sym)
        self.assertTrue(j['oem_qgki_module_layout_matches'])
        self.assertFalse(j['full_vendor_abi_proven'])
    def test_110_missing_layout_is_blocker(self):
        self.sym.write_text('0x1\tfoo\tvmlinux\tEXPORT_SYMBOL\n')
        with self.assertRaisesRegex(g.GateError,'R6_MODULE_LAYOUT_MISSING_OR_DUPLICATE'):g.module_layout_abi_diagnostic(self.sym)
    def test_111_duplicate_layout_is_blocker(self):
        self.sym.write_text('0x945d02f2\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n'*2)
        with self.assertRaisesRegex(g.GateError,'R6_MODULE_LAYOUT_MISSING_OR_DUPLICATE'):g.module_layout_abi_diagnostic(self.sym)
    def test_112_gki_crc_is_not_accepted_as_qgki(self):
        self.sym.write_text('0x1e5b7ab7\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n')
        self.assertFalse(g.module_layout_abi_diagnostic(self.sym)['oem_qgki_module_layout_matches'])

if __name__=='__main__':unittest.main()
