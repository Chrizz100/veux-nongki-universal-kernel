"""Check the retained 5.4.274 inputs before Kbuild and independently check the replayed tree."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tempfile

import driver_check as driver
from full_build import ROOT, REL, patch_source

P3_TREE = "7f97dbbff432d61bbf11cae03de257a21f1d3c74"


def replay_source(repo, dest):
    md = dest / "drivers/md"
    md.mkdir(parents=True)
    for name in json.loads((ROOT / "sources.json").read_text()):
        rel = "drivers/md/" + name
        blob = subprocess.check_output(["git", "-C", repo, "show", P3_TREE + ":" + rel])
        (md / name).write_bytes(blob)
        if (repo / rel).read_bytes() != blob:
            raise ValueError("Checked-out source differs from the pinned tree: " + rel)
    if (repo / "drivers/md/dm-verity-avb.c").exists():
        raise ValueError("Unexpected pre-existing AVB handler in checkout")


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    sub = cli.add_subparsers(dest="stage", required=True)
    arm = sub.add_parser("driver")
    arm.add_argument("--m44", type=Path, required=True)
    arm.add_argument("--toolchain", type=Path, required=True)
    git = sub.add_parser("replay")
    git.add_argument("--repo", type=Path, required=True)
    cli.add_argument("--report", type=Path, required=True)
    args = cli.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        source = work / "kernel"
        if args.stage == "driver":
            shutil.copytree(ROOT / "baseline", source)
        else:
            replay_source(args.repo.resolve(), source)
        patch_source(source)
        result = {"release": REL, "stage": args.stage, "verified_files": 7}
        if args.stage == "driver":
            headers = work / "headers"
            driver.headers_from_build(args.m44, headers)
            tools = args.toolchain.resolve()
            env = driver.toolchain(tools)
            md = source / "drivers/md"
            result["native"] = driver.native_test(md, work)
            for name, enabled in [("disabled", False), ("enabled", True)]:
                result[name] = driver.build_driver(md, headers, tools, work, env, enabled)
        else:
            result["git_tree"] = P3_TREE
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
