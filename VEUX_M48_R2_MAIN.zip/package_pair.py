"""Build a review-only boot/AK3 pair and replay the stock-based entry for both slots."""

import hashlib
import io
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
M45_SHA = "6c31c1189deb4a5c0909f2737dc87e1c395dcd25c8abd96a70764e8efb5e5bcd"


def need(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unpack_m45(work):
    archive = ROOT / "m45-base.zip"
    need(sha(archive.read_bytes()) == M45_SHA, "M45 template mismatch")
    home = work / "m45"
    with zipfile.ZipFile(archive) as z:
        z.extractall(home)
    sys.path.insert(0, str(home))
    import review

    return review


def align(size):
    return (size + 4095) // 4096 * 4096


def make_image(m45, stock, kernel):
    need(
        sha(stock) == m45.STOCK_SHA and kernel[56:60] == b"ARM\x64",
        "Stock or ARM64 Image mismatch",
    )
    si = m45.image_info(stock)
    need(
        si["embedded_boot_digest"] == m45.STOCK_DESCRIPTOR, "Stock descriptor mismatch"
    )
    original = m45.avb.AvbFooter(stock[-64:])
    old_kernel, ram_len = struct.unpack_from("<II", stock, 8)
    rd_start = 4096 + align(old_kernel)
    header = bytearray(stock[:4096])
    struct.pack_into("<I", header, 8, len(kernel))
    payload = (
        bytes(header)
        + kernel.ljust(align(len(kernel)), b"\0")
        + stock[rd_start : rd_start + align(ram_len)]
    )
    end = len(payload)
    need(end + 4096 <= len(stock) - 4096, "Kernel and ramdisk exceed boot partition")
    meta = stock[original.vbmeta_offset : original.vbmeta_offset + 4096]
    desc = m45.boot_descriptor(meta[: original.vbmeta_size], False)
    before = desc.encode()
    desc.image_size = end
    desc.digest = hashlib.sha256(desc.salt + payload).digest()
    need(meta.count(before) == 1, "Stock boot descriptor must occur exactly once")
    page = meta.replace(before, desc.encode(), 1)
    original.original_image_size = end
    original.vbmeta_offset = end
    image = bytearray(len(stock))
    image[:end] = payload
    image[end : end + 4096] = page
    image[-64:] = original.encode()
    info = m45.image_info(image)
    need(
        info["kernel_sha256"] == sha(kernel) and info["ramdisk_sha256"] == m45.RAMDISK,
        "Invalid canonical boot image",
    )
    return bytes(image), page, end // 4096


def replace_once(text, old, new):
    need(text.count(old) == 1, "M45 template field changed: " + old)
    return text.replace(old, new, 1)


def magisk_draft(stock_path, kernel, arm, qemu, work, m45):
    folder = work / "first-repack"
    folder.mkdir()
    base = [str(qemu), str(arm)]
    subprocess.run(
        base + ["unpack", "-n", "-h", str(stock_path)], cwd=folder, check=True
    )
    need(
        sha((folder / "ramdisk.cpio").read_bytes()) == m45.RAMDISK,
        "Stock ramdisk changed on unpack",
    )
    (folder / "kernel").write_bytes(kernel)
    subprocess.run(
        base + ["repack", str(stock_path), "draft.img"],
        env={**os.environ, "PATCHVBMETAFLAG": "false"},
        cwd=folder,
        check=True,
    )
    return (folder / "draft.img").read_bytes()


def create_pair(kernel, original_ak3, stock_path, qemu, output):
    stock_path = Path(stock_path).resolve()
    qemu = Path(qemu).resolve(strict=True)
    out = Path(output)
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=stock_path.parent) as tmp:
        work = Path(tmp)
        m45 = unpack_m45(work)
        need(sha(original_ak3) == m45.ORIGINAL_AK3, "Unrecognized M44 AK3 base")
        stock = stock_path.read_bytes()
        canonical, page, idx = make_image(m45, stock, kernel)
        signed = m45.boot_descriptor((m45.ROOT / "stock-vbmeta.bin").read_bytes(), True)
        need(
            signed.digest.hex() == m45.STOCK_DESCRIPTOR
            and hashlib.sha256(signed.salt + stock[: signed.image_size]).digest()
            == signed.digest,
            "OEM descriptor mismatch",
        )
        actual = hashlib.sha256(
            signed.salt + canonical[: signed.image_size]
        ).hexdigest()
        with zipfile.ZipFile(io.BytesIO(original_ak3)) as z:
            arm = work / "magiskboot.arm"
            arm.write_bytes(z.read("tools/magiskboot"))
            arm.chmod(0o700)
        draft = magisk_draft(stock_path, kernel, arm, qemu, work, m45)
        pos = 4096 * idx
        need(
            len(draft) == len(canonical)
            and draft[:pos] == canonical[:pos]
            and draft[pos + 4096 :] == canonical[pos + 4096 :],
            "Magiskboot and stock-layout producer disagree outside the embedded AVB page",
        )
        render = (m45.ROOT / "render.sh").read_text()
        for old, new in [
            (m45.KERNEL, sha(kernel)),
            (sha((m45.ROOT / "boot-avb-page.bin").read_bytes()), sha(page)),
            (
                "e60bce1b0268e6122546f0706cd8985f4a887fbd0f7a57d0c8191a1f4f7aa224",
                sha(draft),
            ),
            (m45.BOOT, sha(canonical)),
            ("seek=16287", "seek=" + str(idx)),
        ]:
            render = replace_once(render, old, new)
        entry = (m45.ROOT / "anykernel.sh").read_text().replace("M45", "M48")
        template = work / "base.zip"
        m45.write_review_ak3(original_ak3, template)
        ak = work / "VEUX_M48_NOFLASH_AK3.zip"
        changes = {
            "Image": kernel,
            "anykernel.sh": entry.encode(),
            "veux/render.sh": render.encode(),
            "veux/boot-avb-page.bin": page,
        }
        with zipfile.ZipFile(template) as src, zipfile.ZipFile(ak, "x") as dst:
            for info in src.infolist():
                dst.writestr(
                    info,
                    changes[info.filename]
                    if info.filename in changes
                    else src.read(info),
                )
        with zipfile.ZipFile(ak) as z:
            need(
                z.testzip() is None
                and z.namelist().count("Image") == 1
                and z.read("Image") == kernel,
                "AK3 archive CRC or payload mismatch",
            )
        replay = m45.test_entry(ak, stock_path, canonical, work, qemu)
        need(replay == sha(canonical), "AK3 replay mismatch")
        boot = out / "VEUX_M48_NOFLASH_boot.img"
        boot.write_bytes(canonical)
        shutil.copyfile(ak, out / ak.name)
        return {
            "kernel_sha256": sha(kernel),
            "stock_ramdisk_sha256": m45.RAMDISK,
            "boot_sha256": replay,
            "ak3_sha256": sha(ak.read_bytes()),
            "simulated_stock_slots": ["_a", "_b"],
            "rejected_inputs": 3,
            "static_boot_pass": True,
            "oem_signed_boot_descriptor_matches": actual == signed.digest.hex(),
            "candidate_digest_for_oem_descriptor": actual,
            "oem_expected_digest": signed.digest.hex(),
            "device_pass": False,
            "flash_allowed": False,
        }
