/* Offsets observed in the unmodified M44 arm64 vmlinux DWARF. */
#include "dm-verity.h"
_Static_assert(sizeof(struct dm_verity_io) == 104, "dm_verity_io size");
_Static_assert(__builtin_offsetof(struct dm_verity_io, iter) == 16, "iter offset");
_Static_assert(__builtin_offsetof(struct dm_verity_io, block) == 40, "block offset");
_Static_assert(__builtin_offsetof(struct dm_verity_io, n_blocks) == 48, "n_blocks offset");
