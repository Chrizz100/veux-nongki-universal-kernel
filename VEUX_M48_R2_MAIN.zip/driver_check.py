"""Compile the two ARM64 dm-verity configurations and exercise the handler in memory."""

import hashlib
import io
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import time
from urllib.error import URLError, HTTPError
from urllib.request import urlopen
import zipfile

ROOT = Path(__file__).resolve().parent
M44 = "0834c0e5b0e3ec9777168de415e9dd4661ab0ff2fdc0afda9e521cbce9a762bc"
M46 = "e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164"
STOCK = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
RELEASE = "5.4.274-qgki-g82179e362f33"
CONFIG = "c6f842ddf24f496cea367803d2916a17896f221288932e0947de65b66941439a"
TOOLS = {
    "clang-12": (
        "bin/clang-12",
        "5c190576d99caae4d351993a8160c092e3fe07c469fbdf6f7e36a4a9ca7c2dc5",
    ),
    "ld.lld": (
        "bin/ld.lld",
        "51dc9705420c136f583478ac08a3258cd970710296928b3bf24dc3ee2e6208e3",
    ),
    "libc++.so.1": (
        "lib64/libc++.so.1",
        "5450238a6bea2b55c64af01468608f5f84b41fc691aa5d38d766c1f435e95159",
    ),
    "libc++abi.so.1": (
        "lib64/libc++abi.so.1",
        "fc988e92016a61e0635d68b88a533a2d47e21b0447fcfac8ed4e860e7044c924",
    ),
    "libxml2.so.2.9.10": (
        "lib64/libxml2.so.2.9.10",
        "868168612d58598a7f80a97c6095ed327bbbb6d0027423083dbd85a2e61c1807",
    ),
}
BASE = "https://raw.githubusercontent.com/msft-mirror-aosp/platform.prebuilts.clang.host.linux-x86/aa2e4a514a6c85eebcc4a27149eaf9244e951a1e/clang-r416183b/"


def require(ok, message):
    if not ok:
        raise ValueError(message)


def checksum(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1048576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def toolchain(path):
    path.mkdir(exist_ok=True)
    for name, (relative, expected) in TOOLS.items():
        target = path / name
        if not target.exists():
            url = BASE + relative
            # Raw Git downloads expose some symlinks as a one-line basename.
            for _ in range(3):
                for attempt in range(3):
                    try:
                        with (
                            urlopen(url, timeout=90) as response,
                            target.open("wb") as dest,
                        ):
                            shutil.copyfileobj(response, dest)
                        break
                    except (URLError, TimeoutError, ConnectionError) as exc:
                        target.unlink(missing_ok=True)
                        if attempt == 2 or (
                            isinstance(exc, HTTPError)
                            and exc.code < 500
                            and exc.code != 429
                        ):
                            raise
                        time.sleep(2**attempt)
                if target.stat().st_size >= 1024:
                    break
                name_in_git = target.read_text().strip()
                require(
                    re.fullmatch(r"[\w.+-]+", name_in_git),
                    "Unexpected toolchain symlink",
                )
                url = url.rsplit("/", 1)[0] + "/" + name_in_git
        require(checksum(target) == expected, "Compiler input mismatch: " + name)
        target.chmod(0o755)
    return {**os.environ, "LD_LIBRARY_PATH": str(path)}


def headers_from_build(archive, root):
    require(checksum(archive) == M44, "Wrong M44 artifact")
    prefix = "r46-r16-result/candidate-out/"
    with zipfile.ZipFile(archive) as z:
        data = z.read(prefix + "kernel/kheaders_data.tar.xz")
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:xz") as files:
            for member in files:
                if not member.isfile():
                    continue
                name = Path(member.name)
                require(
                    not name.is_absolute() and ".." not in name.parts,
                    "Invalid header path",
                )
                p = root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(files.extractfile(member).read())
        for name in ("include/generated/autoconf.h", ".config", "System.map"):
            (root / name).write_bytes(z.read(prefix + name))
    require(checksum(root / ".config") == CONFIG, "M44 configuration mismatch")
    require(
        (root / "include/generated/utsrelease.h").read_text().split('"')[1] == RELEASE,
        "Unexpected embedded M44 kernel release",
    )


def native_test(md, work):
    text = (md / "dm-verity-avb.c").read_text()
    body = text[
        text.index("/* Set via module parameters. */") : text.index(
            "static int __init dm_verity_avb_init"
        )
    ]
    (work / "handler-under-test.inc").write_text(body)
    exe = work / "memory-test"
    subprocess.run(
        [
            "cc",
            "-std=gnu11",
            "-Wall",
            "-Wextra",
            "-Werror",
            "-fsanitize=undefined",
            "-fno-sanitize-recover=all",
            "-I",
            work,
            ROOT / "test_verity.c",
            "-o",
            exe,
        ],
        check=True,
    )
    summary = subprocess.check_output([exe], text=True).strip()
    require(summary == "90 mock cases passed", "Unexpected native test result")
    return summary


def build_driver(md, headers, tools, work, env, enabled):
    config = (headers / ".config").read_text()
    fragment = (ROOT / "veux-m47.config").read_text()
    require(
        fragment == "CONFIG_DM_VERITY_AVB=y\n"
        and "CONFIG_DM_VERITY_AVB=" not in config,
        "Unexpected M44 or M47 input",
    )
    tag = "enabled" if enabled else "baseline"
    d = work / tag
    d.mkdir()
    cfg = d / ".config"
    cfg.write_text(config + (fragment if enabled else ""))
    require(
        "CONFIG_DM_VERITY=y" in config.splitlines()
        and "CONFIG_DM_VERITY_FEC=y" in config.splitlines(),
        "Missing built-in verity or FEC",
    )
    makefile = d / "components.mk"
    makefile.write_text(
        "include "
        + str(cfg)
        + "\ninclude "
        + str(md / "Makefile")
        + "\nlist:\n\t@echo $(dm-verity-y) $(dm-verity-objs)\n"
    )
    objects = subprocess.check_output(
        ["make", "--no-print-directory", "-s", "-f", makefile, "list"], text=True
    ).split()
    expected = {"dm-verity-target.o", "dm-verity-fec.o"}
    if enabled:
        expected.add("dm-verity-avb.o")
    require(
        set(objects) == expected and len(objects) == len(expected),
        "Unexpected Kbuild components",
    )
    includes = [
        "arch/arm64/include",
        "arch/arm64/include/generated",
        "include",
        "arch/arm64/include/uapi",
        "arch/arm64/include/generated/uapi",
        "include/uapi",
        "include/generated/uapi",
    ]
    cmd = [
        tools / "clang-12",
        "--target=aarch64-linux-gnu",
        "-D__KERNEL__",
        "-nostdinc",
        "-isystem",
        subprocess.check_output(["gcc", "-print-file-name=include"], text=True).strip(),
    ]
    cmd += ["-ffile-prefix-map=" + str(work) + "=/build/veux-m47"]
    cmd += ["-I" + str(headers / p) for p in includes]
    cmd += [
        "-include",
        headers / "include/linux/kconfig.h",
        "-O2",
        "-Wall",
        "-Werror=implicit-function-declaration",
        "-Werror=incompatible-pointer-types",
        "-Werror=return-type",
        "-Wno-address-of-packed-member",
        "-Wno-pointer-sign",
        "-Wno-gnu-variable-sized-type-not-at-end",
        "-std=gnu89",
        "-mgeneral-regs-only",
        "-fno-pic",
        "-fno-stack-protector",
        "-flto=thin",
        "-fsplit-lto-unit",
        "-fvisibility=default",
        "-fsanitize=cfi",
        "-fno-sanitize-blacklist",
        "-fsanitize-cfi-cross-dso",
        "-fno-sanitize-cfi-canonical-jump-tables",
        '-DKBUILD_MODNAME="dm_verity"',
    ]
    if enabled:
        cmd.append("-DCONFIG_DM_VERITY_AVB=1")
    subprocess.run(
        cmd + ["-I", md, "-fsyntax-only", ROOT / "check_layout.c"],
        cwd=md.parents[1], env=env, check=True,
    )
    for obj in objects:
        name = Path(obj).stem
        subprocess.run(
            cmd
            + [
                '-DKBUILD_BASENAME="' + name.replace("-", "_") + '"',
                "-c",
                "drivers/md/" + name + ".c",
                "-o",
                d / obj,
            ],
            cwd=md.parents[1],
            env=env,
            check=True,
        )
    linked = d / "dm-verity.o"
    subprocess.run(
        [tools / "ld.lld", "-r", *objects, "-o", linked.name],
        cwd=d,
        env=env,
        check=True,
    )
    header = subprocess.check_output(["readelf", "-h", linked], text=True)
    require(
        "AArch64" in header and "REL (Relocatable file)" in header,
        "Invalid ARM64 relocatable driver",
    )
    rel = subprocess.check_output(["readelf", "-Wr", linked], text=True)
    calls = re.findall(r"R_AARCH64_CALL26\s+[0-9a-f]+\s+(\S+)", rel)
    require(
        ("dm_verity_avb_error_handler" in calls) == enabled
        and "kernel_restart" in calls,
        "Unexpected linked error path",
    )
    symbols = subprocess.check_output(["nm", "-u", linked], text=True)
    imports = {line.split()[-1] for line in symbols.splitlines() if line.strip()}
    m44 = {
        fields[2].split("$")[0]
        for line in (headers / "System.map").read_text().splitlines()
        if len(fields := line.split()) >= 3
    }
    require(
        not (imports - m44),
        "Unmatched driver references: " + str(sorted(imports - m44)),
    )
    if enabled:
        require(
            "submit_bio_wait" in imports
            and b"androidboot.vbmeta.invalidate_on_error\0" in linked.read_bytes(),
            "Missing policy or completion path",
        )
    return {
        "components": objects,
        "m44_mapped_references": len(imports),
        "arm64_driver_sha256": checksum(linked),
        "avb_call": enabled,
    }
