# M48 R2 für VEUX 5.4.274-qgki-g82179e362f33

VEUX_M48_R2_MAIN.zip im Stammverzeichnis ablegen. VEUX_M48_R2_FULL_KERNEL_NOFLASH.yml unter .github/workflows/ ablegen. Beide Dateien auf main speichern und „VEUX M48 R2 – Stock-Verity, Boot und AK3 (NOFLASH)“ manuell starten.

## Reparatur aus Lauf 44904310917

Schritt 87 verglich die sieben Verity-Dateien mit dem Spenderstand 5.4.268. Das 5.4.274-Update ändert in dm-verity.h die Anordnung von dm_verity_io. R2 verwendet die sieben Dateien aus der Zusammenführung des Vendor-Commits b2b7a3bbc36d120ee523ebc8d68e0f13a97df632 mit Android Common android11-5.4.274_r00 (181edea14ae07024cc87699f3cd49116e6f8fbb3). Der vendorspezifische dm-verity-target.c bleibt als Grundlage erhalten. Nur der Header-Prüfwert hat sich geändert. Die Referenz für die Strukturgröße und die drei Offsets in check_layout.c stammt aus den DWARF-Daten des kompilierten M44-vmlinux aus Lauf 44879323567.

## Zwei Jobs

1. Der Kerneljob prüft das MAIN-Paket und die M44/M46/M47-Artefakte. Auf einer Kopie der sieben Quellen laufen vor dem historischen Nachbau die strikte Patchprüfung, 90 Tests im Arbeitsspeicher und zwei ARM64-Treiberbauten mit den M44-Headern. Nach der P3-Rekonstruktion prüft er dieselben sieben Dateien zusätzlich am festgelegten Git-Baum und am tatsächlichen Checkout. Er kontrolliert sie ein drittes Mal am endgültigen M44-Quellbaum vor dem inkrementellen M48-Bau. Abweichungen zeigen Pfad und beide Prüfsummen. M48 muss Image, vmlinux, Gerätebäume, Konfiguration und Vendor-ABI aus dem neuen Bau nachweisen. Alle 1.423 ABI-Symbole und 3.148 Importe aus 37 Vendor-Modulen müssen passen.
2. Der Paketjob verwendet den per SHA-256 geprüften Zwischenstand des ersten Jobs. Er baut boot.img und Prüf-AK3 mit der Xiaomi-Stock-Ramdisk und führt den AK3-Einstieg mit dem ARM-Werkzeug auf regulären Dateien für Slot A und B aus. Die Ergebnisse müssen bytegenau übereinstimmen. Nach einem Fehler ausschließlich in diesem Job kann „Re-run failed jobs“ den gespeicherten Zwischenstand verwenden, solange das Artefakt verfügbar ist (30 Tage Aufbewahrung).

Die Eingaben stammen aus M44 (44879323567), M46 (44901355794) und M47 (44902841859). Das lokale Backup von boot_a bleibt auf dem Gerät bzw. dem PC. Das Prüfpaar verwendet das originale Xiaomi-Abbild mit SHA-256 ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5. Die AK3 erzeugt ein Vergleichsabbild in einer Datei. Geräteboot, UFS-Treiberbindung am Gerät, Ziel des physischen Verity-Fehlerpfads und Rückweg per PC/Fastboot sind offen. Status NOFLASH.
