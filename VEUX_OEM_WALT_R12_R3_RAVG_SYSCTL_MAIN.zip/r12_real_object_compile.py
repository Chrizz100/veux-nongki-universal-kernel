#!/usr/bin/env python3
"""VEUX R12 real kernel WALT-ON object compile plus OEM proc sysctl symbol check.
Read-only original checkout; disposable kernel snapshot; never link Image/flash.
"""
import argparse,hashlib,importlib.util,json,os,re,shutil,subprocess,sys
from pathlib import Path

class GateError(Exception): pass

def check(p,reason):
    if not p:raise GateError(reason)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

R9_DRIVER_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
R11_SCHED_HASH='2a61b4d52c2630a0851ee379650634dfa96b004db592820ba1e9bc6ad4d0bbfd'
EXPECTED_TARGETS=('kernel/sched/walt/walt.o','kernel/sched/core.o','kernel/sched/fair.o','kernel/sysctl.o')

def verdict(three,sysctl,nm=None):
    flags={k:bool(three.get('objects',{}).get(k,{}).get('compiled')) for k in EXPECTED_TARGETS[:3]}
    flags[EXPECTED_TARGETS[3]]=bool(sysctl.get('compiled'))
    success=all(flags.values()) and nm is not None and bool(nm.get('defined')) and bool(nm.get('referenced'))
    return ('R12_FOUR_REAL_OBJECTS_AND_SYMBOL_CONTRACT_PROVEN' if success else
            'R12_COMPILER_ERRORS_RECORDED' if three.get('object_make_attempted') else
            'R12_PRECOMPILATION_BLOCKED'),flags,success

def run(snapshot,r11gate,r12gate,r11result,r9report,r11report,report,stock,toolchain,driver):
    check(snapshot.is_dir() and not snapshot.is_symlink(),'SNAPSHOT_REQUIRED')
    check(not report.exists() and not report.is_symlink(),'REPORT_ALREADY_EXISTS')
    for p in (r11gate,r12gate,r11result,driver,stock):
        check(p.is_file() and not p.is_symlink(),'SOURCE_PROOF_MISSING:'+str(p))
    check(sha(driver)==R9_DRIVER_SHA,'R9_DRIVER_CHANGED')
    r11=json.loads(r11gate.read_text());g=json.loads(r12gate.read_text());prev=json.loads(r11result.read_text())
    check(r11['status']=='R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED','WRONG_R11_SOURCE')
    check(r11['after_sha256']['kernel/sched/sched.h']==R11_SCHED_HASH,'R11_SCHED_SHA_CHANGED')
    check(prev['status']=='R11_COMPILER_ERRORS_RECORDED' and prev['object_success_count']==2,'R11_DIAG_DRIFT')
    check(g['status']=='R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED' and g['modified_files']==['include/linux/sysctl.h','kernel/sysctl.c'],'BAD_R12_GATE')
    check(g['real_r11_compiler_failure_verified'] is True and g['allowed_windows']==[2,3,4,5,8],'R12_OEM_SEMANTICS_MISSING')
    for name,h in {**r11['after_sha256'],**g['after_sha256']}.items():
        p=snapshot/name
        check(p.is_file() and not p.is_symlink() and sha(p)==h,'SOURCE_CHANGED:'+name)
    for d in (r11report,r9report):check(d.is_dir() and not d.is_symlink(),'R9_R11_PROVENANCE_DIR_MISSING')
    origin=json.loads((r9report/'R9_STAGE_REPORT.json').read_text())
    check(origin['status']=='R9_SOURCE_SNAPSHOT_STAGED' and Path(origin['snapshot']).resolve()==snapshot.resolve(),'SNAPSHOT_PROVENANCE_DRIFT')
    spec=importlib.util.spec_from_file_location('r9_original_pinned',driver)
    check(spec is not None and spec.loader is not None,'R9_DRIVER_NOT_LOADABLE')
    r9=importlib.util.module_from_spec(spec);spec.loader.exec_module(r9)
    check(r9.R8_SCHED_HASH=='12f10b1be96b1868304dd0f5e85a8e4e421ae72383d8b76571a2dc91fd6d4f5d','ORIGINAL_DRIVER_PIN_DRIFT')
    r9.R8_SCHED_HASH=R11_SCHED_HASH
    report.mkdir(parents=True)
    shutil.copy2(r9report/'R9_STAGE_REPORT.json',report/'R9_STAGE_REPORT.json')
    objout=report.parent/'veux-r12-objout'
    result={'status':'R12_STARTED','objects':{},'object_success_count':0,'image_built':False,'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False,
            'r11_compiled':2,'source_r12_sha256':g['after_sha256'],'kernel_version':'5.4.274','config_walt_y':False}
    (report/'R12_COMPILER_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    three=r9.compile_objects(snapshot,objout,report,stock,toolchain,limit=300,jobs=2)
    sysctl={'compiled':False,'exit_code':None,'object_file_present':False,'object_bytes':0}
    syms={'defined':False,'referenced':False,'checked':False}
    if three.get('object_make_attempted'):
        env=os.environ.copy();env['PATH']=str(toolchain/'bin')+os.pathsep+env.get('PATH','')
        target='kernel/sysctl.o'
        log=report/'compiler_logs/06_kernel_sysctl.o.log'
        outcome=r9.run_cmd(r9.make_argv(snapshot,objout,toolchain,target,2),log,300,env=env)
        obj=objout/target
        size=obj.stat().st_size if obj.is_file() and not obj.is_symlink() else 0
        sysctl={**outcome,'object_file_present':size>0,'object_bytes':size,'compiled':outcome['exit_code']==0 and size>0}
        if sysctl['compiled']:sysctl['object_sha256']=sha(obj)
        if sysctl['compiled'] and three['objects'].get('kernel/sched/walt/walt.o',{}).get('compiled'):
            nm=toolchain/'bin/llvm-nm';check(nm.is_file() and not nm.is_symlink(),'LLVM_NM_UNAVAILABLE')
            d=subprocess.run([str(nm),str(obj)],capture_output=True,text=True,timeout=30)
            u=subprocess.run([str(nm),str(objout/'kernel/sched/walt/walt.o')],capture_output=True,text=True,timeout=30)
            s=d.stdout+'\n---- WALT OBJECT ----\n'+u.stdout
            (report/'R12_SYMBOL_LINKAGE.txt').write_text(s)
            check(d.returncode==0 and u.returncode==0,'LLVM_NM_FAILED')
            syms={'defined':bool(re.search(r'(?m)\bT proc_douintvec_ravg_window\s*$',d.stdout)),
                  'referenced':bool(re.search(r'(?m)\bU proc_douintvec_ravg_window\s*$',u.stdout)),
                  'checked':True}
    status,flags,all_good=verdict(three,sysctl,syms)
    result.update({'status':status,'objects':{**three.get('objects',{}),EXPECTED_TARGETS[3]:sysctl},
       'object_success_count':sum(flags.values()),'object_make_attempted':bool(three.get('object_make_attempted')),
       'config_walt_y':bool(three.get('config_walt_y')),
       'symbol_contract':syms,'four_object_compile_proven':all_good,
       'full_oem_config_proven':False,'r11_original_failure_verified':True})
    (report/'R12_COMPILER_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R12_REAL_KBUILD_OBJECTS='+str(sum(flags.values()))+'/4; SYMBOL_GATE='+str(syms.get('checked'))+'; STATUS='+status+'; IMAGE=NO; ABI=NO; FLASH=NO')
    return result

def main():
    q=argparse.ArgumentParser()
    for s in ['snapshot','r11-gate','r12-gate','r11-result','r9-report','r11-report','report','stock','toolchain','driver']:
        q.add_argument('--'+s,required=True,type=Path)
    a=q.parse_args()
    try:run(a.snapshot,a.r11_gate,a.r12_gate,a.r11_result,a.r9_report,a.r11_report,a.report,a.stock,a.toolchain,a.driver)
    except (GateError,OSError,ValueError,KeyError,AttributeError,subprocess.SubprocessError) as e:
        print('R12_REAL_COMPILE_GATE_ERROR:'+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
