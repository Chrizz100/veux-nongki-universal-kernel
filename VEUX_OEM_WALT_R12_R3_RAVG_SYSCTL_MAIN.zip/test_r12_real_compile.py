import importlib.util,pathlib,unittest
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r12',ROOT/'r12_real_object_compile.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Tests(unittest.TestCase):
 def fake(self,a=3,b=True,s=True):
  x={'object_make_attempted':True,'objects':{k:{'compiled':i<a} for i,k in enumerate(m.EXPECTED_TARGETS[:3])}}
  y={'compiled':b};z={'defined':s,'referenced':s};return m.verdict(x,y,z)
 def test_01_three_and_symbol(self):self.assertEqual(self.fake()[0],'R12_FOUR_REAL_OBJECTS_AND_SYMBOL_CONTRACT_PROVEN')
 def test_02_three_plus_missing_sysctl(self):self.assertEqual(self.fake(b=False)[0],'R12_COMPILER_ERRORS_RECORDED')
 def test_03_two(self):self.assertEqual(self.fake(a=2)[0],'R12_COMPILER_ERRORS_RECORDED')
 def test_04_one(self):self.assertEqual(self.fake(a=1)[0],'R12_COMPILER_ERRORS_RECORDED')
 def test_05_no_symbols(self):self.assertEqual(self.fake(s=False)[0],'R12_COMPILER_ERRORS_RECORDED')
 def test_06_none(self):self.assertEqual(m.verdict({'object_make_attempted':False,'objects':{}},{'compiled':False})[0],'R12_PRECOMPILATION_BLOCKED')
 def test_07_object_names(self):self.assertEqual(m.EXPECTED_TARGETS[-1],'kernel/sysctl.o')
 def test_08_r11_header_sha(self):self.assertEqual(len(m.R11_SCHED_HASH),64)
 def test_09_r9_driver_pin(self):self.assertEqual(len(m.R9_DRIVER_SHA),64)
 def test_10_no_fake_abi(self):self.assertIn('vendor_abi_proven\':False', (ROOT/'r12_real_object_compile.py').read_text())
 def test_11_no_kernel_image(self):self.assertIn('image_built\':False', (ROOT/'r12_real_object_compile.py').read_text())
 def test_12_real_make(self):self.assertIn("make_argv(snapshot,objout,toolchain,target,2)",(ROOT/'r12_real_object_compile.py').read_text())
 def test_13_real_nm(self):self.assertIn("'llvm-nm'",(ROOT/'r12_real_object_compile.py').read_text()) if False else self.assertIn('llvm-nm',(ROOT/'r12_real_object_compile.py').read_text())
 def test_14_only_pinned_three(self):self.assertEqual(len(m.EXPECTED_TARGETS),4)
if __name__=='__main__':unittest.main()
