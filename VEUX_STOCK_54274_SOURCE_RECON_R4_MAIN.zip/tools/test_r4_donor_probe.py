import tempfile
import unittest
from pathlib import Path
import r4_donor_probe as r

SCHED='''#define __P(F) 42
#define   PM(F, M) __PS(#F, p->F & (M))
PM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED);
'''
VMSCAN='''static DEFINE_RWLOCK(shrinker_rwlock);

#ifdef CONFIG_MEMCG
'''+ ('\n'.join(['x(&shrinker_rwsem);']*7))+'\n'+ ('\n'.join(['x(&shrinker_rwlock);']*6))+'\n'

class Tests(unittest.TestCase):
 def test_sched_transform(self):
  s=r.transform_sched(SCHED);self.assertIn('SEQ_printf(m',s);self.assertIn('(long long)(p->F & (M))',s);self.assertNotIn('__PS(',s)
 def test_sched_missing_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_sched(SCHED.replace('PM(F, M)','ZZ(F, M)'))
 def test_sched_duplicate_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_sched(SCHED+ r.SCHED_FROM +'\n')
 def test_sched_predefined_is_blocked(self):
  with self.assertRaisesRegex(ValueError,'UNEXPECTED'):r.transform_sched(SCHED+'#define __PS x\n')
 def test_vmscan_transform(self):
  s=r.transform_vmscan(VMSCAN);self.assertIn('static DECLARE_RWSEM(shrinker_rwsem);',s);self.assertEqual(s.count('DEFINE_RWLOCK(shrinker_rwlock)'),1)
 def test_vmscan_wrong_use_count(self):
  with self.assertRaisesRegex(ValueError,'SEM_USE_DRIFT'):r.transform_vmscan(VMSCAN.replace('&shrinker_rwsem','&other',1))
 def test_vmscan_wrong_lock_count(self):
  with self.assertRaisesRegex(ValueError,'LOCK_USE_DRIFT'):r.transform_vmscan(VMSCAN.replace('&shrinker_rwlock','&other',1))
 def test_vmscan_reject_already_defined(self):
  with self.assertRaisesRegex(ValueError,'ALREADY_DEFINED'):r.transform_vmscan(VMSCAN+'static DECLARE_RWSEM(shrinker_rwsem);')
 def test_vmscan_missing_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_vmscan(VMSCAN.replace('#ifdef CONFIG_MEMCG','#ifdef CONFIG_NOPE'))
 def test_report_on_failure(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d); (p/'log').write_text('foo.c:17:2: error: broken\nLLVM ERROR: IO failure on output stream: Broken pipe\n');(p/'rc').write_text('2\n')
   x=r.summarize(p/'log',p/'rc',p/'report.json');self.assertFalse(x['image_flashable']);self.assertEqual(x['status'],'PROBE_COMPILER_FAILED');self.assertTrue((p/'report.json').exists());self.assertEqual(x['llvm_broken_pipe_count'],1);self.assertEqual(x['compiler_error_count'],1)
 def test_report_on_success_is_still_noflash(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'log').write_text('done\n');(p/'rc').write_text('0\n');x=r.summarize(p/'log',p/'rc',p/'report.json');self.assertEqual(x['status'],'PROBE_COMPILED');self.assertFalse(x['image_distributable']);self.assertFalse(x['oem_abi_verified'])

 def test_header_macro_exists_in_pinned_donor_form(self):
  r.verify_rwsem_header('#define DECLARE_RWSEM(name) \\\n\tstruct rw_semaphore name = __RWSEM_INITIALIZER(name)\n')
 def test_header_missing_macro_blocked(self):
  with self.assertRaisesRegex(ValueError,'NOT_SUPPORTED'):
   r.verify_rwsem_header('#define DEFINE_RWLOCK(x) thing\n')
 def test_header_unexpected_modern_macro_blocked(self):
  with self.assertRaisesRegex(ValueError,'UNEXPECTED_DEFINE'):
   r.verify_rwsem_header('#define DECLARE_RWSEM(name) \\\n\tfoo\n#define DEFINE_RWSEM(name) bar\n')
 def test_vmscan_reject_modern_declaration(self):
  with self.assertRaisesRegex(ValueError,'ALREADY_DEFINED'):
   r.transform_vmscan(VMSCAN+'static DEFINE_RWSEM(shrinker_rwsem);\n')
 def test_donor_macro_typo_regression(self):
  self.assertNotIn('static DEFINE_RWSEM(shrinker_rwsem)',r.transform_vmscan(VMSCAN))
 def test_compiler_errors_separated_from_llvm_transport(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'log').write_text('LLVM ERROR: IO failure on output stream: Broken pipe\nmm/vmscan.c:194:1: error: invalid\nmake: *** Error 2\n')
   (p/'rc').write_text('2\n')
   s=r.summarize(p/'log',p/'rc',p/'summary.json')
   self.assertEqual(s['compiler_error_count'],1)
   self.assertEqual(s['llvm_broken_pipe_count'],1)
   self.assertFalse(s['image_flashable'])

if __name__=='__main__':unittest.main()
