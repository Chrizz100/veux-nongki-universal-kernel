# VEUX Stock 5.4.274 – R4 isolierter Compiler-Probelauf (NOFLASH)

**Ausgang:** GitHub R3 #41996676067: Workflow erfolgreich, echter Compiler RC=2.
Der eingefügte `static DEFINE_RWSEM(shrinker_rwsem)` ist für den gepinnten Kernelquellbaum 5.4.268 ungültig. Der unveränderte Header `include/linux/rwsem.h` stellt dagegen `DECLARE_RWSEM(name)` bereit.

**Gezielte Änderung:** Temporär in einer abgetrennten Git-Worktree-Kopie `static DECLARE_RWSEM(shrinker_rwsem)` einsetzen. Nur zwei Dateien der Spenderquelle ändern: `kernel/sched/debug.c` und `mm/vmscan.c`. Vorher gegen exakte Original-Git-Blob-Hashes prüfen, einschließlich des rwsem-Headers.

**Keine Vendor-/Stock-Freigabe:** Der Spender ist 5.4.268 und NICHT der von Xiaomi nicht veröffentlichte originale Quellcode zu 5.4.274. Eine akzeptierte Deklaration garantiert **nicht** die Richtigkeit von Lock-Order/Locking bei Speicher-Reclaim. Der vollständige OEM-ABI-Nachweis (und Device-Boot-Test) fehlt. Kein boot.img, kein AK3, kein Flash.

**Workflow:** `VEUX_STOCK_54274_SOURCE_RECON_R4_NOFLASH.yml`, automatisch ohne Checkbox. Bestehende R1- und R2-MAIN-Dateien im Repo beibehalten, neue R4-MAIN im Repo-Hauptverzeichnis. R3-MAIN wird durch R4 nicht mehr benötigt.

Der Prüf-Workflow markiert sich auch bei fehlgeschlagenem Compiler-Experiment als Erfolg, damit die Logs hochgeladen werden; maßgeblich ist `R4_DONOR_BUILD_SUMMARY.json` / `exit_code`.
