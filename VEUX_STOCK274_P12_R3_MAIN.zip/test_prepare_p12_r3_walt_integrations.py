#!/usr/bin/env python3
import importlib.util, hashlib, pathlib, tempfile, unittest, copy
from unittest.mock import patch
S=pathlib.Path(__file__).with_name('prepare_p12_r3_walt_integrations.py')
spec=importlib.util.spec_from_file_location('p12_r3',S)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def fixture():
 return {
'include/linux/cpumask.h':'''#define cpu_active_mask   ((const struct cpumask *)&__cpu_active_mask)
extern cpumask_t cpus_booted_once_mask;
static inline void
set_cpu_active(unsigned int cpu, bool active)
{
\tif (active)
\t\tcpumask_set_cpu(cpu, &__cpu_active_mask);
\telse
\t\tcpumask_clear_cpu(cpu, &__cpu_active_mask);
}
''',
'kernel/cpu.c':'''struct cpumask __cpu_active_mask __read_mostly;
EXPORT_SYMBOL(__cpu_active_mask);
void init_cpu_online(const struct cpumask *src)
{
\tcpumask_copy(&__cpu_online_mask, src);
}
''',
'include/linux/sched.h':'''#ifdef CONFIG_SCHED_WALT
extern void walt_task_dead(struct task_struct *p);
''',
'kernel/sched/core.c':'''#include "walt/walt.h"

#define CREATE_TRACE_POINTS
''',
'kernel/sched/fair.c':'''#include "walt/walt.h"
static unsigned long capacity_of(int cpu);
static inline unsigned long task_util(struct task_struct *p)
{
\treturn READ_ONCE(p->se.avg.util_avg);
}
static inline unsigned long cpu_util(int cpu);
static unsigned long capacity_of(int cpu)
{
\treturn cpu_rq(cpu)->cpu_capacity;
}
static inline unsigned long cpu_util(int cpu)
{
\tstruct cfs_rq *cfs_rq;
\tunsigned int util;
\tcfs_rq = &cpu_rq(cpu)->cfs;
\tutil = READ_ONCE(cfs_rq->avg.util_avg);
\tif (sched_feat(UTIL_EST))
\t\tutil = max(util, READ_ONCE(cfs_rq->avg.util_est.enqueued));
\treturn min_t(unsigned long, util, capacity_orig_of(cpu));
}
''',
'kernel/sched/sched.h':'''#ifdef CONFIG_SCHED_WALT
extern u64 sched_ktime_clock(void);
enum sched_boost_policy {
SCHED_BOOST_NONE,
SCHED_BOOST_ON_BIG,
SCHED_BOOST_ON_ALL,
};
'''
 }

def bfixture():return {p:s.encode('utf8') for p,s in fixture().items()}

class R3Tests(unittest.TestCase):
 def setUp(self):self.b=bfixture()
 def stage(self):return m.transform(self.b)
 def test_01_exact_paths(self):self.assertEqual(set(m.R3_PATHS),set(self.b))
 def test_02_patch_roundtrip(self):
  after=self.stage();m.verify_roundtrip(self.b,after,m.patch_between(self.b,after))
 def test_03_deterministic_patch(self):
  a=m.patch_between(self.b,self.stage());bb=m.patch_between(self.b,self.stage());self.assertEqual(a,bb)
 def test_04_all_six_changed(self):
  after=self.stage();self.assertEqual(set(after),set(self.b));self.assertTrue(all(self.b[x]!=after[x] for x in m.R3_PATHS))
 def test_05_no_oem(self):self.assertFalse(any(x.startswith('kernel/sched/walt/') for x in m.R3_PATHS))
 def test_06_cpu_isolated_real_mask(self):
  out=self.stage()['include/linux/cpumask.h'].decode();self.assertIn('cpumask_test_cpu((cpu), cpu_isolated_mask)',out)
 def test_07_cpu_mask_export_guard(self):
  out=self.stage()['kernel/cpu.c'].decode();self.assertIn('EXPORT_SYMBOL(__cpu_isolated_mask)',out);self.assertIn('#ifdef CONFIG_SCHED_WALT',out)
 def test_08_set_cpu_isolated(self):self.assertIn('set_cpu_isolated(unsigned int cpu',self.stage()['include/linux/cpumask.h'].decode())
 def test_09_load_boost_decl_def(self):
  after=self.stage();self.assertIn('DECLARE_PER_CPU_READ_MOSTLY(int, sched_load_boost)',after['include/linux/sched.h'].decode());self.assertIn('DEFINE_PER_CPU_READ_MOSTLY(int, sched_load_boost)',after['kernel/sched/fair.c'].decode())
 def test_10_sched_predl_decl_def(self):
  after=self.stage();self.assertIn('extern __read_mostly bool sched_predl',after['kernel/sched/sched.h'].decode());self.assertIn('bool sched_predl = 1',after['kernel/sched/core.c'].decode())
 def test_11_real_walt_task_util(self):self.assertIn('READ_ONCE(p->wts.demand_scaled)',self.stage()['kernel/sched/sched.h'].decode())
 def test_12_real_walt_cpu_util(self):self.assertIn('wrq.walt_stats.cumulative_runnable_avg_scaled',self.stage()['kernel/sched/sched.h'].decode())
 def test_13_legacy_task_util_retained(self):self.assertIn('return READ_ONCE(p->se.avg.util_avg);',self.stage()['kernel/sched/fair.c'].decode())
 def test_14_legacy_cpu_util_retained(self):self.assertIn('util = READ_ONCE(cfs_rq->avg.util_avg);',self.stage()['kernel/sched/fair.c'].decode())
 def test_15_walt_off_guards(self):self.assertGreaterEqual(self.stage()['kernel/sched/fair.c'].decode().count('#ifndef CONFIG_SCHED_WALT'),4)
 def test_16_margins(self):
  f=self.stage()['kernel/sched/fair.c'].decode();self.assertIn('1078',f);self.assertIn('1205',f)
 def test_17_capacity(self):self.assertIn('cap_scale(max_cap, scale_freq)',self.stage()['kernel/sched/fair.c'].decode())
 def test_18_irq_queue(self):self.assertIn('irq_work_queue_on(work',self.stage()['kernel/sched/sched.h'].decode())
 def test_19_guard_empty(self):
  with self.assertRaises(ValueError):m.transform({})
 def test_20_guard_existing_cpu_mask(self):
  d=copy.copy(self.b);d['include/linux/cpumask.h']+=b'cpu_isolated_mask';
  with self.assertRaises(ValueError):m.transform(d)
 def test_21_guard_existing_kernel_cpu(self):
  d=copy.copy(self.b);d['kernel/cpu.c']+=b'__cpu_isolated_mask';
  with self.assertRaises(ValueError):m.transform(d)
 def test_22_guard_missing_core_include(self):
  d=copy.copy(self.b);d['kernel/sched/core.c']=b''
  with self.assertRaises(ValueError):m.transform(d)
 def test_23_guard_missing_fair_func(self):
  d=copy.copy(self.b);d['kernel/sched/fair.c']=d['kernel/sched/fair.c'].replace(b'static unsigned long capacity_of(int cpu)\n{',b'static unsigned long cap_of(int cpu)\n{')
  with self.assertRaises(ValueError):m.transform(d)
 def test_24_guard_duplicate_public_decl(self):
  d=copy.copy(self.b);d['include/linux/sched.h']*=2
  with self.assertRaises(ValueError):m.transform(d)
 def test_25_guard_missing_sched_helpers(self):
  d=copy.copy(self.b);d['kernel/sched/sched.h']=b'hello'
  with self.assertRaises(ValueError):m.transform(d)
 def test_26_guard_missing_cpu_online(self):
  d=copy.copy(self.b);d['kernel/cpu.c']=b'foo'
  with self.assertRaises(ValueError):m.transform(d)
 def test_27_guard_missing_cpumask_set(self):
  d=copy.copy(self.b);d['include/linux/cpumask.h']=b'foo'
  with self.assertRaises(ValueError):m.transform(d)
 def test_28_guard_missing_fair_def(self):
  d=copy.copy(self.b);d['kernel/sched/fair.c']=b'foo'
  with self.assertRaises(ValueError):m.transform(d)
 def test_29_no_flash_output(self):
  for a in self.stage().values():self.assertNotIn(b'flashable',a)
 def test_30_full_sha256(self):self.assertEqual(len(m.sha(b'a')),64)
 def test_31_git_oid(self):self.assertEqual(len(m.oid(b'a')),40)
 def test_32_r1_hash_format(self):self.assertEqual(len(m.EXPECTED_R1_SHA),64)
 def test_33_r2_hash_format(self):self.assertEqual(len(m.EXPECTED_R2_SHA),64)
 def test_34_patch_scope(self):
  s=m.patch_between(self.b,self.stage()).decode();self.assertEqual(s.count('diff --git a/'),6)
 def test_35_no_duplicate_sched_global(self):
  after=self.stage();self.assertEqual(after['kernel/sched/core.c'].decode().count('bool sched_predl = 1;'),1)
 def test_36_capacity_orig_nomod(self):
  self.assertIn(b'cpu_rq(cpu)->cpu_capacity;',self.stage()['kernel/sched/fair.c'])
 def test_37_input_not_modified(self):
  b=copy.copy(self.b);m.transform(self.b);self.assertEqual(self.b,b)
 def test_38_bad_patch_rejected(self):
  p=m.patch_between(self.b,self.stage())
  with self.assertRaises(Exception):m.verify_roundtrip(self.b,self.stage(),p.replace(b'cpu_isolated_mask',b'cpu_unisolated_mask'))
 def test_39_nine_paths_r2(self):self.assertEqual(len(m.R2_PATHS),9)
 def test_40_report_drift_would_fail(self):self.assertEqual(m.EXPECTED_R2_POST['include/linux/sched.h'],'28c4c097871a46083960affecf6c5b015cd65d527fd2b9254b7e495e0605fa7e')
 def test_41_macro_config_smp(self):self.assertIn('#ifdef CONFIG_SMP',self.stage()['kernel/sched/sched.h'].decode())
 def test_42_real_isolated_not_stub(self):self.assertIn('cpumask_andnot(&_m, cpu_online_mask, cpu_isolated_mask)',self.stage()['include/linux/cpumask.h'].decode())
 def test_43_new_root_only(self):self.assertEqual(len(m.R3_PATHS),len(set(m.R3_PATHS)))
 def test_44_eol(self):self.assertTrue(all(x.endswith(b'\n') for x in self.stage().values()))
if __name__=='__main__':unittest.main(verbosity=2)
