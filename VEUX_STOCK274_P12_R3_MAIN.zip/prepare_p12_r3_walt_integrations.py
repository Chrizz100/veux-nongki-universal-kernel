#!/usr/bin/env python3
"""P12 R3: source-only, fail-closed follow-up to R1 + R2.

No upstream writes, no WALT OEM file modifications, no flash artifact.  The
resulting *candidate* source patch adds missing upstream interfaces, preserving
WALT=n source logic and keeping vendor ABI/device checks pending.
"""
from __future__ import annotations
import argparse, difflib, hashlib, json, pathlib, re, subprocess, sys, tempfile

FROZEN_P11_TREE='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
EXPECTED_R1_SHA='5d3547b79a672c1c02aaf01cc8d3b606a7168e388e5f75e22677a16ec6eccea2'
EXPECTED_R2_SHA='63d755014340cdc4e85b9750fd4090090583cff058221b162dc4e685db5c2860'
R2_PATHS=('include/linux/sched.h','include/linux/sched/stat.h','include/linux/sched/sysctl.h',
          'kernel/sched/core.c','kernel/sched/deadline.c','kernel/sched/fair.c','kernel/sched/rt.c',
          'kernel/sched/sched.h','kernel/sched/stop_task.c')
R3_PATHS=('include/linux/cpumask.h','include/linux/sched.h','kernel/cpu.c','kernel/sched/core.c',
          'kernel/sched/fair.c','kernel/sched/sched.h')
EXPECTED_R2_POST={'include/linux/sched.h':'28c4c097871a46083960affecf6c5b015cd65d527fd2b9254b7e495e0605fa7e',
                  'include/linux/sched/stat.h':'2e39fdbc19b39689ce72368dd9ec66bc43d72e3e754e9586d3aebe854a534b75'}

def sha(b: bytes) -> str:return hashlib.sha256(b).hexdigest()
def oid(b: bytes) -> str:return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def one(s: str, old: str, new: str, tag: str) -> str:
 n=s.count(old)
 if n!=1:raise ValueError(f'ANCHOR_{tag}_COUNT_{n}')
 return s.replace(old,new,1)

def guard_function(s: str, signature: str, tag: str) -> str:
 if s.count(signature)!=1:raise ValueError('FUNCTION_ANCHOR_'+tag)
 pos=s.index(signature); start=s.find('{',pos)
 if start<0:raise ValueError('NO_BRACE_'+tag)
 # balanced braces are safe for the exact vetted functions below (no strings containing braces).
 level=0;end=None
 for i in range(start,len(s)):
  if s[i]=='{':level+=1
  elif s[i]=='}':
   level-=1
   if level==0:end=i+1;break
 if end is None:raise ValueError('UNBALANCED_'+tag)
 block=s[pos:end]
 if not block.startswith(signature) or block.count('{')==0:raise ValueError('BAD_FUNCTION_'+tag)
 return s[:pos]+'#ifndef CONFIG_SCHED_WALT\n'+block+'\n#endif /* !CONFIG_SCHED_WALT */'+s[end:]

def transform(before:dict[str,bytes]) -> dict[str,bytes]:
 if set(before)!=set(R3_PATHS):raise ValueError('PATH_SCOPE')
 s={p:b.decode('utf8') for p,b in before.items()}
 p='include/linux/cpumask.h'
 if 'cpu_isolated_mask' in s[p]:raise ValueError('CPU_MASK_ALREADY_PORTED')
 s[p]=one(s[p],'#define cpu_active_mask   ((const struct cpumask *)&__cpu_active_mask)\n',
             '#define cpu_active_mask   ((const struct cpumask *)&__cpu_active_mask)\n'
             '\n#ifdef CONFIG_SCHED_WALT\n'
             'extern struct cpumask __cpu_isolated_mask;\n'
             '#define cpu_isolated_mask ((const struct cpumask *)&__cpu_isolated_mask)\n'
             '#endif\n','CPU_MASK_DECL')
 s[p]=one(s[p],'extern cpumask_t cpus_booted_once_mask;\n',
             '''#if defined(CONFIG_SCHED_WALT) && NR_CPUS > 1
#define num_isolated_cpus() cpumask_weight(cpu_isolated_mask)
#define num_online_uniso_cpus() ({ cpumask_t _m; cpumask_andnot(&_m, cpu_online_mask, cpu_isolated_mask); cpumask_weight(&_m); })
#define cpu_isolated(cpu) cpumask_test_cpu((cpu), cpu_isolated_mask)
#else
#define num_isolated_cpus() 0U
#define num_online_uniso_cpus() num_online_cpus()
#define cpu_isolated(cpu) 0U
#endif

extern cpumask_t cpus_booted_once_mask;
''','CPU_MASK_API')
 # place after real set_cpu_active function; global matched anchor comes next in Positron cpumask.h
 needle='''set_cpu_active(unsigned int cpu, bool active)
{
	if (active)
		cpumask_set_cpu(cpu, &__cpu_active_mask);
	else
		cpumask_clear_cpu(cpu, &__cpu_active_mask);
}
'''
 if needle not in s[p]:raise ValueError('CPU_MASK_SET_API')
 s[p]=one(s[p],needle,needle+'''\n#ifdef CONFIG_SCHED_WALT
static inline void set_cpu_isolated(unsigned int cpu, bool isolated)
{
	if (isolated)
		cpumask_set_cpu(cpu, &__cpu_isolated_mask);
	else
		cpumask_clear_cpu(cpu, &__cpu_isolated_mask);
}
#endif
''','CPU_MASK_SET_API')
 p='kernel/cpu.c'
 if '__cpu_isolated_mask' in s[p]:raise ValueError('KERNEL_CPU_ALREADY_PORTED')
 needle='struct cpumask __cpu_active_mask __read_mostly;\nEXPORT_SYMBOL(__cpu_active_mask);\n'
 s[p]=one(s[p],needle,needle+'''\n#ifdef CONFIG_SCHED_WALT
struct cpumask __cpu_isolated_mask __read_mostly;
EXPORT_SYMBOL(__cpu_isolated_mask);
#endif
''','KERNEL_CPU_MASK')
 needle='''void init_cpu_online(const struct cpumask *src)
{
	cpumask_copy(&__cpu_online_mask, src);
}
'''
 s[p]=one(s[p],needle,needle+'''\n#ifdef CONFIG_SCHED_WALT
void init_cpu_isolated(const struct cpumask *src)
{
	cpumask_copy(&__cpu_isolated_mask, src);
}
#endif
''','CPU_MASK_INIT')
 p='include/linux/sched.h'
 marker='#ifdef CONFIG_SCHED_WALT\nextern void walt_task_dead(struct task_struct *p);\n'
 s[p]=one(s[p],marker,'#ifdef CONFIG_SCHED_WALT\nDECLARE_PER_CPU_READ_MOSTLY(int, sched_load_boost);\nextern void walt_task_dead(struct task_struct *p);\n','SCHED_PUBLIC_LOAD_BOOST')
 p='kernel/sched/core.c'
 marker='#include "walt/walt.h"\n'
 s[p]=one(s[p],marker,marker+'''\n/* Xiaomi WALT predictive demand switch; default matches vendor. */
#ifdef CONFIG_SCHED_WALT
__read_mostly bool sched_predl = 1;
#endif
''','SCHED_PREDL')
 p='kernel/sched/fair.c'
 marker='#include "walt/walt.h"\n'
 s[p]=one(s[p],marker,marker+'''\n#ifdef CONFIG_SCHED_WALT
/* Original Xiaomi VEUX migration margins (per CPU). */
unsigned int sched_capacity_margin_up[NR_CPUS] = {
	[0 ... NR_CPUS - 1] = 1078
};
unsigned int sched_capacity_margin_down[NR_CPUS] = {
	[0 ... NR_CPUS - 1] = 1205
};
DEFINE_PER_CPU_READ_MOSTLY(int, sched_load_boost);

/* Original Xiaomi CPU/frequency capacity accounting. */
unsigned long capacity_curr_of(int cpu)
{
	unsigned long max_cap = cpu_rq(cpu)->cpu_capacity_orig;
	unsigned long scale_freq = arch_scale_freq_capacity(cpu);
	return cap_scale(max_cap, scale_freq);
}
#endif
''','FAIR_XIAOMI_GLOBALS')
 s[p]=one(s[p],'static unsigned long capacity_of(int cpu);\n',
                    '#ifndef CONFIG_SCHED_WALT\nstatic unsigned long capacity_of(int cpu);\n#endif /* !CONFIG_SCHED_WALT */\n','FAIR_CAPACITY_DECL')
 # The original fair.c local helpers are retained only for WALT OFF; WALT ON
 # uses Xiaomi WALT-aware task/cpu util methods shared by all scheduler objects.
 for sig,tag in [('static inline unsigned long task_util(struct task_struct *p)','TASK_UTIL'),
                 ('static unsigned long capacity_of(int cpu)\n{','CAPACITY'),
                 ('static inline unsigned long cpu_util(int cpu)\n{','CPU_UTIL')]:
  s[p]=guard_function(s[p],sig,tag)
 # Avoid a redundant private declaration of cpu_util in the vendor fair.c.
 old='static inline unsigned long cpu_util(int cpu);\n'
 if s[p].count(old)>1:raise ValueError('CPU_UTIL_FWD_AMBIGUOUS')
 if old in s[p]:s[p]=one(s[p],old,'#ifndef CONFIG_SCHED_WALT\n'+old+'#endif /* !CONFIG_SCHED_WALT */\n','FAIR_CPU_UTIL_FWD')
 p='kernel/sched/sched.h'
 marker='#ifdef CONFIG_SCHED_WALT\nextern u64 sched_ktime_clock(void);\n'
 if marker not in s[p]:raise ValueError('R2_HELPER_REGION_MISSING')
 helpers='''#ifdef CONFIG_SCHED_WALT
/* WALT versions of scheduler-private load and capacity APIs. */
extern __read_mostly bool sched_predl;
extern unsigned int sched_capacity_margin_up[NR_CPUS];
extern unsigned int sched_capacity_margin_down[NR_CPUS];
unsigned long capacity_curr_of(int cpu);
#ifdef CONFIG_SMP
static inline unsigned long capacity_of(int cpu)
{
	return cpu_rq(cpu)->cpu_capacity;
}
static inline unsigned long task_util(struct task_struct *p)
{
	return READ_ONCE(p->wts.demand_scaled);
}
static inline unsigned long cpu_util(int cpu)
{
	u64 util = cpu_rq(cpu)->wrq.walt_stats.cumulative_runnable_avg_scaled;
	return min_t(unsigned long, util, capacity_orig_of(cpu));
}
#endif /* CONFIG_SMP */
static inline void walt_irq_work_queue(struct irq_work *work)
{
	if (likely(cpu_online(raw_smp_processor_id())))
		irq_work_queue(work);
	else
		irq_work_queue_on(work, cpumask_any(cpu_online_mask));
}
'''
 s[p]=one(s[p],marker,helpers+'extern u64 sched_ktime_clock(void);\n','SCHED_WALT_HELPERS')
 out={p:t.encode('utf8') for p,t in s.items()}
 for p in R3_PATHS:
  if out[p]==before[p]:raise ValueError('UNCHANGED_'+p)
  if 'kernel/sched/walt/' in p:raise ValueError('OEM_MUTATION')
 return out

def patch_between(before,after):
 chunks=[]
 for name in R3_PATHS:
  orig=before[name];new=after[name]
  s=''.join(difflib.unified_diff(orig.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name,n=3))
  if not s:raise ValueError('EMPTY_DIFF '+name)
  chunks.append(f'diff --git a/{name} b/{name}\nindex {oid(orig)[:12]}..{oid(new)[:12]} 100644\n'+s)
 return ''.join(chunks).encode()

def call(cmd, cwd=None):
 r=subprocess.run(cmd,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
 if r.returncode:raise RuntimeError(f'COMMAND_FAILED {cmd[:3]}: '+r.stderr.decode(errors='replace')[-800:])
 return r.stdout.decode()

def apply_and_revert(root: pathlib.Path,patch: pathlib.Path):
 call(['git','apply','--check',str(patch)],root)
 call(['git','apply',str(patch)],root)

def verify_roundtrip(before,after,patch):
 with tempfile.TemporaryDirectory(prefix='p12_r3_roundtrip_') as tmp:
  root=pathlib.Path(tmp)
  for name,b in before.items():
   f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  pf=root/'r3.patch';pf.write_bytes(patch)
  apply_and_revert(root,pf)
  for name,v in after.items():
   if (root/name).read_bytes()!=v:raise ValueError('PATCH_POSTIMAGE_'+name)
  call(['git','apply','--check','-R',str(pf)],root)
  call(['git','apply','-R',str(pf)],root)
  for name,v in before.items():
   if (root/name).read_bytes()!=v:raise ValueError('PATCH_REVERSE_'+name)

def stage(source,r1report,r1patch,r2report,r2patch,output):
 source=source.resolve(strict=True);output=output.resolve()
 if output.exists() or output.is_relative_to(source):raise ValueError('OUTPUT_UNSAFE')
 if not (source/'.git').is_dir():raise ValueError('NOT_GIT_SOURCE')
 if call(['git','rev-parse','HEAD^{tree}'],source).strip()!=FROZEN_P11_TREE:raise ValueError('WRONG_P11_TREE')
 if call(['git','status','--porcelain','--untracked-files=all'],source).strip():raise ValueError('DIRTY_KERNEL_SOURCE')
 r1=json.loads(r1report.read_text());r2=json.loads(r2report.read_text());p1=r1patch.read_bytes();p2=r2patch.read_bytes()
 if r1['input_tree']!=FROZEN_P11_TREE or r2['source_tree']!=FROZEN_P11_TREE:raise ValueError('SOURCE_DRIFT')
 if sha(p1)!=r1['candidate_patch_sha256'] or sha(p1)!=EXPECTED_R1_SHA:raise ValueError('BAD_R1_PATCH')
 if sha(p2)!=r2['r2_patch_sha256'] or sha(p2)!=EXPECTED_R2_SHA:raise ValueError('BAD_R2_PATCH')
 if any(r2['r2_postimage_sha256'].get(n)!=h for n,h in EXPECTED_R2_POST.items()):raise ValueError('R2_REPORT_DRIFT')
 if r2['oem_original_blobs_preserved'] is not True:raise ValueError('OEM_UNSAFE')
 with tempfile.TemporaryDirectory(prefix='p12_r3_preimage_') as tmp:
  root=pathlib.Path(tmp);all_paths=set(R2_PATHS)|set(R3_PATHS)
  for name in all_paths:
   f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((source/name).read_bytes())
  call(['git','apply','--check',str(r1patch.resolve())],root)
  call(['git','apply',str(r1patch.resolve())],root)
  call(['git','apply','--check',str(r2patch.resolve())],root)
  call(['git','apply',str(r2patch.resolve())],root)
  for name,h in r2['r2_postimage_sha256'].items():
   if sha((root/name).read_bytes())!=h:raise ValueError('R2_PREIMAGE_MISMATCH '+name)
  before={name:(root/name).read_bytes() for name in R3_PATHS}
 after=transform(before);patch=patch_between(before,after)
 verify_roundtrip(before,after,patch)
 output.mkdir(parents=True)
 (output/'P12_R2_TO_R3_WALT_SEMANTIC_APIS.patch').write_bytes(patch)
 report={'phase':'P12_R3_SOURCE_STAGING','kernel':'5.4.274','input_tree':FROZEN_P11_TREE,
         'r1_patch_sha256':sha(p1),'r2_patch_sha256':sha(p2),
         'r3_patch_sha256':sha(patch),'changed_paths':list(R3_PATHS),
         'r3_preimage_sha256':{p:sha(v) for p,v in before.items()},
         'r3_postimage_sha256':{p:sha(v) for p,v in after.items()},
         'oem_walt_11_unchanged':True,'flashable':False,'full_build':'NOT_RUN',
         'vendor_abi':'NOT_CHECKED','device_test':'NOT_RUN'}
 (output/'P12_R3_PREP_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 return report

def main():
 parser=argparse.ArgumentParser()
 for key in ('source','r1-report','r1-patch','r2-report','r2-patch','output'):
  parser.add_argument('--'+key,type=pathlib.Path,required=True)
 args=parser.parse_args()
 try:res=stage(args.source,args.r1_report,args.r1_patch,args.r2_report,args.r2_patch,args.output)
 except Exception as e:
  print('P12_R3_FAIL_CLOSED:',str(e),file=sys.stderr)
  return 2
 print('P12_R3_BRIDGE_STAGED=PASS; PATCH_PATHS='+str(len(res['changed_paths']))+'; NO_FLASH')
 return 0
if __name__=='__main__':raise SystemExit(main())
