#!/usr/bin/env bash
# P12 R3: source-integrity verified WALT=y *targeted* object compilation only.
# Expected compile errors are diagnostic data, never a kernel build/release PASS.
set -Eeuo pipefail
export LC_ALL=C TZ=UTC ARCH=arm64
: "${GITHUB_WORKSPACE:?}" "${RUNNER_TEMP:?}" "${P11_TOOLCHAIN_DIR:?}"
KERNEL="$(realpath "$GITHUB_WORKSPACE/kernel")"
R1="$RUNNER_TEMP/VEUX_274_P12_PORT"
R2="$RUNNER_TEMP/VEUX_274_P12_R2_PORT"
R3="$RUNNER_TEMP/VEUX_274_P12_R3_PORT"
EVIDENCE="$RUNNER_TEMP/VEUX_274_P12_R3_EVIDENCE"
OUT="$RUNNER_TEMP/veux-5.4.274-p12-r3-walt-y-out"
REPORT="$EVIDENCE/P12_R3_BUILD_STATUS.json"
mkdir -p "$EVIDENCE/logs"
trap 'rc=$?; if (( rc != 0 )); then python3 - "$REPORT" "$rc" <<\PY
import json, pathlib, sys
pathlib.Path(sys.argv[1]).write_text(json.dumps({"phase":"P12_R3","kernel":"5.4.274","probe":"SETUP_OR_GATE_ERROR","exit_code":int(sys.argv[2]),"flashable":False,"vendor_abi":"NOT_CHECKED","device_test":"NOT_RUN"}, indent=2)+"\n")
PY
fi' EXIT
[[ -d "$KERNEL/.git" && ! -e "$OUT" ]] || exit 2
[[ "$(make -s -C "$KERNEL" kernelversion)" = 5.4.274 ]] || exit 2
[[ -x "$P11_TOOLCHAIN_DIR/bin/clang" ]] || exit 2
export PATH="$P11_TOOLCHAIN_DIR/bin:$PATH"
clang --version | grep -Fq 'r416183b' || exit 2
[[ "$(git -C "$KERNEL" rev-parse HEAD^{tree})" = 04e3831b70ed3ba19a7bd59e3054b7df5418941d ]] || exit 2
[[ -z "$(git -C "$KERNEL" status --porcelain --untracked-files=all)" ]] || exit 2
python3 - "$R1/P12_PREP_REPORT.json" "$R1/P11_TO_P12_WALT_STRUCTS_ONLY.patch" "$R2/P12_R2_PREP_REPORT.json" "$R2/P12_R1_TO_R2_WALT_API_BRIDGE.patch" <<'PY'
import hashlib,json,pathlib,sys
r1=json.loads(pathlib.Path(sys.argv[1]).read_text());p1=pathlib.Path(sys.argv[2])
r2=json.loads(pathlib.Path(sys.argv[3]).read_text());p2=pathlib.Path(sys.argv[4])
assert r1['input_tree']==r2['source_tree']=='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
assert r1['candidate_patch_sha256']==r2['r1_patch_sha256']==hashlib.sha256(p1.read_bytes()).hexdigest()
assert r2['r2_patch_sha256']==hashlib.sha256(p2.read_bytes()).hexdigest()
assert r2['oem_original_blobs_preserved'] is True and r2['flashable'] is False
assert len(r2['changed_paths'])==9 and all(not x.startswith('kernel/sched/walt/') for x in r2['changed_paths'])
print('P12_R1_R2_SHA_SOURCE_CHAIN=PASS')
PY
git -C "$KERNEL" apply --check "$R1/P11_TO_P12_WALT_STRUCTS_ONLY.patch"
git -C "$KERNEL" apply "$R1/P11_TO_P12_WALT_STRUCTS_ONLY.patch"
git -C "$KERNEL" apply --check "$R2/P12_R1_TO_R2_WALT_API_BRIDGE.patch"
git -C "$KERNEL" apply "$R2/P12_R1_TO_R2_WALT_API_BRIDGE.patch"
git -C "$KERNEL" diff --check
python3 - "$KERNEL" "$R2/P12_R2_PREP_REPORT.json" <<'PY'
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);r=json.loads(pathlib.Path(sys.argv[2]).read_text())
changes=subprocess.check_output(['git','-C',str(root),'diff','--name-only'],text=True).splitlines()
expected=sorted(r['changed_paths']);assert changes==expected,(changes,expected)
for name,h in r['r2_postimage_sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,('BAD_POSTIMAGE',name)
from importlib import util
# 11 OEM files must be unchanged in Git index and working tree (no other modifications).
dirty=subprocess.check_output(['git','-C',str(root),'status','--porcelain','--untracked-files=all'],text=True).splitlines()
assert len(dirty)==len(expected) and all(line[3:] in expected for line in dirty),dirty
print('P12_R2_NINE_PATH_POSTIMAGE_AND_OEM_CHECK=PASS')
PY
# Apply R3 only after R1/R2 authenticated postimages were verified.
python3 - "$R2/P12_R2_PREP_REPORT.json" "$R3/P12_R3_PREP_REPORT.json" "$R3/P12_R2_TO_R3_WALT_SEMANTIC_APIS.patch" <<'PY'
import hashlib,json,pathlib,sys
r2=json.loads(pathlib.Path(sys.argv[1]).read_text())
r3=json.loads(pathlib.Path(sys.argv[2]).read_text())
p=pathlib.Path(sys.argv[3]).read_bytes()
assert r3['input_tree']==r2['source_tree']=='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
assert r3['r2_patch_sha256']==r2['r2_patch_sha256']
assert r3['r3_patch_sha256']==hashlib.sha256(p).hexdigest()
assert len(r3['changed_paths'])==6
assert r3['oem_walt_11_unchanged'] is True and r3['flashable'] is False
print('P12_R3_HASH_SOURCE_CHAIN=PASS')
PY
git -C "$KERNEL" apply --check "$R3/P12_R2_TO_R3_WALT_SEMANTIC_APIS.patch"
git -C "$KERNEL" apply "$R3/P12_R2_TO_R3_WALT_SEMANTIC_APIS.patch"
git -C "$KERNEL" diff --check
python3 - "$KERNEL" "$R2/P12_R2_PREP_REPORT.json" "$R3/P12_R3_PREP_REPORT.json" <<'PY'
import hashlib,json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);r2=json.loads(pathlib.Path(sys.argv[2]).read_text());r3=json.loads(pathlib.Path(sys.argv[3]).read_text())
changed=subprocess.check_output(['git','-C',str(root),'diff','--name-only'],text=True).splitlines()
expected=sorted(set(r2['changed_paths'])|set(r3['changed_paths']))
assert changed==expected,('CHANGED_PATHS',changed,expected)
for name,h in r3['r3_postimage_sha256'].items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==h,('POSTIMAGE',name)
assert all(not p.startswith('kernel/sched/walt/') for p in changed)
assert all(not p.startswith('kernel/sched/walt/') for p in r3['changed_paths'])
print('P12_R3_SIX_PATH_POSTIMAGE_NO_OEM_CHANGES=PASS')
PY
mkdir -p "$OUT"
export KBUILD_BUILD_USER='veux-stock274' KBUILD_BUILD_HOST='p12-r3-compile-probe'
export KBUILD_BUILD_TIMESTAMP='Thu Sep 03 00:00:00 UTC 2026'
export KBUILD_BUILD_VERSION=1 SOURCE_DATE_EPOCH=1788393600
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 veux_defconfig > "$EVIDENCE/logs/veux_defconfig.log" 2>&1
"$KERNEL/scripts/config" --file "$OUT/.config" -e SCHED_WALT
make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 olddefconfig > "$EVIDENCE/logs/olddefconfig.log" 2>&1
grep -qx 'CONFIG_SCHED_WALT=y' "$OUT/.config" || exit 2
grep -qx 'CONFIG_UCLAMP_TASK_GROUP=y' "$OUT/.config" || exit 2
grep -qx '# CONFIG_SPRD_ROTATION_TASK is not set' "$OUT/.config" || exit 2
! grep -qE '^CONFIG_(KSU|KERNELSU|SUSFS|SCHED_CASS)=y$' "$OUT/.config" || exit 2
cp "$OUT/.config" "$EVIDENCE/veux_5.4.274_walt_y_r3_probe.config"
sha256sum "$OUT/.config" > "$EVIDENCE/logs/config.sha256"
# Collect ALL error lines without turning a diagnostic-only investigation into a false build PASS.
set +e
timeout 1200 make -C "$KERNEL" O="$OUT" ARCH=arm64 LLVM=1 LLVM_IAS=1 -j3 \
  kernel/sched/core.o kernel/sched/fair.o kernel/sched/rt.o \
  kernel/sched/deadline.o kernel/sched/stop_task.o \
  kernel/sched/cpufreq_schedutil.o kernel/sched/walt/walt.o \
  KCFLAGS=-ferror-limit=0 \
  > "$EVIDENCE/logs/targeted_walt_r3_objects.log" 2>&1
rc=$?
set -e
python3 - "$REPORT" "$rc" "$EVIDENCE/logs/targeted_walt_r3_objects.log" <<'PY'
import json,pathlib,re,sys
path=pathlib.Path(sys.argv[1]);rc=int(sys.argv[2]);log=pathlib.Path(sys.argv[3]).read_text(errors='replace')
errors=[l.strip() for l in log.splitlines() if re.search(r'error:|undefined reference|No rule to make target|fatal error:',l)]
kind='TARGETED_OBJECTS_PASS' if rc==0 else 'PROBE_TIMEOUT_OR_OOM' if rc in (124,137) else 'TARGETED_COMPILE_ERRORS'
s={'kernel':'5.4.274','phase':'P12_R3','probe':kind,'make_exit_code':rc,
'error_excerpt_count':len(errors),'error_excerpts':errors[:120],
'walt_y_targeted_objects':'PASS' if rc==0 else 'FAILED_OR_INCOMPLETE',
'full_walt_y_kernel_build':'NOT_RUN','vendor_abi':'NOT_CHECKED',
'device_test':'NOT_RUN','boot_img':'NOT_CREATED','ak3':'NOT_CREATED','flashable':False}
path.write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
print(f'P12_R3_WALT_OBJECT_PROBE={kind}; ERROR_LINES={len(errors)}; FLASH=NO')
PY
if ((rc==124 || rc==137));then echo 'P12_R3_INFRA_TIMEOUT_OR_OOM' >&2;exit 3;fi
if ((rc!=0));then echo 'P12_R3_DIAGNOSTIC_ERRORS_COLLECTED_WALT_NOT_BUILT' >> "$GITHUB_STEP_SUMMARY"
else echo 'P12_R3_TARGET_OBJECTS_PASS_LINK_ABI_DEVICE_NOT_TESTED' >> "$GITHUB_STEP_SUMMARY";fi
