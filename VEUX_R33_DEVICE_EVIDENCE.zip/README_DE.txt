VEUX R33 Geraetebaum-Diagnose (read only)
Slot: _a
vendor_boot: vendor_boot_a=PARSED, vendor_boot_b=PARSED
dtbo: dtbo_a=PARSED, dtbo_b=PARSED
Warnungen: 0
NO BUILD / NO FLASH / Keine Bootfreigabe
