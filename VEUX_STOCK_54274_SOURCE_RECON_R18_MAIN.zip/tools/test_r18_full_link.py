"""R18 source provenance, no-flash, real ABI and failure-gating regression tests."""
import csv,hashlib,json,tempfile,unittest,contextlib,io
from pathlib import Path
import r18_full_link as r
ROOT=Path(__file__).resolve().parents[1]

class TestR18(unittest.TestCase):
    def test_01_authenticated_originals(self):
        m=r.attest(ROOT)
        self.assertEqual(m['r17_parent_sha256'],r.R17_SHA)
    def test_02_release_reference_donor_is_not_stock(self):
        m=r.attest(ROOT)
        self.assertFalse(m['production_patch_approved'])
        self.assertFalse(m['expected_full_kernel_link_pass'])
    def test_03_r6_14255_exports(self):
        self.assertEqual(len(r.parse_symvers(ROOT/'reference/R6_Module.symvers')),14255)
    def test_04_r6_qgki_imports(self):
        x=r.load_imports(ROOT/'reference/R6_QGKI_IMPORT_ABI.csv')
        self.assertEqual(len(x),3148)
        self.assertEqual(len({z['module'] for z in x}),37)
    def test_05_r6_gki_imports(self):
        x=r.load_imports(ROOT/'reference/R6_GKI_IMPORT_ABI.csv')
        self.assertEqual(len(x),11500)
        self.assertEqual(len({z['module'] for z in x}),181)
    def test_06_exact_r6_match_reproduction(self):
        self.assertEqual(r.abi_report(ROOT,r.parse_symvers(ROOT/'reference/R6_Module.symvers'))['QGKI']['match'],1470)
    def test_07_exact_r6_gki_reproduction(self):
        self.assertEqual(r.abi_report(ROOT,r.parse_symvers(ROOT/'reference/R6_Module.symvers'))['GKI']['match'],5485)
    def test_08_layout_separates_cohorts(self):
        d=r.abi_report(ROOT,r.parse_symvers(ROOT/'reference/R6_Module.symvers'))
        self.assertNotEqual(d['QGKI']['module_layout_expected_crc'],d['GKI']['module_layout_expected_crc'])
    def test_09_r6_no_compatible_module(self):
        x=r.abi_report(ROOT,r.parse_symvers(ROOT/'reference/R6_Module.symvers'))
        self.assertEqual((x['QGKI']['complete_modules'],x['GKI']['complete_modules']),(0,0))
    def test_10_missing_symvers_is_bad(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'m';p.write_text('')
            with self.assertRaises(ValueError):r.parse_symvers(p)
    def test_11_duplicated_export_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'m';p.write_text('0x12345678\tfoo\tvmlinux\tEXPORT_SYMBOL\n0x12345678\tfoo\tvmlinux\tEXPORT_SYMBOL\n')
            with self.assertRaises(ValueError):r.parse_symvers(p)
    def test_12_crc_case_and_malformed_refused(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'m';p.write_text('0xXYZ\tfoo\tvmlinux\tEXPORT_SYMBOL\n')
            with self.assertRaises(ValueError):r.parse_symvers(p)
    def test_13_missing_rc_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d)
            with self.assertRaisesRegex(ValueError,'RC_MISSING'):r.summarize(ROOT,t/'reports',t/'build')
    def test_14_invalid_rc_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d); (t/'reports').mkdir();(t/'reports/R18_FULL_KERNEL_RC.txt').write_text('banana')
            with self.assertRaisesRegex(ValueError,'RETURN_CODE'):r.summarize(ROOT,t/'reports',t/'build')
    def test_15_failure_no_abi_measure(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d); p=t/'reports';p.mkdir();(p/'R18_FULL_KERNEL_RC.txt').write_text('2')
            (p/'R18_FULL_KERNEL_BUILD.log').write_text('drivers/kernel/file.c:32: error: unavailable function\n')
            with contextlib.redirect_stdout(io.StringIO()):o=r.summarize(ROOT,p,t/'build');self.assertEqual(o['build_rc'],2);self.assertIsNone(o['vendor_module_abi']);self.assertFalse(o['linked_image_and_vmlinux']);self.assertFalse(o['flash_allowed'])
    def test_16_zero_rc_missing_image_no_success(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d);p=t/'reports';p.mkdir();(p/'R18_FULL_KERNEL_RC.txt').write_text('0')
            with contextlib.redirect_stdout(io.StringIO()):o=r.summarize(ROOT,p,t/'build');self.assertFalse(o['linked_image_and_vmlinux']);self.assertIsNone(o['vendor_module_abi'])
    def test_17_llvm_broken_pipe_not_a_fatal_compiler_error_when_rc_zero(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log';p.write_text('LLVM ERROR: IO failure on output stream: Broken pipe\n')
            self.assertEqual(r.first_errors(p),[])
    def test_18_build_issues_recognized(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log';p.write_text('abc:100: error: x\nld.lld: error: foo\n')
            self.assertEqual(len(r.first_errors(p)),2)
    def test_19_failed_build_never_uploads_symvers(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d);p=t/'reports';p.mkdir();(p/'R18_FULL_KERNEL_RC.txt').write_text('1')
            r.summarize(ROOT,p,t/'build');self.assertFalse((p/'R18_COMPILED_Module.symvers').exists())
    def test_20_immutable_parent_original(self):
        self.assertEqual(r.sha(ROOT/'reference/R17_MAIN_ORIGINAL.zip'),r.R17_SHA)
    def test_21_import_rewrite_detected_by_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse((ROOT/'reference/R6_QGKI_IMPORT_ABI.csv').is_symlink())
    def test_22_all_source_refs_data_only(self):
        s=(ROOT/'README_ERST_LESEN.md').read_text()
        self.assertIn('KEINE FLASHFREIGABE',s)
    def test_23_failure_log_capped(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log';p.write_text('foo:1: error: X\n'*95)
            self.assertEqual(len(r.first_errors(p)),75)
    def test_24_realistic_artifact_headers_required(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);out=root/'build';report=root/'reports';out.mkdir();report.mkdir()
            for file in (out/'vmlinux',out/'System.map',out/'Module.symvers',out/'arch/arm64/boot/Image'):
                file.parent.mkdir(exist_ok=True,parents=True);file.write_bytes(b'junk')
            (report/'R18_FULL_KERNEL_RC.txt').write_text('0')
            with contextlib.redirect_stdout(io.StringIO()):x=r.summarize(ROOT,report,out)
            self.assertFalse(x['linked_image_and_vmlinux'])
            self.assertFalse(x['arm64_image_header_valid'])
            self.assertFalse(x['vmlinux_elf_header_valid'])
    def test_25_positive_simulated_outputs_only_produce_abi_report_no_flash(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);out=root/'build';report=root/'reports';out.mkdir();report.mkdir()
            img=out/'arch/arm64/boot/Image';img.parent.mkdir(parents=True)
            head=bytearray(64);head[56:60]=b'ARM\x64';img.write_bytes(head+b'\x00'*1048576)
            (out/'vmlinux').write_bytes(b'\x7fELF'+b'\x00'*1048576)
            (out/'System.map').write_text('0000000000000000 T test\n')
            (out/'Module.symvers').write_bytes((ROOT/'reference/R6_Module.symvers').read_bytes())
            (report/'R18_FULL_KERNEL_RC.txt').write_text('0')
            with contextlib.redirect_stdout(io.StringIO()):x=r.summarize(ROOT,report,out)
            self.assertTrue(x['linked_image_and_vmlinux'])
            self.assertEqual(x['vendor_module_abi']['QGKI']['match'],1470)
            self.assertEqual(x['vendor_module_abi']['GKI']['match'],5485)
            self.assertFalse(x['flash_allowed']);self.assertFalse(x['boot_verified'])
            self.assertEqual(r.sha(report/'R18_COMPILED_Module.symvers'),r.sha(out/'Module.symvers'))
    def test_26_image_without_arm64_magic_blocks_green(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);out=p/'build';out.mkdir();(p/'reports').mkdir()
            (out/'vmlinux').write_bytes(b'\x7fELF'+b'\x00'*1048576)
            img=out/'arch/arm64/boot/Image';img.parent.mkdir(parents=True);img.write_bytes(b'bad!'+b'\x00'*1048576)
            (out/'System.map').write_text('test')
            (out/'Module.symvers').write_bytes((ROOT/'reference/R6_Module.symvers').read_bytes())
            (p/'reports/R18_FULL_KERNEL_RC.txt').write_text('0')
            with contextlib.redirect_stdout(io.StringIO()):x=r.summarize(ROOT,p/'reports',out)
            self.assertFalse(x['linked_image_and_vmlinux'])
    def test_27_all_reference_hashes_sealed(self):
        m=r.attest(ROOT)
        self.assertEqual(len(m['files']),7)
        self.assertTrue(all(len(x)==64 for x in m['files'].values()))
    def test_28_status_no_false_full_walt_claim(self):
        import inspect
        s=inspect.getsource(r.summarize)
        for name in ('boot_verified','runtime_walt_hooks_verified','stock_rtmm_implemented','oem_abi_verified'):
            self.assertIn(name,s)
        self.assertIn("'flash_allowed':False",s)

if __name__=='__main__':unittest.main()
