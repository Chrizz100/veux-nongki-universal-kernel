#!/usr/bin/env python3
"""R18 diagnostic: pinned input verification and full Image/DTB-build ABI measurement.

No signing, flashing, CRC rewriting or production-source mutation.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, json, re, sys
from pathlib import Path

R17_SHA = '511dc8744b4f6b06f837bba9a92e32cf2510eb383224d27bd342b44a4991e4a6'
HEADER = ['module','symbol','expected_crc','candidate_crc','result']
EXPECTED = {'QGKI':(3148,37,1470,1664,14), 'GKI':(11500,181,5485,5989,26)}
SYM = re.compile(r'^[a-zA-Z_][\w.$]*$')
CRC = re.compile(r'^0x[0-9a-f]{8}$')
ERR = re.compile(r'(?i)(?:\berror:|fatal error:|undefined reference to|ld\.lld: error:|make\[\d+\]: \*\*\*|make: \*\*\*)')

def sha(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def attest(root: Path):
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (m.get('schema')!='VEUX_R18_WALT_FULL_IMAGE_LINK_ABI_DIAGNOSTIC_NOFLASH'
        or m.get('flash_allowed') is not False or m.get('production_patch_approved') is not False
        or m.get('boot_verified') is not False or m.get('expected_full_kernel_link_pass') is not False
        or m.get('source_commit_donor')!='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
        or m.get('source_commit_pair')!='01cb3a8824b7b4caf3e3540274e71abba5ade538'):
        raise ValueError('UNSAFE_R18_MANIFEST')
    present={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'MANIFEST_SHA256.json'}
    if present!=set(m['files']): raise ValueError('UNEXPECTED_R18_FILESET')
    for name,h in m['files'].items():
        p=root/name
        if (p.is_symlink() or not p.is_file() or not re.fullmatch('[a-f0-9]{64}',h) or sha(p)!=h):
            raise ValueError('BAD_R18_INPUT_SHA:'+name)
    if sha(root/'reference/R17_MAIN_ORIGINAL.zip')!=R17_SHA:
        raise ValueError('R17_PARENT_ORIGINAL_CHANGED')
    if m.get('r17_parent_sha256')!=R17_SHA:
        raise ValueError('R17_PARENT_SHA_IN_MANIFEST_CHANGED')
    # The imports have to match the captured R6 symvers exactly.
    r6=parse_symvers(root/'reference/R6_Module.symvers')
    if len(r6)!=14255: raise ValueError('R6_EXPORT_COUNT_CHANGED')
    for cohort,(count,mods,matched,mismatch,missing) in EXPECTED.items():
        rows=load_imports(root/'reference'/f'R6_{cohort}_IMPORT_ABI.csv')
        if len(rows)!=count or len({x['module'] for x in rows})!=mods:
            raise ValueError('R6_IMPORT_COUNT_CHANGED:'+cohort)
        states=collections.Counter()
        for r in rows:
            actual=r6.get(r['symbol'])
            state='NOT_EXPORTED' if actual is None else ('MATCH' if actual==r['expected_crc'] else 'CRC_MISMATCH')
            if r['result']!=state or r['candidate_crc']!=(actual or ''):
                raise ValueError('R6_IMPORT_BASELINE_TAMPER:'+cohort)
            states[state]+=1
        if tuple(states[s] for s in ('MATCH','CRC_MISMATCH','NOT_EXPORTED'))!=(matched,mismatch,missing):
            raise ValueError('R6_STATUS_SUMMARY_CHANGED:'+cohort)
    return m

def parse_symvers(path:Path):
    result={}
    for n,line in enumerate(path.read_text().splitlines(),1):
        parts=line.split('\t')
        if len(parts)<4 or not CRC.fullmatch(parts[0]) or not SYM.fullmatch(parts[1]) or parts[1] in result:
            raise ValueError(f'INVALID_MODULE_SYMVERS_LINE:{n}')
        result[parts[1]]=parts[0]
    if not result:raise ValueError('EMPTY_MODULE_SYMVERS')
    return result

def load_imports(path:Path):
    with path.open(newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames != HEADER:raise ValueError('BAD_IMPORT_CSV_HEADER')
        rows=list(reader)
    for r in rows:
        if (not r['module'].startswith('/vendor/lib/modules/') or not r['module'].endswith('.ko')
            or not SYM.fullmatch(r['symbol']) or not CRC.fullmatch(r['expected_crc'])
            or r['result'] not in {'MATCH','NOT_EXPORTED','CRC_MISMATCH'}):
            raise ValueError('INVALID_IMPORT_ROW')
    return rows

def abi_report(root:Path,candidate:dict):
    old=parse_symvers(root/'reference/R6_Module.symvers')
    out={'candidate_exports':len(candidate),'r6_exports':len(old),'changed_common_crc':sum(old[s]!=candidate[s] for s in old.keys()&candidate.keys())}
    for cohort in EXPECTED:
        rows=load_imports(root/'reference'/f'R6_{cohort}_IMPORT_ABI.csv')
        ct=collections.Counter(); m=collections.defaultdict(list)
        for r in rows:
            actual=candidate.get(r['symbol'])
            st='NOT_EXPORTED' if actual is None else ('MATCH' if r['expected_crc']==actual else 'CRC_MISMATCH')
            ct[st]+=1
            m[r['module']].append(st)
        layout=candidate.get('module_layout')
        out[cohort]={
            'imports':len(rows),'modules':len(m),
            'match':ct['MATCH'],'crc_mismatch':ct['CRC_MISMATCH'],'not_exported':ct['NOT_EXPORTED'],
            'complete_modules':sum(all(s=='MATCH' for s in arr) for arr in m.values()),
            'module_layout_candidate':layout,
            'module_layout_expected_crc':('0x945d02f2' if cohort=='QGKI' else '0x1e5b7ab7'),
            'r6_match':EXPECTED[cohort][2],
            'delta_match_vs_r6':ct['MATCH']-EXPECTED[cohort][2]
        }
    return out

def first_errors(log:Path,cap=75):
    if not log.is_file():return []
    result=[]
    for line in log.read_text(errors='replace').splitlines():
        if ERR.search(line) and not ('LLVM ERROR: IO failure on output stream: Broken pipe' in line):
            result.append(line[:1000])
            if len(result)>=cap:break
    return result

def summarize(root:Path,report_dir:Path,build_dir:Path):
    attest(root)
    report_dir.mkdir(parents=True,exist_ok=True)
    rc_path=report_dir/'R18_FULL_KERNEL_RC.txt'
    if not rc_path.is_file():raise ValueError('R18_RC_MISSING_NOT_GREEN')
    try:rc=int(rc_path.read_text().strip())
    except ValueError:raise ValueError('R18_INVALID_RETURN_CODE')
    img=build_dir/'arch/arm64/boot/Image'
    vmlinux=build_dir/'vmlinux'
    symvers=build_dir/'Module.symvers'
    sysmap=build_dir/'System.map'
    # A completed make alone is not evidence of a bootable ARM64 image.
    # Require ARM64 Image magic at offset 0x38 and a real ELF vmlinux header.
    image_valid=False
    if img.is_file() and img.stat().st_size>1048576:
        with img.open('rb') as f:image_valid=f.read(64)[56:60]==b'ARM\x64'
    vmlinux_valid=False
    if vmlinux.is_file() and vmlinux.stat().st_size>1048576:
        with vmlinux.open('rb') as f:vmlinux_valid=f.read(4)==b'\x7fELF'
    success=(rc==0 and image_valid and vmlinux_valid and symvers.is_file() and
             symvers.stat().st_size>100000 and sysmap.is_file() and sysmap.stat().st_size>0)
    errors=first_errors(report_dir/'R18_FULL_KERNEL_BUILD.log')
    result={
        'schema':'VEUX_R18_WALT_FULL_IMAGE_LINK_ABI_DIAGNOSTIC_NOFLASH',
        'build_rc':rc, 'linked_image_and_vmlinux':success,
        'compiler_errors_first':errors,
        'image_present':img.is_file() and img.stat().st_size>0,
        'arm64_image_header_valid':bool(image_valid),
        'vmlinux_present':vmlinux.is_file() and vmlinux.stat().st_size>0,
        'vmlinux_elf_header_valid':bool(vmlinux_valid),
        'module_symvers_present':symvers.is_file() and symvers.stat().st_size>0,
        'system_map_present':sysmap.is_file() and sysmap.stat().st_size>0,
        'flash_allowed':False,'boot_verified':False,'source_patch_approved':False,
        'stock_rtmm_implemented':False, 'runtime_walt_hooks_verified':False,
        'stock_source_reproduction_verified':False,'oem_abi_verified':False,
        'vendor_module_abi':None,'note':'A compiler/link/CRC diagnostic only. Does not prove OEM runtime or boot.'
    }
    if success:
        result['image_bytes']=img.stat().st_size
        result['image_sha256']=sha(img)
        result['vmlinux_sha256']=sha(vmlinux)
        result['module_symvers_sha256']=sha(symvers)
        result['vendor_module_abi']=abi_report(root,parse_symvers(symvers))
        # Allowed to archive text metadata; binaries must never be uploaded.
        (report_dir/'R18_COMPILED_Module.symvers').write_bytes(symvers.read_bytes())
        (report_dir/'R18_BUILD_SHA256.txt').write_text(f"{result['image_sha256']}  Image (NOT UPLOADED)\n{result['vmlinux_sha256']}  vmlinux (NOT UPLOADED)\n{result['module_symvers_sha256']}  Module.symvers\n")
    (report_dir/'R18_FULL_LINK_AND_ABI.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    msg=(f"R18_FULL_IMAGE_LINK={'PASS' if success else 'FAILED'}; MAKE_RC={rc}; "
        f"OEM_ABI={'MEASURED_NOT_APPROVED' if success else 'NOT_MEASURED'}; NOFLASH=YES")
    (report_dir/'R18_STATUS_DE.txt').write_text(msg+'\n'+'\n'.join(errors)+'\n')
    print(msg)
    return result

def main():
    parser=argparse.ArgumentParser();sub=parser.add_subparsers(dest='cmd',required=True)
    a=sub.add_parser('verify');a.add_argument('--root',type=Path,required=True)
    a=sub.add_parser('summary');a.add_argument('--root',type=Path,required=True);a.add_argument('--reports',type=Path,required=True);a.add_argument('--build-dir',type=Path,required=True)
    ns=parser.parse_args()
    if ns.cmd=='verify':print(json.dumps({'R18_INPUTS':'VERIFIED','R17_SHA256':attest(ns.root)['r17_parent_sha256'],'NOFLASH':True}))
    else:summarize(ns.root,ns.reports,ns.build_dir)
if __name__=='__main__':main()
