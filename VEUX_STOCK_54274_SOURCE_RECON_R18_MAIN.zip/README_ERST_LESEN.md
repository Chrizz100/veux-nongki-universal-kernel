# VEUX Stock 5.4.274 R18 – Full Image+dtbs / OEM ABI-Diagnose – NOFLASH

R17 hat am 05.11.2026 alle 12 eindeutigen Objektdateien mit echter Android-Clang-11.0.2-Kompilierung bestanden (GitHub-Lauf 42106940565). R18 baut **nur in einem getrennten temporären Git-Worktree** erstmals den vollständigen Kernel (`Image dtbs`). Die Stock-Taskstruktur und der original gepinnte R17-Paketstand bleiben unverändert.

**KEINE FLASHFREIGABE**. Selbst ein erfolgreicher Gesamtbuild beweist weder die reale WALT-Scheduler-Integration noch OEM-ABI oder Bootfähigkeit; insbesondere ist CONFIG_RTMM noch nicht vollständig portiert. Niemals Stock-CRCs fälschen, `Module.symvers` manipulieren, Module mit --force laden oder ein AK3-/boot.img-Flashpaket aus diesem Experiment erzeugen.

Falls der Build scheitert: GitHub-Job wird ROT, der Fehler samt Return-Code wird in einem textbasierten Diagnose-Artefakt gespeichert. Falls `Image`, `vmlinux`, `System.map`, `Module.symvers` real erzeugt werden: dieselben 3.148 QGKI- sowie 11.500 GKI-Importe werden gegen die originale R6-Referenz gemessen und im JSON-Bericht ausgewiesen. Es gibt weiterhin **keine Flashfreigabe**, auch bei einem erfolgreichen Compiler- und ABI-Bericht. Image/vmlinux werden nicht hochgeladen.

## Versionen und Quellen

- Eigenes Repository: `Chrizz100/veux-nongki-universal-kernel`, Stand R17 `ab31bb16b07d4e2ce9b3d842b124037ee262bd9d`.
- Gepinnter 5.4.268-Spender: `dereference23/kernel_xiaomi_sm6375` Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`.
- Gepinnte 5.4.61-Qualcomm-WALT-Quelldateien: `shandongtlb/kernel_xiaomi_sm8350_M11` Commit `01cb3a8824b7b4caf3e3540274e71abba5ade538`.
- Android-Clang 11.0.2, PREBUILT Tree `1c7dcc2e7095197f7a05dff22a875b6b02ed7117`.
- R6-Symvers und R6-Vendor-Importlisten stammen aus den originalen R6/R9-Referenzdaten (nur Vergleich, niemals manipulieren).

## Upload

- `VEUX_STOCK_54274_SOURCE_RECON_R18_MAIN.zip` → Repo-Hauptverzeichnis
- `VEUX_STOCK_54274_SOURCE_RECON_R18_NOFLASH.yml` → `.github/workflows/`

Frühere MAIN-ZIPs werden beim Workflow-Lauf aus dem verifizierten verschachtelten R17-MAIN bereitgestellt.
