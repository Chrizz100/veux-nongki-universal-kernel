#!/usr/bin/env python3
"""Fail-closed restoration of two upstream declarations in disposable VEUX 5.4.274 tree.

Run AFTER R19 object/provider proof; BEFORE R20 full-kernel make. No changes to
pinned archives, original project checkout, canonical Positron source or BReNE.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

VMSCAN = 'mm/vmscan.c'
SCHED_DEBUG = 'kernel/sched/debug.c'
PATCH_SCOPE = (VMSCAN, SCHED_DEBUG)
LOCK_CONTEXT = 'static DEFINE_RWLOCK(shrinker_rwlock);\n\n#ifdef CONFIG_MEMCG\n'
LOCK_REPLACEMENT = LOCK_CONTEXT + 'static DECLARE_RWSEM(shrinker_rwsem);\n'
PM_PATTERN = re.compile(r'^#define\s+PM\(F,\s*M\)\s+__PS\(#F,\s*p->F\s*&\s*\(M\)\)\s*$', re.M)
P_PATTERN = re.compile(r'^#define\s+__P\(F\)\b.*$', re.M)
# Not a local reinterpretation of PM: this is the Linux upstream __PS macro.
PS_DEFINITION = '#define __PS(S, F) SEQ_printf(m, "%-45s:%21Ld\\n", S, (long long)(F))\n'

class GateFailure(RuntimeError):
    pass

def demand(predicate, message):
    if not predicate:
        raise GateFailure(message)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def restore_vmscan(data):
    demand(data.count(LOCK_CONTEXT.encode()) == 1, 'VMSCAN_PREIMAGE_CONTEXT_DRIFT')
    demand(data.count(b'shrinker_rwsem') == 7, 'VMSCAN_LOCK_REFERENCES_CHANGED')
    demand(not re.search(rb'(?m)^\s*(?:static\s+)?(?:DECLARE_RWSEM\(shrinker_rwsem\)|DEFINE_RWSEM\(shrinker_rwsem\)|struct\s+rw_semaphore\s+shrinker_rwsem\b)', data), 'VMSCAN_LOCK_ALREADY_DECLARED')
    output=data.replace(LOCK_CONTEXT.encode(),LOCK_REPLACEMENT.encode(),1)
    demand(output.count(b'static DECLARE_RWSEM(shrinker_rwsem);') == 1, 'VMSCAN_LOCK_RESTORE_FAILED')
    return output

def restore_sched_debug(data):
    demand(not re.search(rb'(?m)^\s*#\s*define\s+__PS\s*\(', data), 'SCHED_DEBUG_PS_ALREADY_DEFINED')
    source=data.decode('utf-8')
    demand(len(PM_PATTERN.findall(source)) == 1, 'SCHED_DEBUG_PM_CONTRACT_DRIFT')
    # Look for the stable macro prefix rather than fragile indentation/tabbing.
    lines=source.splitlines(keepends=True)
    p=[i for i,l in enumerate(lines) if re.match(r'^#define\s+__P\(F\)\s+SEQ_printf\(m,',l)]
    demand(len(p)==1,'SCHED_DEBUG_P_CONTRACT_DRIFT')
    demand(p[0]+2 < len(lines) and re.match(r'^#define\s+P\(F\)\s+SEQ_printf\(m,',lines[p[0]+1])
           and PM_PATTERN.fullmatch(lines[p[0]+2].rstrip('\n')) is not None,
           'SCHED_DEBUG_MACRO_ORDER_DRIFT')
    lines.insert(p[0],PS_DEFINITION)
    output=''.join(lines).encode('utf-8')
    demand(output.count(PS_DEFINITION.encode())==1,'SCHED_DEBUG_PS_RESTORE_FAILED')
    return output

def changed_lines(before,after,label):
    diff=list(difflib.unified_diff(before.decode().splitlines(),after.decode().splitlines(),fromfile=label+':before',tofile=label+':after',lineterm=''))
    plus=[l for l in diff if l.startswith('+') and not l.startswith('+++')]
    minus=[l for l in diff if l.startswith('-') and not l.startswith('---')]
    demand(len(plus)==1 and not minus,'NON_ADDITIVE_PATCH:'+label)
    return '\n'.join(diff)+'\n'

def restore_tree(snapshot,canonical,project,report_dir):
    snapshot=Path(snapshot);canonical=Path(canonical);project=Path(project);report_dir=Path(report_dir)
    for label,d in (('SNAPSHOT',snapshot),('CANONICAL',canonical),('PROJECT',project)):
        demand(d.is_dir() and not d.is_symlink(),'INVALID_'+label)
    s=snapshot.resolve();c=canonical.resolve();p=project.resolve();r=report_dir.resolve()
    demand(s!=c and not s.is_relative_to(c) and not c.is_relative_to(s),'CANONICAL_SOURCE_IS_NOT_DISPOSABLE')
    demand(not s.is_relative_to(p) and not r.is_relative_to(p),'PROJECT_WRITE_SCOPE_DENIED')
    demand(not r.is_relative_to(s) and not r.is_relative_to(c),'AUDIT_REPORT_MUST_BE_SEPARATE')
    demand(not report_dir.exists() and not report_dir.is_symlink(),'REPORT_ALREADY_EXISTS')
    before={};after={};diffs={};canonical_before={}
    transforms={VMSCAN:restore_vmscan,SCHED_DEBUG:restore_sched_debug}
    # Complete preflight and generate BOTH diffs before mutating either file.
    for rel in PATCH_SCOPE:
        path=snapshot/rel
        demand(path.is_file() and not path.is_symlink(),'MISSING_OR_SYMLINK_SOURCE:'+rel)
        demand(path.resolve().is_relative_to(s),'SNAPSHOT_SOURCE_ESCAPES_TREE:'+rel)
        v=path.read_bytes()
        demand(b'\r\n' not in v and len(v)>70, 'NONCANONICAL_SOURCE:'+rel)
        before[rel]=v
        after[rel]=transforms[rel](v)
        diffs[rel]=changed_lines(v,after[rel],rel)
        can=canonical/rel
        if can.is_file():
            demand(not can.is_symlink() and can.resolve().is_relative_to(c),'CANONICAL_SOURCE_SYMLINK:'+rel)
            canonical_before[rel]=sha256(can.read_bytes())
    # No extraneous changes: the diff consists of one upstream declaration per file.
    written=[]
    try:
        for rel in PATCH_SCOPE:
            path=snapshot/rel
            demand(path.read_bytes()==before[rel],'SNAPSHOT_RACE_BEFORE_WRITE:'+rel)
            path.write_bytes(after[rel]);written.append(rel)
        for rel in PATCH_SCOPE:
            demand((snapshot/rel).read_bytes()==after[rel],'SNAPSHOT_RACE_AFTER_WRITE:'+rel)
        for rel,dig in canonical_before.items():
            demand(sha256((canonical/rel).read_bytes())==dig,'CANONICAL_SOURCE_CHANGED:'+rel)
        report_dir.mkdir(parents=True,exist_ok=False)
        proof={'stage':'VEUX_R20_R3_PRELINK_COMPAT','kernel':'5.4.274',
               'modified_files':list(PATCH_SCOPE),'image_created':False,'vmlinux_linked':False,
               'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
               'bakasusu_nomount_changed':False,'canonical_unmodified':True,
               'project_unmodified':True,'files':{rel:{'sha256_before':sha256(before[rel]),
                                                     'sha256_after':sha256(after[rel]),
                                                     'bytes_before':len(before[rel]),
                                                     'bytes_after':len(after[rel])}
                                                for rel in PATCH_SCOPE}}
        (report_dir/'R20_R3_SOURCE_PATCH.json').write_text(json.dumps(proof,sort_keys=True,indent=2)+'\n')
        (report_dir/'R20_R3_EXACT_SOURCE_DIFF.patch').write_text(''.join(diffs[rel] for rel in PATCH_SCOPE))
        print('R20_R3_PRELINK_SOURCE=PASS; PATCHED_FILES=2; ADDED_LINES=2; CANONICAL_UNCHANGED=YES; NO_FLASH')
        return proof
    except Exception:
        # Roll back only files that still have the exact bytes written by this tool.
        for rel in reversed(written):
            path=snapshot/rel
            if path.is_file() and path.read_bytes()==after[rel]:
                path.write_bytes(before[rel])
        raise

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('--snapshot',required=True)
    parser.add_argument('--canonical',required=True)
    parser.add_argument('--project',required=True)
    parser.add_argument('--report',required=True)
    a=parser.parse_args(argv)
    try:
        restore_tree(a.snapshot,a.canonical,a.project,a.report)
    except (GateFailure,OSError,UnicodeError) as e:
        print('R20_R3_SOURCE_PATCH_BLOCKED:'+str(e),file=sys.stderr)
        return 2
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
