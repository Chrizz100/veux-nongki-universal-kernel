import importlib.util
from pathlib import Path
import tempfile
import unittest
import json
import hashlib

SCRIPT=Path(__file__).resolve().parents[1]/'r20_r3_prebuild.py'
spec=importlib.util.spec_from_file_location('r20_r3_patch',SCRIPT)
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)

V='''#include <linux/kernel.h>\nstatic LIST_HEAD(shrinker_list);\nstatic DEFINE_SPINLOCK(shrinker_lock);\nstatic DEFINE_RWLOCK(shrinker_rwlock);\n\n#ifdef CONFIG_MEMCG\n/* comment */\nstatic DEFINE_IDR(shrinker_idr);\nvoid fn(void) {\n down_write(&shrinker_rwsem);\n up_write(&shrinker_rwsem);\n down_write(&shrinker_rwsem);\n up_write(&shrinker_rwsem);\n down_read_trylock(&shrinker_rwsem);\n rwsem_is_contended(&shrinker_rwsem);\n up_read(&shrinker_rwsem);\n}\n#endif\n'''.encode()
D='''#include <linux/kernel.h>\n#define __P(F) SEQ_printf(m, "%-45s:%21Ld\\n",    #F, (long long)F)\n#define P(F) SEQ_printf(m, "%-45s:%21Ld\\n",    #F, (long long)p->F)\n#define PM(F, M) __PS(#F, p->F & (M))\nvoid fn(void) { PM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED); }\n'''.encode()

class RestoreSourceTests(unittest.TestCase):
    def test_vmscan_exact_one_line(self):
        fixed=p.restore_vmscan(V)
        self.assertEqual(fixed.count(b'static DECLARE_RWSEM(shrinker_rwsem);'),1)
        self.assertEqual(fixed.count(b'shrinker_rwsem'),8)
        self.assertIn(b'static DEFINE_RWLOCK(shrinker_rwlock);',fixed)
    def test_vmscan_diff_additive(self):
        self.assertEqual(p.changed_lines(V,p.restore_vmscan(V),'mm/vmscan.c').count('\n+static DECLARE_RWSEM(shrinker_rwsem);'),1)
    def test_vmscan_existing_definition_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_vmscan(p.restore_vmscan(V))
    def test_vmscan_context_missing_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_vmscan(V.replace(b'DEFINE_RWLOCK',b'DEFINE_SPINLOCK'))
    def test_vmscan_refcount_drift_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_vmscan(V.replace(b' up_read(&shrinker_rwsem);\n',b''))
    def test_debug_exact_one_line(self):
        x=p.restore_sched_debug(D);self.assertIn(p.PS_DEFINITION.encode(),x);self.assertIn(b'#define PM(F, M) __PS',x)
    def test_debug_diff_additive(self):
        x=p.restore_sched_debug(D);self.assertEqual(p.changed_lines(D,x,'debug.c').count('\n+#define __PS(S, F)'),1)
    def test_debug_existing_definition_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_sched_debug(p.restore_sched_debug(D))
    def test_debug_missing_pm_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_sched_debug(D.replace(b'#define PM(F, M) __PS',b'#define PM(F, M) OTHER'))
    def test_debug_order_drift_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_sched_debug(D.replace(b'#define PM(F, M)',b'\n#define PM(F, M)'))
    def test_debug_incorrect_ps_rejected(self):
        with self.assertRaises(p.GateFailure):p.restore_sched_debug(D.replace(b'#define __P(F)',b'#define SOME(F)'))

class TreeTests(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.root=Path(self.t.name)
        self.s=self.root/'snapshot';self.c=self.root/'canonical';self.project=self.root/'project';self.out=self.root/'reports'
        for base in (self.s,self.c,self.project):
            (base/'mm').mkdir(parents=True);(base/'kernel/sched').mkdir(parents=True)
        for base in (self.s,self.c):
            (base/'mm/vmscan.c').write_bytes(V);(base/'kernel/sched/debug.c').write_bytes(D)
    def tearDown(self):self.t.cleanup()
    def test_success_and_sha_report(self):
        before={n:(self.c/n).read_bytes() for n in p.PATCH_SCOPE}
        j=p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertEqual(j['modified_files'],list(p.PATCH_SCOPE))
        self.assertTrue((self.out/'R20_R3_EXACT_SOURCE_DIFF.patch').is_file())
        self.assertEqual((self.out/'R20_R3_EXACT_SOURCE_DIFF.patch').read_text().count('\n+static DECLARE_RWSEM'),1)
        self.assertEqual((self.out/'R20_R3_EXACT_SOURCE_DIFF.patch').read_text().count('\n+#define __PS'),1)
        for n in p.PATCH_SCOPE:
            self.assertEqual((self.c/n).read_bytes(),before[n]);self.assertNotEqual((self.s/n).read_bytes(),before[n])
            self.assertEqual(j['files'][n]['sha256_before'],hashlib.sha256(before[n]).hexdigest())
    def test_reapply_rejected(self):
        p.restore_tree(self.s,self.c,self.project,self.out)
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.root/'reports2')
    def test_symlink_rejected(self):
        n=self.s/'mm/vmscan.c';n.unlink();n.symlink_to(self.c/'mm/vmscan.c')
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertFalse(self.out.exists())
    def test_intermediate_dir_symlink_to_canonical_rejected(self):
        (self.s/'mm/vmscan.c').unlink(); (self.s/'mm').rmdir()
        (self.s/'mm').symlink_to(self.c/'mm',target_is_directory=True)
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertFalse(self.out.exists())
    def test_partial_preflight_no_changes(self):
        before=(self.s/'mm/vmscan.c').read_bytes();(self.s/'kernel/sched/debug.c').write_bytes(b'broken source')
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertEqual((self.s/'mm/vmscan.c').read_bytes(),before)
    def test_canonical_not_disposable(self):
        with self.assertRaises(p.GateFailure):p.restore_tree(self.c,self.c,self.project,self.out)
    def test_project_scope_not_writable(self):
        with self.assertRaises(p.GateFailure):p.restore_tree(self.project,self.c,self.project,self.out)
    def test_preexisting_report_rejected(self):
        self.out.mkdir();withfile=self.out/'existing';withfile.write_text('keep')
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertEqual(withfile.read_text(),'keep')
    def test_source_no_crlf(self):
        (self.s/'mm/vmscan.c').write_bytes(V.replace(b'\n',b'\r\n'))
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.out)
    def test_script_argument_failure_exit(self):
        self.assertEqual(p.main(['--snapshot',str(self.c),'--canonical',str(self.c), '--project',str(self.project),'--report',str(self.out)]),2)
    def test_outside_project_report(self):
        with self.assertRaises(p.GateFailure):p.restore_tree(self.s,self.c,self.project,self.project/'evidence')
    def test_scope_has_only_two_files(self):
        self.assertEqual(set(p.PATCH_SCOPE),{'mm/vmscan.c','kernel/sched/debug.c'})
    def test_runtime_claims_false(self):
        j=p.restore_tree(self.s,self.c,self.project,self.out)
        self.assertFalse(any(j[k] for k in ('flash_allowed','vmlinux_linked','image_created','vendor_abi_proven','brene_changed','bakasusu_nomount_changed')))

if __name__=='__main__':unittest.main()
