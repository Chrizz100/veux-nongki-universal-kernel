#!/usr/bin/env python3
"""R19: independently verify 12 global code providers (T) and one data provider (D).

Only reads an already compiled R18 snapshot and runs llvm-nm on its real object
files. Makes NO kernel/source changes and grants NO link, ABI or flash approval.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

REQUIRED = {
    'kernel/cpu.o': {'__cpu_isolated_mask': 'D'},
    'kernel/sched/core.o': {'calc_load_migrate': 'T', 'migrate_swap': 'T', 'migrate_tasks': 'T'},
    'kernel/sched/fair.o': {'active_load_balance_cpu_stop': 'T', 'find_energy_efficient_cpu': 'T'},
    'kernel/sched/topology.o': {'init_sched_groups_capacity': 'T'},
    'kernel/sysctl.o': {'proc_douintvec_capacity': 'T'},
    'kernel/time/hrtimer.o': {'hrtimer_quiesce_cpu': 'T'},
    'kernel/time/timer.o': {'timer_quiesce_cpu': 'T'},
    'kernel/watchdog.o': {'watchdog_configured': 'T', 'watchdog_disable': 'T',
                          'watchdog_enable': 'T'},
}
POSTIMAGES = {
    'kernel/sched/core.c', 'kernel/sched/sched.h', 'kernel/watchdog.c',
    'include/linux/nmi.h', 'kernel/time/hrtimer.c', 'include/linux/hrtimer.h',
    'kernel/time/timer.c', 'include/linux/timer.h',
}
DIAGNOSTIC = 'R19_TYPED_PROVIDER_DIAGNOSTICS_RECORDED'
PROVEN = 'R19_15_OBJECTS_AND_13_TYPED_PROVIDERS_PROVEN_NO_LINK'
NM_RE = re.compile(r'\s*(?:(?:[a-fA-F0-9]+|-+)\s+)?([A-Za-z])\s+([_A-Za-z][\w.$@]*)\s*')
SHA_RE = re.compile(r'^[a-f0-9]{64}$')

class GateError(RuntimeError):
    pass

def require(ok: bool, description: str) -> None:
    if not ok:
        raise GateError(description)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def checked_file(path: Path, max_bytes: int = 4_000_000) -> bytes:
    require(path.is_file() and not path.is_symlink(), 'R19_MISSING_OR_SYMLINK:'+str(path))
    require(0 < path.stat().st_size <= max_bytes, 'R19_UNSAFE_FILE_SIZE:'+str(path))
    return path.read_bytes()

def parse_nm(s: str) -> list[tuple[str,str]]:
    out = []
    for line in s.splitlines():
        m = NM_RE.fullmatch(line)
        if m:
            out.append((m.group(1), m.group(2)))
    return out

def symbol_found(nm_text: str, symbol: str, kind: str) -> bool:
    require(kind in ('T','D','U'), 'R19_INVALID_SYMBOL_CLASS')
    # Require exact symbol spelling and global symbol type. Lowercase/local,
    # undefined, weak, and unrelated '__ksymtab_' names do not qualify.
    return any(cls == kind and name == symbol for cls, name in parse_nm(nm_text))

def check_report(j: dict) -> None:
    require(j.get('kernel_version') == '5.4.274', 'R19_KERNEL_VERSION_DRIFT')
    require(j.get('source_r18_verified') is True and
            j.get('real_arm64_make_attempted') is True, 'R19_NO_REAL_COMPILER')
    objs = j.get('objects',{})
    require(isinstance(objs,dict) and len(objs)==15 and
            len(j.get('targets',[]))==15 and
            set(objs)==set(j['targets']), 'R19_OBJECT_SCOPE_DRIFT')
    require(j.get('object_success_count') == 15 and
            j.get('prior_eleven_preserved') == 11 and
            j.get('qc_vas_compiled') is True and
            j.get('three_support_objects_compiled') == 3,
            'R19_COMPILATION_NOT_PROVEN')
    for name,o in objs.items():
        require(o.get('compiled') is True and o.get('object_present') is True
                and o.get('exit_code') == 0 and o.get('timed_out') is False
                and o.get('object_bytes',0) > 0
                and bool(SHA_RE.fullmatch(o.get('object_sha256',''))),
                'R19_INCOMPLETE_OBJECT:'+name)
    require(set(j.get('r18_postimages',{})) == POSTIMAGES and
            all(SHA_RE.fullmatch(v) for v in j['r18_postimages'].values()),
            'R19_SOURCE_SCOPE_INVALID')
    require(j.get('status') == 'R18_REAL_OBJECT_OR_PROVIDER_DIAGNOSTICS_RECORDED',
            'R19_R18_STATUS_CHANGED')
    flags=('flash_allowed','vendor_abi_proven','kernel_image_built','vmlinux_linked',
           'brene_changed','bakasusu_nomount_changed','runtime_tested')
    require(all(j.get(k) is False for k in flags), 'R19_UNSAFE_PRIOR_SUCCESS_CLAIM')
    ev=j.get('symbol_evidence',{})
    require(ev.get('tool_invoked') is True and ev.get('count_verified') == 12 and
            ev.get('all_verified') is False and
            set(ev.get('providers',{})) == set(REQUIRED) and
            ev.get('qc_vas_undefined_rc')==0 and
            '__cpu_isolated_mask' in ev.get('qc_vas_undefined',[]),
            'R19_PRIOR_PROVENANCE_MISMATCH')
    wrong=[]
    for target,names in REQUIRED.items():
        old=ev['providers'][target]
        require(old.get('compiled') is True and old.get('nm_rc')==0 and
                set(old.get('symbols',{}))==set(names),
                'R19_PREVIOUS_NM_SCOPE:'+target)
        for sym,kind in names.items():
            got=old['symbols'][sym]
            require(got is (kind=='T'), 'R19_UNEXPECTED_R18_RESULT:'+sym)
            if not got:
                wrong.append(sym)
    require(wrong==['__cpu_isolated_mask'], 'R19_NOT_EXACTLY_ONE_DATA_MISMATCH')

def review_nm(provider_outputs: dict[str,str], undefined: str):
    require(set(provider_outputs)==set(REQUIRED), 'R19_NM_TARGET_SCOPE')
    states={}
    for target,symbols in REQUIRED.items():
        actual=provider_outputs[target]
        states[target]={sym: {'expected_type':klass,
                              'confirmed':symbol_found(actual,sym,klass)}
                        for sym,klass in symbols.items()}
    count=sum(info['confirmed'] for record in states.values() for info in record.values())
    source_ref=symbol_found(undefined,'__cpu_isolated_mask','U')
    return states,count,source_ref

def check_runtime_objects(root:Path, j:dict) -> None:
    require(root.is_dir() and not root.is_symlink(), 'R19_INVALID_OBJECT_DIR')
    for name,item in j['objects'].items():
        file=root / name
        require(file.is_file() and not file.is_symlink() and
                file.stat().st_size == item['object_bytes'] and
                sha(file.read_bytes())==item['object_sha256'],
                'R19_OBJECT_HASH_MISMATCH:'+name)

def check_runtime_sources(root:Path,j:dict)->None:
    require(root.is_dir() and not root.is_symlink(),'R19_INVALID_SOURCE_DIR')
    for name,digest in j['r18_postimages'].items():
        file=root / name
        require(file.is_file() and not file.is_symlink() and
                sha(file.read_bytes())==digest,'R19_SOURCE_HASH_MISMATCH:'+name)

def invoke_nm(toolchain:Path, object_root:Path, target:str, defined:bool):
    tool=toolchain/'bin/llvm-nm'
    require(tool.is_file(), 'R19_MISSING_LLVM_NM')
    p=subprocess.run([str(tool),'--defined-only' if defined else '--undefined-only',
                      str(object_root / target)], capture_output=True,
                     text=True, timeout=35)
    require(p.returncode==0 and not p.stderr.strip(),
            'R19_LLVM_NM_FAILED:'+target+':'+p.stderr[:300])
    return p.stdout

def run(report:Path, snapshot:Path, objout:Path, toolchain:Path, output:Path):
    require(not output.exists() and not output.is_symlink(), 'R19_OUTPUT_ALREADY_EXISTS')
    j=json.loads(checked_file(report,150000))
    check_report(j)
    check_runtime_objects(objout,j)
    check_runtime_sources(snapshot,j)
    observed={}
    for target in REQUIRED:
        observed[target]=invoke_nm(toolchain,objout,target,True)
    undef=invoke_nm(toolchain,objout,'kernel/sched/walt/qc_vas.o',False)
    states,count,source_ref=review_nm(observed,undef)
    out={
       'status': PROVEN if count==13 and source_ref else DIAGNOSTIC,
       'kernel_version':'5.4.274',
       'r18_source_verified': True,
       'r18_real_arm64_compiled': 15,
       'r18_objects_sha_verified': 15,
       'r18_eight_source_postimages_verified': 8,
       'type_aware_symbol_count':count,
       'type_aware_symbol_expected':13,
       'all_verified':bool(count==13 and source_ref),
       'qc_vas_undefined_cpu_mask_reference_proven':source_ref,
       'provider_objects':states,
       'llvm_nm_invocations':len(observed)+1,
       'r19_changed_kernel_source':False,
       'kernel_image_built':False,'vmlinux_linked':False,
       'vendor_abi_proven':False,'flash_allowed':False,'runtime_tested':False,
       'brene_changed':False,'bakasusu_nomount_changed':False,
       'note':'All 15 ARM64 objects were rebuilt by the inherited R18 stage. '
              'R19 checks 13 provider symbols by actual ELF symbol class; '
              'no full vmlinux link, vendor ABI/CRC, or runtime validation.'
    }
    output.mkdir(parents=True)
    nm_dir=output/'nm'
    nm_dir.mkdir()
    for target,data in observed.items():
        (nm_dir/(target.replace('/','_')+'.nm.txt')).write_text(data)
    (nm_dir/'R19_QC_VAS_UNDEFINED.nm.txt').write_text(undef)
    (output/'R19_PROVIDER_RESULT.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print('R19_REAL_ARM64=15/15; TYPED_PROVIDERS='+str(count)+'/13; QC_REF='+
          str(int(source_ref))+'; STATUS='+out['status']+
          '; IMAGE=NO; ABI=OPEN; FLASH=NO')
    return out

def main():
    a=argparse.ArgumentParser()
    for name in ['r18-report','snapshot','objout','toolchain','output']:
        a.add_argument('--'+name,required=True)
    q=a.parse_args()
    try:
        report=run(Path(q.r18_report),Path(q.snapshot),Path(q.objout),
                   Path(q.toolchain),Path(q.output))
    except (GateError,OSError,ValueError,KeyError,TypeError,subprocess.TimeoutExpired) as e:
        print('R19_STRICT_GATE_ERROR:'+str(e),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
