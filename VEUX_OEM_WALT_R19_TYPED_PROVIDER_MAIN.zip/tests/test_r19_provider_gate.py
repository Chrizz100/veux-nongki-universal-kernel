import copy
import hashlib
import json
import pathlib
import re
import sys
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import r19_provider_gate as gate

F = ROOT/'fixtures'
J = json.loads((F/'R18_COMPILER_RESULT_GITHUB.json').read_text())
NM = {name: (F/(name.replace('/','_')+'.nm.txt')).read_text() for name in gate.REQUIRED}
U = (F/'R18_QC_VAS_UNDEFINED.nm.txt').read_text()

class SourceAuthenticity(unittest.TestCase):
    def test_01_original_github_object_count(self):
        self.assertEqual(J['object_success_count'],15)
        self.assertEqual(len(J['objects']),15)

    def test_02_original_github_only_data_fail(self):
        gate.check_report(J)
        self.assertFalse(J['symbol_evidence']['providers']['kernel/cpu.o']['symbols']['__cpu_isolated_mask'])

    def test_03_original_nm_global_data_definition(self):
        self.assertIn('---------------- D __cpu_isolated_mask', NM['kernel/cpu.o'])

    def test_04_original_qcvas_global_data_reference(self):
        self.assertIn('                 U __cpu_isolated_mask', U)

    def test_05_original_real_13_of_13(self):
        states, count, ref = gate.review_nm(NM,U)
        self.assertEqual(count,13)
        self.assertTrue(ref)
        self.assertTrue(all(v['confirmed'] for m in states.values() for v in m.values()))

    def test_06_original_all_fifteen_sha_and_compiler_exit(self):
        self.assertTrue(all(obj['compiled'] and obj['exit_code']==0 and obj['object_present'] and obj['object_bytes']>0 and len(obj['object_sha256'])==64 for obj in J['objects'].values()))

    def test_07_original_eight_exact_source_postimages(self):
        self.assertEqual(set(J['r18_postimages']),gate.POSTIMAGES)

    def test_08_original_no_flash_claim(self):
        for k in ('flash_allowed','kernel_image_built','vmlinux_linked','vendor_abi_proven','runtime_tested','brene_changed','bakasusu_nomount_changed'):
            self.assertIs(J[k],False,k)

class TypedProviderChecks(unittest.TestCase):
    def test_09_required_scope(self):
        self.assertEqual(len(gate.REQUIRED),8)
        self.assertEqual(sum(len(v) for v in gate.REQUIRED.values()),13)
        self.assertEqual(sum(x=='D' for v in gate.REQUIRED.values() for x in v.values()),1)

    def test_10_valid_text(self):
        self.assertTrue(gate.symbol_found('---------------- T f\n','f','T'))

    def test_11_valid_data(self):
        self.assertTrue(gate.symbol_found('---------------- D __cpu_isolated_mask\n','__cpu_isolated_mask','D'))

    def test_12_valid_hex_address(self):
        self.assertTrue(gate.symbol_found('0000000000000000 D __cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_13_no_local_data(self):
        self.assertFalse(gate.symbol_found('---------------- d __cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_14_no_undefined(self):
        self.assertFalse(gate.symbol_found('                 U __cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_15_no_weak_provider(self):
        self.assertFalse(gate.symbol_found('---------------- W __cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_16_no_function_as_data(self):
        self.assertFalse(gate.symbol_found('---------------- T __cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_17_no_data_as_function(self):
        self.assertFalse(gate.symbol_found('---------------- D migrate_tasks','migrate_tasks','T'))

    def test_18_no_local_function(self):
        self.assertFalse(gate.symbol_found('---------------- t migrate_tasks','migrate_tasks','T'))

    def test_19_no_ksymtab_confusion(self):
        self.assertFalse(gate.symbol_found('---------------- d __ksymtab___cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_20_no_kstrtab_confusion(self):
        self.assertFalse(gate.symbol_found('---------------- d __kstrtab___cpu_isolated_mask','__cpu_isolated_mask','D'))

    def test_21_no_prose(self):
        self.assertFalse(gate.symbol_found('Successfully compiled __cpu_isolated_mask', '__cpu_isolated_mask','D'))

    def test_22_no_substring(self):
        self.assertFalse(gate.symbol_found('---------------- D __cpu_isolated_mask_fake','__cpu_isolated_mask','D'))

    def test_23_no_case_insensitive(self):
        self.assertFalse(gate.symbol_found('---------------- D __CPU_ISOLATED_MASK','__cpu_isolated_mask','D'))

    def test_24_missing_data_returns_12(self):
        altered=dict(NM);altered['kernel/cpu.o']=altered['kernel/cpu.o'].replace(' D __cpu_isolated_mask',' d __cpu_isolated_mask')
        _,count,_=gate.review_nm(altered,U)
        self.assertEqual(count,12)

    def test_25_missing_one_function_returns_12(self):
        altered=dict(NM);altered['kernel/watchdog.o']=altered['kernel/watchdog.o'].replace(' T watchdog_enable',' t watchdog_enable')
        _,count,_=gate.review_nm(altered,U)
        self.assertEqual(count,12)

    def test_26_missing_caller_is_not_proven(self):
        _,count,ref=gate.review_nm(NM,U.replace(' U __cpu_isolated_mask',' U __cpu_isolated_mask_X'))
        self.assertEqual(count,13)
        self.assertFalse(ref)

    def test_27_wrong_object_scope_rejected(self):
        altered=dict(NM);altered.pop('kernel/cpu.o')
        with self.assertRaises(gate.GateError):gate.review_nm(altered,U)

    def test_28_no_bogus_type_code(self):
        with self.assertRaises(gate.GateError):gate.symbol_found(' D fake','fake','X')

class RejectUntrustedResults(unittest.TestCase):
    def changed(self,callback):
        j=copy.deepcopy(J);callback(j)
        with self.assertRaises(gate.GateError):gate.check_report(j)

    def test_29_false_compiler_count(self):self.changed(lambda x:x.update(object_success_count=14))
    def test_30_nonzero_exit(self):self.changed(lambda x:x['objects']['kernel/cpu.o'].update(exit_code=1))
    def test_31_missing_real_object(self):self.changed(lambda x:x['objects']['kernel/cpu.o'].update(object_present=False))
    def test_32_compiler_timeout(self):self.changed(lambda x:x['objects']['kernel/cpu.o'].update(timed_out=True))
    def test_33_wrong_object_sha(self):self.changed(lambda x:x['objects']['kernel/cpu.o'].update(object_sha256='invalid'))
    def test_34_bad_kernel_version(self):self.changed(lambda x:x.update(kernel_version='5.4.273'))
    def test_35_bad_source_gate(self):self.changed(lambda x:x.update(source_r18_verified=False))
    def test_36_fake_flash_claim(self):self.changed(lambda x:x.update(flash_allowed=True))
    def test_37_fake_kernel_image_claim(self):self.changed(lambda x:x.update(kernel_image_built=True))
    def test_38_vendor_abi_unproven(self):self.changed(lambda x:x.update(vendor_abi_proven=True))
    def test_39_unwanted_brene_modification(self):self.changed(lambda x:x.update(brene_changed=True))
    def test_40_unwanted_susfs_modification(self):self.changed(lambda x:x.update(bakasusu_nomount_changed=True))
    def test_41_wrong_provider_count(self):self.changed(lambda x:x['symbol_evidence'].update(count_verified=13))
    def test_42_wrong_r18_symbol(self):self.changed(lambda x:x['symbol_evidence']['providers']['kernel/cpu.o']['symbols'].update(__cpu_isolated_mask=True))
    def test_43_missing_qcvas_reference(self):self.changed(lambda x:x['symbol_evidence'].update(qc_vas_undefined=[]))
    def test_44_extra_unknown_source(self):self.changed(lambda x:x['r18_postimages'].update({'random.c':'a'*64}))
    def test_45_wrong_previous_count(self):self.changed(lambda x:x.update(prior_eleven_preserved=10))
    def test_46_no_nm_success(self):self.changed(lambda x:x['symbol_evidence']['providers']['kernel/cpu.o'].update(nm_rc=1))

class LiveReplaySimulation(unittest.TestCase):
    def make_setup(self,t):
        t=pathlib.Path(t)
        objs=t/'obj';snap=t/'snapshot';tool=t/'toolchain';out=t/'out'
        objs.mkdir();snap.mkdir();(tool/'bin').mkdir(parents=True)
        j=copy.deepcopy(J)
        for name,item in j['objects'].items():
            data=('ELF-SYNTHETIC-R19-UNIT-'+name).encode()
            path=objs/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
            item['object_bytes']=len(data)
            item['object_sha256']=gate.sha(data)
        for name in j['r18_postimages']:
            data=('SOURCE-SYNTHETIC-R19-UNIT-'+name).encode()
            path=snap/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
            j['r18_postimages'][name]=gate.sha(data)
        report=t/'R18_COMPILER_RESULT.json';report.write_text(json.dumps(j))
        script=tool/'bin/llvm-nm'
        script.write_text('#!/usr/bin/env python3\nimport pathlib,sys\nf=pathlib.Path('+repr(str(F))+')\np=pathlib.Path(sys.argv[-1]);' +
                          'k=p.as_posix().split("/obj/",1)[-1].replace("/","_")+".nm.txt"\n' +
                          'if "--undefined-only" in sys.argv:k="R18_QC_VAS_UNDEFINED.nm.txt"\n' +
                          'sys.stdout.write((f/k).read_text())\n')
        script.chmod(0o755)
        return objs,snap,tool,report,out

    def test_47_full_real_structure_replay(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            before=(gate.sha((o/'kernel/cpu.o').read_bytes()),gate.sha((s/'kernel/sched/core.c').read_bytes()))
            result=gate.run(r,s,o,t,p)
            after=(gate.sha((o/'kernel/cpu.o').read_bytes()),gate.sha((s/'kernel/sched/core.c').read_bytes()))
            self.assertEqual(before,after)
            self.assertEqual(result['status'],gate.PROVEN)
            self.assertEqual(result['type_aware_symbol_count'],13)
            self.assertTrue(result['qc_vas_undefined_cpu_mask_reference_proven'])
            self.assertFalse(result['flash_allowed'])
            self.assertEqual(len(list((p/'nm').glob('*.nm.txt'))),9)

    def test_48_reject_modified_elf_bytes(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            (o/'kernel/cpu.o').write_bytes(b'CORRUPTION')
            with self.assertRaises(gate.GateError):gate.run(r,s,o,t,p)

    def test_49_reject_modified_kernel_source(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            (s/'kernel/sched/core.c').write_bytes(b'CORRUPTION')
            with self.assertRaises(gate.GateError):gate.run(r,s,o,t,p)

    def test_50_reject_existing_output(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            p.mkdir()
            with self.assertRaises(gate.GateError):gate.run(r,s,o,t,p)

    def test_51_reject_missing_llvm_nm(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            (t/'bin/llvm-nm').unlink()
            with self.assertRaises(gate.GateError):gate.run(r,s,o,t,p)

    def test_52_reject_symlink_object(self):
        with tempfile.TemporaryDirectory() as d:
            o,s,t,r,p=self.make_setup(d)
            orig=o/'kernel/cpu.o';q=o/'kernel/cpu.real';orig.rename(q);orig.symlink_to(q)
            with self.assertRaises(gate.GateError):gate.run(r,s,o,t,p)


if __name__=='__main__':unittest.main()
