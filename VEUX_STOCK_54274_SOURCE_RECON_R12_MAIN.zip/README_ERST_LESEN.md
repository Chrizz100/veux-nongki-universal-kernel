# VEUX R12 – echter WALT-Header-Quellabgleich, NOFLASH

R11 ergab bei **beiden** WALT-Objektproben Compiler-Exit 2. R12 ändert den Ansatz nicht in einen Produktionsport; es testet ausschließlich, ob die fünf **echten und fest gepinnten** Qualcomm-Header der älteren Quellfamilie die nachgewiesenen Deklarations-/Schnittstellenfehler beseitigen.

Die originalen Kernelquellen werden nicht geändert. R11s isolierter Worktree wird in `/RUNNER_TEMP` vorbereitet; danach werden genau `include/linux/sched/{stat,cpufreq,sysctl}.h`, `include/linux/arch_topology.h` und `include/linux/topology.h` aus dem **exakten gepinnten 5.4.61-Quellcommit** in den temporären Worktree übernommen. Git HEAD und Git-Blob-SHA werden sowohl an der Quelle als auch lokal gegen feste IDs geprüft. Es werden **keine** neuen Funktionsdefinitionen, Dummy-Stubs oder künstlichen CRCs eingeführt.

R12 enthält das vollständig authentifizierte ursprüngliche **R11 MAIN** als internes Beweispaket. Es werden keine R1–R11 MAIN-Dateien zusätzlich im Repository benötigt (bestehende Dateien müssen aber nicht gelöscht werden).

## Wichtige Grenzen

- Die originale Stock-`include/linux/sched.h` (SHA-256 `a9923e44...381b111`) bleibt unverändert.
- Der interne `kernel/sched/sched.h` kommt weiterhin aus der fremden Qualcomm-5.4.61-Quelle und ist **keine nachgewiesene Stock-ABI**.
- `CONFIG_RTMM` und die vollständigen WALT-Hooks sind weiterhin nicht portiert.
- Ein erfolgreicher **Objekt**build ist kein kompletter `vmlinux`-Link, kein Module.symvers-Abgleich, kein OEM-ABI-Pass und keine Boot- oder Flashfreigabe.
- Ein roter Workflow ist **absichtlich** ein echter Compilerfehler. Die drei getrennten Logs `R12_PREPARE_BUILD.log`, `R12_WEAK_BUILD.log` und `R12_REAL_BUILD.log` werden trotzdem hochgeladen.

Erst wenn der Test erfolgreich kompiliert, werden die noch fehlenden Kconfig-, Hook- und Stock-ABI-Abhängigkeiten gezielt untersucht. Nicht zum Flashen geeignet.
