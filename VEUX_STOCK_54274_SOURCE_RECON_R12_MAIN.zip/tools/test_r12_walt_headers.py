#!/usr/bin/env python3
"""Negative and integration regressions for R12 genuine-header experiment."""
import importlib.util
import json
from pathlib import Path
from unittest import TestCase, mock
import tempfile
import subprocess
import shutil

SPEC=importlib.util.spec_from_file_location('r12_walt_headers',Path(__file__).with_name('r12_walt_headers.py'))
M=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
ROOT=Path(__file__).resolve().parents[1]

def cmd(*args,cwd=None):
    return subprocess.check_output(args,cwd=cwd,text=True,stderr=subprocess.DEVNULL).strip()

class TestR12(TestCase):
    def test_01_real_main_manifest(self):
        m=M.load_main(ROOT)
        self.assertEqual(m['schema'],M.SCHEMA)
    def test_02_original_stock_task_sha(self):
        with M.ZipFile(ROOT/'reference/R11_MAIN_ORIGINAL.zip') as z:
            self.assertEqual(M.digest(z.read('reference/stock_sched.h')),M.STOCK_TASK_SHA)
    def test_03_pair_and_donor_pinned(self):
        m=M.load_main(ROOT)
        self.assertEqual(m['pair_commit'],M.PAIR_SHA)
        self.assertEqual(m['donor_commit'],M.DONOR_SHA)
    def test_04_source_count(self):
        self.assertEqual(len(M.PAIR_HEADERS),5)
        self.assertEqual(len(set(M.PAIR_HEADERS)),5)
    def test_05_exact_header_paths(self):
        for x in M.PAIR_HEADERS:
            self.assertTrue(x.startswith('include/linux/'))
            self.assertEqual(str(M.PurePosixPath(x)),x)
        self.assertNotIn('include/linux/sched.h',M.PAIR_HEADERS)
    def test_06_git_blob_formula(self):
        self.assertEqual(M.git_blob_hash(b'hello\n'),'ce013625030ba8dba906f756967f9e9ca394464a')
    def test_07_sha256_bundle(self):
        self.assertEqual(M.digest((ROOT/'reference/R11_MAIN_ORIGINAL.zip').read_bytes()),M.R11_SHA)
    def test_08_no_crc_spoof_or_generated_symbols(self):
        src=Path(M.__file__).read_text()
        for x in ('fwrite("0x945d02f2"','force_module_load','CONFIG_MODVERSIONS=n','-Wno-error'):
            self.assertNotIn(x,src)
    def test_09_manifest_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); shutil.copytree(ROOT,d/'main'); (d/'main/README_ERST_LESEN.md').write_text('tampered')
            with self.assertRaisesRegex(ValueError,'BAD_INPUT_HASH'):
                M.load_main(d/'main')
    def test_10_wrong_main_contract_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); shutil.copytree(ROOT,d/'main')
            m=json.loads((d/'main/MANIFEST_SHA256.json').read_text());m['flash_allowed']=True
            (d/'main/MANIFEST_SHA256.json').write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError,'UNSAFE_CONTRACT'):
                M.load_main(d/'main')
    def test_11_wrong_pin_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); shutil.copytree(ROOT,d/'main')
            m=json.loads((d/'main/MANIFEST_SHA256.json').read_text());m['pair_commit']='abcdef'
            (d/'main/MANIFEST_SHA256.json').write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError,'SOURCE_PROVENANCE_DRIFT'):
                M.load_main(d/'main')
    def test_12_symlink_inside_archive_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); shutil.copytree(ROOT,d/'main')
            (d/'main/shortcut').symlink_to(d/'main/README_ERST_LESEN.md')
            with self.assertRaisesRegex(ValueError,'UNSAFE_SYMLINK'):
                M.load_main(d/'main')
    def test_13_missing_rc_never_success(self):
        with tempfile.TemporaryDirectory() as d:
            z=M.summarize(d)
            self.assertFalse(z['object_compilation_pass']);self.assertFalse(z['flash_allowed'])
    def test_14_success_rc_always_noflash(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            for s in ['PREPARE','WEAK','REAL']:
                (d/f'R12_{s}_RC.txt').write_text('0\n');(d/f'R12_{s}_BUILD.log').write_text('CC ok\n')
            z=M.summarize(d)
            self.assertTrue(z['object_compilation_pass'])
            self.assertFalse(z['oem_abi_verified'])
            self.assertFalse(z['linked_vmlinux_built'])
    def test_15_compiler_error_never_success(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            for s,rc in [('PREPARE',0),('WEAK',2),('REAL',2)]:
                (d/f'R12_{s}_RC.txt').write_text(str(rc));(d/f'R12_{s}_BUILD.log').write_text('some.c:30: error: missing source\n')
            z=M.summarize(d);self.assertFalse(z['object_compilation_pass']);self.assertEqual(z['stages']['real']['compiler_error_count'],1)
    def test_16_decl_source_anchors_documented(self):
        all_ids=set(y for v in M.ANCHORS.values() for y in v)
        for name in ('sched_update_nr_prod','SCHED_CPUFREQ_WALT','sysctl_sched_user_hint','topology_possible_sibling_cpumask'):
            self.assertIn(name,all_ids)
    def test_17_git_worktree_source_pair_and_stock_header_guard(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d); donor=base/'donor'; pair=base/'pair'; trial=base/'trial'; reports=base/'reports'
            for path in (donor,pair):
                cmd('git','init','-q',str(path))
                cmd('git','config','user.name','Unit Tester',cwd=path)
                cmd('git','config','user.email','unit@example.invalid',cwd=path)
            # Original donor contains all five preexisting headers.
            for rel in M.PAIR_HEADERS:
                p=donor/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('original donor header\n')
            p=donor/'include/linux/sched.h';p.parent.mkdir(parents=True,exist_ok=True);p.write_text('original STOCK task header\n')
            cmd('git','add','.',cwd=donor);cmd('git','commit','-qm','base',cwd=donor)
            donor_commit=cmd('git','rev-parse','HEAD',cwd=donor)
            cmd('git','worktree','add','--detach',str(trial),donor_commit,cwd=donor)
            expected={}
            for rel,anchors in M.ANCHORS.items():
                p=pair/rel;p.parent.mkdir(parents=True,exist_ok=True)
                p.write_text('/* authentic header fixture */\n'+'\n'.join('extern int '+x+';' for x in anchors)+'\n')
                expected[rel]=M.git_blob_hash(p.read_bytes())
            cmd('git','add','.',cwd=pair);cmd('git','commit','-qm','pair',cwd=pair)
            pair_commit=cmd('git','rev-parse','HEAD',cwd=pair)
            with (mock.patch.object(M,'DONOR_SHA',donor_commit),mock.patch.object(M,'PAIR_SHA',pair_commit),
                  mock.patch.object(M,'PAIR_HEADERS',expected),
                  mock.patch.object(M,'STOCK_TASK_SHA',M.digest((trial/'include/linux/sched.h').read_bytes())),
                  mock.patch.object(M,'load_main',return_value={'schema':M.SCHEMA})):
                p=M.stage(ROOT,donor,pair,trial,reports)
                self.assertEqual(p['source_file_count'],5)
                self.assertTrue(p['stock_rtmm_implemented'] is False)
                self.assertEqual(cmd('git','status','--porcelain',cwd=donor),'')
                for rel in expected:
                    self.assertEqual((pair/rel).read_bytes(),(trial/rel).read_bytes())
                # Repeating a stage is possible but can't silently change the untouched stock task.
                (trial/'include/linux/sched.h').write_text('wrong STOCK layout')
                with self.assertRaisesRegex(ValueError,'STOCK_TASK_STRUCT_WOULD_CHANGE'):
                    M.stage(ROOT,donor,pair,trial,reports)
    def test_18_bad_pin_is_rejected_before_writes(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d)
            with mock.patch.object(M,'load_main',return_value={}):
                with self.assertRaises(Exception):
                    M.stage(ROOT,base/'missing',base/'missingpair',base/'missingtrial',base/'r')
            self.assertFalse((base/'r').exists())
    def test_19_diagnostic_only_source_files(self):
        main_files=M.load_main(ROOT)['files']
        self.assertFalse(any(x.endswith('.img') or x.endswith('.ko') for x in main_files))
    def test_20_nested_archive_is_original_verified_r11(self):
        with M.ZipFile(ROOT/'reference/R11_MAIN_ORIGINAL.zip') as z:
            self.assertIn('reference/R10_PINNED_WALT_SOURCES.tar.gz',z.namelist())
            self.assertIn('tools/r11_walt_probe.py',z.namelist())
