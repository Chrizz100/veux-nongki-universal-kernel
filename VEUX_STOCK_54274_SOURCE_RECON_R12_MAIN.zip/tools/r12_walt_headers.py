#!/usr/bin/env python3
"""R12 isolated WALT source-compatibility experiment: only genuine pinned headers.

NO production source patch; NO CRC spoof; NO boot/image/AK3 distribution.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
from pathlib import Path, PurePosixPath
from zipfile import ZipFile

SCHEMA = 'VEUX_R12_WALT_PINNED_INTERFACE_HEADER_PROBE_NOFLASH'
R11_SHA = '06a6f468699d0785b0db8bcbb745b51d8e12d6b7c26c6b3a4999248e1e994513'
DONOR_SHA = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
PAIR_SHA = '01cb3a8824b7b4caf3e3540274e71abba5ade538'
STOCK_TASK_SHA = 'a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
PAIR_HEADERS = {
    'include/linux/sched/stat.h': '60cf021ddff66b511fe17edae1d4f241b10781d3',
    'include/linux/sched/cpufreq.h': '5aa0259c8a2fee8bdf85ccb5a1fb6ee90faf0eb2',
    'include/linux/sched/sysctl.h': '4ccab15a72c69b1bbfbcc8569b06b5b2bbbc0a21',
    'include/linux/arch_topology.h': '883fba81796c6a4e107b43bfae806e4f6b750a62',
    'include/linux/topology.h': '831ad69caee8d3725e0b6cdc156427728ee58fc8',
}
# Each identifier below must be supplied by a pinned upstream header, NOT invented.
ANCHORS = {
    'include/linux/sched/stat.h': ('sched_update_nr_prod', 'sched_update_hyst_times'),
    'include/linux/sched/cpufreq.h': ('SCHED_CPUFREQ_WALT', 'SCHED_CPUFREQ_INTERCLUSTER_MIG'),
    'include/linux/sched/sysctl.h': ('MAX_MARGIN_LEVELS', 'sysctl_sched_user_hint',
                                      'sysctl_walt_rtg_cfs_boost_prio'),
    'include/linux/arch_topology.h': ('topology_possible_sibling_cpumask',),
    'include/linux/topology.h': ('topology_possible_sibling_cpumask',),
}

def digest(data): return hashlib.sha256(data).hexdigest()

def git_blob_hash(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo), *args],text=True,stderr=subprocess.PIPE).strip()

def load_main(root):
    root=Path(root)
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (m.get('schema')!=SCHEMA or m.get('flash_allowed') is not False or
        m.get('oem_abi_verified') is not False or m.get('kernel_build_requested') is not True or
        m.get('production_source_patch_approved') is not False):
        raise ValueError('R12_UNSAFE_CONTRACT')
    if (m.get('pair_commit')!=PAIR_SHA or m.get('donor_commit')!=DONOR_SHA or
        m.get('r11_sha256')!=R11_SHA or m.get('stock_task_sha256')!=STOCK_TASK_SHA or
        m.get('pair_headers')!=PAIR_HEADERS):
        raise ValueError('R12_SOURCE_PROVENANCE_DRIFT')
    if (set(root.rglob('*')) and any(i.is_symlink() for i in root.rglob('*'))):
        raise ValueError('R12_UNSAFE_SYMLINK')
    for rel,sha in m['files'].items():
        path=root/rel
        if not path.is_file() or path.is_symlink() or digest(path.read_bytes())!=sha:
            raise ValueError('R12_BAD_INPUT_HASH:'+rel)
    if (set(p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()) !=
        set(m['files'])|{'MANIFEST_SHA256.json'}):
        raise ValueError('R12_UNEXPECTED_FILESET')
    if digest((root/'reference/R11_MAIN_ORIGINAL.zip').read_bytes())!=R11_SHA:
        raise ValueError('R12_R11_BUNDLE_DRIFT')
    with ZipFile(root/'reference/R11_MAIN_ORIGINAL.zip') as z:
        if z.testzip() is not None: raise ValueError('R12_R11_CORRUPT')
        p=json.loads(z.read('MANIFEST_SHA256.json'))
        if (p.get('schema')!='VEUX_R11_STOCK_TASK_WALT_OBJECT_PROBE_NOFLASH' or
            p.get('flash_allowed') is not False or p.get('donor_commit')!=DONOR_SHA or p.get('pair_commit')!=PAIR_SHA):
            raise ValueError('R12_WRONG_NESTED_R11')
        if digest(z.read('reference/stock_sched.h'))!=STOCK_TASK_SHA:
            raise ValueError('R12_R11_STOCK_TASK_DRIFT')
    return m

def verify_source_pair(pair):
    pair=Path(pair)
    if git(pair,'rev-parse','HEAD')!=PAIR_SHA or git(pair,'status','--porcelain'):
        raise ValueError('R12_PAIR_HEAD_OR_CLEAN_STATE_DRIFT')
    files={}
    for rel,expected in PAIR_HEADERS.items():
        path=pair/rel
        if not path.is_file() or path.is_symlink():
            raise ValueError('R12_PAIR_FILE_MISSING:'+rel)
        # Git HEAD blob and local checked-out byte-level identity are checked separately.
        if git(pair,'rev-parse','HEAD:'+rel)!=expected:
            raise ValueError('R12_PAIR_GIT_BLOB_DRIFT:'+rel)
        raw=path.read_bytes()
        if git_blob_hash(raw)!=expected:
            raise ValueError('R12_PAIR_WORKTREE_CONTENT_DRIFT:'+rel)
        for key in ANCHORS[rel]:
            if key.encode() not in raw:
                raise ValueError('R12_ORIGINAL_DECLARATION_MISSING:'+rel+':'+key)
        files[rel]=raw
    return files

def stage(root, donor, pair, trial, reports):
    load_main(root)
    donor=Path(donor); trial=Path(trial); reports=Path(reports)
    if git(donor,'rev-parse','HEAD')!=DONOR_SHA or git(donor,'status','--porcelain'):
        raise ValueError('R12_ORIGINAL_DONOR_DRIFT')
    if git(trial,'rev-parse','HEAD')!=DONOR_SHA:
        raise ValueError('R12_TRIAL_NOT_PINNED_DONOR')
    source=verify_source_pair(pair)
    stock_header=trial/'include/linux/sched.h'
    if not stock_header.is_file() or digest(stock_header.read_bytes())!=STOCK_TASK_SHA:
        raise ValueError('R12_STOCK_TASK_STRUCT_WOULD_CHANGE')
    report={}
    for rel,raw in source.items():
        target=trial/rel
        if target.is_symlink() or not target.is_file():
            raise ValueError('R12_DONOR_HEADER_MISSING_OR_UNSAFE:'+rel)
        old=target.read_bytes()
        target.write_bytes(raw)
        if digest(target.read_bytes())!=digest(raw):
            raise ValueError('R12_HEADER_STAGE_FAILED:'+rel)
        report[rel]={'pair_git_blob':PAIR_HEADERS[rel], 'old_donor_sha256':digest(old),
                     'new_pair_sha256':digest(raw), 'bytes':len(raw)}
    if digest(stock_header.read_bytes())!=STOCK_TASK_SHA or git(donor,'status','--porcelain'):
        raise ValueError('R12_STOCK_HEADER_OR_DONOR_MODIFIED')
    result={'schema':SCHEMA,'source_commit_pair':PAIR_SHA,'source_commit_donor':DONOR_SHA,
            'original_stock_task_struct_sha256':STOCK_TASK_SHA,
            'origin':'verified source-level headers, never a proposed production patch',
            'source_files_staged':report,'source_file_count':len(report),
            'production_source_patch_approved':False,'stock_rtmm_implemented':False,
            'full_walt_scheduler_hooks_integrated':False,'full_kernel_linked':False,
            'vendor_abi_verified':False,'flash_allowed':False}
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R12_SOURCE_INTERFACE_PROVENANCE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R12_STOCK_TASK_UNCHANGED':True,'R12_GENUINE_PAIR_HEADER_COUNT':len(report),
                      'R12_DONOR_UNCHANGED':True,'FLASH_ALLOWED':False}))
    return result

def summarize(reports):
    reports=Path(reports)
    stages={}
    for name in ['prepare','weak','real']:
        rcp=reports/f'R12_{name.upper()}_RC.txt';log=reports/f'R12_{name.upper()}_BUILD.log'
        rc=int(rcp.read_text().strip()) if rcp.exists() else None
        body=log.read_text(errors='replace') if log.exists() else ''
        errors=[x[:600] for x in body.splitlines() if re.search(r'\berror:|\bfatal error:|make(?:\[\d+\])?: \*\*\*',x)]
        stages[name]={'rc':rc,'compiler_error_count':len(errors),'first_errors':errors[:80],
                      'log_line_count':len(body.splitlines())}
    green=all(stages[n]['rc']==0 for n in ('prepare','weak','real'))
    result={'schema':SCHEMA,'status':'R12_OBJECT_COMPILER_PASS_NOT_ABI' if green else 'R12_WALT_COMPILER_BLOCKERS',
            'stages':stages,'object_compilation_pass':green,'full_walt_scheduler_hooks_integrated':False,
            'stock_rtmm_implemented':False,'linked_vmlinux_built':False,
            'oem_abi_verified':False,'boot_tested':False,'flash_allowed':False}
    (reports/'R12_WALT_OBJECT_BUILD_SUMMARY.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R12_COMPILER_GREEN':green,'PREPARE_RC':stages['prepare']['rc'],
                      'WEAK_RC':stages['weak']['rc'],'REAL_RC':stages['real']['rc'],'FLASH_ALLOWED':False}))
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('command',choices=['verify','stage','summary'])
    ap.add_argument('--root');ap.add_argument('--donor');ap.add_argument('--pair');ap.add_argument('--trial');ap.add_argument('--reports')
    args=ap.parse_args()
    if args.command=='verify': print(json.dumps({'R12_MANIFEST_AUTH':load_main(args.root)['schema'],'FLASH_ALLOWED':False}))
    elif args.command=='stage': stage(args.root,args.donor,args.pair,args.trial,args.reports)
    else: summarize(args.reports)
if __name__=='__main__': main()
