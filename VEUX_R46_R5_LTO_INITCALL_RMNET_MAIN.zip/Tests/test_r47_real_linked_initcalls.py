"""Negative & positive proof tests for R46-R4's genuine WALT built-in gate."""
import importlib.util
import os
import pathlib
import stat
import struct
import tempfile
import unittest
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('r47_link',ROOT/'Tools/veux_r47_r13_on_r46.py')
g=importlib.util.module_from_spec(sp);sp.loader.exec_module(g)


def sysmap(shs=True,offload=True,core=True,duplicate=False,wrong_section=False):
    x=['ffffffc0127bacd0 D __initcall_start','ffffffc0127bb8f8 D __initcall6_start',
       'ffffffc0127bd098 D __initcall7_start','ffffffc0127bd268 D __initcall_end']
    if shs:
        a='ffffffc0127bd100' if wrong_section else 'ffffffc0127bb980'
        x += [f'{a} d __initcall_309_126_DATARMNET163e93649e6']
        if duplicate:x += ['ffffffc0127bb988 d __initcall_111_126_DATARMNET163e93649e6']
    if offload:x += ['ffffffc0127bb998 d __initcall_211_98_DATARMNETb1c42acd9c6']
    if core:x += ['ffffffc0127bb9a8 d __initcall_317_794_rmnet_init6']
    return '\n'.join(x)+'\n'


def buildlog(llvm_missing=False, missing_archive=False, linker_warning=False):
    x=['  CC      techpack/datarmnet-ext/shs/rmnet_shs_config.o',
       '  CC      techpack/datarmnet-ext/offload/rmnet_offload_state.o',
       '  AR      techpack/datarmnet-ext/shs/built-in.a',
       '  AR      techpack/datarmnet-ext/offload/built-in.a',
       '  LTO     vmlinux.o','  MODPOST vmlinux.o','  OBJCOPY arch/arm64/boot/Image']
    if linker_warning:x += ["ld.lld: warning: vmlinux.o initcall section placement"]
    if missing_archive:x.remove('  AR      techpack/datarmnet-ext/shs/built-in.a')
    if llvm_missing:x+=['/bin/sh: 1: llvm-nm: not found']
    return '\n'.join(x)+'\n'


class RealLinkProof(unittest.TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory()
        self.dir=pathlib.Path(self.t.name)
        (self.dir/'System.map').write_text(sysmap())
        (self.dir/'R47_Image_MAKE.log').write_text(buildlog())
    def tearDown(self):self.t.cleanup()
    def test_51_genuine_both_initcalls_present(self):
        p=g.prove_real_linked_initcalls(self.dir/'System.map')
        self.assertEqual(set(p),{'rmnet_shs','rmnet_offload','rmnet_core'})
        self.assertTrue(all(row['section_range']=='initcall6' for row in p.values()))
    def test_52_module_builtin_file_not_needed_to_prove_link(self):
        self.assertFalse((self.dir/'modules.builtin').exists())
        self.assertEqual(len(g.prove_real_linked_initcalls(self.dir/'System.map')),3)
    def test_53_absent_shs_rejected(self):
        (self.dir/'System.map').write_text(sysmap(shs=False))
        with self.assertRaisesRegex(g.GateError,'R47_EXPECT_EXACT_ONE_LINKED_INITCALL:rmnet_shs'):
            g.prove_real_linked_initcalls(self.dir/'System.map')
    def test_54_absent_offload_rejected(self):
        (self.dir/'System.map').write_text(sysmap(offload=False))
        with self.assertRaisesRegex(g.GateError,'R47_EXPECT_EXACT_ONE_LINKED_INITCALL:rmnet_offload'):
            g.prove_real_linked_initcalls(self.dir/'System.map')
    def test_55_absent_rmnet_core_rejected(self):
        (self.dir/'System.map').write_text(sysmap(core=False))
        with self.assertRaisesRegex(g.GateError,'R47_EXPECT_EXACT_ONE_LINKED_INITCALL:rmnet_core'):
            g.prove_real_linked_initcalls(self.dir/'System.map')
    def test_56_duplicated_symbol_rejected(self):
        (self.dir/'System.map').write_text(sysmap(duplicate=True))
        with self.assertRaisesRegex(g.GateError,'R47_EXPECT_EXACT_ONE_LINKED_INITCALL:rmnet_shs'):
            g.prove_real_linked_initcalls(self.dir/'System.map')
    def test_57_wrong_initcall_section_rejected(self):
        (self.dir/'System.map').write_text(sysmap(wrong_section=True))
        with self.assertRaisesRegex(g.GateError,'R47_INITCALL_OUTSIDE_LEVEL6:rmnet_shs'):
            g.prove_real_linked_initcalls(self.dir/'System.map')
    def test_58_genuine_build_log_pass_and_captures_linker_warnings(self):
        (self.dir/'R47_Image_MAKE.log').write_text(buildlog(linker_warning=True))
        p=g.prove_build_log(self.dir/'R47_Image_MAKE.log')
        self.assertEqual(p['linker_warnings_requires_review'],1)
        self.assertFalse(p['linker_warning_free'])
    def test_59_missing_llvm_nm_rejected_even_when_make_exited_zero(self):
        (self.dir/'R47_Image_MAKE.log').write_text(buildlog(llvm_missing=True))
        with self.assertRaisesRegex(g.GateError,'R47_LLVM_NM_MISSING_DURING_LINK'):
            g.prove_build_log(self.dir/'R47_Image_MAKE.log')
    def test_60_missing_compiled_archive_rejected(self):
        (self.dir/'R47_Image_MAKE.log').write_text(buildlog(missing_archive=True))
        with self.assertRaisesRegex(g.GateError,'R47_REAL_LINK_TRACE_NOT_FOUND'):
            g.prove_build_log(self.dir/'R47_Image_MAKE.log')
    def test_61_a_child_shell_can_find_exact_pinned_llvm_nm(self):
        d=self.dir/'clang/bin';d.mkdir(parents=True)
        nm=d/'llvm-nm';nm.write_text('#!/bin/sh\nexit 0\n');nm.chmod(0o755)
        with mock.patch.dict(os.environ,{'PATH':'/usr/bin'},clear=False):
            env=g.pinned_llvm_tool_env(['make','NM='+str(nm)])
        self.assertEqual(env['PATH'].split(os.pathsep)[0],str(d))
    def test_62_absent_pinned_nm_preflight_blocks(self):
        with self.assertRaisesRegex(g.GateError,'PINNED_LLVM_NM_NOT_EXECUTABLE'):
            g.pinned_llvm_tool_env(['make','NM='+str(self.dir/'clang/bin/llvm-nm')])
    def test_63_no_unsigned_nm_override(self):
        with self.assertRaisesRegex(g.GateError,'PINNED_LLVM_NM_INVALID'):
            g.pinned_llvm_tool_env(['make','NM=/tmp/not-the-pinned-tool'])
    def test_64_no_old_false_modules_builtin_gate(self):
        text=(ROOT/'Tools/veux_r47_r13_on_r46.py').read_text()
        self.assertNotIn('R47_RMNET_NOT_IN_MODULES_BUILTIN',text)
        self.assertIn('prove_real_linked_initcalls',text)
    def _output(self):
        d=self.dir/'obj';d.mkdir()
        (d/'include/config').mkdir(parents=True)
        (d/'include/config/kernel.release').write_text('5.4.274~positron\n')
        (d/'.config').write_bytes((ROOT/'References/R46_EFFECTIVE.config').read_bytes())
        (d/'arch/arm64/boot/dts/vendor/xiaomi').mkdir(parents=True)
        (d/'arch/arm64/boot/Image').write_bytes(b'\x00'*0x38+b'ARM\x64'+b'\x00'*200)
        (d/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb').write_bytes(b'\xd0\x0d\xfe\xed'+b'\x00'*16)
        (d/'vmlinux').write_bytes(b'\x7fELF'+bytes([2,1])+b'\x00'*12+struct.pack('<H',183))
        (d/'Module.symvers').write_bytes(b'0'*50010)
        (d/'System.map').write_text(sysmap())
        (d/'modules.order').write_text('\n'.join(sorted(g.OTHER_MODULE_PATHS))+'\n')
        (d/'modules.builtin').write_text('')
        return d
    def test_65_valid_link_passes_without_builtin_registry_names(self):
        d=self._output()
        b={'image':{'sha256':'0'*64}}
        proof=g.verify_relink_result(d,b,'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256,
                  before_system_map_sha='1'*64,image_log=self.dir/'R47_Image_MAKE.log')
        self.assertEqual(set(proof['built_in_rmnet_initcall_proven']),set(g.INITCALL_NAMES))
        self.assertEqual(proof['modules_builtin_metadata_only_matches'],[])
        self.assertIs(proof['vendor_abi_proven'],False)
        self.assertIs(proof['flash_allowed'],False)
    def test_66_old_external_rmnet_order_blocks(self):
        d=self._output();(d/'modules.order').write_text('\n'.join(g.OTHER_MODULE_PATHS|g.ORIGINAL_MODULE_PATHS))
        with self.assertRaisesRegex(g.GateError,'R47_RMNET_STILL_EXTERNAL_IN_MODULE_ORDER'):
            g.verify_relink_result(d,{'image':{'sha256':'0'*64}},'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256)
    def test_67_missing_external_bluetooth_module_blocks(self):
        d=self._output();(d/'modules.order').write_text('drivers/char/rdbg.ko\n')
        with self.assertRaisesRegex(g.GateError,'R47_OTHER_FOUR_MODULES_MISSING'):
            g.verify_relink_result(d,{'image':{'sha256':'0'*64}},'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256)
    def test_68_unchanged_system_map_blocks(self):
        d=self._output();h=g.sha_file(d/'System.map')
        with self.assertRaisesRegex(g.GateError,'R47_SYSTEM_MAP_UNCHANGED'):
            g.verify_relink_result(d,{'image':{'sha256':'0'*64}},'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256,before_system_map_sha=h)
    def test_69_experimental_kernel_release_must_stay(self):
        d=self._output();(d/'include/config/kernel.release').write_text('5.4.274-qgki-g82179e362f33\n')
        with self.assertRaisesRegex(g.GateError,'KERNEL_RELEASE_CHANGED'):
            g.verify_relink_result(d,{'image':{'sha256':'0'*64}},'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256)
    def test_70_rootless_config_must_not_change(self):
        d=self._output();(d/'.config').write_text('CONFIG_MODULES=n\n')
        with self.assertRaisesRegex(g.GateError,'CONFIG_CHANGED_DURING'):
            g.verify_relink_result(d,{'image':{'sha256':'0'*64}},'5.4.274~positron',g.R46_EFFECTIVE_CONFIG_SHA256)

if __name__=='__main__':unittest.main()
