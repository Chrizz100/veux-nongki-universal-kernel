"""Adversarial offline source/build proof tests: never compiles or flashes a real kernel."""
import hashlib
import importlib.util
import json
import pathlib
import shutil
import struct
import sys
import tempfile
import unittest
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('r47_impl',ROOT/'Tools/veux_r47_r13_on_r46.py')
g=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(g)

class R13Reused(unittest.TestCase):
    def test_01_hist_sums(self):
        for kind,item in g.FILES.items():
            old=(ROOT/'Fixtures'/f'{kind}_Kbuild').read_bytes()
            self.assertEqual(g.sha_bytes(old),item['pre_sha'])
            self.assertEqual(g.sha_bytes(g.expected_postimage(old,item)),item['post_sha'])
    def test_02_two_files_only(self):
        self.assertEqual(set(g.FILES),{'shs','offload'})
    def test_03_same_size_two_hunks(self):
        for kind,item in g.FILES.items():
            old=(ROOT/'Fixtures'/f'{kind}_Kbuild').read_bytes()
            new=g.expected_postimage(old,item)
            self.assertEqual(len(old),len(new))
            self.assertEqual(old.count(b'obj-m'),1)
            self.assertEqual(new.count(b'obj-y'),1)
    def test_04_R13_symbols_left_alone(self):
        for kind,item in g.FILES.items():
            old=(ROOT/'Fixtures'/f'{kind}_Kbuild').read_bytes()
            new=g.expected_postimage(old,item)
            self.assertIn(b'KBUILD_EXTRA_SYMBOLS',new)
            self.assertEqual(old.count(b'KBUILD_EXTRA_SYMBOLS'),new.count(b'KBUILD_EXTRA_SYMBOLS'))
    def test_05_second_hunk_rejected(self):
        s=g.FILES['shs']; b=(ROOT/'Fixtures/shs_Kbuild').read_bytes()
        with self.assertRaises(g.GateError):g.expected_postimage(b+b'obj-m += rmnet_shs.o\n',s)
    def test_06_changed_hunk_rejected(self):
        s=g.FILES['shs']; b=(ROOT/'Fixtures/shs_Kbuild').read_bytes()
        with self.assertRaises(g.GateError):g.expected_postimage(b.replace(b'obj-m',b'obj-b'),s)
    def test_07_wrong_post_sha_rejected(self):
        s=dict(g.FILES['shs'],post_sha='0'*64)
        with self.assertRaises(g.GateError):g.expected_postimage((ROOT/'Fixtures/shs_Kbuild').read_bytes(),s)
    def test_08_unapproved_other_bytes_rejected(self):
        s=g.FILES['shs']; b=(ROOT/'Fixtures/shs_Kbuild').read_bytes()+b'\n'
        with self.assertRaises(g.GateError):g.expected_postimage(b,s)
    def test_09_no_rootless_version_forgery(self):
        self.assertEqual(g.STOCK_RELEASE,'5.4.274-qgki-g82179e362f33')
        self.assertEqual(g.CONFIG_MARKERS['CONFIG_MODULES'],'y')

class AtomicSource(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)
        for kind,s in g.FILES.items():
            p=self.path/s['path'];p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes((ROOT/'Fixtures'/f'{kind}_Kbuild').read_bytes())
    def tearDown(self):self.tmp.cleanup()
    def test_10_all_preimages_proven(self):
        self.assertEqual(len(g.validate_pinned_source(self.path)),2)
    def test_11_exact_patch_and_hash(self):
        v=g.apply_two_hunks(self.path);self.assertEqual(len(v),2)
        for kind,s in g.FILES.items():self.assertEqual(g.sha_file(self.path/s['path']),s['post_sha'])
    def test_12_atomic_guard_no_write_when_second_bad(self):
        b=self.path/g.FILES['offload']['path'];b.write_bytes(b.read_bytes()+b'--bad')
        a=self.path/g.FILES['shs']['path'];old=a.read_bytes()
        with self.assertRaisesRegex(g.GateError,'SOURCE_SHA_MISMATCH'):g.apply_two_hunks(self.path)
        self.assertEqual(a.read_bytes(),old)
    def test_13_already_applied_must_refuse(self):
        g.apply_two_hunks(self.path)
        with self.assertRaisesRegex(g.GateError,'SOURCE_SHA_MISMATCH'):g.apply_two_hunks(self.path)
    def test_14_missing_path_must_refuse(self):
        (self.path/g.FILES['shs']['path']).unlink()
        with self.assertRaisesRegex(g.GateError,'MISSING_OR_SYMLINK'):g.validate_pinned_source(self.path)
    def test_15_symlink_must_refuse(self):
        p=self.path/g.FILES['shs']['path'];p.unlink()
        p.symlink_to(self.path/g.FILES['offload']['path'])
        with self.assertRaisesRegex(g.GateError,'MISSING_OR_SYMLINK'):g.validate_pinned_source(self.path)
    def test_16_unrelated_source_untouched(self):
        side=self.path/'init/main.c';side.parent.mkdir();side.write_bytes(b'untouched')
        g.apply_two_hunks(self.path);self.assertEqual(side.read_bytes(),b'untouched')

class ConfigAndModules(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.config=(ROOT/'References/R46_EFFECTIVE.config').read_text()
    def test_17_real_config(self):
        g.config_assert(self.config)
        self.assertEqual(g.sha_bytes(self.config.encode()),g.R46_EFFECTIVE_CONFIG_SHA256)
    def test_18_root_module_enabled_block(self):
        with self.assertRaisesRegex(g.GateError,'ROOT_COMPONENT_ENABLED'):
            g.config_assert(self.config+'\nCONFIG_NOMOUNT=y\n')
    def test_19_walt_disabled_block(self):
        with self.assertRaisesRegex(g.GateError,'CONFIG_DRIFT'):
            g.config_assert(self.config.replace('CONFIG_SCHED_WALT=y','# CONFIG_SCHED_WALT is not set'))
    def test_20_modules_disabled_block(self):
        with self.assertRaisesRegex(g.GateError,'CONFIG_DRIFT'):
            g.config_assert(self.config.replace('CONFIG_MODULES=y','# CONFIG_MODULES is not set'))
    def test_21_modversions_disabled_block(self):
        with self.assertRaisesRegex(g.GateError,'CONFIG_DRIFT'):
            g.config_assert(self.config.replace('CONFIG_MODVERSIONS=y','# CONFIG_MODVERSIONS is not set'))
    def test_22_other_four_modules_preserved(self):
        self.assertEqual(len(g.OTHER_MODULE_PATHS),4)
        self.assertEqual(len(g.ORIGINAL_MODULE_PATHS),2)
    def test_23_image_magic_good_and_bad(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'Image';p.write_bytes(b'\x00'*0x38+b'ARM\x64'+b'\x00'*50)
            self.assertTrue(g.is_arm64_image(p))
            p.write_bytes(b'\x00'*90);self.assertFalse(g.is_arm64_image(p))
    def test_24_aarch64_elf_good_and_bad(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'vmlinux';p.write_bytes(b'\x7fELF'+bytes([2,1])+b'\0'*12+struct.pack('<H',183))
            self.assertTrue(g.is_arm64_elf(p));p.write_bytes(b'x'+p.read_bytes()[1:]);self.assertFalse(g.is_arm64_elf(p))
    def test_25_module_order_paths(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'modules.order';p.write_text('./drivers/char/rdbg.ko\n\n')
            self.assertEqual(g.normalize_module_lines(p),{'drivers/char/rdbg.ko'})
    def test_26_stale_module_guard_requires_actual_order(self):
        bad=set(g.OTHER_MODULE_PATHS)|g.ORIGINAL_MODULE_PATHS
        self.assertFalse(g.ORIGINAL_MODULE_PATHS.isdisjoint(bad))

class ActualR46Reference(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ref=json.loads((ROOT/'References/R46_REAL_BUILD_RESULT.json').read_text())
        cls.r46=json.loads((ROOT/'References/R46_FIVE_WARNINGS_RESULT.json').read_text())
    def test_27_r46_real_build_true(self):self.assertTrue(self.ref['full_image_proven'])
    def test_28_all_six_base_ko(self):
        self.assertEqual({m['path'] for m in self.ref['module_files']},g.OTHER_MODULE_PATHS|g.ORIGINAL_MODULE_PATHS)
    def test_29_R46_old_warning_zero(self):self.assertEqual(self.r46['old_warning_occurrences_after_rebuild'],0)
    def test_30_R46_not_stock_verified(self):self.assertIs(self.ref['vendor_abi_proven'],False)
    def test_31_no_false_oem_release(self):self.assertIs(self.r46['flash_allowed'],False)
    def test_32_make_exact_real_targets(self):
        for t in ('Image','dtbs','modules'):
            s=self.ref['make_targets'][t]
            self.assertEqual(s['exit_code'],0)
            self.assertEqual(s['invocation'][-1],t)
            self.assertIn('-j2',s['invocation'])
    def test_33_no_shell_invocation_in_builder(self):
        # The make command is a validated argv list, never assembled by shell=True.
        import inspect
        src=inspect.getsource(g.invoke_exact_make)
        self.assertIn('subprocess.run(argv',src)
        self.assertNotIn('shell=True',src)

if __name__ == '__main__':unittest.main()
