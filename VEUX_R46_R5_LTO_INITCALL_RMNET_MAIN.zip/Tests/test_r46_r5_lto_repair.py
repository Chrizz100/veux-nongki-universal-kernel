"""R46-R5: pinned LTO linker-script and LLVM child environment regressions."""
import hashlib
import importlib.util
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest
from unittest import mock

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r47_impl',ROOT/'Tools/veux_r47_r13_on_r46.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)

# Literal lines from the pinned Positron vmlinux.lds.h, no changes to stock identity.
ORIGINAL_LDS=b'''#define INIT_CALLS_LEVEL(level)\\
    __initcall##level##_start = .;\\
    KEEP(*(.initcall##level##.init))\\
    KEEP(*(.initcall##level##s.init))\\
#define INIT_CALLS\\
    KEEP(*(.initcallearly.init))\\
    INIT_CALLS_LEVEL(6)\\
    INIT_CALLS_LEVEL(7)\\
#define CON_INITCALL\\
    KEEP(*(.con_initcall.init))\\
'''

class TestLinkerFix(unittest.TestCase):
    def test_71_exact_rules(self):
        self.assertEqual(len(g.LTO_INITCALL_KEEP_RULES),4)
        self.assertEqual(len({a for a,b in g.LTO_INITCALL_KEEP_RULES}),4)
    def test_72_no_reordering_initcall_levels(self):
        a=g.expected_lto_linker_postimage(ORIGINAL_LDS)
        self.assertIn(b'INIT_CALLS_LEVEL(6)',a)
        self.assertLess(a.index(b'INIT_CALLS_LEVEL(6)'),a.index(b'INIT_CALLS_LEVEL(7)'))
        for old,new in g.LTO_INITCALL_KEEP_RULES:
            self.assertIn(new,a)
            self.assertEqual(a.count(new),1)
    def test_73_non_initcall_text_byte_equal(self):
        out=g.expected_lto_linker_postimage(ORIGINAL_LDS)
        for old,new in g.LTO_INITCALL_KEEP_RULES:out=out.replace(new,old)
        self.assertEqual(out,ORIGINAL_LDS)
    def test_74_lto_rules_not_present_fail_closed(self):
        with self.assertRaisesRegex(g.GateError,'R5_INITCALL_INPUT_PATTERN_NOT_EXACTLY_ONCE'):
            g.expected_lto_linker_postimage(ORIGINAL_LDS.replace(b'con_initcall.init',b'con_notcall.init'))
    def test_75_duplicate_input_rule_refused(self):
        data=ORIGINAL_LDS+b'\n    KEEP(*(.con_initcall.init))\\\n'
        with self.assertRaisesRegex(g.GateError,'R5_INITCALL_INPUT_PATTERN_NOT_EXACTLY_ONCE'):
            g.expected_lto_linker_postimage(data)
    def test_76_wrong_blob_refused_without_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/g.LTO_LDS_REL;p.parent.mkdir(parents=True)
            p.write_bytes(ORIGINAL_LDS)
            with self.assertRaisesRegex(g.GateError,'R5_LDS_PINNED_POSITRON_BLOB_MISMATCH'):
                g.apply_lto_linker_fix(tmp)
            self.assertEqual(p.read_bytes(),ORIGINAL_LDS)
    def test_77_valid_pinned_blob_applied_only_to_temp(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/g.LTO_LDS_REL;p.parent.mkdir(parents=True)
            p.write_bytes(ORIGINAL_LDS)
            with mock.patch.object(g,'LTO_LDS_GIT_BLOB_SHA1',g.git_blob_sha1(ORIGINAL_LDS)):
                row=g.apply_lto_linker_fix(tmp)
            self.assertEqual(row['patched_sha256'],g.sha_file(p))
            self.assertFalse(row['kernel_version_identity_modified'])
    def test_78_no_second_patch(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/g.LTO_LDS_REL;p.parent.mkdir(parents=True)
            p.write_bytes(ORIGINAL_LDS)
            with mock.patch.object(g,'LTO_LDS_GIT_BLOB_SHA1',g.git_blob_sha1(ORIGINAL_LDS)):
                g.apply_lto_linker_fix(tmp)
                with self.assertRaisesRegex(g.GateError,'R5_LDS_PINNED_POSITRON_BLOB_MISMATCH'):
                    g.apply_lto_linker_fix(tmp)
    def test_79_genuine_linux_blob_pin_is_40_hex(self):
        self.assertEqual(len(g.LTO_LDS_GIT_BLOB_SHA1),40)
        int(g.LTO_LDS_GIT_BLOB_SHA1,16)

    @unittest.skipUnless(shutil.which('clang') and shutil.which('ld.lld'),'needs clang and lld')
    def test_80_linker_script_catches_lto_unique_initcall_symbols(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp)
            asm='''\n.section .initcall6.init..123_456_test,"a",@progbits\n.balign 8\n.quad 0x1234\n.section .initcall7.init..321_654_test,"a",@progbits\n.balign 8\n.quad 0x5678\n.section .con_initcall.init..312_156_test,"a",@progbits\n.balign 8\n.quad 0x9abc\n'''
            (d/'a.s').write_text(asm)
            c=subprocess.run(['clang','-c',str(d/'a.s'),'-o',str(d/'a.o')],capture_output=True,text=True)
            self.assertEqual(c.returncode,0,c.stderr)
            script='''SECTIONS { . = 0x10000; .init.data : { __initcall6_start = .; KEEP(*(.initcall6.init .initcall6.init..*)) __initcall7_start = .; KEEP(*(.initcall7.init .initcall7.init..*)) __con_initcall_start = .; KEEP(*(.con_initcall.init .con_initcall.init..*)) __con_initcall_end = .; } /DISCARD/ : { *(.note.GNU-stack) } }'''
            (d/'link.lds').write_text(script)
            c=subprocess.run(['ld.lld','--orphan-handling=warn','-T',str(d/'link.lds'),'-o',str(d/'linked'),str(d/'a.o')],capture_output=True,text=True)
            self.assertEqual(c.returncode,0,c.stderr)
            self.assertNotIn('initcall',c.stderr)

class TestPinNmEnvironment(unittest.TestCase):
    def test_81_child_make_receives_pinned_nm_in_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            d=Path(tmp);t=d/'toolchain';t.mkdir();n=t/'llvm-nm';n.write_text('#!/bin/sh\nexit 0\n');n.chmod(0o755)
            argv=['make','NM='+str(n),'-j2','Image']
            m=mock.Mock(returncode=0)
            with mock.patch.object(g.subprocess,'run',return_value=m) as call:
                row=g.invoke_exact_make(argv,d,'Image')
            self.assertEqual(row['exit_code'],0)
            self.assertEqual(call.call_args.kwargs['env']['PATH'].split(os.pathsep)[0],str(t))
            self.assertNotIn('shell',call.call_args.kwargs)
    def test_82_unpinned_nm_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(g.GateError,'PINNED_LLVM_NM_NOT_SPECIFIED'):
                g.invoke_exact_make(['make','Image'],tmp,'Image')
    def test_83_warning_free_required_for_release_gate(self):
        self.assertIn('R5_LTO_LINK_ORPHANS_STILL_PRESENT',
              (ROOT/'Tools/veux_r47_r13_on_r46.py').read_text())

if __name__=='__main__':unittest.main()
