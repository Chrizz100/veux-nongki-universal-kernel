# VEUX R46-R5 – WALT RMNET Built-in LTO-Initcall-Fix (NO FLASH)

Grundlage: R46-R4, fehlgeschlagener GitHub-Run 42414578967, Job 128529787765.

## Ursache

- Neuer `Image`-/`vmlinux`-Link bereits erfolgreich (`make Image`, `dtbs`, `modules` jeweils Exit 0).
- `ld.lld`: 3.624 verwaiste `.initcall*.init..*`-Abschnitte infolge Clang-LTO.
- Die Initcall-Symbole lagen dadurch nicht im von `__initcall6_start` und
  `__initcall7_start` markierten Bereich. R46-R4-Abbruch:
  `R47_INVALID_INITCALL6_ADDRESS_RANGE`.
- 16 Meldungen `/bin/sh: 1: llvm-nm: not found`; R46-R4 hatte die Funktion
  `pinned_llvm_tool_env()`, verwendete sie aber nicht für `subprocess.run`.

## R46-R5 repariert genau diese zwei Punkte

1. Nur im temporären Kernelquellbaum wird der exakt gepinnte Positron-
   `include/asm-generic/vmlinux.lds.h` um wildcard-Abschnittsmuster für die
   LTO-initcall-Suffixe ergänzt. `initcall`-Level und Reihenfolge bleiben erhalten.
   Bei abweichendem Git-Blob SHA-1 **Abbruch statt blindem Patch**.
2. `make` erhält die bereits gepinnte LLVM-Toolchain im `PATH`; kein Austausch
   der Toolchain und kein unerwünschter System-`llvm-nm`.

Zusätzliche Gatter: Echte ARM64-Builds, Symbole in `System.map` und
`linker_warning_free=true` sind zwingend. Falls noch LTO-Orphans oder
`llvm-nm`-Fehler auftreten, wird R46-R5 **nicht als grün** markiert.

## GitHub-Upload

- `VEUX_R46_R5_LTO_INITCALL_RMNET_MAIN.zip` **als ZIP**, unverändert in die Wurzel von `main`.
- `VEUX_R46_R5_LTO_INITCALL_RMNET_NOFLASH.yml` nach `.github/workflows/`.
- In Actions den neuen **R46-R5** Workflow starten.

**Nicht** flashen. Keine Änderungen an Stock-Kernelkennung
`5.4.274-qgki-g82179e362f33`, P13, originalem R46-Quellpaket, BakaSU,
SUSFS oder NoMount. OEM-ABI, DTBO und Geräteboot bleiben ungeprüft.

Prüfsummen werden in `MANIFEST_SHA256.txt` innerhalb MAIN.zip mitgeliefert.
