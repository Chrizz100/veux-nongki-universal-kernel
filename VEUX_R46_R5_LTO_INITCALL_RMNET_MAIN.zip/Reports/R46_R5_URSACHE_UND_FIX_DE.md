# R46-R5: Entscheidung und Scope

Referenz: GitHub Run `42414578967`, Job `128529787765`,
Archiv `VEUX-R47-R13-REAL-WALT-RMNET-BUILTIN-ONLY-EVIDENCE`.

Die alten R13-Kbuild-Hunks (SHS/Offload: `obj-m` nach `obj-y`) bleiben bytegenau.
R46-R4 `make Image`, `dtbs`, `modules`: alle Exit Code 0, trotzdem fehlender
Boot-Initcall-Nachweis durch 3.624 von `ld.lld` nicht eingefangene LTO-Sections.
16 Fehlaufrufe `llvm-nm` bleiben im R46-R4-Log sichtbar.

Quelle für Linkerskript-Pin:
`dereference23/kernel_xiaomi_sm6375` Commit
`b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`, Datei
`include/asm-generic/vmlinux.lds.h`, Git Blob
`c64ea2e6db5a9e0614163249e81ffe96fff70f16`.

Patch: Nur 4 `KEEP`-Muster um `.init..*`-Suffixe erweitert
(early, Normal-/Sync-Level, Konsole); kein Level verändert.
Echter Test mit clang/ld.lld prüft, dass ein LTO-artiger Section-Name
im markierten Bereich landet, ohne Waisen-Warnung. Das ersetzt keinen
vollständigen echten ARM64-GitHub-Build.

`llvm-nm`-Pfad: zuvor definierte, aber nicht an make übergebene
`pinned_llvm_tool_env()` wird nun als `env=` an `subprocess.run()` übergeben.
Zweistufiger Fail-Closed-Prozess und die gesamte alte R46-Baseline bleiben.

**NO FLASH:** Weder Stock-Vendor-ABI noch Geräteboot bestätigt.
