VEUX R30 – Stock 5.4.274 versus R13 CASS – NO FLASH

PINNED ORIGINALS
Stock Kernel: 5.4.274-qgki-g82179e362f33, SHA-256 kernel image 6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b
Stock config (embedded original): 334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868, 5315 config keys
R13 actual config: 405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4, 4664 config keys
Config key differences: 934 (einschliesslich nur in einer Konfiguration vorhandener Eintraege).
OEM imports: 4501 distinct (cohort,symbol) signatures / 14648 weighted import occurrences, QGKI and GKI separate.

CANDIDATES – INPUT CONFIGS, NOT YET KCONFIG RESOLVED
A_STOCK_IPC: CONFIG_IPC_LOGGING=y.
B_STOCK_IPC_TRACE: CONFIG_IPC_LOGGING=y, CONFIG_FTRACE=y, CONFIG_KPROBES=y, CONFIG_STACKTRACE=y.
Only four reviewed R13 flags may change explicitly. Kconfig dependencies can change only if stock=y. The exact effective config must be validated in GitHub before success.

WARUM NICHT ALLE 934 UNTERSCHIEDE UEBERNEHMEN?
CASS=y and WALT not active are deliberate to protect the proven R13 integration. Root, SUSFS, NoMount and builtin RMNET remain unchanged. Wholesale stock .config substitution risks silently dropping built-in code or breaking ABI. A stock config does not prove exact vendor CRC compatibility.

TO RUN – TWO FILES TOTAL
1. Upload VEUX_R30_STOCK_CASS_ABI_MAIN.zip unchanged into repo ROOT.
2. Upload VEUX_R30_STOCK_CASS_ABI_NOFLASH.yml unchanged to .github/workflows/.
3. GitHub Actions: VEUX R30 Stock-CASS Config and OEM ABI - NO FLASH -> Run workflow auf main.
4. Read R30 report and inspect Module.symvers and Kconfig decisions. All outputs are NO FLASH.

Nur konfigurative und ABI-Forschungsdaten sind im MAIN-ZIP enthalten. No boot.img, device dumps, IMEI, module binaries or private logs. No build has been performed for R30 at creation time. Neither variant is declared vendor-module-loadable or safe to flash.

R30 erstellt und veroeffentlicht weder ein flashbares R30-ZIP noch boot.img.
Die Varianten wurden offline nur geplant, nicht kompiliert. Ein GitHub-Actions-GREEN ist noch nicht nachgewiesen.
