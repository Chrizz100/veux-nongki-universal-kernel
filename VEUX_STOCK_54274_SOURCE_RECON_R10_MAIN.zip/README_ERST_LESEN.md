# VEUX 5.4.274 – R10 gepinnte WALT-Quellfamilienprüfung (NOFLASH)

Zweck: Alle Quellabhängigkeiten der öffentlich gefundenen WALT-Implementierung aus Linux 5.4.61 gegen den 5.4.268-Spender und die originalen OEM-Stock-Header prüfen. Tatsächliches vollständiges WALT-Source-Paket wird auf GitHub in einem text-/source-only Artefakt bereitgestellt.

**Dies ist KEIN funktionsfähiger WALT-Port.** Stock `task_struct.wts` enthält zusätzliche Felder (`iowaited`, `CONFIG_RTMM`-bedingt `proc_load`), und das Pair verwendet `bool low_latency` statt Stock-`u8`. `struct rq.wrq` fehlt im Donor. Ein blindes Kopieren der alten Quellen wäre ein Boot- und ABI-Risiko.

Der aktuelle R6-ABI-Vergleich bleibt Maßstab. R9 meldete 37 QGKI-Moduldateien in der Ladeliste, davon 0 vollständig CRC-kompatibel. R10 erzeugt keinen Kernel, keine Bootdatei, keine AK3-Datei, ändert keine CRCs und hat keine Flashfreigabe.

Quellen:
- https://github.com/shandongtlb/kernel_xiaomi_sm8350_M11 @ `01cb3a8824b7b4caf3e3540274e71abba5ade538`
- https://github.com/dereference23/kernel_xiaomi_sm6375 @ `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`
- R1 user stock reference validated SHA.

Nächster Schritt nach bestandenem R10 auf GitHub: zusammengehörigen Scheduler-/WALT-Port (Quellcodeänderungen, keine CRC-Fälschung) entwickeln und isoliert bis `Image dtbs` mit Stock-config und Clang 11 prüfen, danach QGKI-ABI-Deltas auswerten.
