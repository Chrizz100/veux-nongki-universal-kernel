"""Read-only R10 source-lineage and safety regression tests."""
import io
import json
import tarfile
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import r10_walt_source as m

ROOT=Path(__file__).resolve().parent.parent

class R10Tests(unittest.TestCase):
    def test_01_reference_input_authentic(self):
        self.assertEqual(m.verify_reference(ROOT)['schema'],'R10_STOCK_REFERENCE_PINNED')
    def test_02_16_genuine_stock_headers(self):
        self.assertEqual(len(m.STOCK_HEADERS),16)
        self.assertTrue(all((ROOT/'reference'/p).is_file() for p in m.STOCK_HEADERS))
    def test_03_stock_walt_and_rtmm_true(self):
        s=(ROOT/'reference/STOCK.config').read_text()
        self.assertEqual(m.config_value(s,'SCHED_WALT'),'y')
        self.assertEqual(m.config_value(s,'RTMM'),'y')
    def test_04_candidate_walt_absent(self):
        s=(ROOT/'reference/R6_CANDIDATE.config').read_text()
        self.assertEqual(m.config_value(s,'SCHED_WALT'),'(absent)')
    def test_05_original_stock_walt_struct(self):
        f=m.walt_task_fields((ROOT/'reference/include/linux/sched.h').read_text())
        self.assertIn('u8 low_latency;',f)
        self.assertIn('bool iowaited;',f)
        self.assertIn('u64 proc_load;',f)
    def test_06_stock_structure_has_iowaited(self):
        s=(ROOT/'reference/include/linux/sched.h').read_text()
        self.assertIn('CONFIG_RTMM',m.body_of_struct(s,'walt_task_struct'))
    def test_07_qgki_37_modules_in_loader(self):
        import csv
        with (ROOT/'reference/R9_QGKI_MODULE_PRIORITAET.csv').open(newline='') as f:r=list(csv.DictReader(f))
        self.assertEqual(len(r),37)
        self.assertTrue(all(x['present_in_load_file']=='True' for x in r))
    def test_08_layout_only_exactly_one(self):
        import csv
        with (ROOT/'reference/R9_QGKI_MODULE_PRIORITAET.csv').open(newline='') as f:r=list(csv.DictReader(f))
        self.assertEqual([x['module'] for x in r if x['module_layout_only_blocker']=='True'],['q6_pdr_dlkm.ko'])
    def test_09_walt_pair_source_commit_pinned(self):
        self.assertEqual(m.PAIR_COMMIT,'01cb3a8824b7b4caf3e3540274e71abba5ade538')
        self.assertEqual(len([x for x in m.PAIR_FILES if x.startswith('techpack/sched/')]),12)
    def test_10_weak_versus_real_are_distinct(self):
        self.assertNotEqual(m.PAIR_FILES['techpack/sched/walt.c'],m.PAIR_FILES['kernel/sched/walt.c'])
    def test_11_donor_5_4_268_pinned(self):
        self.assertEqual(m.DONOR_COMMIT,'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632')
    def test_12_low_latency_parser_negative(self):
        with self.assertRaisesRegex(RuntimeError,'STRUCT_NOT_FOUND'):
            m.walt_task_fields('struct irrelevant { int value; };')
    def test_13_braces_parser_negative(self):
        with self.assertRaisesRegex(RuntimeError,'BRACES_UNBALANCED'):
            m.body_of_struct('struct walt_task_struct {\n int x;','walt_task_struct')
    def test_14_config_flag_negative(self):
        self.assertEqual(m.config_value('# CONFIG_SCHED_WALT is not set','SCHED_WALT'),'n')
    def test_15_corrupt_reference_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);p=base/'reference';p.mkdir()
            (base/'REFERENCE_SHA256.json').write_bytes((ROOT/'REFERENCE_SHA256.json').read_bytes())
            (p/'STOCK.config').write_text('CONFIG_SCHED_WALT=n')
            with self.assertRaisesRegex(RuntimeError,'MISSING_FILE|SHA256_MISMATCH'):
                m.verify_reference(base)
    def test_16_invalid_repo_commit_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            with self.assertRaisesRegex(RuntimeError,'GIT_COMMAND_FAILED'):
                m.verify_repo(p,m.PAIR_COMMIT,{})
    def test_17_source_paths_no_traversal(self):
        self.assertTrue(all(not p.startswith('/') and '..' not in Path(p).parts for p in m.PAIR_FILES))
        self.assertTrue(all(not p.startswith('/') and '..' not in Path(p).parts for p in m.DONOR_FILES))
    def test_18_no_boot_or_production_execution(self):
        code=(ROOT/'tools/r10_walt_source.py').read_text()
        self.assertIn("'flash_allowed':False",code)
        self.assertIn("'kernel_build_performed':False",code)
        self.assertIn("'source_patch_approved':False",code)
        self.assertNotIn('fastboot flash',code)
        self.assertNotIn('mkbootimg ',code)
    def test_19_tar_source_deterministic_and_contained(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);src=d/'src';src.mkdir()
            for f in m.PAIR_FILES:
                p=src/f;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('test\n')
            prov={k:{'sha256':m.sha(b'test\n'),'bytes':5,'git_blob':'x'*40} for k in m.PAIR_FILES}
            a=d/'1.tar.gz';b=d/'2.tar.gz';m.make_source_tar(src,a,prov);m.make_source_tar(src,b,prov)
            self.assertEqual(a.read_bytes(),b.read_bytes())
            with tarfile.open(a,'r:gz') as z:
                names=z.getnames();self.assertEqual(len(names),len(m.PAIR_FILES)+2)
                self.assertTrue(all(not x.startswith('/') and '..' not in Path(x).parts for x in names))
    def test_20_manifest_sha_refuses_tamper(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); (d/'x').write_text('original')
            with self.assertRaisesRegex(RuntimeError,'SHA256_MISMATCH'):
                m.checked_file(d,'x','0'*64)
    def test_21_symlink_refused(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); (d/'actual').write_text('hi');(d/'link').symlink_to(d/'actual')
            with self.assertRaisesRegex(RuntimeError,'UNSAFE_OR_MISSING_FILE'):
                m.checked_file(d,'link')
    def test_22_no_compiler_or_spoofed_crc_input(self):
        # The output is a source audit, not a way to alter a modules' CRCs.
        self.assertFalse(any('Module.symvers' in x for x in m.PAIR_FILES))
        self.assertEqual(len(m.PAIR_FILES),19)
        self.assertEqual(len(m.DONOR_FILES),5)

if __name__=='__main__':unittest.main()
