#!/usr/bin/env python3
"""Pinned Linux 5.4.61 WALT source-family audit against immutable VEUX stock headers.

READ ONLY: no kernel sources, configs, CRCs, or upstream repositories are altered.
"""
import argparse
import csv
import difflib
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path

PAIR_REPO = 'https://github.com/shandongtlb/kernel_xiaomi_sm8350_M11.git'
PAIR_COMMIT = '01cb3a8824b7b4caf3e3540274e71abba5ade538'
DONOR_REPO = 'https://github.com/dereference23/kernel_xiaomi_sm6375.git'
DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'

# Git object identifiers verified from pinned GitHub tree and file fetches.
PAIR_FILES = {
 'techpack/sched/Makefile': '049e350f8758b7feeb32be7518f5d1a741459289',
 'techpack/sched/boost.c': 'a660564939ec6ba26d956ad098dfd2a5fbc28503',
 'techpack/sched/core_ctl.c': '2d291db17d9f8c3b41e5ed714aba983da77e07c0',
 'techpack/sched/cpu-boost.c': 'a47bf960ff30a92a1d7cc88043f9e218ef14fa21',
 'techpack/sched/qc_vas.c': 'b11f18ef4dbb319c52c3a648c4fe0e233b7dfd6b',
 'techpack/sched/sched.conf': '48687a6525fb86e42280b1ba38fcfda6792d34dd',
 'techpack/sched/sched_avg.c': '8a8da5e4d2df62eccde47d817eead88798c9b0a7',
 'techpack/sched/schedconf.h': '948e1da830bbcd340e21fdb37df92fad238d0fe6',
 'techpack/sched/trace.c': '0ef92b88f22f60a548c51f668fc9989d3ec0d750',
 'techpack/sched/trace.h': 'a757c30a44aa94d628d12aace9e6755e1f6b4615',
 'techpack/sched/walt.c': '3e2ad36286305d16d34a0c09fe83492ea5089267',
 'techpack/sched/walt.h': 'a7dbe8ae2a2961d86333a53af1afc790fc9ad9d6',
 'kernel/sched/walt.c': '1721a470c2f1de47826a95f735265e0286081a0c',
 'kernel/sched/walt.h': 'e20992b705323795191b0def47766e342abb746a',
 'kernel/sched/sched.h': '79b175a65e0ebda59a5ccc13691b454b347e7701',
 'kernel/sched/Makefile': '1175ed6ccf4df8394c3ec9328bb868f0ee07d8a8',
 'include/linux/sched.h': '1b13e5d272bc3da9d8d8bf9f415166864e5b90af',
 'include/linux/cpumask.h': '4e226e8d737b72f35126341d3c59c0b0af282145',
 'init/Kconfig': 'aad626bac1c187c80e693b88ba9b58cf5c35a490',
}
DONOR_FILES = {
 'kernel/sched/sched.h': '15e50442697e1e0e655cb970130d9c14af56b049',
 'kernel/sched/Makefile': '21fb5a5662b51a46ce08f91b586a1d44810d0012',
 'include/linux/sched.h': 'c29af309e5bd38653b6d3c872d41723ba895646e',
 'include/linux/cpumask.h': 'a4bf0248afedbeb82ddcfe437ff74b1bf1b34517',
 'init/Kconfig': 'd3a651f1b789263780d40966d776dd912e03b06a',
}
STOCK_HEADERS = (
 'include/linux/sched.h', 'include/linux/sched/core_ctl.h',
 'include/linux/sched/sysctl.h', 'include/linux/sched/wake_q.h',
 'include/linux/cpumask.h', 'include/linux/arch_topology.h',
 'include/linux/module.h', 'include/linux/sched/signal.h',
 'include/linux/sched/topology.h', 'include/linux/sched/clock.h',
 'include/linux/sched/stat.h', 'include/linux/sched/rt.h',
 'include/linux/sched/task.h', 'include/linux/sched/isolation.h',
 'include/linux/sched/debug.h', 'include/trace/events/sched.h'
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def checked_file(root, rel, digest=None):
    p = root / rel
    if p.is_symlink() or not p.is_file():
        raise RuntimeError('R10_UNSAFE_OR_MISSING_FILE:' + str(p))
    b = p.read_bytes()
    if digest and sha(b) != digest:
        raise RuntimeError('R10_SHA256_MISMATCH:' + rel)
    return b


def config_value(s, option):
    if re.search(r'^CONFIG_' + re.escape(option) + r'=(.*)$', s, re.M):
        return re.search(r'^CONFIG_' + re.escape(option) + r'=(.*)$', s, re.M).group(1)
    if re.search(r'^# CONFIG_' + re.escape(option) + r' is not set$', s, re.M):
        return 'n'
    return '(absent)'


def body_of_struct(s, name):
    # Extract just the declaration body. This is not a C parser; a diagnostic only.
    m = re.search(r'\bstruct\s+' + re.escape(name) + r'\s*\{', s)
    if not m:
        raise RuntimeError('R10_REQUIRED_STRUCT_NOT_FOUND:' + name)
    depth = 1
    i = m.end()
    start = i
    while i < len(s) and depth:
        if s[i] == '{':
            depth += 1
        elif s[i] == '}':
            depth -= 1
        i += 1
    if depth:
        raise RuntimeError('R10_STRUCT_BRACES_UNBALANCED:' + name)
    return s[start:i-1]


def walt_task_fields(text):
    s = body_of_struct(text, 'walt_task_struct')
    # Ignore comments while preserving preprocessor declarations.
    s = re.sub(r'/\*.*?\*/', ' ', s, flags=re.S)
    s = re.sub(r'//[^\n]*', ' ', s)
    lines = [' '.join(x.strip().split()) for x in s.splitlines()]
    return [x for x in lines if x]


def git_cmd(repo, *args):
    p = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True, check=False, timeout=30)
    if p.returncode:
        raise RuntimeError('R10_GIT_COMMAND_FAILED:' + ' '.join(args) + ':' + p.stderr[:300])
    return p.stdout.strip()


def verify_repo(repo, expected_sha, paths):
    if git_cmd(repo, 'rev-parse', 'HEAD') != expected_sha:
        raise RuntimeError('R10_GIT_COMMIT_DRIFT:' + str(repo))
    if git_cmd(repo, 'status', '--porcelain'):
        raise RuntimeError('R10_REPOSITORY_DIRTY:' + str(repo))
    result = {}
    for path, exp_git_blob in sorted(paths.items()):
        if '..' in Path(path).parts or path.startswith('/'):
            raise RuntimeError('R10_INVALID_SOURCE_PATH:' + path)
        data = checked_file(repo, path)
        actual = git_cmd(repo, 'hash-object', '--', path)
        if actual != exp_git_blob:
            raise RuntimeError('R10_GIT_BLOB_MISMATCH:' + path + ':' + actual)
        result[path] = {'git_blob': actual, 'sha256': sha(data), 'bytes': len(data)}
    return result


def verify_reference(main):
    mf = json.loads(checked_file(main, 'REFERENCE_SHA256.json'))
    if mf['schema'] != 'R10_STOCK_REFERENCE_PINNED' or mf['flash_allowed'] is not False:
        raise RuntimeError('R10_BAD_REFERENCE_SCHEMA')
    files = mf['files']
    if set(files) != set(['reference/' + h for h in STOCK_HEADERS] + [
        'reference/STOCK.config','reference/R6_CANDIDATE.config','reference/R9_QGKI_MODULE_PRIORITAET.csv',
        'reference/R9_QGKI_SYMBOLE_GRUPPIERT.csv','reference/STOCK_ORIGIN.json']):
        raise RuntimeError('R10_REFERENCE_SET_DRIFT')
    for f, h in files.items():
        checked_file(main, f, h)
    so = json.loads(checked_file(main, 'reference/STOCK_ORIGIN.json'))
    if so['stock_release'] != '5.4.274-qgki-g82179e362f33' or so['embedded_stock_header_count'] != 7717:
        raise RuntimeError('R10_STOCK_ORIGIN_DRIFT')
    return mf


def ensure(condition, message):
    if not condition:
        raise RuntimeError('R10_SOURCE_ANCHOR_FAILURE:' + message)


def lint_sources(main, donor, pair):
    stock_sched = checked_file(main, 'reference/include/linux/sched.h').decode()
    stock_cfg = checked_file(main, 'reference/STOCK.config').decode()
    r6_cfg = checked_file(main, 'reference/R6_CANDIDATE.config').decode()
    pair_sched = checked_file(pair, 'include/linux/sched.h').decode()
    donor_sched = checked_file(donor, 'include/linux/sched.h').decode()
    pair_rq = checked_file(pair, 'kernel/sched/sched.h').decode()
    donor_rq = checked_file(donor, 'kernel/sched/sched.h').decode()
    pair_kcfg = checked_file(pair, 'init/Kconfig').decode()
    donor_kcfg = checked_file(donor, 'init/Kconfig').decode()
    walt_impl = checked_file(pair, 'techpack/sched/walt.c').decode()
    wrapper = checked_file(pair, 'kernel/sched/walt.c').decode()
    mk = checked_file(pair, 'techpack/sched/Makefile').decode()
    donor_mk = checked_file(donor, 'kernel/sched/Makefile').decode()
    pair_mk = checked_file(pair, 'kernel/sched/Makefile').decode()

    ensure(config_value(stock_cfg, 'SCHED_WALT') == 'y', 'STOCK_WALT_MUST_BE_ON')
    ensure(config_value(r6_cfg, 'SCHED_WALT') == '(absent)', 'R6_NOT_WALT_ENABLED')
    ensure(config_value(stock_cfg, 'RTMM') == 'y', 'STOCK_RTMM_EXPECTED')
    ensure('struct walt_task_struct' in stock_sched and 'struct walt_task_struct' in pair_sched, 'TASK_STRUCT')
    ensure('struct walt_task_struct' not in donor_sched, 'DONOR_HAS_WALT_UNEXPECTEDLY')
    ensure(re.search(r'\bstruct walt_task_struct\s+wts\s*;', stock_sched) is not None, 'STOCK_TASK_WTS')
    ensure(re.search(r'\bstruct walt_task_struct\s+wts\s*;', pair_sched) is not None, 'PAIR_TASK_WTS')
    ensure('struct walt_rq' in pair_rq and re.search(r'\bstruct walt_rq\s+wrq\s*;', pair_rq), 'PAIR_RQ_WALT')
    ensure('struct walt_rq' not in donor_rq and 'wrq;' not in donor_rq, 'DONOR_RQ_WALT_PRESENT')
    ensure('config SCHED_WALT' in pair_kcfg and 'config SCHED_WALT' not in donor_kcfg, 'KCONFIG')
    ensure('obj-$(CONFIG_SCHED_WALT) += walt.o' in pair_mk, 'PAIR_WALT_SHIM_BUILD')
    ensure('CONFIG_SCHED_WALT' not in donor_mk, 'DONOR_WALT_BUILD')
    ensure('obj-$(CONFIG_SCHED_WALT) += walt.o boost.o sched_avg.o qc_vas.o core_ctl.o trace.o' in mk, 'REAL_WALT_TECHPACK_BUILD')
    ensure('void walt_update_task_ravg' in walt_impl, 'REAL_WALT_FUNCTION')
    ensure('void __weak walt_update_task_ravg' in wrapper, 'WEAK_WRAPPER_MUST_BE_DISTINCT')
    ensure(len(walt_impl) > 80000 and len(wrapper) < 10000, 'REAL_WALT_VS_WEAK_STUB')

    stock_fields = walt_task_fields(stock_sched)
    pair_fields = walt_task_fields(pair_sched)
    stock_field_text = '\n'.join(stock_fields)
    pair_field_text = '\n'.join(pair_fields)
    ensure(re.search(r'\bu8\s+low_latency\s*;',stock_field_text) is not None, 'STOCK_U8_LOW_LATENCY')
    ensure(re.search(r'\bbool\s+low_latency\s*;',pair_field_text) is not None, 'PAIR_BOOL_LOW_LATENCY')
    ensure('iowaited;' in stock_field_text and 'iowaited;' not in pair_field_text, 'STOCK_IOWAITED')
    ensure('proc_load;' in stock_field_text and 'proc_load;' not in pair_field_text, 'STOCK_RTMM_PROC_LOAD')
    ensure(stock_fields != pair_fields, 'STOCK_PAIR_TASK_WALT_NOT_IDENTICAL')
    return {'stock':stock_fields, 'pair':pair_fields, 'stock_config':stock_cfg,
            'r6_config':r6_cfg, 'stock_task_file':stock_sched,'pair_task_file':pair_sched,
            'donor_task_file':donor_sched,
            'pair_sched_file':pair_rq,'donor_sched_file':donor_rq}


def csv_export(path, fields, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        wr=csv.DictWriter(f, fieldnames=fields)
        wr.writeheader();wr.writerows(rows)


def make_source_tar(pair, out, prov):
    # Deterministic source-only bundle for later review; no compiled outputs.
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for p in sorted(PAIR_FILES):
            b=checked_file(pair, p)
            info=tarfile.TarInfo('PAIR_SOURCE/'+p)
            info.size=len(b);info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644
            tar.addfile(info,io.BytesIO(b))
        evidence=json.dumps({'origin':PAIR_REPO,'commit':PAIR_COMMIT,'files':prov},sort_keys=True,indent=2).encode()
        ti=tarfile.TarInfo('SOURCE_PROVENANCE.json');ti.size=len(evidence);ti.mtime=0;ti.mode=0o644
        tar.addfile(ti,io.BytesIO(evidence))
        readme=("Verified Qualcomm/Xiaomi WALT source snapshot, original files only.\n"
                "Reference for a FUTURE audited port. NOT patched into VEUX, NOT flashable.\n"
                f"Source: {PAIR_REPO}\nCommit: {PAIR_COMMIT}\n"
                "Original upstream licenses and copyright headers retained; refer to upstream COPYING.\n").encode()
        ti=tarfile.TarInfo('README_READ_ONLY.txt');ti.size=len(readme);ti.mtime=0;ti.mode=0o644
        tar.addfile(ti,io.BytesIO(readme))
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('wb') as f:
        with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0,compresslevel=7) as g:
            g.write(raw.getvalue())


def audit(main, donor, pair, out):
    verify_reference(main)
    pairprov=verify_repo(pair, PAIR_COMMIT, PAIR_FILES)
    donorprov=verify_repo(donor, DONOR_COMMIT, DONOR_FILES)
    data=lint_sources(main,donor,pair)
    out.mkdir(parents=True,exist_ok=True)
    st=data['stock'];pa=data['pair']
    diff='\n'.join(difflib.unified_diff(pa,st,fromfile='PAIR_5.4.61_walt_task_struct',
        tofile='USER_STOCK_5.4.274_walt_task_struct',lineterm=''))+'\n'
    (out/'R10_WALT_TASK_STRUCTURE_DIFF.patch.txt').write_text(diff,encoding='utf-8')
    with (main/'reference/R9_QGKI_SYMBOLE_GRUPPIERT.csv').open(newline='',encoding='utf-8') as f:
        sym=list(csv.DictReader(f))
    with (main/'reference/R9_QGKI_MODULE_PRIORITAET.csv').open(newline='',encoding='utf-8') as f:
        mods=list(csv.DictReader(f))
    ensure(len(mods)==37 and all(x['present_in_load_file']=='True' for x in mods),'ALL_37_QGKI_IN_LOADER')
    csv_export(out/'R10_QGKI_GEMEINSAME_BLOCKER.csv',
        ['symbol','modules_with_blocker','import_occurrences','type','r6_crc','r8_crc','crc_changed_r6_to_r8'],
        [{k:x[k] for k in ['symbol','modules_with_blocker','import_occurrences','type','r6_crc','r8_crc','crc_changed_r6_to_r8']}
            for x in sym[:35]])
    rows=[]
    for p,x in sorted(pairprov.items()):
        rows.append({'origin':'PAIR_5.4.61','path':p,'git_blob':x['git_blob'],'sha256':x['sha256'],'bytes':x['bytes']})
    for p,x in sorted(donorprov.items()):
        rows.append({'origin':'DONOR_5.4.268','path':p,'git_blob':x['git_blob'],'sha256':x['sha256'],'bytes':x['bytes']})
    csv_export(out/'R10_QUELL_HASH_INDEX.csv',['origin','path','git_blob','sha256','bytes'],rows)
    changes=[
     {'group':'G1_WALT_SUBSYSTEM','detail':'Pinned 12 files under techpack/sched plus scheduler weak shims; no copying alone','risk':'CRITICAL'},
     {'group':'G2_SCHED_TASK_STRUCT','detail':'Stock task_struct.wts; stock u8 low_latency, iowaited and RTMM proc_load are different from pair','risk':'CRITICAL'},
     {'group':'G3_RUNQUEUE','detail':'struct rq.wrq and walt_rq require scheduler core, scheduler trace/hook integration','risk':'CRITICAL'},
     {'group':'G4_CONFIG_BUILD','detail':'SCHED_WALT in init/Kconfig, kernel/sched and techpack Makefiles, root inclusion and config dependency validation','risk':'CRITICAL'},
     {'group':'G5_CORE_CTL','detail':'Match stock core_ctl ABI and WALT CPU isolation; avoid weak-stub success claims','risk':'HIGH'},
     {'group':'G6_RTMM','detail':'Stock CONFIG_RTMM=y; verify proc_load and associated task structures against OEM implementation','risk':'HIGH'},
     {'group':'G7_OEM_ABI','detail':'Post-port actual QGKI .ko module CRC comparisons, no synthetic CRC override','risk':'CRITICAL'}]
    config_fields=['SCHED_WALT','RTMM','SMP','QGKI','MODVERSIONS','CFI_CLANG','UCLAMP_TASK','CPU_BOOST','SCHED_DEBUG']
    cfg=[{'option':'CONFIG_'+o,'stock':config_value(data['stock_config'],o),'r6_candidate':config_value(data['r6_config'],o)} for o in config_fields]
    csv_export(out/'R10_WALT_CONFIG_RELEVANZ.csv',['option','stock','r6_candidate'],cfg)
    report={
       'schema':'VEUX_R10_PINNED_WALT_SOURCE_FAMILY_AUDIT',
       'stock_kernel':'5.4.274-qgki-g82179e362f33',
       'donor_version':'5.4.268', 'paired_source_version':'5.4.61',
       'pair_source':PAIR_REPO, 'pair_commit':PAIR_COMMIT,
       'donor_source':DONOR_REPO,'donor_commit':DONOR_COMMIT,
       'stock_sched_walt_enabled':True,
       'r6_donor_sched_walt_available':False,
       'pair_has_real_walt_implementation':True,
       'pair_kernel_sched_walt_c_is_weak_compatibility_stubs':True,
       'stock_walt_task_struct_matches_pair':False,
       'stock_walt_low_latency':'u8','pair_walt_low_latency':'bool',
       'stock_extra_task_fields':['iowaited','proc_load (CONFIG_RTMM)'],
       'stock_config_rtmm':'y',
       'donor_task_struct_wts':False, 'pair_task_struct_wts':True,
       'donor_rq_wrq':False,'pair_rq_wrq':True,
       'pair_techpack_files':len([x for x in PAIR_FILES if x.startswith('techpack/sched/')]),
       'verified_upstream_files':len(PAIR_FILES)+len(DONOR_FILES),
       'qgki_modules_in_loader':37,
       'qgki_current_full_compatible_modules':0,
       'immediate_source_port_build_approved':False,
       'unverified_stock_vs_pair_scheduler_rq_struct':True,
       'runtime_compatibility_verified':False,
       'vendor_abi_verified':False,
       'flash_allowed':False,
       'source_patch_approved':False,
       'kernel_build_performed':False,
       'port_work_items':changes,
       'walt_config':cfg,
    }
    (out/'R10_WALT_QUELLFAMILIE.json').write_text(json.dumps(report,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    make_source_tar(pair,out/'R10_PINNED_WALT_SOURCES.tar.gz',pairprov)
    md=f"""# VEUX R10 – WALT-/Scheduler-Quellport: geprüfte Ausgangslage\n\n""" \
        +f"Stand: gepinnte Linux-5.4.61-Quelle `{PAIR_COMMIT}` gegen R6-Donor `{DONOR_COMMIT}` und originale Stock-Header (5.4.274).\n\n" \
        +"## Gesicherte Befunde\n\n" \
        +"- Echte WALT-Implementierung: `techpack/sched/walt.c` (nicht mit `kernel/sched/walt.c` verwechseln: letzteres enthält schwache Ersatzfunktionen).\n" \
        +"- Stock- und WALT-Pair-Quellbaum besitzen `task_struct.wts`. Im 5.4.268-Donor fehlt es.\n" \
        +"- Der WALT-Pair-Quellbaum besitzt `rq.wrq` und `struct walt_rq`; beides fehlt im Donor. Die originale Stock-interne `rq`-Struktur liegt nicht in den eingebetteten kheaders.\n" \
        +"- Die Stock-`walt_task_struct` unterscheidet sich vom Pair-Stand: Stock `u8 low_latency`, Pair `bool low_latency`; Stock zusätzliche Felder `iowaited` und optional `proc_load` mit `CONFIG_RTMM=y`.\n" \
        +"- Stock-Kconfig: `CONFIG_SCHED_WALT=y`, `CONFIG_RTMM=y`. R6-Kandidat besitzt diese Optionen nicht.\n" \
        +"- Es gibt derzeit 0 vollständig CRC-kompatible QGKI-Moduldateien (37 in gesicherter Ladeliste); WALT ist allein kein ABI-Fix.\n\n" \
        +"## Geprüfte Quellgruppen und nächste Portreihenfolge\n\n" \
        +"1. WALT-Implementierung und schwache Stub-Aufrufstellen auseinanderhalten.\n" \
        +"2. Originales Stock-Tasklayout inklusive RTMM-Feldern erhalten; nicht blind die ältere `sched.h` kopieren.\n" \
        +"3. Scheduler-Runqueue-/Cgroup-/Core-Control-Hooks mit dazugehörigen Quellpatches zuordnen.\n" \
        +"4. Komplette Kconfig-/Makefile-/`techpack`-Einbindung isoliert umsetzen.\n" \
        +"5. Erst dann einen isolierten Clang-11-Kernelbuild starten, ohne neue Bootdateien zu veröffentlichen.\n" \
        +"6. Danach QGKI-Modul-CRC-Deltas gegen R6 messen und Quellport nur bei erklärbarer Verbesserung beibehalten.\n\n" \
        +"## Artefakte\n\n" \
        +"`R10_PINNED_WALT_SOURCES.tar.gz`: 19 source files mit identifizierten Git-Blob-SHAs; **nur zur Prüfung, kein integrierter Kernel**.\n" \
        +"`R10_WALT_TASK_STRUCTURE_DIFF.patch.txt`: Vergleich der WALT-Taskstrukturen, **kein automatisch anwendbarer Patch**.\n" \
        +"`R10_QUELL_HASH_INDEX.csv`: Original-Git-Blob-IDs und SHA-256 der geprüften Dateien.\n\n" \
        +"## Sicherheitssperren\n\n" \
        +"NOFLASH. Kein Kernelbuild in R10, keine CRC-Änderung, kein automatisch eingespielter Quellpatch, keine Laufzeit-/OEM-ABI-Freigabe.\n"
    (out/'R10_WALT_PORTPLAN_DE.md').write_text(md,encoding='utf-8')
    gate={'schema':'R10_NOFLASH','flash_allowed':False,'build_approved':False,'kernel_build_performed':False,'vendor_abi_green':False,'runtime_verified':False,'production_patch_approved':False,'source_inputs_authenticated':True}
    (out/'R10_NOFLASH_GATE.json').write_text(json.dumps(gate,indent=2)+'\n')
    files=sorted(p for p in out.iterdir() if p.is_file())
    (out/'R10_SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in files))
    print(json.dumps({'status':'READ_ONLY_WALT_PORT_SOURCE_AUDIT_PASS','walt_source_files':report['pair_techpack_files'],'git_files_verified':report['verified_upstream_files'],'stock_pair_struct_equal':False,'qgki_abi_green':False,'flash_allowed':False}))
    return report


def cli():
    ap=argparse.ArgumentParser()
    ap.add_argument('--main',type=Path,required=True)
    ap.add_argument('--donor',type=Path,required=True)
    ap.add_argument('--pair',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    a=ap.parse_args()
    audit(a.main,a.donor,a.pair,a.out)

if __name__=='__main__':
    cli()
