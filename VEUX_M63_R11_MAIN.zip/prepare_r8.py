"""Reconstruct the linked source tree from the exact GitHub R7 artifact."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
from tempfile import TemporaryDirectory
import zipfile

import prepare_r7
from tools.treehash import tree

HERE = Path(__file__).resolve().parent


def prepare(archive, destination, reference, previous=None):
    manifest = json.loads((HERE / "r8-source.json").read_text())
    prepare_r7.stock(reference)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise ValueError(f"Destination already exists: {destination}")
    patch = HERE / "veux-r8.patch"
    prepare_r7.verify(patch, manifest["patch_sha256"])
    with TemporaryDirectory(dir=destination.parent) as directory:
        stage = Path(directory)
        src = stage / "src"
        if previous:
            prepare_r7.prepare(archive, src, previous == "comparison")
        else:
            prepare_r7.verify(archive, manifest["archive_sha256"])
            with zipfile.ZipFile(archive) as zipped:
                if zipped.read("kernel.config") != (HERE / "kernel.config").read_bytes():
                    raise ValueError("R7 configuration mismatch")
                with zipped.open("M63-R7-kernel-source.tar.gz") as stream:
                    tar = stage / "source.tar.gz"
                    with tar.open("wb") as file:
                        shutil.copyfileobj(stream, file)
            prepare_r7.verify(tar, manifest["tar_sha256"])
            src.mkdir()
            with tarfile.open(tar) as kernel:
                kernel.extractall(src, filter="tar")
            tar.unlink()
        for side, tree_name in (("before", "basis_tree"), ("after", "corrected_tree")):
            if side == "after":
                subprocess.run(["git", "apply", "--check", str(patch)], cwd=src, check=True)
                subprocess.run(["git", "apply", str(patch)], cwd=src, check=True)
            for name, hashes in manifest["files"].items():
                prepare_r7.verify(src / name, hashes[side])
            identity = tree(src).hex()
            if identity != manifest[tree_name]:
                raise ValueError(f"Unexpected {side} source tree {identity}")
            print(f"{side} {identity}", flush=True)
        src.rename(destination)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("stock_boot", type=Path)
    parser.add_argument("--from-r6", choices=["archive", "comparison"])
    args = parser.parse_args()
    prepare(args.archive.resolve(), args.destination.resolve(), args.stock_boot.resolve(), args.from_r6)
