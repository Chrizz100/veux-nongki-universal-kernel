"""Recreate both verified source trees from the two supplied archives. Python 3 and git."""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import tempfile
import zipfile

hr=re.compile(rb'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@')
def apply(original,patch):
    src=io.BytesIO(original).readlines();dst=[];i=0;pos=0
    lines=io.BytesIO(patch).readlines()
    while i<len(lines):
        m=hr.match(lines[i]);i+=1
        if not m:continue
        s,n,_,_=m.groups();start=int(s)-(1 if int(n or b'1') else 0)
        assert pos<=start<=len(src)
        dst.extend(src[pos:start]);pos=start
        while i<len(lines) and not lines[i].startswith(b'@@ '):
            line=lines[i];i+=1;kind=line[:1];value=line[1:]
            if i<len(lines) and lines[i].startswith(b'\\ No newline'):
                assert value.endswith(b'\n');value=value[:-1];i+=1
            assert kind in (b' ',b'-',b'+'),line[:120]
            if kind in (b' ',b'-'):
                assert value==src[pos],(pos,value[:40],src[pos][:40]);pos+=1
            if kind in (b' ',b'+'):dst.append(value)
    dst.extend(src[pos:]);return b''.join(dst)

def sha256_file(path):
    with path.open('rb') as data:
        return hashlib.file_digest(data, 'sha256').hexdigest()

def full_tree(repo, label):
    return subprocess.check_output(['git','--git-dir',str(repo),'rev-parse',label+'^{tree}'],text=True).strip()

def path_bytes(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts:
        raise ValueError('Ungültiger Archivpfad')
    return json.dumps(str(p),ensure_ascii=False).encode()

def import_commit(repo, label, parent, source):
    with subprocess.Popen(['git','--git-dir',str(repo),'fast-import','--quiet'],stdin=subprocess.PIPE) as proc:
        write=proc.stdin.write
        write(f'commit refs/heads/{label}\ncommitter Source Archive <archive@local> 1 +0000\ndata 8\nArchive\n'.encode())
        write(('from refs/heads/'+parent+'\n').encode() if parent else b'deleteall\n')
        for name,mode,content in source:
            path=path_bytes(name)
            if mode:
                write(b'M '+mode.encode()+b' inline '+path+b'\n')
                write(f'data {len(content)}\n'.encode());write(content);write(b'\n')
            else:write(b'D '+path+b'\n')
        write(b'\n');proc.stdin.close()
        if proc.wait():raise RuntimeError('Git-Import fehlgeschlagen')

def base_files(source):
    with tarfile.open(source,'r|gz') as tf:
        for item in tf:
            if not (item.isreg() or item.issym()):continue
            rel=PurePosixPath(*PurePosixPath(item.name).parts[1:])
            if item.issym(): mode,data='120000',item.linkname.encode()
            else:mode,data=('100755' if item.mode & 0o111 else '100644'),tf.extractfile(item).read()
            yield str(rel),mode,data

def r6_changes(repo, diffs):
    with zipfile.ZipFile(diffs) as z, z.open('Dateibaum.csv') as src, subprocess.Popen(
        ['git','--git-dir',str(repo),'cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE) as cat:
        for row in csv.DictReader(io.TextIOWrapper(src,encoding='utf-8',newline='')):
            if row['Status']=='identisch':continue
            name=row['Pfad'];oid=row['MiCode_Git_Blob']
            if oid:
                cat.stdin.write(oid.encode()+b'\n');cat.stdin.flush()
                found,typ,size=cat.stdout.readline().split()
                if found.decode()!=oid or typ!=b'blob':raise ValueError(name)
                prev=cat.stdout.read(int(size))
                if cat.stdout.read(1)!=b'\n':raise ValueError(name)
            else:prev=b''
            data=apply(prev,z.read('Diff/'+name+'.diff'))
            if row['R6_Git_Blob']:
                blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
                if blob!=row['R6_Git_Blob']:raise ValueError(name)
            elif data:raise ValueError(name)
            yield name,row['R6_Modus'],data
        cat.stdin.close()
        if cat.wait():raise RuntimeError('Git-Blob-Lesen fehlgeschlagen')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('ziel',type=Path,help='Neuer Ausgabeordner')
    p.add_argument('--nur-git',action='store_true',help='Nur die vollständige Git-Datenbank ausgeben')
    p.add_argument('--original',type=Path,default=Path(__file__).with_name('MiCode-61397e5.tar.gz'))
    p.add_argument('--differenzen',type=Path,default=Path(__file__).with_name('Quellzeilen.zip'))
    args=p.parse_args();dest=args.ziel.resolve()
    if dest.exists():p.error('Zielordner muss neu sein')
    if sha256_file(args.original)!='b33c033cd6277eb1bb05db1fc8a31b596b08a6e895c27f1578f67b8a8d0d15d8':raise ValueError('MiCode-Archiv stimmt nicht')
    with tempfile.TemporaryDirectory(dir=dest.parent) as tmp:
        staging=Path(tmp)/'Neue-Quellen';staging.mkdir();repo=staging/'Vergleich.git'
        subprocess.run(['git','init','--bare','-q',repo],check=True)
        import_commit(repo,'MiCode',None,base_files(args.original))
        if full_tree(repo,'MiCode')!='ce2507948ba02807da44c5f81d04f8ce9945d66a':raise ValueError('MiCode-Tree')
        import_commit(repo,'R6','MiCode',r6_changes(repo,args.differenzen))
        if full_tree(repo,'R6')!='c91bed627648c1384e9a71f833d9512ebf07a910':raise ValueError('R6-Tree')
        if not args.nur_git:
            for label in ['MiCode','R6']:
                subprocess.run(['git','-c','core.autocrlf=false','clone','--quiet','--local','--branch',label,repo,staging/label],check=True)
                subprocess.run(['git','-C',str(staging/label),'remote','remove','origin'],check=True)
        os.rename(staging,dest)
    print('Beide vollständigen Quellbäume stimmen mit den geprüften Git-Prüfsummen überein.')
if __name__=='__main__':main()
