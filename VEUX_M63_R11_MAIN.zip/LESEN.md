# VEUX M63-R11 · POCO X4 Pro 5G

R11 verwendet den GitHub-Quellbaum von R10 aus Lauf 45439711648. Die Referenz ist das originale Xiaomi-Bootabbild der Global-ROM OS1.0.12.0.TKCMIXM. Die Baumkennungen und die Prüfsummen der acht geänderten Quelldateien stehen in source.json.

Auf dem DSI-Connector sind Lese- und Schreibmethoden für disp_param und mipi_reg registriert. Der Rückgabepuffer von disp_param ist von den MIPI-Registerdaten getrennt. Eine nichtleere Herstellerantwort für disp_param auf dem Telefon ist offen. Die Goodix-Diagnose unter /proc/tp_data_dump erfasst die signierten Roh- und Differenzwerte und stellt den Betriebsmodus auch nach einem Fehler wieder her.

Der Paketparser prüft vollständige DSI-Kommandos. Bei Abbruch gibt er die zuvor angelegten Datenpakete frei. Der Diagnosepfad gibt Fehler beim Anlegen der Kommandoliste zurück. Die Produktionstests für Touch und Panel stehen im Verzeichnis tests. Der CI-Lauf verifiziert zusätzlich die Leserechte, die registrierten Rückrufe und die Verknüpfung mit dem Controller und dem Goodix-Treiber im fertigen Kernel.

## GitHub Actions

Lege VEUX_M63_R11_MAIN.zip ins Hauptverzeichnis und VEUX_M63_R11_DSI_GOODIX_DIAGNOSE_NOFLASH.yml in .github/workflows/. Der Workflow kann manuell auf dem Standardbranch oder durch Push der beiden Dateien auf repair/m63-r11-dsi-goodix starten. Das Bootabbild, das AnyKernel3-Paket, der geprüfte Quellstand und die LLDB-Nachweise werden als Artefakte ausgegeben.

## Lokaler Bau

Der Bau verwendet Python ab 3.12, Git, die Kbuild-Werkzeuge, Android-Clang r416183b, LLDB 19 und qemu-arm für das Paketierwerkzeug.

~~~sh
python3 -B prepare.py R10-source.zip work/src /pfad/zum/stock/boot.img
LLDB=lldb-19 bash build.sh work /pfad/zu/clang-r416183b /pfad/zum/stock/boot.img
~~~

Das Quellarchiv muss den SHA-256 ffadc3bba20e7e0e1f986864d11f89ba253f957792d8a292a3086e5664365c19 besitzen. Mit --from-r6 kann die enthaltene Patchkette auch die verifizierte R6-Basis wiederherstellen. Die erwarteten Endbytes des Quellbaums stehen im Manifest.

R11 hat den Status NOFLASH. Die Prüfung der beiden Slot-Abbilder läuft auf Dateien. Eine Bestätigung für die PIN-Eingabe auf dem echten Gerät steht aus.
