import copy
import csv
import hashlib
import io
import json
import os
import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'src'))
import r31_abi_audit as audit


class R31OfflineProof(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.archive = pathlib.Path(os.environ.get('R30R2_ARCHIVE', '/mnt/data/VEUX_R30_R2_OEM_CRC_MAIN.zip'))
        cls.inputs = audit.safe_data(cls.archive)
        cls.outputs = audit.audit_data(cls.inputs)

    def test_01_pinned_archive_sha256(self):
        self.assertEqual(audit.sha(self.archive.read_bytes()), audit.EXPECTED_R30_SHA256)

    def test_02_archive_sha_change_rejected(self):
        with self.assertRaisesRegex(ValueError, 'R30_R2_SHA256_CHANGED'):
            audit.safe_data(self.archive, '0'*64)

    def test_03_all_inputs_manifest_verified(self):
        self.assertIn('preview/R30_R2_ALL_SYMBOLS.csv', self.inputs)
        self.assertIn('inputs/STOCK_5_4_274.config', self.inputs)

    def test_04_input_manifest_safe_flag(self):
        self.assertNotIn(b'flash_allowed": true', self.inputs['preview/R30_R2_RESULTS.json'])

    def test_05_inventory_counts(self):
        self.assertEqual(len(audit.read_csv(self.inputs['preview/R30_R2_ALL_SYMBOLS.csv'])), 4501)
        self.assertEqual(len(audit.read_csv(self.inputs['preview/R30_R2_NINE_DEVICE_MODULES.csv'])), 9)

    def test_06_complete_analysis_matches_preview(self):
        for key, value in self.outputs.items():
            self.assertGreater(len(value), 50, key)
        self.assertEqual(len(self.outputs), 6)

    def test_07_stock_nr_cpus_32(self):
        self.assertEqual(audit.config(self.inputs['inputs/STOCK_5_4_274.config'].decode())['CONFIG_NR_CPUS'], '32')

    def test_08_r13_nr_cpus_8(self):
        self.assertEqual(audit.config(self.inputs['inputs/R13_ACTUAL.config'].decode())['CONFIG_NR_CPUS'], '8')

    def test_09_a_nr_cpus_8(self):
        self.assertEqual(audit.config(self.inputs['inputs/A_STOCK_IPC_ACTUAL.config'].decode())['CONFIG_NR_CPUS'], '8')

    def test_10_b_nr_cpus_8(self):
        self.assertEqual(audit.config(self.inputs['inputs/B_STOCK_IPC_TRACE_ACTUAL.config'].decode())['CONFIG_NR_CPUS'], '8')

    def test_11_arm64_bits_64_requires_gt(self):
        self.assertFalse(audit.nr_cpu_ids_external(8))
        self.assertFalse(audit.nr_cpu_ids_external(32))
        self.assertFalse(audit.nr_cpu_ids_external(64))
        self.assertTrue(audit.nr_cpu_ids_external(65))

    def test_12_invalid_negative_nr_cpus_rejected(self):
        with self.assertRaises(ValueError): audit.nr_cpu_ids_external(-1)
        with self.assertRaises(ValueError): audit.nr_cpu_ids_external(8, bits_per_long=16)

    def test_13_qgki_gki_must_not_merge(self):
        f = json.loads(self.outputs['R31_FINDINGS.json'])
        self.assertEqual(f['separate_vendor_cohort_crc_conflicts'], 836)
        self.assertEqual(f['module_files_checked'], {'GKI':181,'QGKI':37})

    def test_14_qgki_exact_imports(self):
        f = json.loads(self.outputs['R31_FINDINGS.json'])
        self.assertEqual(f['QGKI_import_counts']['A'], {'MATCH':1326,'CRC_MISMATCH':1792,'NOT_EXPORTED':30})
        self.assertEqual(f['QGKI_import_counts']['B']['MATCH'],1326)

    def test_15_gki_exact_imports(self):
        f = json.loads(self.outputs['R31_FINDINGS.json'])
        self.assertEqual(f['GKI_import_counts']['A']['MATCH'],5061)
        self.assertEqual(f['GKI_import_counts']['B']['MATCH'],5061)

    def test_16_nine_module_paths_blocked(self):
        f = json.loads(self.outputs['R31_FINDINGS.json'])
        self.assertEqual(f['priority_module_paths_fully_compatible_A'],0)
        self.assertFalse(f['flash_allowed'])

    def test_17_module_layout_never_matching(self):
        r = audit.read_csv(self.outputs['R31_FOCUS_CRC.csv'])
        for c in ('QGKI','GKI'):
            m = next(x for x in r if x['cohort']==c and x['symbol']=='module_layout')
            self.assertEqual(m['A_status'],'CRC_MISMATCH')
            self.assertNotEqual(m['stock_import_expected_crc'],m['A_crc'])

    def test_18_alloc_trace_missing_r13_present_wrong_a(self):
        r = audit.read_csv(self.outputs['R31_FOCUS_CRC.csv'])
        for c in ('QGKI','GKI'):
            m = next(x for x in r if x['cohort']==c and x['symbol']=='kmem_cache_alloc_trace')
            self.assertEqual(m['R13_status'],'NOT_EXPORTED')
            self.assertEqual(m['A_status'],'CRC_MISMATCH')

    def test_19_geometry_imports_exist_in_both_cohorts(self):
        r = audit.read_csv(self.outputs['R31_CPU_EXPORT_MISMATCH.csv'])
        self.assertEqual(len(r),4)
        self.assertTrue(all(int(x['expected_external_ko_imports'])>0 for x in r))

    def test_20_cpu_mismatch_forces_provenance_review(self):
        r = audit.read_csv(self.outputs['R31_CPU_EXPORT_MISMATCH.csv'])
        self.assertTrue(all(x['interpretation']=='MODULE_BUILD_CONFIG_OR_SOURCE_LINEAGE_UNVERIFIED' for x in r))

    def test_21_fake_cpu_geometry_rejected(self):
        fake=dict(self.inputs)
        fake['inputs/STOCK_5_4_274.config'] = fake['inputs/STOCK_5_4_274.config'].replace(b'CONFIG_NR_CPUS=32',b'CONFIG_NR_CPUS=128')
        with self.assertRaisesRegex(ValueError, 'NR_CPUS_FACT_CHANGED'):
            audit.audit_data(fake)

    def test_22_fake_trace_config_rejected(self):
        fake=dict(self.inputs)
        fake['inputs/R13_ACTUAL.config'] = fake['inputs/R13_ACTUAL.config'] + b'\nCONFIG_TRACING=y\n'
        with self.assertRaisesRegex(ValueError, 'TRACING_FACT_CHANGED'):
            audit.audit_data(fake)

    def test_23_fake_oem_match_rejected(self):
        fake=dict(self.inputs)
        raw = fake['preview/R30_R2_ALL_SYMBOLS.csv'].decode()
        ls = raw.splitlines(keepends=True)
        for i in range(1,len(ls)):
            if ls[i].startswith('QGKI,module_layout,'):
                ls[i] = ls[i].replace('CRC_MISMATCH','MATCH')
                break
        fake['preview/R30_R2_ALL_SYMBOLS.csv'] = ''.join(ls).encode()
        with self.assertRaises(ValueError): audit.audit_data(fake)

    def test_24_manifest_provenance_changed_rejected(self):
        fake=dict(self.inputs)
        obj=json.loads(fake['inputs/PROVENANCE.json'])
        obj['r30_github_run']=12
        fake['inputs/PROVENANCE.json']=audit.json_bytes(obj)
        with self.assertRaisesRegex(ValueError,'R30_PROVENANCE_OR_ABI_GATE_CHANGED'):
            audit.audit_data(fake)

    def test_25_source_contract_official_legacy_not_stock(self):
        c=audit.source_contract()
        self.assertIn('5.4.134',c['official_legacy_kernel_version'])
        self.assertTrue(c['candidate_sources_before_R13_overlays'])

    def test_26_source_contract_only_pins(self):
        c=audit.source_contract()
        self.assertEqual(c['candidate_commit'],'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632')
        self.assertEqual(c['official_legacy_commit'],'61397e524093d1ccb94769b5460825e2eaf8871e')

    def test_27_identical_three_core_blobs(self):
        c=audit.source_contract()
        common=[p for p,v in c['files'].items() if v['candidate_blob']==v['legacy_blob']]
        self.assertEqual(sorted(common),sorted(['include/linux/module.h','include/linux/slab.h','scripts/genksyms/genksyms.c']))

    def test_28_source_contract_mutated_sha_rejected(self):
        c=audit.source_contract()
        c['files']['include/linux/module.h']['candidate_blob']='garbage'
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'r31_test_source_contract_bad.json'
            p.write_text(json.dumps(c))
            with self.assertRaisesRegex(ValueError,'BAD_GIT_BLOB_ID'):
                audit.source_contract(p)

    def test_29_no_non_github_source(self):
        with self.assertRaisesRegex(ValueError, 'SOURCE_URL_NOT_GITHUB'):
            audit.fetch_source('https://example.com/hi', '0'*40,opener=lambda *a:b'')

    def test_30_wrong_content_cannot_pass_git_blob(self):
        with self.assertRaisesRegex(ValueError, 'PINNED_SOURCE_GIT_BLOB_MISMATCH'):
            audit.fetch_source('https://raw.githubusercontent.com/a/b/c', '0'*40,opener=lambda *a:b'invalid bytes')

    def test_31_git_blob_known_test_vector(self):
        self.assertEqual(audit.git_blob_sha(b'hello\n'), 'ce013625030ba8dba906f756967f9e9ca394464a')

    def test_32_source_files_allowlist(self):
        c=audit.source_contract()
        self.assertEqual(len(c['files']),10)
        self.assertTrue(all('..' not in pathlib.PurePosixPath(p).parts for p in c['files']))

    def test_33_source_and_runner_unchanged(self):
        f=json.loads(self.outputs['R31_FINDINGS.json'])
        self.assertFalse(f['kernel_modified'])
        self.assertFalse(f['built_new_kernel'])
        self.assertFalse(f['target_cohort_confirmed'])

    def test_34_report_mentions_no_flash(self):
        self.assertIn('FLASHFREIGABE: NEIN',self.outputs['R31_PRUEFBERICHT_DE.txt'].decode())
        self.assertIn('CONFIG_NR_CPUS=32',self.outputs['R31_PRUEFBERICHT_DE.txt'].decode())

    def test_35_csv_has_expected_names(self):
        c=audit.read_csv(self.outputs['R31_CONFIG_FLAGS.csv'])
        r={x['flag']:x for x in c}
        self.assertEqual(r['CONFIG_IPC_LOGGING']['R13'],'n')
        self.assertEqual(r['CONFIG_IPC_LOGGING']['A'],'y')


if __name__ == '__main__': unittest.main()

class SourceAuditHarness(unittest.TestCase):
    @staticmethod
    def mock_pinned_tree():
        spec=audit.source_contract()
        fake={}
        for path,strings in spec['expected_code_features'].items():
            fake[path]=('\n'.join(strings)+'\n').encode()
        for path in spec['files']:
            fake.setdefault(path,b'/* pinned read-only source */\n')
        for path,entries in spec['files'].items():
            entries['candidate_blob'] = audit.git_blob_sha(fake[path])
            entries['legacy_blob'] = audit.git_blob_sha(fake[path])
        return spec,fake

    def test_36_mocked_pinned_source_proof_without_network(self):
        spec,source=self.mock_pinned_tree()
        def opener(url,timeout):
            return source[url.rsplit('/',1)[-1]] if False else source['/'.join(url.split('/')[6:])]
        proof=audit.source_audit(spec,opener=opener)
        self.assertEqual(proof['same_blob_count'],10)
        self.assertEqual(proof['status'],'PINNED_SOURCE_BLOBS_VERIFIED')
        self.assertTrue(proof['conditional_checks']['lib/cpumask.c']['#if NR_CPUS > BITS_PER_LONG'])

    def test_37_mocked_source_feature_missing_rejected(self):
        spec,source=self.mock_pinned_tree()
        path='include/linux/cpumask.h'
        source[path]=source[path].replace(b'#elif NR_CPUS <= BITS_PER_LONG', b'/* deleted condition */')
        spec['files'][path]['candidate_blob']=audit.git_blob_sha(source[path])
        spec['files'][path]['legacy_blob']=audit.git_blob_sha(source[path])
        def opener(url,timeout):return source['/'.join(url.split('/')[6:])]
        with self.assertRaisesRegex(ValueError,'EXPECTED_PINNED_SOURCE_CONDITION_MISSING'):
            audit.source_audit(spec,opener=opener)

    def test_38_false_source_pin_rejected(self):
        spec,source=self.mock_pinned_tree()
        spec['files']['include/linux/slab.h']['candidate_blob']='0'*40
        def opener(url,timeout):return source['/'.join(url.split('/')[6:])]
        with self.assertRaisesRegex(ValueError,'PINNED_SOURCE_GIT_BLOB_MISMATCH'):
            audit.source_audit(spec,opener=opener)

    def test_39_deterministic_output_json(self):
        data=audit.safe_data(os.environ.get('R30R2_ARCHIVE','/mnt/data/VEUX_R30_R2_OEM_CRC_MAIN.zip'))
        a=audit.audit_data(data)
        b=audit.audit_data(data)
        self.assertEqual(a,b)

    def test_40_zip_slip_file_rejected_before_content(self):
        import tempfile,zipfile
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'bad.zip'
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('../evil.txt',b'invalid')
            with self.assertRaisesRegex(ValueError,'ZIP_UNSAFE_PATH'):
                audit.safe_data(path,audit.sha(path.read_bytes()))

    def test_41_zip_symlink_entry_rejected(self):
        import tempfile,zipfile,stat
        with tempfile.TemporaryDirectory() as d:
            path=pathlib.Path(d)/'bad.zip'
            with zipfile.ZipFile(path,'w') as z:
                zi=zipfile.ZipInfo('link');zi.external_attr=(stat.S_IFLNK|0o777)<<16
                z.writestr(zi,b'target')
            with self.assertRaisesRegex(ValueError,'ZIP_NON_FILE'):
                audit.safe_data(path,audit.sha(path.read_bytes()))
