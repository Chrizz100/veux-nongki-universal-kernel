VEUX R31 – Quellen-/ABI-Ursachenprüfung (NO FLASH)
Stand 01.11.2026

ZIEL
Den externen OEM-QGKI/GKI-Modul-CRC-Konflikt ursachenorientiert untersuchen,
mit konkretem Nachweis zu CPU-Maskengeometrie, Trace-Allocator und module_layout.

GITHUB-ANLEITUNG
1. R30-R2 MAIN ZIP VEUX_R30_R2_OEM_CRC_MAIN.zip im Repository-Hauptverzeichnis BELASSEN.
   Sie ist unabdingbare, bereits authentifizierte Datenbasis.
2. Neue VEUX_R31_OEM_ABI_ROOTCAUSE_MAIN.zip ins Hauptverzeichnis hochladen.
3. VEUX_R31_OEM_ABI_ROOTCAUSE_NOFLASH.yml nach .github/workflows/ hochladen.
4. Actions > VEUX R31 OEM Source and ABI Rootcause - NO FLASH > Run workflow.
5. Bei Green Run das einzige R31-Analyse-Artefakt zur erneuten Begutachtung nutzen.

WAS DER WORKFLOW TATSAECHLICH MACHT
- Verifiziert getrennte SHA-256-Hashes beider Datenarchive.
- Verifiziert ZIP-Pfade, externe Symlinks und ein SHA256-Dateimanifest.
- Reproduziert die kompletten R30-R2-CSV/JSON-Fakten und 41 Negativ-/Regressionstests.
- Laedt 10 Quelltextdateien aus je zwei GENAU gepinnten GitHub-Commits,
  prueft deren Git-BLOB-SHA1 und ursachenrelevante bedingte Compilerschalter.
- Markiert OEM-ABI und Modul-Ladepfad weiterhin ausdruecklich als BLOCKED.
- Erzeugt nur Bericht/CSV/JSON, niemals Image, AK3 oder boot.img.

WICHTIGE GRENZEN
- Xiaomi offizieller Branch veux-r-oss ist 5.4.134, nicht die originale 5.4.274-Quelle.
- dereference23-Commit ist der Originalquellbaum VOR den R13-CASS/SUSFS/Root-Overlays.
- Das Stock-Image liefert die eingebettete .config, aber kein vollstaendiges OEM Module.symvers.
- Ob die neun externen .ko auf dem laufenden Geraet tatsaechlich geladen werden,
  muss mit einem separaten rein lesenden Live-Protokoll verifiziert werden.
- Ein gruenes GitHub-Audit bedeutet nur, dass die Analyse stimmt, NICHT dass
  ein neuer Kernel OEM-kompatibel, startfaehig oder flashfreigegeben waere.

NIEMALS
CRCs manipulieren, Module mittels Gewalt laden, CASS/WALT tauschen, BReNE oder
BakaSU/SUSFS/NoMount umkonfigurieren, den installierten Kernel flashen.

R13 remains untouched, no new kernel build, no flash.
