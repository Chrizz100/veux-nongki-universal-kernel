#!/usr/bin/env python3
"""VEUX R31 offline origin/conditional audit. No device access, compiling, or writes to kernel.
This program reads the authenticated R30-R2 archive as data, never executes its code.
Source proofs use pinned public Git blobs, fetched only in the optional --sources stage.
"""
import argparse
import csv
import hashlib
import io
import json
import pathlib
import re
import stat
import sys
import time
import urllib.error
import urllib.request
import zipfile
from collections import Counter, defaultdict

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE_CONTRACT = ROOT / 'SOURCE_CONTRACT.json'
EXPECTED_R30_SHA256 = 'ec1104a695a96db2515104fad6c0bf2a178b693c66a651ccca511aded146768b'
EXPECTED_R30_ID = 'VEUX_R30_R2_CRC_DETAIL_READONLY'
REQUIRED = frozenset({
    'inputs/STOCK_5_4_274.config', 'inputs/R13_ACTUAL.config',
    'inputs/A_STOCK_IPC_ACTUAL.config', 'inputs/B_STOCK_IPC_TRACE_ACTUAL.config',
    'preview/R30_R2_ALL_SYMBOLS.csv', 'preview/R30_R2_NINE_DEVICE_MODULES.csv',
    'preview/R30_R2_NINE_DEVICE_BLOCKERS.csv', 'preview/R30_R2_RESULTS.json',
    'inputs/PROVENANCE.json',
})
SYMBOL_FOCUS = ('module_layout', 'kmalloc_caches', 'kmem_cache_alloc_trace',
                'cpumask_next', 'nr_cpu_ids', 'queue_work_on', '__alloc_skb',
                '__cpu_online_mask', 'ipc_log_context_create', 'ipc_log_context_destroy',
                'ipc_log_string')
CONFIG_FLAGS = ('CONFIG_NR_CPUS', 'CONFIG_SMP', 'CONFIG_TRACING',
                'CONFIG_TRACEPOINTS', 'CONFIG_EVENT_TRACING', 'CONFIG_IPC_LOGGING',
                'CONFIG_SCHED_WALT', 'CONFIG_SCHED_CASS', 'CONFIG_CFI_CLANG',
                'CONFIG_KPROBES', 'CONFIG_BPF_EVENTS', 'CONFIG_MODVERSIONS',
                'CONFIG_ANDROID_VENDOR_HOOKS', 'CONFIG_CLANG_VERSION')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode('ascii') + b'\0' + data).hexdigest()


def safe_data(archive, expected=EXPECTED_R30_SHA256):
    archive = pathlib.Path(archive)
    if sha(archive.read_bytes()) != expected:
        raise ValueError('R30_R2_SHA256_CHANGED')
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        if len(infos) > 100 or len(set(names)) != len(names) or z.testzip() is not None:
            raise ValueError('ZIP_CORRUPT_OR_DUPLICATES')
        if sum(i.file_size for i in infos) > 25000000:
            raise ValueError('ZIP_DECOMPRESSION_LIMIT')
        for info in infos:
            p = pathlib.PurePosixPath(info.filename)
            kind = stat.S_IFMT(info.external_attr >> 16)
            if p.is_absolute() or '..' in p.parts or '\\' in info.filename or not info.filename:
                raise ValueError('ZIP_UNSAFE_PATH')
            if kind not in (0, stat.S_IFREG) or info.is_dir():
                raise ValueError('ZIP_NON_FILE')
        if not REQUIRED.issubset(set(names)) or 'MANIFEST_SHA256.json' not in names:
            raise ValueError('R30_REQUIRED_INPUTS_MISSING')
        manifest = json.loads(z.read('MANIFEST_SHA256.json'))
        if (manifest['schema'] != 1 or manifest['description'] != EXPECTED_R30_ID or
            manifest['flash_allowed'] is not False or manifest['kernel_build'] is not False or
            set(manifest['files']) | {'MANIFEST_SHA256.json'} != set(names)):
            raise ValueError('R30_MANIFEST_CONTRACT')
        for info in infos:
            if info.filename != 'MANIFEST_SHA256.json':
                if sha(z.read(info.filename)) != manifest['files'][info.filename]:
                    raise ValueError('R30_FILE_MANIFEST_HASH_MISMATCH')
        return {n: z.read(n) for n in REQUIRED}


def config(text):
    result = {}
    for line in text.splitlines():
        if m := re.fullmatch(r'(CONFIG_[A-Z0-9_]+)=(\S+)', line):
            result[m[1]] = m[2]
        elif m := re.fullmatch(r'# (CONFIG_[A-Z0-9_]+) is not set', line):
            result[m[1]] = 'n'
    return result


def read_csv(data):
    return list(csv.DictReader(io.StringIO(data.decode('utf-8'))))


def csv_bytes(rows, fields):
    out = io.StringIO(newline='')
    w = csv.DictWriter(out, fieldnames=fields, extrasaction='ignore', lineterminator='\n')
    w.writeheader()
    w.writerows(rows)
    return out.getvalue().encode('utf-8')


def json_bytes(x):
    return (json.dumps(x, sort_keys=True, indent=2, ensure_ascii=False) + '\n').encode('utf-8')


def source_contract(path=SOURCE_CONTRACT):
    obj = json.loads(pathlib.Path(path).read_text('utf-8'))
    if (obj['schema'] != 1 or obj['candidate_repository'] != 'dereference23/kernel_xiaomi_sm6375' or
        obj['official_legacy_repository'] != 'MiCode/Xiaomi_Kernel_OpenSource' or
        obj['candidate_commit'] !=
        'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632' or
        obj['official_legacy_commit'] != '61397e524093d1ccb94769b5460825e2eaf8871e'):
        raise ValueError('SOURCE_CONTRACT_PIN_CHANGED')
    if len(obj['files']) != 10:
        raise ValueError('SOURCE_CONTRACT_PATH_COUNT')
    for path, versions in obj['files'].items():
        p = pathlib.PurePosixPath(path)
        if p.is_absolute() or '..' in p.parts or not path.endswith(('.c', '.h')):
            raise ValueError('UNSAFE_SOURCE_PATH')
        for key in ('candidate_blob', 'legacy_blob'):
            if re.fullmatch(r'[a-f0-9]{40}', versions[key]) is None:
                raise ValueError('BAD_GIT_BLOB_ID')
    return obj


def fetch_source(uri, expected_blob, opener=None):
    if opener is None:
        def opener(url, timeout):
            with urllib.request.urlopen(
                urllib.request.Request(url, headers={'User-Agent': 'VEUX-R31-Research-NoFlash/1.0', 'Accept': 'text/plain'}),
                timeout=timeout) as response:
                if response.status != 200:
                    raise IOError('GITHUB_SOURCE_HTTP_STATUS')
                data = response.read(180000 + 1)
                return data
    if not uri.startswith('https://raw.githubusercontent.com/'):
        raise ValueError('SOURCE_URL_NOT_GITHUB')
    for attempt in range(3):
        try:
            data = opener(uri, 25)
            if len(data) > 180000 or git_blob_sha(data) != expected_blob:
                raise ValueError('PINNED_SOURCE_GIT_BLOB_MISMATCH')
            return data
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt == 2:
                raise
            time.sleep(1 + attempt)
    raise AssertionError('unreachable')


def source_audit(contract, opener=None):
    """Fetch and authenticate historical candidate/official source files, without execution."""
    records = []
    loaded = {}
    for path, hashes in sorted(contract['files'].items()):
        blobs = {}
        for label, repo_key, rev_key, sha_key in (
            ('candidate', 'candidate_repository', 'candidate_commit', 'candidate_blob'),
            ('official_legacy', 'official_legacy_repository', 'official_legacy_commit', 'legacy_blob')):
            url = 'https://raw.githubusercontent.com/{}/{}/{}'.format(contract[repo_key], contract[rev_key], path)
            blobs[label] = fetch_source(url, hashes[sha_key], opener=opener)
        loaded[path] = blobs['candidate']
        records.append({'path': path, 'candidate_blob': hashes['candidate_blob'],
                        'legacy_blob': hashes['legacy_blob'], 'same_blob':
                        hashes['candidate_blob'] == hashes['legacy_blob'],
                        'source_bytes_verified': True})
    checks = {}
    for path, features in contract['expected_code_features'].items():
        if path not in loaded:
            raise ValueError('UNFETCHED_SOURCE_FILE')
        contents = loaded[path].decode('utf-8')
        checks[path] = {f: f in contents for f in features}
        if not all(checks[path].values()):
            raise ValueError('EXPECTED_PINNED_SOURCE_CONDITION_MISSING:' + path)
    # Require conditional code in the *actual source*, not just a reported Kconfig flag.
    cpumask_h = loaded['include/linux/cpumask.h'].decode('utf-8')
    cpumask_c = loaded['lib/cpumask.c'].decode('utf-8')
    module_h = loaded['include/linux/module.h'].decode('utf-8')
    slab_h = loaded['include/linux/slab.h'].decode('utf-8')
    if not (cpumask_h.find('#elif NR_CPUS <= BITS_PER_LONG') <
            cpumask_h.find('extern unsigned int nr_cpu_ids;') or
            '#if NR_CPUS > BITS_PER_LONG' not in cpumask_c or
            '#ifdef CONFIG_TRACING' not in module_h or
            '#else /* CONFIG_TRACING */' not in slab_h):
        raise ValueError('PINNED_SOURCE_CONDITIONAL_PROOF_FAILED')
    return {'status': 'PINNED_SOURCE_BLOBS_VERIFIED',
            'sources_are_original_unpatched_research_trees': True,
            'actual_R13_CASS_tree_may_differ_from_pin': True,
            'exact_5_4_274_Xiaomi_source_unavailable': True,
            'source_records': records, 'conditional_checks': checks,
            'same_blob_count': sum(r['same_blob'] for r in records)}


def nr_cpu_ids_external(nr_cpus, bits_per_long=64):
    if nr_cpus < 1 or bits_per_long not in (32, 64):
        raise ValueError('UNSUPPORTED_CPU_GEOMETRY')
    return nr_cpus > bits_per_long


def audit_data(inputs):
    symbol_rows = read_csv(inputs['preview/R30_R2_ALL_SYMBOLS.csv'])
    modules = read_csv(inputs['preview/R30_R2_NINE_DEVICE_MODULES.csv'])
    blockers = read_csv(inputs['preview/R30_R2_NINE_DEVICE_BLOCKERS.csv'])
    r30 = json.loads(inputs['preview/R30_R2_RESULTS.json'])
    p = json.loads(inputs['inputs/PROVENANCE.json'])
    configs = {name: config(inputs[arch].decode('utf-8')) for name, arch in (
        ('STOCK', 'inputs/STOCK_5_4_274.config'),
        ('R13', 'inputs/R13_ACTUAL.config'),
        ('A', 'inputs/A_STOCK_IPC_ACTUAL.config'),
        ('B', 'inputs/B_STOCK_IPC_TRACE_ACTUAL.config'))}
    if p['r30_github_run'] != 41207776770 or r30['status'] != 'OFFLINE_CRC_DIAG_PASS__FULL_OEM_ABI_BLOCKED__NO_FLASH':
        raise ValueError('R30_PROVENANCE_OR_ABI_GATE_CHANGED')
    if len(symbol_rows) != 4501 or len(modules) != 9 or r30['nine_device_modules_not_compatible_A'] != 9:
        raise ValueError('INVALID_DATA_CARDINALITY_OR_RELEASE_GATE')
    expected = {'STOCK': 32, 'R13': 8, 'A': 8, 'B': 8}
    for key, val in expected.items():
        if configs[key].get('CONFIG_NR_CPUS') != str(val):
            raise ValueError('NR_CPUS_FACT_CHANGED:' + key)
    if [configs[k].get('CONFIG_TRACING', 'n') for k in ('STOCK', 'R13', 'A', 'B')] != ['y', 'n', 'y', 'y']:
        raise ValueError('TRACING_FACT_CHANGED')
    if [configs[k].get('CONFIG_IPC_LOGGING', 'n') for k in ('STOCK', 'R13', 'A', 'B')] != ['y', 'n', 'y', 'y']:
        raise ValueError('IPC_LOGGING_FACT_CHANGED')
    if not all(c.get('CONFIG_MODVERSIONS') == 'y' for c in configs.values()):
        raise ValueError('MODVERSIONS_MUST_BE_ON')
    rows = [r for r in symbol_rows if r['symbol'] in SYMBOL_FOCUS]
    for cohort, n in [('QGKI', 1423), ('GKI', 3078)]:
        cohort_data = [r for r in symbol_rows if r['cohort'] == cohort]
        if len(cohort_data) != n:
            raise ValueError('COHORT_UNIQUE_SYMBOL_COUNT_CHANGED')
        for variant, status in [('R13', 'R13_status'), ('A', 'A_status'), ('B', 'B_status')]:
            occur = Counter()
            for r in cohort_data:
                occur[r[status]] += int(r['import_occurrences'])
            if dict(occur) != r30['reported_counts'][cohort][variant]:
                raise ValueError('COHORT_IMPORT_COUNTS_DRIFT:' + cohort + '/' + variant)
        for sym in ('module_layout', 'kmalloc_caches', 'kmem_cache_alloc_trace', 'cpumask_next', 'nr_cpu_ids'):
            record = next((r for r in cohort_data if r['symbol'] == sym), None)
            if record is None:
                raise ValueError('IMPORTANT_SYMBOL_LOST:' + sym)
            if record['A_status'] == 'MATCH':
                raise ValueError('EXPECTED_BLOCKER_SUDDENLY_MATCHES:' + sym)
    if any(r['A_full_import_compatible'] != 'NO' for r in modules):
        raise ValueError('MODULE_GATE_UNEXPECTED_FULL_MATCH')
    if len(blockers) < 100:
        raise ValueError('MODULE_BLOCKER_COVERAGE_TOO_SMALL')
    module_path_set = {(r['cohort'], r['module']) for r in modules}
    if {(r['cohort'], r['module']) for r in blockers} != module_path_set:
        raise ValueError('MODULE_BLOCKER_PATH_SET_CHANGED')
    important_symbols = ('cpumask_next', 'nr_cpu_ids', 'module_layout', 'kmalloc_caches', 'kmem_cache_alloc_trace')
    by_path = defaultdict(set)
    for b in blockers:
        if b['symbol'] in important_symbols:
            by_path[(b['cohort'], b['symbol'])].add(b['module'])
    geometry_rows = []
    for cohort in ('QGKI', 'GKI'):
        for symbol in ('cpumask_next', 'nr_cpu_ids'):
            r = next(x for x in symbol_rows if x['cohort']==cohort and x['symbol']==symbol)
            geometry_rows.append({
                'cohort': cohort, 'symbol': symbol,
                'expected_external_ko_imports': r['import_occurrences'],
                'stock_nr_cpus': '32', 'R13_A_B_nr_cpus': '8', 'ARM64_bits_per_long': '64',
                'pinned_source_requires_nr_cpus_gt_bits_for_external': 'YES',
                'stock_external_expected_by_pinned_source': 'NO',
                'A_external_expected_by_pinned_source': 'NO',
                'nine_module_paths_with_this_import': ';'.join(sorted(by_path[(cohort, symbol)])),
                'interpretation': 'MODULE_BUILD_CONFIG_OR_SOURCE_LINEAGE_UNVERIFIED',
            })
    for cohort, n in [('QGKI', 37), ('GKI', 181)]:
        row = next(x for x in symbol_rows if x['cohort']==cohort and x['symbol']=='module_layout')
        if int(row['import_occurrences']) != n:
            raise ValueError('MODULE_LAYOUT_OCCURRENCES_CHANGED')
    if any(nr_cpu_ids_external(x) for x in expected.values()):
        raise ValueError('CPU_MASK_GEOMETRY_CONTRADICTION')
    config_rows = []
    for flag in CONFIG_FLAGS:
        config_rows.append({'flag': flag, **{name: configs[name].get(flag,'n') for name in ('STOCK','R13','A','B')}})
    focus_rows = []
    for r in rows:
        focus_rows.append({key: r[key] for key in (
            'cohort','symbol','import_occurrences','stock_import_expected_crc',
            'R13_crc','A_crc','B_crc','R13_status','A_status','B_status')})
    findings = {
        'schema': 1,
        'stage': 'VEUX_R31_SOURCE_CONDITIONALS_AND_OEM_MODULE_PROVENANCE_NOFLASH',
        'r30_r2_input_sha256': EXPECTED_R30_SHA256,
        'r30_r2_provenance_run': 41207776770,
        'R30_R2_reproducibility_run': 41228681481,
        'source_pin_is_pre_overlay': True,
        'real_stock_config_from_extracted_stock_image': True,
        'exact_stock_kernel_5_4_274_source_and_Symvers_missing': True,
        'architecture': 'arm64', 'bits_per_long': 64,
        'nr_cpus': expected,
        'external_cpumask_export_expected_with_pinned_source': {k:nr_cpu_ids_external(v) for k,v in expected.items()},
        'module_origin_active_loader_path_confirmed': False,
        'target_cohort_confirmed': False,
        'module_files_checked': {'QGKI':37,'GKI':181},
        'separate_vendor_cohort_crc_conflicts': 836,
        'QGKI_import_counts': r30['reported_counts']['QGKI'],
        'GKI_import_counts': r30['reported_counts']['GKI'],
        'priority_module_paths': 9,
        'priority_module_paths_fully_compatible_A': 0,
        'flash_allowed': False,
        'kernel_modified': False,
        'built_new_kernel': False,
        'interpretation': [
            'Pinned source lib/cpumask.c exports cpumask_next only if NR_CPUS > BITS_PER_LONG; observed stock NR_CPUS=32 and candidates NR_CPUS=8 on arm64.',
            'OEM imports of cpumask_next/nr_cpu_ids require separate module provenance investigation; neither presence on disk nor older boot insmod errors establish active runtime dependence.',
            'Header slab.h controls external vs inline kmem_cache_alloc_trace with CONFIG_TRACING: disabled in R13 and enabled in A/B; the export appears but CRC does not match either OEM cohort.',
            'module_layout imported by modpost is a synthetic dependency on conditional struct module and related types, not a user-settable magic CRC.',
            'Source references include original pre-overlay candidate and old 5.4.134 Xiaomi branch; neither proves final R30 patched source or actual 5.4.274 OEM vendor ABI.',
        ],
        'next_safe_step': 'Verify active module loading path read-only, then trace exact final compiled R13/A sources and OEM module provenance. No CRC forcing or flash.',
        'status': 'OFFLINE_ROOT_CAUSE_CLUES_PASS__VENDOR_ABI_AND_LOADER_PATH_BLOCKED__NO_FLASH',
    }
    files = {
        'R31_FINDINGS.json': json_bytes(findings),
        'R31_CONFIG_FLAGS.csv': csv_bytes(config_rows, ['flag','STOCK','R13','A','B']),
        'R31_FOCUS_CRC.csv': csv_bytes(focus_rows, ['cohort','symbol','import_occurrences','stock_import_expected_crc','R13_crc','A_crc','B_crc','R13_status','A_status','B_status']),
        'R31_CPU_EXPORT_MISMATCH.csv': csv_bytes(geometry_rows, ['cohort','symbol','expected_external_ko_imports','stock_nr_cpus','R13_A_B_nr_cpus','ARM64_bits_per_long','pinned_source_requires_nr_cpus_gt_bits_for_external','stock_external_expected_by_pinned_source','A_external_expected_by_pinned_source','nine_module_paths_with_this_import','interpretation']),
        'R31_NINE_MODULES_GATE.csv': csv_bytes(modules, list(modules[0])),
        'R31_PRUEFBERICHT_DE.txt': report(findings, geometry_rows, rows, config_rows).encode('utf-8')
    }
    return files


def report(f, geom, rows, configs):
    lines = [
        'VEUX R31 – QGKI/GKI OEM-ABI: Quellursachen und Modulherkunft',
        'STAND 01.11.2026 – offline, NO FLASH, kein Build, kein Eingriff am Geraet',
        '',
        'EVIDENZ:',
        'Authentische R30-R2-Importtabellen, Hash- und Manifest-geprueft;',
        'R30-R2 GitHub-Erfolg 41228681481 als Reproduktion der Offline-Diagnose.',
        'Unpatchte Quellenreferenzen: dereference23 b2b7a3... und Xiaomi MiCode',
        'veux-r-oss aelterer Android-R-Branch 5.4.134 (NICHT Stock-5.4.274-Quellcode).',
        'Git-BLOB-IDs stehen in SOURCE_CONTRACT.json; GitHub-Workflow verifiziert Live-Quellen.',
        '',
        'ERGEBNIS QGKI IMPORTVORKOMMEN (R13 / R30-A / R30-B):',
        'R13=1303 exakt, 1752 CRC-Konflikte, 93 fehlend',
        'A   =1326 exakt, 1792 CRC-Konflikte, 30 fehlend',
        'B   =1326 exakt, 1805 CRC-Konflikte, 17 fehlend',
        'GKI-Kohorte bleibt getrennt; 836 Symbole widersprechen in erwartetem CRC.',
        '',
        '1) CPU-MASK-EXPORTFALLE / MODULHERKUNFT:',
        'Stock-CONFIG_NR_CPUS=32; R13/A/B=8; arm64 BITS_PER_LONG=64.',
        'In der exakt gepinnten Ausgangsquelle: lib/cpumask.c #if NR_CPUS > BITS_PER_LONG',
        'und include/linux/cpumask.h inline bei <= BITS_PER_LONG.',
        'Daher ist cpumask_next bei 8 oder 32 CPUs dort nicht als externes Symbol verfuegbar.',
        'nr_cpu_ids wird dort bei <= 64 als Makro deklariert, nicht als externe Variable.',
        'Aber die untersuchten OEM .ko importieren diese Namen:',
    ]
    for r in geom:
        lines.append('  {} {}: {} importierendes Vorkommen, {} priorisierte Pfade'.format(
            r['cohort'], r['symbol'], r['expected_external_ko_imports'],
            len([p for p in r['nine_module_paths_with_this_import'].split(';') if p])))
    lines += [
        'Dies beweist eine Quell-/Konfigurations-Diskrepanz im geprueften Teilprofil,',
        'aber weder einen realen Modemfehler noch die Verwendung der Moduldatei im Bootpfad.',
        '',
        '2) TRACE-ALLOCATOR:',
        'include/linux/slab.h fuehrt kmem_cache_alloc_trace unter CONFIG_TRACING als',
        'externen Export, ohne CONFIG_TRACING als Inlinefunktion.',
        'R13 TRACING=n -> kein Export. R30-A und B TRACING=y -> Export, aber falsche CRC.',
        'Das erklaert den neuen Export, NICHT seine vollstaendige OEM-Kompatibilitaet.',
        '',
        '3) module_layout UND WEITERE STRUKTUREN:',
        'scripts/mod/modpost.c nimmt module_layout als versioniertes Modulsymbol auf.',
        'include/linux/module.h hat bedingte Felder u. a. TRACEPOINTS, TRACING, EVENT_TRACING.',
        'Modul-Layout-CRC R13=0xbff14f69, A=0xa6bdffa3, B=0xbae762e8,',
        'OEM-QGKI=0x945d02f2, OEM-GKI=0x1e5b7ab7.',
        'Sowohl Struct-Layout als auch transitive Typen, Flags, Patches und Toolchain',
        'koennen die genksyms-CRC beeinflussen. Konkrete kausale Teilmenge nicht bewiesen.',
        '',
        '4) GEPRUEFTE OEM-TREIBER:',
        '9/9 der priorisierten RMNET-/IPA-Moduldateipfade in R30-A sind nicht voll ABI-kompatibel.',
        'Das gilt fuer die externen .ko; eingebaute RMNET/IPA-Treiber koennen separat laufen.',
        '',
        '5) OFFENE GRENZEN:',
        'Exakte OEM-Module.symvers und passender Stock-Quellbaum 5.4.274 fehlen.',
        'Gepinnter Kernel-Quellbaum ist vor CASS/Root-Overlays; kein Nachweis finaler Header.',
        'Tatsaechlicher QGKI-/GKI-Ladepfad und Modulaktivitaet sind nicht bestaetigt.',
        'Weder vereinheitlichen noch CRCs umschreiben noch Module erzwingen.',
        '',
        'ENTSCHEIDUNG: R31 ist ein Quellen-/Geometrie-Nachweis, KEIN ABI-GREEN.',
        'NAECHSTER GATE: Originalem OEM-Ladepfad und finaler Build-Quellprovenienz nachgehen.',
        'R13 / CASS / BReNE / BakaSU / SUSFS / NoMount / Vendor / DTBO unveraendert.',
        'NEUER KERNEL: NEIN. FLASHFREIGABE: NEIN.',
        '',
    ]
    return '\n'.join(lines)


def selftest():
    assert git_blob_sha(b'hello\n') == 'ce013625030ba8dba906f756967f9e9ca394464a'
    assert nr_cpu_ids_external(8) is False
    assert nr_cpu_ids_external(32) is False
    assert nr_cpu_ids_external(64) is False
    assert nr_cpu_ids_external(65) is True
    assert nr_cpu_ids_external(128) is True
    try:
        nr_cpu_ids_external(0)
    except ValueError:
        pass
    else:
        raise AssertionError('negative CPU geometry was accepted')
    assert source_contract()['files']['include/linux/module.h']['candidate_blob'] == source_contract()['files']['include/linux/module.h']['legacy_blob']
    print('R31_PURE_FUNCTION_SELFTEST=PASS')


def main(argv=None):
    parser = argparse.ArgumentParser(description='VEUX R31 offline/source audit; NO FLASH')
    parser.add_argument('--input', type=pathlib.Path)
    parser.add_argument('--out', type=pathlib.Path)
    parser.add_argument('--sources', action='store_true')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args(argv)
    if args.selftest:
        selftest()
        return
    if args.out is None:
        parser.error('--out required')
    args.out.mkdir(parents=True, exist_ok=True)
    if args.sources:
        source_result = source_audit(source_contract())
        (args.out / 'R31_PINNED_SOURCE_AUDIT.json').write_bytes(json_bytes(source_result))
        print('R31_PINNED_SOURCE_BLOBS_AND_CONDITIONALS=PASS; EXACT_STOCK_SOURCE=NO')
        return
    if args.input is None:
        parser.error('--input required')
    outputs = audit_data(safe_data(args.input))
    for filename, data in outputs.items():
        (args.out / filename).write_bytes(data)
    print('R31_OFFLINE_SOURCE_CONDITIONAL_HYPOTHESES=PASS; OEM_ABI=BLOCKED; NO_FLASH')


if __name__ == '__main__':
    main()
