# VEUX M62 für das POCO X4 Pro 5G

M62 ergänzt den UFS-Gesundheitsbericht `hr` und den Xiaomi-Kerneldienst Millet. Die Vergleichsbasis ist das ausgelieferte `boot.img` von HyperOS `OS1.0.12.0.TKCMIXM` für `veux` mit Kernel `5.4.274-qgki-g82179e362f33`.

## GitHub Actions

1. `VEUX_M62_MAIN.zip` als ZIP-Datei ins Hauptverzeichnis von `Chrizz100/veux-nongki-universal-kernel` legen.
2. `VEUX_M62_MILLET_UFS_NOFLASH.yml` unter `.github/workflows/` ablegen. Beide Dateien müssen im selben Stand vorhanden sein.
3. Unter **Actions** den Workflow **VEUX M62 – Xiaomi UFS-Gesundheitsbericht und Millet** mit **Run workflow** starten.

Der Workflow prüft die SHA-256-Prüfsummen des M61-Quellstands aus GitHub-Lauf `45067682648`, der Stock-Eingaben und der gepatchten Dateien. Er nutzt den GitHub-Cache für Xiaomi-Eingaben und Android-Clang. Die Treibertests und die ABI-Prüfung der beiden Binder-Exporte laufen vor dem zeitaufwendigen Linken. Kernel, Module und Gerätebaum werden in einem gemeinsamen Build erzeugt.

## Xiaomi-Abgleich

`hr` verwendet den Gesundheitsbericht aus Xiaomis veröffentlichtem VEUX-Treiber. Geprüft werden alle sieben UFS- und drei DDR-Anzeigen, ihre Lesefunktionen und Berechtigungen. Die Hosttests überprüfen auch den Samsung-Pfad und die Fehlerbehandlung. [Originaler Xiaomi-Treiber](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/drivers/misc/mi-memory/mi_ufs_info.c)

Der öffentliche `veux-r-oss`-Stand enthält den vollständigen Millet-Treiber nicht. M62 verwendet den Xiaomi-Millet-Code aus dem unten genannten Quellstand und die Binder- und Signal-Anschlüsse aus Xiaomis Android-13-Quellen. Maßgeblich für die Anpassung ist der ausgelieferte VEUX-Kernel. Der statische Test vergleicht Netlink-Kanal 30, die Nachrichtengrößen, 15 Funktionen, sechs registrierte Ereignis-Anschlüsse, vier IPv4-/IPv6-Anschlüsse sowie zehn exportierte Schnittstellen einschließlich Prüfsummen und Lizenzklassen. Ein separater Hosttest führt den Handshake aus. [Millet-Quellstand](https://github.com/EndCredits/android_kernel_xiaomi_sm8350-miui/tree/6cb9f5a9edc161abda546ee23c8f8ba741655746/drivers/mihw/millet) · [Xiaomi-Android-13-Quellstand](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/f4e416aea06c81f1e661d0524c0554f0538d11cb)

`Nachweise` enthält den Bericht über die 37 Originalmodule, die aufgeschlüsselten Speicheranzeigen und Millet-Schnittstellen sowie die Konfigurationsvergleiche. `BOOT-AK3-NOFLASH` enthält das `boot.img` und das AK3-Prüfpaket. Der AK3-Einstieg liest den aktiven Slot, prüft die exakte Xiaomi-Ausgangsdatei und erzeugt sein Ergebnis im temporären Arbeitsverzeichnis. Ein Start auf dem physischen POCO ist separat zu bestätigen. Der Status lautet bis dahin `device_pass=false`, `flash_allowed=false`.
