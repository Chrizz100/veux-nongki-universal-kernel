#!/usr/bin/env bash
set -euo pipefail
work=$(realpath "$1")
tools=$(realpath "$2")
kit=$(cd "$(dirname "$0")" && pwd)
export PYTHONPATH="$kit${PYTHONPATH:+:$PYTHONPATH}"
export SOURCE_DATE_EPOCH=1794009600 KBUILD_BUILD_TIMESTAMP='Sat Nov 7 00:00:00 UTC 2026'
export KBUILD_BUILD_USER=veux-ci KBUILD_BUILD_HOST=github-actions KBUILD_BUILD_VERSION=1
export KBUILD_JOBS="${KBUILD_JOBS:-$(nproc)}"
mkdir -p "$work/evidence"
build=(bash "$tools/kbuild.sh" "$work/src" "$work/out" "$work/clang")
check=(python3 -B "$tools/check.py")
args=(--out "$work/out" --baseline "$work/baseline.config" --vendor "$work/stock-vendor" --stock "$work/boot.img" --result "$work/evidence")
python3 -B "$kit/test_features.py" "$work/src"
python3 -B "$kit/test_diag.py" "$work/src"
python3 -B "$tools/test_mi_memory.py" "$work/src"
python3 -B "$tools/test_f2fs.py" "$work/src"
"${build[@]}" olddefconfig
"${check[@]}" config "${args[@]}"
"${build[@]}" drivers/mihw/binder_gki.o drivers/scsi/ufs/mi-ufs-health.o
LC_ALL=C sort "$work/out/drivers/mihw/binder_gki.o.symversions" | diff -u "$kit/binder-exports.stock" -
{ time "${build[@]}" Image modules dtbs; } > "$work/evidence/build.log" 2>&1 || { tail -100 "$work/evidence/build.log"; exit 1; }
"${check[@]}" final "${args[@]}"
bash "$kit/regress.sh" "$tools" "$work/boot.img" "$work/out" "$work/clang/bin" "$work/evidence/regression"
python3 -B "$kit/pair.py" "$tools" "$work/boot.img" "$work/out/arch/arm64/boot/Image" "$work/pair"
