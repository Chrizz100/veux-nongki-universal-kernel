VEUX R55H17-R4: CASS-Basis mit vorhandenen Updates
=================================================

Ziel
----
Die originale R5S2/CASS-Buildkette bleibt die Basis. Die bereits vorhandenen
Updates werden nach dem echten Baseline-Build in eine getrennte Kopie des
vollständigen finalen Quellbaums übertragen. Die neue Kopie wird mit der
ursprünglichen Konfiguration und dem bisherigen Android-Compiler gebaut.

Repository: Chrizz100/veux-nongki-universal-kernel
Vorgesehene Dateien im Repository:
  VEUX_R55H17_R4_CASS_UPDATE_MAIN.zip
  .github/workflows/R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml

Die separat gelieferte YAML muss bytegleich mit der YAML in diesem ZIP sein.
Beide Dateien zusammen auf denselben Git-Stand übernehmen. Der Workflow wird
manuell mit workflow_dispatch und enable_build=true gestartet.

Änderungen
----------
* BakaSU: echtes Upstream d5e9e025b8b49155f8014684d64c91742b465f65 plus
  native 5.4-Adapter und zwei vollständige SUSFS-Priority-Backendanschlüsse.
  Echter Portcommit: 2cbbcc2363aa8d4b6286fc2266a338063b2b77a7.
  Tatsächliche Historie: 4553 Commits; daraus echte Version 35253.
  Tag und Version werden aus dem vollständigen Git-Repository ermittelt.
* SUSFS: vorhandene gebaute G1-Ergänzungen auf sieben native CASS-Hostdateien
  übertragen. Die bisherigen Funktionskörper in fs/susfs.c bleiben
  bytegenau erhalten. Die Matrix
  review/HOST_CONTRACT_MATRIX.json dokumentiert alle 21 G1-Hostpfade und
  die erhaltenen nativen Alternativen. Die frühere komplette
  Installationspatchserie wird nicht erneut auf bereits integrierte Hooks
  angewendet.
* NoMount: echter bf1847f98fed382369c43bfd652cd93774b9b8e3-Stand, Protokoll22.
  Der R5S2-Stackschutz bleibt erhalten. Der separat geprüfte Fehler am
  unteren Rand einer UID-Ausschlussrange ist korrigiert; 27 Policyfälle
  bestanden den vorhandenen Hosttest.

Erhaltene Basis
----------------
CASS bleibt aktiv, WALT deaktiviert. Scheduler, Gerätekonfiguration,
CFI/ThinLTO, starker Stackschutz und sämtliche Dateien außerhalb des
ausdrücklich erlaubten Updateumfangs bleiben erhalten. Es gibt keinen
gesonderten BReNE-Dateinamen im rekonstruierten Baum; die Erhaltung erfolgt
über den vollständigen Quellenvergleich außerhalb des Updateumfangs.

Prüfablauf
----------
1. Paketmanifest, jede ausführbare Datei, Pfade und Negativkontrollen prüfen.
2. Originalen R5S2/CASS-Build mit unveränderter bisheriger Buildkette bauen.
3. Finale echte Quellen einschließlich Git-Historie vor Bereinigung sichern.
4. Getrennten Kandidaten erzeugen und alle Vorher-/Nachher-Hashes prüfen.
5. Echte Git-BakaSU-Kopie und atomare NoMount-Dateiersetzungen veröffentlichen.
6. Native Header, init/version.o, SELinux und Image/dtbs/modules kompilieren.
7. Tatsächliche und eingebettete Konfiguration, echte BakaSU-Version,
   CASS-/Update-Symbole, Preinit-Objekte, DTB und 132 RMNET-Import-CRCs prüfen.
8. Rohes Image/DTB und Belege nur nach bestandenen Compiler-/ABI-Gates ausgeben.

Unveränderte Referenzwerte
------------------------
Release: 5.4.274-qgki-g82179e362f33
Config-SHA256: 405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4
Baseline-Symvers-SHA256: 6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec
DTB-SHA256: 42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37

Ergebnisumfang
--------------
Für den aktualisierten Kandidaten werden nur rohe Image-/DTB-Belege
ausgegeben, kein aktualisierter Installer und keine aktualisierte boot.img.
Die unveränderte Baselinekette erzeugt intern weiterhin ihre bisherigen
Pakete; diese werden nicht als Update exportiert. Es erfolgen keine
Geräteaktionen. Ein bestandener Build und ABI-Abgleich ist kein
nachgewiesener Geräteboot. Die tatsächlichen lokalen Buildresultate stehen
im gesonderten Build-/Prüfpaket, nicht in den früheren Quellenprüfberichten.

NoMount22 benötigt den dazu passenden Userspace-/Modulstand22. Die
Regel-/Löschheader unterscheiden sich vom älteren21er-Protokoll. Dieses
Kernelpaket liefert keine neue Manager-APK oder NoMount-Userspace-Binärdatei.

Dateien
-------
cass_source_port.py: geprüfter Transfer in den isolierten Kandidaten.
workflow/: ursprünglichen Handoff nutzende Bridge, Build und Prüfungen.
data/: echte Git-Bundle-/Quellenpins und NoMount-Overlay.
patches/: lesbare vollständige Änderungen.
review/: Herkunft und unabhängige Quellen-/Replay-Prüfungen.
PAYLOAD_MANIFEST.json: SHA256 aller ausgeführten/gelesenen Paketdateien.

Der Manifest-Hash ist in der YAML fest eingebunden. YAML und äußere
SHA256SUMS stehen außerhalb der Manifestdateiliste, um einen zyklischen
Hash zu vermeiden; der finale Paketprüfer vergleicht beide YAML-Kopien.
