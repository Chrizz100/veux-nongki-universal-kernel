#!/usr/bin/env python3
"""Apply authenticated existing update deltas to an isolated R5S2/CASS tree.

This stages source only. Compilation and device validation are separate gates.
The original baseline must remain byte-for-byte unchanged.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile

class PortBlocked(RuntimeError):
    pass

def need(test, message):
    if not test:
        raise PortBlocked(message)

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def run(args, cwd=None):
    p = subprocess.run([str(a) for a in args], cwd=cwd, capture_output=True,
                       text=True, timeout=240)
    need(p.returncode == 0, 'COMMAND_FAILED:' + str(args[:3]) + ':' + p.stderr[-1600:])
    return p.stdout.strip()

def git(root, *args):
    return run(['git', '-C', root, *args])

def confined(root, rel):
    p = Path(rel)
    need(not p.is_absolute() and p.parts and '..' not in p.parts,
         'UNSAFE_PATH:' + str(rel))
    target = root / p
    need(target.parent.resolve().is_relative_to(root.resolve()),
         'ESCAPING_PARENT:' + str(rel))
    return target

def entry(path):
    if path.is_symlink():
        return {'type': 'symlink', 'target': os.readlink(path)}
    need(path.is_file(), 'NOT_REGULAR:' + str(path))
    return {'type': 'file', 'sha256': digest(path),
            'mode': stat.S_IMODE(path.stat().st_mode)}

def inventory(root, normalize_links=False):
    result = {}
    for parent, directories, files in os.walk(root, followlinks=False):
        directories[:] = sorted(d for d in directories if d != '.git')
        for d in list(directories):
            p = Path(parent) / d
            if p.is_symlink():
                result[p.relative_to(root).as_posix()] = entry(p)
                directories.remove(d)
        for name in sorted(files):
            if name == '.git':
                continue
            p = Path(parent) / name
            result[p.relative_to(root).as_posix()] = entry(p)
    if normalize_links:
        for rel, item in result.items():
            if item['type'] == 'symlink':
                resolved = (root / rel).resolve()
                need(resolved.is_relative_to(root), 'EXTERNAL_SOURCE_LINK:' + rel)
                item['target'] = 'INTERNAL:' + resolved.relative_to(root).as_posix()
    return result

def check_hash(root, rel, expected):
    p = confined(root, rel)
    need(p.is_file() and not p.is_symlink(), 'EXPECTED_REGULAR:' + rel)
    need(digest(p) == expected, 'HASH_MISMATCH:' + rel)
    return p

def check_provider(root, pin, count=None):
    need((root / '.git').exists(), 'PROVIDER_NOT_GIT:' + str(root))
    need(git(root, 'rev-parse', 'HEAD') == pin, 'PROVIDER_HEAD_MISMATCH')
    need(not git(root, 'status', '--porcelain', '--untracked-files=all'),
         'PROVIDER_DIRTY')
    if count is not None:
        need(git(root, 'rev-parse', '--is-shallow-repository') == 'false',
             'BAKASU_HISTORY_SHALLOW')
        need(int(git(root, 'rev-list', '--count', 'HEAD')) == count,
             'BAKASU_HISTORY_COUNT_MISMATCH')

def replace_file(source, target):
    """Publish complete source bytes through a fresh inode, never a partial copy."""
    content = source.read_bytes()
    fd, temporary = tempfile.mkstemp(prefix='.cass-port-', dir=target.parent)
    temporary = Path(temporary)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        temporary.chmod(stat.S_IMODE(source.stat().st_mode))
        os.replace(temporary, target)
        need(target.read_bytes() == content, 'ATOMIC_COPY_BYTES_CHANGED:' + str(target))
    finally:
        temporary.unlink(missing_ok=True)

def apply(args):
    original = args.baseline.resolve(strict=True)
    candidate = args.kernel.resolve(strict=True)
    payload = args.payload.resolve(strict=True)
    need(original != candidate and not candidate.is_relative_to(original)
         and not original.is_relative_to(candidate), 'BASELINE_CANDIDATE_OVERLAP')
    pins = json.loads((payload / 'data/PORT_PINS.json').read_text())
    need(pins['schema'] == 1, 'PORT_SCHEMA_CHANGED')
    before_original = inventory(original)
    before = inventory(candidate, normalize_links=True)
    need(before == inventory(original, normalize_links=True),
         'CANDIDATE_IS_NOT_EXACT_BASELINE_COPY')
    for rel, expected in pins['baseline_files'].items():
        check_hash(original, rel, expected)
    need((candidate / 'drivers/kernelsu').is_symlink(), 'KSU_LINK_MISSING')
    need((candidate / 'drivers/kernelsu').resolve() == candidate / 'KernelSU/kernel',
         'KSU_LINK_NOT_INTERNAL')
    old = original / 'KernelSU'
    need(git(old, 'rev-parse', 'HEAD^') == pins['legacy_bakasu_parent'],
         'LEGACY_BAKASU_PARENT_CHANGED')
    need(int(git(old, 'rev-list', '--count', 'HEAD')) == 4534,
         'LEGACY_BAKASU_HISTORY_CHANGED')
    need(not git(old, 'status', '--porcelain', '--untracked-files=all'),
         'LEGACY_BAKASU_DIRTY')
    bp = pins['bakasu']
    check_provider(args.bakasu, bp['upstream'], 4552)
    need(git(args.bakasu, 'rev-parse', bp['tag'] + '^{}') == bp['tag_commit'],
         'GENUINE_BAKASU_TAG_CHANGED')
    np = pins['nomount']
    check_provider(args.nomount_old, np['old_commit'])
    check_provider(args.nomount_new, np['new_commit'])
    for rel, hashes in np['upstream_files'].items():
        check_hash(args.nomount_old, rel, hashes['old'])
        check_hash(args.nomount_new, rel, hashes['new'])

    # Verify every input before modifying the disposable candidate.
    bundle = check_hash(payload, bp['bundle'], bp['bundle_sha256'])
    host = pins['host']
    patch = check_hash(payload, host['patch'], host['patch_sha256'])
    for rel, hashes in host['files'].items():
        check_hash(candidate, rel, hashes['before'])
        need(not rel.startswith(('kernel/sched/', 'arch/', 'drivers/gpu/')),
             'HOST_PATCH_PROTECTED_PATH:' + rel)
    for rel, values in np['overlay'].items():
        check_hash(candidate, rel, values['before'])
        check_hash(payload, values['payload'], values['after'])
    patch_paths = {line.split('\t', 2)[2] for line in
                   run(['git', 'apply', '--numstat', patch], cwd=candidate).splitlines()}
    need(patch_paths == set(host['files']), 'HOST_PATCH_PATH_SCOPE_CHANGED')
    run(['git', 'apply', '--check', '--whitespace=error', patch], cwd=candidate)
    run(['git', 'bundle', 'verify', bundle], cwd=args.bakasu)

    new_provider = candidate / 'KernelSU'
    need(not new_provider.is_symlink() and (new_provider / '.git').is_dir(),
         'UNEXPECTED_OLD_PROVIDER_LAYOUT')
    staged_provider = Path(tempfile.mkdtemp(prefix='cass-provider-', dir=candidate.parent))
    try:
        run(['git', 'clone', '--quiet', '--no-hardlinks', '--no-checkout',
             args.bakasu, staged_provider])
        git(staged_provider, 'fetch', '--quiet', '--no-tags', str(bundle), bp['commit'])
        git(staged_provider, 'checkout', '--quiet', '--detach', bp['commit'])
        check_provider(staged_provider, bp['commit'], bp['count'])
        for rel, expected in bp['files'].items():
            need(entry(confined(staged_provider, rel)) == expected,
                 'STAGED_BAKASU_TREE_MISMATCH:' + rel)
        shutil.rmtree(new_provider)
        os.replace(staged_provider, new_provider)
    finally:
        if staged_provider.exists():
            shutil.rmtree(staged_provider)
    check_provider(new_provider, bp['commit'], bp['count'])
    need(git(new_provider, 'rev-parse', 'HEAD^') == bp['upstream'],
         'NEW_PROVIDER_PARENT_CHANGED')
    need(bp['version'] == 30000 + bp['count'] + 700,
         'GENUINE_VERSION_FORMULA_CHANGED')
    for rel, expected in bp['files'].items():
        p = confined(new_provider, rel)
        need(entry(p) == expected, 'BAKASU_TREE_MISMATCH:' + rel)
    run(['git', 'apply', '--whitespace=error', patch], cwd=candidate)
    for rel, values in np['overlay'].items():
        replace_file(payload / values['payload'], candidate / rel)
    for rel, hashes in host['files'].items():
        check_hash(candidate, rel, hashes['after'])
    for rel, values in np['overlay'].items():
        check_hash(candidate, rel, values['after'])

    after = inventory(candidate, normalize_links=True)
    touched = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
    allowed = set(host['files']) | set(np['overlay'])
    forbidden = [k for k in touched if k not in allowed and not k.startswith('KernelSU/')]
    need(not forbidden, 'SOURCE_CHANGED_OUTSIDE_UPDATE_SCOPE:' + repr(forbidden[:15]))
    need(before_original == inventory(original), 'ORIGINAL_BASELINE_WAS_CHANGED')
    need(not any(p.startswith('kernel/sched/') or 'brene' in p.lower() for p in touched),
         'CASS_OR_BRENE_CHANGED')
    # Re-read final bytes after the complete inventories, so a stale or changed
    # working tree cannot be mistaken for a successfully materialized port.
    check_provider(new_provider, bp['commit'], bp['count'])
    for rel, expected in bp['files'].items():
        need(entry(confined(new_provider, rel)) == expected,
             'FINAL_BAKASU_TREE_MISMATCH:' + rel)
    for rel, hashes in host['files'].items():
        check_hash(candidate, rel, hashes['after'])
    for rel, values in np['overlay'].items():
        check_hash(candidate, rel, values['after'])
    need('CONFIG_SCHED_CASS' in (candidate / 'init/Kconfig').read_text()
         or 'config SCHED_CASS' in (candidate / 'init/Kconfig').read_text(),
         'CASS_KCONFIG_MISSING')
    need('#define NOMOUNT_BASE_VERSION "22"' in (candidate / 'fs/nomount/nomount.h').read_text(),
         'NOMOUNT_PROTOCOL_MISSING')
    result = {'schema': 1, 'status': 'PORT_SOURCE_PASS',
              'source_updates_staged': True, 'compiler_test': False,
              'kernel_image_generated': False, 'device_test': False,
              'flash_allowed': False, 'baseline_unchanged': True,
              'scheduler_and_brene_unchanged': True,
              'bakasu_version': {k: bp[k] for k in ('commit','count','version')},
              'nomount_protocol': 22, 'changed_paths': touched,
              'host_patch_sha256': host['patch_sha256'],
              'before_files': len(before), 'after_files': len(after)}
    (args.out / 'CHANGED_SOURCE_FILES.json').write_text(json.dumps({
        p: {'before': before.get(p), 'after': after.get(p)} for p in touched}, indent=2)+'\n')
    return result

def main():
    ap = argparse.ArgumentParser()
    for name in ('baseline','kernel','bakasu','nomount-old','nomount-new','payload','out'):
        ap.add_argument('--' + name, type=Path, required=True)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    try:
        result = apply(args)
    except (PortBlocked, OSError, ValueError, KeyError, subprocess.TimeoutExpired) as exc:
        result = {'schema': 1, 'status': 'PORT_BLOCKED', 'reason': str(exc),
                  'source_updates_staged': False, 'compiler_test': False,
                  'kernel_image_generated': False, 'device_test': False, 'flash_allowed': False}
    (args.out / 'PORT_RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result), flush=True)
    return 0 if result['status'] == 'PORT_SOURCE_PASS' else 23

if __name__ == '__main__':
    sys.exit(main())
