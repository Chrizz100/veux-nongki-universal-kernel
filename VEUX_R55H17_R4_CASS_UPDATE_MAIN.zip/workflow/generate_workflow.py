#!/usr/bin/env python3
"""Generate the R4 workflow while retaining the authenticated R3 baseline chain."""
from __future__ import annotations
import argparse
import copy
import hashlib
from pathlib import Path
import re
import textwrap
import yaml

NAME = 'R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml'


class ReadableDumper(yaml.SafeDumper):
    pass


def readable_string(dumper, value):
    return dumper.represent_scalar('tag:yaml.org,2002:str', value,
                                   style='|' if '\n' in value else None)


ReadableDumper.add_representer(str, readable_string)


def generate(original: Path, manifest_sha: str) -> str:
    if not re.fullmatch(r'[0-9a-f]{64}', manifest_sha) or manifest_sha == '0' * 64:
        raise ValueError('REAL_PAYLOAD_MANIFEST_SHA256_REQUIRED')
    document = yaml.safe_load(original.read_text())
    if True in document:
        document['on'] = document.pop(True)
    document['name'] = 'VEUX R55H17-R4 protected CASS baseline plus genuine updated full build - NO FLASH'
    document['on']['workflow_dispatch']['inputs']['enable_build']['description'] = (
        'Rebuild protected CASS baseline, transfer existing updates, compile and verify candidate; no flash')
    document['concurrency']['group'] = 'veux-r55h17-r4-cass-updated-build-${{ github.ref }}'
    document['env']['R4_PACKAGE_NAME'] = 'VEUX_R55H17_R4_CASS_UPDATE_MAIN.zip'
    document['env']['R4_MANIFEST_SHA256'] = manifest_sha
    job = document['jobs']['r5s2_bakasu_522']
    job['name'] = 'R4 original CASS protected; updates in isolated native ARM64 build; no flash'
    job['timeout-minutes'] = 360
    steps = []
    bootstrap = (Path(__file__).parent / 'extract_payload.py').read_text().rstrip('\n')
    for original_step in job['steps']:
        step = copy.deepcopy(original_step)
        name = step['name']
        if name.startswith('R55H17-R3 actual ShellCheck'):
            step['name'] = 'R4 verify every Bash stage and embedded Python before kernel compilation'
            step['run'] = textwrap.dedent('''\
                set -euo pipefail
                command -v shellcheck
                mkdir -p "$RUNNER_TEMP/r55h17-r4-shellcheck"
                python3 - ".github/workflows/R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml" "$RUNNER_TEMP/r55h17-r4-shellcheck" <<'PY_R4_SC'
                import ast,re,sys
                from pathlib import Path
                import yaml
                source=Path(sys.argv[1]); destination=Path(sys.argv[2])
                document=yaml.safe_load(source.read_text())
                for i,step in enumerate(document['jobs']['r5s2_bakasu_522']['steps']):
                    if 'run' in step:
                        if step.get('shell')!='bash':raise SystemExit('UNREVIEWED_RUN_SHELL')
                        (destination / (str(i)+'-step.sh')).write_text(step['run'])
                        lines=step['run'].splitlines()
                        for j,line in enumerate(lines):
                            match=re.search(r"<<'(PY[A-Za-z0-9_]*)'",line)
                            if match:
                                delimiter=match.group(1)
                                end=next(k for k in range(j+1,len(lines)) if lines[k]==delimiter)
                                ast.parse('\\n'.join(lines[j+1:end])+'\\n')
                PY_R4_SC
                for script in "$RUNNER_TEMP"/r55h17-r4-shellcheck/*-step.sh; do
                  bash -n "$script"
                  shellcheck --shell=bash --severity=error "$script"
                done
                echo 'R55H17_R4_ALL_BASH_STAGES=PASS; NO_FLASH'
                ''')
        elif name.startswith('R55H17-R3 pin source-port hook'):
            step['name'] = 'R4 authenticate source-port payload and run isolation negative tests before baseline build'
            step['run'] = ("set -euo pipefail\n"
                "test -f \"$GITHUB_WORKSPACE/$R4_PACKAGE_NAME\"\n"
                "cat > \"$RUNNER_TEMP/r4-extract-payload.py\" <<'PY_R4_EXTRACT'\n" + bootstrap +
                "\nPY_R4_EXTRACT\n"
                "python3 -B \"$RUNNER_TEMP/r4-extract-payload.py\" --archive \"$GITHUB_WORKSPACE/$R4_PACKAGE_NAME\" "
                "--out \"$RUNNER_TEMP/veux-r55h17-r4-payload\" --manifest-sha256 \"$R4_MANIFEST_SHA256\"\n"
                "printf 'R4_PAYLOAD=%s\\n' \"$RUNNER_TEMP/veux-r55h17-r4-payload\" >> \"$GITHUB_ENV\"\n"
                "python3 -B -m unittest discover -s \"$RUNNER_TEMP/veux-r55h17-r4-payload/workflow\" "
                "-p test_cass_r4.py -v\n"
                "python3 -B - \"$RUNNER_TEMP/veux-r55h17-r4-payload\" <<'PY_R4_AST'\n"
                "import ast,sys\nfrom pathlib import Path\n"
                "for path in Path(sys.argv[1]).rglob('*.py'):\n"
                "    ast.parse(path.read_text(),filename=str(path))\n"
                "print('R4_AUTHENTICATED_PYTHON_SYNTAX=PASS')\n"
                "PY_R4_AST\n")
        elif name.startswith('Compile authentic R5S2 CASS'):
            step['name'] = 'Compile original CASS then preserve final source and build isolated updated CASS candidate'
            step['run'] = textwrap.dedent('''\
                set -euo pipefail
                export PYTHONPATH="$R4_PAYLOAD/workflow:$VERSION_OVERLAY/common/scripts:$R5S2_OVERLAY/common/scripts:$R5S1_OVERLAY/common/scripts:$R5_OVERLAY/common/scripts:$R4_OVERLAY/common/scripts:$NM211_R2_OVERLAY/common/scripts${PYTHONPATH:+:$PYTHONPATH}"
                "$R5S2_PY" -B -u "$R4_PAYLOAD/workflow/cass_r4_bridge.py" \
                  --repo "$GITHUB_WORKSPACE" --work "$RUNNER_TEMP/veux-r5s2-work" \
                  --reference "$R5S1_REFERENCE" --donor522 "$BAKASU522_DONOR" --sync "$SYNC_DONOR" --jobs 4
                ''')
        elif name.startswith('R55H17-R3 verify source-port report'):
            step['name'] = 'R4 require genuine candidate build CASS config DTB version preinit and 132 RMNET proofs'
            step['id'] = 'r4_verify'
            step['run'] = textwrap.dedent('''\
                set -euo pipefail
                python3 -B - "$RUNNER_TEMP/veux-r55h17-r4/evidence/R4_RESULT.json" \
                  "$RUNNER_TEMP/veux-r55h17-r1-audit/R55H17_R1_CASS_RESULT.json" <<'PY_R4_FINAL'
                import json,sys
                from pathlib import Path
                updated=json.loads(Path(sys.argv[1]).read_text())
                baseline=json.loads(Path(sys.argv[2]).read_text())
                if updated.get('status')!='CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH':
                    raise SystemExit('UPDATED_CASS_BUILD_OR_STATIC_GATES_INCOMPLETE')
                for flag in ('compiler_test','source_updates_staged','kernel_image_generated','raw_exported',
                             'original_baseline_unchanged','embedded_config_matches','cass_linked'):
                    if updated.get(flag) is not True:raise SystemExit('MISSING_PROOF:'+flag)
                if (updated.get('flash_allowed') is not False or updated.get('device_test') is not False
                    or updated.get('rmnet_imports_matched')!=132
                    or baseline.get('rmnet_imports_matched')!=132
                    or updated.get('bakasu_version',{}).get('count')!=4553
                    or updated.get('bakasu_version',{}).get('version')!=35253):
                    raise SystemExit('R4_VERSION_ABI_OR_NOFLASH_CONTRACT_CHANGED')
                print('R55H17_R4_UPDATED_CASS_BUILD_AND_STATIC_ABI=PASS; DEVICE_TEST=NO; FLASH=NO')
                PY_R4_FINAL
                ''')
        elif name.startswith('Upload R55H17-R3 genuine'):
            step['name'] = 'Upload R4 source transfer and compiler evidence even when a gate blocks'
            step['with']['name'] = 'VEUX-R55H17-R4-CASS-UPDATE-EVIDENCE-NOFLASH-${{ github.run_id }}'
            step['with']['path'] = '${{ runner.temp }}/veux-r55h17-r4/evidence/'
        elif name == 'Upload source and compile diagnostics even if blocked':
            step['name'] = 'Upload original CASS baseline reports without old Image or installers'
            step['with']['path'] = '\n'.join([
                '${{ runner.temp }}/veux-r5s2-overlay/ZIP_VALIDATION.json',
                '${{ runner.temp }}/veux-real-version-overlay/MANIFEST_SHA256.json',
                '${{ runner.temp }}/veux-r5s2-work/prepare.json',
                '${{ runner.temp }}/veux-r5s2-work/report/*.json',
                '${{ runner.temp }}/veux-r5s2-work/builds/diagnostics/5.4.274/**/*.json',
                '${{ runner.temp }}/veux-r5s2-work/builds/diagnostics/5.4.274/**/*.log',
                '${{ runner.temp }}/veux-r5s2-work/builds/diagnostics/5.4.274/**/*.config',
                '${{ runner.temp }}/veux-r5s2-work/builds/diagnostics/5.4.274/**/Module.symvers',
                '${{ runner.temp }}/veux-r5s2-work/builds/diagnostics/5.4.274/**/System.map'])
        elif name.startswith('Assert repository unchanged'):
            steps.extend([
                {'name': 'Preserve authenticated final CASS baseline source before worker cleanup',
                 'if': '${{ always() }}',
                 'uses': 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02',
                 'with': {'name': 'VEUX-R55H17-R4-FINAL-CASS-BASELINE-SOURCE-${{ github.run_id }}',
                          'path': '${{ runner.temp }}/veux-r55h17-r4/R5S2_FINAL_CASS_SOURCE.tar.gz',
                          'if-no-files-found': 'warn', 'retention-days': 21, 'compression-level': 0}},
                {'name': 'Export raw CASS kernel only after all static build and ABI gates pass',
                 'if': "${{ success() && inputs.enable_build == true && steps.r4_verify.conclusion == 'success' }}",
                 'uses': 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02',
                 'with': {'name': 'VEUX-R55H17-R4-CASS-RAW-STATIC-PASSED-NOFLASH-${{ github.run_id }}',
                          'path': '${{ runner.temp }}/veux-r55h17-r4/raw-passed/',
                          'if-no-files-found': 'error', 'retention-days': 21, 'compression-level': 6}}
            ])
            step['run'] = textwrap.dedent('''\
                set -euo pipefail
                test "$GITHUB_REPOSITORY" = "$EXPECTED_REPO"
                test "$(git rev-parse HEAD)" = "$GITHUB_SHA"
                test -z "$(git status --porcelain --untracked-files=all)"
                echo 'R55H17_R4_CHECKED_OUT_REPOSITORY_UNCHANGED=PASS; DEVICE_TEST=NO; FLASH=NO'
                ''')
        if 'run' in step:
            step['run'] = step['run'].replace(
                '.github/workflows/R55H17_R3_CASS_POST_COMPILE_SOURCE_PORT_NOFLASH.yml',
                '.github/workflows/' + NAME)
        steps.append(step)
    authentication = [s for s in steps if s['name'].startswith('R4 authenticate source-port payload')]
    if len(authentication) != 1:
        raise ValueError('R4_PAYLOAD_AUTHENTICATION_STAGE_MISSING')
    steps.remove(authentication[0])
    steps.insert(2, authentication[0])
    job['steps'] = steps
    # This verifies all mandatory transformations; stale R3 port code cannot
    # silently survive a source workflow rename or upstream layout change.
    rendered = yaml.dump(document, Dumper=ReadableDumper, sort_keys=False,
                         width=110, allow_unicode=True)
    for forbidden in ('cherry-pick', 'veux-r55h17-r2-port.py', 'BAKASU_THREEWAY_SOURCE_STAGE_PASS',
                      'SOURCE_PORT_STAGED_PENDING_FULL_COMPILER_ABI_RECHECK'):
        if forbidden in rendered:
            raise ValueError('STALE_R3_SOURCE_PORT_SURVIVED:' + forbidden)
    for required in ('cass_r4_bridge.py', 'R4_MANIFEST_SHA256', 'steps.r4_verify.conclusion',
                     'R5S2_FINAL_CASS_SOURCE.tar.gz', '239e1e8871b8fcd51a6e5b3002e0ba522fdd99fb'):
        if required not in rendered:
            raise ValueError('REQUIRED_R4_OR_BASELINE_GATE_MISSING:' + required)
    return rendered


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--original', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = generate(args.original, args.manifest_sha256)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(result)
    print(args.output, hashlib.sha256(result.encode()).hexdigest())


if __name__ == '__main__':
    main()
