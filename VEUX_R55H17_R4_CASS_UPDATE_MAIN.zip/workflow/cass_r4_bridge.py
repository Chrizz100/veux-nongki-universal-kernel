#!/usr/bin/env python3
"""Attach R4 to the authenticated R5S2 worker after genuine baseline compilation."""
from __future__ import annotations

import argparse
import ast
import os
from pathlib import Path

ANCHOR = ('        result["bakasu_true_version"] = '
          'verify_version_compilation(src,work,real_version,result)\n')
HOOK = ('        from cass_r4_build import run_update as __r4_run_update\n'
        '        __r4_update_proof = __r4_run_update(src, state, work, args.jobs)\n')


def attach_hook(worker: Path) -> dict:
    if worker.is_symlink() or not worker.is_file():
        raise RuntimeError('R4_WORKER_NOT_REGULAR')
    body = worker.read_text(encoding='utf-8')
    if body.count(ANCHOR) != 1 or '__r4_run_update' in body:
        raise RuntimeError('R4_POST_COMPILE_ANCHOR_MISSING_OR_DUPLICATED')
    updated = body.replace(ANCHOR, ANCHOR + HOOK, 1)
    ast.parse(updated)
    if updated.replace(ANCHOR + HOOK, ANCHOR, 1) != body:
        raise RuntimeError('R4_UNRELATED_WORKER_MUTATION')
    worker.write_text(updated, encoding='utf-8')
    return {'post_genuine_baseline_compile': True,
            'baseline_build_result_unchanged': True}


def main() -> None:
    import veux_r5s2_true_version as original
    parser = argparse.ArgumentParser()
    for key in ('repo', 'work', 'reference', 'donor522', 'sync'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--jobs', type=int, default=4)
    args = parser.parse_args()
    before = original.inject_version_worker
    attached = []

    def wrapped(*positional, **keywords):
        metadata = before(*positional, **keywords)
        if len(positional) < 3:
            raise RuntimeError('R4_WORKER_CALL_LAYOUT_CHANGED')
        worker = Path(positional[2])
        if not worker.resolve().is_relative_to(Path(os.environ['RUNNER_TEMP']).resolve()):
            raise RuntimeError('R4_WORKER_OUTSIDE_RUNNER_TEMP')
        proof = attach_hook(worker)
        attached.append(proof)
        metadata['r55h17_r4'] = proof
        return metadata

    original.inject_version_worker = wrapped
    try:
        original.build(args.repo, args.work, args.reference,
                       args.donor522, args.sync, args.jobs)
    finally:
        original.inject_version_worker = before
    if len(attached) != 1:
        raise RuntimeError('R4_WORKER_NOT_ATTACHED_EXACTLY_ONCE')
    print('R55H17_R4_WORKER_COMPLETED; DEVICE_TEST=NO; FLASH=NO', flush=True)


if __name__ == '__main__':
    main()
