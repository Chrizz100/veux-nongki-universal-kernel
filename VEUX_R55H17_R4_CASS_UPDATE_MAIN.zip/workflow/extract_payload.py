#!/usr/bin/env python3
"""Extract a SHA-pinned executable payload, refusing unsafe ZIP entries."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile


def extract(archive: Path, destination: Path, manifest_sha: str) -> dict:
    if destination.exists() or destination.is_symlink():
        raise ValueError('R4_PAYLOAD_DESTINATION_EXISTS')
    with zipfile.ZipFile(archive) as source:
        if source.testzip() is not None:
            raise ValueError('R4_PAYLOAD_ZIP_CRC_FAILED')
        names = source.namelist()
        if len(names) != len(set(names)):
            raise ValueError('R4_DUPLICATE_ZIP_ENTRY')
        raw = source.read('PAYLOAD_MANIFEST.json')
        if hashlib.sha256(raw).hexdigest() != manifest_sha:
            raise ValueError('R4_PAYLOAD_MANIFEST_HASH_CHANGED')
        manifest = json.loads(raw)
        if manifest.get('schema') != 1 or manifest.get('flash_allowed') is not False:
            raise ValueError('R4_UNTRUSTED_MANIFEST_SCHEMA')
        files = manifest.get('files', {})
        if not files or not all(isinstance(k, str) and isinstance(v, str) for k, v in files.items()):
            raise ValueError('R4_INVALID_PAYLOAD_HASH_MAP')
        # The final workflow and human-facing checksum wrapper are optional ZIP
        # companions. They are not executed from this extracted payload.
        companions = {'R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml', 'SHA256SUMS', 'README.txt'}
        extras = set(names) - set(files) - {'PAYLOAD_MANIFEST.json'}
        if not extras <= companions:
            raise ValueError('R4_UNMANIFESTED_PAYLOAD_ENTRY')
        for item in source.infolist():
            path = PurePosixPath(item.filename)
            if (path.is_absolute() or '..' in path.parts or '\\' in item.filename
                    or item.filename.endswith('/') or '\x00' in item.filename
                    or stat.S_ISLNK(item.external_attr >> 16)):
                raise ValueError('R4_UNSAFE_PAYLOAD_PATH')
        for name, expected in files.items():
            data = source.read(name)
            if hashlib.sha256(data).hexdigest() != expected:
                raise ValueError('R4_PAYLOAD_FILE_HASH_CHANGED:' + name)
        destination.mkdir(parents=True)
        for name in ['PAYLOAD_MANIFEST.json', *sorted(files)]:
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read(name))
    return {'status': 'R4_PAYLOAD_AUTHENTICATED', 'files': len(files),
            'manifest_sha256': manifest_sha, 'flash_allowed': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(extract(args.archive, args.out, args.manifest_sha256), sort_keys=True))


if __name__ == '__main__':
    main()
