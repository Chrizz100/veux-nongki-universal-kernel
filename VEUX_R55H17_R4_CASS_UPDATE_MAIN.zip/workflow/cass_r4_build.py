#!/usr/bin/env python3
"""Independent CASS candidate build from the authenticated final R5S2 source."""
from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tarfile

CONFIG_SHA = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
SYMVERS_SHA = '6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec'
DTB_SHA = '42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37'
RELEASE = '5.4.274-qgki-g82179e362f33'
DTB_REL = 'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb'
BAKASU_PARENT = 'd5e9e025b8b49155f8014684d64c91742b465f65'
TAG_COMMIT = '239e1e8871b8fcd51a6e5b3002e0ba522fdd99fb'
CRITICAL = {'CONFIG_SCHED_CASS': 'y', 'CONFIG_SCHED_WALT': 'n',
            'CONFIG_NR_CPUS': '8', 'CONFIG_MODULES': 'y', 'CONFIG_MODVERSIONS': 'y',
            'CONFIG_CFI_CLANG': 'y', 'CONFIG_LTO_CLANG': 'y',
            'CONFIG_STACKPROTECTOR_STRONG': 'y', 'CONFIG_KSU': 'y',
            'CONFIG_KSU_SUSFS': 'y', 'CONFIG_NOMOUNT': 'y'}
HOST_PATHS = {
    'block/ioprio.c', 'drivers/Kconfig', 'drivers/Makefile', 'drivers/kernelsu',
    'drivers/input/input.c', 'fs/Kconfig', 'fs/Makefile', 'fs/exec.c', 'fs/open.c',
    'fs/read_write.c', 'fs/namei.c', 'fs/namespace.c', 'fs/notify/fdinfo.c',
    'fs/proc/base.c', 'fs/proc/cmdline.c', 'fs/proc/fd.c', 'fs/proc/task_mmu.c',
    'fs/proc_namespace.c', 'fs/readdir.c', 'fs/stat.c', 'fs/statfs.c', 'fs/super.c',
    'fs/susfs.c', 'include/linux/mount.h', 'include/linux/susfs.h',
    'include/linux/susfs_def.h', 'include/linux/ksu_hook_contract.h',
    'kernel/kallsyms.c', 'kernel/sys.c', 'kernel/reboot.c', 'kernel/module.c',
    'mm/memory.c', 'security/selinux/hooks.c', 'security/selinux/selinuxfs.c',
}


class BuildBlocked(RuntimeError):
    pass


def need(condition, message):
    if not condition:
        raise BuildBlocked(message)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def dump(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def config_values(text: str) -> dict:
    result = {}
    for line in text.splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key, value = line.split('=', 1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            key, value = line[2:-11], 'n'
        else:
            continue
        need(key not in result, 'DUPLICATE_CONFIG:' + key)
        result[key] = value
    return result


def check_config(original: str, candidate: str) -> dict:
    old, new = config_values(original), config_values(candidate)
    changes = {k: [old.get(k, 'n'), new.get(k, 'n')]
               for k in old.keys() | new.keys() if old.get(k, 'n') != new.get(k, 'n')}
    need(all(k.startswith('CONFIG_KSU_') for k in changes), 'NON_KSU_CONFIG_CHANGED:' + ','.join(changes))
    for key, value in CRITICAL.items():
        need(new.get(key, 'n') == value, 'CRITICAL_CONFIG_CHANGED:' + key)
    for key, value in old.items():
        if key.startswith('CONFIG_KSU_') and value == 'y':
            need(new.get(key, 'n') == 'y', 'EXISTING_KSU_FEATURE_DROPPED:' + key)
    for key in ('CONFIG_KSU_NO_PREINIT', 'CONFIG_KSU_TRACEPOINT_HOOK', 'CONFIG_KSU_MANUAL_HOOK',
                'CONFIG_KSU_DISABLE_MANAGER'):
        need(new.get(key, 'n') == 'n', 'FORBIDDEN_HOOK_OR_PREINIT_CONFIG:' + key)
    return changes


def inventory(root: Path, normalize_links=False) -> dict:
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(x for x in dirs if x != '.git')
        for name in sorted(dirs + files):
            path = Path(directory) / name
            relative = path.relative_to(root).as_posix()
            info = path.lstat()
            if stat.S_ISLNK(info.st_mode):
                target = os.readlink(path)
                resolved = (path.parent / target).resolve()
                if normalize_links and resolved.is_relative_to(root):
                    target = 'INTERNAL:' + resolved.relative_to(root).as_posix()
                result[relative] = {'type': 'link', 'target': target}
            elif stat.S_ISREG(info.st_mode):
                result[relative] = {'type': 'file', 'mode': stat.S_IMODE(info.st_mode),
                                    'sha256': digest(path)}
            else:
                need(stat.S_ISDIR(info.st_mode), 'SPECIAL_SOURCE_FILE:' + relative)
    return result


def copy_source(original: Path, candidate: Path) -> list:
    need(not candidate.exists(), 'CANDIDATE_ALREADY_EXISTS')
    shutil.copytree(original, candidate, symlinks=True)
    relocations = []
    for directory, dirs, files in os.walk(candidate, followlinks=False):
        dirs[:] = [x for x in dirs if x != '.git']
        for name in dirs + files:
            path = Path(directory) / name
            if not path.is_symlink():
                continue
            relative = path.relative_to(candidate)
            source_link = original / relative
            source_target = source_link.resolve()
            need(source_target.is_relative_to(original), 'EXTERNAL_SOURCE_SYMLINK:' + str(relative))
            wanted = candidate / source_target.relative_to(original)
            target = os.path.relpath(wanted, path.parent)
            if os.readlink(path) != target:
                relocations.append({'path': str(relative), 'old': os.readlink(path), 'new': target})
                path.unlink()
                path.symlink_to(target)
    need(inventory(original, True) == inventory(candidate, True), 'COPIED_SOURCE_NOT_IDENTICAL')
    return relocations


def source_delta(before: dict, after: dict) -> list:
    changes = sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))
    for name in changes:
        allowed = name in HOST_PATHS or name.startswith(('KernelSU/', 'fs/nomount/'))
        need(allowed, 'PROTECTED_SOURCE_CHANGED:' + name)
    need(changes, 'PORT_DID_NOT_CHANGE_SOURCE')
    return changes


def invoke(args, log: Path, env=None, timeout=10800) -> None:
    log.parent.mkdir(parents=True, exist_ok=True)
    with log.open('wb') as stream:
        status = subprocess.run([str(x) for x in args], stdout=stream,
                                stderr=subprocess.STDOUT, env=env, timeout=timeout, check=False)
    need(status.returncode == 0, 'COMMAND_FAILED:' + log.name + ':' + str(status.returncode))


def git(root: Path, *args) -> str:
    proc = subprocess.run(['git', '-C', str(root), *args], capture_output=True,
                          text=True, timeout=180, check=False)
    need(proc.returncode == 0, 'GIT_FAILED:' + ' '.join(args))
    return proc.stdout.strip()


def validate_version(root: Path, declared: dict) -> dict:
    need((root / '.git').is_dir() and not (root / '.git/shallow').exists(), 'BAKASU_FULL_HISTORY_REQUIRED')
    commit = git(root, 'rev-parse', 'HEAD')
    parent = git(root, 'rev-parse', 'HEAD^')
    count = int(git(root, 'rev-list', '--count', 'HEAD'))
    version = 30700 + count
    need(parent == BAKASU_PARENT and count == 4553, 'BAKASU_GENUINE_PORT_HISTORY_CHANGED')
    need(declared.get('commit') == commit and declared.get('count') == count
         and declared.get('version') == version, 'PORT_VERSION_REPORT_MISMATCH')
    need(git(root, 'rev-parse', 'refs/tags/v4.2.0-rc3^{commit}') == TAG_COMMIT,
         'BAKASU_GENUINE_TAG_CHANGED')
    need(git(root, 'describe', '--abbrev=0', '--tags') == 'v4.2.0-rc3', 'BAKASU_TAG_DESCRIBE_CHANGED')
    need(not git(root, 'status', '--porcelain', '--untracked-files=all'), 'BAKASU_CANDIDATE_DIRTY')
    return {'commit': commit, 'parent': parent, 'count': count, 'version': version,
            'tag': 'v4.2.0-rc3'}


def check_outputs(candidate: Path, obj: Path, baseline_config: str, version: dict, evidence: Path) -> dict:
    config = (obj / '.config').read_text()
    changes = check_config(baseline_config, config)
    release = (obj / 'include/config/kernel.release').read_text().strip()
    need(release == RELEASE, 'KERNEL_RELEASE_CHANGED')
    image = obj / 'arch/arm64/boot/Image'
    data = image.read_bytes()
    need(len(data) > 1024 * 1024 and data[56:60] == b'ARM\x64', 'INVALID_ARM64_IMAGE')
    start = data.find(b'IKCFG_ST')
    stop = data.find(b'IKCFG_ED', start + 8)
    need(start >= 0 and stop > start, 'EMBEDDED_CONFIG_MISSING')
    embedded = gzip.decompress(data[start + 8:stop])
    need(embedded == (obj / '.config').read_bytes(), 'IMAGE_CONFIG_NOT_ACTUAL_BUILD_CONFIG')
    format_value = config_values(config).get('CONFIG_KSU_FULL_NAME_FORMAT')
    need(format_value is not None, 'GENUINE_BAKASU_VERSION_FORMAT_MISSING')
    full_name = json.loads(format_value)
    replacements = {'%TAG_NAME%': version['tag'], '%COMMIT_SHA%': version['commit'][:8],
                    '%REPO_NAME%': 'BakaSU', '%KSU_VERSION%': str(version['version']),
                    '%BRANCH_NAME%': git(candidate / 'KernelSU', 'branch', '--show-current')}
    for token, value in replacements.items():
        full_name = full_name.replace(token, value)
    need(not re.search(r'%[A-Z_]+%', full_name), 'UNKNOWN_BAKASU_VERSION_FORMAT_TOKEN')
    marker = full_name.encode()
    need(marker and marker in data, 'BAKASU_IMAGE_IDENTITY_MISSING')
    version_marker_occurrences = data.count(marker)
    command = (obj / 'drivers/kernelsu/core/.init.o.cmd').read_text(errors='replace')
    need('-DKSU_VERSION=' + str(version['version']) in command, 'REAL_BAKASU_VERSION_NOT_COMPILED')
    need(digest(obj / DTB_REL) == DTB_SHA, 'DEVICE_DTB_CHANGED')
    symbols = (obj / 'System.map').read_text()
    for symbol in ('cass_select_task_rq_rt', 'cass_select_task_rq_fair',
                   'ksu_handle_setuid', 'susfs_spoof_uname', 'nomount_init',
                   'susfs_set_priority_uid_filter', 'susfs_parse_priority_app_strings'):
        need(re.search(r'\b' + re.escape(symbol) + r'(?:\b|\$)', symbols), 'LINKED_PROVIDER_MISSING:' + symbol)
    need(not re.search(r'\b(?:walt_update_task_ravg|walt_irq_work|walt_init)\b', symbols), 'WALT_LINKED_IN_CASS_IMAGE')
    required = ('fs/susfs.o', 'fs/nomount/nomount.o', 'drivers/kernelsu/core/init.o',
                'drivers/kernelsu/built-in.a', 'drivers/kernelsu/preinit/preinit.o',
                'drivers/kernelsu/preinit/runner.elf', 'drivers/kernelsu/preinit/blob.o',
                'drivers/kernelsu/manager/throne_tracker.o',
                'security/selinux/flask.h', 'security/selinux/av_permissions.h',
                'include/generated/compile.h', 'vmlinux', 'Module.symvers', 'System.map')
    for name in required:
        need((obj / name).is_file() and (obj / name).stat().st_size > 0, 'COMPILED_OUTPUT_MISSING:' + name)
    # Reuse the original audited 132-import RMNET gate; KSU-only config additions
    # are reviewed above, so only the old byte-for-byte config-hash check is replaced.
    from cass_reference_gate import audit as reference_audit
    abi, rows = reference_audit(obj / '.config', obj / 'Module.symvers', release,
                                DTB_SHA, require_config_sha=False)
    dump(evidence / 'RMNET_132_ABI.json', {'report': abi, 'imports': rows})
    need(not abi['failures'] and abi['rmnet_imports_matched'] == 132, 'RMNET_REFERENCE_ABI_CHANGED')
    files = ['arch/arm64/boot/Image', DTB_REL, '.config', 'Module.symvers', 'System.map']
    hashes = {p: {'sha256': digest(obj / p), 'bytes': (obj / p).stat().st_size} for p in files}
    validate_version(candidate / 'KernelSU', version)
    return {'config_changes': changes, 'rmnet_imports_matched': 132, 'outputs': hashes,
            'release': release, 'embedded_config_matches': True, 'cass_linked': True,
            'bakasu_version_marker': full_name,
            'bakasu_version_marker_occurrences': version_marker_occurrences}



def compile_candidate(candidate: Path, obj: Path, baseline_config: Path, state: dict,
                      version: dict, evidence: Path, jobs: int,
                      baseline_work: Path | None = None) -> dict:
    """Real native compilation; independently usable after a source-only replay.

    This function never claims that a local baseline compilation occurred.
    Callers must record whether baseline_config came from the current genuine
    worker or an authenticated historical artifact.
    """
    candidate = Path(candidate).resolve(strict=True)
    baseline_config = Path(baseline_config).resolve(strict=True)
    obj = Path(obj).resolve()
    evidence = Path(evidence).resolve()
    need(not obj.exists() and not obj.is_relative_to(candidate), 'FRESH_SEPARATE_OBJECT_TREE_REQUIRED')
    need(digest(baseline_config) == CONFIG_SHA, 'UNVERIFIED_BASELINE_CONFIG_INPUT')
    need(1 <= jobs <= 12, 'UNSAFE_JOBS')
    validate_version(candidate / 'KernelSU', version)
    obj.mkdir(parents=True)
    evidence.mkdir(parents=True, exist_ok=True)
    report = {'status': 'BLOCKED', 'native_compile_completed': False,
              'static_gates_passed': False, 'baseline_compiled_by_this_function': False,
              'device_test': False, 'flash_allowed': False}
    try:
        config_text = baseline_config.read_text()
        shutil.copy2(baseline_config, obj / '.config')
        variables = dict(v.split('=', 1) for v in state['variables'])
        need(variables.get('ARCH', state.get('env', {}).get('ARCH')) == 'arm64'
             and 'O' in variables, 'INHERITED_KBUILD_VARIABLES_INVALID')
        variables['O'] = str(obj)
        old_kcflags = variables.get('KCFLAGS', state.get('env', {}).get('KCFLAGS', ''))
        variables['KCFLAGS'] = (old_kcflags + ' -I' + str(obj / 'security/selinux')).strip()
        env = dict(os.environ, **state['env'])
        env.pop('VEUX_CAPTURE', None)
        forbidden = ('KSU_NO_PREINIT', 'KSU_VERSION', 'KSU_LOCAL_VERSION',
                     'KSU_COMMIT_SHA', 'KSU_TAG_NAME')
        need(not any(key in variables or env.get(key) for key in forbidden),
             'FORBIDDEN_BAKASU_BUILD_OVERRIDE')
        if baseline_work is not None:
            wrapper = str(Path(baseline_work) / 'source-temp/bin')
            env['PATH'] = os.pathsep.join(p for p in env['PATH'].split(os.pathsep) if p != wrapper)
        command = ['/usr/bin/make', '-C', str(candidate)] + [f'{k}={v}' for k, v in variables.items()]
        dump(evidence / 'BUILD_COMMAND.json', {'variables': variables, 'jobs': jobs,
             'source': str(candidate), 'original_captured_env': state['env']})
        invoke([*command, 'olddefconfig'], evidence / 'OLDDEFCONFIG.log', env, 600)
        dump(evidence / 'CONFIG_DELTA.json', check_config(config_text, (obj / '.config').read_text()))
        for target, label in [('init/version.o', 'NATIVE_COMPILE_H'),
                              ('security/selinux/', 'NATIVE_SELINUX_HEADERS')]:
            invoke([*command, f'-j{jobs}', target], evidence / (label + '.log'), env, 2400)
        invoke([*command, f'-j{jobs}', 'Image', 'dtbs', 'modules'], evidence / 'FULL_BUILD.log', env, 10800)
        report['native_compile_completed'] = True
        proof = check_outputs(candidate, obj, config_text, version, evidence)
        report.update(status='NATIVE_CASS_BUILD_AND_STATIC_ABI_PASS_NOFLASH',
                      static_gates_passed=True, proof=proof)
        return proof
    except Exception as error:
        report['blocker'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        report['kernel_image_generated'] = (obj / 'arch/arm64/boot/Image').is_file()
        dump(evidence / 'NATIVE_BUILD_RESULT.json', report)


def run_update(kernel: Path, state: dict, baseline_work: Path, jobs: int) -> dict:
    kernel = Path(kernel).resolve(strict=True)
    baseline_work = Path(baseline_work).resolve(strict=True)
    temporary = Path(os.environ['RUNNER_TEMP']).resolve(strict=True)
    payload = Path(os.environ['R4_PAYLOAD']).resolve(strict=True)
    stage = temporary / 'veux-r55h17-r4'
    need(not stage.exists(), 'R4_STAGE_ALREADY_EXISTS')
    need(kernel.is_relative_to(baseline_work) and baseline_work.is_relative_to(temporary), 'BASELINE_OUTSIDE_RUNNER_TEMP')
    need(kernel.name == 'kernel' and baseline_work.name == '5.4.274', 'BASELINE_LAYOUT_CHANGED')
    need(1 <= jobs <= 12, 'UNSAFE_JOBS')
    stage.mkdir()
    evidence = stage / 'evidence'
    evidence.mkdir()
    result = {'schema': 1, 'status': 'BLOCKED', 'compiler_test': False,
              'source_updates_staged': False, 'kernel_image_generated': False,
              'flash_allowed': False, 'device_test': False, 'raw_exported': False}
    original_inventory = None
    original_git_heads = None
    try:
        old_obj = baseline_work / 'build'
        need(digest(old_obj / '.config') == CONFIG_SHA, 'BASELINE_CONFIG_HASH_CHANGED')
        need(digest(old_obj / 'Module.symvers') == SYMVERS_SHA, 'BASELINE_ABI_HASH_CHANGED')
        need(digest(old_obj / DTB_REL) == DTB_SHA, 'BASELINE_DTB_HASH_CHANGED')
        need((old_obj / 'include/config/kernel.release').read_text().strip() == RELEASE, 'BASELINE_RELEASE_CHANGED')
        config_text = (old_obj / '.config').read_text()
        check_config(config_text, config_text)
        original_inventory = inventory(kernel)
        original_git_heads = {name: git(kernel / name, 'rev-parse', 'HEAD')
                              for name in ('.', 'KernelSU')}
        dump(evidence / 'BASELINE_SOURCE_INVENTORY.json', original_inventory)
        dump(evidence / 'BASELINE_BUILD_FINGERPRINTS.json', {
            'source': str(kernel), 'config_sha256': CONFIG_SHA, 'symvers_sha256': SYMVERS_SHA,
            'dtb_sha256': DTB_SHA, 'kernelrelease': RELEASE,
            'kernel_git_head': original_git_heads['.'],
            'bakasu_git_head': original_git_heads['KernelSU'],
            'source_inventory_sha256': digest(evidence / 'BASELINE_SOURCE_INVENTORY.json')})
        shutil.copy2(old_obj / '.config', evidence / 'BASELINE.config')
        shutil.copy2(old_obj / 'Module.symvers', evidence / 'BASELINE.Module.symvers')
        shutil.copy2(old_obj / 'System.map', evidence / 'BASELINE.System.map')
        # Preserve the final source plus real Git metadata before the old worker's
        # cleanup. The port is never run against this source or this archive.
        snapshot = stage / 'R5S2_FINAL_CASS_SOURCE.tar.gz'
        with tarfile.open(snapshot, 'w:gz', compresslevel=1, dereference=False) as archive:
            archive.add(kernel, arcname='kernel')
        dump(evidence / 'BASELINE_SNAPSHOT.json', {'name': snapshot.name,
             'sha256': digest(snapshot), 'bytes': snapshot.stat().st_size,
             'contains_real_git_history': True, 'source_files': len(original_inventory)})
        candidate = stage / 'source/kernel'
        candidate.parent.mkdir()
        dump(evidence / 'SYMLINK_RELOCATIONS.json', copy_source(kernel, candidate))
        copied_inventory = inventory(candidate, True)
        port_out = evidence / 'port'
        invoke([sys.executable, '-B', payload / 'cass_source_port.py',
                '--baseline', kernel, '--kernel', candidate,
                '--bakasu', temporary / 'BakaSU35252',
                '--nomount-old', temporary / 'NoMountR5S2',
                '--nomount-new', temporary / 'NoMount22',
                '--payload', payload, '--out', port_out], evidence / 'SOURCE_PORT.log', timeout=1800)
        port = json.loads((port_out / 'PORT_RESULT.json').read_text())
        need(port.get('status') == 'PORT_SOURCE_PASS' and port.get('source_updates_staged') is True
             and port.get('flash_allowed') is False and port.get('device_test') is False, 'SOURCE_PORT_NOT_PROVEN')
        changes = source_delta(copied_inventory, inventory(candidate, True))
        dump(evidence / 'SOURCE_DELTA.json', changes)
        need(inventory(kernel) == original_inventory, 'ORIGINAL_BASELINE_CHANGED_BY_PORT')
        version = validate_version(candidate / 'KernelSU', port.get('bakasu_version', {}))
        result.update(source_updates_staged=True, bakasu_version=version)
        obj = stage / 'build'
        proof = compile_candidate(candidate, obj, old_obj / '.config', state,
                                  version, evidence, jobs, baseline_work)
        result.update(compiler_test=True, kernel_image_generated=True)
        result.update(proof)
        need(inventory(kernel) == original_inventory, 'ORIGINAL_BASELINE_CHANGED_DURING_BUILD')
        raw = stage / 'raw-passed'
        raw.mkdir()
        for original, name in [('arch/arm64/boot/Image', 'Image'), (DTB_REL, 'veux.dtb'),
                               ('.config', 'actual-build.config'), ('Module.symvers', 'Module.symvers'),
                               ('System.map', 'System.map')]:
            shutil.copy2(obj / original, raw / name)
        (raw / 'READ_ME_NO_FLASH.txt').write_text('Raw CASS compiler/ABI evidence. No boot.img or installer. Device boot untested. No flash approval.\n')
        result.update(status='CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH',
                      kernel_image_generated=True, raw_exported=True,
                      original_baseline_unchanged=True)
        dump(raw / 'R4_RESULT.json', result)
        (raw / 'SHA256SUMS').write_text(''.join(digest(p) + '  ' + p.name + '\n'
                                              for p in sorted(raw.iterdir()) if p.is_file()))
    except Exception as error:
        result.update(status='BLOCKED', blocker=type(error).__name__ + ': ' + str(error), raw_exported=False)
        raise
    finally:
        native_report = evidence / 'NATIVE_BUILD_RESULT.json'
        if native_report.is_file():
            native = json.loads(native_report.read_text())
            result['compiler_test'] = native.get('native_compile_completed') is True
            result['kernel_image_generated'] = native.get('kernel_image_generated') is True
        if original_inventory is not None:
            unchanged = inventory(kernel) == original_inventory
            if original_git_heads is not None:
                unchanged = unchanged and all(git(kernel / name, 'rev-parse', 'HEAD') == head
                                              for name, head in original_git_heads.items())
            result['original_baseline_unchanged'] = unchanged
            if not unchanged:
                result.update(status='BLOCKED', raw_exported=False,
                              blocker='ORIGINAL_BASELINE_SOURCE_CHANGED')
        dump(evidence / 'R4_RESULT.json', result)
        print('R55H17_R4_STATUS=' + result['status'] + '; FLASH=NO', flush=True)
        if result.get('original_baseline_unchanged') is False:
            raise BuildBlocked('ORIGINAL_BASELINE_SOURCE_CHANGED')
    return result
