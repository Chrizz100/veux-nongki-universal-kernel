#!/usr/bin/env python3
"""VEUX R55H17 offline proof: CASS baseline, unchanged module ABI, no flash.
Strict audit only; cannot attest to device boot or sign an image.
"""
import argparse
import base64
import csv
import hashlib
import json
from pathlib import Path
import sys
import zlib

CONFIG_SHA256 = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
EXPECTED_RELEASE = '5.4.274-qgki-g82179e362f33'
EXPECTED_DTB_SHA256 = '42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37'
REFERENCE = json.loads(zlib.decompress(base64.b64decode('eNqdWNty6zYM/Jfz3AeSIinyWzodDnizVVuXSHJy3K8vJMqxHFG225eMndm1SAALLPTnn7/6ugmjGY7Drz9+GQPnc+tMF3rXXfAf5LfmOpYFZ7/++iOPHU52BhJtpSaMZ4AuVmY4t18djMcZy5zXJHifw3YX0zbnqgmmhuE0w6mUjHsZduBdOwyVPa8IKhSRUAoZwqmejz3DgmVFAVxkYOdqGA14bz7hXPkZLVUsqLN+D+3D2YRm7K8rTqCiKJnIPqF1cDb2iByYDl91M6NwRXSh0BlGPQQ3mLE1f1cxVmGY8WUkjCoVM3jMYgpnjEMYEzo4Swi1GXTvLqYP4KeDLVH0grGS8mfgS/MNZ1xqRUnuJFgj5oDfjzCkAuCKFKGgag87tGYIhxrDmU5SChuIyBXAMII7GXc8mQjVeUZHEn2Uzj5FHy7QpxypKEtlSZmDf5njV6gOx1HypIbIpQs+c+4evszQVc0cPkzrDLeFLIQl9BW86j8G+AwzR9BSEk3LJ5wU9NtDuHacgniDgI/pwzC2fXpSoSgjgmxVkoT91fanj0u4JLCPmhHlyAbsoHFY+Vj9cA1+Zpnh2iwKKwqlPVd7rEc0IY5ICduCc20zXOrw3WuUp5QSuZXVVO7NpbahT+UODGJpeQ4X+/Axy+OwaEOpYDHwkAMPP6QBhEfNxTPsShlURcscbJXxELSxqlGwsUliYlYU1BYZyjD27fVHdjAxhWfEbeE9YP4fwVAoSbAFb8AYkmA6OCythReEeRLsDu4+I5wOjgdGc8AP89EOcyfFzxc8fJIoLQsMkt9n9KFuP8MDiYTAvSdPSJfOw/hIco5oDWI7vw6hOSPygK17CjvU1fmaKh0jqUMMecalyXKEIKWiIsuph4PpLuk4MmB30pD78dH8E/oWq2HKwNLItBVeb6vs2KdiATdWS9uw4FjkRO5ik+JSPRJbOin9Lja2/detPQovQqGs2AVXTTXeGhGlXrJdJHbffsSu1ByCaVKNBUk4Z3wrjelXTbNI0wOK3UaaR6UfP4UlFSVngqnteavuU2IHqToTfo9H3y8NXWFZue3zT1ORp7IrSiDOQh7y3ZMo8egnyPb2i+PABLjjoqzAJQ86o+5THeoENHebItEOEG63luA03XwerNhxzmYcblMqOOlAb2th9ilD2y/SsMDBhu0p8BCuuy6DmmngZchhbqbCO1tKDttyqlt/QWeDPa5dyt/GSHmU26vgpyriNVzAgv6OqY5WQIy78N/pHpKVGqjbRZmmSpehzhWUhhwQHSdO1L4F72BpHdYKS5WOu/BLU93B0kUb7LZEmzOYVUAj9ZaWhGdxty5BXABgmU7XQQ+1gb6Hq2m7VEzaxsBDZDtghKFEb4cErGX9DHq5YQkpQUpOn2GxRJtDygGAdqUqnqJv4AL9vC/ENgYdCqruRuPaSzPb7xQyxjT2CMjA8bBpxDqhBDp+ksFM0kN9jIuaqSzA5UIwAeuTr5bGQAsbrY15HJa+uQyLy7AlIzTqbcf5qCuTvs858GiSbsMjTW3ghdOyfE18oJW0pC6yDG0a8Y9OrE12oiicCuitdihrKGpJoOi2yelDTHnB0dCYAcZL/x1UpqXUImY4y6zEf/nwWTls/C2Kslqu4pkHSjL+8JvYtvUjRTLmSs1YhjI7hjk/8x6Wbk688wy2hZk+T82zuzXEktAA1LsdbDWkPosX+U5IWPY85jkRGfWnzzV0xp9zJQCS4uqRMZIb4gMNXRCjQasdGn6e96h7GADjrEQQzwhf1ejSSqGswialts6vH9ECfftaVwLHpufzsJUBlgElEjMtajqka7ursdW47LNoDHlJiizUh1Sv423VK0pLvcjU9dDGcfqGfhDSlVD2WrFtANBOn2/NWWBhRZUpRwQ1rk4bugDNKI6RLeiK+anN10fSkcfdR/jtRVYOckcVGtMrWcbLragbXThJy6jYunhx8T/jQHv7Hcwa/94LkDXjrRcIWcLzlwhrynvbfp7xdONfUd7d5HOUl5v5nfTUYK5gb7nHNf49B7liYHGPLc7y5f2TmrbwfBm9Zeju8Dfdyk/C1JNX1qIAQoiF8gnjtRlZMZ6ahjvufwzvJ+RXA/xO/R8jc0Wev8ceDpMNQCudODwIqeTDerrDGVxfdWPbz9Kf/jfg37ZeGp8K1Gv76leOqGk8fzemhzMbNdGevaJl9zOhC2xqO9p4b4T/xP+nYfyE/Gog/6R2oY/YiKb3MaFJjYhbVaJxFK9YU15Wwzxiu3AS5BMablJXh1L9kdb01Bg9eJqnv5h0d+B/GWN//QvdVCqM')).decode('utf-8'))
FEATURES = {
    'CONFIG_SCHED_CASS': 'y', 'CONFIG_SCHED_WALT': 'n',
    'CONFIG_NR_CPUS': '8', 'CONFIG_MODULES': 'y',
    'CONFIG_MODVERSIONS': 'y', 'CONFIG_CFI_CLANG': 'y',
    'CONFIG_LTO_CLANG': 'y', 'CONFIG_LOCALVERSION': '"-qgki"',
    'CONFIG_KSU': 'y', 'CONFIG_KSU_SUSFS': 'y',
}


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while True:
            data=f.read(1048576)
            if not data:break
            h.update(data)
    return h.hexdigest()


def parse_config(text):
    out={}
    for line in text.splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key,val=line.split('=',1)
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            key,val=line[2:].split(' is not set',1)[0],'n'
        else:continue
        if key in out:raise ValueError('DUPLICATE_CONFIG_KEY:'+key)
        out[key]=val
    return out


def parse_symvers(text):
    out={}
    for line in text.splitlines():
        parts=line.split()
        if len(parts)<4:raise ValueError('MALFORMED_SYMVERS_LINE:'+line[:60])
        crc,name=parts[:2]
        if not crc.startswith('0x'):raise ValueError('SYMVERS_MISSING_CRC:'+name)
        crc=f'0x{int(crc,16):08x}'
        if name in out and out[name]!=crc:raise ValueError('SYMVERS_DUPLICATE_DIFFERENT_CRC:'+name)
        out[name]=crc
    return out


def audit(config_file, symvers_file, release, dtb_sha256=None, require_config_sha=True):
    failures=[]
    conf_path=Path(config_file)
    cfg=parse_config(conf_path.read_text(encoding='utf-8'))
    sym=parse_symvers(Path(symvers_file).read_text(encoding='utf-8'))
    for key,expected in FEATURES.items():
        if cfg.get(key,'n')!=expected:
            failures.append(f'CONFIG_MISMATCH:{key}:expected={expected}:got={cfg.get(key,"n")}')
    actual_cfg_sha=sha256(conf_path)
    if require_config_sha and actual_cfg_sha!=CONFIG_SHA256:
        failures.append('FULL_REFERENCE_CONFIG_SHA_MISMATCH')
    if release.strip()!=EXPECTED_RELEASE:
        failures.append('KERNEL_RELEASE_MISMATCH')
    if dtb_sha256 is not None and dtb_sha256.lower()!=EXPECTED_DTB_SHA256:
        failures.append('VEUX_DTB_SHA_MISMATCH')
    crc_rows=[]
    for mod,name,expected in REFERENCE:
        actual=sym.get(name)
        status='MATCH' if actual==expected else ('MISSING' if actual is None else 'CRC_MISMATCH')
        crc_rows.append({'module':mod,'symbol':name,'original_module_crc':expected,'candidate_crc':actual or '', 'status':status})
        if status!='MATCH':failures.append(f'RMNET_{status}:{mod}:{name}')
    report={
        'schema':1, 'stage':'R55H17_R1_CASS_1TO1_REFERENCE_GATE',
        'status':'CASS_REFERENCE_STATIC_PASS_NOFLASH' if not failures else 'BLOCKED_CASS_REFERENCE_OR_VENDOR_ABI',
        'kernel_release':release.strip(), 'config_sha256':actual_cfg_sha,
        'config_reference_sha256':CONFIG_SHA256,
        'dtb_sha256_reported':dtb_sha256,
        'critical_config':{k:cfg.get(k,'n') for k in FEATURES},
        'rmnet_imports_count':len(crc_rows),
        'rmnet_imports_matched':sum(x['status']=='MATCH' for x in crc_rows),
        'rmnet_module_layout_crc':sym.get('module_layout'),
        'failures':failures, 'flash_allowed':False,
        'device_test':False,
        'new_bakasu_35252_integrated':False,
        'new_nomount_v22_integrated':False,
        'walt_porting_in_this_stage':False,
    }
    return report,crc_rows


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--config',required=True)
    ap.add_argument('--symvers',required=True)
    ap.add_argument('--release-file',required=True)
    ap.add_argument('--dtb-sha256')
    ap.add_argument('--report-dir',required=True)
    ns=ap.parse_args()
    report,rows=audit(ns.config,ns.symvers,Path(ns.release_file).read_text(),ns.dtb_sha256)
    d=Path(ns.report_dir)
    d.mkdir(parents=True,exist_ok=True)
    (d/'R55H17_R1_CASS_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    with (d/'R55H17_R1_RMNET_132_ABI.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
    print(f'R55H17_R1_CASS_GATE={report["status"]}; RMNET={report["rmnet_imports_matched"]}/{len(rows)}; NO_FLASH')
    if report['failures']:
        for msg in report['failures'][:24]:print('BLOCKER:',msg)
        raise SystemExit(26)

if __name__=='__main__':main()
