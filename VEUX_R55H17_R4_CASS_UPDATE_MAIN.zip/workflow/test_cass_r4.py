#!/usr/bin/env python3
"""Gate/negative regressions for isolation and authentic CASS compiler handoff."""
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import cass_r4_bridge as bridge
import cass_r4_build as build
import extract_payload


class Gates(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.config = '\n'.join(k + '=' + v for k, v in build.CRITICAL.items() if v != 'n') + '\n'

    def tearDown(self):
        self.temp.cleanup()

    def test_baseline_config_accepted(self):
        self.assertEqual(build.check_config(self.config, self.config), {})

    def test_walt_is_blocked(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'NON_KSU_CONFIG'):
            build.check_config(self.config, self.config + 'CONFIG_SCHED_WALT=y\n')

    def test_cpu_count_change_is_blocked(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'NON_KSU_CONFIG'):
            build.check_config(self.config, self.config.replace('CONFIG_NR_CPUS=8', 'CONFIG_NR_CPUS=32'))

    def test_new_real_ksu_config_is_allowed(self):
        new = self.config + 'CONFIG_KSU_FULL_NAME_FORMAT="%TAG_NAME%-%COMMIT_SHA%"\n'
        self.assertEqual(list(build.check_config(self.config, new)), ['CONFIG_KSU_FULL_NAME_FORMAT'])

    def test_existing_ksu_feature_must_remain_enabled(self):
        old = self.config + 'CONFIG_KSU_SUSFS_OPEN_REDIRECT=y\n'
        with self.assertRaisesRegex(build.BuildBlocked, 'EXISTING_KSU_FEATURE_DROPPED'):
            build.check_config(old, self.config)

    def test_preinit_cannot_be_disabled(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'FORBIDDEN_HOOK_OR_PREINIT'):
            build.check_config(self.config, self.config + 'CONFIG_KSU_NO_PREINIT=y\n')

    def test_live_package_refresh_cannot_lose_manager_component(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'FORBIDDEN_HOOK_OR_PREINIT'):
            build.check_config(self.config, self.config + 'CONFIG_KSU_DISABLE_MANAGER=y\n')

    def test_duplicate_config_is_not_last_value_wins(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'DUPLICATE_CONFIG'):
            build.config_values('CONFIG_KSU=y\nCONFIG_KSU=n\n')

    def test_not_set_config_parsing(self):
        self.assertEqual(build.config_values('# CONFIG_FOO is not set\n'), {'CONFIG_FOO': 'n'})

    def test_cass_source_changes_are_blocked(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'PROTECTED_SOURCE_CHANGED'):
            build.source_delta({'kernel/sched/fair.c': 'a'}, {'kernel/sched/fair.c': 'b'})

    def test_brene_source_changes_are_blocked(self):
        with self.assertRaisesRegex(build.BuildBlocked, 'PROTECTED_SOURCE_CHANGED'):
            build.source_delta({'drivers/brene/main.c': 'a'}, {'drivers/brene/main.c': 'b'})

    def test_existing_component_paths_are_allowed(self):
        self.assertEqual(build.source_delta({'KernelSU/kernel/a.c': 'a'},
                                           {'KernelSU/kernel/a.c': 'b'}), ['KernelSU/kernel/a.c'])

    def test_absolute_internal_ksu_link_is_independently_relocated(self):
        old = self.root / 'old'
        (old / 'KernelSU/kernel').mkdir(parents=True)
        (old / 'drivers').mkdir()
        (old / 'KernelSU/kernel/a.c').write_text('original')
        (old / 'drivers/kernelsu').symlink_to(old / 'KernelSU/kernel')
        new = self.root / 'new'
        rows = build.copy_source(old, new)
        self.assertEqual(len(rows), 1)
        (new / 'drivers/kernelsu/a.c').write_text('candidate')
        self.assertEqual((old / 'drivers/kernelsu/a.c').read_text(), 'original')

    def test_external_source_symlink_is_blocked(self):
        old = self.root / 'old'
        old.mkdir()
        (self.root / 'external').write_text('not owned')
        (old / 'unsafe').symlink_to(self.root / 'external')
        with self.assertRaisesRegex(build.BuildBlocked, 'EXTERNAL_SOURCE_SYMLINK'):
            build.copy_source(old, self.root / 'new')

    def test_worker_anchor_mutation_is_exact(self):
        worker = self.root / 'worker.py'
        original = 'def worker():\n    if True:\n' + bridge.ANCHOR
        worker.write_text(original)
        bridge.attach_hook(worker)
        self.assertEqual(worker.read_text().replace(bridge.ANCHOR + bridge.HOOK, bridge.ANCHOR), original)
        with self.assertRaisesRegex(RuntimeError, 'ANCHOR_MISSING_OR_DUPLICATED'):
            bridge.attach_hook(worker)

    def test_worker_missing_anchor_is_blocked(self):
        worker = self.root / 'worker.py'
        worker.write_text('print("no baseline proof")\n')
        with self.assertRaisesRegex(RuntimeError, 'ANCHOR_MISSING_OR_DUPLICATED'):
            bridge.attach_hook(worker)

    def test_worker_symlink_is_blocked(self):
        real = self.root / 'real.py'
        real.write_text('print(1)\n')
        worker = self.root / 'worker.py'
        worker.symlink_to(real)
        with self.assertRaisesRegex(RuntimeError, 'NOT_REGULAR'):
            bridge.attach_hook(worker)

    def make_payload(self, file_content=b'source', extra=None):
        manifest = json.dumps({'schema': 1, 'flash_allowed': False,
                               'files': {'cass_source_port.py': hashlib.sha256(b'source').hexdigest()}}).encode()
        archive = self.root / 'payload.zip'
        with zipfile.ZipFile(archive, 'w') as output:
            output.writestr('PAYLOAD_MANIFEST.json', manifest)
            output.writestr('cass_source_port.py', file_content)
            if extra:
                output.writestr(extra, 'extra')
        return archive, hashlib.sha256(manifest).hexdigest()

    def test_manifest_validated_before_extraction(self):
        archive, sha = self.make_payload()
        result = extract_payload.extract(archive, self.root / 'out', sha)
        self.assertEqual(result['status'], 'R4_PAYLOAD_AUTHENTICATED')

    def test_changed_payload_is_blocked_without_partial_output(self):
        archive, sha = self.make_payload(b'changed')
        with self.assertRaisesRegex(ValueError, 'FILE_HASH_CHANGED'):
            extract_payload.extract(archive, self.root / 'out', sha)
        self.assertFalse((self.root / 'out').exists())

    def test_unmanifested_payload_is_blocked(self):
        archive, sha = self.make_payload(extra='unreviewed.py')
        with self.assertRaisesRegex(ValueError, 'UNMANIFESTED'):
            extract_payload.extract(archive, self.root / 'out', sha)

    def test_manifest_mismatch_is_blocked(self):
        archive, _ = self.make_payload()
        with self.assertRaisesRegex(ValueError, 'MANIFEST_HASH_CHANGED'):
            extract_payload.extract(archive, self.root / 'out', '0' * 64)

    def test_completed_compile_is_not_erased_by_later_abi_failure(self):
        candidate = self.root / 'candidate'
        candidate.mkdir()
        config = self.root / 'reference.config'
        config.write_text(self.config)
        obj, evidence = self.root / 'out', self.root / 'evidence'
        state = {'variables': ['ARCH=arm64', 'O=old-output'], 'env': {}}

        def completed_make(argv, log, env=None, timeout=None):
            if 'Image' in argv:
                image = obj / 'arch/arm64/boot/Image'
                image.parent.mkdir(parents=True)
                image.write_bytes(b'actual-output-placeholder-for-control-flow-only')

        expected = hashlib.sha256(config.read_bytes()).hexdigest()
        with patch.object(build, 'CONFIG_SHA', expected), \
             patch.object(build, 'validate_version', return_value={}), \
             patch.object(build, 'invoke', side_effect=completed_make), \
             patch.object(build, 'check_outputs', side_effect=build.BuildBlocked('RMNET_REFERENCE_ABI_CHANGED')):
            with self.assertRaisesRegex(build.BuildBlocked, 'RMNET_REFERENCE_ABI_CHANGED'):
                build.compile_candidate(candidate, obj, config, state, {}, evidence, 1)
        report = json.loads((evidence / 'NATIVE_BUILD_RESULT.json').read_text())
        self.assertTrue(report['native_compile_completed'])
        self.assertTrue(report['kernel_image_generated'])
        self.assertFalse(report['static_gates_passed'])
        self.assertFalse(report['baseline_compiled_by_this_function'])
        self.assertFalse(report['flash_allowed'])


if __name__ == '__main__':
    unittest.main()
