#!/usr/bin/env python3
"""Check the exact generated YAML and its payload boundary, without a kernel build."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import yaml
import zipfile

from extract_payload import extract


def execute(command):
    result = subprocess.run([str(x) for x in command], capture_output=True, text=True, timeout=180)
    if result.returncode:
        raise RuntimeError('STATIC_CHECK_FAILED:' + repr(command) + '\n' + result.stdout + result.stderr)
    return {'command': [str(x) for x in command], 'exit': result.returncode,
            'stdout': result.stdout, 'stderr': result.stderr}


def verify(workflow: Path, actionlint: Path, package: Path | None, output: Path):
    document = yaml.safe_load(workflow.read_text())
    jobs = document['jobs']['r5s2_bakasu_522']['steps']
    results, embedded = [], []
    with tempfile.TemporaryDirectory(prefix='cass-r4-static-') as temporary:
        root = Path(temporary)
        for i, step in enumerate(jobs):
            if 'run' not in step:
                continue
            if step.get('shell') != 'bash':
                raise RuntimeError('UNREVIEWED_RUN_SHELL')
            script = root / ('step-' + str(i) + '.sh')
            script.write_text(step['run'])
            results.append(execute(['bash', '-n', script]))
            results.append(execute(['shellcheck', '--shell=bash', '--severity=error', script]))
            lines = step['run'].splitlines()
            for j, line in enumerate(lines):
                match = re.search(r"<<'(PY[A-Za-z0-9_]*)'", line)
                if not match:
                    continue
                delimiter = match.group(1)
                end = next(k for k in range(j + 1, len(lines)) if lines[k] == delimiter)
                code = '\n'.join(lines[j + 1:end]) + '\n'
                ast.parse(code)
                embedded.append({'step': i, 'delimiter': delimiter,
                                 'sha256': hashlib.sha256(code.encode()).hexdigest()})
        results.append(execute([actionlint, '-oneline', workflow]))
        if package:
            source = root / 'authenticated-payload'
            payload_result = extract(package, source, document['env']['R4_MANIFEST_SHA256'])
            companion_name = 'R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml'
            with zipfile.ZipFile(package) as archive:
                bundled_workflow_present = companion_name in archive.namelist()
                if bundled_workflow_present and archive.read(companion_name) != workflow.read_bytes():
                    raise RuntimeError('BUNDLED_AND_SEPARATE_WORKFLOW_BYTES_DIFFER')
            payload_result['bundled_workflow_present'] = bundled_workflow_present
            payload_result['bundled_workflow_bytes_match'] = True if bundled_workflow_present else None
            runtime = source / 'workflow'
            for code in source.rglob('*.py'):
                ast.parse(code.read_text(), filename=str(code))
        else:
            payload_result = {'status': 'NOT_CHECKED_FINAL_PACKAGE_NOT_SUPPLIED'}
            runtime = Path(__file__).parent
            for code in runtime.glob('*.py'):
                ast.parse(code.read_text(), filename=str(code))
        results.append(execute([sys.executable, '-B', '-m', 'unittest', 'discover',
                                '-s', runtime, '-p', 'test_cass_r4.py', '-v']))
    report = {'status': 'WORKFLOW_STATIC_CHECKS_PASS',
              'final_payload_verified': package is not None,
              'workflow_sha256': hashlib.sha256(workflow.read_bytes()).hexdigest(),
              'payload': payload_result, 'checks': results, 'embedded_python': embedded,
              'kernel_build_performed_by_this_check': False, 'flash_allowed': False}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + '\n')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--workflow', type=Path, required=True)
    parser.add_argument('--actionlint', type=Path, required=True)
    parser.add_argument('--package', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    report = verify(args.workflow, args.actionlint, args.package, args.output)
    print(json.dumps({key: report[key] for key in ('status', 'final_payload_verified', 'workflow_sha256')}, sort_keys=True))
