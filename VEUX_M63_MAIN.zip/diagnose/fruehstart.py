"""Run a paired kernel startup regression on an ARM64 virt board with a minimal PID 1."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import shutil
import stat
import struct
import subprocess
import tempfile
import time

STOCK_BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
M62_BOOT = '1d9dfbbbecce8f34aa9a409a1ca7f3c99fda702fd480557e3e3f0f7d0d320eea'
STOCK_IMAGE = '6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
M62_IMAGE = '39b3d5668e8c3117a6c5b8fcbb5e6f1c3b5e3de4890072b40f422a9fa4d040d0'
MACHINE = 'virt-8.2,gic-version=3,virtualization=on'
MARKER = re.compile(rb'(?m)^VEUX_WALT_PID1_OK\r?\n')
COMMAND_LINE = 'console=ttyAMA0 earlycon=pl011,0x09000000 loglevel=7 ignore_loglevel rdinit=/init panic=-1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def require(condition, detail):
    if not condition:
        raise ValueError(detail)

def unpack_boot(path, expected_boot=None, expected_image=None):
    boot = path.read_bytes()
    require(len(boot) == 134217728 and boot[:8] == b'ANDROID!' and struct.unpack_from('<I', boot, 40)[0] == 3,
            f'{path}: full Android v3 boot image required')
    if expected_boot:
        require(digest(boot) == expected_boot, f'{path}: baseline boot SHA-256')
    size, = struct.unpack_from('<I', boot, 8)
    require(64 <= size <= len(boot)-4096 and boot[4096+56:4096+60] == b'ARM\x64', 'ARM64 kernel required')
    kernel = boot[4096:4096+size]
    if expected_image:
        require(digest(kernel) == expected_image, f'{path}: embedded Image SHA-256')
    return kernel

def make_initramfs(work, clang):
    init = work/'pid1'
    subprocess.run([clang, '--target=aarch64-linux-gnu', '-fuse-ld=lld', '-static', '-nostdlib',
                    '-Wl,-e,_start', '-o', init, Path(__file__).with_name('pid1.S')], check=True)
    blocks = bytearray()
    def add(name, mode, ino, data=b'', major=0, minor=0):
        encoded = name.encode() + b'\0'
        fields = [ino, mode, 0, 0, 1, 0, len(data), 0, 0, major, minor, len(encoded), 0]
        blocks.extend(b'070701' + b''.join(f'{field:08x}'.encode() for field in fields) + encoded)
        blocks.extend(b'\0' * (-len(blocks)%4))
        blocks.extend(data)
        blocks.extend(b'\0' * (-len(blocks)%4))
    add('dev', stat.S_IFDIR|0o755, 1)
    add('dev/console', stat.S_IFCHR|0o600, 2, major=5, minor=1)
    add('init', stat.S_IFREG|0o755, 3, init.read_bytes())
    add('TRAILER!!!', 0, 4)
    out = work/'initramfs.cpio'
    out.write_bytes(blocks)
    return out

def boot_once(exe, firmware_dir, kernel, initrd, log_path, seed, timeout):
    cmd = [exe, '-no-user-config', '-nodefaults', '-machine', MACHINE, '-cpu', 'cortex-a76',
           '-accel', 'tcg', '-smp', '2', '-m', '1024M', '-serial', 'stdio', '-display', 'none',
           '-monitor', 'none', '-nic', 'none', '-no-reboot', '-seed', str(seed),
           '-kernel', str(kernel), '-initrd', str(initrd), '-append', COMMAND_LINE]
    if firmware_dir:
        cmd[1:1] = ['-L', str(firmware_dir)]
    output = bytearray()
    expired = False
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    try:
        with selectors.DefaultSelector() as s:
            s.register(proc.stdout, selectors.EVENT_READ)
            end = time.monotonic()+timeout
            while True:
                remaining = end-time.monotonic()
                if remaining <= 0:
                    expired = True
                    break
                if not s.select(timeout=min(remaining,0.5)):
                    continue
                chunk = os.read(proc.stdout.fileno(),65536)
                if not chunk:
                    break
                output.extend(chunk)
                if MARKER.search(output) or b'---[ end Kernel panic' in output:
                    break
                require(len(output) < 4_000_000, 'Unexpectedly large serial log')
    finally:
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
        proc.stdout.close()
        log_path.write_bytes(output)
    text = output.decode(errors='replace')
    return dict(log=log_path.name, serial_sha256=digest(output), seed=seed, timeout=expired,
                pid1=bool(MARKER.search(output)), kernel_panic='Kernel panic - not syncing' in text,
                run_init='Run /init as init process' in text, fatal_scheduler_tick=bool(
                    re.search(r'pc\s*:\s*update_task_rq_cpu_cycles\+', text)
                    and 'walt_update_task_ravg+' in text and 'scheduler_tick+' in text
                    and '0000000000000028' in text and 'Fatal exception in interrupt' in text))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', required=True, type=Path)
    parser.add_argument('--m62', required=True, type=Path)
    parser.add_argument('--candidate-boot', type=Path)
    parser.add_argument('--candidate-image', type=Path)
    parser.add_argument('--clang', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--qemu', default=shutil.which('qemu-system-aarch64'))
    parser.add_argument('--firmware-dir', type=Path)
    args = parser.parse_args()
    require(args.qemu, 'qemu-system-aarch64 missing')
    require(bool(args.candidate_boot) == bool(args.candidate_image), 'Provide both candidate boot container and linked Image')
    inputs = {'Xiaomi':unpack_boot(args.stock, STOCK_BOOT, STOCK_IMAGE),
              'M62':unpack_boot(args.m62, M62_BOOT, M62_IMAGE)}
    if args.candidate_boot:
        current = unpack_boot(args.candidate_boot)
        require(current == args.candidate_image.read_bytes() and digest(current) not in (M62_IMAGE,STOCK_IMAGE), 'Candidate from tested build')
        inputs['M63'] = current
    args.output.mkdir(parents=True, exist_ok=True)
    proof = dict(test='ARM64 scheduler startup to minimal PID 1', board=MACHINE, cpu='cortex-a76',
                 qemu_version=subprocess.check_output([args.qemu,'--version'],text=True).splitlines()[0],
                 command_line=COMMAND_LINE, android_boot_tested=False, device_pass=False, flash_allowed=False, images={})
    with tempfile.TemporaryDirectory() as temp:
        work = Path(temp)
        initrd = make_initramfs(work,args.clang)
        proof['test_ramdisk_sha256'] = digest(initrd.read_bytes())
        for label, data in inputs.items():
            path = work/(label+'.Image')
            path.write_bytes(data)
            runs = []
            for seed in (1,2) if label == 'M63' else (1,):
                runs.append(boot_once(args.qemu, args.firmware_dir, path, initrd,
                                      args.output/f'{label}-{seed}.log', seed, 55))
            proof['images'][label] = dict(image_sha256=digest(data),runs=runs)
    positive = lambda r: r['pid1'] and r['run_init'] and not r['kernel_panic'] and not r['timeout']
    base = proof['images']['M62']['runs'][0]
    passed = (all(positive(r) for r in proof['images']['Xiaomi']['runs']) and
              base['kernel_panic'] and base['fatal_scheduler_tick'] and not base['pid1'] and not base['timeout'])
    if 'M63' in proof['images']:
        passed = passed and all(positive(r) for r in proof['images']['M63']['runs'])
    proof['passed'] = passed
    (args.output/'ARM64-Fruehstart.json').write_text(json.dumps(proof,indent=2)+'\n')
    require(passed, 'Startup regression failed. See the named serial logs.')
    print('PASS', ', '.join(proof['images']), 'separate physical boot result required')

if __name__ == '__main__':
    main()
