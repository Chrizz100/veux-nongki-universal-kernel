# VEUX M63 · Reparatur des frühen WALT-Absturzes

M62 aus GitHub-Lauf 45114346742 endete auf dem POCO X4 Pro 5G in einer Bootschleife. Der vorherige Kernel startet nach dem Rückflash wieder.

Im ausgelieferten Kernel von Xiaomi HyperOS OS1.0.12.0.TKCMIXM ruft sched_init() fünf WALT-Funktionen auf. M62 enthielt die Routinen, übersprang jedoch ihre Initialisierung. Der erste Scheduler-Tick kann dadurch einen fehlenden CPU-Cluster dereferenzieren. Der ARM64-Vergleichsstart reproduziert das mit dem unveränderten GitHub-Kernel. Für die Zuordnung des gemeldeten Gerätefehlers ist ein Absturzprotokoll vom POCO erforderlich.

M63 setzt die fünf Aufrufe in der Reihenfolge und an den Stellen des Xiaomi-Quellcodes wieder ein. Der Patch ändert kernel/sched/core.c und die erforderliche Deklaration in kernel/sched/sched.h. Konfiguration, Compiler und Kernelkennung entsprechen M62.

Für GitHub die Datei VEUX_M63_MAIN.zip ins Repository-Hauptverzeichnis und VEUX_M63_WALT_START_NOFLASH.yml nach .github/workflows/ legen. Der Workflow wird manuell gestartet. Er holt Quellstand und Vergleichsimage aus dem überprüften M62-Lauf. Geräte- und Compilerdateien werden aus dem bestehenden Cache wiederverwendet. Netzwerkzugriff benötigt der GitHub-Workflow nur auf dem Build-Rechner.

Der frühe Startvergleich verwendet einen emulierten ARM64-Rechner mit zwei CPUs und einem minimalen ersten Prozess. Der Xiaomi-Kernel muss diesen Prozess erreichen. Der alte M62 muss den bekannten Fehler im Scheduler zeigen. Das aus dem neu gepackten Boot-Image entnommene Kernel-Image muss mit dem gebauten Image übereinstimmen und den ersten Prozess in beiden Testläufen erreichen. Die seriellen Protokolle und das Ergebnis liegen im Artefakt NACHWEISE. Die bisherige Prüfung der 37 QGKI-Module, der zehn Speicheranzeigen, von Millet, der Konfiguration, des Gerätebaums und des Boot-Layouts läuft zusätzlich.

Dieses Verfahren prüft weder den Qualcomm-Bootloader auf dem POCO noch das Entschlüsseln und Starten von HyperOS. Der Workflow erteilt keine Flash-Freigabe. Das AK3 bleibt ein Prüfpaket.

Xiaomi-Referenz für die Aufrufstellen
https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/kernel/sched/core.c#L6973

Ausgangslauf
https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45114346742
