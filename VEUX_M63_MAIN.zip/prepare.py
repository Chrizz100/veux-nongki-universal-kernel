"""Prepare the pinned M62 source, the factory boot and the scheduler-only repair."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = 'dd3a30ec719cf324a23298e5fb56a58d0c621fe5469a74130ab08e0ab64dbdd1'
TAR = '557dd8300935476e7e4ea87b10a9b7e343c67b397e30fa7ac16233121fbec33b'
CONFIG = 'c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54'
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
IMAGE = '39b3d5668e8c3117a6c5b8fcbb5e6f1c3b5e3de4890072b40f422a9fa4d040d0'
PATCH = '5087222b17a2ef55cc0a55f1dba16a2ffff12bd888962968d950699703263495'
FILES = {
    'kernel/sched/core.c': ('aae1031d3d3f0bb0362c3efc409e24e0cdb0ddc321d18aae0c040d8fdffde9da',
                            '7c8bb9b21ef41097be365576bbb7a2efedb866cdc9d020e4cda3bb20ec1a340b'),
    'kernel/sched/sched.h': ('acb46fea539892087c4198f49b0b4131490831d31ebc5b56a03f87c81ae4dd8e',
                             '23d4734859db56c9ea84b404466653c3eda8004a1735523f2d5b50be8f0f93df'),
}

def digest(path):
    with path.open('rb') as stream:
        h = hashlib.sha256()
        for block in iter(lambda:stream.read(1024*1024), b''):
            h.update(block)
        return h.hexdigest()

def need(ok, msg):
    if not ok:
        raise ValueError(msg)

def prepare(work, archive, stock):
    work.mkdir(parents=True, exist_ok=True)
    need(digest(archive)==SOURCE and digest(stock)==BOOT, 'Pinned M62 artifact and Xiaomi boot required')
    patch = ROOT/'veux-m63-walt-start.patch'
    need(digest(patch)==PATCH, 'Scheduler patch integrity')
    with zipfile.ZipFile(archive) as z:
        manifest = json.loads(z.read('M62_KERNEL.json'))
        need(manifest['config_sha256']==CONFIG and manifest['image_sha256']==IMAGE, 'M62 manifest')
        config = z.read('kernel.config')
        need(hashlib.sha256(config).hexdigest()==CONFIG, 'M62 config')
        tar = Path(z.extract('M62-kernel-source.tar.gz',work))
    need(digest(tar)==TAR, 'Kernel source archive')
    src = work/'src'
    src.mkdir()
    subprocess.run(['tar','--no-same-owner','--no-same-permissions','-xzf',tar,'-C',src],check=True)
    need(all(digest(src/k)==v[0] for k,v in FILES.items()), 'Unmodified M62 scheduler sources')
    subprocess.run(['git','apply','--check',patch],cwd=src,check=True)
    subprocess.run(['git','apply',patch],cwd=src,check=True)
    need(all(digest(src/k)==v[1] for k,v in FILES.items()), 'M63 source result')
    (work/'out').mkdir()
    (work/'out/.config').write_bytes(config)
    (work/'baseline.config').write_bytes(config)
    shutil.copyfile(stock,work/'boot.img')

if __name__=='__main__':
    prepare(*(Path(arg).resolve() for arg in sys.argv[1:]))
