#!/usr/bin/env python3
"""Verify the live build compiler before worker cleanup, then verify its receipt.

The historical worker removes its complete baseline work directory, including
the compiler, before the following Actions step. Never resolve a deleted PATH
again: that can silently select the runner's unrelated compiler. No compiler
pin, kernel source, build command or cleanup behavior is changed here.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

ORIGINAL_SHA256 = '2ac5586d2eb5bc806adc50b44f85dd511c899958ccb05e773cc133cd61d289cd'
SCHEMA = 'veux-r12-live-toolchain-v1'
EXPECTED_REPOSITORY = 'Chrizz100/veux-nongki-universal-kernel'
EXPECTED = {
    'clang': 'b2ce016755bddbab76549895bca07b1dc8d14a3e315b8b3567097fef04eadae1',
    'ld.lld': '51dc9705420c136f583478ac08a3258cd970710296928b3bf24dc3ee2e6208e3',
    'llvm-ar': 'dfe6c18a46138a81220768cabe385fe09a851bab05d18914fc2cd15bbbde8d4a',
    'clang-12': '5c190576d99caae4d351993a8160c092e3fe07c469fbdf6f7e36a4a9ca7c2dc5',
    'clang.real': '5c190576d99caae4d351993a8160c092e3fe07c469fbdf6f7e36a4a9ca7c2dc5',
}
RESOLVED_NAMES = {'clang': 'clang', 'ld.lld': 'lld',
                  'llvm-ar': 'llvm-ar', 'clang-12': 'clang-12', 'clang.real': 'clang-12'}
IDENTITY_KEYS = ('GITHUB_REPOSITORY', 'GITHUB_SHA', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT')
BEFORE_FILE = 'TOOLCHAIN_BEFORE_BUILD.json'
REPORT_FILE = 'BUILD_ENVIRONMENT.json'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def object_sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def identity():
    result = {key: os.environ.get(key, '') for key in IDENTITY_KEYS}
    require(result['GITHUB_REPOSITORY'] == EXPECTED_REPOSITORY,
            'TOOLCHAIN_REPOSITORY_CHANGED')
    commit = result['GITHUB_SHA']
    require(len(commit) == 40 and all(c in '0123456789abcdef' for c in commit),
            'TOOLCHAIN_BUILD_COMMIT_INVALID')
    require(all(result[key].isdigit() and int(result[key]) > 0
                for key in ('GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT')),
            'TOOLCHAIN_BUILD_RUN_IDENTITY_MISSING')
    return result


def snapshot(state, baseline_work):
    """Hash the selected live files, without accepting a system-PATH fallback."""
    baseline_work = Path(baseline_work)
    require(baseline_work.is_absolute() and baseline_work.resolve(strict=True) == baseline_work,
            'TOOLCHAIN_BASELINE_PATH_NOT_CANONICAL')
    binary_dir = baseline_work / 'source-work/toolchains/clang-r416183b/bin'
    require(binary_dir.is_dir() and binary_dir.resolve(strict=True) == binary_dir,
            'TOOLCHAIN_LIVE_DIRECTORY_MISSING_OR_RELOCATED')
    wrapper = str(baseline_work / 'source-temp/bin')
    paths = [p for p in state['env']['PATH'].split(os.pathsep) if p != wrapper]
    require(paths and paths[0] == str(binary_dir) and all(paths),
            'TOOLCHAIN_CAPTURED_PATH_CHANGED')
    variables = dict(value.split('=', 1) for value in state['variables'])
    require(variables.get('CC') == 'clang' and variables.get('LD') == 'ld.lld',
            'TOOLCHAIN_BUILD_COMMAND_COMPILER_CHANGED')
    result = {}
    for name, expected in EXPECTED.items():
        executable = binary_dir / name
        require(executable.is_file() and os.access(executable, os.X_OK),
                'TOOLCHAIN_LIVE_EXECUTABLE_MISSING:' + name)
        if name in ('clang.real', 'ld.lld'):
            require(executable.is_symlink() and os.readlink(executable) == RESOLVED_NAMES[name],
                    'TOOLCHAIN_UPSTREAM_SYMLINK_CHANGED:' + name)
        require(shutil.which(name, path=os.pathsep.join(paths)) == str(executable),
                'TOOLCHAIN_PATH_FALLBACK_FORBIDDEN:' + name)
        resolved = executable.resolve(strict=True)
        require(resolved == binary_dir / RESOLVED_NAMES[name],
                'TOOLCHAIN_EXECUTABLE_OUTSIDE_PINNED_DIRECTORY:' + name)
        observed = sha(resolved)
        require(observed == expected, 'TOOLCHAIN_EXECUTABLE_CHANGED:' + name)
        result[name] = {'resolved_path': str(resolved), 'sha256': observed,
                        'bytes': resolved.stat().st_size}
    return result


def begin(state, baseline_work, out):
    """Called inside the existing worker, before the isolated candidate update."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    require(not (out / BEFORE_FILE).exists() and not (out / REPORT_FILE).exists(),
            'TOOLCHAIN_RECEIPT_ALREADY_EXISTS')
    data = {'schema': SCHEMA, 'status': 'LIVE_TOOLCHAIN_BEFORE_BUILD_PASS',
            'runner': identity(), 'toolchain': snapshot(state, baseline_work),
            'captured_env_sha256': object_sha(state['env']),
            'producer_sha256': sha(Path(__file__)), 'device_test': False}
    (out / BEFORE_FILE).write_text(json.dumps(data, indent=2) + '\n')
    print('LIVE_TOOLCHAIN_BEFORE_CANDIDATE_BUILD=PASS', flush=True)
    return data


def finish(before, state, baseline_work, stage, out):
    """Run the original audit after compilation, while its real files exist."""
    stage, out = Path(stage), Path(out)
    require(before == json.loads((out / BEFORE_FILE).read_text()),
            'TOOLCHAIN_BEFORE_RECEIPT_CHANGED')
    require(before.get('runner') == identity(), 'TOOLCHAIN_RUN_IDENTITY_CHANGED')
    require(before.get('producer_sha256') == sha(Path(__file__)), 'TOOLCHAIN_PRODUCER_CHANGED')
    after = snapshot(state, baseline_work)
    require(before.get('toolchain') == after, 'TOOLCHAIN_CHANGED_DURING_BUILD')
    command_path = stage / 'evidence/BUILD_COMMAND.json'
    command = json.loads(command_path.read_text())
    require(command['original_captured_env'] == state['env']
            and before['captured_env_sha256'] == object_sha(state['env']),
            'TOOLCHAIN_CAPTURED_BUILD_ENV_CHANGED')
    require(command['variables'].get('CC') == 'clang'
            and command['variables'].get('LD') == 'ld.lld',
            'TOOLCHAIN_ACTUAL_BUILD_COMPILER_CHANGED')
    original_path = Path(__file__).resolve().parents[1] / 'pipeline/record_environment.py'
    require(sha(original_path) == ORIGINAL_SHA256, 'TOOLCHAIN_ORIGINAL_AUDITOR_CHANGED')
    spec = importlib.util.spec_from_file_location('r12_original_environment_auditor', original_path)
    original = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(original)
    require(original.EXPECTED == {name: EXPECTED[name] for name in ('clang', 'ld.lld', 'llvm-ar')},
            'TOOLCHAIN_ORIGINAL_PINS_CHANGED')
    original.record(stage, out)
    data = json.loads((out / REPORT_FILE).read_text())
    data.update(schema=SCHEMA, capture_phase='after_candidate_build_before_worker_cleanup',
                producer_sha256=sha(Path(__file__)), original_auditor_sha256=ORIGINAL_SHA256,
                before_receipt_sha256=sha(out / BEFORE_FILE), toolchain_before=before['toolchain'],
                toolchain_after=after, captured_env_sha256=before['captured_env_sha256'],
                installed_packages_sha256=sha(out / 'INSTALLED_PACKAGES.tsv'),
                live_before_and_after_verified=True, runner_fallback_used=False)
    (out / REPORT_FILE).write_text(json.dumps(data, indent=2) + '\n')
    verify(stage, out)
    print('LIVE_TOOLCHAIN_AFTER_CANDIDATE_BUILD_BEFORE_CLEANUP=PASS', flush=True)
    return data


def verify(stage, out):
    """Validate this run's receipt; deleted toolchain files are never resolved."""
    stage, out = Path(stage), Path(out)
    require((out / REPORT_FILE).is_file() and (out / BEFORE_FILE).is_file(),
            'TOOLCHAIN_LIVE_RECEIPTS_MISSING')
    data = json.loads((out / REPORT_FILE).read_text())
    before = json.loads((out / BEFORE_FILE).read_text())
    require(data.get('schema') == SCHEMA and data.get('status') == 'TOOLCHAIN_PINS_PASS'
            and data.get('capture_phase') == 'after_candidate_build_before_worker_cleanup'
            and data.get('live_before_and_after_verified') is True
            and data.get('runner_fallback_used') is False and data.get('device_test') is False,
            'TOOLCHAIN_LIVE_CAPTURE_NOT_PROVEN')
    require(before.get('schema') == SCHEMA and before.get('status') == 'LIVE_TOOLCHAIN_BEFORE_BUILD_PASS'
            and before.get('device_test') is False, 'TOOLCHAIN_BEFORE_CAPTURE_NOT_PROVEN')
    current = identity()
    require(all(data.get('runner', {}).get(key) == value for key, value in current.items())
            and before.get('runner') == current, 'TOOLCHAIN_RECEIPT_FROM_DIFFERENT_RUN')
    require(data.get('producer_sha256') == before.get('producer_sha256') == sha(Path(__file__))
            and data.get('original_auditor_sha256') == ORIGINAL_SHA256,
            'TOOLCHAIN_RECEIPT_PRODUCER_CHANGED')
    require(data.get('before_receipt_sha256') == sha(out / BEFORE_FILE),
            'TOOLCHAIN_BEFORE_RECEIPT_DIGEST_CHANGED')
    command_path = stage / 'evidence/BUILD_COMMAND.json'
    require(data.get('build_command_record_sha256') == sha(command_path),
            'TOOLCHAIN_BUILD_COMMAND_RECEIPT_CHANGED')
    command = json.loads(command_path.read_text())
    require(data.get('captured_env_sha256') == before.get('captured_env_sha256')
            == object_sha(command['original_captured_env']), 'TOOLCHAIN_BUILD_ENV_RECEIPT_CHANGED')
    require(command['variables'].get('CC') == 'clang' and command['variables'].get('LD') == 'ld.lld',
            'TOOLCHAIN_SAVED_COMPILER_COMMAND_CHANGED')
    tools = data.get('toolchain_before', {})
    require(set(tools) == set(EXPECTED) and tools == data.get('toolchain_after')
            == before.get('toolchain'), 'TOOLCHAIN_BEFORE_AFTER_PROOF_CHANGED')
    # Validate paths lexically: these files have legitimately been deleted.
    binary_dir = Path(command['original_captured_env']['PATH'].split(os.pathsep)[0])
    require(binary_dir.is_absolute()
            and binary_dir.parts[-4:] == ('source-work', 'toolchains', 'clang-r416183b', 'bin'),
            'TOOLCHAIN_SAVED_BINARY_DIRECTORY_CHANGED')
    for name, expected in EXPECTED.items():
        item = tools[name]
        require(item.get('sha256') == expected and item.get('resolved_path')
                == str(binary_dir / RESOLVED_NAMES[name]) and item.get('bytes', 0) > 0,
                'TOOLCHAIN_SAVED_PIN_CHANGED:' + name)
    require(data.get('toolchain') == {name: {key: tools[name][key]
                for key in ('resolved_path', 'sha256')} for name in ('clang', 'ld.lld', 'llvm-ar')},
            'TOOLCHAIN_ORIGINAL_AUDIT_RECEIPT_CHANGED')
    require(data.get('installed_packages_sha256') == sha(out / 'INSTALLED_PACKAGES.tsv'),
            'TOOLCHAIN_PACKAGES_RECEIPT_CHANGED')
    print('BUILD_ENVIRONMENT_THIS_RUN_RECEIPT_VERIFIED_AFTER_WORKER_CLEANUP')
    return data


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stage', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    verify(args.stage, args.out)
