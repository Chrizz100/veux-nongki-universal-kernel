#!/usr/bin/env python3
"""Read-only R12 downstream audit of genuine run metadata and immutable assets.

This does not execute collect_builtin or pretend to have the failed CI run's
Image/vmlinux. Diagnostics and summary programs are exercised as host tooling.
"""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parent.parent
PAYLOAD = ROOT / 'payload'
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence/artifact/veux-r55h17-r4/evidence'
RESULT = {'schema': 'r12-ci-r3-downstream-read-only-audit-v1',
          'run_id': 40879252447, 'job_id': 123466062573,
          'current_ci_binaries_available': False,
          'current_ci_complete_builtin_collection_executed': False,
          'current_ci_kernel_package_generated': False,
          'device_test': False, 'checks': {}}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def check(name, condition, details=None):
    if not condition:
        raise AssertionError(name)
    RESULT['checks'][name] = {'status': 'PASS', 'details': details}


def execute(argv, **kwargs):
    proc = subprocess.run([str(p) for p in argv], text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          **kwargs)
    if proc.returncode:
        raise RuntimeError(str(argv) + '\n' + proc.stdout)
    return {'exit': proc.returncode, 'output': proc.stdout}


def main():
    contract_path = PAYLOAD / 'r11/SOURCE_CONTRACT.json'
    source = load(contract_path)
    native = load(EVIDENCE / 'NATIVE_BUILD_RESULT.json')
    r4 = load(EVIDENCE / 'R4_RESULT.json')
    updated = load(EVIDENCE / 'R11_SOURCE_UPDATE.json')
    hook = load(EVIDENCE / 'R11_COMPILE_HOOK.json')
    index = load(EVIDENCE / 'R11_GIT_INDEX.json')
    command = load(EVIDENCE / 'BUILD_COMMAND.json')
    check('current_ci_compile_reports_compatible',
          native['status'] == 'NATIVE_CASS_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
          and all(native[k] is True for k in ('native_compile_completed', 'static_gates_passed', 'kernel_image_generated'))
          and r4['status'] == 'CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
          and r4['original_baseline_unchanged'] is True
          and native['proof']['outputs'] == r4['outputs'],
          {'native_sha256': sha(EVIDENCE / 'NATIVE_BUILD_RESULT.json'),
           'r4_sha256': sha(EVIDENCE / 'R4_RESULT.json'),
           'candidate_image_reported_sha256': r4['outputs']['arch/arm64/boot/Image']['sha256']})
    check('current_ci_source_contract_compatible',
          source['schema'] == 'veux-r11-source-v1'
          and updated['status'] == 'SOURCE_UPDATE_PASS'
          and updated['all_other_source_files_unchanged'] is True
          and updated['source_contract_sha256'] == sha(contract_path)
          and set(source['files']) == set(updated['changed_paths'])
          and all(source['files'][k]['after_sha256'] == updated['files'][k]['after']['sha256'] for k in source['files']),
          {'source_contract_sha256': sha(contract_path)})
    check('current_ci_hook_compatible',
          hook['schema'] == 'veux-r11-compile-hook-v1'
          and hook['r4_compile_and_static_gates_passed'] is True
          and hook['candidate_source_unchanged_during_compile'] is True
          and hook['original_r4_build_script_sha256'] == '12519a7d94825d3bc2006a46420f8884773a659443e56ba542f48057929dd3a0'
          and hook['precompile_source_update_sha256'] == sha(EVIDENCE / 'R11_SOURCE_UPDATE.json'),
          {'compile_hook_sha256': sha(EVIDENCE / 'R11_COMPILE_HOOK.json')})
    check('current_ci_git_index_compatible',
          index['status'] == 'CLEAN_INDEX_AND_WORKTREE'
          and index['source_bytes_unchanged'] is True
          and index['version_overrides'] is False
          and index['only_isolated_git_metadata_refreshed'] is True)
    check('current_ci_collector_command_paths_compatible',
          command['source'] == '/home/runner/work/_temp/veux-r55h17-r4/source/kernel'
          and command['variables']['O'] == '/home/runner/work/_temp/veux-r55h17-r4/build'
          and command['variables']['CC'] == 'clang'
          and command['variables']['LD'] == 'ld.lld')
    original_manifest = load(PAYLOAD / 'r12/reference/R11_PAYLOAD_MANIFEST.json')['files']
    preserved = ['r11/packaging/collect_builtin.py', 'r11/packaging/builtin_validation.py',
                 'r11/packaging/boot_common.py', 'r11/packaging/test_builtin_contract.py',
                 'r11/SOURCE_CONTRACT.json']
    check('collector_and_validator_preserve_prior_real_kernel_validation',
          all(sha(PAYLOAD / p) == original_manifest[p] for p in preserved),
          {p: sha(PAYLOAD / p) for p in preserved})

    spec = importlib.util.spec_from_file_location('audit_r12_package', PAYLOAD / 'r12/package_anykernel.py')
    package = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(package)
    template, helper, assets = package.assets(PAYLOAD)
    check('all_packager_assets_and_fixed_official_tool_pins_authentic', True,
          {'asset_count': len(assets),
           'image_placeholder_occurrences': template.count(b'@IMAGE_SHA256@'),
           'repack_placeholder_occurrences': template.count(b'@REPACK_SHA256@'),
           'magiskboot_placeholder_occurrences': template.count(b'@MAGISKBOOT_SHA256@')})
    for key, filename in [('manager_apk', 'BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk'),
                          ('nomount_zip', 'NoMount-v2.2.0-release-bf1847f-605.zip')]:
        file = PAYLOAD / 'companions' / filename
        check('official_' + key + '_byte_pin', sha(file) == package.common.PINS[key],
              {'file': filename, 'bytes': file.stat().st_size, 'sha256': sha(file)})
    tool = OUT / 'shellcheck'
    shutil.copyfile(PAYLOAD / 'r12/host-tools/shellcheck', tool)
    tool.chmod(0o755)
    check('pinned_shellcheck_unchanged', sha(tool) == '4da528ddb3a4d1b7b24a59d4e16eb2f5fd960f4bd9a3708a15baddbdf1d5a55b')
    # This is a prior genuine local ELF notes proof, explicitly not the new CI
    # kernel. It tests the notes-bound diagnostic generator and its syntax.
    old_check = PAYLOAD / 'r12/review/LOCAL_FULL_IMAGE_CHECK.json'
    diagnostic = OUT / 'HOST_ONLY_PRIOR_LOCAL_KERNEL_DIAGNOSTIC.sh'
    execute([sys.executable, '-B', PAYLOAD / 'r12/write_device_diagnostics.py',
             '--checks', old_check, '--out', diagnostic])
    execute(['sh', '-n', diagnostic])
    execute([tool, '--shell=sh', '--severity=error', diagnostic])
    check('diagnostic_generation_and_actual_shellcheck',
          '@KERNEL_NOTES_SHA256@' not in diagnostic.read_text()
          and load(old_check)['kernel_notes_sha256'] in diagnostic.read_text(),
          {'scope': 'HOST_ONLY_PRIOR_GENUINE_LOCAL_NOTES_NOT_NEW_CI_KERNEL',
           'notes_sha256': load(old_check)['kernel_notes_sha256'],
           'diagnostic_sha256': sha(diagnostic)})

    workflow = yaml.safe_load((ROOT / 'original/VEUX_R12_CASS_BUILD.yml').read_text())
    job = next(iter(workflow['jobs'].values()))
    steps = {s.get('id'): s for s in job['steps'] if s.get('id')}
    artifact_paths = steps['r12_kernel_upload']['with']['path'].splitlines()
    actual_names = [Path(p).name for p in artifact_paths]
    expected_names = ['VEUX_R12_CASS_KERNEL.zip', 'VEUX_R12_GERAETEDIAGNOSE_R2.sh',
                      'SHA256SUMS', 'BUILD_OUTPUTS.json', 'BUILD_PACKAGE_CHECK.json',
                      'PACKAGE_RESULT.json', 'ANYKERNEL_PACKAGE_CHECK.json', 'README.txt',
                      'BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk',
                      'NoMount-v2.2.0-release-bf1847f-605.zip']
    check('artifact_members_match_package_and_diagnostic_producers',
          len(actual_names) == len(set(actual_names)) and set(actual_names) == set(expected_names),
          {'files': actual_names, 'checksums_cover_all_members_except_SHA256SUMS': True})
    summary_body = steps['r12_complete']['run']
    summary_source = summary_body.split("<<'PY_R12_COMPLETE'\n", 1)[1].split('\nPY_R12_COMPLETE', 1)[0]
    summary_program = OUT / 'summary_under_test.py'
    summary_program.write_text(summary_source)
    required = ['STATIC_RESULT', 'COMPILE_RESULT', 'R4_RESULT', 'BUILTIN_RESULT',
                'PACKAGE_RESULT', 'DIAGNOSTICS_RESULT', 'REPO_RESULT', 'KERNEL_UPLOAD_RESULT']
    cases = []
    for mode, job_state, values in [('all_success_host_model', 'success', {}),
                                     ('environment_step_failed_host_model', 'failure', {}),
                                     ('kernel_upload_skipped_host_model', 'success', {'KERNEL_UPLOAD_RESULT': 'skipped'})]:
        env = dict(os.environ, **{k: 'success' for k in required}, **{'JOB_RESULT_BEFORE_SUMMARY': job_state})
        env.update(values)
        env['GITHUB_STEP_SUMMARY'] = str(OUT / (mode + '.txt'))
        proc = subprocess.run([sys.executable, '-B', str(summary_program)], env=env, text=True,
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        expected = 0 if mode == 'all_success_host_model' else 1
        check('summary_' + mode, proc.returncode == expected,
              {'exit': proc.returncode, 'stdout': proc.stdout, 'scope': 'SYNTHETIC_HOST_STATUS_VALUES_ONLY'})
        cases.append(mode)
    RESULT['status'] = 'READ_ONLY_DOWNSTREAM_CONTRACT_AND_HOST_CHECKS_PASS'
    RESULT['limits'] = [
        'The failed run did not upload candidate Image/vmlinux/RMNET command objects; current CI binary collection/packaging cannot be replayed honestly.',
        'No new positive whole-kernel fixture was fabricated; no CI evidence mode was emulated to label old local bytes as CI.',
        'No concrete later runtime blocker was identified in the inspected producer/consumer contracts; the next real CI must execute the full untouched binary gates.',
        'On-device boot, hardware behavior and installer write/readback remain untested by this read-only host audit.'
    ]
    (OUT / 'DOWNSTREAM_AUDIT.json').write_text(json.dumps(RESULT, indent=2) + '\n')
    print(json.dumps({'status': RESULT['status'], 'checks': len(RESULT['checks']),
                      'current_ci_binaries_available': False}, indent=2))


if __name__ == '__main__':
    main()
