#!/usr/bin/env python3
"""Exercise production pins and lifecycle with authentic upstream compiler bytes.

Filesystem layout and run identity are explicit local host fixtures. No actual
kernel build or current GitHub CI output is claimed. Production byte pins and
the complete original reporter execute unchanged, without mocks.
"""
from pathlib import Path
import json
import shutil

from test_environment_lifecycle import LiveFixture, RECORDER, ORIGINAL, digest


HERE = Path(__file__).resolve().parent
REAL_BINARIES = HERE.parent / 'agent_toolchain/binaries'


def main():
    fixture = LiveFixture(real_binaries=REAL_BINARIES)
    try:
        before = fixture.begin()
        result = fixture.finish(before)
        fixture.cleanup_worker()
        if fixture.baseline.exists():
            raise AssertionError('Fixture baseline cleanup did not delete compiler tree')
        old_failure = None
        try:
            fixture.original_after_cleanup()
        except ValueError as error:
            old_failure = str(error)
        if old_failure != 'TOOLCHAIN_EXECUTABLE_CHANGED:clang':
            raise AssertionError('Unexpected old audit result: ' + repr(old_failure))
        verified = fixture.verify()
        if verified != result:
            raise AssertionError('Saved real-binary audit receipt changed')
        for name in ['TOOLCHAIN_BEFORE_BUILD.json', 'BUILD_ENVIRONMENT.json', 'INSTALLED_PACKAGES.tsv']:
            shutil.copyfile(fixture.out / name, HERE / ('REAL_BINARY_HOST_' + name))
        report = {
            'schema': 'r12-ci-r3-real-toolchain-host-probe-v1',
            'status': 'AUTHENTIC_TOOLCHAIN_LIFECYCLE_PROBE_PASS',
            'scope': 'LOCAL_HOST_LAYOUT_AND_IDENTITY_WITH_AUTHENTIC_UPSTREAM_COMPILER_BYTES',
            'production_recorder_sha256': digest(RECORDER),
            'original_auditor_sha256': digest(ORIGINAL),
            'production_expected_pins_changed': False,
            'production_auditor_code_changed': False,
            'mocks_used': False,
            'before_and_after_actual_toolchain_sha256_equal': before['toolchain'] == result['toolchain_after'],
            'compiler_tree_deleted_before_final_verification': True,
            'unrelated_runner_fallback_present': True,
            'original_late_audit_failure_reproduced': old_failure,
            'new_saved_receipt_verified_after_cleanup': True,
            'actual_toolchain': before['toolchain'],
            'kernel_compilation_performed': False,
            'current_ci_kernel_binary_validated': False,
            'device_test': False,
        }
        (HERE / 'REAL_BINARY_LIFECYCLE_PROBE.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k: v for k, v in report.items() if k != 'actual_toolchain'}, indent=2))
    finally:
        fixture.close()


if __name__ == '__main__':
    main()
