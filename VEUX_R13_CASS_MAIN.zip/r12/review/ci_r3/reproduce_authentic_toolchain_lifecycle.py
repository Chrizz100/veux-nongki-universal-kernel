#!/usr/bin/env python3
"""Local host fixture only. No actual CI, kernel compile, or device execution."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import os
import shutil
import tempfile

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
MODULE = PROJECT / "payload/r12/record_environment_r3.py"
ACTUAL_COMMAND = PROJECT / "evidence/artifact/veux-r55h17-r4/evidence/BUILD_COMMAND.json"

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    spec=importlib.util.spec_from_file_location("record_environment_r3_under_audit", MODULE)
    audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
    start_hash=digest(MODULE)
    fixture=Path(tempfile.mkdtemp(prefix="new-lifecycle-", dir=ROOT)).resolve()
    baseline_work=fixture/"veux-r5s2-work/builds/5.4.274"
    tools=baseline_work/"source-work/toolchains/clang-r416183b/bin"
    tools.mkdir(parents=True)
    for name in ("clang","clang-12","lld","llvm-ar"):
        shutil.copy2(ROOT/"binaries"/name, tools/name)
        (tools/name).chmod(0o755)
    (tools/"clang.real").symlink_to("clang-12")
    (tools/"ld.lld").symlink_to("lld")
    stage=fixture/"veux-r55h17-r4"
    (stage/"evidence").mkdir(parents=True)
    out=fixture/"r12-reports"
    identity={"GITHUB_REPOSITORY":"Chrizz100/veux-nongki-universal-kernel", "GITHUB_SHA":"1"*40,
              "GITHUB_RUN_ID":"1", "GITHUB_RUN_ATTEMPT":"1"}
    os.environ.update(identity)
    os.environ["RUNNER_TEMP"]=str(fixture)
    original=json.loads(ACTUAL_COMMAND.read_text())
    command=copy.deepcopy(original)
    command["original_captured_env"]["PATH"]=str(tools)+":"+str(baseline_work/"source-temp/bin")+":"+os.environ["PATH"]
    command["source"]=str(stage/"source/kernel")
    command["variables"]["O"]=str(stage/"build")
    command["variables"]["KCFLAGS"]="-D__ANDROID_COMMON_KERNEL__ -I"+str(stage/"build/security/selinux")
    state={"env":copy.deepcopy(command["original_captured_env"]),
           "variables":[k+"="+v for k,v in command["variables"].items()]}
    before=audit.begin(state,baseline_work,out)
    command_path=stage/"evidence/BUILD_COMMAND.json"
    command_bytes=(json.dumps(command,indent=2)+"\n").encode()
    command_path.write_bytes(command_bytes)
    complete=audit.finish(before,state,baseline_work,stage,out)
    assert complete["toolchain_before"]==complete["toolchain_after"]
    assert complete["runner_fallback_used"] is False
    live_sha={n:row["sha256"] for n,row in complete["toolchain_after"].items()}
    assert live_sha==audit.EXPECTED
    cases=[]
    def reject(label,operation,wanted):
        try:operation()
        except Exception as exc:
            error=type(exc).__name__+":"+str(exc)
            assert wanted in error,(label,error,wanted)
            cases.append({"name":label,"result":"REJECTED_AS_REQUIRED","error":error})
        else:raise AssertionError("accepted invalid case "+label)
    altered=copy.deepcopy(state);altered["env"]["PATH"]="/usr/bin:"+altered["env"]["PATH"]
    reject("system_path_precedence",lambda:audit.snapshot(altered,baseline_work),"TOOLCHAIN_CAPTURED_PATH_CHANGED")
    (tools/"clang.real").unlink();(tools/"clang.real").symlink_to("clang")
    reject("wrong_clang_real_symlink",lambda:audit.snapshot(state,baseline_work),"TOOLCHAIN_UPSTREAM_SYMLINK_CHANGED:clang.real")
    (tools/"clang.real").unlink();(tools/"clang.real").symlink_to("clang-12")
    original_compiler=(tools/"clang-12").read_bytes()
    with (tools/"clang-12").open("r+b") as f:f.seek(1024);b=f.read(1);f.seek(1024);f.write(bytes([b[0]^1]))
    reject("actual_compiler_single_byte_tamper",lambda:audit.snapshot(state,baseline_work),"TOOLCHAIN_EXECUTABLE_CHANGED:clang-12")
    (tools/"clang-12").write_bytes(original_compiler)
    # Real reproduction of the original worker's destructive cleanup, local fixture only.
    shutil.rmtree(baseline_work)
    assert not baseline_work.exists() and not tools.exists()
    after_cleanup=audit.verify(stage,out)
    assert after_cleanup==complete
    cases.append({"name":"verify_after_real_worker_directory_cleanup","result":"PASS","toolchain_directory_exists":tools.exists()})
    reject("fresh_live_snapshot_after_cleanup",lambda:audit.snapshot(state,baseline_work),"No such file or directory")
    command_path.write_bytes(command_bytes+b" ")
    reject("build_command_byte_tamper",lambda:audit.verify(stage,out),"TOOLCHAIN_BUILD_COMMAND_RECEIPT_CHANGED")
    command_path.write_bytes(command_bytes)
    for key,value in (("GITHUB_RUN_ID","2"),("GITHUB_RUN_ATTEMPT","2"),("GITHUB_SHA","2"*40)):
        saved=os.environ[key];os.environ[key]=value
        reject("foreign_"+key,lambda:audit.verify(stage,out),"TOOLCHAIN_RECEIPT_FROM_DIFFERENT_RUN")
        os.environ[key]=saved
    report_path=out/audit.REPORT_FILE;report_bytes=report_path.read_bytes()
    tampered=json.loads(report_bytes);tampered["toolchain_after"]["clang"]["sha256"]="0"*64
    report_path.write_text(json.dumps(tampered))
    reject("saved_compiler_hash_tamper",lambda:audit.verify(stage,out),"TOOLCHAIN_BEFORE_AFTER_PROOF_CHANGED")
    report_path.write_bytes(report_bytes)
    assert audit.verify(stage,out)==complete
    assert digest(MODULE)==start_hash
    result={"classification":"LOCAL_NEW_TOOLCHAIN_LIFECYCLE_HOST_FIXTURE_NOT_ACTUAL_CI",
            "status":"AUTHENTIC_TOOL_BYTES_BEFORE_AFTER_CAPTURE_AND_POST_CLEANUP_VERIFICATION_PASS",
            "module_sha256":start_hash,"original_ci_command_input_sha256":digest(ACTUAL_COMMAND),
            "fixture_directory":str(fixture),"synthetic_ci_identity":identity,
            "local_command_replacements":{"original_PATH":original["original_captured_env"]["PATH"],"fixture_PATH":command["original_captured_env"]["PATH"],
                                          "source":command["source"],"O":command["variables"]["O"],"KCFLAGS":command["variables"]["KCFLAGS"]},
            "fixture_BUILD_COMMAND_written_without_compiler_invocation":True,
            "toolchain_pins":live_sha,"original_auditor_invoked_unchanged":True,
            "actual_worker_directory_removed":True,"verify_succeeds_after_cleanup":True,
            "negative_and_lifecycle_checks":cases,"module_unchanged_during_execution":True,
            "kernel_compiled":False,"actual_ci_execution":False,"device_test":False,"production_files_changed":False}
    (ROOT/"LOCAL_NEW_LIFECYCLE.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":main()
