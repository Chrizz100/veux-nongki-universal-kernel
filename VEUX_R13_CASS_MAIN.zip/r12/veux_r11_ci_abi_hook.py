#!/usr/bin/env python3
"""Authenticate the full baseline ABI independently of modpost row order.

Only the in-memory raw-file hash expected by the pinned R4 function is scoped
to the authenticated, freshly built input. No kernel or pipeline file is
rewritten. The unmodified R11 hook still runs all original build/source gates.
"""
from __future__ import annotations

import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import stat
import tempfile

BUILD_PIN = "12519a7d94825d3bc2006a46420f8884773a659443e56ba542f48057929dd3a0"
R11_HOOK_PIN = "9a7bb369519ed6b2b472da31d6a4ca0c20f3f51118b26978c57b60ad28c8029d"
REFERENCE_RAW_SHA256 = "6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec"
REFERENCE_CANONICAL_SHA256 = "bc8c9db3aff0f0a6af92f0574792676fcc71ba260351bb57a9d42f1d79cdba12"
REFERENCE_RECORDS = 12947
BASELINE_RELATIVE = Path("veux-r5s2-work/builds/5.4.274")
REPORT_RELATIVE = Path("r11-reports/BASELINE_ABI_ORDER_CHECK.json")


class AbiOrderBlocked(RuntimeError):
    """An unauthenticated input or real ABI difference must stop the build."""


def _need(condition, message):
    if not condition:
        raise AbiOrderBlocked(message)


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _plain_path(path, *, directory=False):
    """Require a canonical absolute path without symlink components."""
    path = Path(path)
    _need(path.is_absolute(), "ABI_PATH_NOT_ABSOLUTE")
    _need(".." not in path.parts, "ABI_PATH_TRAVERSAL")
    for component in (path, *path.parents):
        _need(not component.is_symlink(), "ABI_SYMLINK_PATH:" + str(component))
    _need(path.resolve(strict=True) == path, "ABI_PATH_NOT_CANONICAL")
    mode = path.stat().st_mode
    _need(stat.S_ISDIR(mode) if directory else stat.S_ISREG(mode),
          "ABI_PATH_WRONG_TYPE:" + str(path))
    return path


def _read_regular(path):
    path = _plain_path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        _need(stat.S_ISREG(os.fstat(stream.fileno()).st_mode), "ABI_INPUT_NOT_REGULAR")
        return stream.read()


def validate_symvers_bytes(data):
    """Validate all five tab-separated fields and their pinned full-row set.

    Sorting retains complete rows and multiplicity; it does not normalize
    whitespace, CRC spelling, providers, export classes or namespaces.
    """
    _need(isinstance(data, bytes), "ABI_INPUT_NOT_BYTES")
    _need(data and data.endswith(b"\n"), "ABI_FINAL_LF_REQUIRED")
    _need(b"\r" not in data and b"\x00" not in data, "ABI_CR_OR_NUL_FORBIDDEN")
    try:
        data.decode("ascii", errors="strict")
    except UnicodeDecodeError as error:
        raise AbiOrderBlocked("ABI_NON_ASCII") from error
    rows = data[:-1].split(b"\n")
    _need(len(rows) == REFERENCE_RECORDS, "ABI_RECORD_COUNT_CHANGED")
    symbols = set()
    for number, row in enumerate(rows, 1):
        fields = row.split(b"\t")
        _need(len(fields) == 5, "ABI_FIELD_COUNT:" + str(number))
        crc, symbol, provider, export, namespace = fields
        _need(re.fullmatch(rb"0x[0-9a-f]{8}", crc), "ABI_CRC_FORMAT:" + str(number))
        _need(re.fullmatch(rb"[A-Za-z_][A-Za-z0-9_]*", symbol),
              "ABI_SYMBOL_FORMAT:" + str(number))
        _need(symbol not in symbols, "ABI_DUPLICATE_SYMBOL:" + symbol.decode("ascii"))
        symbols.add(symbol)
        _need(re.fullmatch(rb"[A-Za-z0-9_-]+(?:[./][A-Za-z0-9_-]+)*", provider),
              "ABI_PROVIDER_FORMAT:" + str(number))
        _need(export in (b"EXPORT_SYMBOL", b"EXPORT_SYMBOL_GPL"),
              "ABI_EXPORT_FORMAT:" + str(number))
        _need(not namespace or re.fullmatch(rb"[A-Za-z_][A-Za-z0-9_]*", namespace),
              "ABI_NAMESPACE_FORMAT:" + str(number))
    canonical = _sha(b"\n".join(sorted(rows)) + b"\n")
    _need(canonical == REFERENCE_CANONICAL_SHA256, "BASELINE_ABI_RECORDS_CHANGED")
    raw = _sha(data)
    return {
        "raw_sha256": raw,
        "canonical_sha256": canonical,
        "records": len(rows),
        "unique_symbols": len(symbols),
        "fields_checked": ["crc", "symbol", "provider", "export", "namespace"],
        "full_record_multiplicity_preserved": True,
        "raw_hash_matches_reference": raw == REFERENCE_RAW_SHA256,
        "hash_difference_is_line_order_only": raw != REFERENCE_RAW_SHA256,
        "canonicalization": "strict ASCII/LF; sort complete tab-separated byte rows; append LF",
    }


def _write_report(path, report):
    _need(not path.is_symlink(), "ABI_REPORT_SYMLINK")
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     prefix=".abi-order-", delete=False) as output:
        staged = Path(output.name)
        try:
            json.dump(report, output, indent=2, sort_keys=True)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        except BaseException:
            staged.unlink(missing_ok=True)
            raise
    try:
        os.replace(staged, path)
    finally:
        staged.unlink(missing_ok=True)


def run_update(kernel, state, baseline_work, jobs):
    """Same signature as veux_r11_build_hook.run_update; original result returned."""
    temporary = _plain_path(Path(os.environ["RUNNER_TEMP"]), directory=True)
    report_path = temporary / REPORT_RELATIVE
    _need(not report_path.parent.is_symlink(), "ABI_REPORT_DIRECTORY_SYMLINK")
    report_path.parent.mkdir(exist_ok=True)
    _plain_path(report_path.parent, directory=True)
    _need(not report_path.is_symlink(), "ABI_REPORT_SYMLINK")
    report = {
        "schema": "veux-r11-ci-abi-order-v1", "status": "BLOCKED",
        "abi_records_verified": False, "delegate_called": False,
        "delegate_completed": False, "device_test": False,
        "reference_run": 40704046049, "reference_attempt": 2,
        "reference_url": "https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/40704046049/attempts/2",
        "reference_artifact_id": 12829810137,
        "reference_artifact_sha256": "dc7202be61329283067723c98fe57b3877686dedd680e00bcc8c79d1a68f9648",
        "reference_raw_sha256": REFERENCE_RAW_SHA256,
        "reference_canonical_sha256": REFERENCE_CANONICAL_SHA256,
        "expected_records": REFERENCE_RECORDS,
        "wrapper_rewrites_source_files": False,
        "original_build_and_source_gates_preserved": True,
    }
    original = None
    saved_constant = None
    constant_changed = False
    snapshots = {}
    result = None
    failure = None
    violations = []
    try:
        baseline_work = _plain_path(Path(baseline_work), directory=True)
        _need(baseline_work == temporary / BASELINE_RELATIVE, "ABI_BASELINE_LAYOUT_CHANGED")
        source = _plain_path(Path(kernel), directory=True)
        _need(source.is_relative_to(baseline_work) and source.name == "kernel",
              "ABI_BASELINE_SOURCE_OUTSIDE_WORK")
        baseline_symvers = baseline_work / "build/Module.symvers"
        data = _read_regular(baseline_symvers)
        snapshots[baseline_symvers] = _sha(data)
        report["baseline_symvers"] = str(baseline_symvers)
        report["actual_raw_sha256"] = _sha(data)
        record_proof = validate_symvers_bytes(data)
        report.update(abi_records_verified=True, records=record_proof)

        build_file = _plain_path(Path(os.environ["R4_PAYLOAD"]) / "workflow/cass_r4_build.py")
        hook_file = _plain_path(Path(os.environ["REPRO_PAYLOAD"]) / "r11/veux_r11_build_hook.py")
        for source_file, expected in ((build_file, BUILD_PIN), (hook_file, R11_HOOK_PIN)):
            observed = _sha(_read_regular(source_file))
            _need(observed == expected, "ABI_PIPELINE_SOURCE_PIN:" + source_file.name)
            snapshots[source_file] = observed
        original = importlib.import_module("cass_r4_build")
        r11 = importlib.import_module("veux_r11_build_hook")
        _need(_plain_path(Path(original.__file__)) == build_file, "ABI_R4_IMPORT_ORIGIN")
        _need(_plain_path(Path(r11.__file__)) == hook_file, "ABI_R11_IMPORT_ORIGIN")
        saved_constant = original.SYMVERS_SHA
        _need(saved_constant == REFERENCE_RAW_SHA256, "ABI_ORIGINAL_EXPECTED_HASH_CHANGED")
        _need(_sha(_read_regular(baseline_symvers)) == record_proof["raw_sha256"],
              "ABI_INPUT_CHANGED_BEFORE_DELEGATION")

        # The complete ABI has already matched the pinned reference. Scope only
        # the original raw-file expectation to this exact fresh input ordering.
        original.SYMVERS_SHA = record_proof["raw_sha256"]
        constant_changed = True
        from record_environment_r3 import begin as environment_begin, finish as environment_finish
        environment_out = temporary / "r12-reports"
        environment_before = environment_begin(state, baseline_work, environment_out)
        report["live_toolchain_before_verified"] = True
        report["delegate_called"] = True
        result = r11.run_update(kernel, state, baseline_work, jobs)
        report["delegate_completed"] = True
        environment_finish(environment_before, state, baseline_work,
                           temporary / "veux-r55h17-r4", environment_out)
        report["live_toolchain_after_verified_before_worker_cleanup"] = True
    except BaseException as error:
        failure = error
        report["failure"] = type(error).__name__ + ": " + str(error)
    finally:
        if constant_changed:
            original.SYMVERS_SHA = saved_constant
        report["original_constant_restored"] = (
            original.SYMVERS_SHA == REFERENCE_RAW_SHA256 if original is not None else None)
        if constant_changed and not report["original_constant_restored"]:
            violations.append("ABI_ORIGINAL_CONSTANT_NOT_RESTORED")
        unchanged = {}
        for source_file, digest in snapshots.items():
            try:
                observed = _sha(_read_regular(source_file))
                equal = observed == digest
                unchanged[str(source_file)] = {
                    "before_sha256": digest, "after_sha256": observed, "unchanged": equal}
                if not equal:
                    violations.append("ABI_INPUT_CHANGED:" + source_file.name)
            except BaseException as check_error:
                unchanged[str(source_file)] = {"unchanged": False,
                    "error": type(check_error).__name__ + ": " + str(check_error)}
                violations.append("ABI_INPUT_UNREADABLE:" + source_file.name)
        report["input_files"] = unchanged
        report["all_recorded_input_files_unchanged"] = bool(unchanged) and all(
            item["unchanged"] for item in unchanged.values())
        report["preservation_failures"] = violations
        if failure is None and not violations:
            report["status"] = "ABI_ORDER_CHECK_AND_DELEGATED_UPDATE_PASS"
        try:
            _write_report(report_path, report)
        except BaseException as report_error:
            if failure is None:
                failure = report_error
            else:
                failure.add_note("ABI proof write also failed: " + str(report_error))
    if failure is not None:
        if violations:
            failure.add_note("ABI preservation failures: " + ", ".join(violations))
        raise failure.with_traceback(failure.__traceback__)
    if violations:
        raise AbiOrderBlocked("; ".join(violations))
    return result
