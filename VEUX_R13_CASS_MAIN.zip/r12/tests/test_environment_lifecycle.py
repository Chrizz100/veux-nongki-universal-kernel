#!/usr/bin/env python3
"""Host-only regression for compiler lifetime, cleanup and run-bound receipts.

Default tests use small, explicitly synthetic executable files. Only the
test-local module's trusted byte pins and the original auditor's in-memory
EXPECTED mapping are substituted. Both production source files, all rejection
logic, hashing, path resolution, receipt I/O and the original record() function
remain unchanged. No kernel compilation, GitHub CI run or device test is
claimed. Original production pins/source are separately asserted below.
"""
from __future__ import annotations

from contextlib import redirect_stdout
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch


def payload_root():
    explicit = os.environ.get('R12_TEST_PAYLOAD') or os.environ.get('REPRO_PAYLOAD')
    choices = [Path(explicit)] if explicit else []
    choices += [Path(__file__).resolve().parents[2],
                Path(__file__).resolve().parents[1] / 'payload']
    for choice in choices:
        if (choice / 'r12/record_environment_r3.py').is_file():
            return choice.resolve()
    raise RuntimeError('Authenticated R12 payload containing the lifecycle recorder is required')


PAYLOAD = payload_root()
RECORDER = PAYLOAD / 'r12/record_environment_r3.py'
ORIGINAL = PAYLOAD / 'pipeline/record_environment.py'
ORIGINAL_SOURCE_SHA256 = '2ac5586d2eb5bc806adc50b44f85dd511c899958ccb05e773cc133cd61d289cd'
PRODUCTION_PINS = {
    'clang': 'b2ce016755bddbab76549895bca07b1dc8d14a3e315b8b3567097fef04eadae1',
    'ld.lld': '51dc9705420c136f583478ac08a3258cd970710296928b3bf24dc3ee2e6208e3',
    'llvm-ar': 'dfe6c18a46138a81220768cabe385fe09a851bab05d18914fc2cd15bbbde8d4a',
    'clang-12': '5c190576d99caae4d351993a8160c092e3fe07c469fbdf6f7e36a4a9ca7c2dc5',
    'clang.real': '5c190576d99caae4d351993a8160c092e3fe07c469fbdf6f7e36a4a9ca7c2dc5',
}
REAL_NAMES = {'clang': 'clang', 'ld.lld': 'lld', 'llvm-ar': 'llvm-ar',
              'clang-12': 'clang-12', 'clang.real': 'clang-12'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def import_file(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class LiveFixture:
    """Real filesystem and cleanup; optional authentic compiler byte inputs."""

    def __init__(self, *, real_binaries=None):
        self.temporary = tempfile.TemporaryDirectory(prefix='r12-toolchain-host-fixture-')
        self.root = Path(self.temporary.name).resolve()
        self.recorder = import_file(RECORDER, 'r12_lifecycle_test_subject')
        self.original_source_sha = digest(ORIGINAL)
        self.production_source_sha = digest(RECORDER)
        self.baseline = self.root / 'runner/veux-r5s2-work/builds/5.4.274'
        self.bin = self.baseline / 'source-work/toolchains/clang-r416183b/bin'
        self.bin.mkdir(parents=True)
        self.runner_bin = self.root / 'runner-host-tools'
        self.runner_bin.mkdir()
        for name in set(REAL_NAMES.values()):
            target = self.bin / name
            if real_binaries is not None:
                source = Path(real_binaries) / name
                try:
                    if not os.access(source, os.X_OK):
                        raise OSError('Fixture copy needs an executable mode')
                    os.link(source, target)
                except OSError:
                    shutil.copyfile(source, target)
                    target.chmod(0o755)
            else:
                target.write_text('#!/bin/sh\n# SYNTHETIC HOST FIXTURE ONLY: ' + name + '\nexit 0\n')
                target.chmod(0o755)
        for name, resolved in REAL_NAMES.items():
            if name != resolved:
                (self.bin / name).symlink_to(resolved)
            fallback = self.runner_bin / name
            fallback.write_text('#!/bin/sh\n# UNRELATED RUNNER COMPILER FIXTURE: ' + name + '\nexit 0\n')
            fallback.chmod(0o755)
        self.synthetic = real_binaries is None
        self.fixture_pins = {name: digest(self.bin / name) for name in PRODUCTION_PINS}
        if self.synthetic:
            self.recorder.EXPECTED = self.fixture_pins.copy()
        else:
            if self.fixture_pins != PRODUCTION_PINS:
                raise AssertionError('Real fixture toolchain differs from unmodified production pins')
        self.state = {'variables': ['ARCH=arm64', 'CC=clang', 'LD=ld.lld', 'LLVM=1',
                                    'LLVM_IAS=1', 'O=' + str(self.baseline / 'build')],
                      'env': {'ARCH': 'arm64', 'KBUILD_BUILD_USER': 'HOST_FIXTURE_ONLY',
                              'PATH': os.pathsep.join([str(self.bin), str(self.baseline / 'source-temp/bin'),
                                                       str(self.runner_bin), '/usr/bin', '/bin']),
                              'SOURCE_DATE_EPOCH': '1733410079'}}
        self.stage = self.root / 'runner/veux-r55h17-r4'
        (self.stage / 'evidence').mkdir(parents=True)
        self.command_file = self.stage / 'evidence/BUILD_COMMAND.json'
        self.command = {'variables': {'ARCH': 'arm64', 'CC': 'clang', 'LD': 'ld.lld',
                                     'LLVM': '1', 'LLVM_IAS': '1', 'O': str(self.stage / 'build')},
                        'source': str(self.stage / 'source/kernel'), 'jobs': 4,
                        'original_captured_env': copy.deepcopy(self.state['env'])}
        self.write_command()
        self.out = self.root / 'runner/r12-reports'
        self.environment = {
            'RUNNER_TEMP': str(self.root / 'runner'),
            'GITHUB_ACTIONS': 'false',
            'GITHUB_REPOSITORY': self.recorder.EXPECTED_REPOSITORY,
            'GITHUB_SHA': 'a' * 40,
            'GITHUB_RUN_ID': '987654321',
            'GITHUB_RUN_ATTEMPT': '3',
            'GITHUB_WORKFLOW_REF': 'HOST_FIXTURE_ONLY',
        }
        self.env_patch = patch.dict(os.environ, self.environment)
        self.env_patch.start()

    def write_command(self):
        self.command_file.write_text(json.dumps(self.command, indent=2) + '\n')

    def begin(self):
        with redirect_stdout(io.StringIO()):
            return self.recorder.begin(self.state, self.baseline, self.out)

    def _spec_with_fixture_pins(self, name, path, *args, **kwargs):
        spec = self.actual_spec(name, path, *args, **kwargs)
        if name == 'r12_original_environment_auditor':
            execute = spec.loader.exec_module

            def load_then_bind_fixture_pins(module):
                execute(module)
                # Test-only dependency injection into trusted data, not code.
                # The production original file and record() function are exact.
                module.EXPECTED = {k: self.fixture_pins[k] for k in ('clang', 'ld.lld', 'llvm-ar')}

            spec.loader.exec_module = load_then_bind_fixture_pins
        return spec

    def finish(self, before):
        with redirect_stdout(io.StringIO()):
            if not self.synthetic:
                return self.recorder.finish(before, self.state, self.baseline, self.stage, self.out)
            self.actual_spec = importlib.util.spec_from_file_location
            with patch.object(importlib.util, 'spec_from_file_location', self._spec_with_fixture_pins):
                return self.recorder.finish(before, self.state, self.baseline, self.stage, self.out)

    def verify(self):
        with redirect_stdout(io.StringIO()):
            return self.recorder.verify(self.stage, self.out)

    def completed(self):
        before = self.begin()
        return self.finish(before)

    def cleanup_worker(self):
        shutil.rmtree(self.baseline)

    def original_after_cleanup(self):
        original = import_file(ORIGINAL, 'r12_legacy_late_audit_test_subject')
        if self.synthetic:
            original.EXPECTED = {k: self.fixture_pins[k] for k in ('clang', 'ld.lld', 'llvm-ar')}
        original.record(self.stage, self.root / 'late-original-result')

    def report(self):
        return json.loads((self.out / self.recorder.REPORT_FILE).read_text())

    def write_report(self, report):
        (self.out / self.recorder.REPORT_FILE).write_text(json.dumps(report, indent=2) + '\n')

    def close(self):
        try:
            assert digest(ORIGINAL) == self.original_source_sha, 'production legacy auditor was rewritten'
            assert digest(RECORDER) == self.production_source_sha, 'production lifecycle recorder was rewritten'
        finally:
            self.env_patch.stop()
            self.temporary.cleanup()


class SourcePreservation(unittest.TestCase):
    def test_production_original_source_and_all_five_pins_preserved(self):
        recorder = import_file(RECORDER, 'r12_production_pin_test_subject')
        original = import_file(ORIGINAL, 'r12_original_pin_test_subject')
        self.assertEqual(digest(ORIGINAL), ORIGINAL_SOURCE_SHA256)
        self.assertEqual(recorder.ORIGINAL_SHA256, ORIGINAL_SOURCE_SHA256)
        self.assertEqual(recorder.EXPECTED, PRODUCTION_PINS)
        self.assertEqual(recorder.RESOLVED_NAMES, REAL_NAMES)
        self.assertEqual(original.EXPECTED, {k: PRODUCTION_PINS[k] for k in ('clang', 'ld.lld', 'llvm-ar')})


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.fixture = LiveFixture()
        self.addCleanup(self.fixture.close)

    def test_live_capture_survives_real_cleanup_and_old_reporter_reproduces_failure(self):
        f = self.fixture
        expected = f.completed()
        f.cleanup_worker()
        self.assertFalse(f.baseline.exists())
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_EXECUTABLE_CHANGED:clang'):
            f.original_after_cleanup()
        self.assertEqual(f.verify(), expected)
        self.assertEqual(expected['toolchain_before'], expected['toolchain_after'])
        self.assertTrue(expected['live_before_and_after_verified'])
        self.assertFalse(expected['runner_fallback_used'])
        self.assertFalse(expected['device_test'])

    def test_saved_verification_does_not_resolve_deleted_compilers(self):
        f = self.fixture
        f.completed()
        f.cleanup_worker()
        with patch.object(shutil, 'which', side_effect=AssertionError('post-cleanup compiler lookup forbidden')):
            self.assertEqual(f.verify()['status'], 'TOOLCHAIN_PINS_PASS')

    def test_missing_live_directory_rejects_runner_fallback(self):
        f = self.fixture
        shutil.rmtree(f.bin)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_LIVE_DIRECTORY_MISSING_OR_RELOCATED'):
            f.begin()

    def test_runner_compiler_first_in_captured_path_is_rejected(self):
        f = self.fixture
        f.state['env']['PATH'] = str(f.runner_bin) + os.pathsep + f.state['env']['PATH']
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_CAPTURED_PATH_CHANGED'):
            f.begin()

    def test_missing_pinned_executable_cannot_fall_back(self):
        f = self.fixture
        (f.bin / 'clang').unlink()
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_LIVE_EXECUTABLE_MISSING:clang'):
            f.begin()

    def test_changed_live_bytes_fail_the_pin(self):
        f = self.fixture
        (f.bin / 'clang').write_text('#!/bin/sh\n# changed fixture executable\nexit 0\n')
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_EXECUTABLE_CHANGED:clang'):
            f.begin()

    def test_wrapper_real_target_cannot_point_to_runner_compiler(self):
        f = self.fixture
        (f.bin / 'clang.real').unlink()
        (f.bin / 'clang.real').symlink_to(f.runner_bin / 'clang.real')
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_UPSTREAM_SYMLINK_CHANGED:clang.real'):
            f.begin()

    def test_non_executable_compiler_rejected(self):
        f = self.fixture
        (f.bin / 'clang').chmod(0o644)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_LIVE_EXECUTABLE_MISSING:clang'):
            f.begin()

    def test_changed_actual_compiler_between_begin_and_finish_rejected(self):
        f = self.fixture
        before = f.begin()
        (f.bin / 'clang-12').write_text('#!/bin/sh\n# changed between captures\nexit 0\n')
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_EXECUTABLE_CHANGED:clang-12'):
            f.finish(before)

    def test_compiler_variable_override_rejected(self):
        f = self.fixture
        f.state['variables'] = [s.replace('CC=clang', 'CC=ccache clang') for s in f.state['variables']]
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_BUILD_COMMAND_COMPILER_CHANGED'):
            f.begin()

    def test_captured_environment_change_during_build_rejected(self):
        f = self.fixture
        before = f.begin()
        f.state['env']['KBUILD_BUILD_USER'] = 'CHANGED_HOST_FIXTURE'
        f.command['original_captured_env'] = copy.deepcopy(f.state['env'])
        f.write_command()
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_CAPTURED_BUILD_ENV_CHANGED'):
            f.finish(before)

    def test_different_build_command_capture_rejected(self):
        f = self.fixture
        before = f.begin()
        f.command['original_captured_env']['SOURCE_DATE_EPOCH'] = '1'
        f.write_command()
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_CAPTURED_BUILD_ENV_CHANGED'):
            f.finish(before)

    def test_actual_build_command_compiler_override_rejected(self):
        f = self.fixture
        before = f.begin()
        f.command['variables']['CC'] = '/usr/bin/clang'
        f.write_command()
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_ACTUAL_BUILD_COMPILER_CHANGED'):
            f.finish(before)

    def test_before_receipt_changed_during_build_rejected(self):
        f = self.fixture
        before = f.begin()
        p = f.out / f.recorder.BEFORE_FILE
        changed = json.loads(p.read_text())
        changed['toolchain']['clang']['bytes'] += 1
        p.write_text(json.dumps(changed))
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_BEFORE_RECEIPT_CHANGED'):
            f.finish(before)

    def test_existing_receipts_cannot_be_reused_as_new_live_capture(self):
        f = self.fixture
        f.completed()
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_RECEIPT_ALREADY_EXISTS'):
            f.begin()

    def test_missing_report_rejected(self):
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_LIVE_RECEIPTS_MISSING'):
            self.fixture.verify()

    def test_changed_run_attempt_or_commit_rejected_after_cleanup(self):
        f = self.fixture
        f.completed()
        f.cleanup_worker()
        for key, value in [('GITHUB_RUN_ID', '987654322'), ('GITHUB_RUN_ATTEMPT', '4'),
                           ('GITHUB_SHA', 'b' * 40)]:
            with self.subTest(key=key), patch.dict(os.environ, {key: value}):
                with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_RECEIPT_FROM_DIFFERENT_RUN'):
                    f.verify()

    def test_run_identity_changed_before_finish_rejected(self):
        f = self.fixture
        before = f.begin()
        with patch.dict(os.environ, {'GITHUB_RUN_ATTEMPT': '4'}):
            with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_RUN_IDENTITY_CHANGED'):
                f.finish(before)

    def test_wrong_repository_and_invalid_identity_rejected(self):
        f = self.fixture
        for key, value, message in [('GITHUB_REPOSITORY', 'wrong/repository', 'TOOLCHAIN_REPOSITORY_CHANGED'),
                                    ('GITHUB_SHA', 'not-a-commit', 'TOOLCHAIN_BUILD_COMMIT_INVALID'),
                                    ('GITHUB_RUN_ID', '', 'TOOLCHAIN_BUILD_RUN_IDENTITY_MISSING')]:
            with self.subTest(key=key), patch.dict(os.environ, {key: value}):
                with self.assertRaisesRegex(ValueError, message):
                    f.begin()

    def test_saved_build_command_byte_change_rejected(self):
        f = self.fixture
        f.completed()
        f.command_file.write_text(f.command_file.read_text() + '\n')
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_BUILD_COMMAND_RECEIPT_CHANGED'):
            f.verify()

    def test_saved_installed_packages_byte_change_rejected(self):
        f = self.fixture
        f.completed()
        p = f.out / 'INSTALLED_PACKAGES.tsv'
        p.write_text(p.read_text() + 'HOST_FIXTURE_TAMPER\t0\n')
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_PACKAGES_RECEIPT_CHANGED'):
            f.verify()

    def test_legacy_report_without_live_capture_cannot_pass(self):
        f = self.fixture
        f.completed()
        report = f.report()
        report.pop('capture_phase')
        f.write_report(report)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_LIVE_CAPTURE_NOT_PROVEN'):
            f.verify()

    def test_saved_before_after_disagreement_rejected(self):
        f = self.fixture
        f.completed()
        report = f.report()
        report['toolchain_after']['clang']['bytes'] += 1
        f.write_report(report)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_BEFORE_AFTER_PROOF_CHANGED'):
            f.verify()

    def test_saved_pin_change_rejected_even_if_internal_copies_are_consistent(self):
        f = self.fixture
        f.completed()
        report = f.report()
        before_path = f.out / f.recorder.BEFORE_FILE
        before = json.loads(before_path.read_text())
        for table in (before['toolchain'], report['toolchain_before'], report['toolchain_after']):
            table['clang']['sha256'] = '0' * 64
        report['toolchain']['clang']['sha256'] = '0' * 64
        before_path.write_text(json.dumps(before, indent=2) + '\n')
        report['before_receipt_sha256'] = digest(before_path)
        f.write_report(report)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_SAVED_PIN_CHANGED:clang'):
            f.verify()

    def test_saved_original_auditor_or_producer_identity_changed_rejected(self):
        f = self.fixture
        f.completed()
        original = f.report()
        for key in ('original_auditor_sha256', 'producer_sha256'):
            with self.subTest(key=key):
                report = copy.deepcopy(original)
                report[key] = '0' * 64
                f.write_report(report)
                with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_RECEIPT_PRODUCER_CHANGED'):
                    f.verify()

    def test_saved_original_audit_tool_table_changed_rejected(self):
        f = self.fixture
        f.completed()
        report = f.report()
        report['toolchain']['clang']['resolved_path'] = str(f.runner_bin / 'clang')
        f.write_report(report)
        with self.assertRaisesRegex(ValueError, 'TOOLCHAIN_ORIGINAL_AUDIT_RECEIPT_CHANGED'):
            f.verify()


if __name__ == '__main__':
    unittest.main(verbosity=2)
