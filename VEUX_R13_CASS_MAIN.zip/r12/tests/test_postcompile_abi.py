#!/usr/bin/env python3
"""Regression tests for the explicit R12 CI-R2 postcompile ABI revision.

The ABI bytes and historical reference archives are authentic. Full verify()
integration uses an explicitly synthetic, non-bootable Image and small report
fixtures in a TemporaryDirectory. It proves gate behavior, never a new compile,
real CI Image/AK3 validation or a device boot. No production function is mocked.
"""
from __future__ import annotations

import argparse
import contextlib
import difflib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import random
import shutil
import sys
import tempfile
import unittest
import zipfile

sys.dont_write_bytecode = True
PAYLOAD = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PAYLOAD / 'r12'))
from veux_r11_ci_abi_hook import AbiOrderBlocked
import verify_legacy_result_r2 as revised

ORIGINAL_SHA = '74f6df5b4300b7dd21556b5dc21dc8128831368541e709df66369021e50e8537'
REFERENCE_SHA = '6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec'
ACTUAL_SHA = '0b5f909c68ec375533e961ac106da49c71b25f4fc99e6d13d0d093a52a540ec2'
CANONICAL_SHA = 'bc8c9db3aff0f0a6af92f0574792676fcc71ba260351bb57a9d42f1d79cdba12'
CONFIG_SHA = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
R4_RELATIVE = Path('nested_r5_r4_r2/r5/evidence/VEUX_R4_RUN39008125408_AUDIT_ORIGINAL.zip')
R5_RELATIVE = Path('evidence/VEUX_R5_RUN39104446746_AUDIT_ORIGINAL.zip')
BASE = 'builds/diagnostics/5.4.274/'
UNIT_IMAGE = b'R12_EXPLICIT_UNIT_TEST_ONLY_NOT_A_BOOTABLE_KERNEL\n'
EVIDENCE = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load_original():
    path = PAYLOAD / 'r12/reference/legacy_r5s1_verify_result.py'
    if sha(path.read_bytes()) != ORIGINAL_SHA:
        raise ValueError('ORIGINAL_AUDITOR_REFERENCE_CHANGED')
    spec = importlib.util.spec_from_file_location('r12_original_postcompile_auditor', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def preservation_proof():
    original_path = PAYLOAD / 'r12/reference/legacy_r5s1_verify_result.py'
    revised_path = PAYLOAD / 'r12/verify_legacy_result_r2.py'
    before, after = original_path.read_text(), revised_path.read_text()
    if sha(before.encode()) != ORIGINAL_SHA:
        raise ValueError('ORIGINAL_AUDITOR_REFERENCE_CHANGED')
    normalized = after.replace('\nfrom veux_r11_ci_abi_hook import validate_symvers_bytes\n', '', 1)
    start = normalized.index('def compare_symvers_abi(')
    end = normalized.index('def verify(', start)
    normalized = normalized[:start] + normalized[end:]
    normalized = normalized.replace(
        '    abi_comparison=compare_symvers_abi(original_symvers,ours_symvers)\n',
        "    ensure(ours_symvers==original_symvers,'R5S1_MODULE_SYMVERS_ABI_CHANGED_VS_R4')\n", 1)
    normalized = normalized.replace("        'abi_comparison':abi_comparison,\n", '', 1)
    # One extra newline was introduced immediately after the original import.
    normalized = normalized.replace('import sys\n\n\n', 'import sys\n\n', 1)
    if normalized != before:
        raise ValueError('AUDITOR_CHANGED_OUTSIDE_EXPLICIT_ABI_REVISION')
    return {'status': 'EXACT_ORIGINAL_FLOW_PRESERVED_EXCEPT_DOCUMENTED_ABI_COMPARISON',
            'original_sha256': sha(before.encode()), 'revision_sha256': sha(after.encode()),
            'changes': ['import existing strict ABI validator',
                        'compare every complete authenticated ABI row independent of row order',
                        'include actual and reference raw/canonical hashes in report'],
            'original_source_nomount_compile_image_ak3_archive_config_gates_preserved': True,
            'historical_reference_archives_still_require_original_sha_and_mutual_byte_equality': True,
            'unified_diff': ''.join(difflib.unified_diff(before.splitlines(keepends=True),
                after.splitlines(keepends=True), fromfile='legacy_r5s1_verify_result.py',
                tofile='verify_legacy_result_r2.py'))}


class PostcompileAbiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.original = load_original()
        overlay_text = os.environ.get('R5S1_OVERLAY')
        if not overlay_text:
            raise ValueError('R5S1_OVERLAY_REQUIRED_FOR_AUTHENTIC_HISTORICAL_ARCHIVES')
        cls.overlay = Path(overlay_text).resolve(strict=True)
        cls.r4_path, cls.r5_path = cls.overlay / R4_RELATIVE, cls.overlay / R5_RELATIVE
        cls.r4_raw, cls.r5_raw = cls.r4_path.read_bytes(), cls.r5_path.read_bytes()
        if sha(cls.r4_raw) != revised.R4_AUDIT_SHA or sha(cls.r5_raw) != revised.R5_AUDIT_SHA:
            raise ValueError('AUTHENTIC_HISTORICAL_ARCHIVE_PIN_CHANGED')
        with zipfile.ZipFile(io.BytesIO(cls.r4_raw)) as z:
            if z.testzip() is not None:
                raise ValueError('R4_REFERENCE_CRC_FAILED')
            cls.reference = z.read(BASE + 'build/Module.symvers')
            cls.config = z.read(BASE + 'config-reports/actual-build.config')
        with zipfile.ZipFile(io.BytesIO(cls.r5_raw)) as z:
            if z.testzip() is not None:
                raise ValueError('R5_REFERENCE_CRC_FAILED')
            cls.r5_symvers = z.read('veux-r5-susfs-work/' + BASE + 'build/Module.symvers')
            cls.r5_config = z.read('veux-r5-susfs-work/' + BASE + 'config-reports/actual-build.config')
        cls.actual_path = Path(os.environ.get('R12_ABI_ACTUAL_SYMVERS',
            str(PAYLOAD / 'r12/reference/baseline-reordered.symvers'))).resolve(strict=True)
        cls.actual = cls.actual_path.read_bytes()
        if sha(cls.reference) != REFERENCE_SHA or sha(cls.actual) != ACTUAL_SHA:
            raise ValueError('AUTHENTIC_ABI_TEST_FIXTURE_CHANGED')
        if cls.reference != cls.r5_symvers or cls.config != cls.r5_config or sha(cls.config) != CONFIG_SHA:
            raise ValueError('AUTHENTIC_R4_R5_REFERENCE_DISAGREEMENT')
        actual_config = os.environ.get('R12_ABI_ACTUAL_CONFIG')
        if actual_config and Path(actual_config).read_bytes() != cls.config:
            raise ValueError('ACTUAL_CI_CONFIG_DIFFERS_FROM_UNCHANGED_REFERENCE')
        cls.rows = cls.actual[:-1].split(b'\n')
        cls.snapshots = {cls.r4_path: sha(cls.r4_raw), cls.r5_path: sha(cls.r5_raw),
                         cls.actual_path: sha(cls.actual)}
        EVIDENCE.update(preservation=preservation_proof(),
            abi_inputs={'reference_sha256': sha(cls.reference), 'current_sha256': sha(cls.actual),
                        'canonical_sha256': CANONICAL_SHA, 'records': 12947,
                        'current_path': str(cls.actual_path), 'config_sha256': sha(cls.config),
                        'actual_ci_config_checked': bool(actual_config)},
            historical_archives={'r4_sha256': sha(cls.r4_raw), 'r5_sha256': sha(cls.r5_raw)})

    @classmethod
    def tearDownClass(cls):
        unchanged = all(sha(path.read_bytes()) == digest for path, digest in cls.snapshots.items())
        EVIDENCE['original_inputs_unchanged'] = unchanged
        if not unchanged:
            raise ValueError('TEST_MODIFIED_AUTHENTIC_INPUT')

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='r12-abi-unit-')
        self.root = Path(self.temporary.name) / 'explicit-unit-fixture'
        self.root.mkdir()

    def tearDown(self):
        self.temporary.cleanup()

    def fixture(self, symvers=None):
        """Small synthetic positive gate fixture, expressly not a kernel build."""
        public = self.root / 'public/5.4.274'
        report = self.root / 'report'
        compiled = self.root / BASE
        for directory in (public, report, compiled / 'build', compiled / 'config-reports'):
            directory.mkdir(parents=True, exist_ok=True)
        row = {'fixture_kind': 'SYNTHETIC_UNIT_TEST_NOT_CI_BUILD',
               'bakasu_sync_f308_d726_r5': {'source_sha256': revised.EXPECTED_SOURCE},
               'nomount211_r2': {'strong_stack_protector_on_nomount_object': True,
                                'thinlto_on_nomount_object': True},
               'compile': True, 'package': True, 'static_boot': True, 'device': False,
               'image_sha256': sha(UNIT_IMAGE)}
        (public / 'RESULT.json').write_text(json.dumps(row))
        source_proof = {'fixture_kind': 'SYNTHETIC_UNIT_TEST_NOT_CI_BUILD',
            'status': 'EXPERIMENTAL_SYNC_F308_D726_R5_KERNEL_BUILT_NOT_DEVICE_TESTED',
            'flash_release': False, 'device_pass': False}
        (report / 'BAKASU_SYNC_F308_D726_R5_FINAL.json').write_text(json.dumps(source_proof))
        with zipfile.ZipFile(public / 'UNIT_FIXTURE_AnyKernel_RMNET.zip', 'w') as z:
            z.writestr('Image', UNIT_IMAGE)
        (compiled / 'build/Module.symvers').write_bytes(self.actual if symvers is None else symvers)
        (compiled / 'config-reports/actual-build.config').write_bytes(self.config)
        return row

    def verify_fixture(self, module=revised, overlay=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return module.verify(self.root, self.overlay if overlay is None else overlay)

    def mutate_row(self, field):
        row = self.rows[0].split(b'\t')
        if field == 0:
            row[field] = f'0x{int(row[field], 16) ^ 1:08x}'.encode()
        elif field == 3:
            row[field] = b'EXPORT_SYMBOL_GPL' if row[field] == b'EXPORT_SYMBOL' else b'EXPORT_SYMBOL'
        else:
            row[field] += b'_CHANGED'
        return b'\n'.join([b'\t'.join(row), *self.rows[1:]]) + b'\n'

    def test_authentic_current_abi_matches_all_five_fields(self):
        proof = revised.compare_symvers_abi(self.reference, self.actual)
        self.assertEqual(proof['status'], 'ALL_FIVE_FIELD_ABI_RECORDS_MATCH')
        self.assertEqual(proof['actual']['canonical_sha256'], CANONICAL_SHA)
        self.assertEqual(proof['actual']['records'], 12947)
        self.assertEqual(proof['actual']['fields_checked'], ['crc', 'symbol', 'provider', 'export', 'namespace'])
        self.assertEqual(proof['reference']['raw_sha256'], REFERENCE_SHA)
        self.assertEqual(proof['actual']['raw_sha256'], ACTUAL_SHA)
        self.assertFalse(proof['raw_bytes_equal'])
        self.assertTrue(proof['difference_is_row_order_only'])
        self.assertFalse(proof['input_bytes_rewritten'])

    def test_other_real_row_permutations_are_accepted(self):
        shuffled = self.rows.copy()
        random.Random(40868038315).shuffle(shuffled)
        for name, rows in [('reverse', list(reversed(self.rows))), ('seeded_shuffle', shuffled)]:
            with self.subTest(name=name):
                proof = revised.compare_symvers_abi(self.reference, b'\n'.join(rows) + b'\n')
                self.assertEqual(proof['actual']['canonical_sha256'], CANONICAL_SHA)

    def test_each_real_abi_field_mutation_is_rejected(self):
        for field, name in enumerate(('crc', 'symbol', 'provider', 'export', 'namespace')):
            with self.subTest(field=name), self.assertRaisesRegex(AbiOrderBlocked, 'BASELINE_ABI_RECORDS_CHANGED'):
                revised.compare_symvers_abi(self.reference, self.mutate_row(field))

    def test_reference_is_validated_as_strictly_as_actual(self):
        with self.assertRaisesRegex(AbiOrderBlocked, 'BASELINE_ABI_RECORDS_CHANGED'):
            revised.compare_symvers_abi(self.mutate_row(0), self.actual)

    def test_duplicate_symbol_and_changed_counts_are_rejected(self):
        variants = {'same_count_duplicate': b'\n'.join([self.rows[1], *self.rows[1:]]) + b'\n',
                    'missing': b'\n'.join(self.rows[:-1]) + b'\n',
                    'extra': self.actual + self.rows[0] + b'\n'}
        for name, raw in variants.items():
            with self.subTest(name=name), self.assertRaises(AbiOrderBlocked):
                revised.compare_symvers_abi(self.reference, raw)

    def test_malformed_files_are_rejected(self):
        variants = {'missing_final_lf': self.actual[:-1], 'crlf': self.actual.replace(b'\n', b'\r\n'),
                    'nul': b'\x00' + self.actual[1:], 'non_ascii': b'\xff' + self.actual[1:],
                    'missing_tab': self.actual.replace(b'\t', b' ', 1),
                    'extra_tab': self.actual.replace(b'\t', b'\t\t', 1),
                    'bad_crc': b'0xzzzzzzzz' + self.actual[10:]}
        for name, raw in variants.items():
            with self.subTest(name=name), self.assertRaises(AbiOrderBlocked):
                revised.compare_symvers_abi(self.reference, raw)

    def test_other_production_checks_are_exactly_preserved(self):
        proof = preservation_proof()
        self.assertTrue(proof['original_source_nomount_compile_image_ak3_archive_config_gates_preserved'])

    def test_full_gate_retains_acceptance_of_original_order(self):
        self.fixture(self.reference)
        original = self.verify_fixture(self.original)
        result = self.verify_fixture()
        comparison = result.pop('abi_comparison')
        self.assertEqual(result, original)
        self.assertTrue(comparison['raw_bytes_equal'])

    def test_full_gate_reproduces_old_failure_and_accepts_only_reordered_abi(self):
        self.fixture()
        with self.assertRaisesRegex(ValueError, 'R5S1_MODULE_SYMVERS_ABI_CHANGED_VS_R4'):
            self.verify_fixture(self.original)
        self.assertFalse((self.root / 'report/R5S1_FINAL_INDEPENDENT_AUDIT.json').exists())
        result = self.verify_fixture()
        self.assertEqual(result['module_symvers_sha256'], ACTUAL_SHA)
        self.assertEqual(result['config_sha256'], CONFIG_SHA)
        self.assertTrue(result['abi_comparison']['difference_is_row_order_only'])
        self.assertFalse(result['device_pass'])
        self.assertFalse(result['flash_release'])
        self.assertEqual(json.loads((self.root / 'report/R5S1_FINAL_INDEPENDENT_AUDIT.json').read_text()), result)

    def test_full_gate_rejects_real_crc_mutation(self):
        self.fixture(self.mutate_row(0))
        with self.assertRaises(AbiOrderBlocked):
            self.verify_fixture()
        self.assertFalse((self.root / 'report/R5S1_FINAL_INDEPENDENT_AUDIT.json').exists())

    def test_full_gate_still_requires_exact_config(self):
        self.fixture()
        (self.root / BASE / 'config-reports/actual-build.config').write_bytes(self.config + b'# changed\n')
        with self.assertRaisesRegex(ValueError, 'R5S1_KERNEL_CONFIG_CHANGED_VS_R4'):
            self.verify_fixture()

    def test_full_gate_still_authenticates_built_image(self):
        self.fixture()
        with zipfile.ZipFile(self.root / 'public/5.4.274/UNIT_FIXTURE_AnyKernel_RMNET.zip', 'w') as z:
            z.writestr('Image', UNIT_IMAGE + b'changed')
        with self.assertRaisesRegex(ValueError, 'BUILT_IMAGE_SHA_MISMATCH'):
            self.verify_fixture()

    def test_full_gate_still_requires_compile_source_and_nomount_evidence(self):
        row = self.fixture()
        variants = [({'compile': False}, 'COMPILE_PACKAGE_STATIC_BOOT_NOT_GREEN'),
                    ({'bakasu_sync_f308_d726_r5': {'source_sha256': '0' * 64}}, 'EXACT_SYNC_SOURCE_NOT_COMPILED'),
                    ({'nomount211_r2': {'strong_stack_protector_on_nomount_object': False,
                                       'thinlto_on_nomount_object': True}}, 'NOMOUNT_PROTECTIONS_NOT_PRESERVED')]
        for delta, expected in variants:
            with self.subTest(expected=expected):
                changed = dict(row)
                changed.update(delta)
                (self.root / 'public/5.4.274/RESULT.json').write_text(json.dumps(changed))
                with self.assertRaisesRegex(ValueError, expected):
                    self.verify_fixture()

    def test_full_gate_still_rejects_mutated_reference_archives(self):
        self.fixture()
        overlay = Path(self.temporary.name) / 'unit-overlay'
        for relative, raw in ((R4_RELATIVE, self.r4_raw), (R5_RELATIVE, self.r5_raw)):
            path = overlay / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
        for relative, raw, message in ((R4_RELATIVE, self.r4_raw, 'R4_REFERENCE_AUDIT_CHANGED'),
                                       (R5_RELATIVE, self.r5_raw, 'COMPILED_R5_REFERENCE_AUDIT_DRIFT')):
            with self.subTest(reference=relative.as_posix()):
                (overlay / relative).write_bytes(raw + b'changed')
                with self.assertRaisesRegex(ValueError, message):
                    self.verify_fixture(overlay=overlay)
                (overlay / relative).write_bytes(raw)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(PostcompileAbiTests)
    outcome = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {'schema': 'veux-r12-ci-r2-postcompile-abi-tests-v1',
              'status': 'PASS' if outcome.wasSuccessful() else 'FAIL',
              'tests_run': outcome.testsRun, 'failures': len(outcome.failures), 'errors': len(outcome.errors),
              'kernel_compilation': False, 'device_test': False,
              'real_ci_image_or_ak3_validated': False,
              'real_ci_input_scope': 'complete Module.symvers and optional exact config only',
              'full_gate_integration_scope': 'explicit synthetic non-bootable Image and metadata; genuine ABI/config/reference archives',
              'production_functions_mocked': False, **EVIDENCE}
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(report, indent=2) + '\n')
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
