#!/usr/bin/env python3
"""R5S1 post-compile static binary, R4 ABI, and AK3 report gate.

Never approves flashing. The source branch's official Linux <5.10
manual-SUSFS-hook exclusion is retained and checked by the source preflight.
"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile
import sys

KERNEL='5.4.274'
IMAGE_R4='e11853f4f98eb8a4231b9a02c52a5ca099dbead0e577d7934e7dc49c5e8ccb57'
EXPECTED_SOURCE='78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78'
R4_AUDIT_SHA='9d0a58fc8deafebade097b6cf8ddc4de333b08d2ae7c82edc470895236d7a0c8'
R5_AUDIT_SHA='746f997e85d6bad27c957dc99215c3d192550839257b72d2d527c88b52d660c7'

def ensure(ok:bool,msg:str):
    if not ok:raise ValueError(msg)

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()

def verify(root:Path,overlay:Path)->dict:
    root=root.resolve(strict=True);overlay=overlay.resolve(strict=True)
    row=json.loads((root/'public'/KERNEL/'RESULT.json').read_text())
    source_proof=json.loads((root/'report/BAKASU_SYNC_F308_D726_R5_FINAL.json').read_text())
    ensure(source_proof.get('status')=='EXPERIMENTAL_SYNC_F308_D726_R5_KERNEL_BUILT_NOT_DEVICE_TESTED' and
           source_proof.get('flash_release') is False and source_proof.get('device_pass') is False,
           'SYNC_BUILD_STATUS_FALSE')
    ensure(row.get('bakasu_sync_f308_d726_r5',{}).get('source_sha256')==EXPECTED_SOURCE,
           'EXACT_SYNC_SOURCE_NOT_COMPILED')
    ensure(row.get('nomount211_r2',{}).get('strong_stack_protector_on_nomount_object') is True and
           row['nomount211_r2'].get('thinlto_on_nomount_object') is True,
           'NOMOUNT_PROTECTIONS_NOT_PRESERVED')
    ensure(all(row.get(k) is True for k in ('compile','package','static_boot')) and
           row.get('device') is False,'COMPILE_PACKAGE_STATIC_BOOT_NOT_GREEN')
    ensure(row.get('image_sha256')!=IMAGE_R4,'SYNCSUSFS_KERNEL_IMAGE_IDENTICAL_TO_R4')
    ziplist=list((root/'public'/KERNEL).glob('*_AnyKernel_RMNET.zip'))
    ensure(len(ziplist)==1,'AK3_NOT_UNIQUE')
    with zipfile.ZipFile(ziplist[0]) as z:
        ensure(z.testzip() is None,'AK3_INTERNAL_CRC_FAIL')
        built=z.read('Image')
    ensure(sha(built)==row['image_sha256'],'BUILT_IMAGE_SHA_MISMATCH')
    audit=overlay/'nested_r5_r4_r2/r5/evidence/VEUX_R4_RUN39008125408_AUDIT_ORIGINAL.zip'
    ensure(sha(audit.read_bytes())==R4_AUDIT_SHA,'R4_REFERENCE_AUDIT_CHANGED')
    base='builds/diagnostics/5.4.274/'
    with zipfile.ZipFile(audit) as z:
        ensure(z.testzip() is None,'R4_REFERENCE_ZIP_CRC_FAIL')
        original_symvers=z.read(base+'build/Module.symvers')
        original_config=z.read(base+'config-reports/actual-build.config')
    r5audit=overlay/'evidence/VEUX_R5_RUN39104446746_AUDIT_ORIGINAL.zip'
    ensure(sha(r5audit.read_bytes())==R5_AUDIT_SHA,'COMPILED_R5_REFERENCE_AUDIT_DRIFT')
    with zipfile.ZipFile(r5audit) as z:
        ensure(z.testzip() is None,'COMPILED_R5_REFERENCE_CRC_BAD')
        r5symvers=z.read('veux-r5-susfs-work/'+base+'build/Module.symvers')
        r5config=z.read('veux-r5-susfs-work/'+base+'config-reports/actual-build.config')
    ensure(r5symvers==original_symvers and r5config==original_config,
           'ORIGINAL_R4_AND_R5_ABI_REFERENCES_DISAGREE')
    compiled=root/'builds/diagnostics/5.4.274'
    ours_symvers=(compiled/'build/Module.symvers').read_bytes()
    ours_config=(compiled/'config-reports/actual-build.config').read_bytes()
    ensure(ours_symvers==original_symvers,'R5S1_MODULE_SYMVERS_ABI_CHANGED_VS_R4')
    ensure(ours_config==original_config,'R5S1_KERNEL_CONFIG_CHANGED_VS_R4')
    result={'status':'R5S1_COMPILE_AK3_CONFIG_MODULE_SYMVERS_PASS_DEVICE_NOT_TESTED',
        'image_sha256':row['image_sha256'],
        'ak3_sha256':sha(ziplist[0].read_bytes()),
        'module_symvers_sha256':sha(ours_symvers),
        'config_sha256':sha(ours_config),
        'official_f308_sync_susfs_reconciled_with_d726':True,
        'r3_r5_runtime_guards_preserved':True,
        'bakasu_32bit_522_not_integrated':True,
        'susfs_full_newer_510_host_patch_not_integrated':True,
        'device_pass':False,'flash_release':False}
    (root/'report/R5S1_FINAL_INDEPENDENT_AUDIT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R5S1_R4_MODULE_ABI_CONFIG_AK3_BINARY=PASS; NO_FLASH_PERMISSION',flush=True)
    return result

def main()->int:
    p=argparse.ArgumentParser()
    p.add_argument('--work',type=Path,required=True)
    p.add_argument('--overlay',type=Path,required=True)
    a=p.parse_args()
    try:verify(a.work,a.overlay)
    except Exception as exc:
        print('R5S1_FINAL_AUDIT_BLOCKED:'+type(exc).__name__+':'+str(exc),file=sys.stderr)
        return 1
    return 0
if __name__=='__main__':raise SystemExit(main())
