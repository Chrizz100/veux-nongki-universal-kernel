#!/usr/bin/env python3
"""Prove the native5.4 parser selected by the actual recorded compiler invocation."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
from source_update import require, sha


def function(text, name):
    matches = list(re.finditer(r'\b' + re.escape(name) + r'\s*\(', text))
    bodies = []
    for match in matches:
        pos, depth = match.end(), 1
        while pos < len(text) and depth:
            depth += (text[pos] == '(') - (text[pos] == ')')
            pos += 1
        while pos < len(text) and text[pos].isspace():
            pos += 1
        if pos == len(text) or text[pos] != '{':
            continue
        start, depth = pos, 1
        pos += 1
        while pos < len(text) and depth:
            depth += (text[pos] == '{') - (text[pos] == '}')
            pos += 1
        require(depth == 0, 'R13_PREPROCESSED_FUNCTION_TRUNCATED:' + name)
        bodies.append(text[start:pos])
    require(len(bodies) == 1, 'R13_PREPROCESSED_FUNCTION_COUNT:' + name)
    return bodies[0]


def verify(candidate, obj, evidence, captured, baseline_work):
    candidate, obj, evidence = Path(candidate), Path(obj), Path(evidence)
    files = sorted(obj.rglob('.selinux_hide.o.cmd'))
    require(len(files) == 1, 'R13_SELINUX_ACTUAL_COMMAND_MISSING_OR_AMBIGUOUS')
    cmdfile = files[0]
    objectfile = cmdfile.with_name('selinux_hide.o')
    require(objectfile.is_file() and objectfile.read_bytes()[:4] == b'BC\xc0\xde', 'R13_SELINUX_ACTUAL_BITCODE_MISSING')
    protected = {p: sha(p) for p in (cmdfile, objectfile)}
    commands = [line.split(' := ',1)[1] for line in cmdfile.read_text().splitlines()
                if line.startswith('cmd_') and ' := ' in line]
    require(len(commands) == 1, 'R13_AMBIGUOUS_RECORDED_COMMAND')
    argv = shlex.split(commands[0])
    require(Path(argv[0]).name == 'clang' and argv.count('-c') == 1 and argv.count('-o') == 1,
            'R13_UNEXPECTED_COMPILER_COMMAND')
    require(not any(token in (';', '&&', '|', '||', '>', '<') for token in argv), 'R13_SHELL_COMMAND_FORBIDDEN')
    require(any(token.endswith('/feature/selinux_hide.c') for token in argv), 'R13_WRONG_COMPILE_SOURCE')
    # Drop only output/dependency destinations and change compile to preprocess.
    # Every include, target, config and feature flag stays identical.
    replay, index = [], 0
    while index < len(argv):
        item = argv[index]
        if item == '-o':
            index += 2
            continue
        if item == '-c':
            replay += ['-E', '-P']
        elif item.startswith('-Wp,-MMD,') or item.startswith('-Wp,-MD,'):
            pass
        else:
            replay.append(item)
        index += 1
    env = dict(os.environ, **captured['env'])
    env.pop('VEUX_CAPTURE', None)
    wrapper = str(Path(baseline_work) / 'source-temp/bin')
    env['PATH'] = os.pathsep.join(p for p in env['PATH'].split(os.pathsep) if p != wrapper)
    output = evidence / 'R13_SELINUX_PREPROCESSED.c'
    with output.open('w') as stream:
        proc = subprocess.run(replay, cwd=obj, env=env, text=True, stdout=stream, stderr=subprocess.PIPE)
    (evidence / 'R13_SELINUX_PREPROCESS.log').write_text(proc.stderr)
    require(proc.returncode == 0, 'R13_ACTUAL_PREPROCESS_FAILED:' + proc.stderr[-2000:])
    text = output.read_text()
    parser = function(text, 'string_to_context_struct')
    converter = function(text, 'ksu_security_context_to_sid')
    require('orig_scontextp' not in parser and 'orig_valid' in parser
            and 'source_len - offset' in parser and 'orig_typdatum->attribute' in parser,
            'R13_NATIVE_SINGLE_PARSE_BRANCH_NOT_SELECTED')
    require(converter.count('kmemdup_nul(') == 1 and 'orig_scontext2' not in converter
            and 'ksu_lock_sepolicy_legacy()' in converter
            and 'ksu_unlock_sepolicy_legacy()' in converter,
            'R13_NATIVE_SINGLE_BUFFER_OR_LEGACY_LOCK_NOT_SELECTED')
    require('context_add_hash(policydb, &context)' in converter
            and 'context_add_hash(orig_policydb, &orig_context)' in converter,
            'R13_NATIVE_CONTEXT_HASH_SUPPORT_NOT_SELECTED')
    header = obj / 'include/generated/uapi/linux/version.h'
    require(header.is_file(), 'R13_GENERATED_VERSION_HEADER_MISSING')
    match = re.search(r'^#define LINUX_VERSION_CODE (\d+)$', header.read_text(), re.MULTILINE)
    require(match is not None and 328704 <= int(match.group(1)) < 328960,
            'R13_REAL_VERSION_CODE_NOT_NATIVE54')
    unchanged = all(sha(p) == before for p,before in protected.items())
    require(unchanged, 'R13_PREPROCESS_CHANGED_COMPILED_OUTPUTS')
    proof = {'status':'ACTUAL_NATIVE54_BRANCH_PASS', 'source_sha256':sha(candidate/'KernelSU/kernel/feature/selinux_hide.c'),
             'single_buffer_native_parser_active':True, 'legacy_lock_and_context_hash_active':True,
             'original_object_and_command_unchanged':unchanged,
             'actual_compile_command_sha256':protected[cmdfile], 'compiled_object_sha256':protected[objectfile],
             'preprocessed_sha256':sha(output), 'parser_sha256':hashlib.sha256(parser.encode()).hexdigest(),
             'converter_sha256':hashlib.sha256(converter.encode()).hexdigest(),
             'version_header_sha256':sha(header), 'linux_version_code':int(match.group(1)),
             'replayed_argv':replay, 'cwd':str(obj), 'device_test':False}
    (evidence/'R13_NATIVE_BRANCH.json').write_text(json.dumps(proof,indent=2)+'\n')
    return proof
