#!/usr/bin/env python3
"""Compile actual production parser/converter under API fault injection."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    here = Path(__file__).resolve().parent
    data = a.source.read_bytes()
    text = data.decode()
    start = text.index("#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 4, 0)", text.index(" * Caveat:  Mutates scontext."))
    stop = text.index("\n/*\n * Write the security context string", start)
    fragment = text[start:stop]
    harness = (here / "native_harness_prefix.c").read_text() + fragment + (here / "native_harness_suffix.c").read_text()
    f = a.out / "actual_source_harness.c"
    f.write_text(harness)
    reports = []
    for name, flags in (("native54_hash", []), ("native54_no_hash", ["-DTEST_WITHOUT_HASH=1"]),
                        ("native54_sanitizers", ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"])):
        binary = a.out / name
        command = ["gcc", "-std=gnu11", "-O1", "-g", "-Wall", "-Wextra", "-Werror", *flags, str(f), "-o", str(binary)]
        compile_result = subprocess.run(command, capture_output=True, text=True)
        (a.out / (name + ".compile.log")).write_text(compile_result.stdout + compile_result.stderr)
        compile_result.check_returncode()
        # This executor is ptrace-managed, where LeakSanitizer cannot inspect
        # /proc/<pid>/task. Exact allocation/context balance is asserted by the
        # harness; AddressSanitizer and UndefinedBehaviorSanitizer remain on.
        env = dict(os.environ, ASAN_OPTIONS="detect_leaks=0:halt_on_error=1", UBSAN_OPTIONS="halt_on_error=1:print_stacktrace=1")
        run = subprocess.run([str(binary.resolve())], capture_output=True, text=True, env=env)
        (a.out / (name + ".log")).write_text(run.stdout + run.stderr)
        run.check_returncode()
        line = next(x for x in run.stdout.splitlines() if x.startswith("NATIVE54_CONTRACT_CASES="))
        reports.append({"name": name, "command": command, "returncode": run.returncode, "summary": line})
        print(name, line)
    result = {"status": "ACTUAL_NATIVE54_FUNCTION_CONTRACTS_PASS", "source_sha256": sha(data),
              "extracted_fragment_sha256": sha(fragment.encode()), "harness_sha256": sha(harness.encode()),
              "tests": reports, "device_test": False, "full_policy_vm_test": False,
              "api_model": "Controlled policy-local IDs, destructively parsed MLS buffer, allocation/context ownership, legacy locking, hash and SID faults.",
              "source_rewritten_for_test": False, "kernel_build": False,
              "leak_sanitizer": "Unavailable under executor ptrace; harness asserts zero live allocations and exact context init/destroy balance."}
    (a.out / "NATIVE_FUNCTION_TEST_RESULT.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
