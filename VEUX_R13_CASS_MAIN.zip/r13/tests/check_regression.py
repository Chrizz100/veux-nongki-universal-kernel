#!/usr/bin/env python3
"""Original-source negative control and other-kernel branch equivalence."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess


def fragment(text, revised=False):
    marker = "#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 4, 0)" if revised else "static int string_to_context_struct("
    start = text.index(marker, text.index(" * Caveat:  Mutates scontext."))
    stop = text.index("\n/*\n * Write the security context string", start)
    return text[start:stop]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--base", type=Path, required=True)
    p.add_argument("--candidate", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)
    here = Path(__file__).resolve().parent
    texts = {"base": a.base.read_text(), "candidate": a.candidate.read_text()}
    parts = {k: fragment(v, k == "candidate") for k,v in texts.items()}
    prefix = (here / "native_harness_prefix.c").read_text()
    setup = (here / "native_harness_suffix.c").read_text().split("static void balanced(")[0]
    tail = r'''
int main(void)
{
    setup("backup SID failure negative control");
    t.sid_error[0] = -ENOMEM;
    u32 sid = 91, live_sid = 92;
    int live_rc = 93;
    const char *input = "u:r:t:s0:c1,c2-s0:c1.c3";
    int rc = ksu_security_context_to_sid(&t.pol[1], &t.tabs[1], &t.pol[0], &t.tabs[0],
                                          input, strlen(input), &sid, 42, 123, &live_sid, &live_rc);
    CHECK(rc == -ENOMEM);
    CHECK(t.allocations_live == 0 && t.mls_live == 0);
    CHECK(t.context_inits == t.context_destroys);
    CHECK(t.locks == 1 && t.unlocks == 1 && t.lock_depth == 0);
    printf("backup_rc=%d; live_rc=%d; backup_sid_calls=%d; live_sid_calls=%d; live_sid=%u\n",
           rc, live_rc, t.sid_calls[0], t.sid_calls[1], live_sid);
    /* Return42 identifies the actual old unwanted live mutation. */
    return t.sid_calls[1] != 0 ? 42 : 0;
}
'''
    negative = {}
    for key, part in parts.items():
        src = a.out / (key + "_negative_control.c")
        binary = a.out / (key + "_negative_control")
        src.write_text(prefix + part + setup + tail)
        proc = subprocess.run(["gcc", "-std=gnu11", "-O1", "-Wall", "-Wextra", "-Werror", "-Wno-unused-parameter",
                               str(src), "-o", str(binary)], capture_output=True, text=True)
        (a.out / (key + "_negative.compile.log")).write_text(proc.stdout + proc.stderr)
        proc.check_returncode()
        run = subprocess.run([str(binary.resolve())], capture_output=True, text=True)
        expected = 42 if key == "base" else 0
        if run.returncode != expected:
            raise AssertionError((key, expected, run.returncode, run.stdout, run.stderr))
        negative[key] = {"exit_code": run.returncode, "expected_exit_code": expected, "output": run.stdout}
        print(key, run.stdout.strip())
    equal = []
    for version, modern in (("4,19,0",False), ("5,3,0",False), ("5,4,274",True), ("5,10,0",False), ("6,18,0",False)):
        prelude = ("#define KERNEL_VERSION(a,b,c) (((a)<<16)+((b)<<8)+((c)>255?255:(c)))\n"
                   "#define LINUX_VERSION_CODE KERNEL_VERSION(" + version + ")\n"
                   "#define KSU_COMPAT_USE_SELINUX_STATE 1\n"
                   "#define KSU_COMPAT_HAS_CONTEXT_ADD_HASH 1\n")
        if modern:
            prelude += "#define KSU_COMPAT_HAS_SELINUX_POLICY_STRUCT 1\n"
        outputs = []
        for part in parts.values():
            run = subprocess.run(["gcc", "-E", "-P", "-x", "c", "-"], input=prelude + part,
                                 capture_output=True, text=True)
            run.check_returncode()
            outputs.append(run.stdout)
        if outputs[0] != outputs[1]:
            raise AssertionError("Other-kernel preprocessed branch differs: " + version)
        equal.append({"version": version, "modern_policy_struct": modern,
                      "preprocessed_byte_identical": True,
                      "sha256": hashlib.sha256(outputs[0].encode()).hexdigest()})
    result = {"status": "ORIGINAL_BUG_REPRODUCED_AND_FIXED_PATH_CHECKED",
              "negative_control": negative, "other_kernel_branches": equal,
              "device_test": False, "kernel_build": False,
              "scope": "Actual extracted C functions under controlled API failures; not a live-device fault injection."}
    (a.out / "REGRESSION_CONTROL_RESULT.json").write_text(json.dumps(result,indent=2) + "\n")
    print("OTHER_KERNEL_PREPROCESSED_BRANCHES_BYTE_EQUAL", len(equal))


if __name__ == "__main__":
    main()
