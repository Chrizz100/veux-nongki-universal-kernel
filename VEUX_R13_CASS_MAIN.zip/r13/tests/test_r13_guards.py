#!/usr/bin/env python3
"""Regress the security boundaries newly introduced by the genuine R13 source layer."""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
sys.path[:0]=[str(HERE.parent),str(HERE.parents[1]/'r11')]
import record_environment_r13 as environment
import r13_source_update as source
from verify_native_branch import function
sys.path.insert(0, str(HERE.parent/'packaging'))
from collect_builtin import phase_source_cwd


class IdentityTests(unittest.TestCase):
    def env(self,mode='ci'):
        return {'GITHUB_REPOSITORY':environment.EXPECTED_REPOSITORY,'GITHUB_SHA':'a'*40,
                'GITHUB_ACTIONS':'true' if mode=='ci' else 'false','VEUX_EXECUTION_MODE':mode,
                'GITHUB_RUN_ID':'19' if mode=='ci' else '0','GITHUB_RUN_ATTEMPT':'1' if mode=='ci' else '0'}
    def test_hosted_identity(self):
        with patch.dict(os.environ,self.env(),clear=True):
            self.assertEqual(environment.identity()['execution_mode'],'ci')
    def test_local_identity(self):
        with patch.dict(os.environ,self.env('local-native'),clear=True):
            self.assertEqual(environment.identity()['execution_mode'],'local-native')
    def test_no_fabricated_hosted_identity(self):
        for field,value in [('GITHUB_ACTIONS','false'),('GITHUB_RUN_ID','0'),('GITHUB_RUN_ATTEMPT','0'),('VEUX_EXECUTION_MODE',''),('GITHUB_SHA','main')]:
            env=self.env();env[field]=value
            with self.subTest(field=field),patch.dict(os.environ,env,clear=True),self.assertRaises(ValueError):environment.identity()
    def test_local_mode_cannot_claim_run(self):
        for field,value in [('GITHUB_ACTIONS','true'),('GITHUB_RUN_ID','19'),('GITHUB_RUN_ATTEMPT','1')]:
            env=self.env('local-native');env[field]=value
            with self.subTest(field=field),patch.dict(os.environ,env,clear=True),self.assertRaises(ValueError):environment.identity()


class GenuineVersionTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);(self.root/'.git').mkdir()
        self.lock=source.contract()
        target=self.root/'kernel/feature/selinux_hide.c';target.parent.mkdir(parents=True)
        target.write_bytes((HERE.parent/'reference/selinux_hide.updated.c').read_bytes())
        self.values={('rev-parse','HEAD'):self.lock['bakasu_port_commit'],('rev-parse','HEAD^'):self.lock['bakasu_parent'],
                     ('rev-parse','HEAD^{tree}'):self.lock['bakasu_tree'],('rev-list','--count','HEAD'):'4554',
                     ('rev-parse','refs/tags/v4.2.0-rc3^{commit}'):source.TAG_COMMIT,
                     ('describe','--abbrev=0','--tags'):'v4.2.0-rc3',('status','--porcelain','--untracked-files=all'):'',
                     ('diff-tree','--no-commit-id','--name-only','-r','HEAD'):'kernel/feature/selinux_hide.c'}
        self.declared={'commit':self.lock['bakasu_port_commit'],'count':4554,'version':35254}
    def validate(self):
        with patch.object(source,'git',side_effect=lambda root,*args:self.values[args]):
            return source.validate_version(self.root,self.declared)
    def test_exact_genuine_child(self):self.assertEqual(self.validate()['version'],35254)
    def test_forged_history_or_source_rejected(self):
        for key,value in [(('rev-parse','HEAD'),'b'*40),(('rev-parse','HEAD^'),'b'*40),
                          (('rev-parse','HEAD^{tree}'),'b'*40),(('rev-list','--count','HEAD'),'4553'),
                          (('rev-parse','refs/tags/v4.2.0-rc3^{commit}'),'b'*40),
                          (('status','--porcelain','--untracked-files=all'),' M kernel/Kbuild'),
                          (('diff-tree','--no-commit-id','--name-only','-r','HEAD'),'kernel/Kbuild')]:
            old=self.values[key];self.values[key]=value
            with self.subTest(key=key),self.assertRaises(ValueError):self.validate()
            self.values[key]=old
    def test_version_override_rejected(self):
        self.declared['version']=35253
        with self.assertRaises(ValueError):self.validate()
    def test_shallow_history_rejected(self):
        (self.root/'.git/shallow').write_text('anything')
        with self.assertRaises(ValueError):self.validate()
    def test_changed_c_file_rejected(self):
        (self.root/'kernel/feature/selinux_hide.c').write_text('changed')
        with self.assertRaises(ValueError):self.validate()


class ActualBranchTests(unittest.TestCase):
    def test_only_definition_is_counted(self):
        text='int wanted(int x); int outer(void) { return wanted(1); } int wanted(int x) { if (x) { return 3; } return 2; }'
        self.assertEqual(function(text,'wanted'),'{ if (x) { return 3; } return 2; }')
    def test_missing_or_ambiguous_definition_rejected(self):
        for text in ('wanted(2);','int wanted(void) {} int wanted(void) {}'):
            with self.assertRaises(ValueError):function(text,'wanted')


class ReceiptCwdTests(unittest.TestCase):
    def test_original_process_cwd(self):
        self.assertTrue(phase_source_cwd({'cwd':'/tmp/source'},'/tmp/source'))
        self.assertFalse(phase_source_cwd({'cwd':'/tmp/other'},'/tmp/source'))
    def test_real_make_c_source_preserves_process_cwd(self):
        receipt={'cwd':'/tmp/outer','cwd_semantics':'make-C-source','effective_make_cwd':'/tmp/source',
                 'argv':['/usr/bin/make','-C','/tmp/source','Image','dtbs','modules']}
        self.assertTrue(phase_source_cwd(receipt,'/tmp/source'))
        self.assertEqual(receipt['cwd'],'/tmp/outer')
    def test_wrong_or_ambiguous_make_source_rejected(self):
        for argv,effective in [(['/usr/bin/make','-C','/tmp/other'],'/tmp/source'),
                               (['/usr/bin/make','-C','/tmp/source'],'/tmp/other'),
                               (['/usr/bin/make','-C','/tmp/source','-C','/tmp/other'],'/tmp/source'),
                               (['/usr/bin/make'],'/tmp/source'),
                               (['/usr/bin/make','-C','source'],'/tmp/source'),
                               (['/usr/bin/make','-C','/tmp/source'],'source'),
                               (['/bin/other','-C','/tmp/source'],'/tmp/source')]:
            receipt={'cwd':'/tmp/outer','cwd_semantics':'make-C-source','effective_make_cwd':effective,'argv':argv}
            with self.subTest(argv=argv,effective=effective),self.assertRaises(ValueError):phase_source_cwd(receipt,'/tmp/source')
    def test_unknown_semantics_and_relative_cwd_rejected(self):
        for receipt in ({'cwd':'/tmp/source','cwd_semantics':'anything'}, {'cwd':'source'}):
            with self.assertRaises(ValueError):phase_source_cwd(receipt,'/tmp/source')


if __name__=='__main__':unittest.main()
