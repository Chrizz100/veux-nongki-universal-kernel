/* Host contract harness: real production functions, controlled SELinux APIs.
 * This tests control flow, ownership and arguments, not a complete policy VM.
 */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + ((c) > 255 ? 255 : (c)))
#define LINUX_VERSION_CODE KERNEL_VERSION(5,4,274)
#define KSU_COMPAT_USE_SELINUX_STATE 1
#ifndef TEST_WITHOUT_HASH
#define KSU_COMPAT_HAS_CONTEXT_ADD_HASH 1
#endif
#define SECSID_NULL 0
typedef uint32_t u32;
typedef unsigned int gfp_t;
typedef int rwlock_t;

struct user_datum { u32 value; };
struct role_datum { u32 value; };
struct type_datum { u32 value; bool attribute; };
struct symtab { int policy, field; };
struct policydb {
    int id;
    struct symtab p_users, p_roles, p_types;
    struct user_datum user;
    struct role_datum role;
    struct type_datum type;
};
struct sidtab { int id; };
struct context { u32 user, role, type; char *mls; bool initialized, hashed; };
struct legacy_ss { rwlock_t policy_rwlock; };
static struct legacy_ss global_ss;
static struct { struct legacy_ss *ss; } selinux_state = { &global_ss };
rwlock_t *ksu_policy_rwlock_ptr;

static struct {
    struct policydb pol[2];
    struct sidtab tabs[2];
    int missing[2], attribute[2];
    bool invalid_policy[2], mls_disabled;
    int mls_error[2], hash_error[2], sid_error[2];
    int allocation_calls, allocation_fail, allocations_live;
    int context_inits, context_destroys, mls_live;
    int mls_calls[2], hash_calls[2], sid_calls[2], validity_calls[2];
    int locks, unlocks, lock_depth;
    int failures, cases;
    u32 default_sid;
    const char *expected_mls;
    const char *case_name;
} t;

#define CHECK(c) do { if (!(c)) { \
    fprintf(stderr, "FAIL %s line %d: %s\n", t.case_name, __LINE__, #c); \
    abort(); \
} } while (0)

static void read_lock(rwlock_t *p)
{
    CHECK(p == &global_ss.policy_rwlock);
    CHECK(t.lock_depth == 0);
    t.lock_depth++;
    t.locks++;
}

static void read_unlock(rwlock_t *p)
{
    CHECK(p == &global_ss.policy_rwlock);
    CHECK(t.lock_depth == 1);
    t.lock_depth--;
    t.unlocks++;
}

static char *kmemdup_nul(const char *source, size_t length, gfp_t flags)
{
    char *p;
    CHECK(flags == 123);
    CHECK(t.lock_depth == 0);
    t.allocation_calls++;
    if (t.allocation_fail == t.allocation_calls)
        return NULL;
    p = malloc(length + 1);
    CHECK(p != NULL);
    memcpy(p, source, length);
    p[length] = '\0';
    t.allocations_live++;
    return p;
}

static void kfree(void *p)
{
    if (p) {
        CHECK(t.allocations_live > 0);
        t.allocations_live--;
        free(p);
    }
}

static void context_init(struct context *c)
{
    memset(c, 0, sizeof(*c));
    c->initialized = true;
    t.context_inits++;
}

static void context_destroy(struct context *c)
{
    CHECK(t.lock_depth == 1);
    CHECK(c->initialized);
    c->initialized = false;
    if (c->mls) {
        CHECK(t.mls_live > 0);
        t.mls_live--;
        free(c->mls);
        c->mls = NULL;
    }
    t.context_destroys++;
}

static void *symtab_search(const struct symtab *s, const char *name)
{
    struct policydb *p = &t.pol[s->policy];
    CHECK(t.lock_depth == 1);
    if (t.missing[s->policy] == s->field)
        return NULL;
    if (s->field == 1 && !strcmp(name, "u"))
        return &p->user;
    if (s->field == 2 && !strcmp(name, "r"))
        return &p->role;
    if (s->field == 3 && !strcmp(name, "t")) {
        p->type.attribute = t.attribute[s->policy];
        return &p->type;
    }
    return NULL;
}

static int mls_context_to_sid(struct policydb *p, char oldc, char *input,
                              struct context *c, struct sidtab *s, u32 def_sid)
{
    int id = p->id;
    CHECK(t.lock_depth == 1);
    CHECK(s->id == id);
    CHECK(def_sid == t.default_sid);
    CHECK(c->user == p->user.value && c->role == p->role.value && c->type == p->type.value);
    t.mls_calls[id]++;
    if (!oldc) {
        /* A real MLS parser must not dereference the one-past-NUL pointer. */
        return t.mls_disabled ? 0 : -EINVAL;
    }
    CHECK(oldc == ':');
    CHECK(!strcmp(input, t.expected_mls));
    /* Allocate even on injected errors, matching partial MLS parse ownership. */
    c->mls = strdup(input);
    CHECK(c->mls != NULL);
    t.mls_live++;
    /* Destructively split multiple separators, as MLS parsing does. */
    for (size_t n = 0, len = strlen(input); n < len; n++)
        if (input[n] == ':' || input[n] == ',' || input[n] == '-' || input[n] == '.')
            input[n] = '\0';
    return t.mls_error[id];
}

static bool policydb_context_isvalid(struct policydb *p, struct context *c)
{
    CHECK(t.lock_depth == 1);
    CHECK(c->initialized);
    CHECK(c->user == p->user.value && c->role == p->role.value && c->type == p->type.value);
    t.validity_calls[p->id]++;
    return !t.invalid_policy[p->id];
}

#ifdef KSU_COMPAT_HAS_CONTEXT_ADD_HASH
static int context_add_hash(struct policydb *p, struct context *c)
{
    CHECK(t.lock_depth == 1);
    CHECK(c->initialized);
    CHECK(c->user == p->user.value && c->role == p->role.value && c->type == p->type.value);
    t.hash_calls[p->id]++;
    if (!t.hash_error[p->id])
        c->hashed = true;
    return t.hash_error[p->id];
}
#endif

static int sidtab_context_to_sid(struct sidtab *s, struct context *c, u32 *sid)
{
    struct policydb *p = &t.pol[s->id];
    CHECK(t.lock_depth == 1);
    CHECK(c->initialized);
#ifdef KSU_COMPAT_HAS_CONTEXT_ADD_HASH
    CHECK(c->hashed);
#endif
    CHECK(c->user == p->user.value && c->role == p->role.value && c->type == p->type.value);
    t.sid_calls[s->id]++;
    if (t.sid_error[s->id])
        return t.sid_error[s->id];
    *sid = (u32)(500 + 100 * s->id);
    return 0;
}

/* The test runner inserts the exact extracted production functions here. */
