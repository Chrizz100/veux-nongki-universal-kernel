
static void setup(const char *name)
{
    int cases = t.cases;
    memset(&t, 0, sizeof(t));
    t.cases = cases;
    t.case_name = name;
    t.expected_mls = "s0:c1,c2-s0:c1.c3";
    t.default_sid = 42;
    for (int i = 0; i < 2; i++) {
        t.pol[i].id = i;
        t.pol[i].p_users = (struct symtab){i, 1};
        t.pol[i].p_roles = (struct symtab){i, 2};
        t.pol[i].p_types = (struct symtab){i, 3};
        t.pol[i].user.value = 10 + 100 * i;
        t.pol[i].role.value = 20 + 100 * i;
        t.pol[i].type.value = 30 + 100 * i;
        t.tabs[i].id = i;
    }
}

static void balanced(void)
{
    CHECK(t.context_inits == t.context_destroys);
    CHECK(t.allocations_live == 0 && t.mls_live == 0);
    CHECK(t.locks == t.unlocks && t.lock_depth == 0);
    t.cases++;
    printf("PASS %s\n", t.case_name);
}

static void run_input(const char *input, size_t length, int expected_rc, int expected_live,
                       int backup_sid_calls, int live_sid_calls, bool omit_optional)
{
    u32 sid = 91, live_sid = 92;
    int live_rc = 93;
    char *copy = malloc(length ? length : 1);
    CHECK(copy != NULL);
    memcpy(copy, input, length);
    int rc = ksu_security_context_to_sid(&t.pol[1], &t.tabs[1], &t.pol[0], &t.tabs[0],
                                          input, length, &sid, t.default_sid, 123,
                                          omit_optional ? NULL : &live_sid,
                                          omit_optional ? NULL : &live_rc);
    CHECK(rc == expected_rc);
    if (!omit_optional)
        CHECK(live_rc == expected_live);
    CHECK(!memcmp(copy, input, length));
    free(copy);
    CHECK(t.sid_calls[0] == backup_sid_calls && t.sid_calls[1] == live_sid_calls);
    if (length && !t.allocation_fail) {
        CHECK(t.allocation_calls == 1);
        CHECK(t.locks == 1 && t.unlocks == 1);
        if (!omit_optional) {
            if (expected_live)
                CHECK(live_sid == 0);
            else
                CHECK(live_sid == 600);
        }
    } else {
        CHECK(sid == 91);
        CHECK(live_sid == 92 && live_rc == 93);
        CHECK(t.locks == 0);
    }
    balanced();
}

static void standard(int rc, int live, int backup_calls, int live_calls)
{
    const char *s = "u:r:t:s0:c1,c2-s0:c1.c3";
    run_input(s, strlen(s), rc, live, backup_calls, live_calls, false);
}

int main(void)
{
    setup("valid policy-local IDs, MLS suffix restored, single input allocation");
    standard(0, 0, 1, 1);
    CHECK(t.mls_calls[0] == 1 && t.mls_calls[1] == 1);
    CHECK(t.validity_calls[0] == 1 && t.validity_calls[1] == 1);

    setup("optional output pointers may be NULL");
    run_input("u:r:t:s0:c1,c2-s0:c1.c3", 23, 0, 0, 1, 1, true);

    setup("zero length returns EINVAL without allocation");
    run_input("", 0, -EINVAL, 93, 0, 0, false);
    CHECK(t.allocation_calls == 0);

    setup("input allocation ENOMEM does not lock or write outputs");
    t.allocation_fail = 1;
    standard(-ENOMEM, 93, 0, 0);

    const char *malformed[] = {"u", "u:", "u:r", ":r:t", "u::t", "u:r:",
                               "unknown:r:t:s0", "u:unknown:t:s0", "u:r:unknown:s0",
                               "\nu:r:t:s0"};
    for (size_t n = 0; n < sizeof(malformed)/sizeof(*malformed); n++) {
        char label[80];
        snprintf(label, sizeof(label), "malformed/unknown input %zu", n);
        setup(label);
        run_input(malformed[n], strlen(malformed[n]), -EINVAL, -EINVAL, 0, 0, false);
        CHECK(t.mls_calls[0] == 0 && t.mls_calls[1] == 0);
    }

    for (int field = 1; field <= 3; field++) {
        char label[80];
        snprintf(label, sizeof(label), "backup policy field %d absent", field);
        setup(label); t.missing[0] = field;
        standard(-EINVAL, -EINVAL, 0, 0);
        snprintf(label, sizeof(label), "live policy field %d absent", field);
        setup(label); t.missing[1] = field;
        standard(0, -EINVAL, 1, 0);
        CHECK(t.mls_calls[1] == 0);
    }

    setup("backup type attribute rejected");
    t.attribute[0] = 1; standard(-EINVAL, -EINVAL, 0, 0);
    setup("live type attribute does not enter live MLS or SID table");
    t.attribute[1] = 1; standard(0, -EINVAL, 1, 0);
    CHECK(t.mls_calls[1] == 0);

    setup("backup MLS EINVAL cleans both partially allocated contexts");
    t.mls_error[0] = -EINVAL; standard(-EINVAL, -EINVAL, 0, 0);
    setup("backup MLS ENOMEM preserves primary error and blocks SID sync");
    t.mls_error[0] = -ENOMEM; standard(-ENOMEM, -EINVAL, 0, 0);
    setup("live MLS ENOMEM preserves independent error");
    t.mls_error[1] = -ENOMEM; standard(0, -ENOMEM, 1, 0);
    setup("both MLS parsers fail without double free");
    t.mls_error[0] = -EINVAL; t.mls_error[1] = -ENOMEM;
    standard(-EINVAL, -EINVAL, 0, 0);
    setup("backup policy invalid blocks both SID tables");
    t.invalid_policy[0] = true; standard(-EINVAL, -EINVAL, 0, 0);
    setup("live policy invalid does not invalidate backup-local IDs");
    t.invalid_policy[1] = true; standard(0, -EINVAL, 1, 0);

#ifdef KSU_COMPAT_HAS_CONTEXT_ADD_HASH
    setup("backup hash ENOMEM blocks live hash and both SID writes");
    t.hash_error[0] = -ENOMEM; standard(-ENOMEM, -ENOMEM, 0, 0);
    CHECK(t.hash_calls[0] == 1 && t.hash_calls[1] == 0);
    setup("live hash failure keeps live SID output cleared");
    t.hash_error[1] = -EINVAL; standard(0, -EINVAL, 1, 0);
    CHECK(t.hash_calls[0] == 1 && t.hash_calls[1] == 1);
#endif

    setup("backup SID ENOMEM blocks live hash and SID");
    t.sid_error[0] = -ENOMEM; standard(-ENOMEM, -ENOMEM, 1, 0);
    CHECK(t.hash_calls[1] == 0);
    setup("backup SID ESTALE propagates without unsafe native retry");
    t.sid_error[0] = -ESTALE; standard(-ESTALE, -ESTALE, 1, 0);
    setup("live SID ENOMEM never publishes uninitialized SID");
    t.sid_error[1] = -ENOMEM; standard(0, -ENOMEM, 1, 1);
    setup("live SID ESTALE propagates under balanced native lock");
    t.sid_error[1] = -ESTALE; standard(0, -ESTALE, 1, 1);

    setup("missing MLS suffix follows MLS policy rejection");
    run_input("u:r:t", 5, -EINVAL, -EINVAL, 0, 0, false);
    setup("MLS-disabled policy permits missing suffix without pointer read");
    t.mls_disabled = true;
    run_input("u:r:t", 5, 0, 0, 1, 1, false);
    setup("empty MLS suffix safely restores terminating NUL");
    t.expected_mls = ""; t.mls_error[0] = -EINVAL; t.mls_error[1] = -EINVAL;
    run_input("u:r:t:", 6, -EINVAL, -EINVAL, 0, 0, false);

    setup("non-NUL-terminated input copied within explicit length");
    const char raw[] = {'u',':','r',':','t',':','s','0'};
    t.expected_mls = "s0";
    run_input(raw, sizeof(raw), 0, 0, 1, 1, false);

    setup("embedded NUL does not overrun supplied source length");
    const char embedded[] = "u:r:t:s0\0ignored";
    t.expected_mls = "s0";
    run_input(embedded, sizeof(embedded)-1, 0, 0, 1, 1, false);

    setup("long MLS input retains exact restoration beyond 128-byte boundary");
    char long_context[4096];
    memset(long_context, 'x', sizeof(long_context));
    memcpy(long_context, "u:r:t:s0:", 9);
    long_context[sizeof(long_context)-1] = '\0';
    t.expected_mls = long_context + 6;
    run_input(long_context, sizeof(long_context)-1, 0, 0, 1, 1, false);

    printf("NATIVE54_CONTRACT_CASES=%d; DEVICE_TEST=NO; REAL_POLICY_VM_TEST=NO\n", t.cases);
    return 0;
}
