#!/usr/bin/env python3
"""Advance the genuine BakaSU history by one authenticated SELinux-only commit."""
from __future__ import annotations
import json
from pathlib import Path
import subprocess
from source_update import inventory, require, sha

HERE = Path(__file__).resolve().parent
SOURCE = 'KernelSU/kernel/feature/selinux_hide.c'
OLD_COMMIT = '2cbbcc2363aa8d4b6286fc2266a338063b2b77a7'
OLD_PARENT = 'd5e9e025b8b49155f8014684d64c91742b465f65'
TAG_COMMIT = '239e1e8871b8fcd51a6e5b3002e0ba522fdd99fb'


def git(root, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(root), *args], text=True).strip()


def contract():
    result = json.loads((HERE / 'SOURCE_CONTRACT.json').read_text())
    require(result.get('schema') == 'veux-r13-source-v1', 'R13_SOURCE_CONTRACT_SCHEMA')
    require(result.get('bakasu_parent') == OLD_COMMIT and result.get('bakasu_count') == 4554
            and result.get('bakasu_version') == 35254 and result.get('bakasu_tag_commit') == TAG_COMMIT,
            'R13_GENUINE_HISTORY_CONTRACT_CHANGED')
    require(set(result['r13_changed_paths']) == {SOURCE}, 'R13_SOURCE_SCOPE_CHANGED')
    return result


def validate_version(root, declared):
    """Exact new history identity; the original R4 validator handles the old stage."""
    root = Path(root)
    lock = contract()
    require((root / '.git').is_dir() and not (root / '.git/shallow').exists(), 'R13_FULL_HISTORY_REQUIRED')
    commit, parent = git(root, 'rev-parse', 'HEAD'), git(root, 'rev-parse', 'HEAD^')
    tree, count = git(root, 'rev-parse', 'HEAD^{tree}'), int(git(root, 'rev-list', '--count', 'HEAD'))
    require(commit == lock['bakasu_port_commit'] and parent == OLD_COMMIT
            and tree == lock['bakasu_tree'] and count == 4554, 'R13_REAL_HISTORY_IDENTITY_CHANGED')
    require(declared.get('commit') == commit and declared.get('count') == count
            and declared.get('version') == 30700 + count, 'R13_DECLARED_VERSION_NOT_REAL_HISTORY')
    require(git(root, 'rev-parse', 'refs/tags/v4.2.0-rc3^{commit}') == TAG_COMMIT
            and git(root, 'describe', '--abbrev=0', '--tags') == 'v4.2.0-rc3', 'R13_GENUINE_TAG_CHANGED')
    require(not git(root, 'status', '--porcelain', '--untracked-files=all'), 'R13_BAKASU_DIRTY')
    require(sha(root / 'kernel/feature/selinux_hide.c') == lock['files'][SOURCE]['after_sha256'],
            'R13_SELINUX_SOURCE_CHANGED')
    changed = git(root, 'diff-tree', '--no-commit-id', '--name-only', '-r', 'HEAD').splitlines()
    require(changed == ['kernel/feature/selinux_hide.c'], 'R13_COMMIT_CHANGED_OTHER_SOURCE')
    return {'commit': commit, 'parent': parent, 'count': count, 'version': 30700 + count,
            'tag': 'v4.2.0-rc3'}


def apply(kernel, evidence, old_version):
    kernel, evidence = Path(kernel).resolve(strict=True), Path(evidence)
    report = evidence / 'R13_SOURCE_UPDATE.json'
    require(not report.exists(), 'R13_SOURCE_UPDATE_ALREADY_RECORDED')
    lock = contract()
    root = kernel / 'KernelSU'
    require(old_version == {'commit': OLD_COMMIT, 'parent': OLD_PARENT, 'count': 4553,
                            'version': 35253, 'tag': 'v4.2.0-rc3'}, 'R13_OLD_VERSION_PROOF_CHANGED')
    require(git(root, 'rev-parse', 'HEAD') == OLD_COMMIT
            and git(root, 'rev-parse', 'HEAD^') == OLD_PARENT
            and git(root, 'rev-list', '--count', 'HEAD') == '4553', 'R13_PARENT_HISTORY_CHANGED')
    subprocess.run(['git', '-C', str(root), 'update-index', '--refresh'], check=True, capture_output=True)
    require(not git(root, 'status', '--porcelain', '--untracked-files=all'), 'R13_PARENT_WORKTREE_DIRTY')
    require(sha(kernel / SOURCE) == lock['files'][SOURCE]['before_sha256'], 'R13_SOURCE_PREIMAGE_MISMATCH')
    for relative, item in lock['files'].items():
        if relative != SOURCE:
            require(sha(kernel / relative) == item['after_sha256'], 'R13_INHERITED_SOURCE_CHANGED:' + relative)
    bundle, patch = HERE / lock['bundle_file'], HERE / lock['patch_file']
    require(bundle.is_file() and not bundle.is_symlink() and sha(bundle) == lock['bundle_sha256'], 'R13_BUNDLE_PIN')
    require(patch.is_file() and not patch.is_symlink() and sha(patch) == lock['patch_sha256'], 'R13_PATCH_PIN')
    before = inventory(kernel)
    commands = [
        ['git', '-C', str(root), 'bundle', 'verify', str(bundle)],
        ['git', '-C', str(root), 'fetch', '--no-tags', str(bundle), lock['bundle_ref']],
        ['git', '-C', str(root), 'checkout', '--detach', lock['bakasu_port_commit']],
        ['git', '-C', str(root), 'update-index', '--refresh'],
        ['git', '-C', str(root), 'diff-index', '--quiet', 'HEAD', '--'],
    ]
    for command in commands:
        subprocess.run(command, check=True, capture_output=True, text=True)
    after = inventory(kernel)
    changed = {p for p in before.keys() | after.keys() if before.get(p) != after.get(p)}
    require(changed == {SOURCE}, 'R13_UNEXPECTED_SOURCE_DELTA:' + repr(sorted(changed)))
    declared = {'commit': lock['bakasu_port_commit'], 'count': 4554, 'version': 35254}
    version = validate_version(root, declared)
    proof = {'schema': 'veux-r13-source-update-v1', 'status': 'SOURCE_UPDATE_PASS',
             'source': str(kernel), 'changed_paths': sorted(changed),
             'files': {p: {'before': before[p], 'after': after[p]} for p in sorted(changed)},
             'inventory_files': len(before), 'all_other_source_files_unchanged': True,
             'source_contract_sha256': sha(HERE / 'SOURCE_CONTRACT.json'),
             'bundle_sha256': lock['bundle_sha256'], 'patch_sha256': lock['patch_sha256'],
             'genuine_version': version, 'version_overrides': False,
             'upstream_commit': lock['selinux_upstream_commit'], 'device_test': False}
    report.write_text(json.dumps(proof, indent=2, sort_keys=True) + '\n')
    return proof, version
