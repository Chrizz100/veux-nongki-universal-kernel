#!/usr/bin/env python3
"""Apply the existing R11 update and one explicit R13 update before unchanged R4 compilation."""
from __future__ import annotations
import inspect
import hashlib
import json
import os
from pathlib import Path
import subprocess
from source_update import apply as apply_r11, inventory, require, sha
from r13_source_update import apply as apply_r13, validate_version

BUILD_PIN = '12519a7d94825d3bc2006a46420f8884773a659443e56ba542f48057929dd3a0'
R11_UPDATE_PIN = 'c21ca29535bd6f71466533052e96395fda5fe670b976fa45aa7f7940047d7c96'
VERSION_FUNCTION_PIN = 'f4e9cf71b47a24cdf2987f9d05151d28f620eb61baec5bf2c090bac1372295c5'


def run_update(kernel, state, baseline_work, jobs):
    import cass_r4_build as original
    import source_update as r11_source
    require(sha(Path(original.__file__)) == BUILD_PIN, 'R13_R4_COMPILER_SOURCE_PIN')
    require(sha(Path(r11_source.__file__)) == R11_UPDATE_PIN, 'R13_ORIGINAL_R11_SOURCE_UPDATER_PIN')
    require(hashlib.sha256(inspect.getsource(original.validate_version).encode()).hexdigest()
            == VERSION_FUNCTION_PIN, 'R13_ORIGINAL_VERSION_VALIDATOR_PIN')
    original_compile, original_version = original.compile_candidate, original.validate_version
    calls = []

    def compile_r13(candidate, obj, baseline_config, captured, version, evidence,
                    compile_jobs, original_work=None):
        candidate, evidence = Path(candidate).resolve(strict=True), Path(evidence)
        temporary = Path(os.environ['RUNNER_TEMP']).resolve(strict=True)
        require(candidate == temporary / 'veux-r55h17-r4/source/kernel'
                and candidate != Path(kernel).resolve(), 'R13_REQUIRES_ISOLATED_R4_CANDIDATE')
        require(not Path(obj).exists(), 'R13_FRESH_OBJECT_TREE_REQUIRED')
        # The original validator still authenticates the pre-update R4 history.
        require(original.validate_version is original_version, 'R13_VALIDATOR_CHANGED_BEFORE_SOURCE_UPDATE')
        original_version(candidate / 'KernelSU', version)
        apply_r11(candidate, evidence)
        proof, updated_version = apply_r13(candidate, evidence, version)
        calls.append(proof)
        # R4_RESULT holds this exact object. Its identity becomes the genuine
        # committed candidate, never an environment/compiler version override.
        version.clear()
        version.update(updated_version)
        after_patch = inventory(candidate)
        bakasu = candidate / 'KernelSU'
        commands = [['git', '-C', str(bakasu), 'update-index', '--refresh'],
                    ['git', '-C', str(bakasu), 'diff-index', '--quiet', 'HEAD', '--']]
        for command in commands:
            subprocess.run(command, check=True, capture_output=True, text=True)
        status = subprocess.check_output(['git', '-C', str(bakasu), 'status', '--porcelain',
                                          '--untracked-files=all'], text=True)
        require(not status and after_patch == inventory(candidate), 'R13_GIT_METADATA_REFRESH_CHANGED_SOURCE')
        (evidence / 'R13_GIT_INDEX.json').write_text(json.dumps({
            'status': 'CLEAN_INDEX_AND_WORKTREE', 'commands': commands,
            'only_isolated_git_metadata_refreshed': True, 'source_bytes_unchanged': True,
            'version_overrides': False, 'genuine_version': updated_version}, indent=2) + '\n')
        result = None
        original.validate_version = validate_version
        try:
            compiled = original_compile(candidate, obj, baseline_config, captured, version,
                                        evidence, compile_jobs, original_work)
            from verify_native_branch import verify
            verify(candidate, obj, evidence, captured, original_work)
            result = compiled
            return result
        finally:
            original.validate_version = original_version
            unchanged = after_patch == inventory(candidate)
            report = {'schema': 'veux-r13-compile-hook-v1', 'rmnet_mode': 'built-in',
                      'r11_source_update_sha256': sha(evidence / 'R11_SOURCE_UPDATE.json'),
                      'precompile_source_update_sha256': sha(evidence / 'R13_SOURCE_UPDATE.json'),
                      'r4_compile_and_static_gates_passed': result is not None,
                      'candidate_source_unchanged_during_compile': unchanged,
                      'original_r4_build_script_sha256': BUILD_PIN,
                      'original_version_validator_restored': original.validate_version is original_version,
                      'genuine_version': updated_version, 'device_test': False}
            (evidence / 'R13_COMPILE_HOOK.json').write_text(json.dumps(report, indent=2) + '\n')
            require(unchanged, 'R13_SOURCE_CHANGED_DURING_COMPILE')

    original.compile_candidate = compile_r13
    try:
        result = original.run_update(kernel, state, baseline_work, jobs)
    finally:
        original.compile_candidate = original_compile
        original.validate_version = original_version
    require(len(calls) == 1, 'R13_COMPILE_HOOK_CALL_COUNT')
    return result
