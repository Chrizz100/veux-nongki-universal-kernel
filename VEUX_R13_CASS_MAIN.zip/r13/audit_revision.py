#!/usr/bin/env python3
"""Verify preserved successful inputs and the deliberately narrow R13 revisions."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions(path):
    tree = ast.parse(path.read_text())
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,ast.FunctionDef)}


def audit(payload):
    payload = Path(payload)
    root = payload/'r13'
    manifest = root/'reference/R12_PAYLOAD_MANIFEST.json'
    require(sha(manifest) == '7999787f31ed173d85e7b5b63ff0d0075d59207fcf42a1b298ffe3f2b2efaf54',
            'R13_SUCCESSFUL_R12_MANIFEST_CHANGED')
    original = json.loads(manifest.read_text())['files']
    require(len(original) == 275, 'R13_ORIGINAL_FILE_COUNT_CHANGED')
    for name,digest in original.items():
        path = root/'reference/R12_ANLEITUNG.txt' if name == 'ANLEITUNG.txt' else payload/name
        require(path.is_file() and not path.is_symlink() and sha(path) == digest,
                'R13_HISTORICAL_INPUT_CHANGED:' + name)
    before = (payload/'r11/packaging/builtin_validation.py').read_text()
    after = (root/'packaging/builtin_validation.py').read_text()
    expected = before.replace("BAKASU_MARKER = 'v4.2.0-rc3-2cbbcc23@BakaSU'",
                              "BAKASU_MARKER = 'v4.2.0-rc3-d2537b13@BakaSU'")
    require(after == expected, 'R13_ELF_IMAGE_BUILTIN_VALIDATOR_UNRELATED_CHANGE')
    require((root/'packaging/boot_common.py').read_bytes() == (payload/'r11/packaging/boot_common.py').read_bytes(),
            'R13_COMMON_BOOT_VALIDATOR_CHANGED')
    require((root/'assets/anykernel.sh.in').read_text()
            == (payload/'r12/assets/anykernel.sh.in').read_text().replace('VEUX R12','VEUX R13'),
            'R13_ANYKERNEL_BEHAVIOR_CHANGED')
    require((root/'device_diagnostics.sh.in').read_text()
            == (payload/'r12/device_diagnostics.sh.in').read_text().replace('VEUX_R12_READ_ONLY_DIAGNOSIS_V2','VEUX_R13_READ_ONLY_DIAGNOSIS_V2'),
            'R13_DEVICE_DIAGNOSTICS_BEHAVIOR_CHANGED')
    require((root/'write_device_diagnostics.py').read_bytes() == (payload/'r12/write_device_diagnostics.py').read_bytes(),
            'R13_DIAGNOSTICS_BINDING_CHANGED')
    oldenv,newenv = functions(payload/'r12/record_environment_r3.py'),functions(root/'record_environment_r13.py')
    require(set(oldenv) == set(newenv), 'R13_COMPILER_AUDITOR_FUNCTION_SET_CHANGED')
    for name in set(oldenv)-{'identity','finish'}:
        require(oldenv[name] == newenv[name], 'R13_COMPILER_AUDITOR_UNRELATED_CHANGE:' + name)
    oldtext = (payload/'r12/record_environment_r3.py').read_text()
    newtext = (root/'record_environment_r13.py').read_text()
    for text in (oldtext,newtext):
        tree=ast.parse(text)
        pins=next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='EXPECTED' for x in n.targets))
        if text == oldtext: oldpins=ast.literal_eval(pins)
        else: require(ast.literal_eval(pins)==oldpins, 'R13_COMPILER_PINS_CHANGED')
    oldabi,newabi=functions(payload/'r12/veux_r11_ci_abi_hook.py'),functions(root/'veux_r13_ci_abi_hook.py')
    require(set(oldabi)==set(newabi),'R13_ABI_FUNCTION_SET_CHANGED')
    for name in set(oldabi)-{'run_update'}:
        require(oldabi[name]==newabi[name], 'R13_FULL_ABI_VALIDATION_CHANGED:' + name)
    pack = (payload/'r12/package_anykernel.py').read_text()
    for before,after in {
        "HERE.parent / 'r11/packaging'":"HERE / 'packaging'",
        "KERNEL_NAME = 'VEUX_R12_CASS_KERNEL.zip'":"KERNEL_NAME = 'VEUX_R13_CASS_KERNEL.zip'",
        "authenticated(payload, 'r12/assets/anykernel.sh.in')":"authenticated(payload, 'r13/assets/anykernel.sh.in')",
        "HERE / 'assets/r12_boot_repack.sh'":"HERE.parent / 'r12/assets/r12_boot_repack.sh'",
        "'VEUX R12 CASS – Kernel-ZIP\\n\\n'":"'VEUX R13 CASS – Kernel-ZIP\\n\\n'",
        "'schema': 'veux-r12-anykernel-package-v1'":"'schema': 'veux-r13-anykernel-package-v1'",
        "'R12_PACKAGE_BLOCKED: '":"'R13_PACKAGE_BLOCKED: '",
    }.items():
        require(before in pack, 'R13_PACKAGER_DELTA_ANCHOR_MISSING')
        pack=pack.replace(before,after)
    require((root/'package_anykernel.py').read_text()==pack,'R13_PACKAGER_UNRELATED_CHANGE')
    contract=json.loads((root/'SOURCE_CONTRACT.json').read_text())
    lock=json.loads((root/'data/BAKASU_R13_LOCK.json').read_text())
    review=root/'evidence/port-review/INDEPENDENT_PORT_REVIEW.json'
    reviewed=json.loads(review.read_text())
    require(lock.get('independent_review_complete') is True and sha(review)==lock['independent_review_sha256']
            and reviewed.get('status')=='PASS_FOR_FULL_KERNEL_COMPILE' and reviewed.get('blocking_findings')==[],
            'R13_INDEPENDENT_PORT_REVIEW_MISSING')
    require(reviewed.get('reviewed_source_sha256')==lock['after_sha256']
            and reviewed.get('reviewed_patch_sha256')==contract['patch_sha256'],
            'R13_REVIEW_FOR_DIFFERENT_SOURCE')
    source='KernelSU/kernel/feature/selinux_hide.c'
    require(contract.get('schema')=='veux-r13-source-v1' and contract.get('bakasu_port_commit')=='d2537b13ab15fce72e8c0d99e7788805f071aeb4'
            and contract.get('bakasu_parent')=='2cbbcc2363aa8d4b6286fc2266a338063b2b77a7'
            and contract.get('bakasu_count')==4554 and contract.get('bakasu_version')==35254,
            'R13_GENUINE_SOURCE_CONTRACT_CHANGED')
    oldcontract=json.loads((payload/'r11/SOURCE_CONTRACT.json').read_text())
    require(set(contract['files'])==set(oldcontract['files'])|{source}, 'R13_SOURCE_PATH_SCOPE_CHANGED')
    require(all(contract['files'][p]==v for p,v in oldcontract['files'].items()),'R13_INHERITED_SOURCE_CONTRACT_CHANGED')
    require(sha(root/'reference/selinux_hide.r12.c')==contract['files'][source]['before_sha256']
            and sha(root/'reference/selinux_hide.updated.c')==contract['files'][source]['after_sha256'],
            'R13_SELINUX_TEST_SOURCE_NOT_ACTUAL_PRE_POSTIMAGE')
    require(sha(root/contract['bundle_file'])==contract['bundle_sha256']
            and sha(root/contract['patch_file'])==contract['patch_sha256'], 'R13_SOURCE_INPUT_PIN_CHANGED')
    for pin in ['protected_config_sha256','rmnet_mode','susfs_upstream_commit']:
        require(contract[pin]==oldcontract[pin],'R13_PROTECTED_PIN_CHANGED:'+pin)
    return {'status':'R13_EXPLICIT_REVISION_PASS','successful_r12_members_preserved':len(original),
            'only_new_kernel_path':source,'genuine_bakasu_commit':contract['bakasu_port_commit'],
            'genuine_bakasu_version':35254,'complete_elf_image_builtin_validator_preserved_except_marker':True,
            'anykernel_behavior_preserved':True,'full_abi_and_compiler_pins_preserved':True,
            'device_test':False}
