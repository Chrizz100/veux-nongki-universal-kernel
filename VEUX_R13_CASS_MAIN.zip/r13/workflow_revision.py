#!/usr/bin/env python3
"""Exact, reviewable transformation of the successful R12 CI-R3 workflow."""
from __future__ import annotations
import copy
import hashlib
from pathlib import Path
import yaml

REFERENCE_SHA = 'c7e01c36c94940498517539277389746a23cdd2904297613b2a046a832bc6f35'
PUBLIC_FILES = {
    'VEUX_R12_CASS_BUILD.yml':'VEUX_R13_CASS_BUILD.yml',
    'VEUX_R12_CASS_KERNEL.zip':'VEUX_R13_CASS_KERNEL.zip',
    'VEUX_R12_GERAETEDIAGNOSE_R2.sh':'VEUX_R13_GERAETEDIAGNOSE_R2.sh',
    'VEUX_R12_KERNEL':'VEUX_R13_KERNEL',
    'VEUX_R12_PRUEFBERICHTE':'VEUX_R13_PRUEFBERICHTE',
}


def load_reference(payload):
    path = Path(payload)/'r13/reference/VEUX_R12_CASS_BUILD.yml'
    raw = path.read_text()
    if hashlib.sha256(path.read_bytes()).hexdigest() != REFERENCE_SHA:
        raise ValueError('R13_SUCCESSFUL_R12_WORKFLOW_REFERENCE_CHANGED')
    return yaml.safe_load(raw), raw


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('R13_REVISION_ANCHOR_NOT_UNIQUE:' + before)
    return text.replace(before, after)


def revision(base, archive_sha, manifest_sha):
    doc = copy.deepcopy(base)
    doc['name'] = 'VEUX R13 CASS - Kernel bauen'
    doc['concurrency']['group'] = 'veux-r13-cass-${{ github.ref }}'
    doc['env'].update(REPRO_PACKAGE='VEUX_R13_CASS_MAIN.zip', REPRO_ARCHIVE_SHA256=archive_sha,
                      REPRO_MANIFEST_SHA256=manifest_sha, VEUX_EXECUTION_MODE='ci')
    steps = doc['jobs']['r5s2_bakasu_522']['steps']
    for step in steps:
        # Exact filename tokens contain underscores and cannot touch the
        # historical embedded base64 CRC-reference bytes.
        for key in ('run',):
            if key in step:
                for before, after in PUBLIC_FILES.items():
                    step[key] = step[key].replace(before, after)
        for key in ('name', 'path'):
            if key in step.get('with', {}):
                for before,after in PUBLIC_FILES.items():
                    step['with'][key] = step['with'][key].replace(before,after)
        identifier = step.get('id')
        if identifier == 'r12_auth':
            step['name'] = '01 Authenticate the complete R13 MAIN before executing any payload'
        elif identifier == 'r12_static':
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r12/static_green.py', '$REPRO_PAYLOAD/r13/static_green.py')
            step['run'] += '''python3 -B "$REPRO_PAYLOAD/r13/tests/run_native_tests.py" \\
  --source "$REPRO_PAYLOAD/r13/reference/selinux_hide.updated.c" \\
  --out "$RUNNER_TEMP/r12-reports/r13-native-functions"
python3 -B "$REPRO_PAYLOAD/r13/tests/check_regression.py" \\
  --base "$REPRO_PAYLOAD/r13/reference/selinux_hide.r12.c" \\
  --candidate "$REPRO_PAYLOAD/r13/reference/selinux_hide.updated.c" \\
  --out "$RUNNER_TEMP/r12-reports/r13-native-regression"
python3 -B -m unittest discover -s "$REPRO_PAYLOAD/r13/tests" -p test_r13_guards.py -v \\
  2>&1 | tee "$RUNNER_TEMP/r12-reports/R13_GUARD_REGRESSION.log"
'''
        elif identifier == 'r12_compile':
            step['run'] = once(step['run'], 'PYTHONPATH="$REPRO_PAYLOAD/r11:', 'PYTHONPATH="$REPRO_PAYLOAD/r13:$REPRO_PAYLOAD/r11:')
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r12/veux_r11_bridge.py', '$REPRO_PAYLOAD/r13/veux_r13_bridge.py')
        elif identifier == 'r4_verify':
            step['run'] = once(step['run'], ".get('count')!=4553", ".get('count')!=4554")
            step['run'] = once(step['run'], ".get('version')!=35253", ".get('version')!=35254\n    or updated.get('bakasu_version',{}).get('commit')!='d2537b13ab15fce72e8c0d99e7788805f071aeb4'\n    or updated.get('bakasu_version',{}).get('parent')!='2cbbcc2363aa8d4b6286fc2266a338063b2b77a7'")
        elif identifier == 'r12_environment':
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r12/record_environment_r3.py', '$REPRO_PAYLOAD/r13/record_environment_r13.py')
            step['run'] += 'cp "$REPRO_PAYLOAD/r13/SOURCE_CONTRACT.json" "$RUNNER_TEMP/r12-reports/R13_SOURCE_CONTRACT.json"\n'
        elif identifier == 'r12_builtin':
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r11/packaging/collect_builtin.py', '$REPRO_PAYLOAD/r13/packaging/collect_builtin.py')
        elif identifier == 'r12_package':
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r12/package_anykernel.py', '$REPRO_PAYLOAD/r13/package_anykernel.py')
        elif identifier == 'r12_diagnostics':
            step['run'] = once(step['run'], '$REPRO_PAYLOAD/r12/write_device_diagnostics.py', '$REPRO_PAYLOAD/r13/write_device_diagnostics.py')
        elif identifier == 'r12_complete':
            step['run'] = once(step['run'], "lines = ['## VEUX R12'", "lines = ['## VEUX R13'")
    return doc


class Dumper(yaml.SafeDumper):
    pass


def _string(dumper, value):
    return dumper.represent_scalar('tag:yaml.org,2002:str',value,style='|' if '\n' in value else None)


Dumper.add_representer(str,_string)


def render(doc):
    return ('# VEUX R13: one YAML + one MAIN; no user secrets or inputs.\n'
            '# Based on successful R12 CI-R3, with one pinned native5.4 SELinux commit.\n'
            '# Original full ABI, 132 CRC, compiler, Image/ELF and built-in gates retained.\n'
            '# Historical internal stage IDs/paths stay explicit; new source proof is R13.\n'
            + yaml.dump(doc,Dumper=Dumper,sort_keys=False,allow_unicode=True,width=140))
