"""Restore the verified GitHub R8 source and apply the Xiaomi interface repair."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
from tempfile import TemporaryDirectory
import zipfile

import prepare_r7
import prepare_r8
from tools.treehash import tree

HERE = Path(__file__).resolve().parent


def check_sources(src, manifest, side, tree_key):
    for name, hashes in manifest["files"].items():
        path = src / name
        if hashes[side] is None:
            if path.exists() or path.is_symlink():
                raise ValueError(f"Unexpected {side} path {name}")
        else:
            prepare_r7.verify(path, hashes[side])
    actual = tree(src).hex()
    if actual != manifest[tree_key]:
        raise ValueError(f"{side} source tree {actual}")
    print(f"{side} {actual}", flush=True)


def prepare(archive, destination, stock_boot, from_r6=None):
    manifest = json.loads((HERE / "source.json").read_text())
    prepare_r7.stock(stock_boot)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise ValueError(f"Destination already exists: {destination}")
    patch = HERE / "veux-r9.patch"
    prepare_r7.verify(patch, manifest["patch_sha256"])
    with TemporaryDirectory(dir=destination.parent) as directory:
        src = Path(directory) / "src"
        if from_r6:
            prepare_r8.prepare(archive, src, stock_boot, from_r6)
        else:
            prepare_r7.verify(archive, manifest["archive_sha256"])
            with zipfile.ZipFile(archive) as package:
                if package.read("kernel.config") != (HERE / "kernel.config").read_bytes():
                    raise ValueError("R8 embedded configuration")
                name = "M63-R8-kernel-source.tar.gz"
                with package.open(name) as stream:
                    if hashlib.file_digest(stream, "sha256").hexdigest() != manifest["tar_sha256"]:
                        raise ValueError("R8 source tar digest")
                src.mkdir()
                with package.open(name) as stream, tarfile.open(fileobj=stream, mode="r|gz") as tar:
                    tar.extractall(src, filter="tar")
        check_sources(src, manifest, "before", "basis_tree")
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=src, check=True)
        subprocess.run(["git", "apply", "--whitespace=nowarn", str(patch)], cwd=src, check=True)
        check_sources(src, manifest, "after", "corrected_tree")
        src.rename(destination)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("stock_boot", type=Path)
    parser.add_argument("--from-r6", choices=["archive", "comparison"])
    args = parser.parse_args()
    prepare(args.archive.resolve(), args.destination.resolve(), args.stock_boot.resolve(), args.from_r6)
