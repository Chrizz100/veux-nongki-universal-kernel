# VEUX M63-R9 für das POCO X4 Pro 5G

R9 stellt vier im Xiaomi-Stockkernel vorhandene Startaufrufe wieder her. Die drei Qualcomm-Plattformtreiber lesen die vom Gerät bereitgestellten Register. Die Wakeup-Diagnose erfasst Aufwach-Interrupts, Suspend-Abbrüche und die Dauer des letzten Schlafzyklus. Referenz ist das Bootabbild der Global-ROM OS1.0.12.0.TKCMIXM. Der Ausgangsstand ist der Quellbaum von GitHub-R8 aus Lauf 45384439039. Der zusätzliche Quellabgleich verwendet Xiaomis VEUX-Veröffentlichung auf Commit `61397e524093d1ccb94769b5460825e2eaf8871e`.

Die Leser verwenden die Originalnamen und Zahlenformate. Die Einträge werden nach erfolgreicher Registerzuordnung veröffentlicht und beim Entfernen vor dem Freigeben der zugehörigen Ressourcen abgemeldet. Die Wakeup-Erfassung verwendet die vorhandene IRQ-Verwaltung der 5.4.274-Basis, den Stock-Startwert für die IRQ-Protokollierung und die SRCU-Synchronisierung der vorhandenen Liste von Aufwachquellen.

## GitHub Actions

Das Baupaket heißt `VEUX_M63_R9_MAIN.zip` und liegt im Repository-Hauptverzeichnis. Der zugehörige Workflow heißt `.github/workflows/VEUX_M63_R9_OEM_SCHNITTSTELLEN_NOFLASH.yml`. Er lässt sich manuell starten und läuft bei einem Push der Dateien auf den Reparaturbranch `repair/m63-r9-oem-interfaces`.

Der Workflow prüft R8-Quellen, Stockabbild und R9-Patch, baut den Kernel und vergleicht das gelinkte Image mit Stock. Zu den Prüfungen gehören die vier Initialisierer und ihre unmittelbaren Nachbarn, die vorhandene R8-Reihenfolge, die Touch-Treiberfälle, die OEM-Diagnose im Erfolgs- und Fehlerfall und die Importe der 37 originalen QGKI-Module. Der Lauf gibt Prüfprotokolle mit Debug-Symbolen, das Boot-/AK3-Prüfpaar und den vollständigen neuen Quellstand aus.

## Lokaler Bau

Python ab 3.12, Git, die Kbuild-Werkzeuge, Android-Clang r416183b, LLDB 19 und qemu-arm für das ARM-Paketierwerkzeug werden benötigt.

```sh
python3 -B prepare.py R8-source.zip work/src /pfad/zum/stock/boot.img
LLDB=lldb-19 bash build.sh work /pfad/zu/clang-r416183b /pfad/zum/stock/boot.img
```

Bei fehlendem Stockabbild liest die Vorbereitung die erforderlichen Daten aus Xiaomis öffentlicher Firmware. Alternativ zum R8-Aktionsartefakt kann `prepare.py` weiterhin die gesicherte R6-Basis verwenden, mit `--from-r6 comparison` für das historische Quellenvergleichspaket oder `--from-r6 archive` für das R6-Quellartefakt. Beide Wege prüfen dieselben resultierenden Git-Bäume.

## Gerätestatus

Das Boot-/AK3-Paar trägt den Status NOFLASH. Der Pakettest arbeitet auf regulären Abbilddateien. Für die frühere Störung von R6 an der Android-Displaysperre liegt kein Geräte-Stacktrace vor.
