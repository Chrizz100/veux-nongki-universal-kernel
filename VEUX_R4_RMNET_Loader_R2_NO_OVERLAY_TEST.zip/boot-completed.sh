#!/system/bin/sh
# VEUX R4 RMNET Loader R2 - executes only after Android boot completion.
PATH=/system/bin:/system/xbin:/vendor/bin
export PATH
LC_ALL=C
export LC_ALL

MODDIR=${0%/*}
LOG="$MODDIR/loader.log"
EXPECTED_KERNEL='5.4.274-qgki-g82179e362f33'
EXPECTED_NOTES='cf28a097181133ea1fd1c372617258be5fd3e4a74b9bca26e2f229b69679fedc'
EXPECTED_OFFLOAD='74d3a077bb20905ba41d2d6a621893f2b014e7f9cef9c0081e5f8fdfd1693091'
EXPECTED_SHS='eaebe113373313672238a93f3a4b24285c1ff3063542520ffa55866e0d237b86'

: > "$LOG" 2>/dev/null || exit 0
exec >> "$LOG" 2>&1

echo "VEUX_RMNET_NO_OVERLAY_LOADER=START"
date -u '+ZEIT_UTC=%Y%m%d_%H%M%S' 2>/dev/null

hash_file() {
    line=$(sha256sum "$1" 2>/dev/null) || return 1
    value=${line%% *}
    case "$value" in ''|*[!0-9a-f]*) return 1;; esac
    [ "${#value}" = 64 ] || return 1
    printf '%s\n' "$value"
}

state() {
    name=$1
    if [ -r "/sys/module/$name/initstate" ]; then
        printf 'MODUL=%s; INITSTATE=' "$name"
        cat "/sys/module/$name/initstate"
    else
        echo "MODUL=$name; INITSTATE=NICHT_GELADEN"
    fi
}

release=$(uname -r 2>/dev/null)
echo "KERNEL=$release"
[ "$release" = "$EXPECTED_KERNEL" ] || {
    echo "ABBRUCH=FALSCHER_KERNEL"
    exit 0
}

notes=$(hash_file /sys/kernel/notes 2>/dev/null)
echo "KERNEL_NOTES_SHA256=$notes"
[ "$notes" = "$EXPECTED_NOTES" ] || {
    echo "ABBRUCH=R4_IDENTITAET_ABWEICHEND"
    exit 0
}

offload="$MODDIR/payload/rmnet_offload.ko"
shs="$MODDIR/payload/rmnet_shs.ko"
[ "$(hash_file "$offload")" = "$EXPECTED_OFFLOAD" ] || {
    echo "ABBRUCH=OFFLOAD_PAYLOAD_HASH"
    exit 0
}
[ "$(hash_file "$shs")" = "$EXPECTED_SHS" ] || {
    echo "ABBRUCH=SHS_PAYLOAD_HASH"
    exit 0
}

# This is post-boot. Wait only for the rmnet interface; never block Android boot.
i=0
while [ ! -e /sys/class/net/rmnet_data0 ] && [ "$i" -lt 30 ]; do
    sleep 2
    i=$((i + 1))
done
echo "RMNET_DATA0_WAIT_LOOPS=$i"
if [ ! -e /sys/class/net/rmnet_data0 ]; then
    echo "ABBRUCH=RMNET_DATA0_NICHT_VORHANDEN"
    exit 0
fi

offload_prop=$(getprop persist.vendor.data.offload_ko_load 2>/dev/null)
shs_prop=$(getprop persist.vendor.data.shs_ko_load 2>/dev/null)
echo "PROPERTY_OFFLOAD=$offload_prop"
echo "PROPERTY_SHS=$shs_prop"

insmod_one() {
    name=$1
    file=$2

    if [ -r "/sys/module/$name/initstate" ]; then
        echo "LOAD=$name; STATUS=BEREITS_GELADEN"
        return 0
    fi

    echo "LOAD=$name; START"
    if [ -x /system/bin/insmod ]; then
        /system/bin/insmod "$file"
        rc=$?
    elif [ -x /system/bin/toybox ]; then
        /system/bin/toybox insmod "$file"
        rc=$?
    else
        echo "LOAD=$name; STATUS=KEIN_INSMOD"
        return 1
    fi
    echo "LOAD=$name; EXIT=$rc"

    [ "$rc" -eq 0 ] || return "$rc"
    sleep 1
    [ -r "/sys/module/$name/initstate" ] || return 1
    [ "$(cat "/sys/module/$name/initstate" 2>/dev/null)" = "live" ] || return 1
    return 0
}

offload_result=SKIP_PROPERTY
shs_result=SKIP_PROPERTY

if [ "$offload_prop" = "1" ]; then
    if insmod_one rmnet_offload "$offload"; then
        offload_result=PASS
    else
        offload_result=FAIL
    fi
fi

if [ "$shs_prop" = "1" ]; then
    if insmod_one rmnet_shs "$shs"; then
        shs_result=PASS
    else
        shs_result=FAIL
    fi
fi

state rmnet_offload
state rmnet_shs

echo "OFFLOAD_RESULT=$offload_result"
echo "SHS_RESULT=$shs_result"
echo "DYNAMIC_PROPERTY_UNLOAD=NICHT_IMPLEMENTIERT_IN_R2"
echo "VEUX_RMNET_NO_OVERLAY_LOADER=ENDE"
exit 0
