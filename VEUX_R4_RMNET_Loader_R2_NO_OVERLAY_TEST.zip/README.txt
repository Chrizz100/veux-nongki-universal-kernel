VEUX R4 RMNET Loader R2 - NO OVERLAY TEST

Purpose:
- Keep the exact already device-tested R4 rmnet_offload and rmnet_shs modules.
- Do NOT replace /vendor files.
- Do NOT use NoMount/metamodule mounting.
- Do NOT patch modules.dep.
- Do NOT use modprobe.
- Load only after Android has completed booting.

Safety boundary:
- This candidate repairs only the normal boot-time state when the existing ROM
  properties persist.vendor.data.offload_ko_load / shs_ko_load are 1.
- It does not yet implement dynamic unload/reload after a property changes.
- No SIM/mobile-data path is claimed tested.
- Do not install until the separate GitHub audit workflow is GREEN.
