# VEUX R4 RMNET Loader R2 - NO OVERLAY TEST
# Sourced by KernelSU/ReSukiSU module installer.

ui_print " "
ui_print "VEUX R4 RMNET Loader R2 - NO OVERLAY TEST"
ui_print "Kein system/vendor Overlay. skip_mount ist Pflicht."

EXPECTED_KERNEL='5.4.274-qgki-g82179e362f33'
EXPECTED_NOTES='cf28a097181133ea1fd1c372617258be5fd3e4a74b9bca26e2f229b69679fedc'
EXPECTED_CONFIG='5904f8d2439e2cb05ef3db7edbe653d269e070b0e28d7e131a44600d61bab229'
EXPECTED_OFFLOAD='74d3a077bb20905ba41d2d6a621893f2b014e7f9cef9c0081e5f8fdfd1693091'
EXPECTED_SHS='eaebe113373313672238a93f3a4b24285c1ff3063542520ffa55866e0d237b86'

hash_file() {
    line=$(sha256sum "$1" 2>/dev/null) || return 1
    value=${line%% *}
    case "$value" in ''|*[!0-9a-f]*) return 1;; esac
    [ "${#value}" = 64 ] || return 1
    printf '%s\n' "$value"
}

require_hash() {
    file=$1
    expected=$2
    label=$3
    [ -f "$file" ] || abort "$label fehlt: $file"
    actual=$(hash_file "$file") || abort "$label Hash nicht lesbar"
    [ "$actual" = "$expected" ] || abort "$label unerwartet: $actual"
    ui_print "  PASS $label"
}

[ "$KSU" = "true" ] || abort "Nur fuer KernelSU/ReSukiSU."
[ "$BOOTMODE" = "true" ] || abort "Installation nur im laufenden Android."

device=$(getprop ro.product.device)
[ "$device" = "veux" ] || abort "Falsches Geraet: $device"

release=$(uname -r)
[ "$release" = "$EXPECTED_KERNEL" ] || abort "Falscher Kernel: $release"

notes=$(hash_file /sys/kernel/notes) || abort "Kernel-Notes nicht lesbar"
[ "$notes" = "$EXPECTED_NOTES" ] || abort "R4-Kernelidentitaet stimmt nicht"

gzip -dc /proc/config.gz > "$TMPDIR/veux-r4-loader.config" 2>/dev/null ||
    abort "Kernelkonfiguration nicht lesbar"
config=$(hash_file "$TMPDIR/veux-r4-loader.config") || abort "Config-Hash nicht lesbar"
[ "$config" = "$EXPECTED_CONFIG" ] || abort "R4-Konfiguration stimmt nicht"

require_hash "$MODPATH/payload/rmnet_offload.ko" "$EXPECTED_OFFLOAD" "rmnet_offload"
require_hash "$MODPATH/payload/rmnet_shs.ko" "$EXPECTED_SHS" "rmnet_shs"

[ -f "$MODPATH/skip_mount" ] || abort "skip_mount fehlt"

for forbidden in system vendor product system_ext odm; do
    [ ! -e "$MODPATH/$forbidden" ] || abort "Verbotener Mount-Baum vorhanden: $forbidden"
done

[ ! -e "$MODPATH/post-mount.sh" ] || abort "post-mount.sh ist in diesem Kandidaten verboten"
[ ! -e "$MODPATH/service.sh" ] || abort "service.sh ist in diesem Kandidaten verboten"

set_perm "$MODPATH/boot-completed.sh" 0 0 0755
set_perm "$MODPATH/payload/rmnet_offload.ko" 0 0 0644
set_perm "$MODPATH/payload/rmnet_shs.ko" 0 0 0644
set_perm "$MODPATH/skip_mount" 0 0 0644

{
    echo "INSTALL=PASS"
    echo "MODE=NO_OVERLAY_BOOT_COMPLETED_ONLY"
    echo "KERNEL=$release"
    echo "KERNEL_NOTES_SHA256=$notes"
    echo "CONFIG_SHA256=$config"
    echo "OFFLOAD_SHA256=$EXPECTED_OFFLOAD"
    echo "SHS_SHA256=$EXPECTED_SHS"
    echo "SKIP_MOUNT=JA"
    echo "SYSTEM_VENDOR_OVERLAY=NEIN"
    echo "PHYSICAL_VENDOR_WRITE=NEIN"
    echo "MODPROBE=NEIN"
} > "$MODPATH/INSTALL_EVIDENCE.txt"

ui_print " "
ui_print "Vorbereitung PASS."
ui_print "Kein NoMount-Overlay und kein /vendor-Schreibzugriff."
ui_print "Noch NICHT verwenden, bevor der separate CI-Audit GREEN ist."
