#!/usr/bin/env python3
"""Read-only VEUX R34 device-tree / driver binding evidence.

Reads ONLY /proc/device-tree (compatible and status) and sysfs driver/of_node
symlink metadata, /proc/modules and /proc/sys/kernel/osrelease.
Never writes a device node, kernel property, mount, module, or partition.
No raw device tree, serials, MAC addresses, partition bytes or install payload.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import zipfile

SCHEMA = 'VEUX_R34_DEVICE_DRIVER_BINDINGS_V1'
OUTPUT = 'VEUX_R34_DEVICE_EVIDENCE.zip'
ROOT_CANDIDATES = ('/proc/device-tree', '/sys/firmware/devicetree/base')
BUS_NAMES = ('platform', 'i2c', 'spi')
MAX_NODES = 6000
MAX_DRIVERS = 6500
MAX_COMPATS = 18
MAX_PROP_BYTES = 2048
# Only human-inspectable hardware nodes; never collect property values other than
# generic compatible and status. Skip dynamic alias / memory data trees entirely.
SKIP_ROOTS = ('/__symbols__', '/__fixups__', '/__local_fixups__', '/chosen',
              '/aliases', '/memory', '/reserved-memory')
VALID_STRING = re.compile(r'^[ -~]{1,180}$')


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def property_bytes(p):
    try:
        with p.open('rb') as f:
            v = f.read(MAX_PROP_BYTES + 1)
        return v if len(v) <= MAX_PROP_BYTES else None
    except (OSError, ValueError):
        return None


def visible_strings(blob):
    if blob is None:
        return []
    result = []
    for part in blob.split(b'\0'):
        if not part:
            continue
        try:
            s = part.decode('ascii')
        except UnicodeDecodeError:
            continue
        if VALID_STRING.fullmatch(s) and s not in result:
            result.append(s)
        if len(result) >= MAX_COMPATS:
            break
    return result


def valid_node_path(s):
    if not isinstance(s,str) or not s.startswith('/') or len(s)>256:
        return False
    if '\x00' in s or '\n' in s or '\r' in s or '/..' in s or '//' in s:
        return False
    return all(32 <= ord(x) <= 126 for x in s)


def scan_tree(root):
    root=Path(root)
    nodes=[]
    errors=0
    visited=0
    if not root.is_dir():
        return nodes,{'status':'TREE_UNAVAILABLE','visited':0,'property_errors':0}
    for base,dirs,_files in os.walk(root,followlinks=False):
        dirs[:]=[d for d in dirs if not d.startswith('.') and d not in ('__symbols__','__fixups__','__local_fixups__')]
        visited+=1
        if visited>MAX_NODES:
            return nodes,{'status':'NODE_LIMIT_EXCEEDED','visited':visited,'property_errors':errors}
        dirpath=Path(base)
        rel='/' + dirpath.relative_to(root).as_posix().lstrip('.')
        if rel!='/' and rel.endswith('/'):
            rel=rel[:-1]
        if rel=='/.' or rel=='//': rel='/'
        if any(rel==skip or rel.startswith(skip+'/') for skip in SKIP_ROOTS):
            dirs[:]=[]
            continue
        if not valid_node_path(rel):
            errors+=1
            continue
        cp=dirpath/'compatible'
        sp=dirpath/'status'
        compat=visible_strings(property_bytes(cp)) if cp.exists() else []
        if not compat:
            continue
        raw_status=visible_strings(property_bytes(sp)) if sp.exists() else []
        status=raw_status[0] if raw_status else 'okay (default)'
        nodes.append({'path':rel,'compatible':compat,'status':status,'stock_bound_drivers':[]})
    return nodes,{'status':'ENUMERATED','visited':visited,'property_errors':errors}


def stock_binding_map(real_root, bus_roots=None):
    if bus_roots is None:
        bus_roots={name:Path('/sys/bus')/name/'devices' for name in BUS_NAMES}
    root=os.path.realpath(str(real_root)).rstrip('/')+'/'
    mapping={}
    checked=0
    warnings=[]
    for bus,base in bus_roots.items():
        try:
            devices=list(base.iterdir())
        except OSError:
            warnings.append('BUS_UNAVAILABLE:'+bus)
            continue
        for entry in devices:
            checked+=1
            if checked>MAX_DRIVERS:
                warnings.append('BUS_ENTRY_LIMIT')
                return mapping,{'entries_examined':checked,'warnings':warnings}
            ofnode=entry/'of_node'
            driver=entry/'driver'
            if not ofnode.exists() or not driver.exists() or not driver.is_symlink():
                continue
            target=os.path.realpath(str(ofnode))
            if not target.startswith(root):
                continue
            rel='/'+target[len(root):].strip('/')
            if not valid_node_path(rel) or any(rel==p or rel.startswith(p+'/') for p in SKIP_ROOTS):
                continue
            name=os.path.basename(os.path.realpath(str(driver)))
            if not VALID_STRING.fullmatch(name):
                continue
            marker=bus+':'+name
            mapping.setdefault(rel,set()).add(marker)
    return mapping,{'entries_examined':checked,'warnings':warnings}


def capture(tree_roots=ROOT_CANDIDATES,bus_roots=None,output=None):
    nodes=[];meta={'status':'TREE_UNAVAILABLE','visited':0,'property_errors':0}
    selected=None
    for root in tree_roots:
        nodes,meta=scan_tree(root)
        if meta['status']=='ENUMERATED' and nodes:
            selected=root
            break
    warnings=[]
    if meta['status']!='ENUMERATED' or not nodes:
        warnings.append('CURRENT_DEVICE_TREE_NODES_UNAVAILABLE')
    binding_map,binding_meta=stock_binding_map(selected or tree_roots[0],bus_roots)
    for n in nodes:
        n['stock_bound_drivers']=sorted(binding_map.get(n['path'],()))
    status='CURRENT_NODES_ENUMERATED' if nodes and meta['status']=='ENUMERATED' else 'INCOMPLETE_DEVICE_CAPTURE'
    try:
        k=Path('/proc/sys/kernel/osrelease').read_text().strip()[:130]
    except OSError:
        k='UNAVAILABLE'
        warnings.append('KERNEL_RELEASE_UNAVAILABLE')
    try:
        m=Path('/proc/modules').read_text().splitlines()
        loaded=sorted({line.split()[0] for line in m if line.strip()})
    except OSError:
        loaded=[]
        warnings.append('PROC_MODULES_UNAVAILABLE')
    doc={'schema':SCHEMA,'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'read_only':True,'status':status,'kernel_release':k,
         'tree_source':str(selected) if selected else 'UNAVAILABLE','tree_scan':meta,
         'driver_scan':binding_meta,'device_nodes':nodes,
         'loaded_module_names':loaded[:500],
         'limitations':['Bound drivers reflect STOCK currently running, NOT R20.',
             'Compatible string overlap with R20 DTB does not prove driver built-in or probe success.',
             'This capture does not prove selected DTBO overlay or Vendor ABI compatibility.',
             'No raw DTB, private device identifiers, partition bytes, module binaries or secrets saved.'],
         'warnings':warnings+binding_meta['warnings']}
    path=Path(output) if output is not None else Path('/sdcard/Download')/OUTPUT
    if output is None and not path.parent.is_dir():
        path=Path.cwd()/OUTPUT
        doc['warnings'].append('DOWNLOAD_DIRECTORY_NOT_AVAILABLE_RESULT_IN_CWD')
    b=(json.dumps(doc,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
        z.writestr('R34_DEVICE_EVIDENCE.json',b)
        z.writestr('SHA256SUMS.txt',sha(b)+'  R34_DEVICE_EVIDENCE.json\n')
        z.writestr('README_DE.txt',
            'VEUX R34: Nur Lesezugriff, keine Installation, kein Flash.\n'
            'Enthaelt generische Device-Tree-Compatibles, Status und aktuelle Treiber-Symlinks.\n'
            'Treiberbeobachtungen gelten nur fuer den aktuell laufenden Stock-Kernel.\n')
    print('R34_CAPTURE='+status+'; NODE_COUNT='+str(len(nodes))+
          '; STOCK_BOUND_NODES='+str(sum(bool(x['stock_bound_drivers']) for x in nodes)))
    print('R34_EVIDENCE_SAVED='+str(path))
    print('NO_BUILD=YES; NO_FLASH=YES; NO_DEVICE_MODIFICATION=YES')
    return doc


if __name__=='__main__':
    try:
        capture()
    except (OSError,ValueError) as e:
        print('R34_CAPTURE_FAILED: '+str(e),file=sys.stderr)
        sys.exit(1)
