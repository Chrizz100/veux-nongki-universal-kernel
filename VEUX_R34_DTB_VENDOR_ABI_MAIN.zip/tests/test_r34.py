#!/usr/bin/env python3
import csv
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile

ROOT=Path(__file__).resolve().parents[1]

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

audit=load('r34_gate',ROOT/'scripts/r34_gate.py')
capture=load('r34_capture',ROOT/'scripts/VEUX_R34_CAPTURE_GERAET.py')


def device_blob(node=None, status='CURRENT_NODES_ENUMERATED', read_only=True, schema=None):
    if node is None:node={'path':'/soc/serial@123','compatible':['qcom,blair','qcom,soc'],
                          'status':'okay','stock_bound_drivers':['platform:qcom_serial']}
    data={'schema':schema or audit.DEVICE_SCHEMA,'status':status,'read_only':read_only,
          'device_nodes':[node],'loaded_module_names':['rmnet_offload','rmnet_shs'],
          'tree_scan':{'status':'ENUMERATED','visited':1}}
    b=(json.dumps(data,sort_keys=True)+'\n').encode()
    with io.BytesIO() as stream:
        with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
            z.writestr('R34_DEVICE_EVIDENCE.json',b)
            z.writestr('SHA256SUMS.txt',audit.digest(b)+'  R34_DEVICE_EVIDENCE.json\n')
            z.writestr('README_DE.txt','R34 nur lesen\n')
        return stream.getvalue()


class TestManifest(unittest.TestCase):
    def test_01_verified_input_manifest(self):
        self.assertGreaterEqual(len(audit.verify_manifest(ROOT)['files']),10)
    def test_02_trusted_r31_r32_r33(self):
        _,r32,r33,d=audit.verify_r33(ROOT)
        self.assertEqual(r32['r20_matching_imports'],307)
        self.assertTrue(r33['r33_device_capture_present'])
        self.assertEqual(d['reported_active_slot'],'_a')
    def test_03_r20_dtb_sha_pinned(self):
        b=(ROOT/'evidence/R20_VEUX.dtb').read_bytes()
        self.assertEqual(audit.digest(b),audit.EXPECTED_R20_DTB_SHA)
    def test_04_vendor_imports_hash_pinned(self):
        b=(ROOT/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes()
        self.assertEqual(audit.digest(b),audit.EXPECTED_R21_IMPORTS_SHA)
    def test_05_symvers_hash_pinned(self):
        b=(ROOT/'evidence/R20_Module.symvers').read_bytes()
        self.assertEqual(audit.digest(b),audit.EXPECTED_R20_SYMVERS_SHA)
    def test_06_manifest_rejects_mutated_evidence(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'MANIFEST_SHA256.json').write_bytes((ROOT/'MANIFEST_SHA256.json').read_bytes())
            with self.assertRaises(ValueError):audit.verify_manifest(p)
    def test_07_reference_only_nonflash(self):
        _,r32,r33,_=audit.verify_r33(ROOT)
        self.assertIs(r32['flash_allowed'],False)
        self.assertIs(r33['boot_ready'],False)


class TestFdt(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.b=(ROOT/'evidence/R20_VEUX.dtb').read_bytes()
    def test_08_parse_real_r20(self):
        n=audit.fdt_nodes(self.b)
        self.assertEqual(len(n),1829)
        self.assertIn('qcom,blair',n[0]['compatible'])
    def test_09_reject_bad_magic(self):
        b=bytearray(self.b);b[0]=0
        with self.assertRaises(ValueError):audit.fdt_nodes(b)
    def test_10_reject_too_short(self):
        with self.assertRaises(ValueError):audit.fdt_nodes(b'\0'*15)
    def test_11_reject_bogus_total(self):
        b=bytearray(self.b);b[4:8]=b'\xff'*4
        with self.assertRaises(ValueError):audit.fdt_nodes(b)
    def test_12_reject_bogus_struct_off(self):
        b=bytearray(self.b);b[8:12]=b'\xff'*4
        with self.assertRaises(ValueError):audit.fdt_nodes(b)
    def test_13_reject_truncated_fdt(self):
        with self.assertRaises(ValueError):audit.fdt_nodes(self.b[:100])
    def test_14_no_raw_property_contents(self):
        n=audit.fdt_nodes(self.b)
        self.assertTrue(all(set(x)=={'path','compatible','status'} for x in n))
    def test_15_root_compatible_is_strict(self):
        n=audit.fdt_nodes(self.b)
        self.assertIn('qcom,blair',n[0]['compatible'])


class TestVendor(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sym=audit.parse_symvers((ROOT/'evidence/R20_Module.symvers').read_bytes())
        cls.rows,cls.totals=audit.vendor_rows((ROOT/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes(),cls.sym)
    def test_16_symvers_exports_many(self):self.assertGreaterEqual(len(self.sym),14000)
    def test_17_exact_historical_vendor_imports(self):self.assertEqual(sum(self.totals.values()),14648)
    def test_18_exact_crc_matches(self):self.assertEqual(self.totals['MATCH'],6960)
    def test_19_exact_crc_mismatches(self):self.assertEqual(self.totals['CRC_MISMATCH'],7653)
    def test_20_exact_missing_exports(self):self.assertEqual(self.totals['ABSENT_IN_R20_SYMVERS'],35)
    def test_21_exact_candidate_files(self):self.assertEqual(len(self.rows),218)
    def test_22_reject_bad_symvers(self):
        with self.assertRaises(ValueError):audit.parse_symvers(b'invalid\n')
    def test_23_reject_tampered_vendor_import(self):
        text=(ROOT/'evidence/R21_VENDOR_IMPORTS.csv').read_text()
        changed=text.replace('0x011344eb','0x11111111',1)
        with self.assertRaises(ValueError):audit.vendor_rows(changed.encode(),self.sym)
    def test_24_not_all_listed_are_loaded(self):
        _,r32,_,d=audit.verify_r33(ROOT)
        m=audit.list_vendor_inventory(d,self.rows,r32)
        self.assertGreater(len(m),150)
        self.assertEqual(set(d['loaded_module_names']),{'rmnet_shs','rmnet_offload'})
    def test_25_names_preserve_ko(self):
        _,r32,_,d=audit.verify_r33(ROOT)
        m=audit.list_vendor_inventory(d,self.rows,r32)
        self.assertTrue(all(x['module'].endswith('.ko') for x in m))
    def test_26_priority_counts_present(self):
        _,r32,_,d=audit.verify_r33(ROOT)
        m=audit.list_vendor_inventory(d,self.rows,r32)
        self.assertTrue(any(x['historical_crc_mismatches']>20 for x in m))
    def test_27_listed_is_not_proof(self):
        _,r32,_,d=audit.verify_r33(ROOT)
        m=audit.list_vendor_inventory(d,self.rows,r32)
        self.assertTrue(all(x['evidence_role'].startswith('LISTED_NOT_PROOF') for x in m))


class TestDeviceInput(unittest.TestCase):
    def test_28_valid_mock_device_zip(self):
        j=audit.parse_new_device_zip(device_blob())
        self.assertEqual(j['status'],'CURRENT_NODES_ENUMERATED')
    def test_29_reject_forged_readonly_false(self):
        with self.assertRaises(ValueError):audit.parse_new_device_zip(device_blob(read_only=False))
    def test_30_reject_other_schema(self):
        with self.assertRaises(ValueError):audit.parse_new_device_zip(device_blob(schema='WRONG'))
    def test_31_reject_nonabsolute_node_path(self):
        n={'path':'../../evil','compatible':['qcom,soc'],'status':'okay','stock_bound_drivers':[]}
        with self.assertRaises(ValueError):audit.parse_new_device_zip(device_blob(node=n))
    def test_32_reject_extra_sensitive_field(self):
        n={'path':'/soc','compatible':['qcom,soc'],'status':'okay','stock_bound_drivers':[],'serial_number':'secret'}
        with self.assertRaises(ValueError):audit.parse_new_device_zip(device_blob(node=n))
    def test_33_reject_false_empty_coverage(self):
        b=device_blob();d=json.loads(zipfile.ZipFile(io.BytesIO(b)).read('R34_DEVICE_EVIDENCE.json'))
        d['device_nodes']=[]
        b=(json.dumps(d)+'\n').encode()
        with io.BytesIO() as stream:
            with zipfile.ZipFile(stream,'w') as z:
                z.writestr('R34_DEVICE_EVIDENCE.json',b)
                z.writestr('SHA256SUMS.txt',audit.digest(b)+'  R34_DEVICE_EVIDENCE.json\n')
                z.writestr('README_DE.txt','ok')
            with self.assertRaises(ValueError):audit.parse_new_device_zip(stream.getvalue())
    def test_34_reject_corrupt_archive_hash(self):
        b=bytearray(device_blob())
        # Replace the valid sum with a bad one by repackaging.
        files=audit.read_zip_strict(bytes(b))
        files['SHA256SUMS.txt']=b'0'*64+b'  R34_DEVICE_EVIDENCE.json\n'
        with io.BytesIO() as stream:
            with zipfile.ZipFile(stream,'w') as z:
                for k,v in files.items():z.writestr(k,v)
            with self.assertRaises(ValueError):audit.parse_new_device_zip(stream.getvalue())
    def test_35_reject_duplicate_zip_entries(self):
        with io.BytesIO() as stream:
            with zipfile.ZipFile(stream,'w') as z:
                z.writestr('R34_DEVICE_EVIDENCE.json','{}')
                import warnings
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore');z.writestr('R34_DEVICE_EVIDENCE.json','{}')
            with self.assertRaises(ValueError):audit.read_zip_strict(stream.getvalue())
    def test_36_reject_unsafe_zip_member(self):
        with io.BytesIO() as stream:
            with zipfile.ZipFile(stream,'w') as z:z.writestr('../escape','bad')
            with self.assertRaises(ValueError):audit.read_zip_strict(stream.getvalue())
    def test_37_reject_symlink_in_archive(self):
        info=zipfile.ZipInfo('unsafe');info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16
        with io.BytesIO() as stream:
            with zipfile.ZipFile(stream,'w') as z:z.writestr(info,'target')
            with self.assertRaises(ValueError):audit.read_zip_strict(stream.getvalue())
    def test_38_limit_zip_size(self):
        with self.assertRaises(ValueError):audit.read_zip_strict(b'abcdef',maximum=3)
    def test_39_reject_wrong_members(self):
        with self.assertRaises(ValueError):audit.read_zip_strict(device_blob(),expected={'ONLY'})
    def test_40_compatible_overlap_does_not_claim_driver(self):
        n=audit.fdt_nodes((ROOT/'evidence/R20_VEUX.dtb').read_bytes())
        d=audit.parse_new_device_zip(device_blob())
        mat=audit.tree_matrix(n,d)
        self.assertTrue(mat[0]['any_r20_dtb_compatible_overlap'])
        self.assertEqual(mat[0]['r20_driver_compiled_or_probed'],'UNKNOWN_NOT_TESTED')


class TestDeviceCapture(unittest.TestCase):
    def test_41_compatible_property_filter(self):
        self.assertEqual(capture.visible_strings(b'qcom,blair\x00qcom,board\x00'),['qcom,blair','qcom,board'])
    def test_42_binary_skipped(self):
        self.assertEqual(capture.visible_strings(b'\xff\xfe\x00'),[])
    def test_43_path_accept(self):
        self.assertTrue(capture.valid_node_path('/soc/serial@123'))
    def test_44_path_traversal_blocked(self):
        self.assertFalse(capture.valid_node_path('/soc/../secret'))
    def test_45_tree_node_snapshot_only_two_properties(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'soc').mkdir();
            (p/'soc/compatible').write_bytes(b'qcom,blair\0')
            (p/'soc/serial-number').write_bytes(b'SECRET_1234567890\0')
            n,meta=capture.scan_tree(p)
            self.assertEqual(meta['status'],'ENUMERATED')
            self.assertEqual(len(n),1)
            self.assertEqual(n[0]['path'],'/soc')
            self.assertNotIn('SECRET',json.dumps(n))
    def test_46_respect_disabled_status(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'compatible').write_bytes(b'qcom,blair\0');(p/'status').write_bytes(b'disabled\0')
            n,_=capture.scan_tree(p)
            self.assertEqual(n[0]['status'],'disabled')
    def test_47_missing_tree_not_fabricated(self):
        with tempfile.TemporaryDirectory() as td:
            n,meta=capture.scan_tree(Path(td)/'not-found')
            self.assertEqual(meta['status'],'TREE_UNAVAILABLE')
            self.assertEqual(n,[])
    def test_48_capture_test_fixture_no_mutation(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'devicetree').mkdir()
            (p/'devicetree/compatible').write_bytes(b'qcom,blair\0')
            output=p/'RESULT.zip'
            before=sorted(x.name for x in (p/'devicetree').iterdir())
            doc=capture.capture((p/'devicetree',),{'platform':p/'empty'},output)
            self.assertEqual(doc['status'],'CURRENT_NODES_ENUMERATED')
            self.assertEqual(before,sorted(x.name for x in (p/'devicetree').iterdir()))
            self.assertIs(audit.parse_new_device_zip(output.read_bytes())['read_only'],True)


class TestFullReport(unittest.TestCase):
    def test_49_offline_without_device_is_explicit(self):
        with tempfile.TemporaryDirectory() as td:
            r=audit.audit(ROOT,Path(td))
            self.assertEqual(r['status'],'HISTORICAL_MODULE_ABI_DONE_AWAIT_DEVICE_NODE_CAPTURE')
            self.assertEqual(r['fresh_device_tree_nodes'],0)
            self.assertIs(r['boot_ready'],False)
    def test_50_offline_with_mock_device_is_not_boot_approval(self):
        with tempfile.TemporaryDirectory() as td:
            r=audit.audit(ROOT,Path(td),device_blob())
            self.assertEqual(r['status'],'CURRENT_DEVICE_NODES_COMPARED_BOOT_BLOCKED')
            self.assertIs(r['vendor_abi_proven'],False)
            self.assertIs(r['flash_allowed'],False)
    def test_51_output_five_reports_only(self):
        with tempfile.TemporaryDirectory() as td:
            audit.audit(ROOT,Path(td))
            self.assertEqual({p.name for p in Path(td).iterdir()},set(audit.REPORTS))
    def test_52_checksum_output_reproducible(self):
        with tempfile.TemporaryDirectory() as td:
            audit.audit(ROOT,Path(td))
            for line in (Path(td)/'SHA256SUMS.txt').read_text().splitlines():
                v,name=line.split('  ',1)
                self.assertEqual(hashlib.sha256((Path(td)/name).read_bytes()).hexdigest(),v)
    def test_53_reports_have_no_flash_binaries(self):
        with tempfile.TemporaryDirectory() as td:
            audit.audit(ROOT,Path(td),device_blob())
            self.assertFalse(any(p.suffix in ('.img','.ko','.dtb','.sh') for p in Path(td).iterdir()))
    def test_54_all_guards_false_in_report(self):
        with tempfile.TemporaryDirectory() as td:
            r=audit.audit(ROOT,Path(td))
            self.assertTrue(all(r[x] is False for x in (
                'vendor_abi_proven','r20_driver_probe_proven','boot_ready',
                'flash_allowed','kernel_built','source_patch_created','device_modified',
                'brene_changed','nomount_changed')))

if __name__=='__main__':unittest.main(verbosity=2)
