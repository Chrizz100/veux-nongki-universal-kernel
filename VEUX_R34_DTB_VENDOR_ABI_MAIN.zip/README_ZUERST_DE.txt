VEUX R34 – DT-Knoten/Treiberzuordnungen + historischer Vendor-Modul-ABI-Vergleich

NUR DIAGNOSE. KEIN FLASHPAKET. KEINE boot.img. Kein Kernelbuild und keine
Quelländerung. Keine Veraenderung an BReNE/NoMount.

GitHub: Lege dieses ZIP UNENTPACKT direkt im Repository-Hauptverzeichnis main ab.
Lege VEUX_R34_DTB_VENDOR_ABI_GATE.yml unter .github/workflows/ ab.

Fuer LIVE-Treiberzuordnungen erst die mitgelieferte
scripts/VEUX_R34_CAPTURE_GERAET.py auf VEUX in Termux ausfuehren (separat
bereitgestellte Python-Datei); sie schreibt VEUX_R34_DEVICE_EVIDENCE.zip nach
/sdcard/Download und enthaelt nur generische Node-/Treiberinformationen.
Bitte die Ergebnis-ZIP als separate Datei ins Repository-Root hochladen.

Ohne Geraete-ZIP erstellt der Workflow trotzdem einen vollstaendigen historischen
Vendor-ABI-Bericht, markiert jedoch die fehlende Live-Erfassung explizit.

WICHTIG: R33: Nur zwei RMNET-Module waren tatsaechlich geladen.
Die 38/182 Eintraege in modules.load sind keine Beweise fuer geladene Module.
R20-DTB-compatible Ueberschneidung ist kein Treiberbindungsnachweis fuer R20.
Der R34-Geratesnapshot beschreibt Treiber nur fuer den aktuell laufenden STOCK-Kernel.

GitHub-Ausgabe: R34_RESULT.json, R34_BERICHT_DE.txt, R34_VENDOR_MATRIX.csv,
R34_DEVICE_TREE_MATRIX.csv, SHA256SUMS.txt.

Alle Berichte muessen weiterhin Bootfreigabe = NEIN melden.
