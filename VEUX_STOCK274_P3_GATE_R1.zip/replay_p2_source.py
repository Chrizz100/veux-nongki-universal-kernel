#!/usr/bin/env python3
"""Reproduce only the already-proven P2 source preparation from the SHA-pinned P2-v5 YAML.

Not a kernel build. The historical workflow is read, never edited or invoked remotely.
The exact 5.4.274 P2 Git TREE, not a merely green job, is the authoritative gate.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import yaml

DONOR_BLOB = '8a5ff82b1b04838b27744cfef3d253732673b4a3'
VENDOR_SHA = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
P2_TREE = '16ce899d4549819d42d76b423ebcbd51f1b82a61'
XIAOMI_HEAD = '61397e524093d1ccb94769b5460825e2eaf8871e'
DONOR_WORKFLOW = '.github/workflows/ksu2-p2-veux-5.4.274-source-clean-proven-reproducibility-v5.yml'
STEPS = (
    'Initialize KSU2-P2 cleanup checkpoint audit',
    'Install deterministic build dependencies',
    'Install exact Android clang-r416183b',
    'Checkout immutable VEUX source base',
    'Recreate exact Linux 5.4.274 Candidate 2',
    'Fetch official Xiaomi VEUX reference',
    'Restore Xiaomi idle sleep policy',
    'Restore standard CPUFreq min max sysfs behavior',
    'Restore standard schedutil behavior',
    'Remove custom HZ100',
    'Restore standard load balance capacity rate limit',
    'Apply proven CASS max frequency thermal correction',
    'Restore cumulative VEUX defconfig',
    'Restore exact Xiaomi VEUX PELT8',
    'Gate exact P1 PROVEN parent source tree',
    'Prove exact P1 parent configuration before cleanup',
    'Remove inherited legacy KernelSU source and hook footprint',
    'Resolve P2 source-clean VEUX configuration',
)


def gitblob(blob: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(blob)).encode() + b'\0' + blob).hexdigest()


def load_plan(donor: Path, workspace: Path) -> tuple[dict[str, str], list[dict]]:
    data = donor.read_bytes()
    if gitblob(data) != DONOR_BLOB:
        raise ValueError('PINNED_HISTORICAL_WORKFLOW_CHANGED')
    info = yaml.safe_load(data)
    job = info['jobs']['ksu-source-cleanup']
    steps = job['steps'][:len(STEPS)]
    actual = tuple(s.get('name') for s in steps)
    if actual != STEPS:
        raise ValueError('HISTORIC_STEP_ORDER_CHANGED')
    # Only the expected vendor checkout is allowed as a non-script action.
    for i, step in enumerate(steps):
        if i == 3:
            if not str(step.get('uses','')).startswith('actions/checkout@'):
                raise ValueError('VENDOR_CHECKOUT_NOT_FOUND')
            with_opts = step.get('with', {})
            if with_opts.get('repository') != 'dereference23/kernel_xiaomi_sm6375' or with_opts.get('ref') != VENDOR_SHA:
                raise ValueError('VENDOR_SOURCE_ID_DRIFT')
            continue
        if 'uses' in step or step.get('shell') != 'bash':
            raise ValueError('UNEXPECTED_EXTERNAL_OR_NONBASH_STEP: '+str(step.get('name')))
        if not isinstance(step.get('run'), str) or '${{' in step['run']:
            raise ValueError('UNSAFE_OR_EXPRESSION_IN_RUN')
        path = step.get('working-directory', '.')
        if path not in ('.', 'kernel'):
            raise ValueError('UNEXPECTED_STEP_DIRECTORY '+str(path))
    env = {}
    for k, v in job['env'].items():
        val = str(v)
        val = val.replace('${{ github.workspace }}', str(workspace))
        if '${{' in val:
            raise ValueError('UNSUPPORTED_ENV_EXPRESSION '+k)
        env[k] = val
    if env.get('SOURCE_REF') != VENDOR_SHA or env.get('EXPECTED_P2_TREE') != P2_TREE:
        raise ValueError('SOURCE_PIN_DRIFT')
    return env, steps


def run_checked(*args: str, cwd: Path | None = None) -> str:
    p = subprocess.run(args, cwd=cwd, text=True, capture_output=True, timeout=65)
    if p.returncode:
        raise ValueError('COMMAND_FAILED '+repr(args)+' '+p.stderr[-250:])
    return p.stdout.strip()


def read_env_update(path: Path, last_pos: int, env: dict[str, str]) -> int:
    if not path.exists(): return last_pos
    data = path.read_bytes()
    if len(data) < last_pos: raise ValueError('GITHUB_ENV_TRUNCATED')
    body = data[last_pos:].decode('utf-8')
    for line in body.splitlines():
        if not line: continue
        if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*=', line):
            raise ValueError('UNSUPPORTED_GITHUB_ENV_LINE '+line[:70])
        key, value = line.split('=',1)
        env[key] = value
    return len(data)


def replay(donor: Path, workspace: Path, logdir: Path) -> dict:
    env0, steps = load_plan(donor, workspace)
    workspace = workspace.resolve(strict=True)
    kernel = workspace/'kernel'
    vendor_actual = run_checked('git','-C',str(kernel),'rev-parse','HEAD')
    if vendor_actual != VENDOR_SHA: raise ValueError('ACTUAL_VENDOR_REF_MISMATCH')
    # The workflow must not write to the project's repository; all changes stay inside the CI runner.
    if (workspace/'project'/'.git').exists() and kernel.resolve().is_relative_to((workspace/'project').resolve()):
        raise ValueError('KERNEL_IS_PROJECT_SUBDIRECTORY')
    os.makedirs(logdir, exist_ok=False)
    env = dict(os.environ)
    env.update(env0)
    efile = workspace/'p3_replay_environment'
    pfile = workspace/'p3_replay_path'
    env['GITHUB_ENV'] = str(efile)
    env['GITHUB_PATH'] = str(pfile)
    env_pos=path_pos=0
    for i, step in enumerate(steps):
        # Source-only replay: skip system package install, huge Clang archive,
        # and make/compile-only config steps. The exact P2 Git tree is mandatory.
        if i in (1, 2, 3, 15, 17):
            continue
        cwd = workspace / step.get('working-directory','.')
        print(f'P2_REPLAY_STEP={i:02d}:{step["name"]}',flush=True)
        p = subprocess.run(['bash','--noprofile','--norc','-e','-o','pipefail','-c',step['run']],
                           cwd=cwd,env=env,capture_output=True,text=True,timeout=1200)
        (logdir/f'{i:02d}.stdout.txt').write_text(p.stdout[-16000:])
        (logdir/f'{i:02d}.stderr.txt').write_text(p.stderr[-8000:])
        if p.returncode:
            raise ValueError('PROVEN_P2_REPLAY_FAILED_STEP_'+str(i)+': '+p.stderr[-900:])
        env_pos = read_env_update(efile,env_pos,env)
        if pfile.exists():
            s=pfile.read_bytes()
            if len(s)<path_pos: raise ValueError('GITHUB_PATH_TRUNCATED')
            for path in s[path_pos:].decode().splitlines():
                if not path.startswith(str(workspace)):
                    raise ValueError('UNSAFE_GITHUB_PATH')
                env['PATH']=path+os.pathsep+env['PATH']
            path_pos=len(s)
    final_tree=run_checked('git','-C',str(kernel),'rev-parse','HEAD^{tree}')
    if final_tree!=P2_TREE: raise ValueError('P2_TREE_FINAL_DRIFT '+final_tree)
    # Baseline compiled P2 configuration: independently authenticated GitHub
    # CI artifact, NOT re-generated by this intentionally source-only replay.
    cfgfile=workspace/'project/common/stock274/source_only_r2/P2_5_4_274_NO_ROOT_BUILD.config'
    if not cfgfile.is_file():raise ValueError('KNOWN_GOOD_P2_CONFIG_NOT_IN_REPO')
    confighash=hashlib.sha256(cfgfile.read_bytes()).hexdigest()
    if confighash!='f6a4c78bf637bbf89b5e3a3059cf9d1651e43189a6ac459e806fa289d8628f9d':
        raise ValueError('KNOWN_GOOD_P2_CONFIG_DRIFT '+confighash)
    xiaomi=run_checked('git','-C',str(kernel),'rev-parse','refs/remotes/xiaomi/veux-r-oss')
    if xiaomi!=XIAOMI_HEAD: raise ValueError('XIAOMI_STOCK_REF_MOVED '+xiaomi)
    result={"status":"PINNED_P2_SOURCE_REPRODUCED", "kernel":"5.4.274",
            "git_tree":final_tree,"git_commit":run_checked('git','-C',str(kernel),'rev-parse','HEAD'),
            "archived_p2_config_sha256":confighash,"config_rebuilt_this_run":False,
            "xiaomi_stock_sha":xiaomi,"kernel_compiled_this_run":False}
    (logdir/'SOURCE_REPLAY.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result


def main():
    a=argparse.ArgumentParser()
    a.add_argument('--legacy',required=True,type=Path)
    a.add_argument('--workspace',required=True,type=Path)
    a.add_argument('--logs',required=True,type=Path)
    args=a.parse_args()
    result=replay(args.legacy/DONOR_WORKFLOW,args.workspace,args.logs)
    print('P2_SOURCE=PROVEN; P2_TREE='+result['git_tree'])

if __name__=='__main__':
    try: main()
    except Exception as e:
        print('RECONSTRUCTION_BLOCKED: '+str(e),file=sys.stderr)
        sys.exit(2)
