VEUX R28 – GITHUB MAIN: STRUKTUR- UND ABI-HERKUNFTSAUDIT
======================================================
Stand: 23.10.2026 – R20-R11 als unveränderter Vergleich

ZWECK
- Erstmals vollständiges, selbstständiges GitHub-Actions-Audit mit den im R27 lokal geprüften
  Original-R21-/R22-/R24-/R25-Daten und vier echten Module.symvers-Ständen (R20 + 3x R26).
- Kein Kernelbuild, KEINE boot.img erzeugt oder geschrieben, kein AK3, KEIN Flash, keine Änderungen an BReNE.
- Nachweis der 836 zwischen Vendor-Familien widersprüchlichen Symbol-CRCs.
- Verhindert, dass ein grüner GitHub-Run als Flashfreigabe missverstanden wird.
- Erstellt Report und sortierte CSVs mit klaren Evidenzlücken.

GITHUB INSTALLATION (SOWOHL ZIP ALS AUCH YAML SIND ERFORDERLICH)
1) VEUX_R28_ABI_PROVENANCE_MAIN.zip unverändert ins REPO-HAUPTVERZEICHNIS (main) laden.
2) VEUX_R28_ABI_PROVENANCE_AUDIT.yml nach .github/workflows/ laden.
3) Auf GitHub Actions: "VEUX R28 – Structural ABI Provenance – NO BUILD / NO FLASH"
   -> Run workflow -> Branch main -> Run workflow.
4) Artifact "VEUX-R28-ABI-REPORT-<RunID>" herunterladen und den Report lesen.

OPTIONALE ZWEITE PHASE (NUR WENN DER LAUF EINE NEUE GERAETEHERKUNFT BRAUCHT)
- In Termux auf dem VEUX-Gerät mit Python:
  python3 scripts/r28_capture_device.py
- Das Skript fragt ggf. per 'su' rein lesende Dateien und Boot-Partition-PRUEFSUMMEN ab.
  Es prüft Boot-KERNEL-SHA256 über rein lesende Boot-Partition-Zugriffe und schreibt NUR
  VEUX_R28_DEVICE_EVIDENCE.zip ins aktuelle Termux-Verzeichnis.
- Dieses ZIP kann spaeter im GitHub-Repo-Hauptverzeichnis (main) hochgeladen werden.
- Derselbe R28-Workflow nimmt es dann als optionale zusätzliche Datenquelle.
- Keine neuen Bilder, kein flash, keine Kernel-/Systemänderung.
- Das Hochladen ist freiwillig und nicht erforderlich, damit der erste Auditlauf grün wird.

ENTHALTENE DATEN
- evidence/R21_IMPORTS.csv                         Original-14.648-Imports
- evidence/R20_Module.symvers                     Original-R20-R11-Vergleich
- evidence/R26_{kabi,nrcpus,oemdata}_Module.symvers    Original-Drei-Varianten
- evidence/R22_RUNTIME_REPORT.json                Historische laufende Konfiguration
- evidence/R24_REPORT.json                        Historische geladenen Modul-Build-IDs
- evidence/R25_CONFIG_*.csv                        Unveränderte Konfigurationsvergleiche
- evidence/R27_NACHWEISE.json                        Gesicherte Kernel-SHA-Referenzen
- evidence/MANIFEST_SHA256.json                    Hash-Pins für alle Eingabedaten
- scripts/r28_audit.py                            Audit und HARTE Prüfbedingungen
- scripts/r28_capture_device.py                   Optionaler reiner Geräte-Read-Collector
- tests/test_r28.py                               Negativ- und Positivtests
- tools/actionlint                                 Gepinnte actionlint 1.7.12 aus Uebergabe

SICHERHEIT
Falsche Hashes, fehlende Dateien, unbekannte Modulgruppen, Zählfehler oder unerlaubte
Eingabe-Formate führen zu einem FEHLER. Bei offener Vendor-ABI entsteht KEINE Flashfreigabe.
Der ursprüngliche R20-Replay-Kernel wird NICHT erneut kompiliert oder verändert.

Lokal: actionlint 1.7.12, Bash -n, Python, 24/24 Tests und Repo-Simulation gruen.
ShellCheck laeuft als eigener verpflichtender CI-Gate auf GitHub Ubuntu 24.04; lokal nicht verfuegbar.
