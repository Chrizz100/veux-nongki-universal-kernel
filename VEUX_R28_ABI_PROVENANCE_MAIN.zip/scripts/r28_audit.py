#!/usr/bin/env python3
"""R28: read-only VEUX ABI evidence consolidation. No kernel builds or system writes."""
import argparse
import collections
import csv
import hashlib
import io
import json
import pathlib
import re
import sys
import zipfile

EXPECTED_COUNTS = {
    'r20': {'MATCH': 6960, 'CRC_MISMATCH': 7653, 'ABSENT_IN_SYMVERS': 35},
    'kabi': {'MATCH': 6529, 'CRC_MISMATCH': 8084, 'ABSENT_IN_SYMVERS': 35},
    'nrcpus': {'MATCH': 6883, 'CRC_MISMATCH': 7730, 'ABSENT_IN_SYMVERS': 35},
    'oemdata': {'MATCH': 6872, 'CRC_MISMATCH': 7741, 'ABSENT_IN_SYMVERS': 35},
}
EXPECTED_CHANGED = {'kabi': 9717, 'nrcpus': 9600, 'oemdata': 9607}
EXPECTED_LOST = {'kabi': 431, 'nrcpus': 77, 'oemdata': 88}
SYMVERS_NAMES = {
    'r20': 'R20_Module.symvers',
    'kabi': 'R26_kabi_Module.symvers',
    'nrcpus': 'R26_nrcpus_Module.symvers',
    'oemdata': 'R26_oemdata_Module.symvers',
}
CRC = re.compile(r'^0x[0-9a-fA-F]{8}$')
HEX = re.compile(r'^[0-9a-fA-F]+$')
SHA = re.compile(r'^[0-9a-f]{64}$')


class EvidenceError(Exception):
    pass


def require(cond, message):
    if not cond:
        raise EvidenceError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalize_import_status(s):
    if s.startswith('ABSENT'):
        return 'ABSENT_IN_SYMVERS'
    require(s in ('MATCH', 'CRC_MISMATCH'), 'UNKNOWN_R21_STATUS:' + str(s))
    return s


def classify_vendor_path(path):
    require(path.startswith('/vendor/lib/modules/') and path.endswith('.ko'), 'UNKNOWN_VENDOR_PATH:' + str(path))
    return '5.4-gki' if '/5.4-gki/' in path else 'qgki'


def parse_symvers(raw):
    rows = {}
    for num, line in enumerate(raw.decode('utf8').splitlines(), 1):
        fields = line.split()
        require(len(fields) in (4, 5), f'MALFORMED_SYMVERS_ROW:{num}')
        crc, symbol, provider, export_type = fields[:4]
        namespace = fields[4] if len(fields) == 5 else ''
        require(bool(CRC.fullmatch(crc)), f'INVALID_CRC:{num}')
        require(symbol not in rows, 'DUPLICATE_EXPORT:' + symbol)
        rows[symbol] = (crc.lower(), provider, export_type, namespace)
    require(len(rows) == 14260, f'INVALID_EXPORT_COUNT:{len(rows)}')
    return rows


def input_bytes(evidence_dir):
    manifest_file = evidence_dir / 'MANIFEST_SHA256.json'
    require(manifest_file.is_file(), 'NO_ORIGINAL_SHA256_MANIFEST')
    manifest = json.loads(manifest_file.read_text(encoding='utf8'))
    expected = manifest['sha256']
    require(set(expected) == set(SYMVERS_NAMES.values()) | {
        'R21_IMPORTS.csv', 'R22_RUNTIME_REPORT.json', 'R24_REPORT.json',
        'R25_CONFIG_PRIORITY_FLAGS.csv', 'R25_CONFIG_ALL_DIFFERENCES.csv',
        'R27_NACHWEISE.json'
    }, 'UNEXPECTED_OR_MISSING_EVIDENCE_MANIFEST_ENTRIES')
    files = {}
    for name, sha in expected.items():
        require(bool(SHA.fullmatch(sha)), 'INVALID_SHA256_IN_MANIFEST:' + name)
        path = evidence_dir / name
        require(path.is_file() and not path.is_symlink(), 'MISSING_EVIDENCE:' + name)
        data = path.read_bytes()
        require(digest(data) == sha, 'ORIGINAL_EVIDENCE_SHA_MISMATCH:' + name)
        files[name] = data
    return files, manifest


def parse_imports(raw):
    rows = list(csv.DictReader(io.StringIO(raw.decode('utf8'))))
    require(len(rows) == 14648, f'R21_IMPORTS_COUNT_CHANGED:{len(rows)}')
    required = {'path','symbol','module_crc','r20_crc','r20_provider','status'}
    require(required.issubset(rows[0]), 'R21_IMPORTS_COLUMNS_INVALID')
    seen = set()
    for r in rows:
        classify_vendor_path(r['path'])
        require(bool(CRC.fullmatch(r['module_crc'])), 'R21_IMPORT_CRC_MALFORMED')
        key=(r['path'],r['symbol'])
        require(key not in seen, 'R21_DUPLICATE_MODULE_IMPORT:' + repr(key))
        seen.add(key)
    require(len({r['path'] for r in rows}) == 218, 'R21_MODULE_FILE_COUNT_CHANGED')
    return rows


def safe_device_input(archive_path):
    if archive_path is None:
        return None
    p = pathlib.Path(archive_path)
    require(p.is_file() and p.stat().st_size <= 2_000_000, 'DEVICE_ZIP_MISSING_OR_TOO_LARGE')
    with zipfile.ZipFile(p) as z:
        require(set(z.namelist()) == {'R28_DEVICE_EVIDENCE.json','README_DE.txt'}, 'DEVICE_ZIP_UNEXPECTED_FILES')
        entry=z.getinfo('R28_DEVICE_EVIDENCE.json')
        require(entry.file_size <= 300_000, 'DEVICE_JSON_TOO_LARGE')
        raw=z.read(entry)
    record=json.loads(raw)
    require(record.get('schema') == 'VEUX_R28_DEVICE_CAPTURE_V1', 'DEVICE_JSON_WRONG_SCHEMA')
    require(record.get('read_only') is True, 'DEVICE_CAPTURE_NOT_READ_ONLY')
    require(isinstance(record.get('loaded_modules'), list), 'DEVICE_LOADED_NOT_LIST')
    require(isinstance(record.get('candidates'), list), 'DEVICE_CANDIDATES_NOT_LIST')
    require(len(record['loaded_modules']) <= 100 and len(record['candidates']) <= 2500, 'DEVICE_REPORT_OVERSIZE')
    for r in record['loaded_modules']:
        require(isinstance(r,dict) and isinstance(r.get('name'),str) and len(r['name']) <= 80, 'DEVICE_BAD_LOADED_ENTRY')
        val=r.get('build_id')
        require(val is None or (isinstance(val,str) and len(val) <= 128 and HEX.fullmatch(val)), 'DEVICE_BAD_LOADED_BUILDID')
    for r in record['candidates']:
        require(isinstance(r,dict) and isinstance(r.get('name'),str) and len(r['name']) <= 80,'DEVICE_BAD_CANDIDATE')
        require(isinstance(r.get('path'),str) and len(r['path']) <= 512 and r['path'].startswith('/'), 'DEVICE_BAD_PATH')
        val=r.get('build_id')
        require(val is None or (isinstance(val,str) and len(val) <= 128 and HEX.fullmatch(val)), 'DEVICE_BAD_CANDIDATE_ID')
        val=r.get('sha256')
        require(val is None or (isinstance(val,str) and SHA.fullmatch(val)), 'DEVICE_BAD_CANDIDATE_SHA')
    boot_items=record.get('boot_kernels',[])
    require(isinstance(boot_items,list) and len(boot_items)<=4,'DEVICE_BOOT_KERNELS_INVALID')
    for b in boot_items:
        require(isinstance(b,dict) and b.get('partition') in ('boot_a','boot_b','boot'), 'DEVICE_BOOT_PARTITION_INVALID')
        h=b.get('kernel_sha256')
        require(h is None or (isinstance(h,str) and SHA.fullmatch(h)), 'DEVICE_BOOT_KERNEL_SHA_INVALID')
        size=b.get('kernel_size')
        require(size is None or (isinstance(size,int) and 0 < size <= 64*1024*1024), 'DEVICE_BOOT_KERNEL_SIZE_INVALID')
    return record


def device_assessment(device):
    if device is None:
        return {'status':'MISSING_FRESH_DEVICE_CAPTURE', 'module_matches': {},'group_proven':False}
    index=collections.defaultdict(list)
    for entry in device['candidates']:
        index[entry['name']].append(entry)
    results={}
    for r in device['loaded_modules']:
        name=r['name'];id_ = r.get('build_id')
        candidates=index.get(name, [])
        matches=[{'path':c['path'],'sha256':c.get('sha256')} for c in candidates if id_ and c.get('build_id') and c['build_id'].lower() == id_.lower()]
        groups=set()
        for c in matches:
            try:
                groups.add(classify_vendor_path(c['path']))
            except EvidenceError:
                groups.add('OTHER')
        results[name]={'loaded_build_id':id_, 'candidate_files_checked':len(candidates),
                       'same_build_id_candidates':matches,'candidate_groups':sorted(groups),
                       'note':'Build-ID match is a binary-identity clue, NOT proof of exact loader pathname or kernel ABI.'}
    unresolved=[r for r in results.values() if not r['same_build_id_candidates']]
    status=('ALL_REPORTED_MODULES_HAVE_BINARY_CANDIDATES_NOT_ABI_PROOF' if not unresolved and results
            else 'RUNTIME_MODULE_ORIGIN_REMAINS_UNRESOLVED')
    return {'status':status, 'module_matches':results,'group_proven':False,
            'kernel_release':device.get('kernel_release'), 'capture_warnings':device.get('warnings',[])}


def run_audit(evidence_dir, output_dir, device_zip=None):
    raw, manifest = input_bytes(pathlib.Path(evidence_dir))
    maps={name:parse_symvers(raw[fname]) for name,fname in SYMVERS_NAMES.items()}
    ref=maps['r20']
    for name,mapping in maps.items():
        require(mapping.keys() == ref.keys(), 'EXPORT_NAMES_OR_COUNT_DRIFT:' + name)
        require(all(mapping[key][1:] == ref[key][1:] for key in ref), 'EXPORT_SEMANTICS_DRIFT:' + name)
    imports=parse_imports(raw['R21_IMPORTS.csv'])
    r22=json.loads(raw['R22_RUNTIME_REPORT.json'])
    r24=json.loads(raw['R24_REPORT.json'])
    require(r22['kernel_release']['releases_agree'] is True,'R22_KERNEL_RELEASE_UNVERIFIED')
    require(r22['kernel_release']['uname_command_release'] == r24['kernel_release'],'R22_R24_RELEASE_DRIFT')
    loaded_names={r['name'] for r in r22['modules_snapshot']['loaded_module_records']}
    require(loaded_names == {'rmnet_shs','rmnet_offload'},'R22_LOADED_MODULES_NOT_AS_RECORDED')
    require(set(r24['comparison']) == loaded_names,'R24_LOADED_MODULE_MISMATCH')
    for name,record in r24['comparison'].items():
        require(record['currently_loaded'] is True,'R24_MODULE_NOT_LOADED:' + name)
        require(record['loaded_build_id'] == record['previous_r23_build_id'],'R24_R23_BUILDID_DRIFT')
        require(all(not c['match_loaded_build_id'] for c in record['candidates']),'R24_ORIGINAL_MODULE_ID_ALREADY_MATCHED')
    r27=json.loads(raw['R27_NACHWEISE.json'])
    require(r27['boot_reference_checks']['geraete_boot_a_19_10']['kernel_sha256'] ==
            '5fc8db0c92426e9628c2fe1fb8cd8e4157e4e91bc9e9d0ff9f2ed088c67596ce',
            'BOOT_REFERENCE_SHA_CHANGED')
    r25=list(csv.DictReader(io.StringIO(raw['R25_CONFIG_PRIORITY_FLAGS.csv'].decode('utf8'))))
    require(any(x['flag']=='CONFIG_SCHED_CASS' for x in r25),'NO_CASS_CONFIG_EVIDENCE')
    require(any(x['flag']=='CONFIG_SCHED_WALT' for x in r25),'NO_WALT_CONFIG_EVIDENCE')
    require(len(list(csv.DictReader(io.StringIO(raw['R25_CONFIG_ALL_DIFFERENCES.csv'].decode('utf8'))))) == 879,'R25_CONFIG_DIFF_COUNT')
    groups=collections.defaultdict(lambda:collections.defaultdict(set))
    totals=collections.defaultdict(collections.Counter)
    transitions=collections.defaultdict(collections.Counter)
    module_stats=collections.defaultdict(collections.Counter)
    hot=collections.defaultdict(lambda:collections.defaultdict(set))
    for line in imports:
        group=classify_vendor_path(line['path'])
        sym=line['symbol']; expected=line['module_crc'].lower()
        groups[group][sym].add(expected)
        base=(('ABSENT_IN_SYMVERS' if sym not in ref else 'MATCH' if ref[sym][0]==expected else 'CRC_MISMATCH'))
        require(base == normalize_import_status(line['status']), 'R21_R20_STATUS_DISAGREEMENT:' + sym)
        for name,mapping in maps.items():
            status=('ABSENT_IN_SYMVERS' if sym not in mapping else 'MATCH' if mapping[sym][0]==expected else 'CRC_MISMATCH')
            totals[name][status]+=1
            if name != 'r20':transitions[name][(base,status)]+=1
        module_stats[(group,line['path'])][base]+=1
        if base != 'MATCH':hot[(group,sym)]['files'].add(line['path'])
    require(all(len(v)==1 for gp in groups.values() for v in gp.values()),'VENDOR_GROUP_INTERNAL_CRC_CONFLICT')
    common=set(groups['qgki'])&set(groups['5.4-gki'])
    require(len(common)==1393,'SHARED_SYMBOL_COUNT_CHANGED')
    mismatch=sum(groups['qgki'][s]!=groups['5.4-gki'][s] for s in common)
    require(mismatch == 836,'CROSS_FAMILY_CRC_CONFLICT_COUNT_CHANGED')
    require(len(groups['qgki'])==1423 and len(groups['5.4-gki'])==3078,'GROUP_SYMBOL_COUNT_CHANGED')
    for name,expected in EXPECTED_COUNTS.items():
        require(dict(totals[name])==expected,'ABI_MATCH_COUNT_DRIFT:' + name + ':' + repr(totals[name]))
    diffs={name:sum(ref[s][0]!=maps[name][s][0] for s in ref) for name in maps if name!='r20'}
    require(diffs==EXPECTED_CHANGED,'R26_CHANGED_CRC_COUNT_DRIFT')
    gain={n:sum(ct for (before,after),ct in transitions[n].items() if before!='MATCH' and after=='MATCH') for n in diffs}
    loss={n:sum(ct for (before,after),ct in transitions[n].items() if before=='MATCH' and after!='MATCH') for n in diffs}
    require(not any(gain.values()),'UNEXPECTED_R26_NEW_MATCHES_RECHECK_REQUIRED')
    require(loss==EXPECTED_LOST,'R26_MATCH_LOSS_DRIFT')
    out=pathlib.Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    with (out/'R28_PER_MODULE_ABI.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(['vendor_group','file','r20_matches','r20_crc_mismatches','r20_missing_exports','runtime_loaded_binary_proven'])
        for (g,p),cts in sorted(module_stats.items()):
            w.writerow([g,p,cts['MATCH'],cts['CRC_MISMATCH'],cts['ABSENT_IN_SYMVERS'],'NO'])
    with (out/'R28_CRC_HOTSPOTS.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(['vendor_group','symbol','affected_module_files','vendor_expected_crc','r20_crc','interpretation'])
        rows=[]
        for (g,s),entry in hot.items():
            rows.append((g,s,len(entry['files']),next(iter(groups[g][s])),ref[s][0] if s in ref else 'ABSENT_IN_SYMVERS'))
        for g,s,n,expected,actual in sorted(rows,key=lambda r:(-r[2],r[0],r[1])):
            w.writerow([g,s,n,expected,actual,'frequency only; NOT source type causality'])
    with (out/'R28_FAMILY_CONFLICTS.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(['symbol','qgki_crc','5_4_gki_crc','conflict','r20_crc'])
        for s in sorted(common):
            w.writerow([s,next(iter(groups['qgki'][s])),next(iter(groups['5.4-gki'][s])),int(groups['qgki'][s]!=groups['5.4-gki'][s]),ref[s][0] if s in ref else 'ABSENT_IN_SYMVERS'])
    with (out/'R28_R24_LOADED_BINARY_CANDIDATES.csv').open('w',encoding='utf8',newline='') as f:
        w=csv.writer(f);w.writerow(['loaded_module','loaded_build_id','disk_path','disk_build_id','disk_sha256','equal_build_id'])
        for mod,rec in sorted(r24['comparison'].items()):
            for c in rec['candidates']:
                w.writerow([mod,rec['loaded_build_id'],c['path'],c['build_id'],c['on_disk_sha256'], 'YES' if c['match_loaded_build_id'] else 'NO'])
    device_record=safe_device_input(device_zip)
    device=device_assessment(device_record)
    saved_boots=r27['boot_reference_checks']
    reference_kernel_sha={label:entry['kernel_sha256'] for label,entry in saved_boots.items()}
    boot_comparison=[]
    if device_record is not None:
        for b in device_record.get('boot_kernels',[]):
            s=b.get('kernel_sha256')
            matches=[n for n,v in reference_kernel_sha.items() if s and s.lower()==v]
            boot_comparison.append({'partition':b.get('partition'), 'kernel_sha256':s,
                                   'matches_archived_kernel':matches,
                                   'status':'MATCHES_SAVED_KERNEL_BYTES' if matches else 'UNRESOLVED_NOT_A_BYTE_MATCH'})
    device['boot_kernel_identity_comparison']=boot_comparison
    j={'schema':'VEUX_R28_STRUCTURAL_ABI_EVIDENCE_V1','audit':'PASS_VERIFIED_HISTORICAL_EVIDENCE',
       'mode':'READ_ONLY_OFFLINE_NO_BUILD_NO_FLASH','reference':'R20-R11 WALT_ON',
       'source_evidence_hashes':manifest['sha256'],'vendor_module_files':len(module_stats),
       'vendor_import_observations':len(imports),'kernel_export_count':len(ref),
       'r20_import_status':dict(totals['r20']),
       'r26_variants':{n:{'status_counts':dict(totals[n]),'crc_changed':diffs[n],
                            'new_matched_imports':gain[n],'lost_matched_imports':loss[n]} for n in diffs},
       'vendor_families':{'qgki':len(groups['qgki']),'5.4-gki':len(groups['5.4-gki']),
                          'shared_symbols':len(common),'conflicting_expected_crcs':mismatch},
       'device_r22_release':r22['kernel_release']['uname_command_release'],
       'device_r24_loaded_binary_id_proven':False,'r24_loaded_modules':{n:v['loaded_build_id'] for n,v in r24['comparison'].items()},
       'new_device_capture':device,'abi_approved':False,'kernel_build_justified_by_ABI_evidence':False,
       'source_patch_allowed':False,'flash_allowed':False,
       'next_required_evidence':['actual loaded module binaries / build IDs','running boot kernel SHA identity',
                                 'OEM source and Kbuild genksyms/symtypes provenance']}
    (out/'R28_RESULT.json').write_text(json.dumps(j,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf8')
    md=['# VEUX R28 – Structural ABI proof (read-only)',
        '', '**AUDIT: PASS · VENDOR ABI: NOT PROVEN · KERNEL BUILD: NOT JUSTIFIED · FLASH: NO**',
        '', f"- Source: R20-R11 and three R26 original Module.symvers, SHA-256 checked against pinned manifest.",
        f"- Vendor module files: **{len(module_stats)}**; observed imports: **{len(imports):,}**; kernel exports: **{len(ref):,}**.",
        f"- R20 matches: **{totals['r20']['MATCH']:,}**; CRC mismatches: **{totals['r20']['CRC_MISMATCH']:,}**; missing exports: **{totals['r20']['ABSENT_IN_SYMVERS']}**.",
        f"- 2 vendor groups share **{len(common):,}** symbol names, **{mismatch}** of which require different CRCs.",
        f"- R26 matches gained: **0** across all three variants; matches lost: KABI {loss['kabi']}, NR_CPUS {loss['nrcpus']}, OEM_DATA {loss['oemdata']}.",
        f"- R24 loaded rmnet modules: **no matching on-disk Build-ID** among candidates; origin unresolved.",
        f"- New device capture: **{device['status']}**.",
        f"- Direct boot-kernel SHA-256 matches to archived kernels: **{sum(bool(x['matches_archived_kernel']) for x in boot_comparison)}** (if capture supplied).",
        '', '## Next evidence gate',
        '', '1. Capture actual runtime loaded module IDs and disk candidates (read-only optional collector).',
        '2. Match the actual running boot kernel bytes with the saved images.',
        '3. Choose the verified runtime ABI target; compare original OEM source + genksyms/symtypes before patching.',
        '4. Preserve R20-R11; no BReNE change; no blind config change; no AK3/boot.img.',
        '', 'These tables rank frequency of mismatches, **not** proven root causes. A GitHub Actions green check means only the audit code ran.',
        '']
    (out/'R28_GITHUB_SUMMARY.md').write_text('\n'.join(md),encoding='utf8')
    with (out/'R28_OUTPUT_SHA256SUMS.txt').open('w',encoding='utf8') as f:
        for p in sorted(out.iterdir()):
            if p.is_file() and p.name!='R28_OUTPUT_SHA256SUMS.txt':f.write(f'{digest(p.read_bytes())}  {p.name}\n')
    print('R28_AUDIT=PASS; OBSERVED_IMPORTS=14648; FAMILY_CRC_CONFLICTS=836; ABI=UNPROVEN; FLASH=NO')
    return j


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--evidence',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--device-zip')
    args=p.parse_args(argv)
    try:
        run_audit(args.evidence,args.out,args.device_zip)
    except (EvidenceError,KeyError,ValueError,UnicodeError,zipfile.BadZipFile) as exc:
        print('R28_HARD_FAIL: '+str(exc),file=sys.stderr)
        return 2
    return 0


if __name__=='__main__':
    sys.exit(main())
