#!/usr/bin/env python3
"""Termux read-only VEUX capture; writes a report ZIP to current working directory only."""
import datetime
import hashlib
import json
import pathlib
import re
import shlex
import struct
import subprocess
import sys
import zipfile

TARGET_MODULES = {'rmnet_shs', 'rmnet_offload'}
ROOTS = (
 '/vendor/lib/modules', '/vendor_dlkm/lib/modules', '/odm/lib/modules',
 '/odm_dlkm/lib/modules', '/system/lib/modules', '/system_dlkm/lib/modules',
 '/system_ext/lib/modules', '/product/lib/modules', '/lib/modules',
 '/first_stage_ramdisk/lib/modules', '/data/adb/modules',
 '/proc/1/root/vendor/lib/modules', '/proc/1/root/vendor_dlkm/lib/modules',
 '/proc/1/root/odm_dlkm/lib/modules', '/proc/1/root/system_dlkm/lib/modules',
 '/proc/1/root/lib/modules',
)


def command(argv, timeout=20):
    try:
        p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout,check=False)
        return p.stdout if p.returncode==0 else None
    except (OSError,subprocess.TimeoutExpired):
        return None


def su_read(path, timeout=20):
    # Only known absolute kernel or module paths, no user-supplied shell text.
    if not path.startswith('/') or '\n' in path or '\r' in path:
        return None
    return command(['su','-c','cat '+shlex.quote(path)], timeout=timeout)


def read_protected(path):
    try:
        return pathlib.Path(path).read_bytes()
    except OSError:
        return su_read(path)


def note_build_id(blob):
    """Parse GNU build-id ELF note bytes (sysfs note or ELF .note.gnu.build-id)."""
    for match in re.finditer(b'GNU\x00',blob):
        idx=match.start()
        if idx < 12:
            continue
        try:
            namesz,descsz,ntype=struct.unpack_from('<III',blob,idx-12)
        except struct.error:
            continue
        if namesz != 4 or ntype != 3 or not (4 <= descsz <= 64):
            continue
        desc_begin=(idx + namesz + 3)&~3
        desc_end=desc_begin+descsz
        if desc_end <= len(blob):
            return blob[desc_begin:desc_end].hex()
    return None


def vermagic(blob):
    pos=blob.find(b'vermagic=')
    if pos == -1:
        return None
    value=blob[pos+9:pos+250].split(b'\x00',1)[0]
    return value.decode('utf8','replace')[:220]


def discover_candidates():
    # find -L is intentionally NOT used: avoid following unexpected file system links.
    roots=' '.join(shlex.quote(r) for r in ROOTS)
    predicate=' \\( -name rmnet_shs.ko -o -name rmnet_offload.ko \\) '
    # Some roots will not exist; skip missing roots before find.
    script=('for root in '+roots+'; do '
            'if [ -d "$root" ]; then '
            'find "$root" -maxdepth 5 -type f '+predicate+' -print 2>/dev/null; '
            'fi; done')
    value=command(['su','-c',script],timeout=40)
    if value is None:
        return [], ['SU_READ_ONLY_FILE_DISCOVERY_UNAVAILABLE']
    paths=sorted(set(p for p in value.decode('utf8','replace').splitlines() if p.startswith('/')))
    if len(paths)>1000:
        return [], ['DISCOVERY_PATH_COUNT_TOO_LARGE']
    results=[];warnings=[]
    for path in paths:
        name=path.rsplit('/',1)[-1].removesuffix('.ko')
        if name not in TARGET_MODULES:
            continue
        blob=su_read(path,timeout=20)
        if blob is None:
            warnings.append('UNREADABLE_CANDIDATE:' + path)
            continue
        results.append({'name':name,'path':path,'sha256':hashlib.sha256(blob).hexdigest(),
                        'size':len(blob),'build_id':note_build_id(blob),'vermagic':vermagic(blob)})
    return results,warnings


def boot_kernel_identity(partition):
    """Read ONLY kernel bytes from Android boot partition; never capture flash images."""
    path='/dev/block/by-name/'+partition
    header=command(['su','-c','dd if='+shlex.quote(path)+' bs=4096 count=1 2>/dev/null'],timeout=20)
    if not header or len(header)<64 or header[:8]!=b'ANDROID!':
        return {'partition':partition,'kernel_size':None,'kernel_sha256':None,'read_status':'NO_ANDROID_BOOT_HEADER_OR_READ_ERROR'}
    kernel_size=struct.unpack_from('<I',header,8)[0]
    page=struct.unpack_from('<I',header,36)[0]
    if page not in (2048,4096,8192,16384):
        page=4096
    if not (0<kernel_size<=64*1024*1024):
        return {'partition':partition,'kernel_size':None,'kernel_sha256':None,'read_status':'INVALID_KERNEL_SIZE'}
    count=(kernel_size+page-1)//page
    data=command(['su','-c','dd if='+shlex.quote(path)+' bs='+str(page)+' skip=1 count='+str(count)+' 2>/dev/null'],timeout=100)
    if data is None or len(data)<kernel_size:
        return {'partition':partition,'kernel_size':kernel_size,'kernel_sha256':None,'read_status':'KERNEL_BYTES_UNREADABLE'}
    return {'partition':partition,'kernel_size':kernel_size,'kernel_sha256':hashlib.sha256(data[:kernel_size]).hexdigest(),
            'read_status':'READ_ONLY_KERNEL_HASH' }


def capture():
    warnings=[]
    kernel_release=read_protected('/proc/sys/kernel/osrelease')
    kernel_version=read_protected('/proc/version')
    modules=read_protected('/proc/modules')
    names=[]
    if modules:
        names=sorted({line.split(None,1)[0] for line in modules.decode('utf8','replace').splitlines() if line.strip()})
    else:
        warnings.append('PROC_MODULES_UNREADABLE')
    loaded=[]
    for name in sorted(TARGET_MODULES & set(names)):
        buildid=note_build_id(read_protected(f'/sys/module/{name}/notes/.note.gnu.build-id') or b'')
        if not buildid:
            warnings.append('SYSFS_LOADED_BUILD_ID_MISSING:' + name)
        loaded.append({'name':name,'build_id':buildid})
    if not loaded:
        warnings.append('NO_TARGET_MODULES_REPORTED_AS_LOADED')
    candidates,extra=discover_candidates();warnings.extend(extra)
    # Direct kernel payload SHA-256 is comparable to archived boot-kernel SHA-256.
    slot=(command(['getprop','ro.boot.slot_suffix']) or b'').decode('utf8','replace').strip()
    boot_names=(['boot_a','boot_b'] if slot in ('_a','_b') else ['boot_a','boot_b','boot'])
    boot_kernels=[boot_kernel_identity(name) for name in boot_names]
    if not any(x.get('kernel_sha256') for x in boot_kernels):
        warnings.append('DIRECT_BOOT_KERNEL_SHA_UNAVAILABLE')
    document={'schema':'VEUX_R28_DEVICE_CAPTURE_V1','read_only':True,
              'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'kernel_release':(kernel_release or b'').decode('utf8','replace').strip()[:150],
              'kernel_version':(kernel_version or b'').decode('utf8','replace').strip()[:700],
              'loaded_module_names':names[:300],
              'loaded_modules':loaded,'candidates':candidates,
              'boot_kernels':boot_kernels,'boot_active_slot_reported':slot,
              'warnings':warnings,
              'limitations':['Build-ID identity does not prove the exact loading pathname.',
                            'No ABI, source origin or flash approval is inferred from this capture.',
                            'Only metadata and hashes are saved; no partition or modules are written.']}
    dest=pathlib.Path.cwd()/'VEUX_R28_DEVICE_EVIDENCE.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps(document,sort_keys=True,indent=2,ensure_ascii=False)+'\n')
        z.writestr('README_DE.txt','VEUX R28 nur lesende Gerätediagnose. ZIP enthält Metadaten/Prüfsummen, kein Boot-Image oder Flash-Paket.\n')
    print('R28_DEVICE_CAPTURE=CREATED:',dest)
    print('target_loaded:',len(loaded),'disk_candidates:',len(candidates),'warnings:',len(warnings))
    print('Kein Flash; keine Änderungen am Gerät.')
    return dest


if __name__=='__main__':
    try:
        capture()
    except Exception as e:
        print('CAPTURE_FAILED; no changes to device:',repr(e),file=sys.stderr)
        sys.exit(2)
