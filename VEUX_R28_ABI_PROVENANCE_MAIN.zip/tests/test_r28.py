#!/usr/bin/env python3
"""R28 safety and fail-closed regression tests (offline and network-free)."""
import io
import json
import pathlib
import shutil
import struct
import sys
import tempfile
import unittest
import zipfile

PARENT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PARENT/'scripts'))
import r28_audit as audit
import r28_capture_device as device


class TestR28Safety(unittest.TestCase):
    def test_canonical_r20_audit(self):
        with tempfile.TemporaryDirectory() as d:
            j=audit.run_audit(PARENT/'evidence',pathlib.Path(d)/'output')
            self.assertEqual(j['vendor_module_files'],218)
            self.assertEqual(j['vendor_import_observations'],14648)
            self.assertEqual(j['vendor_families']['conflicting_expected_crcs'],836)
            self.assertEqual(j['r20_import_status']['MATCH'],6960)
            self.assertFalse(j['flash_allowed'])
            self.assertFalse(j['abi_approved'])
            self.assertFalse(j['source_patch_allowed'])
            self.assertFalse(j['kernel_build_justified_by_ABI_evidence'])
            self.assertEqual(j['new_device_capture']['status'],'MISSING_FRESH_DEVICE_CAPTURE')
            self.assertTrue((pathlib.Path(d)/'output'/'R28_CRC_HOTSPOTS.csv').is_file())

    def test_original_evidence_hashes(self):
        _, manifest=audit.input_bytes(PARENT/'evidence')
        self.assertEqual(len(manifest['sha256']),10)
        self.assertTrue(all(len(v)==64 for v in manifest['sha256'].values()))

    def test_corrupted_input_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            dest=pathlib.Path(d)
            shutil.copytree(PARENT/'evidence',dest/'evidence')
            target=dest/'evidence'/'R24_REPORT.json'
            target.write_bytes(target.read_bytes()+b'\n')
            with self.assertRaisesRegex(audit.EvidenceError,'ORIGINAL_EVIDENCE_SHA_MISMATCH'):
                audit.input_bytes(dest/'evidence')

    def test_missing_input_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            dest=pathlib.Path(d)
            shutil.copytree(PARENT/'evidence',dest/'evidence')
            (dest/'evidence'/'R20_Module.symvers').unlink()
            with self.assertRaisesRegex(audit.EvidenceError,'MISSING_EVIDENCE'):
                audit.input_bytes(dest/'evidence')

    def test_import_family_classification(self):
        self.assertEqual(audit.classify_vendor_path('/vendor/lib/modules/rmnet_shs.ko'),'qgki')
        self.assertEqual(audit.classify_vendor_path('/vendor/lib/modules/5.4-gki/rmnet_shs.ko'),'5.4-gki')

    def test_import_unknown_path_fails_closed(self):
        with self.assertRaisesRegex(audit.EvidenceError,'UNKNOWN_VENDOR_PATH'):
            audit.classify_vendor_path('/data/adb/modules/unknown.ko')

    def test_status_normalization(self):
        self.assertEqual(audit.normalize_import_status('ABSENT_IN_R20_SYMVERS'),'ABSENT_IN_SYMVERS')
        with self.assertRaisesRegex(audit.EvidenceError,'UNKNOWN_R21_STATUS'):
            audit.normalize_import_status('PASS')

    def test_invalid_duplicate_symvers(self):
        row=b'0x00000001\tsymbol\tvmlinux\tEXPORT_SYMBOL\n'
        with self.assertRaisesRegex(audit.EvidenceError,'DUPLICATE_EXPORT'):
            audit.parse_symvers(row+row)

    def test_wrong_symbol_count_rejected(self):
        with self.assertRaisesRegex(audit.EvidenceError,'INVALID_EXPORT_COUNT'):
            audit.parse_symvers(b'0x00000001\tfoo\tvmlinux\tEXPORT_SYMBOL\n')

    def test_malformed_crc_rejected(self):
        with self.assertRaisesRegex(audit.EvidenceError,'INVALID_CRC'):
            audit.parse_symvers(b'0xzzzzzzzz\tfoo\tvmlinux\tEXPORT_SYMBOL\n')

    def test_vendor_group_consistency(self):
        self.assertTrue(audit.EXPECTED_COUNTS['r20']['MATCH']>audit.EXPECTED_COUNTS['kabi']['MATCH'])
        self.assertEqual(sum(audit.EXPECTED_COUNTS['r20'].values()),14648)
        self.assertEqual(set(audit.EXPECTED_LOST),{'kabi','nrcpus','oemdata'})

    def test_missing_device_is_not_approved(self):
        check=audit.device_assessment(None)
        self.assertEqual(check['status'],'MISSING_FRESH_DEVICE_CAPTURE')
        self.assertIs(check['group_proven'],False)

    def test_no_id_match_is_not_approved(self):
        check=audit.device_assessment({'loaded_modules':[{'name':'rmnet_shs','build_id':'abcdef12'}],
            'candidates':[{'name':'rmnet_shs','path':'/vendor/lib/modules/rmnet_shs.ko','build_id':'12345678'}]})
        self.assertEqual(check['status'],'RUNTIME_MODULE_ORIGIN_REMAINS_UNRESOLVED')
        self.assertIs(check['group_proven'],False)

    def test_matching_id_is_still_not_abi_approval(self):
        check=audit.device_assessment({'loaded_modules':[{'name':'rmnet_shs','build_id':'abcdef12'}],
            'candidates':[{'name':'rmnet_shs','path':'/vendor/lib/modules/rmnet_shs.ko','build_id':'abcdef12'}]})
        self.assertEqual(check['status'],'ALL_REPORTED_MODULES_HAVE_BINARY_CANDIDATES_NOT_ABI_PROOF')
        self.assertIs(check['group_proven'],False)

    def test_archived_boot_payload_match_without_flash_authorization(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            known='5fc8db0c92426e9628c2fe1fb8cd8e4157e4e91bc9e9d0ff9f2ed088c67596ce'
            j={'schema':'VEUX_R28_DEVICE_CAPTURE_V1','read_only':True,
               'loaded_modules':[],'candidates':[],
               'boot_kernels':[{'partition':'boot_a','kernel_sha256':known,'kernel_size':34834944}]}
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps(j))
                z.writestr('README_DE.txt','synthetic test')
            r=audit.run_audit(PARENT/'evidence',pathlib.Path(d)/'out',p)
            checks=r['new_device_capture']['boot_kernel_identity_comparison']
            self.assertEqual(checks[0]['status'],'MATCHES_SAVED_KERNEL_BYTES')
            self.assertFalse(r['abi_approved'])
            self.assertFalse(r['flash_allowed'])

    def test_device_zip_wrong_members_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('../oops','n/a')
            with self.assertRaisesRegex(audit.EvidenceError,'DEVICE_ZIP_UNEXPECTED_FILES'):
                audit.safe_device_input(p)

    def test_device_zip_wrong_schema_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps({'schema':'OTHER'}))
                z.writestr('README_DE.txt','hi')
            with self.assertRaisesRegex(audit.EvidenceError,'DEVICE_JSON_WRONG_SCHEMA'):
                audit.safe_device_input(p)

    def test_device_boot_kernel_hash_validation(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            j={'schema':'VEUX_R28_DEVICE_CAPTURE_V1','read_only':True,
               'loaded_modules':[],'candidates':[],
               'boot_kernels':[{'partition':'boot_a','kernel_sha256':'invalid','kernel_size':123}]}
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps(j))
                z.writestr('README_DE.txt','test')
            with self.assertRaisesRegex(audit.EvidenceError,'DEVICE_BOOT_KERNEL_SHA_INVALID'):
                audit.safe_device_input(p)

    def test_device_valid_schema(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            j={'schema':'VEUX_R28_DEVICE_CAPTURE_V1','read_only':True,
               'loaded_modules':[{'name':'rmnet_shs','build_id':'abcdef12'}],
               'candidates':[{'name':'rmnet_shs','path':'/vendor/lib/modules/rmnet_shs.ko',
                              'build_id':'abcdef12','sha256':'0'*64}]}
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps(j))
                z.writestr('README_DE.txt','test')
            self.assertEqual(audit.safe_device_input(p)['schema'],j['schema'])
            with tempfile.TemporaryDirectory() as out:
                result=audit.run_audit(PARENT/'evidence',out,p)
                self.assertFalse(result['abi_approved'])
                self.assertFalse(result['flash_allowed'])

    def test_invalid_device_crc_input(self):
        with tempfile.TemporaryDirectory() as d:
            p=pathlib.Path(d)/'evidence.zip'
            j={'schema':'VEUX_R28_DEVICE_CAPTURE_V1','read_only':True,
               'loaded_modules':[{'name':'rmnet_shs','build_id':'WRONG-HEX'}],
               'candidates':[]}
            with zipfile.ZipFile(p,'w') as z:
                z.writestr('R28_DEVICE_EVIDENCE.json',json.dumps(j))
                z.writestr('README_DE.txt','test')
            with self.assertRaisesRegex(audit.EvidenceError,'DEVICE_BAD_LOADED_BUILDID'):
                audit.safe_device_input(p)

    def test_real_gnu_note_parser(self):
        raw=struct.pack('<III',4,8,3)+b'GNU\x00'+b'abcdefgh'
        self.assertEqual(device.note_build_id(raw),'6162636465666768')

    def test_note_parser_rejects_fake_note(self):
        raw=struct.pack('<III',4,8,9)+b'GNU\x00'+b'abcdefgh'
        self.assertIsNone(device.note_build_id(raw))

    def test_vermagic_parser(self):
        self.assertEqual(device.vermagic(b'junk\x00vermagic=5.4.274 aarch64\x00x'),'5.4.274 aarch64')
        self.assertIsNone(device.vermagic(b'unknown'))

    def test_read_only_collector_scans_fixed_roots(self):
        self.assertIn('/vendor/lib/modules',device.ROOTS)
        self.assertEqual(device.TARGET_MODULES,{'rmnet_shs','rmnet_offload'})
        self.assertFalse(hasattr(device,'flash'))


if __name__=='__main__':
    unittest.main()
