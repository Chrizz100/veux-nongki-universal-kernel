#!/usr/bin/env python3
"""Extend the proven R16 build by restoring the complete stock DMA alignment commit."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HEADER = 'arch/arm64/include/asm/cache.h'


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tokens(text):
    return hashlib.sha256(re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '',
                          text, flags=re.S)).encode()).hexdigest()


def profile():
    value = json.loads((ROOT / 'References/PROFILE.json').read_text())
    require(len(value['previous_matching_symbols']) == 1291
            and len(set(value['previous_matching_symbols'])) == 1291
            and len(value['required_new_stock_matches']) == 13,
            'WRONG_R16_R17_PROFILE')
    return value


def verify_package():
    files = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in files,
                'UNSAFE_R17_MANIFEST')
        require(not (ROOT / path).is_symlink() and sha(ROOT / path) == digest,
                'R17_PACKAGE_CHANGED:' + name)
        files.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == files, 'R17_MANIFEST_SCOPE_CHANGED')
    profile()


def prepared(source):
    source = Path(source).resolve(strict=True)
    path = source / HEADER
    require(path.is_file() and not path.is_symlink()
            and all(not p.is_symlink() for p in path.parents if p.is_relative_to(source)),
            'CACHE_HEADER_NOT_REGULAR')
    before = path.read_text()
    require(tokens(before) == profile()['before_tokens_sha256'], 'CACHE_HEADER_PREIMAGE_DRIFT')
    pattern = r'(?m)^#define[ \t]+ARCH_DMA_MINALIGN[ \t]+L1_CACHE_BYTES[ \t]*$'
    require(len(re.findall(pattern, before)) == 1, 'CACHE_ALIGNMENT_DECLARATION_CHANGED')
    after = re.sub(pattern, '#define ARCH_DMA_MINALIGN\t(128)', before)
    require(tokens(after) == profile()['after_tokens_sha256'], 'CACHE_HEADER_NOT_ORIGINAL_STOCK')
    return path, after


def check_source(source):
    path, _ = prepared(source)
    return {'header_sha256': sha(path), 'source_changed': False,
            'complete_commit_to_reverse': profile()['complete_reversed_commit']}


def apply_cache(source):
    path, after = prepared(source)
    path.write_text(after)
    return {'changed_files': [HEADER], 'header_sha256': sha(path),
            'stock_header_tokens_match': True, 'ARCH_DMA_MINALIGN': 128,
            'L1_CACHE_SHIFT_changed': False, 'irq_configuration_changed': False,
            'complete_reversed_commit': profile()['complete_reversed_commit']}


def verify_config_values(after):
    observed = hashlib.sha256(json.dumps(after, sort_keys=True,
                                        separators=(',', ':')).encode()).hexdigest()
    require(observed == profile()['config_values_sha256'], 'R16_CONFIGURATION_CHANGED')
    return {'config_changed_against_green_R16': False}


def verify_current_abi(actual, expected):
    p = profile()
    previous = set(p['previous_matching_symbols'])
    require(previous <= expected.keys(), 'R16_REFERENCE_NOT_IN_STOCK_COHORT')
    matches = {name for name, crc in expected.items() if actual.get(name) == crc}
    require(not previous - matches, 'PREVIOUS_1291_STOCK_MATCH_LOST:' + repr(sorted(previous - matches)))
    require(not expected.keys() - actual.keys(), 'ORIGINAL_IMPORT_MISSING')
    required = set(p['required_new_stock_matches'])
    require(required <= matches - previous, 'THIRTEEN_CRYPTO_GAINS_NOT_CONFIRMED')
    require(actual.get('module_layout') == '0x945d02f2', 'STOCK_MODULE_LAYOUT_LOST')
    return {'baseline_run': p['baseline_run'], 'baseline_matches': 1291,
            'gained_matching_symbols': sorted(matches - previous), 'lost_matching_symbols': [],
            'all_13_crypto_gains_confirmed': True,
            'counts': {'MATCH': len(matches), 'CRC_MISMATCH': len(expected) - len(matches),
                       'NOT_EXPORTED': 0}}


def load_base(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['base_tool_sha256'], 'PROVEN_R16_BUILD_ENGINE_CHANGED')
    spec = importlib.util.spec_from_file_location('r17_proven_r16_engine', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def build(args):
    verify_package()
    base = load_base(args.base_tool)
    check_source(args.source)
    result = {'status': 'R17_BUILD_PENDING', 'baseline_run': 43418418666,
              'flash_allowed': False, 'device_boot_tested': False,
              'irq_effective_affinity_changed': False, 'kernel_compiled': False}
    original_apply, original_config, original_abi = base.apply_source, base.verify_config, base.verify_abi

    # Extend three named interfaces of the authenticated engine. Its complete
    # R6 control, Image/DTB/module build and all existing proof gates still run.
    def apply_extended(source):
        old = original_apply(source)
        result['cache_source'] = apply_cache(source)
        return {'unchanged_R16_port': old, 'R17_cache_alignment': result['cache_source']}

    def config_extended(before, after):
        old = original_config(before, after)
        result['config_proof'] = verify_config_values(after)
        return old

    def abi_extended(actual, reference, expected):
        old = original_abi(actual, reference, expected)
        result['abi_progress'] = verify_current_abi(actual, expected)
        return dict(old, R17_progress=result['abi_progress'])

    base.apply_source, base.verify_config, base.verify_abi = apply_extended, config_extended, abi_extended
    output = Path(args.output).resolve()
    try:
        base.build(args)
        report = json.loads((output / 'R16_RESULT.json').read_text())
        require(report['kernel_compiled'] and report['r6_baseline_unchanged'], 'FULL_BUILD_NOT_PROVEN')
        require(result['abi_progress']['counts'] == report['qgki_counts'], 'ABI_REPORT_DISAGREEMENT')
        candidate = output / 'candidate-source' / HEADER
        require(sha(candidate) == result['cache_source']['header_sha256'], 'CACHE_HEADER_CHANGED_DURING_BUILD')
        result.update(status='R17_FULL_ARM64_BUILD_AND_STOCK_DMA_ALIGNMENT_PROGRESS_PROVEN_NOFLASH',
                      kernel_compiled=True, qgki_counts=report['qgki_counts'],
                      fully_matching_modules=report['fully_matching_modules'],
                      kernel_product_hashes=report['kernel_product_hashes'],
                      ipa_normal_kbuild=report['ipa_normal_kbuild'], r6_baseline_unchanged=True)
    except Exception as error:
        result.update(status='R17_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        if output.is_dir():
            (output / 'R17_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    bp = sub.add_parser('build')
    for name in ('base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        bp.add_argument('--' + name, required=True)
    args = parser.parse_args()
    verify_package()
    if args.operation == 'build':
        build(args)
    elif args.operation == 'check-source':
        print(json.dumps(check_source(args.source), sort_keys=True))
    else:
        print('R17_ONE_COMPLETE_STOCK_ALIGNMENT_COMMIT_AUTHENTICATED; KERNEL_NOT_BUILT; FLASH=NO')


if __name__ == '__main__':
    main()
