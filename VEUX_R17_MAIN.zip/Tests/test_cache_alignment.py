import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r17_tests', ROOT / 'Tools/r17_cache_alignment.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class CacheAlignmentTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / 'source'
        self.header = self.source / r.HEADER
        self.header.parent.mkdir(parents=True)
        shutil.copyfile(ROOT / 'References/CACHE_ORIGINAL.h', self.header)

    def tearDown(self):
        self.temp.cleanup()

    def test_complete_commit_restores_original_stock_header(self):
        result = r.apply_cache(self.source)
        self.assertEqual(result['ARCH_DMA_MINALIGN'], 128)
        self.assertFalse(result['irq_configuration_changed'])
        self.assertEqual(self.header.read_bytes(), (ROOT / 'References/CACHE_STOCK_RESTORED.h').read_bytes())

    def test_comments_preserved_and_preflight_does_not_write(self):
        self.header.write_text('/* previous source integration */\n' + self.header.read_text())
        before = self.header.read_bytes()
        self.assertFalse(r.check_source(self.source)['source_changed'])
        self.assertEqual(before, self.header.read_bytes())
        r.apply_cache(self.source)
        self.assertTrue(self.header.read_text().startswith('/* previous source integration */'))

    def test_unrelated_header_drift_and_reapplication_rejected(self):
        self.header.write_text(self.header.read_text() + '\n#define UNEXPECTED_ABI_CHANGE 1\n')
        before = self.header.read_bytes()
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
            r.apply_cache(self.source)
        self.assertEqual(before, self.header.read_bytes())
        shutil.copyfile(ROOT / 'References/CACHE_ORIGINAL.h', self.header)
        r.apply_cache(self.source)
        with self.assertRaises(ValueError):
            r.apply_cache(self.source)

    def test_symlink_cannot_redirect_source_write(self):
        outside = Path(self.temp.name) / 'outside'
        outside.write_bytes(self.header.read_bytes())
        before = outside.read_bytes()
        self.header.unlink()
        self.header.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'NOT_REGULAR'):
            r.apply_cache(self.source)
        self.assertEqual(outside.read_bytes(), before)

    def base(self):
        return r.load_base(os.environ['R17_BASE_TOOL'])

    def abi(self):
        base = self.base()
        h = base.dependency().dependency().dependency()[2]
        expected, _ = h.references()
        previous = set(r.profile()['previous_matching_symbols'])
        actual = {name: (crc if name in previous else '0x00000000') for name, crc in expected.items()}
        for name in r.profile()['required_new_stock_matches']:
            actual[name] = expected[name]
        return actual, expected

    def test_all_current_1291_matches_and_new_13_crypto_matches_required(self):
        actual, expected = self.abi()
        result = r.verify_current_abi(actual, expected)
        self.assertEqual(result['counts'], {'MATCH': 1304, 'CRC_MISMATCH': 119, 'NOT_EXPORTED': 0})
        actual[r.profile()['required_new_stock_matches'][0]] = '0x00000000'
        with self.assertRaisesRegex(ValueError, 'THIRTEEN_CRYPTO_GAINS'):
            r.verify_current_abi(actual, expected)

    def test_loss_or_missing_original_import_fails(self):
        actual, expected = self.abi()
        name = r.profile()['previous_matching_symbols'][0]
        original = actual[name]
        actual[name] = '0x00000000'
        with self.assertRaisesRegex(ValueError, '1291_STOCK_MATCH_LOST'):
            r.verify_current_abi(actual, expected)
        actual[name] = original
        removed = next(n for n in expected if n not in r.profile()['previous_matching_symbols'])
        del actual[removed]
        with self.assertRaisesRegex(ValueError, 'ORIGINAL_IMPORT_MISSING'):
            r.verify_current_abi(actual, expected)

    def test_configuration_must_stay_equal_to_green_r16(self):
        base = self.base()
        r12 = base.dependency().dependency().dependency()[1]
        # Original base reference is R15; apply only the three already proven R16 flags.
        values = r12.config_values((base.ROOT / 'References/R15.config').read_text())
        values.update(CONFIG_EMERGENCY_MEMORY='y', CONFIG_MULTIPLE_KSWAPD='y',
                      CONFIG_VM_EVENT_COUNT_CLEAN_PAGE_RECLAIM='y')
        self.assertFalse(r.verify_config_values(values)['config_changed_against_green_R16'])
        values['CONFIG_GENERIC_IRQ_EFFECTIVE_AFF_MASK'] = 'y'
        with self.assertRaisesRegex(ValueError, 'CONFIGURATION_CHANGED'):
            r.verify_config_values(values)


if __name__ == '__main__':
    unittest.main()
