#!/usr/bin/env python3
"""R17-B1: Xiaomi WALT EAS + active balancing; safe WALT-OFF branches.

The untouched P3/P10/R11 EAS algorithm stays the basis; WALT-specific many-
wakeup routing and the real Xiaomi push-task detach/attach lifecycle are added.
Pure source staging with exact GitHub source gates; never a flash release.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

DONOR='MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'
FAIR='kernel/sched/fair.c'
SCHED='kernel/sched/sched.h'
FILES=(FAIR,SCHED)
R17A_SCHED_SHA='46495eabc77cb0e47676486cc18c91d41f1872b8a9d043f3334abc56a4c0f83f'
R11_FAIR_SHA='f594f7286e068a7009a06e2cb8ae7ac6b10b95a8901580e79a67481a477a8ad3'
R17A_STATUS='R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED'
R17A_COMPILE_STATUS='R17A_OBJECT_OR_SYMBOL_DIAGNOSTICS_RECORDED'
FAIL_FLAGS=('vendor_abi_proven','flash_allowed','kernel_image_built','vmlinux_linked','brene_changed','bakasusu_nomount_changed')

class StageError(Exception):pass

def require(v,why):
    if not v:raise StageError(why)

def sha(raw):return hashlib.sha256(raw if isinstance(raw,bytes) else raw.encode()).hexdigest()

def replace_one(text,old,new,tag):
    ct=text.count(old)
    require(ct==1,tag+':EXACTLY_ONE_EXPECTED_'+str(ct))
    return text.replace(old,new,1)

def patch_eas(src):
    old='static int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu, int sync)\n{\n'
    # Xiaomi original uses the 4th parameter for many-wakeup detection. The
    # existing EAS calculation remains; the hint selects original OEM reuse.
    new='''#ifdef CONFIG_SCHED_WALT
static inline bool walt_is_many_wakeup(int sibling_count_hint)
{
	return sibling_count_hint >= sysctl_sched_many_wakeup_threshold;
}

int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu,
			       int sync, int sibling_count_hint)
#else
static int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu, int sync)
#endif
{
'''
    require('compute_energy(' in src and 'sd_asym_cpucapacity' in src,
            'EAS_REAL_ENERGY_ALGORITHM_NOT_PRESENT')
    src=replace_one(src,old,new,'EAS_ORIGINAL_FUNCTION')
    # Xiaomi's hint check goes after local declarations, immediately before
    # the first energy-model RCU read. The original C89/Clang declaration
    # order must remain unchanged (no statements before local variables).
    read='\trcu_read_lock();\n\tpd = rcu_dereference(rd->pd);'
    prefix='''#ifdef CONFIG_SCHED_WALT
	/* Genuine Xiaomi many-wakeup early return, keeping old EAS calculation. */
	if (walt_is_many_wakeup(sibling_count_hint) &&
	    prev_cpu != smp_processor_id() &&
	    cpumask_test_cpu(prev_cpu, p->cpus_ptr))
		return prev_cpu;
#endif
'''
    src=replace_one(src,read,prefix+read,'EAS_OEM_HINT_AFTER_LOCALS')
    # Existing non-QCOM 5.4 EAS caller must continue to call the original
    # 3-argument function with WALT OFF, 4-argument OEM when WALT ON.
    old='new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync);'
    new='''#ifdef CONFIG_SCHED_WALT
			new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync, 1);
#else
			new_cpu = find_energy_efficient_cpu(p, prev_cpu, sync);
#endif'''
    src=replace_one(src,old,new,'EAS_ORIGINAL_CALLSITE')
    return src

def patch_active_balance(src):
    old_decl='static int active_load_balance_cpu_stop(void *data);\n'
    decl='''#ifdef CONFIG_SCHED_WALT
int active_load_balance_cpu_stop(void *data);
#else
static int active_load_balance_cpu_stop(void *data);
#endif
'''
    src=replace_one(src,old_decl,decl,'BALANCER_DECL')
    begin='static int active_load_balance_cpu_stop(void *data)\n{\n'
    require(src.count(begin)==1,'BALANCER_ORIGINAL_BODY_SIGNATURE')
    new_begin='''#ifdef CONFIG_SCHED_WALT
int active_load_balance_cpu_stop(void *data)
#else
static int active_load_balance_cpu_stop(void *data)
#endif
{
'''
    src=replace_one(src,begin,new_begin,'BALANCER_IMPL_VISIBILITY')
    # Locate precisely the original function body, bounded by next global.
    start=src.index(new_begin)
    stop=src.index('static DEFINE_SPINLOCK(balancing);',start)
    body=src[start:stop]
    body=replace_one(body,'\tstruct rq_flags rf;\n','''	struct rq_flags rf;
#ifdef CONFIG_SCHED_WALT
	struct task_struct *push_task;
	int push_task_detached = 0;
	struct lb_env walt_env = {
		.sd = NULL,
		.dst_cpu = target_cpu,
		.dst_rq = target_rq,
		.src_cpu = busiest_rq->cpu,
		.src_rq = busiest_rq,
		.idle = CPU_IDLE,
		.flags = 0,
		.loop = 0,
	};
#endif
''','BALANCER_OEM_LOCALS')
    anchor='''	/* Search for an sd spanning us and the target CPU. */'''
    incoming='''#ifdef CONFIG_SCHED_WALT
	push_task = busiest_rq->wrq.push_task;
	target_cpu = busiest_rq->push_cpu;
	if (push_task) {
		if (task_on_rq_queued(push_task) &&
		    push_task->state == TASK_RUNNING &&
		    task_cpu(push_task) == busiest_cpu &&
		    cpu_online(target_cpu)) {
			update_rq_clock(busiest_rq);
			detach_task(push_task, &walt_env);
			push_task_detached = 1;
		}
		goto out_unlock;
	}
#endif

'''
    body=replace_one(body,anchor,incoming+anchor,'BALANCER_OEM_PUSH_PATH')
    old='''out_unlock:
	busiest_rq->active_balance = 0;
	rq_unlock(busiest_rq, &rf);

	if (p)
		attach_one_task(target_rq, p);
'''
    new='''out_unlock:
	busiest_rq->active_balance = 0;
#ifdef CONFIG_SCHED_WALT
	push_task = busiest_rq->wrq.push_task;
#endif
	target_cpu = busiest_rq->push_cpu;
#ifdef CONFIG_SCHED_WALT
	clear_reserved(target_cpu);
	if (push_task)
		busiest_rq->wrq.push_task = NULL;
#endif
	rq_unlock(busiest_rq, &rf);

#ifdef CONFIG_SCHED_WALT
	if (push_task) {
		if (push_task_detached)
			attach_one_task(target_rq, push_task);
		put_task_struct(push_task);
	}
#endif

	if (p)
		attach_one_task(target_rq, p);
'''
    body=replace_one(body,old,new,'BALANCER_OEM_ATTACH_RELEASE')
    require('detach_one_task(&env)' in body and 'rq_unlock(busiest_rq, &rf)' in body,
            'BALANCER_ORIGINAL_LOGIC_REMOVED')
    src=src[:start]+body+src[stop:]
    return src

def patch_fair(src):
    require('walt_env' not in src and 'walt_is_many_wakeup(' not in src,
            'R17B_ALREADY_MODIFIED_OR_FOREIGN')
    return patch_active_balance(patch_eas(src))

def patch_sched(src):
    needle='''#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)
extern void init_sched_groups_capacity(int cpu, struct sched_domain *sd);
#endif
'''
    require('extern int find_energy_efficient_cpu(' not in src and
            'extern int active_load_balance_cpu_stop(' not in src,
            'R17B_SCHED_PROTOTYPES_ALREADY_PRESENT')
    extra='''
#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SMP)
extern int find_energy_efficient_cpu(struct task_struct *p, int prev_cpu,
                                     int sync, int sibling_count_hint);
extern int active_load_balance_cpu_stop(void *data);
#endif
'''
    return replace_one(src,needle,needle+extra,'OEM_SCHED_REAL_PROTOTYPES')

def validate_input(r17a_src,r17a_compiler,r11_src):
    require(r17a_src.get('status')==R17A_STATUS,'R17A_SOURCE_GATE_BAD')
    require(r17a_src.get('after_sha256',{}).get(SCHED)==R17A_SCHED_SHA,'R17A_SCHED_PIN_MISMATCH')
    require(r17a_compiler.get('status')==R17A_COMPILE_STATUS,'R17A_COMPILER_STATUS_BAD')
    require(r17a_compiler.get('real_arm64_make_attempted') is True and
            r17a_compiler.get('object_success_count')==11 and
            r17a_compiler.get('qc_vas_compiled') is False and
            r17a_compiler.get('topology_compiled') is True,'R17A_PROVEN_11_OF_12_NOT_GROUNDED')
    require(r17a_compiler.get('symbol_evidence',{}).get('symbols_verified') is True,
            'R17A_FIVE_PROVIDERS_NOT_PROVEN')
    require(r11_src.get('status')=='R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED' and
            r11_src.get('after_sha256',{}).get(FAIR)==R11_FAIR_SHA,
            'R11_FAIR_CANONICAL_SHA_WRONG')
    for t in ('kernel/sched/core.c','kernel/sched/sched.h','kernel/sched/topology.c'):
        require(r17a_src.get('after_sha256',{}).get(t)==r17a_compiler.get('r17a_postimages',{}).get(t),
                'R17A_REAL_COMPILED_POSTIMAGE_DRIFT:'+t)
    for d in (r17a_src,r17a_compiler,r11_src):
        for flag in FAIL_FLAGS:
            require(d.get(flag,False) is False,'FALSE_SAFETY_FLAG:'+flag)
    require(r17a_compiler.get('objects',{}).get('kernel/sched/fair.o',{}).get('compiled') is True,
            'R17A_FAIR_NOT_COMPILED')

def stage(snapshot,source_gate,compiler_result,r11_gate,out):
    require(snapshot.is_dir() and not snapshot.is_symlink(),'SNAPSHOT_INVALID')
    require(not out.exists() and not out.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    inputs=[source_gate,compiler_result,r11_gate]
    require(all(p.is_file() and not p.is_symlink() for p in inputs),'INPUT_FILE_MISSING')
    docs=[json.loads(p.read_text()) for p in inputs]
    validate_input(*docs)
    for name,expected in docs[0]['after_sha256'].items():
        p=snapshot/name
        require(p.is_file() and not p.is_symlink() and sha(p.read_bytes())==expected,
                'R17A_POSTIMAGE_MISMATCH:'+name)
    before={}
    for n,expected in ((FAIR,R11_FAIR_SHA),(SCHED,R17A_SCHED_SHA)):
        p=snapshot/n
        require(p.is_file() and not p.is_symlink(),'R17B_SOURCE_PATH_INVALID:'+n)
        old=p.read_bytes()
        require(sha(old)==expected,'R17B_SOURCE_PREIMAGE_MISMATCH:'+n)
        before[n]=old.decode('utf-8')
    updated={FAIR:patch_fair(before[FAIR]),SCHED:patch_sched(before[SCHED])}
    require(all(updated[k]!=before[k] for k in FILES),'NO_ACTUAL_CHANGES')
    patch=''.join(''.join(difflib.unified_diff(before[n].splitlines(keepends=True),
         updated[n].splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n)) for n in FILES)
    require(patch.count('--- a/')==2 and patch.count('+++ b/')==2,'PATCH_SCOPE_CHANGED')
    q=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=patch,capture_output=True,text=True)
    require(q.returncode==0,'GIT_APPLY_CHECK_FAILED:'+q.stderr[:400])
    for n in FILES:
        p=snapshot/n;p.write_text(updated[n])
        require(sha(p.read_bytes())==sha(updated[n]),'R17B_SOURCE_WRITE_MISMATCH:'+n)
    out.mkdir(parents=True)
    (out/'R17B_FAIR_OEM_PROVIDER.patch').write_text(patch)
    d={'status':'R17B_FAIR_OEM_SCHEDULER_APIS_STAGED_NOT_COMPILED',
       'source_r17a_proven':True,'modified_files':list(FILES),
       'before_sha256':{n:sha(before[n]) for n in FILES},
       'after_sha256':{n:sha(updated[n]) for n in FILES},
       'patch_sha256':sha(patch),
       'provider_contracts':['find_energy_efficient_cpu','active_load_balance_cpu_stop'],
       'rest_open':['migrate_tasks','watchdog_enable','watchdog_configured',
                    'watchdog_disable','hrtimer_quiesce_cpu','timer_quiesce_cpu'],
       'donor':DONOR,'prior_11_objects':11,
       'exact_full_oem_eas_behavior_proven':False,
       'real_kernel_compile_proven':False,'real_runtime_behavior_proven':False,
       'vendor_abi_proven':False,'flash_allowed':False,'kernel_image_built':False,
       'vmlinux_linked':False,'brene_changed':False,'bakasusu_nomount_changed':False}
    (out/'R17B_SOURCE_GATE.json').write_text(json.dumps(d,sort_keys=True,indent=2)+'\n')
    return d

def main(argv=None):
    ap=argparse.ArgumentParser()
    for n in ('snapshot','r17a-source','r17a-compiler','r11-source','output'):
        ap.add_argument('--'+n,required=True,type=Path)
    v=ap.parse_args(argv)
    try:
        d=stage(v.snapshot,v.r17a_source,v.r17a_compiler,v.r11_source,v.output)
    except (StageError,ValueError,KeyError,OSError,UnicodeError) as e:
        print('R17B_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr)
        return 2
    print('R17B_FAIR_XIAOMI_SOURCE=STAGED; FILES=2; COMPILE=NOT_RUN; LINK=NO; ABI=OPEN; FLASH=NO')
    return 0
if __name__=='__main__':sys.exit(main())
