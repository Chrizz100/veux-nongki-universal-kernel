#!/usr/bin/env python3
"""P11: exact P3 source -> single P10 WALT-off source candidate.

Only operates inside ephemeral CI workspace/kernel checkout. Does not flash,
write the user's GitHub repository, or claim WALT runtime support.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

P2_TREE='16ce899d4549819d42d76b423ebcbd51f1b82a61'
P3_TREE='7f97dbbff432d61bbf11cae03de257a21f1d3c74'
P4_DORMANT_TREE='362565999b366c5e8c9e055dd6cdea553bfaf2cc'
P10_ZIP_SHA='088bf259ee072b7da73b1f34cbce22357a87f7a43b98f1f688776010a978ac96'
R4_ZIP_SHA='9d763d3e0a1a9d38f636a08710a291e657dd908b314c75521d0f436fd72209bb'
ALLOWED_SOURCE_DIRNAME='kernel'
ALLOWED_PATCH_PATHS=24
TRACE_WARNING='kernel/sched/walt/trace.c:82: new blank line at EOF.\n'


def sha(blob:bytes)->str:
    return hashlib.sha256(blob).hexdigest()


def run(cmd:list[str], *, cwd:Path|None=None, timeout=90, allow_error=False)->subprocess.CompletedProcess:
    r=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,timeout=timeout)
    if not allow_error and r.returncode:
        raise RuntimeError('COMMAND_FAILED '+repr(cmd[:8])+' stdout='+r.stdout[-500:]+' stderr='+r.stderr[-500:])
    return r


def git(kernel:Path,*args:str)->str:
    return run(['git','-C',str(kernel),*args]).stdout.strip()


def read_report(path:Path)->dict:
    report=json.loads(path.read_bytes())
    assert report['kernel']=='5.4.274', 'WRONG_KERNEL'
    assert report['p2_tree']==P2_TREE, 'WRONG_P2_TREE'
    assert report['p3_cass_free_tree']==P3_TREE, 'WRONG_P3_TREE'
    assert report['p4_dormant_walt_source_tree']==P4_DORMANT_TREE, 'WRONG_DORMANT_TREE'
    assert report['cass_removal_applied_in_temporary_source'] is True, 'CASS_NOT_REMOVED'
    assert report['flashable'] is False, 'UNEXPECTED_FLASH_PACKAGE'
    return report


def check_checkout(kernel:Path, workspace:Path)->None:
    if kernel.is_symlink() or not kernel.is_dir() or kernel.name!=ALLOWED_SOURCE_DIRNAME:
        raise RuntimeError('NOT_EPHEMERAL_KERNEL_CHECKOUT')
    if kernel.resolve()!=workspace.resolve()/'kernel':
        raise RuntimeError('NONSTANDARD_KERNEL_LOCATION')
    if not (kernel/'.git').exists():raise RuntimeError('MISSING_KERNEL_GIT_METADATA')
    if git(kernel,'status','--porcelain','--untracked-files=all'):
        raise RuntimeError('KERNEL_WORKTREE_IS_DIRTY')
    actual=git(kernel,'rev-parse','HEAD^{tree}')
    parent=git(kernel,'rev-parse','HEAD^^{tree}')
    if actual!=P4_DORMANT_TREE or parent!=P3_TREE:
        raise RuntimeError('UNEXPECTED_P3_P4_ANCESTRY '+actual+' '+parent)


def check_walt_registration(kconfig_text:str, scheduler_makefile_text:str)->None:
    # Fail closed for missing or duplicate WALT Kconfig symbols. Anchored
    # matching prevents accidentally accepting a comment or an unrelated
    # `CONFIG_SCHED_WALT` macro in C/preprocessor code.
    declarations=re.findall(r'(?m)^config SCHED_WALT[ \t]*$',kconfig_text)
    if len(declarations)!=1:
        raise RuntimeError('WALT_KCONFIG_MISSING_OR_DUPLICATE')
    if not re.search(r'(?m)^config SCHED_WALT[ \t]*\n\s+bool "Support window based load tracking"[ \t]*\n\s+depends on SMP[ \t]*$',kconfig_text):
        raise RuntimeError('WALT_KCONFIG_DEFINITION_DRIFT')
    if scheduler_makefile_text.count('obj-$(CONFIG_SCHED_WALT) += walt/\n')!=1:
        raise RuntimeError('WALT_MAKEFILE_MISSING_OR_DUPLICATE')


def stage(*,workspace:Path,p10_tools:Path,p3_result:Path,output:Path)->dict:
    workspace=workspace.resolve(strict=True)
    kernel=workspace/'kernel'
    p10_tools=p10_tools.resolve(strict=True)
    output=output.resolve()
    if output.exists() or output.is_relative_to(kernel.resolve()):
        raise RuntimeError('UNSAFE_OUTPUT_DIRECTORY')
    report=read_report(p3_result)
    check_checkout(kernel,workspace)
    p10_zip=workspace/'p11-bundles'/'VEUX_5_4_274_P10_WALT_KOMBI_PATCH_SAMMELPAKET.zip'
    r4_zip=workspace/'p11-bundles'/'VEUX_STOCK274_P3_GATE_R4.zip'
    for path,digest in ((p10_zip,P10_ZIP_SHA),(r4_zip,R4_ZIP_SHA)):
        if path.is_symlink() or not path.is_file() or sha(path.read_bytes())!=digest:
            raise RuntimeError('SOURCE_PACKAGE_PIN_MISMATCH '+path.name)
    p9_bundle=p10_tools/'P9_MASTER_ORIGINAL.zip'
    if p9_bundle.is_symlink() or not p9_bundle.is_file():
        raise RuntimeError('MISSING_P9_DEPENDENCY')
    # Restore only the ephemeral CI checkout from P4 donor-files commit to P3.
    # Never touch the user's repository; no server-side GitHub writes.
    run(['git','-C',str(kernel),'reset','--hard','HEAD^'])
    if git(kernel,'rev-parse','HEAD^{tree}')!=P3_TREE:
        raise RuntimeError('POST_RESET_P3_TREE_MISMATCH')
    if git(kernel,'status','--porcelain','--untracked-files=all'):
        raise RuntimeError('POST_RESET_DIRTY')
    output.mkdir(parents=True)
    generated=output/'P10_COMPOSED'
    run(['python3',str(p10_tools/'compose_p10_source.py'),
         '--source',str(kernel),'--p9-master',str(p9_bundle),'--output',str(generated)],timeout=240)
    r=json.loads((generated/'P10_REPORT.json').read_text())
    patch=generated/'P3_TO_P10_COMBINED_DORMANT_WALT.patch'
    if (r.get('p3_tree')!=P3_TREE or r.get('combined_changed_paths')!=ALLOWED_PATCH_PATHS
        or r.get('source_patch_sha256')!=sha(patch.read_bytes())
        or r.get('walt_config_default')!='n'
        or r.get('release_approved') is not False):
        raise RuntimeError('INVALID_P10_COMPOSITION_RESULT')
    if any('..' in Path(p).parts or p.startswith('/') for p in r['scope']):
        raise RuntimeError('INVALID_COMPOSITE_SCOPE')
    # Source change is allowed only after exact P3 tree and SHA-pinned patch checks.
    run(['git','-C',str(kernel),'apply','--check',str(patch)])
    run(['git','-C',str(kernel),'apply','--index',str(patch)])
    names=git(kernel,'diff','--cached','--name-only').splitlines()
    if sorted(names)!=sorted(r['scope']) or len(names)!=ALLOWED_PATCH_PATHS:
        raise RuntimeError('DIFF_SCOPE_DRIFT')
    normal=run(['git','-C',str(kernel),'diff','--cached','--check'],allow_error=True)
    if normal.returncode!=2 or normal.stdout!=TRACE_WARNING or normal.stderr:
        raise RuntimeError('UNEXPECTED_PATCH_WHITESPACE '+repr((normal.stdout+normal.stderr)[-250:]))
    safe=run(['git','-C',str(kernel),'-c','core.whitespace=-blank-at-eof',
              'diff','--cached','--check'])
    if safe.stdout or safe.stderr:raise RuntimeError('ADDITIONAL_WHITESPACE')
    # Pinned Xiaomi donor file byte hashes are verified by the P10 generator.
    # Kconfig declares `config SCHED_WALT` (without CONFIG_ prefix); the C
    # preprocessor macro CONFIG_SCHED_WALT is NOT the Kconfig declaration.
    check_walt_registration((kernel/'init/Kconfig').read_text(),
                            (kernel/'kernel/sched/Makefile').read_text())
    if any((kernel/x).exists() for x in ('drivers/kernelsu','KernelSU','fs/susfs.c')):
        raise RuntimeError('ROOT_SUBTREE_PRESENT')
    run(['git','-C',str(kernel),'-c','user.name=github-actions[bot]',
         '-c','user.email=41898282+github-actions[bot]@users.noreply.github.com',
         'commit','-qm','p11: compose source-only Xiaomi WALT dormant baseline'])
    if git(kernel,'status','--porcelain','--untracked-files=all'):
        raise RuntimeError('COMMITTED_SOURCE_DIRTY')
    tree=git(kernel,'rev-parse','HEAD^{tree}')
    if tree in (P2_TREE,P3_TREE,P4_DORMANT_TREE):
        raise RuntimeError('UNEXPECTED_COMPOSITE_TREE')
    state={
        'kernel':'5.4.274','source_p2_tree':P2_TREE,
        'source_p3_tree':P3_TREE,'source_p4_donor_tree':P4_DORMANT_TREE,
        'source_p11_composed_tree':tree,'combined_patch_sha256':sha(patch.read_bytes()),
        'changed_paths':names,'changed_path_count':len(names),
        'walt_11_original_files_byte_exact':True,'compile_attempted':False,
        'walt_enabled':False,'flashable':False,'user_repo_changed':False,
        'source_gate':'PASS',
    }
    (output/'P11_PREP_REPORT.json').write_text(json.dumps(state,indent=2,sort_keys=True)+'\n')
    return state


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--workspace',required=True,type=Path)
    ap.add_argument('--p10-tools',required=True,type=Path)
    ap.add_argument('--p3-result',required=True,type=Path)
    ap.add_argument('--output',required=True,type=Path)
    a=ap.parse_args()
    try: o=stage(workspace=a.workspace,p10_tools=a.p10_tools,p3_result=a.p3_result,output=a.output)
    except Exception as e:
        print('P11_SOURCE_GATE_FAIL: '+str(e),file=sys.stderr);return 2
    print('P11_SOURCE_GATE=PASS; P11_TREE='+o['source_p11_composed_tree']+'; BUILD=NOT_RUN')
    return 0

if __name__=='__main__':raise SystemExit(main())
