VEUX R60-R9 (04.11.2026): vorhandenen SUSFS-AVC-Hook behalten, gezielt reparieren.

Beleg: avc.c aus dereference23/kernel_xiaomi_sm6375@b2b7a3bbc36d +
SUSFS-5.4-Patch JackA1ltman (Git-Blob dd567741efd1144ee87283f52de640bd4cbdfc51)
ergibt bytegenau die erfolgreich kompilierte R13-avc.c:
SHA256 785f2de8539906bad413e4f15e34f59c36873ec09d6bd4ececb66e8721a304e9.
Das ist kein fehlender Hook: Er war bereits eingebaut. Die alte R59-Portierung
versuchte faelschlich, ihn erneut einzufuegen. R9 aktualisiert NUR den
bereits vorhandenen, gesamten SHA256-gepinnten R13-AVC-Quellstand:
- den Kontextpuffer im Audit-Bypass nach erfolgreicher Konvertierung freigeben,
- nur mit beiden gueltigen SID-Cachewerten einen Auditkontext maskieren,
- fuer die standardmaessig deaktivierte Static-Key den unlikely-Pfad verwenden.
Access-Entscheidungen, KSU/SUSFS-Konfiguration und die R13-Quellbasis werden
nicht geaendert. Jede Abweichung von den genauen R13-Preimages blockiert.

Die R60-R8-Fruehpruefung verwendet den korrigierten R9-Code automatisch,
noch vor dem eigentlichen Basiskernelbau. Nach dem Merge wird der reale R13-
Quellinventar-SHA256 weiterhin strikt geprueft. GitHub Actions produziert
bei Erfolg UND Fehlern Log-Artefakte (Text/JSON), keine Kernel-/Flashdateien.

Alle lokalen Tests pruefen Python-Logik und Quellkompatibilitaet; es gab in
dieser Sitzung KEINEN echten neuen ARM64-CI-Kernelbau. KERNEL=NOFLASH.

R60-R8: R13 SELinux-Host-Quellenhashes und fruehe Vorpruefung
Die alten R13-, R55H6- und GitHub-Quellstaende bleiben unveraendert.
Pins fuer hooks.c, avc.c und selinuxfs.c stammen aus den byteidentischen R13-Inventaren der Runs 40921711051 und 41635325597.
Eine fruehe, nur lesende Vorpruefung prueft die drei Host-Anker vor dem langen Basiskernelbau.
Beim R59-Quellmerge werden die Originaldateien anhand des gesamten R13-Inventars und ihrer exakten SHA-256 erneut geprueft.
Bei fehlender Kompatibilitaet wird keine Quellveraenderung ungeprueft zugelassen; Logs werden immer hochgeladen.
Compiler-/OEM-ABI-/Boot-Green-Pass weiterhin NICHT nachgewiesen. KEINE FLASHFREIGABE.

VEUX R60 — authentifizierte R13/R56-R4 Native54 CASS Compiler-/ABI-Fortsetzung
Datum: 03.11.2026, NO FLASH. Die Basis-Archive R13 und R56-R4 bleiben unveraendert.

Verbindlicher technischer Stand:
1) R59 stellt echte Source-Tools bereit, die auf dem separaten CI-Runner BakaSU 35259,
   SUSFS-5.4-Teildelta, CASS, NoMount und vier Native54 SELinux-Hostdateien
   zu einem gemeinsamen ARM64-Komprimierungs-Kandidaten zusammenfuehren.
2) Der R59-Build ist noch nicht tatsaechlich auf GitHub ausgefuehrt.
3) Die 14.648 historischen Imports stammen aus 218 Dateien in ZWEI
   inkompatiblen Kohorten. Der originale R30-R2-Befund nennt 836
   gleichnamige Symbole mit verschiedenen GKI-/QGKI-CRCs.
   Die neue R60-Analyse rechnet den Befund reproduzierbar aus dem
   SHA256-fixierten Original-R21-Datensatz nach.
4) Ein vollstaendiger CRC-PASS ueber beide historischen Kohorten ist fuer
   ein einzelnes Kernel-Module.symvers nicht gleichzeitig erreichbar.
   Ein Quell-/Compiler-PASS wird deshalb klar vom ABI-Release-PASS getrennt.
5) Das neue R60-Finalgate meldet einen unverifizierten OEM-Bootmodulsatz als
   BLOCKED und verhindert das falsche Gruen des kompletten Releases.
6) Native 5.4 SELinux/Postcompile Pruefung: postimage-SHA aller vier Hostdateien,
   tatsaechliche Objektdateien, nm-Symbole und 132 RMNET-CRCs werden erzwungen.
   Das Kontrollprogramm verwendet keine wegoptimierbaren Python-asserts.

Dateien fuer GitHub (in einem neuen Commit):
  VEUX_R60_NATIVE54_CASS_MAIN_NOFLASH.zip     (Repo-Hauptordner)
  .github/workflows/VEUX_R60_NATIVE54_CASS_BUILD_NOFLASH.yml

GitHub: Actions > VEUX R60 CASS native54 source compiler and cohort gate NOFLASH.
Der Workflow fuehrt actionlint 1.7.12 aus, dann den echten Build, den
getrennten QGKI/GKI Vergleich und das Final-Gate. Fail-closed bei Befunden.
Achtung: bisher nur lokale Tests, KEIN neuer GitHub-Vollbuild. Kein Image,
boot.img oder AK3 wird als flashbar publiziert. Keine Veraenderung am Telefon.
Fuer einen spaeteren OEM-ABI-PASS muss die tatsaechlich fuer den Bootvorgang
benoetigte Module-Load-Liste anhand belastbarer Geraete-/ROM-Belege feststehen.
Full Boot-/Device-/DTBO-/AK3-PASS ist weiterhin nicht erreicht.

R60 KCONFIG-KORREKTUR (03.11.2026):
  - Die originale R13 .config (4664 Einstellungen) bleibt die unveraenderliche Basis.
  - Neuer *fail-closed* tools/r60_config_guard.py prueft alle 4664 Baseline-Optionen.
  - Nur vier namentlich bekannte BakaSU 35259 Optionen und evtl. WALT=n
    duerfen als NEUE, DEAKTIVIERTE Schalter in olddefconfig hinzukommen.
  - Bei Aenderung einer einzigen alten Option oder unbekanntem Flag BLOCKED.
  - Das alte rohe byteweise cmp ist deshalb durch exakten semantischen
    Vergleich mit maschinenlesbarem R60_OLDDEFCONFIG_DELTA.json ersetzt.
  - Keine neuen Boot-Images, keine geaenderten OEM-CRCs, keine Flashfreigabe.
  - Native SUSFS type hash bucket matches now use stored exact type_value
    and check it at insertion/lookup; fixes false matches on collisions.
  - Dieser Patch ist ein lokaler 5.4-Backport-Fix, kein offizieller SUSFS-Commit.
  - R60-Compiler/GitHub-Run muss noch erfolgen.


R60-R4 (03.11.2026)
- Lauf 41602987413: alte R13-Basiskompilierung PASS, alle 132 RMNET-CRCs PASS, BakaSU-Replay PASS.
- R60-Integration scheiterte NUR an einem veralteten Preimage-Gate fuer services.c:
  Es erwartete den unveraenderten Xiaomi-/dereference23-Git-Blob, obwohl im
  nachweislich kompilierten R13-Quellbaum die R11/R13-Host-Exports vorliegen.
- Die zuvor erfolgreiche R13-Quellinventur und ein weiterer R13-Beleg nennen
  fuer security/selinux/ss/services.c genau SHA256 5e96d63c90cd102c6a92a4173430d44a44d5f86cf63345b39c678a842bad1e19.
- Die neue Integrationsstufe akzeptiert ausschliesslich genau diese R13-Datei,
  danach muessen Original-Patch, native Host-Hooks und der gemeinsame Kernelbau
  unveraendert alle weiteren Kbuild- und ABI-Gates bestehen.
- Original-R13 und R56 bleiben unveraendert. QUELLTEST-ERFOLG IST KEIN BUILDPASS.
- Kein boot.img/AK3, kein Flash, keine Bootfreigabe.


R60-R11 KORREKTUR (04.11.2026): Original GitHub Run 41766730742, echter
Clang-12.0.5-Compilerfehler in security/selinux/hooks.c, Zeilen 6557-6558.
R13 hat CONFIG_QCOM_RTIC=y. Bisherige KSU-extern-Deklarationen standen
im QCOM_RTIC-#else-Zweig und waren unsichtbar. r59_host.port_hooks() bindet
die vorhandene QCOM-RTIC-#if-#else-#endif-Gruppe nun komplett und hängt die
Deklarationen nach #endif an. Original-Symbole und BakaSU-Prototyp bleiben
unverändert; kein globales Auskommentieren, kein SELinux-Permissive.
Neuer Test test_r60_r11_qcom_rtic_compiler.py führt den originalen Fehler
mit einem echten C-Compiler vor und prüft beide QCOM_RTIC-Varianten.
Kein Image, kein boot.img, keine Flash-Freigabe, logs always.
Kernel-CI noch offen, kein Erfolg vorab garantiert.
R11-Fruehtest in GitHub nutzt explizit den authentifizierten clang-r416183b aus dem vorbereiteten Source-Audit; lokaler Test ohne Runner verwendet Host-Clang.


R60-R12 (04.11.2026): Der GitHub-Lauf 41774707788 scheiterte in Schritt 22,
weil der curl-Download des gepinnten Android-Clang-Archivs bei ~191 MiB
unvollstaendig endete (gzip/tar EOF). Die R11-Bridge wurde durch das alte
Modul veux_source_transport.materialize beim Aendern von engine.HERE
unbeabsichtigt ausgehebelt. R12 sichert die exakte Originaldatei mit ihrem
Git-Blob-Hash und bindet deren 5.4.274-Aufruf in-memory an den geprueften
Clang-Archiv-Transport. Keinerlei Aenderung am Original-GitHub-Repo oder
an R13. Vor der langwierigen Quellvorbereitung erfolgt ein tatsaechlicher
Clang-Archivdownload mit drei AOSP/CDN-Quellen und streng geprueftem Git-
Tree-Fallback. Jeder tar.gz wird ueber alle Daten und den gzip-CRC/Trailer
validiert; unvollstaendige Archive werden abgewiesen. Beide Legacy-Worker
verwenden das gleiche, authentifizierte Runner-Cache-Archiv.
Kernel CI / Boot / SUSFS-Verhalten noch nicht beweisen. Kein Flash.
