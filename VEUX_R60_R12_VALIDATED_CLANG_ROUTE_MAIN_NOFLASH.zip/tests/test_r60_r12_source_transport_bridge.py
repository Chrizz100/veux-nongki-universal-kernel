import gzip, hashlib, os, sys, unittest, tempfile, shutil
from pathlib import Path
from unittest.mock import patch, Mock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import veux_r60_clang_transport as b

class R12SourceTransportBridge(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='r12-bridge-test-')
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)

    def test_01_original_source_transport_is_exactly_pinned(self):
        self.assertEqual(b.ORIGINAL_SOURCE_TRANSPORT_GIT_BLOB,
                         '7a7f8ab87e0796c17463382e7039d170e06da32a')
        self.assertEqual(len(b.ORIGINAL_SOURCE_TRANSPORT_GIT_BLOB),40)
        repo=os.environ.get('GITHUB_WORKSPACE')
        if repo:
            path=Path(repo)/'common/scripts/veux_source_transport.py'
            data=path.read_bytes()
            h=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
            self.assertEqual(h,b.ORIGINAL_SOURCE_TRANSPORT_GIT_BLOB)

    def test_02_old_here_reset_reproduces_unwrapped_transport(self):
        from types import SimpleNamespace
        original=Path('/legacy/source/veux_update_engine.py')
        transport=Path('/legacy/source/veux_source_transport.py')
        bridge=Path(b.__file__).resolve()
        seen=[]
        def eng(label,work):
            seen.append(e.HERE)
            return 'seen'
        e=SimpleNamespace(HERE=bridge,materialize=eng)
        def old(label,work):
            previous=e.HERE
            try:
                e.HERE=transport
                return e.materialize(label,work)
            finally:e.HERE=previous
        old('5.4.274','dummy')
        self.assertEqual(seen,[transport],'R11 bug must be reproduced')
        self.assertEqual(e.HERE,bridge)

    def test_03_real_materialize_route_uses_pinned_bridge(self):
        from types import SimpleNamespace
        bridge=Path(b.__file__).resolve()
        engine=Path('/legacy/source/veux_update_engine.py')
        transport=Path('/legacy/source/veux_source_transport.py')
        calls=[]
        def eng(label,work):
            calls.append((label,e.HERE))
            return 'materialized'
        e=SimpleNamespace(HERE=engine,materialize=eng)
        def old(label,work):
            before=e.HERE
            try:
                e.HERE=transport
                return e.materialize(label,work)
            finally:e.HERE=before
        wrapped=b.pinned_source_materialize(e,old)
        self.assertEqual(wrapped('5.4.274','x'),'materialized')
        self.assertEqual(calls, [('5.4.274',bridge)])
        self.assertEqual(e.HERE,engine)
        self.assertEqual(wrapped('5.10.0','x'),'materialized')
        self.assertEqual(calls[-1],('5.10.0',transport))
        self.assertEqual(e.HERE,engine)

    def test_04_materialize_failure_restores_here(self):
        from types import SimpleNamespace
        oldhere=Path('/root/old-engine.py')
        e=SimpleNamespace(HERE=oldhere,materialize=Mock(side_effect=ValueError('worker failed')))
        materialize=b.pinned_source_materialize(e,Mock())
        with self.assertRaisesRegex(ValueError,'worker failed'):
            materialize('5.4.274','work')
        self.assertEqual(e.HERE,oldhere)

    def test_05_non_callable_original_blocked(self):
        with self.assertRaisesRegex(b.PinError,'ORIGINAL_MATERIALIZER_INVALID'):
            b.pinned_source_materialize(object(),None)

    def test_06_real_command_dispatch_prepares_archive_before_legacy(self):
        with patch.object(b,'safe_cache_dir',return_value=self.base),patch.object(b,'obtain_tar',return_value=self.base/'ok.tar.gz'),patch.object(b,'sha256',return_value='a'*64) as sha:
            b.main(['prime-cache'])
        sha.assert_called_once()

    def test_07_no_positional_args_allowed_for_prime(self):
        with self.assertRaisesRegex(b.PinError,'PRIME_REQUIRES_NO_ARGS'):
            b.main(['prime-cache','untrusted'])

    def test_08_corrupt_footer_is_rejected(self):
        import test_r60_clang_transport as old
        archive=old.create_fake_tar(self.base/'complete.tar.gz')
        b.validate_archive(archive)
        damaged=self.base/'damaged.tar.gz'
        damaged.write_bytes(archive.read_bytes()[:-8])
        try:
            b.validate_archive(damaged)
        except Exception as exc:
            self.assertTrue('gzip' in str(type(exc)).lower() or isinstance(exc,(b.PinError,EOFError,OSError)),repr(exc))
        else:
            self.fail('truncated gzip checksum not rejected')

    def test_09_previous_partially_downloaded_archive_never_cached(self):
        import test_r60_clang_transport as old
        src=old.create_fake_tar(self.base/'original.tar.gz')
        def broken(url,out):
            out.write_bytes(src.read_bytes()[:-8])
            b.validate_archive(out)
        with patch.object(b,'try_cdn',side_effect=broken),patch.object(b,'try_git_tree',side_effect=b.PinError('network down')):
            with self.assertRaisesRegex(b.PinError,'ALL_PINNED_CLANG_TRANSPORTS_FAILED'):
                b.obtain_tar(self.base)
        self.assertFalse((self.base/(b.VERSION+'.tar.gz')).exists())
        self.assertFalse((self.base/(b.VERSION+'.sha256')).exists())

    def test_11_real_checkout_materialize_bypasses_source_transport_here_reset(self):
        # This intentionally exercises the real checked-out 94-line transport,
        # not the reduced fixture that let the R11 bug slip through.
        repo=os.environ.get('GITHUB_WORKSPACE')
        if not repo:
            self.skipTest('Requires authentic GitHub Actions checkout')
        from importlib import import_module
        source=Path(repo)/'common/scripts'
        assert source.is_dir()
        path=source/'veux_source_transport.py'
        data=path.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        self.assertEqual(blob,b.ORIGINAL_SOURCE_TRANSPORT_GIT_BLOB)
        oldpath=sys.path[:]
        prev_engine=sys.modules.pop('veux_update_engine',None)
        prev_transport=sys.modules.pop('veux_source_transport',None)
        try:
            sys.path.insert(0,str(source))
            e=import_module('veux_update_engine')
            transport=import_module('veux_source_transport')
            pre=e.HERE
            with patch.object(e,'materialize',side_effect=lambda label,work:e.HERE):
                unpatched=transport.materialize('5.4.274',self.base)
                fixed=b.pinned_source_materialize(e,transport.materialize)
                corrected=fixed('5.4.274',self.base)
            self.assertEqual(unpatched.resolve(),path.resolve())
            self.assertEqual(corrected.resolve(),Path(b.__file__).resolve())
            self.assertEqual(e.HERE,pre)
        finally:
            sys.path[:]=oldpath
            sys.modules.pop('veux_update_engine',None)
            sys.modules.pop('veux_source_transport',None)
            if prev_engine is not None:sys.modules['veux_update_engine']=prev_engine
            if prev_transport is not None:sys.modules['veux_source_transport']=prev_transport

    def test_10_bridge_source_matches_current_workflow_context(self):
        s=(ROOT/'tools/veux_r60_clang_transport.py').read_text()
        self.assertIn('source_transport.materialize = pinned_source_materialize',s)
        self.assertIn('source_transport.materialize = legacy_materialize',s)
        self.assertIn('R60_CLANG_PREPARED_REAL_ARCHIVE=PASS',s)
        self.assertIn('PINNED_CLANG_GZIP_INCOMPLETE_OR_CORRUPT',s)

if __name__=='__main__':unittest.main()
