#!/usr/bin/env python3
from __future__ import annotations
import hashlib, io, os, random, subprocess, sys, tarfile, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"tools"))
import veux_r60_clang_transport as b


def fixture(archive:Path, *, bad_version=False, missing_tool=False):
    with tarfile.open(archive, "w:gz", compresslevel=1) as tf:
        version=b"12.0.5\nbased on r416183b\n"
        t=tarfile.TarInfo("AndroidVersion.txt");t.size=len(version);tf.addfile(t,io.BytesIO(version))
        for item in sorted(b.TOOLS):
            if missing_tool and item=="bin/llvm-nm":continue
            if item=="bin/clang":
                value=b"#!/bin/sh\necho 'Android (7284624, based on r416183b) clang version 12.0.5'\n"
                if bad_version:value=b"#!/bin/sh\necho 'clang version 13.0.0'\n"
            else:value=b"#!/bin/sh\nexit 0\n"
            t=tarfile.TarInfo(item);t.size=len(value);t.mode=0o755;tf.addfile(t,io.BytesIO(value))
        data=random.Random(894).randbytes(1_200_000)
        t=tarfile.TarInfo('lib/librandom.bin');t.size=len(data);tf.addfile(t,io.BytesIO(data))
    return archive


class R10RestoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='r10-test-');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        (self.root/'veux-r58').mkdir()
        self.cache=self.root/'veux-r60-clang-cache';self.cache.mkdir()
        self.archive=self.cache/(b.VERSION+'.tar.gz')
        self.target=self.root/'veux-r58/pinned-toolchain'/b.VERSION
        self.env=patch.dict(os.environ,{'VEUX_R60_BASE_TEMP':str(self.root),'VEUX_R60_CLANG_CACHE_DIR':str(self.cache)})
        self.env.start();self.addCleanup(self.env.stop)

    def add_valid_archive(self,*,bad_version=False,missing_tool=False):
        fixture(self.archive,bad_version=bad_version,missing_tool=missing_tool)
        (self.cache/(b.VERSION+'.sha256')).write_text(b.sha256(self.archive)+'\n')

    def test_01_restore_uses_real_cached_archive_and_binary_version(self):
        self.add_valid_archive()
        b.restore_pinned_clang([str(self.target)])
        self.assertTrue((self.target/'bin/clang').is_file())
        self.assertTrue(os.access(self.target/'bin/clang',os.X_OK))
        result=subprocess.check_output([str(self.target/'bin/clang'),'--version'],text=True)
        self.assertIn('based on r416183b',result)
        self.assertFalse((self.root/'veux-r5s2-work').exists())
        self.assertEqual(b.sha256(self.archive),(self.cache/(b.VERSION+'.sha256')).read_text().strip())

    def test_02_cache_missing_blocks_before_creating_target(self):
        with self.assertRaisesRegex(b.PinError,'CACHE_MISSING'):
            b.restore_pinned_clang([str(self.target)])
        self.assertFalse(self.target.parent.exists())

    def test_03_cache_tamper_blocks_without_clang(self):
        self.add_valid_archive();self.archive.write_bytes(self.archive.read_bytes()+b'wrong')
        with self.assertRaisesRegex(b.PinError,'CACHE_TAMPERED'):
            b.restore_pinned_clang([str(self.target)])
        self.assertFalse(self.target.exists())

    def test_04_refuse_escaping_output(self):
        self.add_valid_archive()
        with self.assertRaisesRegex(b.PinError,'RESTORE_PATH_OR_COLLISION'):
            b.restore_pinned_clang([str(self.root/'elsewhere')])

    def test_05_refuse_reused_target(self):
        self.add_valid_archive();self.target.parent.mkdir();self.target.mkdir()
        with self.assertRaisesRegex(b.PinError,'RESTORE_PATH_OR_COLLISION'):
            b.restore_pinned_clang([str(self.target)])

    def test_06_binary_version_spoof_rejected(self):
        self.add_valid_archive(bad_version=True)
        with self.assertRaisesRegex(b.PinError,'BINARY_VERSION_MISMATCH'):
            b.restore_pinned_clang([str(self.target)])
        self.assertFalse(self.target.exists())

    def test_07_missing_tool_is_rejected(self):
        self.add_valid_archive(missing_tool=True)
        with self.assertRaisesRegex(b.PinError,'TOOLS_MISSING_IN_ARCHIVE'):
            b.restore_pinned_clang([str(self.target)])
        self.assertFalse(self.target.exists())

    def test_08_insecure_parent_symlink_is_blocked(self):
        self.add_valid_archive()
        outside=self.root/'outside';outside.mkdir()
        (self.root/'veux-r58').rmdir()
        (self.root/'veux-r58').symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(b.PinError,'PARENT_UNTRUSTED'):
            b.restore_pinned_clang([str(self.target)])

    def test_09_cache_verification_does_not_create_toolchain(self):
        self.add_valid_archive()
        self.assertEqual(b.verify_cached_clang(),self.archive)
        self.assertFalse(self.target.exists())

    def place_source_archive(self):
        source=(self.root/'veux-r5s2-work/source-audit/5.4.274/source-temp')
        source.mkdir(parents=True)
        candidate=source/(b.VERSION+'.tar.gz')
        fixture(candidate)
        return candidate

    def test_11_seed_actual_preflight_archive_then_restore(self):
        source=self.place_source_archive()
        b.seed_cached_clang_from_source()
        self.assertEqual(b.sha256(self.archive),b.sha256(source))
        b.restore_pinned_clang([str(self.target)])
        self.assertTrue((self.target/'bin/clang').is_file())

    def test_12_seed_source_archive_missing_fails_before_compile(self):
        with self.assertRaisesRegex(b.PinError,'PREFLIGHT_ARCHIVE_MISSING_OR_UNSAFE'):
            b.seed_cached_clang_from_source()
        self.assertFalse(self.archive.exists())

    def test_13_seed_source_archive_must_not_be_symlink(self):
        path=(self.root/'veux-r5s2-work/source-audit/5.4.274/source-temp')
        path.mkdir(parents=True)
        (path/(b.VERSION+'.tar.gz')).symlink_to(self.root/'not-real')
        with self.assertRaisesRegex(b.PinError,'PREFLIGHT_ARCHIVE_MISSING_OR_UNSAFE'):
            b.seed_cached_clang_from_source()

    def test_14_seed_source_rejects_disagreeing_pinned_cache(self):
        source=self.place_source_archive()
        self.add_valid_archive()
        # A distinct, valid compressed tar from the same toolchain fixture
        # must still not silently override the exact preserved source bytes.
        # Keep the archive FULLY valid while changing gzip metadata. Appending
        # garbage now correctly fails the stricter R12 gzip trailer validation.
        import gzip
        source.write_bytes(gzip.compress(gzip.decompress(source.read_bytes()), mtime=1))
        b.validate_archive(source)
        with self.assertRaisesRegex(b.PinError,'DIFFERS_FROM_EXISTING_CACHE'):
            b.seed_cached_clang_from_source()

    def test_15_seed_source_refuses_invalid_archive(self):
        source=self.place_source_archive();source.write_bytes(b'invalid')
        with self.assertRaises((tarfile.TarError,EOFError,OSError,b.PinError)):
            b.seed_cached_clang_from_source()
        self.assertFalse(self.archive.exists())

    def test_10_restore_is_called_by_real_r59_compiler_script(self):
        script=(Path(__file__).resolve().parents[1]/'tools/r59_build_no_flash.sh').read_text()
        self.assertIn('restore-clang "$TC_ROOT"',script)
        self.assertIn('TC="$TC_ROOT/bin"',script)
        self.assertNotIn('TC="$RUNNER_TEMP/veux-r5s2-work/builds/',script)
        self.assertIn('R60_PINNED_CLANG_RESTORE.log',script)

if __name__=='__main__':unittest.main(verbosity=2)
