"""R26-R2 regression: full exported symbol provenance, only line-order differences accepted."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
SPEC=importlib.util.spec_from_file_location('r26_r2',ROOT/'r26_abi_ab_probe.py')
R=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(R)
FIX=ROOT/'fixtures'
REF=FIX/'R20_REAL_Module.symvers'
ROWS=REF.read_text().splitlines()

class R26R2ProvenanceTests(unittest.TestCase):
    def prove(self,lines,claim=None):
        with tempfile.TemporaryDirectory() as td:
            actual=Path(td)/'Module.symvers'
            actual.write_text('\n'.join(lines)+'\n')
            return R.stable_symvers_attestation(REF,actual,claim or R.sha256(actual))

    def test_known_pinned_fixture_still_valid(self):
        self.assertEqual(R.sha256(REF),'c626fc72563b7e96ebd2f50236a3b840847a65e9cc7affb2f47bf9b9c0692c21')
    def test_14260_complete_export_rows(self):
        self.assertEqual(len(ROWS),14260)
        self.assertEqual(len(set(ROWS)),len(ROWS))
    def test_exact_bytes_accepted(self):
        p=self.prove(ROWS)
        self.assertTrue(p['same_bytes']);self.assertFalse(p['order_only_drift'])
        self.assertTrue(p['fully_matched_export_records']);self.assertFalse(p['flash_allowed'])
    def test_reverse_order_accepted(self):
        p=self.prove(ROWS[::-1]);self.assertFalse(p['same_bytes'])
        self.assertTrue(p['order_only_drift']);self.assertEqual(p['complete_export_rows'],14260)
    def test_sorted_order_accepted(self):
        p=self.prove(sorted(ROWS));self.assertTrue(p['fully_matched_export_records'])
        self.assertEqual(p['complete_export_rows'],14260)
    def test_shuffle_order_accepted(self):
        p=self.prove(ROWS[5000:]+ROWS[:5000]);self.assertTrue(p['order_only_drift'])
    def test_content_hash_order_independent(self):
        a=self.prove(ROWS);b=self.prove(ROWS[::-1]);self.assertEqual(a['complete_export_records_sha256'],b['complete_export_records_sha256'])
    def test_report_sha_must_match_current_file(self):
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_REPORT_VS_OBJOUT_SHA_MISMATCH'):
            self.prove(ROWS[::-1],claim='a'*64)
    def test_changed_crc_rejected(self):
        rows=ROWS.copy();cols=rows[0].split('\t');cols[0]='0xdeadbeef';rows[0]='\t'.join(cols)
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):self.prove(rows)
    def test_changed_provider_rejected(self):
        rows=ROWS.copy();cols=rows[2].split('\t');cols[2]='drivers/other/spy';rows[2]='\t'.join(cols)
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):self.prove(rows)
    def test_changed_export_kind_rejected(self):
        rows=ROWS.copy();cols=rows[0].split('\t');cols[3]='EXPORT_SYMBOL_GPL' if cols[3]!='EXPORT_SYMBOL_GPL' else 'EXPORT_SYMBOL';rows[0]='\t'.join(cols)
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):self.prove(rows)
    def test_changed_namespace_rejected(self):
        rows=ROWS.copy();cols=rows[0].split('\t');cols[-1]='VENDOR_CHANGED';rows[0]='\t'.join(cols)
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):self.prove(rows)
    def test_missing_export_rejected(self):
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):self.prove(ROWS[:-1])
    def test_added_export_rejected(self):
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_EXPORT_CRC_TYPE_OR_PROVIDER_DRIFT'):
            self.prove(ROWS+['0x10000000\tbogus_sym\tvmlinux\tEXPORT_SYMBOL\t'])
    def test_duplicate_export_rejected(self):
        with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_DUPLICATE_EXPORTS'):self.prove(ROWS+[ROWS[0]])
    def test_malformed_export_rejected(self):
        with self.assertRaisesRegex(R.ProbeError,'MALFORMED_SYMVERS'):self.prove(ROWS+['0xbad'])
    def test_wrong_crc_format_rejected(self):
        rows=ROWS.copy();rows[0]='bad'+rows[0][10:]
        with self.assertRaisesRegex(R.ProbeError,'SYMVERS_INVALID_EXPORT'):self.prove(rows)
    def test_baseline_validation_accepts_reordered_symvers_with_valid_current_proof(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'arch/arm64/boot').mkdir(parents=True)
            (root/'.config').write_bytes((FIX/'R20_REAL_BUILD_CONFIG.config').read_bytes())
            (root/'Module.symvers').write_text('\n'.join(ROWS[::-1])+'\n')
            (root/'arch/arm64/boot/Image').write_bytes(b'ARM64_TEST_IMAGE')
            (root/'vmlinux').write_bytes(b'ELF64_TEST_VMLINUX')
            current=json.loads((FIX/'R20_BUILD_RESULT.json').read_text())
            current['module_symvers_sha256']=R.sha256(root/'Module.symvers')
            current['image']['sha256']=R.sha256(root/'arch/arm64/boot/Image')
            current['vmlinux']['sha256']=R.sha256(root/'vmlinux')
            (root/'current.json').write_text(json.dumps(current))
            info=R.baseline_validation(FIX,root,root/'current.json')
            self.assertTrue(info['live_symvers_attestation']['order_only_drift'])
            self.assertEqual(info['live_symvers_attestation']['complete_export_rows'],14260)
    def test_baseline_validation_rejects_forged_report_sha_even_when_rows_match(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);root.joinpath('arch/arm64/boot').mkdir(parents=True)
            (root/'.config').write_bytes((FIX/'R20_REAL_BUILD_CONFIG.config').read_bytes())
            (root/'Module.symvers').write_bytes(REF.read_bytes())
            current=json.loads((FIX/'R20_BUILD_RESULT.json').read_text());current['module_symvers_sha256']='0'*64
            (root/'current.json').write_text(json.dumps(current))
            with self.assertRaisesRegex(R.ProbeError,'R20_SYMVERS_REPORT_VS_OBJOUT_SHA_MISMATCH'):
                R.baseline_validation(FIX,root,root/'current.json')
    def test_proof_requires_reference_file(self):
        with self.assertRaisesRegex(R.ProbeError,'FILE_UNAVAILABLE_OR_SYMLINK'):
            R.stable_symvers_attestation('/no/such/reference',REF,R.sha256(REF))
    def test_pinned_expected_reference_still_passes(self):
        r=R.expected_reference(FIX)
        self.assertEqual(r['baseline_symbol_count'],14260)
        self.assertEqual(r['imports_count'],14648)

if __name__=='__main__':unittest.main()
