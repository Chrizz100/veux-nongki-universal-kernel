"""Execute the delivered Bash invocation and validate its real Python CLI arguments."""
import contextlib
import importlib.util
import io
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import textwrap
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
MARKER='python3 -B "$R21_SCHED_DIR/Tools/r21_scheduler_release.py" build'


def delivered_command():
    if 'R21_WORKFLOW' not in os.environ:
        return (ROOT/'References/R21_REPAIRED_BUILD_COMMAND.sh').read_text()
    lines=Path(os.environ['R21_WORKFLOW']).read_text().splitlines();matches=[]
    for i,line in enumerate(lines):
        if not line.strip().startswith('run: |'):continue
        indent=len(line)-len(line.lstrip());body=[]
        for row in lines[i+1:]:
            if row.strip() and len(row)-len(row.lstrip())<=indent:break
            body.append(row)
        script=textwrap.dedent('\n'.join(body))+'\n'
        if MARKER in script:matches.append(script)
    if len(matches)!=1:raise ValueError('BUILD_COMMAND_NOT_UNIQUE_IN_DELIVERED_YAML')
    return matches[0]


class WorkflowInvocationTests(unittest.TestCase):
    def driver(self):
        spec=importlib.util.spec_from_file_location('r21_actual_cli_test',ROOT/'Tools/r21_scheduler_release.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

    def capture_bash_arguments(self,body):
        with tempfile.TemporaryDirectory(prefix='r21 cli paths ') as temp:
            root=Path(temp);shim=root/'bin';shim.mkdir();capture=root/'argv'
            python=shim/'python3'
            python.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$R21_CAPTURE"\n')
            python.chmod(0o755)
            values={n:str(root/(n.lower()+' with spaces')) for n in
                    ['R19_RMNET_DIR','R18_IRQ_DIR','R17_CACHE_DIR','R16_REPAIR_DIR','R9_SNAPSHOT',
                     'R13_OBJOUT','R47_REPORT_DIR','R47_TOOLS_DIR','GITHUB_WORKSPACE','R16_REPAIR_OUTPUT']}
            values['R21_SCHED_DIR']=str(ROOT)
            env=dict(os.environ,**values,PATH=str(shim)+os.pathsep+os.environ['PATH'],R21_CAPTURE=str(capture))
            result=subprocess.run(['bash','-c',body],env=env,text=True,capture_output=True,timeout=10)
            self.assertEqual(result.returncode,0,result.stderr)
            argv=capture.read_bytes().split(b'\0');self.assertEqual(argv.pop(),b'')
            return [x.decode() for x in argv],values

    def test_delivered_bash_arguments_are_accepted_by_the_real_build_parser(self):
        body=delivered_command()
        self.assertEqual(body,(ROOT/'References/R21_REPAIRED_BUILD_COMMAND.sh').read_text())
        argv,env=self.capture_bash_arguments(body);m=self.driver()
        self.assertEqual(argv[:2],['-B',str(ROOT/'Tools/r21_scheduler_release.py')])
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'verify_package'),patch.object(m,'build') as build:
            m.main()
        build.assert_called_once();actual=vars(build.call_args.args[0])
        self.assertEqual(actual,dict(op='build',
            r19_tool=env['R19_RMNET_DIR']+'/Tools/r19_rmnet_vendor_abi.py',
            r18_tool=env['R18_IRQ_DIR']+'/Tools/r18_irq_affinity.py',
            r17_tool=env['R17_CACHE_DIR']+'/Tools/r17_cache_alignment.py',
            base_tool=env['R16_REPAIR_DIR']+'/Tools/restore_memory_network.py',
            source=env['R9_SNAPSHOT'],objout=env['R13_OBJOUT'],
            r6_report=env['R47_REPORT_DIR']+'/R47_RESULT.json',
            r6_tool=env['R47_TOOLS_DIR']+'/Tools/veux_r47_r13_on_r46.py',
            project=env['GITHUB_WORKSPACE']+'/project',output=env['R16_REPAIR_OUTPUT']))

    def test_original_run43504034071_plus_error_is_reproduced_and_rejected(self):
        body=(ROOT/'References/R21_FAILED_BUILD_COMMAND.sh').read_text()
        argv,_=self.capture_bash_arguments(body);self.assertIn('+',argv)
        m=self.driver();stderr=io.StringIO()
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'build') as build,contextlib.redirect_stderr(stderr):
            with self.assertRaises(SystemExit) as failure:m.main()
        self.assertEqual(failure.exception.code,2);build.assert_not_called()
        self.assertIn('unrecognized arguments: +',stderr.getvalue())


if __name__=='__main__':unittest.main()
