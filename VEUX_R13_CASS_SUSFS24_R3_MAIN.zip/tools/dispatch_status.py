"""Check the SUSFS dispatcher using stubbed handlers and test-only command numbers."""
import argparse
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory


def run(source, config, before):
    dispatch = (source / "KernelSU/kernel/supercall/dispatch.c").read_text()
    definition = re.search(r"^int ksu_handle_susfs_cmd\([^\n]+\)\n\{.*?^\}", dispatch, re.M | re.S)
    if not definition:
        raise ValueError("Missing SUSFS dispatcher")
    body = definition[0]
    handlers = re.findall(r"case (CMD_[A-Z0-9_]+): \{\s+(\w+)\(arg\);", body)
    if not handlers or len(handlers) != len(set(handlers)):
        raise ValueError("Unexpected SUSFS dispatcher cases")
    config_defines = [
        f"#define {name} 1" for name in re.findall(r"^(CONFIG_KSU_SUSFS_[A-Z_]+)=y$", config.read_text(), re.M)
    ]
    test_defines = [f"#define {name} {i}" for i, (name, _) in enumerate(handlers, 1)]
    handler_ids = {name: i for i, name in enumerate(sorted({handler for _, handler in handlers}), 1)}
    stubs = [
        f"static void {handler}(void **arg) {{ handled = {i}; last_argument = arg; }}"
        for handler, i in handler_ids.items()
    ]
    cases = "\n".join(f"    assert(ksu_handle_susfs_cmd({name}, &reply) == 0);\n"
                      f"    assert(handled == {handler_ids[handler]} && last_argument == &reply);"
                      for name, handler in handlers)
    unknown_result = "0" if before else "-EOPNOTSUPP"
    diagnostic = ("BASELINE unknown cases return zero without a warning" if before else
                  "PASS unknown cases are rejected and reach the diagnostic path")
    fake_kernel = """
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#define __user
static unsigned int handled;
static unsigned int warnings;
static void **last_argument;
#define pr_warn_ratelimited(...) ((void)++warnings)
"""
    test = f"""
int main(void)
{{
    void *reply = &handled;
{cases}
    assert(warnings == 0);
    handled = 0;
    last_argument = NULL;
    assert(ksu_handle_susfs_cmd(0, &reply) == {unknown_result});
    assert(ksu_handle_susfs_cmd(UINT_MAX, &reply) == {unknown_result});
    assert(!handled && !last_argument && reply == &handled);
    assert(warnings == {0 if before else 2});
    puts("PASS all {len(handlers)} existing cases retain their handler and return code");
    puts("{diagnostic}");
}}
"""
    with TemporaryDirectory(prefix="veux-dispatch-") as directory:
        cfile = Path(directory) / "test.c"
        binary = cfile.with_suffix("")
        cfile.write_text("\n".join([fake_kernel, *config_defines, *test_defines, *stubs, body, test]))
        subprocess.run(
            ["cc", "-std=gnu11", "-O2", "-Werror=implicit-function-declaration", cfile, "-o", binary],
            check=True,
        )
        subprocess.run([binary], check=True, timeout=10)


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("source", type=Path)
    cli.add_argument("config", type=Path)
    cli.add_argument("--before", action="store_true")
    args = cli.parse_args()
    run(args.source, args.config, args.before)
