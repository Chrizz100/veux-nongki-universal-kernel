"""Test the compiled SUSFS status output using the production C functions."""
import argparse
import re
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from debug import SUSFS_FEATURES

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path)
parser.add_argument("--before", action="store_true")
args = parser.parse_args()
code = (args.source / "fs/susfs.c").read_text()
first = code.index("static int copy_config_to_buf(")
last = code.index("/* show_variant */", first)
production = code[first:last]
header = (args.source / "include/linux/susfs.h").read_text()
defs = (args.source / "include/linux/susfs_def.h").read_text()
decl = re.search(r"struct st_susfs_enabled_features \{[^}]+\};", header)[0]
buffer_size = re.search(r"^#define SUSFS_ENABLED_FEATURES_SIZE[ \t]+(\d+)", defs, re.M)[1]
ordered = re.findall(
    r'copy_config_to_buf\("(CONFIG_KSU_SUSFS_[A-Z_]+)\\n"', production,
)
assert len(ordered) == len(SUSFS_FEATURES) and set(ordered) == SUSFS_FEATURES
config = "".join(f"#define {name} 1\n" for name in ordered)
kernel_api = r"""
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define __user
#define GFP_KERNEL 0
#define SUSFS_LOGE(...)
#define SUSFS_LOGI(...)

static bool allocation_failed;
static inline void *kzalloc(size_t size, int flags)
{
    return allocation_failed ? NULL : calloc(1, size);
}
static inline void kfree(void *memory)
{
    free(memory);
}
static inline unsigned long copy_from_user(void *dst, const void *src, size_t len)
{
    memcpy(dst, src, len);
    return 0;
}
static inline unsigned long copy_to_user(void *dst, const void *src, size_t len)
{
    memcpy(dst, src, len);
    return 0;
}
"""
expected_value = "".join(f'"{feature}\\n"\n' for feature in ordered)
tests = r"""
int main(void)
{
    struct st_susfs_enabled_features reply;
    void *output = &reply;
    size_t length = sizeof(expected) - 1;

    memset(&reply, 0, sizeof(reply));
    susfs_get_enabled_features(&output);
    assert(reply.err == 0);
    assert(strcmp(reply.enabled_features, expected) == 0);
    puts("PASS ten ordered entries in a zero-initialized status buffer");

    memset(&reply, 0xa5, sizeof(reply));
    susfs_get_enabled_features(&output);
    assert(reply.err == 0);
    assert(memcmp(reply.enabled_features, expected, length) == 0);
#if BASELINE
    assert((unsigned char)reply.enabled_features[length] == 0xa5);
    puts("BASELINE nonzero previous byte survives directly after the feature list");
#else
    for (size_t n = length; n < sizeof(reply.enabled_features); n++)
        assert(reply.enabled_features[n] == '\0');
    puts("PASS ten entries and a zeroed tail in a reused status buffer");
#endif

    allocation_failed = true;
    susfs_get_enabled_features(&output);
    assert(reply.err == -ENOMEM);
    puts("PASS allocation error remains visible to the caller");
}
"""
with TemporaryDirectory(prefix="veux-status-") as temp:
    directory = Path(temp)
    c_file = directory / "status.c"
    binary = directory / "status"
    c_file.write_text(
        kernel_api + config + f"#define BASELINE {int(args.before)}\n"
        + f"#define SUSFS_ENABLED_FEATURES_SIZE {buffer_size}\n"
        + decl + "\n" + production + "\nstatic const char expected[] =\n"
        + expected_value + ";\n" + tests
    )
    subprocess.run(["cc", "-std=gnu11", "-O2", "-fsanitize=undefined",
                    "-fno-sanitize-recover=all", "-Werror=implicit-function-declaration",
                    c_file, "-o", binary], check=True)
    subprocess.run([binary], check=True, timeout=10)
