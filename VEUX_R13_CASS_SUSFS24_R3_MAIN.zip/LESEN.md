# VEUX R13-CASS · R3 Befehlsdiagnose

Lege die R3-MAIN-ZIP in den obersten Ordner des Repositories und die R3-YAML unter `.github/workflows/` ab. Der manuelle Workflow heißt **VEUX R13 CASS · SUSFS 2.4 R3 Befehlsdiagnose · NOFLASH**.

Der [Prüfbericht](PRUEFBERICHT.md) beschreibt die Diagnosekorrektur, den Vorher-/Nachher-Test und den Stockabgleich.
