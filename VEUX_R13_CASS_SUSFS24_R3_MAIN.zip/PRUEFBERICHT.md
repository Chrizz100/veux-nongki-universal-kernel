# R13-CASS · SUSFS 2.4 R3 Befehlsdiagnose

26. November 2026 · POCO X4 Pro 5G · HyperOS Global OS1.0.12.0.TKCMIXM

## Befund und Korrektur

Der gelinkte R2 enthält die zusätzliche SUS_PATH-UID-Funktion. Der gepinnte BakaSU-Dispatcher hat dafür keinen Aufrufpfad. Vier im GitHub-Artefakt dokumentierte Startfunktionen und die SUSFS-Statusfunktion weisen keinen direkten Aufruf auf. Die Funktion gehört zu einer zusätzlichen Steuerungsmöglichkeit. [R2-GitHub-Lauf](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45857966361/job/140041230166)

Bei einem unbekannten SUSFS-Befehl lieferte der interne Dispatcher bisher `0`. Der Reboot-Wrapper verwirft diesen Wert und setzt den regulären Syscall-Pfad fort. R3 protokolliert unbekannte Befehle mit einem Ratenlimit und gibt intern `-EOPNOTSUPP` zurück. Der reguläre Reboot-Pfad bestimmt die Syscall-Rückgabe an die App.

Der Test verwendet Platzhalter für die Befehlsnummern und Handler. Er bestätigt für 16 vorhandene Befehle im R13-Konfigurationsstand die Weiterleitung. Zwei unbekannte Testbefehle lösen nach der Korrektur die Diagnose und den internen Fehler aus.

## Lokal geprüft

- LLDB prüfte 5.868.864 ARM64-Wörter in 5 ausführbaren Abschnitten. Im Dispatcher sind die Begrenzung der Meldung und der Ausgabeaufruf gelinkt.
- Die zehn SUSFS-Statuseinträge, der Ausgabepfad der Statuskorrektur und die Tests des Dateiwächters sind bestätigt.
- Der Gerätebaum und 12.947 Einträge der Modulschnittstelle entsprechen dem gerätebestätigten R13-CASS. Der Stockabgleich verwendet die Xiaomi-Global-OTA OS1.0.12.0.TKCMIXM. Die Binärvergleiche mit Xiaomi Stock, R13-CASS, ConfigDiag10 und dem lokalen R2 sind als JSON enthalten.
- Die R13-Ramdisk, Kernel-Kommandozeile und OS-Felder sind in der Layout-Gegenprobe bytegleich.

Der Workflow baut und prüft den Kernel und veröffentlicht die Prüfnachweise. Der Gerätepass und die Flash-Freigabe für R3 stehen aus.

SHA-256 des lokalen ARM64-Images `43f0feae9ea13577fbc4f8c867bde5bd72394d4c82ae65e880aa79b7f9645d97`
