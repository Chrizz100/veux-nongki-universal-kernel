#!/usr/bin/env python3
"""Fail-closed tests for R4 module ABI checks, not an Android device PASS."""
import struct
import argparse
import io
import sys
import unittest
from unittest.mock import patch
from pathlib import Path
import tempfile
import build_shs as b

MODULE = None


def record(name, crc):
    return struct.pack('<Q', crc) + name.encode().ljust(56, b'\0')


class ABI(unittest.TestCase):
    def setUp(self):
        self.exports = {'module_layout': 0xbff14f69, 'register_netdevice_notifier': 0x12345678}
        self.records = list(self.exports.items())

    def test_reference_identity(self):
        self.assertEqual(len(b.reference()), 12947)

    def test_accept_exact_abi(self):
        self.assertEqual(b.verify_versions(self.records, {'register_netdevice_notifier'}, self.exports), 2)

    def test_reject_rom_gki_layout(self):
        with self.assertRaisesRegex(RuntimeError, 'module_layout'):
            b.verify_versions([('module_layout', 0x1e5b7ab7)], set(), self.exports)

    def test_reject_rom_qgki_layout(self):
        with self.assertRaisesRegex(RuntimeError, 'module_layout'):
            b.verify_versions([('module_layout', 0x945d02f2)], set(), self.exports)

    def test_reject_nonlayout_crc_mismatch(self):
        with self.assertRaisesRegex(RuntimeError, 'ABI mismatch'):
            b.verify_versions([self.records[0], ('register_netdevice_notifier', 0)], set(), self.exports)

    def test_reject_missing_export(self):
        with self.assertRaisesRegex(RuntimeError, 'ABI mismatch'):
            b.verify_versions(self.records+[('unavailable', 0)], set(), self.exports)

    def test_reject_unversioned_strong_import(self):
        with self.assertRaisesRegex(RuntimeError, 'without CRC'):
            b.verify_versions(self.records, {'missing_import'}, self.exports)

    def test_reject_duplicate_version(self):
        with self.assertRaisesRegex(RuntimeError, 'duplicate'):
            b.verify_versions(self.records+self.records, set(), self.exports)

    def test_reject_empty_versions(self):
        with self.assertRaises(RuntimeError):
            b.verify_versions([], set(), self.exports)

    def test_parse_valid_aarch64_records(self):
        self.assertEqual(b.parse_versions(b''.join(record(n, c) for n,c in self.records)), self.records)

    def test_reject_partial_record(self):
        with self.assertRaisesRegex(RuntimeError, 'malformed'):
            b.parse_versions(record('module_layout', 0)[:-1])

    def test_reject_unterminated_name(self):
        with self.assertRaisesRegex(RuntimeError, 'unterminated'):
            b.parse_versions(struct.pack('<Q', 0)+b'a'*56)

    def test_reject_nonzero_padding(self):
        with self.assertRaisesRegex(RuntimeError, 'padding'):
            b.parse_versions(record('bad\0name', 0))

    def test_reject_wide_crc(self):
        with self.assertRaisesRegex(RuntimeError, '32 bits'):
            b.parse_versions(record('module_layout', 1<<32))

    def test_reject_invalid_name(self):
        with self.assertRaisesRegex(RuntimeError, 'invalid version name'):
            b.parse_versions(record('bad-name', 0))

    def test_no_existing_work_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            sentinel = root/'sentinel'
            sentinel.write_text('keep')
            with self.assertRaisesRegex(RuntimeError, 'fresh'):
                b.run_build(root, root, root/'public', 1)
            self.assertEqual(sentinel.read_text(), 'keep')


class Binary(unittest.TestCase):
    def setUp(self):
        if MODULE is None:
            self.skipTest('binary is tested after compilation')
        from elftools.elf.elffile import ELFFile
        self.data = MODULE.read_bytes()
        self.elf = ELFFile(io.BytesIO(self.data))
        self.exports = b.reference()

    def rejected(self, data, message):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'bad.ko'
            path.write_bytes(data)
            with self.assertRaisesRegex(RuntimeError, message):
                b.inspect_module(path, self.exports)

    def test_accept_compiled_binary(self):
        result = b.inspect_module(MODULE, self.exports)
        self.assertGreater(result['checked_crcs'], 1)
        self.assertFalse(result['device_pass'])

    def test_reject_wrong_architecture(self):
        data = bytearray(self.data)
        struct.pack_into('<H', data, 18, 62)  # EM_X86_64, not AArch64.
        self.rejected(data, 'AArch64')

    def test_reject_wrong_release(self):
        section = self.elf.get_section_by_name('.modinfo')
        pos = section['sh_offset'] + section.data().index(b'vermagic=') + len('vermagic=')
        data = bytearray(self.data); data[pos] = ord('9')
        self.rejected(data, 'vermagic')

    def test_reject_wrong_name(self):
        section = self.elf.get_section_by_name('.modinfo')
        pos = section['sh_offset'] + section.data().index(b'name=rmnet_shs') + len('name=')
        data = bytearray(self.data); data[pos] = ord('x')
        self.rejected(data, 'module name')

    def test_reject_actual_rom_layout_crcs(self):
        section = self.elf.get_section_by_name('__versions')
        records = b.parse_versions(section.data())
        pos = section['sh_offset'] + 64*[n for n,c in records].index('module_layout')
        for crc in (0x1e5b7ab7, 0x945d02f2):
            with self.subTest(crc=hex(crc)):
                data = bytearray(self.data); struct.pack_into('<Q', data, pos, crc)
                self.rejected(data, 'module_layout mismatch')

    def test_reject_other_symbol_crc(self):
        section = self.elf.get_section_by_name('__versions')
        records = b.parse_versions(section.data())
        index = next(i for i,(n,c) in enumerate(records) if n != 'module_layout')
        data = bytearray(self.data)
        struct.pack_into('<Q', data, section['sh_offset']+64*index, records[index][1]^1)
        self.rejected(data, 'ABI mismatch')

    def test_reject_missing_cfi_entry(self):
        symbols = self.elf.get_section_by_name('.symtab')
        symbol = next(s for s in symbols.iter_symbols() if s.name == '__cfi_check')
        strings = self.elf.get_section(symbols['sh_link'])
        pos = strings['sh_offset'] + symbol['st_name']
        data = bytearray(self.data); data[pos:pos+11] = b'__bad_check'
        self.rejected(data, 'CFI implementation missing')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--module', type=Path)
    args, remaining = parser.parse_known_args()
    MODULE = args.module
    unittest.main(argv=[sys.argv[0], *remaining], verbosity=2)
