#!/usr/bin/env python3
"""Build one R4-compatible SHS test module, never a replacement kernel.

Reuses the frozen R4 recipe and patches. No source/config/CRC rewriting to
make an incompatible binary load, no ROM edits, and no repository promotion.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO_SHA = '20c142b62b6f39282771b0397ce77748ce6a552a'
CONFIG_SHA = '5904f8d2439e2cb05ef3db7edbe653d269e070b0e28d7e131a44600d61bab229'
SYMVERS_SHA = '6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec'
RELEASE = '5.4.274-qgki-g82179e362f33'
VERMAGIC = RELEASE + ' SMP preempt mod_unload modversions aarch64'
INIT = 'DATARMNET163e93649e'
SHS = 'techpack/datarmnet-ext/shs'


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def shs_inputs(src):
    names = subprocess.check_output(
        ['git', '-C', str(src), 'ls-files', '-z', '--', SHS, 'techpack/datarmnet/core'])
    paths = [n.decode() for n in names.split(b'\0') if n]
    require(paths and SHS+'/rmnet_shs_config.c' in paths, 'missing SHS source inventory')
    return {name: sha(src/name) for name in paths}


def reference():
    require(sha(ROOT/'reference/R4.config') == CONFIG_SHA, 'R4 config drift')
    require(sha(ROOT/'reference/Module.symvers') == SYMVERS_SHA, 'R4 export reference drift')
    rows = {}
    for line in (ROOT/'reference/Module.symvers').read_text().splitlines():
        fields = line.split()
        require(len(fields) >= 4 and fields[2] == 'vmlinux', 'invalid export record')
        crc, name = int(fields[0], 16), fields[1]
        require(name not in rows and 0 <= crc <= 0xffffffff, 'duplicate or invalid export')
        rows[name] = crc
    require(len(rows) == 12947 and rows.get('module_layout') == 0xbff14f69,
            'wrong R4 export identity')
    return rows


def verify_versions(records, imports, exports):
    require(records and len(records) == len(set(n for n, c in records)), 'empty/duplicate versions')
    versions = dict(records)
    require(versions.get('module_layout') == exports['module_layout'], 'module_layout mismatch')
    failures = {name: {'module': hex(crc), 'r4': hex(exports[name]) if name in exports else None}
                for name, crc in records if exports.get(name) != crc}
    require(not failures, 'ABI mismatch: ' + json.dumps(failures, sort_keys=True))
    require(not (set(imports) - set(versions)), 'strong imports without CRC: ' + str(sorted(set(imports) - set(versions))))
    return len(records)


def parse_versions(data):
    require(data and len(data) % 64 == 0, 'malformed AArch64 __versions')
    records = []
    for pos in range(0, len(data), 64):
        crc = struct.unpack_from('<Q', data, pos)[0]
        raw = data[pos+8:pos+64]
        require(b'\0' in raw, 'unterminated version name')
        name, padding = raw.split(b'\0', 1)
        require(not any(padding), 'nonzero version-name padding')
        name = name.decode('ascii')
        require(re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name) is not None, 'invalid version name')
        require(crc <= 0xffffffff, 'CRC exceeds 32 bits')
        records.append((name, crc))
    return records


def inspect_module(path, exports):
    from elftools.elf.elffile import ELFFile
    with Path(path).open('rb') as stream:
        elf = ELFFile(stream)
        require(elf.elfclass == 64 and elf.little_endian and elf['e_machine'] == 'EM_AARCH64'
                and elf['e_type'] == 'ET_REL', 'not an AArch64 ELF module')
        sections = {name: elf.get_section_by_name(name) for name in ('.modinfo', '.symtab', '__versions')}
        require(all(v is not None for v in sections.values()), 'missing module sections')
        info = [s.decode() for s in sections['.modinfo'].data().split(b'\0') if s]
        require([s for s in info if s.startswith('vermagic=')] == ['vermagic='+VERMAGIC], 'module vermagic differs from R4')
        require([s for s in info if s.startswith('name=')] == ['name=rmnet_shs'], 'wrong module name')
        require([s for s in info if s.startswith('depends=')] == ['depends='], 'external dependency not supplied')
        symbols = list(sections['.symtab'].iter_symbols())
        functions = {s.name for s in symbols if s['st_info']['type'] == 'STT_FUNC' and s['st_shndx'] != 'SHN_UNDEF'}
        require(any(re.fullmatch(re.escape(INIT) + r'(?:\$[0-9a-f]{32})?(?:\.cfi)?', n) for n in functions), 'SHS implementation missing')
        require({'init_module', 'cleanup_module', '__cfi_check'} <= functions, 'module init/exit or CFI implementation missing')
        imports = {s.name for s in symbols if s['st_shndx'] == 'SHN_UNDEF' and s.name and s['st_info']['bind'] != 'STB_WEAK'}
        raw = sections['__versions'].data()
        count = verify_versions(parse_versions(raw), imports, exports)
    # Read the section through a second implementation as a transport/parser check.
    dump = subprocess.check_output(['readelf', '-x', '__versions', str(path)], text=True)
    words = []
    for line in dump.splitlines():
        match = re.match(r'\s*0x[0-9a-f]+\s+(.*)', line)
        if match:
            for word in match[1].split()[:4]:
                if not re.fullmatch(r'[0-9a-f]{8}', word):
                    break
                words.append(word)
    require(bytes.fromhex(''.join(words)) == raw, 'readelf section cross-check failed')
    return dict(sha256=sha(path), bytes=Path(path).stat().st_size, name='rmnet_shs',
                vermagic=VERMAGIC, checked_crcs=count, unresolved_strong_imports=[],
                depends=[], cfi=True, init=True, exit=True, readelf_crosscheck=True,
                kernel_build=False, device_pass=False, persistent_install=False)


def run_build(repo, work, public, jobs):
    require(jobs > 0, 'jobs must be positive')
    require(not work.exists() and not public.exists(), 'fresh output directories required')
    require(subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'], text=True).strip() == REPO_SHA,
            'not the reviewed R4 repository commit')
    require(not subprocess.check_output(['git','-C',str(repo),'status','--porcelain'], text=True).strip(), 'dirty base repository')
    reference()
    sys.path.insert(0, str(repo/'common/scripts'))
    import veux_update_engine as e
    import veux_source_transport as transport
    import veux_frozen_components as frozen
    work.mkdir(parents=True)
    try:
        cfg, _ = e.check_repo()
        frozen.load_contract(cfg)
        state = transport.materialize('5.4.274', work)
        finish_build(repo, work, public, jobs, state)
    except Exception as exc:
        (work/'BLOCKED.json').write_text(json.dumps({'reason': str(exc), 'device_pass': False}, indent=2)+'\n')
        raise


def finish_build(repo, work, public, jobs, state):
    """Continue from the authenticated historical build boundary."""
    import veux_update_engine as e
    import veux_release as r
    import veux_frozen_components as frozen
    import veux_device_fixes as fixes
    import veux_rpm_fixes as rpm
    import veux_wakeup_fixes as wakeup
    import veux_config_compat as compat
    exports = reference()
    cfg, _ = e.check_repo()
    lock = frozen.load_contract(cfg)
    require(state['recipe'] == cfg['lineages']['5.4.274'], 'source recipe differs from R4')
    src = Path(state['source'])
    require(src == work/'source-work/kernel', 'source outside authenticated build workspace')
    # R4 used the frozen resolver when CURRENT_BUILD described other
    # commits. Reproduce that exact path; never resolve upstream HEADs.
    targets = {'components': lock['components']}
    if not r.replay_current(src, '5.4.274', targets):
        bundle = work/'frozen-components'
        targets = frozen.resolve(bundle)
        require(targets['components'] == lock['components'], 'frozen target drift')
        e.apply_update(src, state, bundle, work)
    proofs = []
    for module in (fixes, rpm, wakeup):
        proof = module.apply(src, '5.4.274', work)
        module.verify_source(src, '5.4.274', proof)
        proofs.append((module, proof))
    audit = compat._load_audit()
    source_proof = audit.apply(src)
    e.write_json(work/'SOURCE-PATCH.json', source_proof)
    inputs = shs_inputs(src)
    out = work/'build'
    out.mkdir()
    shutil.copy2(ROOT/'reference/R4.config', out/'.config')
    values = dict(v.split('=', 1) for v in state['variables'])
    require('O' in values, 'missing explicit build directory')
    values['O'] = str(out)
    env = dict(os.environ, **state['env'])
    env.pop('VEUX_CAPTURE', None)
    env['PATH'] = os.pathsep.join(p for p in env['PATH'].split(os.pathsep)
                                  if p != str(work/'source-temp/bin'))
    base = ['/usr/bin/make', '-C', str(src), *[f'{k}={v}' for k,v in values.items()]]
    e.run([*base, 'olddefconfig'], env=env, log=work/'configure.log')
    require(sha(out/'.config') == CONFIG_SHA, 'olddefconfig changed R4 configuration')
    e.run([*base, f'-j{jobs}', 'modules_prepare'], env=env, log=work/'prepare.log')
    require(sha(out/'.config') == CONFIG_SHA, 'modules_prepare changed R4 configuration')
    release = e.run([*base, '-s', 'kernelrelease'], env=env).splitlines()[-1]
    require(release == RELEASE, 'prepared kernel release does not match R4: '+release)
    shutil.copy2(ROOT/'reference/Module.symvers', out/'Module.symvers')
    # Build the unchanged external-module target with the existing core's
    # headers and symbol versions. Override its obsolete sibling symvers path.
    command = [*base, f'-j{jobs}', 'M='+str(src/SHS),
               'RMNET_CORE_INC_DIR='+str(src/'techpack/datarmnet/core'),
               'KBUILD_EXTRA_SYMBOLS=', 'modules']
    e.run(command, env=env, log=work/'shs-compile.log', timeout=1200)
    require(sha(out/'.config') == CONFIG_SHA, 'module build changed R4 configuration')
    require(sha(out/'Module.symvers') == SYMVERS_SHA, 'module build changed R4 exports')
    for module, proof in proofs:
        module.verify_source(src, '5.4.274', proof)
    require(shs_inputs(src) == inputs, 'SHS/core source changed during build')
    require(not (out/'vmlinux').exists() and not (out/'arch/arm64/boot/Image').exists(),
            'unexpected full kernel output')
    ko = src/SHS/'rmnet_shs.ko'
    result = inspect_module(ko, exports)
    protected = []
    for name in inputs:
        if name.startswith(SHS+'/') and name.endswith('.c'):
            unit = Path(name).stem
            cmd = (src/SHS/('.'+unit+'.o.cmd')).read_text()
            require('-fsanitize=cfi' in cmd and '-flto=thin' in cmd
                    and '-fstack-protector-strong' in cmd,
                    'SHS compile protections not proven: '+unit)
            protected.append(unit)
    require(len(protected) == 8, 'unexpected SHS translation units')
    result.update(repository_sha=REPO_SHA, reference_run=37355658904,
                  config_sha256=CONFIG_SHA, export_reference_sha256=SYMVERS_SHA,
                  targets=lock['components'], source_patch=source_proof,
                  source_files_sha256=inputs,
                  compiler_sha256=sha(shutil.which('clang', path=env['PATH'])),
                  protected_translation_units=sorted(protected),
                  make_variables=values,
                  warning_lines=[l for l in (work/'shs-compile.log').read_text().splitlines() if 'warning:' in l])
    # Warnings need review before a test candidate is published.
    require(not result['warning_lines'], 'SHS compile warnings require review')
    public.mkdir(parents=True)
    shutil.copy2(ko, public/'rmnet_shs_R4_test.ko')
    e.write_json(public/'SHS-BUILD.json', result)
    (public/'NICHT_FLASHEN.txt').write_text(
        'Dies ist ein SHS-Testmodul fuer den unveraenderten VEUX R4, kein Kernel und kein Flash-ZIP.\n'
        'Noch nicht auf dem Geraet laden. Zuerst den Run und das Modul pruefen lassen.\n'
        'Kein automatischer Start, keine ROM-Aenderung, keine dauerhafte Installation.\n')
    (public/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(public.iterdir())))
    e.write_json(work/'RESULT.json', result)
    print('SHS_MODULE_BUILD=PASS; KERNEL_BUILD=NOT_RUN; DEVICE_PASS=NO', flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--work', type=Path, required=True)
    p.add_argument('--public', type=Path, required=True)
    p.add_argument('--jobs', type=int, default=4)
    args = p.parse_args()
    try:
        run_build(args.repo.resolve(), args.work.resolve(), args.public.resolve(), args.jobs)
    except Exception as exc:
        print('BLOCKED: '+str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
