VEUX SHS R1 – Modulbuild für den bereits geflashten R4

Zweck
Der Build erstellt ausschließlich rmnet_shs.ko passend zum R4 aus
Run 37355658904. Er baut keinen neuen Kernel und installiert nichts auf
dem Handy. Die vollständige R4-Quellrekonstruktion und der alte Compiler
werden trotzdem benötigt; der erste Lauf kann daher länger dauern.

Dateien hochladen
1. VEUX_SHS_Modul_R1.zip unverändert ins Hauptverzeichnis von main legen.
2. VEUX_SHS_Modul_R1.yml in .github/workflows/ legen.
3. Unter Actions „VEUX SHS R1 - passendes Testmodul ohne Kernelneubau“
   manuell starten. Der Workflow startet nicht automatisch beim Upload.

Was der Lauf tut
- Prüft ZIP und Dateihashes, dann die mitgelieferten negativen ABI-Tests.
- Verwendet den exakten Repo-Stand des R4; keine neuen Upstream-Versionen.
- Holt bei abweichendem Repo-Snapshot ausschließlich die im R4-Vertrag
  festgeschriebenen Komponenten-Commits und prüft deren Herkunft/Version.
- Rekonstruiert die eingefrorenen Quellen einschließlich bestehender
  Lade-, WT-, RPM-, Wakeup- und Konfigurationskorrekturen.
- Bereitet exakt dieselbe Konfiguration vor und baut nur SHS als Modul.
- Verlangt unveränderte R4-Konfiguration und unveränderte Export-Referenz.
- Prüft AArch64-ELF, Kernelkennung, alle Modul-Symbol-CRCs, starke Imports,
  tatsächliche SHS-Initialisierung, Aufräumfunktion sowie CFI/ThinLTO und
  Stack-Protector. Unbekannte Warnungen blockieren die Bereitstellung.
- Vergleicht die __versions-Sektion zusätzlich über GNU readelf.
- Prüft nach dem Build die echte ELF-Datei und gezielt beschädigte Kopien:
  falsche Architektur, Kernelkennung, Modulname, CRCs und fehlendes CFI.

Ergebnis
Bei Erfolg erscheint ein ausdrücklich als Testmodul benanntes Artefakt.
Es enthält keinen Kernel und ist nicht flashbar. Zuerst den Run-Link
zur Prüfung schicken. Der Gerätetest und die spätere dauerhafte Einbindung
sind eigene Schritte. Noch keine automatische Modul-Ladung oder Bootänderung.

Die ROM-Ein-/Ausschaltregeln für SHS bleiben Gegenstand der Einbindung.
Durch den Modulbuild wird SHS nicht pauschal dauerhaft eingeschaltet.
Offload bleibt separat offen und wird in diesem Schritt nicht aktiviert.

Bestehende sechs Kernel-Linien und V4-Updater werden nicht geändert.
Keine Commits, Pushes, Releases, Bereinigungen oder Gerätezugriffe.
Diagnoseartefakte werden ausschließlich bei einem Fehlschlag hochgeladen.
Ein erfolgreicher Host-/CI-Build ist kein DEVICE PASS.

Referenzen
R4 Repo: 20c142b62b6f39282771b0397ce77748ce6a552a
R4 Image: f25157822979c464ad857aeab9472d799f122b807d7be58f9d18a8e64b092eea
R4 Config: 5904f8d2439e2cb05ef3db7edbe653d269e070b0e28d7e131a44600d61bab229
Module.symvers: 6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec
Die 12947 Exportnamen und CRCs dieser Referenz wurden zuvor direkt gegen
das ausgelieferte R4-Image geprüft; sie werden nicht aus der ROM übernommen.

Lokaler Nachweis vom 06.10.2026
Der vollständige Ablauf wurde aus einem frischen temporären Quellverzeichnis
mit dem fertigen Buildskript erfolgreich ausgeführt. Das Modul kompiliert
ohne Warnungen. Alle 100 Symbolversionen passen zur R4-Exportreferenz.
23 ABI-/ELF-Prüfungen einschließlich beschädigter Moduldateien bestehen.
YAML, Shellsyntax, verwendete Action-Eingaben und acht ZIP-Fälle wurden geprüft.
Details stehen in LOKALER_BUILDNACHWEIS.json. Kein GitHub- oder Geräte-PASS.
