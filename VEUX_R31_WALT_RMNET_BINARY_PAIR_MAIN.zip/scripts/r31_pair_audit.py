#!/usr/bin/env python3
"""VEUX R31: read-only reproducible Module.symvers/ELF provenance gate.

Requires only stdlib. Writes diagnostics to an output directory. NEVER builds or flashes.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import struct
import zipfile

APPROVED_FILES = {
    'evidence/DWARF_COMPARE.json',
    'evidence/R22_DEVICE_IKCONFIG.txt',
    'evidence/R20_Module.symvers',
    'evidence/R20_BUILD_RESULT.json',
    'modules/r20/rmnet_shs.ko',
    'modules/r20/rmnet_offload.ko',
    'modules/device_2ef0/rmnet_shs.ko',
    'modules/device_2ef0/rmnet_offload.ko',
    'scripts/r31_pair_audit.py',
    'tests/test_r31.py',
    'tools/actionlint',
    'source_links.txt',
    'README_ZUERST_DE.txt',
    'MANIFEST_SHA256.json',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read_manifest(bundle):
    metadata = json.loads((bundle/'MANIFEST_SHA256.json').read_text(encoding='utf-8'))
    assert metadata['schema'] == 'VEUX_R31_PINNED_INPUT_V1'
    listed = set(metadata['files']) | {'MANIFEST_SHA256.json'}
    present = {p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file()}
    if listed != present or present != APPROVED_FILES:
        raise ValueError(f'INVALID_PACKAGE_FILE_SET:missing={sorted(APPROVED_FILES-present)} extra={sorted(present-APPROVED_FILES)}')
    for name, properties in sorted(metadata['files'].items()):
        p = bundle/name
        if p.is_symlink() or not p.is_file():
            raise ValueError('SYMLINK_OR_MISSING_FILE:' + name)
        data = p.read_bytes()
        if len(data) != properties['bytes'] or sha(data) != properties['sha256']:
            raise ValueError('PACKAGE_INPUT_HASH_MISMATCH:' + name)
    return metadata


def safe_extract(archive, target):
    archive = Path(archive)
    target = Path(target)
    with zipfile.ZipFile(archive) as z:
        members = z.infolist()
        names = [m.filename for m in members if not m.is_dir()]
        if len(names) != len(set(names)) or set(names) != APPROVED_FILES:
            raise ValueError('UNEXPECTED_OR_DUPLICATE_ZIP_FILES')
        total = 0
        for m in members:
            p = PurePosixPath(m.filename)
            if p.is_absolute() or not p.parts or any(q in ('..','.') for q in p.parts) or '\\' in m.filename:
                raise ValueError('ZIP_PATH_TRAVERSAL')
            mode = (m.external_attr >> 16)
            if stat.S_ISLNK(mode):
                raise ValueError('ZIP_SYMLINK_FORBIDDEN')
            if m.file_size > 16_000_000:
                raise ValueError('ZIP_MEMBER_OVERSIZE')
            total += m.file_size
            if total > 32_000_000:
                raise ValueError('ZIP_UNCOMPRESSED_OVERSIZE')
        for m in members:
            if m.is_dir():
                continue
            dest = target / m.filename
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_bytes(z.read(m))
    return read_manifest(target)


def parse_elf_module(blob):
    if blob[:4] != b'\x7fELF' or len(blob) < 64 or blob[4] != 2 or blob[5] != 1:
        raise ValueError('NOT_ELF64_LITTLE_ENDIAN')
    if struct.unpack_from('<H',blob,18)[0] != 183:
        raise ValueError('NOT_AARCH64')
    e_shoff=struct.unpack_from('<Q',blob,40)[0]
    shentsize=struct.unpack_from('<H',blob,58)[0]
    shnum=struct.unpack_from('<H',blob,60)[0]
    shstrndx=struct.unpack_from('<H',blob,62)[0]
    if shentsize!=64 or not(0 < shnum < 2000) or not (0<=shstrndx<shnum) or e_shoff+shnum*shentsize>len(blob):
        raise ValueError('INVALID_ELF_SECTION_HEADERS')
    entries=[]
    for n in range(shnum):
        h=struct.unpack_from('<IIQQQQIIQQ',blob,e_shoff+n*shentsize)
        name,type_,flags,addr,offset,size,link,info,align,ent=h
        if offset+size > len(blob) and type_!=8:
            raise ValueError('ELF_SECTION_OUTSIDE_FILE')
        entries.append((name,offset,size,type_))
    n,off,size,_=entries[shstrndx]
    strtab=blob[off:off+size]
    sections={}
    for index,off,size,type_ in entries:
        end=strtab.find(b'\x00',index)
        if end==-1:
            raise ValueError('ELF_SECTION_NAME_NOT_TERMINATED')
        name=strtab[index:end].decode('ascii','strict')
        if name in sections:
            raise ValueError('DUPLICATE_SECTION_NAME')
        sections[name]=blob[off:off+size] if type_!=8 else b''
    for name in ('__versions','.modinfo','.note.gnu.build-id'):
        if name not in sections:
            raise ValueError('MISSING_ELF_SECTION:'+name)
    raw=sections['__versions']
    if len(raw)%64 or not raw:
        raise ValueError('INVALID_VERSIONS_SIZE')
    versions={}
    for i in range(0,len(raw),64):
        b=raw[i:i+64]
        name=b[8:].split(b'\x00',1)[0].decode('ascii','strict')
        if not name or name in versions:
            raise ValueError('INVALID_OR_DUPLICATE_IMPORT')
        versions[name]=struct.unpack_from('<I',b,0)[0]
    props={}
    for v in sections['.modinfo'].split(b'\x00'):
        if b'=' in v:
            key,value=v.split(b'=',1)
            props[key.decode('ascii','strict')]=value.decode('utf-8','replace')
    note=sections['.note.gnu.build-id']
    if len(note) < 16:
        raise ValueError('INVALID_BUILD_ID_NOTE')
    name_len,desc_len,note_type=struct.unpack_from('<III',note,0)
    off=12+((name_len+3)//4)*4
    if note[12:12+name_len]!=b'GNU\0' or note_type!=3 or not(4<=desc_len<=64) or off+desc_len>len(note):
        raise ValueError('INVALID_GNU_BUILD_ID')
    return {'imports':versions,'vermagic':props.get('vermagic',''),
            'name':props.get('name',''),'build_id':note[off:off+desc_len].hex(),
            'elf_machine':'EM_AARCH64'}


def symvers_database(s):
    db={}
    for line in s.splitlines():
        fields=line.split('\t')
        if len(fields)<4:
            raise ValueError('BAD_MODULE_SYMVERS_ROW')
        crc,name,origin,export_type=fields[:4]
        value=int(crc,16)
        if name in db and db[name]!=value:
            raise ValueError('MULTIPLE_DIFFERENT_CRC_FOR_SYMBOL:'+name)
        db[name]=value
    if len(db)<10000:
        raise ValueError('TOO_FEW_KERNEL_EXPORTS')
    return db


def compare(imports,db):
    return [{'symbol':n,'module_crc':'0x%08x'%crc,
             'kernel_crc': '0x%08x'%db[n] if n in db else '',
             'status': ('missing_export' if n not in db else ('matching_crc' if crc==db[n] else 'crc_mismatch'))}
            for n,crc in sorted(imports.items())]


def read_kernel_flag(config,key):
    t=f'{key}='
    return next((line[len(t):] for line in config.splitlines() if line.startswith(t)),
                'n' if f'# {key} is not set' in config else 'not_recorded')


def analyze(bundle,out):
    bundle=Path(bundle)
    out=Path(out)
    read_manifest(bundle)
    report=json.loads((bundle/'evidence/R20_BUILD_RESULT.json').read_text())
    if not (report['full_image_proven'] and report['modules_built'] and report['vmlinux_linked']):
        raise ValueError('R20_FULL_BUILD_NOT_PROVEN')
    if report['flash_allowed'] is not False or report['brene_changed'] is not False:
        raise ValueError('UNSAFE_BUILD_PROVENANCE')
    symvers=(bundle/'evidence/R20_Module.symvers').read_bytes()
    if sha(symvers)!=report['module_symvers_sha256']:
        raise ValueError('R20_SYMVERS_NOT_FROM_ATTESTED_BUILD')
    db=symvers_database(symvers.decode('utf8'))
    expected_mod={m['path'].rsplit('/',1)[-1]:m for m in report['module_files']}
    details={}
    comparisons=[]
    all_r20=0
    for mod in ('rmnet_shs','rmnet_offload'):
        this={}
        for family,directory in [('WALT_R20','r20'),('DEVICE_2EF0','device_2ef0')]:
            file=bundle/'modules'/directory/(mod+'.ko')
            blob=file.read_bytes()
            meta=parse_elf_module(blob)
            if meta['name']!=mod:
                raise ValueError('MODULE_NAME_MISMATCH')
            if family=='WALT_R20':
                ref=expected_mod.get(mod+'.ko')
                if ref is None or sha(blob)!=ref['sha256'] or len(blob)!=ref['bytes']:
                    raise ValueError('MODULE_DOES_NOT_MATCH_R20_BUILD_RESULT:'+mod)
                if not meta['vermagic'].startswith('5.4.274~positron '):
                    raise ValueError('INCORRECT_R20_VERMAGIC')
            else:
                if not meta['vermagic'].startswith('5.4.274-qgki-g82179e362f33 '):
                    raise ValueError('INCORRECT_DEVICE_VERMAGIC')
            rows=compare(meta['imports'],db)
            for r in rows:
                comparisons.append(dict(module=mod,family=family,**r))
            statuses={status:sum(r['status']==status for r in rows) for status in ('matching_crc','crc_mismatch','missing_export')}
            if family=='WALT_R20':
                if statuses['matching_crc']!=len(rows) or statuses['crc_mismatch'] or statuses['missing_export']:
                    raise ValueError('REBUILT_MODULE_IMPORT_CRC_MISMATCH:'+mod)
                if meta['imports'].get('module_layout')!=db.get('module_layout'):
                    raise ValueError('R20_MODULE_LAYOUT_CRC_MISMATCH')
                all_r20+=len(rows)
            else:
                if meta['imports'].get('module_layout')==db.get('module_layout'):
                    raise ValueError('LEGACY_MODULE_LAYOUT_UNEXPECTEDLY_MATCHES')
            this[family]={'file_sha256':sha(blob),'file_bytes':len(blob),'build_id':meta['build_id'],
                          'vermagic':meta['vermagic'],'import_count':len(rows),
                          'symbol_matches':statuses['matching_crc'],
                          'crc_mismatches':statuses['crc_mismatch'],
                          'missing_exports':statuses['missing_export'],
                          'module_layout_crc': '0x%08x'%meta['imports']['module_layout']}
        details[mod]=this
    if all_r20 != 140:
        raise ValueError('NOT_140_R20_IMPORTS')
    device_config=(bundle/'evidence/R22_DEVICE_IKCONFIG.txt').read_text(errors='replace')
    flag_names=['CONFIG_PREEMPTION','CONFIG_DEBUG_PREEMPT','CONFIG_ANDROID_KABI_RESERVE','CONFIG_ANDROID_VENDOR_OEM_DATA',
                'CONFIG_SCHED_CASS','CONFIG_SCHED_WALT','CONFIG_MODVERSIONS','CONFIG_FTRACE','CONFIG_TRACING','CONFIG_EVENT_TRACING']
    flags={key:read_kernel_flag(device_config,key) for key in flag_names}
    if flags['CONFIG_DEBUG_PREEMPT']!='y' or flags['CONFIG_ANDROID_KABI_RESERVE']!='n' or flags['CONFIG_SCHED_CASS']!='y':
        raise ValueError('DEVICE_CONFIG_DOES_NOT_MATCH_EXPECTED_GUARDS')
    dwarf=json.loads((bundle/'evidence/DWARF_COMPARE.json').read_text())
    expected={'sk_buff':(232,240),'net_device':(2176,2432),'timer_list':(40,56),
              'work_struct':(32,48),'hrtimer':(64,72),'task_struct':(3008,3776),'module':(768,896)}
    dwarf_summary=[]
    for name,(original,r20) in expected.items():
        key='shs:'+name
        if key not in dwarf:raise ValueError('DWARF_EVIDENCE_MISSING:'+key)
        legacy=dwarf[key]['original']['size_matches'];new=dwarf[key]['r20']['size_matches']
        if str(original) not in legacy or str(r20) not in new:
            raise ValueError('DWARF_SIZE_GATE_FAILED:'+name)
        dwarf_summary.append({'structure':name,'2ef0_size_bytes':original,'r20_size_bytes':r20})
    output={'schema':'VEUX_R31_WALT_RMNET_PAIR_GATE_V1','status':'SOURCE_BINARY_PAIR_CRC_PROVEN_NO_FLASH',
            'r20_build_attestation':'AUTHENTICATED','r20_image_sha256_attested_not_rechecked':report['image']['sha256'],
            'r20_symvers_sha256':sha(symvers),'r20_export_count':len(db),'r20_rebuilt_module_total_imports':all_r20,
            'r20_rebuilt_modules_matching_imports':all_r20,'modules':details,'device_config':flags,
            'dwarf_struct_sizes':dwarf_summary,
            'precise_conclusion':'The R20 rebuilt RMNET pair has no CRC mismatches with its attested R20 symvers; old 2EF0 modules do. This is not a boot/flash or device ABI approval.',
            'blocking': ['R20 module vermagic is 5.4.274~positron, not the running device stock identifier.',
                         'R20 image+DTB and device boot/vendor ABI not validated by this source-only audit.',
                         'Device loader selects the 2EF0 module pair keyed by the running kernel notes; no new loader payload is deployed.',
                         'WALT/CASS structural and runtime behavior still need careful device compatibility review.'],
            'kernel_built':False,'kernel_or_module_installed':False,'flash_allowed':False,'repo_mutated':False,'brene_changed':False}
    out.mkdir(parents=True,exist_ok=True)
    (out/'R31_RESULT.json').write_text(json.dumps(output,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    with (out/'R31_IMPORT_PROOF.csv').open('w',encoding='utf-8',newline='') as f:
        cols=['module','family','symbol','module_crc','kernel_crc','status']
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(comparisons)
    with (out/'R31_TYPE_COMPARISON.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['structure','2ef0_size_bytes','r20_size_bytes']);w.writeheader();w.writerows(dwarf_summary)
    (out/'R31_SUMMARY_DE.txt').write_text(
        'VEUX R31 – R20 passend gebaute RMNET-Module\n'
        'Verifizierte R20-Module: rmnet_shs 108/108, rmnet_offload 32/32 Symbolimporte passend.\n'
        'Das ältere 2EF0-Paar erwartet eine andere Kernel-ABI.\n'
        'R20 verwendet vermagic 5.4.274~positron, das derzeit laufende Gerät 5.4.274-qgki-g82179e362f33.\n'
        'Die strukturellen Unterschiede bei WALT und den Android-KABI-Feldern sind durch DWARF belegt.\n'
        'Kein Kernel gebaut, kein Flashimage erzeugt, keine Installer-/Bootdateien verändert.\n'
        'Vendor-ABI, Runtime-Kompatibilität und Boot-Freigabe bleiben OFFEN.\n',encoding='utf-8')
    output_files=[p for p in out.iterdir() if p.is_file()]
    (out/'R31_SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in sorted(output_files)),encoding='utf-8')
    print('R31_BINARY_PAIR_PROOF=PASS; R20_RMNET_CRC=140/140; ORIGINAL_2EF0_CRC_MISMATCH=CONFIRMED; SOURCE_PATCH=NO; FLASH=NO')
    return output


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--bundle',required=True)
    p.add_argument('--out',required=True)
    a=p.parse_args()
    analyze(a.bundle,a.out)

if __name__=='__main__':
    main()
