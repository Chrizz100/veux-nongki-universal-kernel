#!/usr/bin/env python3
"""Unit and adversarial tests for VEUX R31 read-only ABI gate."""
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import stat
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

SCRIPT=Path(__file__).resolve().parents[1]/'scripts'/'r31_pair_audit.py'
SPEC=importlib.util.spec_from_file_location('r31_pair_audit',SCRIPT)
r31=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(r31)
BUNDLE=SCRIPT.parents[1]


class TestCore(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r20=(BUNDLE/'modules/r20/rmnet_shs.ko').read_bytes()
        cls.old=(BUNDLE/'modules/device_2ef0/rmnet_shs.ko').read_bytes()

    def test_a_manifest_integrity(self):
        self.assertEqual(len(r31.read_manifest(BUNDLE)['files']),len(r31.APPROVED_FILES)-1)

    def test_real_r20_is_arm64(self):
        self.assertEqual(r31.parse_elf_module(self.r20)['elf_machine'],'EM_AARCH64')

    def test_real_r20_modinfo(self):
        m=r31.parse_elf_module(self.r20)
        self.assertEqual(m['name'],'rmnet_shs')
        self.assertTrue(m['vermagic'].startswith('5.4.274~positron '))

    def test_real_legacy_modinfo(self):
        m=r31.parse_elf_module(self.old)
        self.assertEqual(m['build_id'],'52967b0490abea75')
        self.assertTrue(m['vermagic'].startswith('5.4.274-qgki-g82179e362f33 '))

    def test_r20_symvers_matches_module_layout(self):
        db=r31.symvers_database((BUNDLE/'evidence/R20_Module.symvers').read_text())
        m=r31.parse_elf_module(self.r20)
        self.assertEqual(m['imports']['module_layout'],db['module_layout'])

    def test_r20_symvers_matches_all_shs_imports(self):
        db=r31.symvers_database((BUNDLE/'evidence/R20_Module.symvers').read_text())
        rows=r31.compare(r31.parse_elf_module(self.r20)['imports'],db)
        self.assertEqual(len(rows),108)
        self.assertTrue(all(x['status']=='matching_crc' for x in rows))

    def test_r20_symvers_matches_all_offload_imports(self):
        db=r31.symvers_database((BUNDLE/'evidence/R20_Module.symvers').read_text())
        m=r31.parse_elf_module((BUNDLE/'modules/r20/rmnet_offload.ko').read_bytes())
        self.assertEqual(len(m['imports']),32)
        self.assertTrue(all(x['status']=='matching_crc' for x in r31.compare(m['imports'],db)))

    def test_legacy_still_crc_incompatible(self):
        db=r31.symvers_database((BUNDLE/'evidence/R20_Module.symvers').read_text())
        rows=r31.compare(r31.parse_elf_module(self.old)['imports'],db)
        self.assertEqual(len(rows),100)
        self.assertTrue(any(x['status']=='crc_mismatch' for x in rows))
        self.assertTrue(any(x['status']=='missing_export' for x in rows))

    def test_valid_build_original(self):
        report=json.loads((BUNDLE/'evidence/R20_BUILD_RESULT.json').read_text())
        self.assertFalse(report['flash_allowed'])
        self.assertFalse(report['brene_changed'])
        self.assertEqual(report['module_symvers_sha256'],r31.sha((BUNDLE/'evidence/R20_Module.symvers').read_bytes()))

    def test_device_preempt_flag(self):
        cfg=(BUNDLE/'evidence/R22_DEVICE_IKCONFIG.txt').read_text()
        self.assertEqual(r31.read_kernel_flag(cfg,'CONFIG_DEBUG_PREEMPT'),'y')

    def test_device_kabi_flag(self):
        cfg=(BUNDLE/'evidence/R22_DEVICE_IKCONFIG.txt').read_text()
        self.assertEqual(r31.read_kernel_flag(cfg,'CONFIG_ANDROID_KABI_RESERVE'),'n')

    def test_device_cass_flag(self):
        cfg=(BUNDLE/'evidence/R22_DEVICE_IKCONFIG.txt').read_text()
        self.assertEqual(r31.read_kernel_flag(cfg,'CONFIG_SCHED_CASS'),'y')

    def test_device_missing_flag(self):
        cfg=(BUNDLE/'evidence/R22_DEVICE_IKCONFIG.txt').read_text()
        self.assertEqual(r31.read_kernel_flag(cfg,'CONFIG_HYPOTHETICAL_GARBAGE_FLAG'),'not_recorded')

    def test_invalid_magic(self):
        with self.assertRaisesRegex(ValueError,'NOT_ELF64'):
            r31.parse_elf_module(b'XXXX'+self.r20[4:])

    def test_invalid_class(self):
        bad=bytearray(self.r20);bad[4]=1
        with self.assertRaisesRegex(ValueError,'NOT_ELF64'):
            r31.parse_elf_module(bad)

    def test_invalid_endian(self):
        bad=bytearray(self.r20);bad[5]=2
        with self.assertRaisesRegex(ValueError,'NOT_ELF64'):
            r31.parse_elf_module(bad)

    def test_invalid_arch(self):
        bad=bytearray(self.r20);struct.pack_into('<H',bad,18,62)
        with self.assertRaisesRegex(ValueError,'NOT_AARCH64'):
            r31.parse_elf_module(bad)

    def test_invalid_header_offset(self):
        bad=bytearray(self.r20);struct.pack_into('<Q',bad,40,len(bad)-64)
        with self.assertRaisesRegex(ValueError,'INVALID_ELF_SECTION_HEADERS'):
            r31.parse_elf_module(bad)

    def test_bad_symvers(self):
        with self.assertRaisesRegex(ValueError,'BAD_MODULE_SYMVERS_ROW'):
            r31.symvers_database('invalid\n')

    def test_too_few_symvers(self):
        with self.assertRaisesRegex(ValueError,'TOO_FEW'):
            r31.symvers_database('0x01\tfoo\tfoo.o\tEXPORT_SYMBOL\n')

    def test_conflicting_symvers(self):
        with self.assertRaisesRegex(ValueError,'MULTIPLE_DIFFERENT_CRC'):
            r31.symvers_database('0x01\tfoo\ta\tEXPORT_SYMBOL\n0x02\tfoo\ta\tEXPORT_SYMBOL\n')

    def test_compare_matching_missing_mismatch(self):
        rows=r31.compare({'a':1,'b':2,'c':3},{'a':1,'b':17})
        self.assertEqual([x['status'] for x in rows],['matching_crc','crc_mismatch','missing_export'])

    def test_full_readonly_run(self):
        with tempfile.TemporaryDirectory() as d:
            out=r31.analyze(BUNDLE,d)
            self.assertEqual(out['r20_rebuilt_modules_matching_imports'],140)
            self.assertFalse(out['flash_allowed'])
            self.assertFalse(out['repo_mutated'])
            self.assertFalse(out['kernel_built'])
            self.assertTrue((Path(d)/'R31_IMPORT_PROOF.csv').is_file())
            self.assertTrue((Path(d)/'R31_SHA256SUMS.txt').is_file())

    def test_no_new_image_created(self):
        with tempfile.TemporaryDirectory() as d:
            r31.analyze(BUNDLE,d)
            self.assertFalse(any(p.suffix in ('.img','.ko') for p in Path(d).iterdir()))

    def test_evidence_is_complete(self):
        with tempfile.TemporaryDirectory() as d:
            r31.analyze(BUNDLE,d)
            m=json.loads((Path(d)/'R31_RESULT.json').read_text())
            self.assertEqual(len(m['dwarf_struct_sizes']),7)
            self.assertEqual(m['modules']['rmnet_shs']['WALT_R20']['import_count'],108)
            self.assertEqual(m['modules']['rmnet_offload']['WALT_R20']['import_count'],32)

    def test_zip_wrong_set_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('other.txt','x')
            with self.assertRaisesRegex(ValueError,'UNEXPECTED_OR_DUPLICATE'):
                r31.safe_extract(p,Path(d)/'out')

    def test_zip_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.zip'
            with zipfile.ZipFile(p,'w') as z:
                for name in sorted(r31.APPROVED_FILES): z.writestr(name,'x')
                with __import__('warnings').catch_warnings():
                    __import__('warnings').simplefilter('ignore')
                    z.writestr('source_links.txt','x')
            with self.assertRaisesRegex(ValueError,'UNEXPECTED_OR_DUPLICATE'):
                r31.safe_extract(p,Path(d)/'out')

    def test_zip_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'a.zip'
            with zipfile.ZipFile(p,'w') as z:
                for name in sorted(r31.APPROVED_FILES):
                    x=zipfile.ZipInfo(name)
                    x.create_system=3
                    x.external_attr=((stat.S_IFLNK|0o777) if name=='source_links.txt' else (stat.S_IFREG|0o644))<<16
                    z.writestr(x,'x')
            with self.assertRaisesRegex(ValueError,'ZIP_SYMLINK_FORBIDDEN'):
                r31.safe_extract(p,Path(d)/'out')

    def test_manifest_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'b'
            shutil.copytree(BUNDLE,root)
            with (root/'source_links.txt').open('a') as f:f.write('ATTACK')
            with self.assertRaisesRegex(ValueError,'PACKAGE_INPUT_HASH_MISMATCH'):
                r31.read_manifest(root)

    def test_report_source_guard_blocks_without_trusted_hash(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'b'
            shutil.copytree(BUNDLE,root)
            (root/'evidence/R20_Module.symvers').write_text('0x1\ta\ta.o\tEXPORT_SYMBOL\n')
            with self.assertRaisesRegex(ValueError,'PACKAGE_INPUT_HASH_MISMATCH'):
                r31.analyze(root,Path(d)/'out')


if __name__=='__main__':
    unittest.main()
