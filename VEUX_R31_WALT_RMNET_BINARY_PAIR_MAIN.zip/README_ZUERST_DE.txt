VEUX R31 – ABI-Herkunft: korrekt zusammengehöriges R20-RMNET-Modulpaar
=======================================================================

Zweck:
 - Die alten geladenen 2EF0-RMNET-Module sind binär für den auf dem Gerät
   laufenden 5.4.274-qgki-Kernel gebaut.
 - R20-R11 hat den WALT-Kernel und die RMNET-Module gemeinsam kompiliert.
 - R31 beweist aus Originalbytes und der originalen R20-Build-Attestation,
   dass die beiden neu gebauten Module alle 140 Kernel-Imports mit der
   dazugehörigen R20-Module.symvers-Datei CRC-identisch auflösen.
 - Zusätzlich werden die 2EF0-Altdaten und DWARF-Strukturunterschiede belegt.

Bewiesene Fakten:
 * R20 rmnet_shs: 108/108 Kernel-Importe CRC-passend.
 * R20 rmnet_offload: 32/32 Kernel-Importe CRC-passend.
 * R20-Modulvermagic: 5.4.274~positron.
 * Installierter Kernel: 5.4.274-qgki-g82179e362f33 (andere Kennung).
 * Alter 2EF0-Modulsatz: anderer module_layout-Wert und fehlende CRC-Passung.
 * R20 bleibt exakt unveraendert, kein BReNE-Eingriff.

Kritische Grenze:
 Dies ist eine Quell-/Binaer-Provenance- und ABI-intern-Pruefung, keine
 ROM-/Boot-/Runtime-Kompatibilitaets- oder Flashfreigabe.
 Es ist KEIN AnyKernel3 und KEIN Installer. .ko-Dateien NICHT auf dem
 laufenden Stock-Kernel installieren; die neue Kennung und ABI sind anders.
 Der Image-Hash stammt aus dem Buildbericht und wird hier NICHT gegen
 eigene Image-Bytes erneut geprueft, da bewusst KEIN Image mitgeliefert wird.

GitHub:
 1. VEUX_R31_WALT_RMNET_BINARY_PAIR_MAIN.zip in das Repo-Root (main) laden.
 2. VEUX_R31_WALT_RMNET_BINARY_PAIR_GATE.yml in .github/workflows/ laden.
 3. GitHub Actions => VEUX R31 - WALT/RMNET Binary Pair ... => Run workflow.
 4. Ergebnisartefakt VEUX-R31-ABI-PAIR-PROOF-<runid> pruefen.

Sicherheit: Der Workflow liest Dateien nur, erzeugt keine Boot-Image-/Flash-ZIP,
fasst keine Partitionen an und veraendert weder BReNE noch das Repository.
