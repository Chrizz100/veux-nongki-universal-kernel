import unittest, pathlib, subprocess, re, os
from collections import Counter
import yaml
R=pathlib.Path(__file__).resolve().parents[1]
D=pathlib.Path(os.environ.get('R45_WORKFLOW', str(R/'VEUX_R46_R2_WALT_SOURCE_PROVENANCE_FIX_NOFLASH.yml')))
ORIG=R/'References'/'ORIGINAL_R44_R2_WORKFLOW.yml'
class WorkflowIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw=D.read_text()
        cls.o=ORIG.read_text()
        cls.d=yaml.safe_load(cls.raw)
        cls.job=cls.d['jobs']['p11-exact-source']
        cls.steps=cls.job['steps']
    def test_dispatch_only_and_readonly(self):
        self.assertEqual(self.d['on'],{'workflow_dispatch':{}})
        self.assertEqual(self.d['permissions'],{'contents':'read'})
        self.assertEqual(len(self.d['jobs']),1)
    def test_r44_historical_original_not_replaced(self):
        self.assertIn('name: VEUX R44-R2 R20 WALT GPU AO symbol-count fix - NO FLASH',self.o[:150])
        self.assertNotIn('R45_OUT',self.o)
        self.assertNotEqual(self.raw,self.o)
    def test_original_r44_dependency_sha_pins_unchanged(self):
        defs=re.compile(r'^\s*([A-Z0-9_]*PACKAGE_NAME):\s*([^\n]+)$',re.M)
        q=lambda s: dict(defs.findall(s))
        self.assertEqual(q(self.o),{k:v for k,v in q(self.raw).items() if k!='R45_PACKAGE_NAME'})
        self.assertEqual(q(self.raw).get('R45_PACKAGE_NAME'),'VEUX_R46_R2_MAIN.zip')
        self.assertEqual(len(q(self.o)),26)
    def test_original_r44_yaml_is_linted_by_self_test_current_new_yaml(self):
        self.assertIn("wf=pathlib.Path('project/.github/workflows/VEUX_R46_R2_WALT_SOURCE_PROVENANCE_FIX_NOFLASH.yml')",self.raw)
        self.assertIn("d.get('name')=='VEUX R46-R2 Rootless WALT Provenance Repair + Stock Gate - NO FLASH'",self.raw)
        self.assertEqual(self.d['name'],'VEUX R46-R2 Rootless WALT Provenance Repair + Stock Gate - NO FLASH')
    def test_all_step_names_unique_and_count(self):
        self.assertEqual(len(self.steps),107)
        self.assertEqual(len(set(x['name'] for x in self.steps)),len(self.steps))
    def test_r45_after_fullbuild_and_r44_gate_before_upload(self):
        names=[s['name'] for s in self.steps]
        self.assertLess(names.index('R44 require genuine patched Image vmlinux DTB modules and exact reference targets'),names.index('R45 audit rootfree built kernel against authentic Stock without patching source'))
        self.assertLess(names.index('R45 audit rootfree built kernel against authentic Stock without patching source'),names.index('R45 preserve source config and kernel evidence on failures'))
    def test_r45_checked_in_source_paths_present(self):
        s=next(x for x in self.steps if x['name'].startswith('R45 audit'))
        self.assertIn('$R45_TOOLS_DIR/Tools/VEUX_R45_ROOTLESS/veux_r45_rootless_gate.py',s['run'])
        self.assertIn('$R45_TOOLS_DIR/Tools/VEUX_R45_ROOTLESS/STOCK_5.4.274_QGKI.config',s['run'])
        self.assertTrue((R/'Tools/VEUX_R45_ROOTLESS/veux_r45_rootless_gate.py').is_file())
        self.assertTrue((R/'Tools/VEUX_R45_ROOTLESS/STOCK_5.4.274_QGKI.config').is_file())
        self.assertIn('--pin-stock-only',s['run'])
        self.assertNotIn('--pin-known-config',s['run'])
    def test_build_artifacts_30_days_and_always_when_needed(self):
        raw=next(s for s in self.steps if s['name'].startswith('R20 upload unverified non-flash'))
        self.assertIn("always()",raw['if'])
        self.assertEqual(raw['with']['retention-days'],30)
        self.assertIn('${{ env.R13_OBJOUT }}/.config',raw['with']['path'])
        self.assertIn('${{ env.R13_OBJOUT }}/System.map',raw['with']['path'])
        extra=next(s for s in self.steps if s['name'].startswith('R45 preserve source'))
        self.assertEqual(extra['if'],'${{ always() }}')
        self.assertEqual(extra['with']['retention-days'],30)
    def test_shell_syntax_all_70(self):
        runs=[s['run'] for s in self.steps if 'run' in s]
        self.assertEqual(len(runs),73)
        for i,r in enumerate(runs,1):
            with self.subTest(i=i):
                p=subprocess.run(['bash','-n'],input=r,text=True,capture_output=True)
                self.assertEqual(p.returncode,0,p.stderr[:1000])
    def test_preflight_before_compilation_and_mandatory(self):
        names=[s['name'] for s in self.steps]
        pname='R46-R2 SHA-pinned MAIN: actionlint ShellCheck regressions before compiler'
        self.assertIn(pname,names)
        self.assertLess(names.index(pname),names.index('R20 genuine WALT-ON ARM64 full Image DTBs and modules make with linked vmlinux'))
        s=self.steps[names.index(pname)]
        self.assertIn('shellcheck',s['run'])
        self.assertIn('actionlint',s['run'])
        self.assertIn('VEUX_R46_R2_MAIN.zip',self.raw)
        self.assertIn('MANIFEST_SHA256.txt',s['run'])
    def test_main_zip_outside_checkout_and_p13_preserved(self):
        s=next(z for z in self.steps if z['name'].startswith('R46-R2 SHA-pinned'))
        self.assertIn('$R45_TOOLS_DIR',s['run'])
        self.assertIn('test -z "$(git -C project status --porcelain',s['run'])
        self.assertNotIn('fastboot flash',self.raw)
    def test_r46_five_real_source_changes_between_gpu_and_full_build(self):
        names=[s['name'] for s in self.steps]
        patch='R46 patch five compiler-warning sources on disposable R44 snapshot'
        self.assertIn(patch,names)
        self.assertLess(names.index('R44-R2 integrate unchanged R43 GPU AO patch and verify 449 nodes including /__symbols__'),names.index(patch))
        self.assertLess(names.index(patch),names.index('R20 genuine WALT-ON ARM64 full Image DTBs and modules make with linked vmlinux'))
        block=self.steps[names.index(patch)]['run']
        self.assertIn('veux_r46_repair.py',block)
        self.assertIn('$R9_SNAPSHOT',block)
        self.assertIn('--source',block)
    def test_r46_postbuild_warning_gate_required(self):
        names=[s['name'] for s in self.steps]
        verify='R46 verify all five old warnings eliminated in real ARM64 build'
        self.assertLess(names.index('R45 audit rootfree built kernel against authentic Stock without patching source'),names.index(verify))
        self.assertIn('verify-build',self.steps[names.index(verify)]['run'])
        self.assertIn('make_logs/R20_Image_make.log',self.steps[names.index(verify)]['run'])
        self.assertEqual(self.steps[names.index(verify)]['if'],"${{ steps.r20_status.outputs.full_build == 'true' }}")
    def test_r46_deterministic_metadata_not_stock_spoof(self):
        env=self.job['env']
        self.assertEqual(env['SOURCE_DATE_EPOCH'],'1794009600')
        self.assertEqual(env['KBUILD_BUILD_TIMESTAMP'],'Sat Nov 7 00:00:00 UTC 2026')
        self.assertEqual(env['KBUILD_BUILD_USER'],'veux-ci')
        self.assertEqual(env['KBUILD_BUILD_HOST'],'github-actions')
        self.assertEqual(env['KBUILD_BUILD_VERSION'],'1')
        self.assertNotIn('qgki-g82179e362f33',env.get('KBUILD_BUILD_HOST',''))
    def test_r46_new_script_read_only_project_and_no_root_hooks(self):
        self.assertTrue((R/'Tools/veux_r46_repair.py').exists())
        self.assertNotIn('fastboot flash',self.raw)
        self.assertIn('R46_OUT',self.raw)
        self.assertIn('R46_SOURCE_FIX_RESULT.json',self.raw)
        names=[s['name'] for s in self.steps]
        self.assertLess(names.index('R46 verify all five old warnings eliminated in real ARM64 build'),
                        names.index('R45 preserve source config and kernel evidence on failures'))
    def test_r46_r2_all_five_source_preimage_guard(self):
        names=[x['name'] for x in self.steps]
        step=self.steps[names.index('R46 patch five compiler-warning sources on disposable R44 snapshot')]
        self.assertIn('R46_R2_ALL_FIVE_PREIMAGES_NOT_VERIFIED',step['run'])
        self.assertIn('match_provenance',step['run'])
        self.assertIn('context_unique',step['run'])
        self.assertIn('PY_R46_R2_FIVE_PREIMAGE_GATE',step['run'])
        self.assertIn('05cbdf367815bb93af5cbb16eed24ebf2dd6dfaf',
                      (R/'Tools/veux_r46_repair.py').read_text())
        self.assertIn('42368775951',(R/'Tools/veux_r46_repair.py').read_text())

    def test_no_new_flash_commands(self):
        self.assertNotRegex(self.raw,r'\bfastboot\s+flash\b')
        self.assertNotRegex(self.raw,r'\badb\s+(?:reboot|shell\s+reboot)\b')
if __name__=='__main__': unittest.main()
