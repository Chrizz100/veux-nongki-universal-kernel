#!/usr/bin/env python3
"""VEUX R46-R2, isolated rootless R44 maintenance: strict Git-blob-pinned fixes.

This does NOT grant OEM ABI or device/flash approval.  It only changes a
throwaway runner source snapshot, never the repository, boot image or P13.
"""
import argparse
import difflib
import hashlib
import json
import os
import pathlib
import re
import sys
from datetime import datetime, timezone

SCHEMA = 'VEUX_R46_ROOTLESS_FIVE_FOCUS_REPAIRS_V2'
BUILD_EPOCH = 1794009600  # 2026-11-07 00:00:00 UTC, fixed on purpose
BUILD_STAMP = 'Sat Nov 7 00:00:00 UTC 2026'
BUILD_USER = 'veux-ci'
BUILD_HOST = 'github-actions'

# All five donor source Git blob hashes were retrieved from immutable Positron
# commit b2b7a3bbc36d120ee523ebc8d68e0f13a97df632 (not a moving HEAD).
# The assembled snapshot MUST match either the pinned donor blob or a separately evidenced, explicitly allowlisted R44 assembly blob; the exact old code context is still mandatory.
FIXES = (
    {
        'path': 'drivers/cpufreq/qcom-cpufreq-hw.c',
        'git_blob': '32a43039a916f1e446591b420b933026a2443c0e',
        'warning': 'unused variable c in qcom_cpufreq_hw_driver_remove',
        'old': ('static int qcom_cpufreq_hw_driver_remove(struct platform_device *pdev)\n'
                '{\n\tstruct cpufreq_qcom *c;\n\tstruct device *cpu_dev;'),
        'new': ('static int qcom_cpufreq_hw_driver_remove(struct platform_device *pdev)\n'
                '{\n\tstruct device *cpu_dev;'),
    },
    {
        'path': 'drivers/power/supply/qcom/qpnp-smb5.c',
        'git_blob': '8a25745698a388694cc5740a25ff23f5df2d566e',
        'warning': 'void pointer to narrow u8 cast in charger subtype match data',
        'old': 'int subtype = (u8)of_device_get_match_data(chg->dev);',
        'new': 'int subtype = (u8)(unsigned long)of_device_get_match_data(chg->dev);',
    },
    {
        'path': 'drivers/power/supply/qcom/smb1398-charger.c',
        'git_blob': '288706005bd4c8774939ac9bbfcdab30fbbb357d',
        'warning': 'void pointer to int cast in SMB1398 chip role match data',
        'old': 'chip->div2_cp_role = (int)of_device_get_match_data(chip->dev);',
        'new': 'chip->div2_cp_role = (int)(unsigned long)of_device_get_match_data(chip->dev);',
    },
    {
        'path': 'net/core/dev.c',
        'git_blob': '463932327f3bcd7365c29d1a99dbd6f6a8dd8718',
        'warning': 'static EXPORT_SYMBOL for externally used embms_tm_multicast_recv',
        'old': ('static int (*embms_tm_multicast_recv)(struct sk_buff *skb) __rcu __read_mostly;\n'
                'EXPORT_SYMBOL(embms_tm_multicast_recv);'),
        'new': ('int (*embms_tm_multicast_recv)(struct sk_buff *skb) __rcu __read_mostly;\n'
                'EXPORT_SYMBOL(embms_tm_multicast_recv);'),
    },
    {
        'path': 'techpack/camera/drivers/cam_ope/ope_hw_mgr/ope_hw/ope_dev.c',
        'git_blob': '914539ccb0861bd2438678b08e421e271c1c9a21',
        'warning': 'static EXPORT_SYMBOL for cam_ope_soc_private ope_soc_info',
        'old': ('static struct cam_ope_soc_private ope_soc_info;\n'
                'EXPORT_SYMBOL(ope_soc_info);'),
        'new': ('struct cam_ope_soc_private ope_soc_info;\n'
                'EXPORT_SYMBOL(ope_soc_info);'),
    },
)

# Source assembly lineage: this source file is modified by the proven R44
# replay before R46 runs. The exact assembled blob was observed by the GitHub
# action in R46-R1 Run 42368775951, job 128392362050, step 70, on 2026-11-07.
# Reject all other modified blobs. The replacement site must ALSO match exactly.
DERIVED_R44_PREIMAGES = {
    'net/core/dev.c': {
        '05cbdf367815bb93af5cbb16eed24ebf2dd6dfaf':
            'R46_R1_RUN_42368775951_JOB_128392362050_STEP_70_R44_SOURCE',
    }
}


def accepted_preimages(entry):
    allowed = {entry['git_blob']: 'PINNED_POSITRON_DONOR'}
    allowed.update(DERIVED_R44_PREIMAGES.get(entry['path'], {}))
    return allowed


WARNING_MARKERS = (
    r'qcom-cpufreq-hw\.c:\d+:\d+: warning: unused variable',
    r'qpnp-smb5\.c:\d+:\d+: warning: cast to smaller integer type',
    r'smb1398-charger\.c:\d+:\d+: warning: cast to smaller integer type',
    r'WARNING: "embms_tm_multicast_recv" \[vmlinux\] is a static EXPORT_SYMBOL',
    r'WARNING: "ope_soc_info" \[vmlinux\] is a static EXPORT_SYMBOL',
)


def git_blob_sha1(data):
    return hashlib.sha1(b'blob %d\0' % len(data) + data).hexdigest()


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def within(root, relative):
    root = pathlib.Path(root).resolve(strict=True)
    path = root.joinpath(*pathlib.PurePosixPath(relative).parts)
    resolved = path.resolve(strict=True)
    if resolved != root and root not in resolved.parents:
        raise ValueError('SOURCE_PATH_ESCAPES_ROOT:' + relative)
    if path.is_symlink() or not path.is_file():
        raise ValueError('SOURCE_NOT_REGULAR:' + relative)
    return path


def prepare_fix(data, entry, *, allow_test_pin=False):
    expected = entry['git_blob']
    actual = git_blob_sha1(data)
    allowed = accepted_preimages(entry)
    if actual not in allowed and not allow_test_pin:
        raise ValueError('SOURCE_BLOB_PIN_MISMATCH:%s allowed=%s got=%s' %
                         (entry['path'], ','.join(allowed), actual))
    old, new = entry['old'].encode(), entry['new'].encode()
    if old == new or data.count(old) != 1:
        raise ValueError('SOURCE_CONTEXT_NOT_UNIQUE:' + entry['path'])
    changed = data.replace(old, new, 1)
    if changed == data or old in changed or changed.count(new) != 1:
        raise ValueError('SOURCE_REPLACEMENT_INVALID:' + entry['path'])
    return changed


def make_patch(records):
    results = []
    for record in records:
        a = record['original'].decode('utf-8').splitlines(keepends=True)
        b = record['patched'].decode('utf-8').splitlines(keepends=True)
        results.extend(difflib.unified_diff(a, b,
                 fromfile='a/' + record['path'], tofile='b/' + record['path']))
    return ''.join(results)


def validate_build_env(env):
    expected = {
        'SOURCE_DATE_EPOCH': str(BUILD_EPOCH),
        'KBUILD_BUILD_TIMESTAMP': BUILD_STAMP,
        'KBUILD_BUILD_USER': BUILD_USER,
        'KBUILD_BUILD_HOST': BUILD_HOST,
        'KBUILD_BUILD_VERSION': '1',
    }
    mismatches = {k: {'expected': v, 'actual': env.get(k)} for k, v in expected.items()
                  if env.get(k) != v}
    if mismatches:
        raise ValueError('NONDETERMINISTIC_OR_CHANGED_BUILD_ENV:' + json.dumps(mismatches))
    return expected


def apply(root, output):
    output = pathlib.Path(output)
    output.mkdir(parents=True, exist_ok=True)
    result = {'schema': SCHEMA, 'status': 'BLOCKED_NOFLASH', 'source_commit':
              'dereference23/kernel_xiaomi_sm6375@b2b7a3bbc36d120ee523ebc8d68e0f13a97df632',
              'flash_allowed': False, 'p13_modified': False, 'root_modules_modified': False,
              'changes': [], 'build_environment': {}, 'blocking_errors': []}
    records = []
    result['source_validation'] = []
    try:
        env = validate_build_env(os.environ)
        result['build_environment'] = env
        # Observe ALL five source identities and contexts, before writing ANY file.
        blockers = []
        for entry in FIXES:
            actual = None
            detail = {'path': entry['path'], 'donor_git_blob': entry['git_blob'],
                      'allowed_preimages': accepted_preimages(entry),
                      'observed_git_blob': None, 'match_provenance': None,
                      'context_unique': False}
            try:
                path = within(root, entry['path'])
                original = path.read_bytes()
                actual = git_blob_sha1(original)
                detail['observed_git_blob'] = actual
                edited = prepare_fix(original, entry)
                detail['context_unique'] = True
                detail['match_provenance'] = accepted_preimages(entry).get(actual)
                records.append({'path': entry['path'], 'file': path,
                                'original': original, 'patched': edited,
                                'pin': actual, 'donor_pin': entry['git_blob'],
                                'match_provenance': detail['match_provenance'],
                                'warning': entry['warning']})
            except (OSError, ValueError) as exc:
                blockers.append('%s: %s' % (entry['path'], exc))
                detail['error'] = str(exc)
            result['source_validation'].append(detail)
        if blockers:
            raise ValueError('R46_SOURCE_PREFLIGHT_ALL_FIVE_BLOCKED:' + ';'.join(blockers))
        if len(records) != len(FIXES):
            raise ValueError('R46_INCOMPLETE_SOURCE_PREFLIGHT')
        # Make a patch for independent review before touching the snapshot.
        delta = make_patch(records)
        if not delta.startswith('--- a/') or delta.count('--- a/') != len(FIXES):
            raise ValueError('R46_INVALID_UNIFIED_DIFF')
        (output/'R46_EXACT_FIVE_SOURCE_FIXES.patch').write_text(delta)
        for record in records:
            path = record['file']
            # Check for changes between preflight and update.
            if path.read_bytes() != record['original']:
                raise ValueError('SOURCE_CHANGED_SINCE_PREFLIGHT:' + record['path'])
            path.write_bytes(record['patched'])
            if path.read_bytes() != record['patched']:
                raise ValueError('SOURCE_WRITE_VERIFY_FAILED:' + record['path'])
            result['changes'].append({
                'path': record['path'], 'warning': record['warning'],
                'old_git_blob_sha1': record['pin'],
                'donor_git_blob_sha1': record['donor_pin'],
                'source_provenance': record['match_provenance'],
                'new_git_blob_sha1': git_blob_sha1(record['patched']),
                'old_sha256': sha256(record['original']),
                'new_sha256': sha256(record['patched'])})
        result['status'] = 'R46_FIVE_SOURCE_EDITS_APPLIED_UNVERIFIED_BUILD_NOFLASH'
    except Exception as exc:
        result['blocking_errors'].append(str(exc))
    (output/'R46_SOURCE_FIX_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    if result['blocking_errors']:
        raise SystemExit('R46_SOURCE_FIX_GATE_BLOCKED:' + ';'.join(result['blocking_errors']))
    return result


def verify_build(root, output, build_log, r45_report, r20_report):
    output = pathlib.Path(output)
    proof = json.loads((output/'R46_SOURCE_FIX_RESULT.json').read_text())
    failures = []
    if proof.get('status') != 'R46_FIVE_SOURCE_EDITS_APPLIED_UNVERIFIED_BUILD_NOFLASH':
        failures.append('SOURCE_FIX_PROOF_MISSING')
    by_path = {e['path']: e for e in proof['changes']}
    if set(by_path) != {e['path'] for e in FIXES}:
        failures.append('INCOMPLETE_FIVE_FIXES')
    for entry in FIXES:
        try:
            data = within(root, entry['path']).read_bytes()
            if sha256(data) != by_path[entry['path']]['new_sha256']:
                failures.append('SOURCE_MODIFIED_AFTER_APPLY:' + entry['path'])
        except (OSError, ValueError, KeyError) as ex:
            failures.append('MISSING_OR_CHANGED:' + str(ex))
    text = pathlib.Path(build_log).read_text(errors='replace')
    matches = {pattern: re.findall(pattern, text) for pattern in WARNING_MARKERS}
    for pattern, values in matches.items():
        if values:
            failures.append('OLD_WARNING_STILL_PRESENT:' + pattern)
    r45 = json.loads(pathlib.Path(r45_report).read_text())
    r20 = json.loads(pathlib.Path(r20_report).read_text())
    if r20.get('full_image_proven') is not True:
        failures.append('FULL_KERNEL_IMAGE_NOT_PROVEN')
    if r45.get('status') != 'STATIC_PARTIAL_PASS_NOFLASH':
        failures.append('STOCK_STATUS_UNEXPECTED')
    for doc in (r45, r20):
        if doc.get('flash_allowed') is not False:
            failures.append('UNSAFE_FLASH_CLAIM')
    other_warnings = [s.strip() for s in text.splitlines()
                      if re.search(r'\bwarning:|^WARNING:', s)]
    if other_warnings:
        failures.append('R46_FULL_IMAGE_COMPILE_WARNINGS_REMAIN:%d' % len(other_warnings))
    result = {
        'schema': SCHEMA, 'status': 'R46_FIVE_WARNINGS_FIXED_BUILD_PASS_NOFLASH' if not failures
                 else 'R46_VERIFICATION_BLOCKED_NOFLASH',
        'original_compiler_warning_patterns': len(WARNING_MARKERS),
        'old_warning_occurrences_after_rebuild': sum(len(x) for x in matches.values()),
        'remaining_compiler_warning_lines': other_warnings,
        'full_image_proven': r20.get('full_image_proven'),
        'image_sha256': r20.get('image', {}).get('sha256'),
        'module_symvers_sha256': r20.get('module_symvers_sha256'),
        'stock_gate_status': r45.get('status'),
        'stock_gaps_by_type': r45.get('config_comparison'),
        'stock_source_identity_proven': False,
        'vendor_abi_proven': False,
        'device_boot_tested': False,
        'flash_allowed': False,
        'blocking_errors': failures,
    }
    (output/'R46_POSTBUILD_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    if failures:
        raise SystemExit('R46_POSTBUILD_GATE_BLOCKED:' + ';'.join(failures))
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    a = sub.add_parser('apply')
    a.add_argument('--source', required=True)
    a.add_argument('--out', required=True)
    b = sub.add_parser('verify-build')
    b.add_argument('--source', required=True)
    b.add_argument('--out', required=True)
    b.add_argument('--log', required=True)
    b.add_argument('--r45-report', required=True)
    b.add_argument('--r20-report', required=True)
    args = p.parse_args()
    if args.command == 'apply':
        j = apply(args.source, args.out)
    else:
        j = verify_build(args.source, args.out, args.log, args.r45_report, args.r20_report)
    print(j['status'])


if __name__ == '__main__':
    main()
