# VEUX R46-R2 – gezielte Rootless-Reparatur, NOFLASH

**Stand:** 07.11.2026. Technische Grundlage: GitHub Run 42365165482,
Job 128381585380 (echter ARM64 Image/vmlinux/DTB/6 Module Build),
und originaler R44 Run 40168917960.

**Wirklich repariert im nächsten isolierten Build, noch nicht live kompiliert:**
1. `drivers/cpufreq/qcom-cpufreq-hw.c`: unbenutzte Variable in .remove() entfernen.
2. `drivers/power/supply/qcom/qpnp-smb5.c`: korrekt breiten Zwischencast fuer `const void*`-Matchdaten einsetzen.
3. `drivers/power/supply/qcom/smb1398-charger.c`: entsprechenden Pointer-Cast fuer Ladereglerrolle korrigieren.
4. `net/core/dev.c`: falsch `static` deklariertes, aber per `EXPORT_SYMBOL` exportiertes `embms_tm_multicast_recv` global machen.
5. `techpack/camera/drivers/cam_ope/ope_hw_mgr/ope_hw/ope_dev.c`: falsch `static` deklariertes, aber exportiertes `ope_soc_info` global machen.

Vier Quellen muessen bytegenau mit ihren gepinnten Positron-Bausteinen uebereinstimmen.
Fuer `net/core/dev.c` sind der Positron-Originalblob und genau die separat
belegte R44-Assembled-Preimage erlaubt. Bei jeder Quelle ist der exakt
passende einmalige Quellkontext zwingend; sonst ABORT vor dem Build.
Die Quelle wird ausschließlich im isolierten `$R9_SNAPSHOT` geaendert, nicht im GitHub main, nicht im P13, nicht in historischen ZIPs.

**Determinismus-Vorbereitung:** `SOURCE_DATE_EPOCH=1794009600` und feste,
offene `KBUILD_BUILD_*`-CI-Metadaten (kein Stock-Versionsspoofing).
Ob damit zwei unabhaengige Image-Builds bytegleich sind, muss erst in zwei
neuen echten Runner-Laeufen geprueft werden.

**Wichtige Grenzen:** 72 Stock-Konfigurationsabweichungen inkl. 15 P0 bleiben
separate Quell-/ABI-Aufgaben. Weder Hersteller-ABI noch Geraete-Boot ist
nachgewiesen. Kein BakaSU, SUSFS oder NoMount. Kein AK3/boot.img. Kein Flash.

**Belege:** `References/R45_FIVE_ORIGINAL_WARNINGS.txt` enthaelt genau die
fuenf Warnzeilen aus originalem `make_logs/R20_Image_make.log` von Run
42365165482, Log-SHA256 `83c30adf48152670fc6c526a9079855bb46ab112044263b04feefb8a0a06295c`.

**Installation:** `VEUX_R46_R2_MAIN.zip` im GitHub `main` Root, YAML separat
unter `.github/workflows/` hochladen, Workflow `VEUX R46-R2 Rootless WALT Source Repairs + Stock Gate - NO FLASH` manuell starten.
Der komplette Build darf erst nach bestandenen SHA256/Bash/Actionlint/ShellCheck/
Python-Regressionen beginnen. Alte R45/R44-Workflows bleiben unangetastet.

## R46-R2 Reparatur des fehlerhaften Quellen-SHA-Gates
Der reale R46-R1 GitHub-Lauf `42368775951`, Job `128392362050` scheiterte
am Source-Preflight `net/core/dev.c`: donor blob
`463932327f3bcd7365c29d1a99dbd6f6a8dd8718`, assembled blob
`05cbdf367815bb93af5cbb16eed24ebf2dd6dfaf`.
Der zweite Blob ist jetzt ausschließlich für `net/core/dev.c` ausdrücklich
freigegeben, auf Grundlage des realen GitHub-Protokolls und nur bei
exakt und eindeutig vorkommendem Altsymbol plus `EXPORT_SYMBOL`.
Die vier anderen Dateien bleiben donor-gepinnt, es gibt KEINE generische
Hash-Ausnahme. Bei unerwarteten Änderungen werden ALLE fünf Ist-Hashes
und Ursachen in `R46_SOURCE_FIX_RESULT.json` dokumentiert, bevor irgendeine
Datei geändert wird. Kein Blindpatch, keine Abschwächung des Static-Boot-Gates.

Wichtig: Der nächste GitHub-Lauf ist noch NICHT gelaufen. Lokale Tests und
YAML-Prüfungen beweisen keinen realen Compiler-/ABI-/Boot-PASS. Falls ein
unerwarteter Quellstand auftritt, muss er weiterhin sicher blockiert werden.
