#!/usr/bin/env python3
"""R36 read-only source/build/DTB audit for VEUX. Never builds, installs or flashes."""
from __future__ import annotations
import argparse,csv,hashlib,io,json,pathlib,re,subprocess,sys,zipfile
from collections import Counter
import r34_gate

PINS={
'evidence/R20_BUILD.config':'7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe',
'evidence/DEVICE_STOCK.config':'405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4',
'evidence/R20_Image_make.log':'f16aaafb1cb91e39a4cfe3727a1dcc35a132efd7d8a4595cb44217fa46fee570',
'evidence/R20_VEUX.dtb':'42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
}
COMMIT='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
# This is an independently checked PINNED ANCESTOR, not a bytewise final-R20-source attestation.
PROVIDERS={
 'qti-regulator-fixed':('drivers/regulator/fixed.c','CONFIG_REGULATOR_QTI_FIXED_VOLTAGE','drivers/regulator/qti-fixed-regulator.o'),
 'qcom,stub-regulator':('drivers/regulator/stub-regulator.c','CONFIG_REGULATOR_STUB','drivers/regulator/stub-regulator.o'),
 'regulator-fixed':('drivers/regulator/fixed.c','CONFIG_REGULATOR_FIXED_VOLTAGE','drivers/regulator/fixed.o'),
 'qcom,i2c-pmic':('drivers/mfd/qcom-i2c-pmic.c','CONFIG_MFD_I2C_PMIC','drivers/mfd/qcom-i2c-pmic.o'),
 'qcom,adc-tm5-iio':('drivers/thermal/qcom/adc-tm.c','CONFIG_QTI_ADC_TM','drivers/thermal/qcom/adc-tm.o'),
 'qcom,adc-tm5':('drivers/thermal/qcom/adc-tm.c','CONFIG_QTI_ADC_TM','drivers/thermal/qcom/adc-tm.o'),
 'qcom,spmi-clkdiv':('drivers/clk/qcom/clk-spmi-pmic-div.c','CONFIG_SPMI_PMIC_CLKDIV','drivers/clk/qcom/clk-spmi-pmic-div.o'),
 'qcom,pm6125-gpio':('drivers/pinctrl/qcom/pinctrl-spmi-gpio.c','CONFIG_PINCTRL_QCOM_SPMI_PMIC','drivers/pinctrl/qcom/pinctrl-spmi-gpio.o'),
 'qcom,qpnp-power-on':('drivers/input/misc/qpnp-power-on.c','CONFIG_INPUT_QPNP_POWER_ON','drivers/input/misc/qpnp-power-on.o'),
 'qcom,spmi-adc5':('drivers/iio/adc/qcom-spmi-adc5.c','CONFIG_QCOM_SPMI_ADC5','drivers/iio/adc/qcom-spmi-adc5.o'),
 'qcom,adc-tm7':('drivers/thermal/qcom/adc-tm.c','CONFIG_QTI_ADC_TM','drivers/thermal/qcom/adc-tm.o'),
 'qcom,pmk8350-gpio':('drivers/pinctrl/qcom/pinctrl-spmi-gpio.c','CONFIG_PINCTRL_QCOM_SPMI_PMIC','drivers/pinctrl/qcom/pinctrl-spmi-gpio.o'),
 'qcom,pmk8350-rtc':('drivers/rtc/rtc-pm8xxx.c','CONFIG_RTC_DRV_PM8XXX','drivers/rtc/rtc-pm8xxx.o'),
 'qcom,spmi-sdam':('drivers/nvmem/qcom-spmi-sdam.c','CONFIG_NVMEM_SPMI_SDAM','drivers/nvmem/qcom-spmi-sdam.o'),
 'qcom,spmi-adc7':('drivers/iio/adc/qcom-spmi-adc5.c','CONFIG_QCOM_SPMI_ADC5','drivers/iio/adc/qcom-spmi-adc5.o'),
 'qcom,pmr735a-gpio':('drivers/pinctrl/qcom/pinctrl-spmi-gpio.c','CONFIG_PINCTRL_QCOM_SPMI_PMIC','drivers/pinctrl/qcom/pinctrl-spmi-gpio.o'),
}
UFS={'qcom,ufs-phy-qmp-v4-yupik':('drivers/phy/qualcomm/phy-qcom-ufs-qmp-v4-yupik.c','CONFIG_PHY_QCOM_UFS_V4','drivers/phy/qualcomm/phy-qcom-ufs-qmp-v4-yupik.o'),
     'qcom,ufshc':('drivers/scsi/ufs/ufs-qcom.c','CONFIG_SCSI_UFS_QCOM','drivers/scsi/ufs/ufs-qcom.o')}

def sha(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def read_exact_zip(path):
  with zipfile.ZipFile(path) as z:
    if z.testzip():raise ValueError('ARCHIVE_CRC_FAIL')
    names=[i.filename for i in z.infolist() if not i.is_dir()]
    if len(names)!=len(set(names)) or any(x.startswith('/') or '..' in pathlib.PurePosixPath(x).parts or '\\' in x for x in names):raise ValueError('ARCHIVE_PATH_DUPLICATE_OR_TRAVERSAL')
    if sum(i.file_size for i in z.infolist())>15_000_000:raise ValueError('ARCHIVE_TOO_LARGE')
    return {n:z.read(n) for n in names}

def verify_input(bundle):
    manifest=json.loads((bundle/'MANIFEST_SHA256.json').read_text())
    listed=set(manifest['files'])|{'MANIFEST_SHA256.json'}
    actual={p.relative_to(bundle).as_posix() for p in bundle.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    if listed!=actual:raise ValueError('BUNDLE_FILES_DIFFER:'+str(sorted(listed^actual)[:3]))
    for name,hashvalue in manifest['files'].items():
        content=(bundle/name).read_bytes()
        if sha(content)!=hashvalue:raise ValueError('BUNDLE_FILE_BAD_SHA:'+name)
    for n,h in PINS.items():
        if sha((bundle/n).read_bytes())!=h:raise ValueError('R20_INPUT_BAD_SHA:'+n)
    z=read_exact_zip(bundle/'evidence/R35_GITHUB_RESULT.zip')
    r35=json.loads(z['R35_RESULT.json'])
    if r35['status']!='R35_EVIDENCE_PROVEN_PRIORITY_ONLY_BOOT_BLOCKED' or r35['stock_bound_without_r20_compatible_overlap']!=65 or r35['boot_ready'] is not False:
       raise ValueError('R35_ORIGINAL_RESULT_CHANGED')
    for line in z['SHA256SUMS.txt'].decode().splitlines():
      a,b=line.split(maxsplit=1)
      if b.strip() not in z or sha(z[b.strip()])!=a:raise ValueError('R35_ORIGINAL_MEMBER_TAMPERED')
    d= r34_gate.parse_new_device_zip(bundle/'evidence/DEVICE_R34_R2.zip')
    if len(d['device_nodes'])!=754 or sum(bool(v['stock_bound_drivers']) for v in d['device_nodes'])!=503 or d.get('status')!='CURRENT_NODES_ENUMERATED':
       raise ValueError('DEVICE_STOCK_TREE_COUNT_CHANGED')
    return r35,z,d

def status_for_fdt(blob):
    nodes={n['path']:n for n in r34_gate.fdt_nodes(blob)}
    return nodes

def source_verify(source,manifest):
    source=pathlib.Path(source)
    commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True,timeout=10).strip()
    if commit!=COMMIT:raise ValueError('SOURCE_COMMIT_MISMATCH:'+commit)
    if manifest.get('commit')!=COMMIT or manifest.get('repository')!='dereference23/kernel_xiaomi_sm6375':
      raise ValueError('SOURCE_MANIFEST_PIN_WRONG')
    checked={}
    for rel,expected in manifest['git_blob_shas'].items():
      p=source/rel
      if not p.is_file() or p.is_symlink():raise ValueError('SOURCE_FILE_MISSING:'+rel)
      data=p.read_bytes()
      if len(data)>750_000 or gitblob(data)!=expected:raise ValueError('SOURCE_GIT_BLOB_MISMATCH:'+rel)
      checked[rel]=data.decode('utf8')
    return checked

def of_supported(content,compatible):
    # A driver .compatible initializer, not a comment, filename or DT source literal.
    content=re.sub(r'/\*.*?\*/','',content,flags=re.S)
    content=re.sub(r'//[^\n]*','',content)
    return bool(re.search(r'(?<![A-Za-z0-9_])\.compatible\s*=\s*"'+re.escape(compatible)+r'"',content))

def object_built(log,obj):
    return bool(re.search(r'^\s*CC\s+'+re.escape(obj)+r'\s*$',log,re.M))

def config_on(config,key):return key+'=y' in config.splitlines()

def calculate(bundle,source=None):
    r35,z,device=verify_input(bundle)
    cfg=(bundle/'evidence/R20_BUILD.config').read_text()
    stock_cfg=(bundle/'evidence/DEVICE_STOCK.config').read_text()
    log=(bundle/'evidence/R20_Image_make.log').read_text()
    src_manifest=json.loads((bundle/'SOURCE_BLOBS.json').read_text())
    checked=source_verify(source,src_manifest) if source else None
    dt=status_for_fdt((bundle/'evidence/R20_VEUX.dtb').read_bytes())
    stock={n['path']:n for n in device['device_nodes']}
    ufs_pairs=[('/soc/ufsphy_mem@4807000','qcom,ufs-phy-qmp-v4-yupik'),('/soc/ufshc@4804000','qcom,ufshc')]
    ufs=[]
    for path,compat in ufs_pairs:
        r20=dt[path]; live=stock[path]
        if r20['status']!='disabled' or live['status'] not in ('okay (default)','okay','ok') or compat not in live['compatible'] or not live['stock_bound_drivers']:
           raise ValueError('UFS_DT_STOCK_STATE_UNEXPECTED:'+path)
        src,conf,obj=UFS[compat]
        if not config_on(cfg,conf) or not config_on(stock_cfg,conf) or not object_built(log,obj):raise ValueError('UFS_NOT_PROVEN_COMPILED:'+obj)
        if checked is not None and not of_supported(checked[src],compat):raise ValueError('UFS_PINNED_DRIVER_OF_MATCH_ABSENT:'+compat)
        ufs.append({'node':path,'stock_compatible':compat,'r20_standalone_status':r20['status'],'r20_standalone_compatible':r20['compatible'],'stock_status':live['status'],'stock_bound_driver':live['stock_bound_drivers'],'r20_object_compiled':obj,'config':conf,'source_file':src,'source_exact_blob_verified':checked is not None})
    # Base VEUX DTS != board-specific QRD NOPMI DTBO. This is an observed source distinction.
    if checked is not None:
        if '#include "../qcom/blair.dts"' not in checked['arch/arm64/boot/dts/vendor/xiaomi/veux.dts']:
            raise ValueError('R20_VEUX_DTS_BASE_CHANGED')
        if '#include "blair-qrd.dtsi"' not in checked['arch/arm64/boot/dts/vendor/qcom/blair-qrd-nopmi.dtsi']:
            raise ValueError('QRD_NOMPI_INCLUDE_CHAIN_CHANGED')
        if '#include "blair-qrd-nopmi.dtsi"' not in checked['arch/arm64/boot/dts/vendor/qcom/blair-qrd-nopmi-overlay.dts']:
            raise ValueError('QRD_NOMPI_OVERLAY_CHANGED')
        if 'compatible = "qcom,ufs-phy-qmp-v4-yupik"' not in checked['arch/arm64/boot/dts/vendor/qcom/blair-qrd.dtsi']:
            raise ValueError('QRD_UFS_SOURCE_ABSENT')
        if not re.search(r'obj-\$\(CONFIG_PHY_QCOM_UFS_V4\).*phy-qcom-ufs-qmp-v4-yupik\.o',checked['drivers/phy/qualcomm/Makefile']):
            raise ValueError('UFS_PHY_MAKE_RULE_MISSING')
        if not re.search(r'obj-\$\(CONFIG_SCSI_UFS_QCOM\).*ufs-qcom\.o',checked['drivers/scsi/ufs/Makefile']):
            raise ValueError('UFS_HOST_MAKE_RULE_MISSING')
    rows=list(csv.DictReader(io.StringIO(z['R35_65_KNOTEN_PRIORITAET.csv'].decode())))
    pmic=[]
    for row in rows:
        if row['investigation_group']!='PMIC_REGULATOR':continue
        compatible=row['stock_compatible'];path=row['stock_node']
        if compatible not in PROVIDERS:raise ValueError('UNKNOWN_PMIC_COMPATIBLE:'+compatible)
        if path not in stock or compatible not in stock[path]['compatible']:raise ValueError('PMIC_NODE_NOT_IN_LIVE_STOCK:'+path)
        src,conf,obj=PROVIDERS[compatible]
        if not config_on(cfg,conf) or not object_built(log,obj):raise ValueError('PMIC_KCONFIG_OR_REAL_OBJECT_MISSING:'+compatible)
        if checked is not None and not of_supported(checked[src],compatible):raise ValueError('PMIC_PINNED_OF_MATCH_MISSING:'+compatible)
        pmic.append({'node':path,'compatible':compatible,'stock_driver':row['stock_bound_driver'],'pin_source':src,'r20_config':conf,'r20_object':obj,'source_of_match_pin_proven':checked is not None,'r20_object_compiled':True,'r20_runtime_probe_proven':False})
    if len(pmic)!=25 or len({r['compatible'] for r in pmic})!=16:
        raise ValueError('PMIC_MATRIX_EXPECTED_25_AND_16_COMPATIBLES')
    status='R36_ANCESTOR_SOURCE_OBJECTS_AND_STOCK_DT_CONFIRMED_BOOT_BLOCKED' if source else 'R36_LOCAL_INPUT_AND_COMPILE_PROOF_SOURCE_CHECK_PENDING'
    report={'schema':'VEUX_R36_PINNED_UFS_PMIC_SOURCE_GATE_V1','status':status,
      'pinned_source_repository':src_manifest['repository'],'pinned_source_commit':COMMIT,'source_blob_count':len(src_manifest['git_blob_shas']),
      'source_blob_hashes_verified':bool(source),'r35_nodes_unmatched':65,'r20_standalone_ufs_nodes_disabled':2,
      'stock_ufs_nodes_enabled_and_bound':2,'r20_ufs_built_objects_proven':2,
      'pmic_nodes_source_and_build_checked':25,'pmic_distinct_compatibles':16,
      'source_of_matches_proven':bool(source),'r20_pmic_objects_compiled_proven':25,
      'r20_final_source_exact_for_every_file':False,'live_r20_driver_probe_proven':False,
      'dtbo_selection_proven':False,'dtbo_merge_into_r20_proven':False,
      'r20_boot_compatible':False,'vendor_abi_proven':False,'boot_ready':False,'flash_allowed':False,
      'kernel_built':False,'source_patch_created':False,'brene_changed':False,
      'bakasusu_nomount_changed':False,'device_modified':False,
      'limitations':['The pinned ancestor OF-match is not a byte-identical proof of each final patched R20 source file.',
      'The successful Image compiler log is object-build evidence, not R20 hardware probe.',
      'The R20 standalone DTB has disabled UFS host/PHY; the stock runtime DT reports both enabled and bound.',
      'Bootloader overlay choice/merge with R20 is not proven. Do not force UFS status=okay from this report.',
      'R35 65 unmatched paths are NOT 65 missing kernel drivers; full vendor ABI and runtime boot are untested.']}
    return report,ufs,pmic

def write_report(out,report,ufs,pmic):
    out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    (out/'R36_RESULT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n')
    with (out/'R36_PMIC_25_SOURCE_MATRIX.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(pmic[0]));w.writeheader();w.writerows(pmic)
    with (out/'R36_UFS_2_BOOT_MATRIX.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(ufs[0]));w.writeheader();w.writerows(ufs)
    txt='''VEUX R36 – Gepinnter QUELL-/KBUILD-/KCONFIG-/R20-Compilerlog-Nachweis\n
R35: 65 prioritierte fehlende R20-Einzel-DTB-compatible-Ueberschneidungen (KEINE 65 nachgewiesenen Treiberfehler).
R20-Einzel-DTB: UFS-PHY UND UFS-Host STATUS=disabled.
Stock VEUX Laufzeitbaum: UFS-PHY UND UFS-Host aktiv (ok), Treiber gebunden.
R20 realer Compilerlog: Beide benoetigten UFS-Objekte kompiliert.
R20-Config: UFS-Optionen aktiviert; Stock-Config ebenfalls.
PMIC/Regler: 25 Knoten / 16 unterschiedliche OF-compatibles; passende Kconfig/Compilerobjekte.
Gepinnte Quell-OF-Matches: %s.

WICHTIG: R20-Einzel-DTB ist nicht der fertige Stock-Laufzeit-Tree mit DTBO.
Die NOPMI-Qrd-FDT-Include-Kette existiert separat. DTBO Auswahl/Anwendung ist UNBELEGT.
Kein Treiber- oder Quellpatch gerechtfertigt; keine Boot-, Vendor-ABI- oder Flashfreigabe.
'''%('gegen exakt gepinnte Git-Blobs erneut geprueft' if report['source_blob_hashes_verified'] else 'nur extern gelesen, CI-Pinpruefung steht noch aus')
    (out/'R36_BERICHT_DE.txt').write_text(txt)
    names=['R36_RESULT.json','R36_PMIC_25_SOURCE_MATRIX.csv','R36_UFS_2_BOOT_MATRIX.csv','R36_BERICHT_DE.txt']
    (out/'SHA256SUMS.txt').write_text(''.join(sha((out/n).read_bytes())+'  '+n+'\n' for n in names))

def main():
    p=argparse.ArgumentParser();p.add_argument('--bundle',required=True,type=pathlib.Path);p.add_argument('--source',type=pathlib.Path);p.add_argument('--out',required=True,type=pathlib.Path);a=p.parse_args()
    try:
        report,ufs,pmic=calculate(a.bundle,a.source)
        write_report(a.out,report,ufs,pmic)
        print('R36_SOURCE_CHECK='+('PASS' if a.source else 'PENDING')+'; UFS_BUILT=2/2; STOCK_UFS_ENABLED=2/2; PMIC_PROVIDER_ROWS=25/25; BOOT=NO; FLASH=NO')
    except Exception as e:
        print('R36_FAIL_CLOSED: '+str(e),file=sys.stderr);raise SystemExit(2)
if __name__=='__main__': main()
