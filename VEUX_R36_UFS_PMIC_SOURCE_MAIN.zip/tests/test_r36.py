import unittest,pathlib,sys,hashlib,zipfile,io,json,csv,re,tempfile,shutil
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
import r36_source_audit as a

class Evidence(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.r35,cls.zip,cls.device=a.verify_input(ROOT)
  cls.report,cls.ufs,cls.pmic=a.calculate(ROOT)
  cls.cfg=(ROOT/'evidence/R20_BUILD.config').read_text()
  cls.stock=(ROOT/'evidence/DEVICE_STOCK.config').read_text()
  cls.log=(ROOT/'evidence/R20_Image_make.log').read_text()
 def test_01_manifest_inputs(self):self.assertEqual(len(self.zip['R35_RESULT.json'])>100,True)
 def test_02_original_r35_pass(self):self.assertEqual(self.r35['status'],'R35_EVIDENCE_PROVEN_PRIORITY_ONLY_BOOT_BLOCKED')
 def test_03_65_unmatched(self):self.assertEqual(self.r35['stock_bound_without_r20_compatible_overlap'],65)
 def test_04_source_pin(self):self.assertEqual(a.COMMIT,'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632')
 def test_05_r20_config_sha(self):self.assertEqual(a.sha((ROOT/'evidence/R20_BUILD.config').read_bytes()),a.PINS['evidence/R20_BUILD.config'])
 def test_06_stock_config_sha(self):self.assertEqual(a.sha((ROOT/'evidence/DEVICE_STOCK.config').read_bytes()),a.PINS['evidence/DEVICE_STOCK.config'])
 def test_07_log_sha(self):self.assertEqual(a.sha((ROOT/'evidence/R20_Image_make.log').read_bytes()),a.PINS['evidence/R20_Image_make.log'])
 def test_08_dtb_sha(self):self.assertEqual(a.sha((ROOT/'evidence/R20_VEUX.dtb').read_bytes()),a.PINS['evidence/R20_VEUX.dtb'])
 def test_09_stock_nodes(self):self.assertEqual(len(self.device['device_nodes']),754)
 def test_10_stock_bound_nodes(self):self.assertEqual(sum(bool(n['stock_bound_drivers']) for n in self.device['device_nodes']),503)
 def test_11_ufs_list(self):self.assertEqual(len(self.ufs),2)
 def test_12_ufs_disabled(self):self.assertTrue(all(x['r20_standalone_status']=='disabled' for x in self.ufs))
 def test_13_ufs_stock_enabled(self):self.assertTrue(all(x['stock_status']=='ok' for x in self.ufs))
 def test_14_ufs_has_real_bound_driver(self):self.assertTrue(all(x['stock_bound_driver'] for x in self.ufs))
 def test_15_ufs_phy_built(self):self.assertTrue(a.object_built(self.log,a.UFS['qcom,ufs-phy-qmp-v4-yupik'][2]))
 def test_16_ufs_host_built(self):self.assertTrue(a.object_built(self.log,a.UFS['qcom,ufshc'][2]))
 def test_17_ufs_phy_enabled(self):self.assertTrue(a.config_on(self.cfg,'CONFIG_PHY_QCOM_UFS_V4'))
 def test_18_ufs_host_enabled(self):self.assertTrue(a.config_on(self.cfg,'CONFIG_SCSI_UFS_QCOM'))
 def test_19_pmic_25(self):self.assertEqual(len(self.pmic),25)
 def test_20_pmic_16_compatible(self):self.assertEqual(len({p['compatible'] for p in self.pmic}),16)
 def test_21_pmic_build_matches(self):self.assertTrue(all(a.object_built(self.log,p['r20_object']) for p in self.pmic))
 def test_22_pmic_config(self):self.assertTrue(all(a.config_on(self.cfg,p['r20_config']) for p in self.pmic))
 def test_23_no_boot(self):self.assertIs(self.report['boot_ready'],False)
 def test_24_no_flash(self):self.assertIs(self.report['flash_allowed'],False)
 def test_25_no_source_patch(self):self.assertIs(self.report['source_patch_created'],False)
 def test_26_no_brene_patch(self):self.assertIs(self.report['brene_changed'],False)
 def test_27_no_false_source_claim_locally(self):self.assertIs(self.report['source_blob_hashes_verified'],False)
 def test_28_complete_source_blob_manifest(self):self.assertEqual(len(json.loads((ROOT/'SOURCE_BLOBS.json').read_text())['git_blob_shas']),22)
 def test_29_bad_blob_detectable(self):
  self.assertNotEqual(a.gitblob(b'abd'),a.gitblob(b'abc'))
 def test_30_correct_blob_calculation(self):
  self.assertEqual(a.gitblob(b'abc'),hashlib.sha1(b'blob 3\0abc').hexdigest())
 def test_31_false_compatible_rejected(self):self.assertFalse(a.of_supported('/* .compatible = "x,test" */','x,TEST'))
 def test_32_true_compatible(self):self.assertTrue(a.of_supported('{ .compatible = "x,test" }','x,test'))
 def test_33_compatible_prefix_rejected(self):self.assertFalse(a.of_supported('{ .compatible = "qcom,ufshcd" }','qcom,ufshc'))
 def test_34_missing_object_rejected(self):self.assertFalse(a.object_built(self.log,'drivers/phy/qualcomm/not-built.o'))
 def test_35_config_false_rejected(self):self.assertFalse(a.config_on(self.cfg,'CONFIG_NOT_EXISTING_DRIVER_R36'))
 def test_36_readonly_zip(self):self.assertEqual(len(a.read_exact_zip(ROOT/'evidence/R35_GITHUB_RESULT.zip'))>=7,True)
 def test_37_crc_corruption_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'bad.zip'
   with zipfile.ZipFile(p,'w') as z:
    z.writestr('a.txt','a');z.writestr('a.txt','b')
   with self.assertRaises(ValueError):a.read_exact_zip(p)
 def test_38_parent_path_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   p=pathlib.Path(d)/'bad.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('../a.txt','a')
   with self.assertRaises(ValueError):a.read_exact_zip(p)
 def test_39_missing_source_file_rejected(self):
  m=json.loads((ROOT/'SOURCE_BLOBS.json').read_text())
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises((ValueError,Exception)):
    a.source_verify(d,m)
 def test_40_output_format_and_hash(self):
  with tempfile.TemporaryDirectory() as d:
   a.write_report(d,self.report,self.ufs,self.pmic)
   self.assertTrue((pathlib.Path(d)/'R36_BERICHT_DE.txt').exists())
   for s in (pathlib.Path(d)/'SHA256SUMS.txt').read_text().splitlines():
    h,n=s.split(maxsplit=1);self.assertEqual(a.sha((pathlib.Path(d)/n).read_bytes()),h)
 def test_41_output_no_modules(self):
  with tempfile.TemporaryDirectory() as d:
   a.write_report(d,self.report,self.ufs,self.pmic)
   self.assertFalse(any(x.suffix in ('.ko','.img','.dtb') for x in pathlib.Path(d).rglob('*')))
 def test_42_historical_imports_not_boot(self):self.assertFalse(self.report['vendor_abi_proven'])
 def test_43_stock_ufs_not_r20_probe(self):self.assertFalse(self.report['live_r20_driver_probe_proven'])
 def test_44_dtbo_merge_unproven(self):self.assertFalse(self.report['dtbo_merge_into_r20_proven'])
 def test_45_unknown_pmic_fails_closed(self):self.assertNotIn('not-a-real,device',a.PROVIDERS)

if __name__=='__main__': unittest.main()
