VEUX R36: QUELLCODE-NACHWEIS UFS UND PMIC – KEIN BUILD, KEIN FLASH.

Die ZIP gehoert UNENTPACKT in das Hauptverzeichnis (main).
Die begleitende .yml gehoert nach .github/workflows/ OHNE (1).
Die CI prueft den originalen, auf Commit b2b7... gepinnten Kernel-Ahnen
mit kryptografischen Git-Blob-Hashes, die Build-.config, den tatsaechlichen
R20-Compiler-Log und den Stock-Laufzeit-Device-Tree aus R34.

WICHTIG: R20-Einzel-DTB hat UFS host+phy disabled. Stock-Laufzeitbaum
hat beide enabled+Treiber gebunden. Auswahl/Anwendung der DTBO ist
nicht bewiesen. Gleiche OF-Matches/Kompilierung sind KEIN Probe-/Boot-Beweis.
R20-R11, BReNE, SUSFS, BakaSU, NoMount bleiben unveraendert.
Kein flashbares Image, keine boot.img, keine AK3.
