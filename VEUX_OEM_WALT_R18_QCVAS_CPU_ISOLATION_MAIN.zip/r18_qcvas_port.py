#!/usr/bin/env python3
"""R18: bounded genuine Xiaomi CPU isolation helpers for VEUX 5.4.274.

Do not claim a kernel build/ABI/runtime/flash success. For CONFIG_SCHED_WALT=n,
existing code is preserved in preprocessor branches. Exact previous source gates
and authenticated Positron/P10 preimages are mandatory, no blind fuzz/overwrite.
"""
from __future__ import annotations
import argparse, difflib, hashlib, json, pathlib, re, subprocess, sys

DONOR = 'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e'
ANCESTOR = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
P10_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
FILES = (
    'kernel/sched/core.c', 'kernel/sched/sched.h',
    'kernel/watchdog.c', 'include/linux/nmi.h',
    'kernel/time/hrtimer.c', 'include/linux/hrtimer.h',
    'kernel/time/timer.c', 'include/linux/timer.h',
)
PREVIOUS_MODIFIED = {'kernel/sched/core.c':'r17a', 'kernel/sched/sched.h':'r17b'}
FORBIDDEN = ('flash_allowed','vendor_abi_proven','kernel_image_built','vmlinux_linked',
             'brene_changed','bakasusu_nomount_changed','runtime_tested')

class GateError(Exception): pass

def need(a, reason):
    if not a: raise GateError(reason)

def sha(data):
    if isinstance(data,str): data=data.encode()
    return hashlib.sha256(data).hexdigest()

def one(s,old,new,why):
    n=s.count(old)
    need(n==1,why+':ANCHOR_COUNT_'+str(n))
    return s.replace(old,new,1)

def patch_sched(s):
    need('extern void migrate_tasks(' not in s and 'extern void detach_one_task_core(' not in s,
         'SCHED_MIGRATE_DECL_ALREADY_EXISTS')
    anchor='extern void set_rq_offline(struct rq *rq);\n'
    extra='''#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_HOTPLUG_CPU)
extern void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf,
                          bool migrate_pinned_tasks);
/* Real providers reside in the original Xiaomi qc_vas.c WALT branch. */
extern void detach_one_task_core(struct task_struct *p, struct rq *rq,
                                 struct list_head *tasks);
extern void attach_tasks_core(struct list_head *tasks, struct rq *rq);
#endif
'''
    return one(s,anchor,anchor+extra,'SCHED_CPU_HOTPLUG_DECL')

def patch_core(s):
    need('void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf,' not in s,
         'MIGRATION_ALREADY_WALT_PATCHED')
    old='static void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf)\n{\n'
    new='''#ifdef CONFIG_SCHED_WALT
void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf,
                   bool migrate_pinned_tasks)
#else
static void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf)
#endif
{
'''
    s=one(s,old,new,'CORE_REAL_MIGRATE_FUNCTION')
    start=s.index(new);end=s.index('\n#endif /* CONFIG_HOTPLUG_CPU */',start)
    f=s[start:end]
    f=one(f,'\tint dest_cpu;\n','''\tint dest_cpu;
#ifdef CONFIG_SCHED_WALT
\tunsigned int num_pinned_kthreads = 1; /* executing stopper */
\tLIST_HEAD(tasks);
\tcpumask_t avail_cpus;

\tcpumask_andnot(&avail_cpus, cpu_online_mask, cpu_isolated_mask);
#endif
''','CORE_WALT_PINNED_LOCALS')
    f=one(f,'\t\tnext = __pick_migrate_task(rq);\n', '''\t\tnext = __pick_migrate_task(rq);
#ifdef CONFIG_SCHED_WALT
\t\t/* OEM: keep pinned kernel threads on the isolated CPU. */
\t\tif (!migrate_pinned_tasks && (next->flags & PF_KTHREAD) &&
\t\t    !cpumask_intersects(&avail_cpus, &next->cpus_mask)) {
\t\t\tdetach_one_task_core(next, rq, &tasks);
\t\t\tnum_pinned_kthreads++;
\t\t\tcontinue;
\t\t}
#endif
''','CORE_OEM_PINNED_SKIP')
    f=one(f,'\t\traw_spin_lock(&next->pi_lock);\n\t\trq_relock(rq, rf);\n','''\t\traw_spin_lock(&next->pi_lock);
\t\trq_relock(rq, rf);
#ifdef CONFIG_SCHED_WALT
\t\tif (!(rq->clock_update_flags & RQCF_UPDATED))
\t\t\tupdate_rq_clock(rq);
#endif
''','CORE_OEM_FIRST_CLOCK_UPDATE')
    f=one(f,'\t\t\t*rf = orf;\n\t\t\trq_relock(rq, rf);\n','''\t\t\t*rf = orf;
\t\t\trq_relock(rq, rf);
#ifdef CONFIG_SCHED_WALT
\t\t\tif (!(rq->clock_update_flags & RQCF_UPDATED))
\t\t\t\tupdate_rq_clock(rq);
#endif
''','CORE_OEM_RELOCK_CLOCK_UPDATE')
    orig='\t\tif (WARN_ON(task_rq(next) != rq || !task_on_rq_queued(next))) {\n'
    repl='''#ifdef CONFIG_SCHED_WALT
\t\tif (task_rq(next) != rq || !task_on_rq_queued(next)) {
\t\t\tWARN_ON(migrate_pinned_tasks);
#else
\t\tif (WARN_ON(task_rq(next) != rq || !task_on_rq_queued(next))) {
#endif
'''
    f=one(f,orig,repl,'CORE_OEM_ISOLATION_RACE')
    f=one(f,'\t\trq->stop = stop;\n', '''\t\trq->stop = stop;
#ifdef CONFIG_SCHED_WALT
\tif (num_pinned_kthreads > 1)
\t\tattach_tasks_core(&tasks, rq);
#endif
''','CORE_PINNED_REATTACH') if '\t\trq->stop = stop;\n' in f else one(f,'\trq->stop = stop;\n','''\trq->stop = stop;
#ifdef CONFIG_SCHED_WALT
\tif (num_pinned_kthreads > 1)
\t\tattach_tasks_core(&tasks, rq);
#endif
''','CORE_PINNED_REATTACH')
    s=s[:start]+f+s[end:]
    # The original hotplug call must always migrate pinned tasks.
    call='\tmigrate_tasks(rq, &rf);\n'
    s=one(s,call,'''#ifdef CONFIG_SCHED_WALT
\tmigrate_tasks(rq, &rf, true);
#else
\tmigrate_tasks(rq, &rf);
#endif
''','CORE_EXISTING_HOTPLUG_CALL')
    return s

def patch_nmi(s):
    need('extern bool watchdog_configured(' not in s,'NMI_ALREADY_STAGED')
    anchor='#ifdef CONFIG_LOCKUP_DETECTOR\nvoid lockup_detector_init(void);\n'
    return one(s,anchor,anchor+'''#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_SOFTLOCKUP_DETECTOR)
extern void watchdog_enable(unsigned int cpu);
extern void watchdog_disable(unsigned int cpu);
extern bool watchdog_configured(unsigned int cpu);
#endif
''','NMI_OEM_DECLARATIONS')

def patch_watchdog(s):
    need('static DEFINE_PER_CPU(unsigned int, watchdog_en)' not in s,'WATCHDOG_ALREADY_STAGED')
    s=one(s,'static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);\n',
          '''static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);
#ifdef CONFIG_SCHED_WALT
/* Xiaomi watchdog state synchronized with CPU isolation and hotplug. */
static DEFINE_PER_CPU(unsigned int, watchdog_en);
#endif
''','WATCHDOG_REAL_CPU_STATE')
    s=one(s,'static void watchdog_enable(unsigned int cpu)\n{\n', '''#ifdef CONFIG_SCHED_WALT
void watchdog_enable(unsigned int cpu)
#else
static void watchdog_enable(unsigned int cpu)
#endif
{
''','WATCHDOG_OEM_ENABLE_VISIBILITY')
    x=s.index('#ifdef CONFIG_SCHED_WALT\nvoid watchdog_enable(')
    y=s.index('\nstatic int softlockup_stop_fn',x)
    b=s[x:y]
    b=one(b,'\tstruct completion *done = this_cpu_ptr(&softlockup_completion);\n', '''\tstruct completion *done = this_cpu_ptr(&softlockup_completion);
#ifdef CONFIG_SCHED_WALT
\tunsigned int *enabled = this_cpu_ptr(&watchdog_en);
#endif
''','WATCHDOG_ENABLE_TRACKER')
    b=one(b,'\tcomplete(done);\n', '''\tcomplete(done);
#ifdef CONFIG_SCHED_WALT
\tif (*enabled)
\t\treturn;
#endif
''','WATCHDOG_ENABLE_IDEMPOTENT')
    b=one(b,'\t\twatchdog_nmi_enable(cpu);\n','''\t\twatchdog_nmi_enable(cpu);
#ifdef CONFIG_SCHED_WALT
\t/* OEM memory ordering: publish only after enabling the timer. */
\tmb();
\t*enabled = 1;
#endif
''','WATCHDOG_ENABLE_PUBLISH')
    b=one(b,'static void watchdog_disable(unsigned int cpu)\n{\n', '''#ifdef CONFIG_SCHED_WALT
void watchdog_disable(unsigned int cpu)
#else
static void watchdog_disable(unsigned int cpu)
#endif
{
''','WATCHDOG_DISABLE_VISIBILITY')
    head, disable=b.split('\n#ifdef CONFIG_SCHED_WALT\nvoid watchdog_disable(',1)
    disable='\n#ifdef CONFIG_SCHED_WALT\nvoid watchdog_disable('+disable
    disable=one(disable,'\tstruct hrtimer *hrtimer = this_cpu_ptr(&watchdog_hrtimer);\n', '''#ifdef CONFIG_SCHED_WALT
\tstruct hrtimer *hrtimer = per_cpu_ptr(&watchdog_hrtimer, cpu);
\tunsigned int *enabled = per_cpu_ptr(&watchdog_en, cpu);
#else
\tstruct hrtimer *hrtimer = this_cpu_ptr(&watchdog_hrtimer);
#endif
''','WATCHDOG_DISABLE_CPU_REFERENCE')
    b=head+disable
    # first WARN is in watchdog_enable, second in watchdog_disable
    old='\tWARN_ON_ONCE(cpu != smp_processor_id());\n'
    need(b.count(old)==2,'WATCHDOG_TWO_AFFINITY_CHECKS_REQUIRED')
    b=b.replace(old,'''#ifndef CONFIG_SCHED_WALT
\tWARN_ON_ONCE(cpu != smp_processor_id());
#endif
''',2)
    start=b.index('#ifdef CONFIG_SCHED_WALT\nvoid watchdog_disable')
    pre, post=b[:start],b[start:]
    post=one(post,'\n\t/*\n\t * Disable the perf event first.', '''
#ifdef CONFIG_SCHED_WALT
\tif (!*enabled)
\t\treturn;
#endif
\n\t/*
\t * Disable the perf event first.''','WATCHDOG_DISABLE_STATE_CHECK')
    post=one(post,'\twait_for_completion(this_cpu_ptr(&softlockup_completion));\n','''#ifdef CONFIG_SCHED_WALT
\twait_for_completion(per_cpu_ptr(&softlockup_completion, cpu));
\t*enabled = 0;
#else
\twait_for_completion(this_cpu_ptr(&softlockup_completion));
#endif
''','WATCHDOG_REMOTE_COMPLETION')
    # Callable from the original Xiaomi qc_vas.c only when softlockup detector is active.
    post=one(post,'\nstatic int softlockup_stop_fn', '\nstatic int softlockup_stop_fn','WATCHDOG_NEVER') if False else post
    b=pre+post
    b=b+'''#ifdef CONFIG_SCHED_WALT
bool watchdog_configured(unsigned int cpu)
{
\treturn *per_cpu_ptr(&watchdog_en, cpu);
}
#endif
'''
    return s[:x]+b+s[y:]

def patch_hrtimer_h(s):
    need('HRTIMER_STATE_PINNED' not in s,'HRTIMER_PINNED_ALREADY_PRESENT')
    s=one(s,'#define HRTIMER_STATE_ENQUEUED\t0x01\n','''#define HRTIMER_STATE_ENQUEUED\t0x01
#ifdef CONFIG_SCHED_WALT
#define HRTIMER_PINNED_SHIFT\t1
#define HRTIMER_STATE_PINNED\t(1 << HRTIMER_PINNED_SHIFT)
#endif
''','HRTIMER_OEM_PINNED_BITS')
    token='/* Initialize timers: */\n'
    return one(s,token,'''#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_HOTPLUG_CPU)
extern void hrtimer_quiesce_cpu(void *cpup);
#endif

'''+token,'HRTIMER_ISOLATION_DECL')

def patch_timer_h(s):
    need('timer_quiesce_cpu(' not in s,'TIMER_QUIESCE_ALREADY_PRESENT')
    a='extern void add_timer(struct timer_list *timer);\n'
    return one(s,a,'''#if defined(CONFIG_SCHED_WALT) && defined(CONFIG_HOTPLUG_CPU)
extern void timer_quiesce_cpu(void *cpup);
#endif
'''+a,'TIMER_OEM_QUIESCE_DECL')

def patch_hrtimer(s):
    need('hrtimer_quiesce_cpu(' not in s,'HRTIMER_ALREADY_STAGED')
    old='WRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);'
    s=one(s,old,'''#ifdef CONFIG_SCHED_WALT
\tWRITE_ONCE(timer->state, timer->state | HRTIMER_STATE_ENQUEUED);
#else
\tWRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);
#endif''','HRTIMER_ENQUEUE_RETAIN_PIN')
    old='WRITE_ONCE(timer->state, newstate);'
    s=one(s,old,'''#ifdef CONFIG_SCHED_WALT
\tWRITE_ONCE(timer->state, newstate | (timer->state & HRTIMER_STATE_PINNED));
#else
\tWRITE_ONCE(timer->state, newstate);
#endif''','HRTIMER_REMOVAL_RETAIN_PIN')
    mark='\t\t__remove_hrtimer(timer, base, state, reprogram);\n'
    s=one(s,mark,mark+'''#ifdef CONFIG_SCHED_WALT
\t\ttimer->state &= ~HRTIMER_STATE_PINNED;
#endif
''','HRTIMER_REMOVE_CLEAR_PIN')
    mark='\tfirst = enqueue_hrtimer(timer, new_base, mode);\n'
    s=one(s,mark,'''#ifdef CONFIG_SCHED_WALT
\t/* OEM: preserve HRTIMER_MODE_PINNED across CPU isolation. */
\ttimer->state &= ~HRTIMER_STATE_PINNED;
\ttimer->state |= (!!(mode & HRTIMER_MODE_PINNED)) << HRTIMER_PINNED_SHIFT;
#endif
'''+mark,'HRTIMER_START_SET_PIN')
    active='if (timer->state != HRTIMER_STATE_INACTIVE ||\n'
    s=one(s,active,'''#ifdef CONFIG_SCHED_WALT
\t\tif ((timer->state & ~HRTIMER_STATE_PINNED) !=
\t\t    HRTIMER_STATE_INACTIVE ||
#else
\t\tif (timer->state != HRTIMER_STATE_INACTIVE ||
#endif
''','HRTIMER_ACTIVE_PIN_MASK')
    begin='\n#ifdef CONFIG_HOTPLUG_CPU\n\nstatic void migrate_hrtimer_list('
    need(s.count(begin)==1,'HRTIMER_ORIGINAL_MIGRATE_BEGIN_NOT_UNIQUE')
    end='\n#endif /* CONFIG_HOTPLUG_CPU */\n\nvoid __init hrtimers_init('
    need(s.count(end)==1,'HRTIMER_MIGRATION_BLOCK_END_INVALID')
    start=s.index(begin);stop=s.index(end,start)+len('\n#endif /* CONFIG_HOTPLUG_CPU */\n')
    original=s[start:stop]
    # WALT-on port of actual OEM hotplug/quiesce path. WALT-off retains byte-for-byte
    # original migration block in its preprocessor branch.
    oem='''
#ifdef CONFIG_HOTPLUG_CPU
static void migrate_hrtimer_list(struct hrtimer_clock_base *old_base,
                                 struct hrtimer_clock_base *new_base,
                                 bool remove_pinned)
{
\tstruct hrtimer *timer;
\tstruct timerqueue_node *node;
\tstruct timerqueue_head pinned;
\tbool is_hotplug = !cpu_online(old_base->cpu_base->cpu);

\ttimerqueue_init_head(&pinned);
\twhile ((node = timerqueue_getnext(&old_base->active))) {
\t\ttimer = container_of(node, struct hrtimer, node);
\t\tif (is_hotplug)
\t\t\tBUG_ON(hrtimer_callback_running(timer));
\t\tdebug_deactivate(timer);
\t\t__remove_hrtimer(timer, old_base, HRTIMER_STATE_ENQUEUED, 0);
\t\tif (!remove_pinned && (timer->state & HRTIMER_STATE_PINNED)) {
\t\t\ttimerqueue_add(&pinned, &timer->node);
\t\t\tcontinue;
\t\t}
\t\ttimer->base = new_base;
\t\tenqueue_hrtimer(timer, new_base, HRTIMER_MODE_ABS);
\t}
\twhile ((node = timerqueue_getnext(&pinned))) {
\t\ttimer = container_of(node, struct hrtimer, node);
\t\ttimerqueue_del(&pinned, &timer->node);
\t\tenqueue_hrtimer(timer, old_base, HRTIMER_MODE_ABS);
\t}
}

static void __migrate_hrtimers(unsigned int scpu, bool remove_pinned)
{
\tstruct hrtimer_cpu_base *old_base, *new_base;
\tunsigned long flags;
\tint i;

\tlocal_irq_save(flags);
\told_base = &per_cpu(hrtimer_bases, scpu);
\tnew_base = this_cpu_ptr(&hrtimer_bases);
\traw_spin_lock(&new_base->lock);
\traw_spin_lock_nested(&old_base->lock, SINGLE_DEPTH_NESTING);
\tfor (i = 0; i < HRTIMER_MAX_CLOCK_BASES; i++)
\t\tmigrate_hrtimer_list(&old_base->clock_base[i],
\t\t                     &new_base->clock_base[i], remove_pinned);
\thrtimer_update_softirq_timer(new_base, false);
\traw_spin_unlock(&old_base->lock);
\traw_spin_unlock(&new_base->lock);
\t__hrtimer_peek_ahead_timers();
\tlocal_irq_restore(flags);
}

int hrtimers_dead_cpu(unsigned int scpu)
{
\tBUG_ON(cpu_online(scpu));
\ttick_cancel_sched_timer(scpu);
\tlocal_bh_disable();
\t__migrate_hrtimers(scpu, true);
\tlocal_bh_enable();
\treturn 0;
}

void hrtimer_quiesce_cpu(void *cpup)
{
\t__migrate_hrtimers(*(int *)cpup, false);
}
#endif /* CONFIG_HOTPLUG_CPU */
'''
    return s[:start]+'\n#ifdef CONFIG_SCHED_WALT\n'+oem+'#else /* CONFIG_SCHED_WALT */\n'+original+'#endif /* CONFIG_SCHED_WALT */\n'+s[stop:]

def patch_timer(s):
    need('timer_quiesce_cpu(' not in s,'TIMER_ALREADY_STAGED')
    start_token='\n#ifdef CONFIG_HOTPLUG_CPU\nstatic void migrate_timer_list('
    stop_token='\n#endif /* CONFIG_HOTPLUG_CPU */\n\nstatic void __init init_timer_cpu('
    need(s.count(start_token)==1 and s.count(stop_token)==1,'TIMER_MIGRATION_BOUNDARIES_MISSING')
    a=s.index(start_token);b=s.index(stop_token,a)+len('\n#endif /* CONFIG_HOTPLUG_CPU */\n')
    original=s[a:b]
    oem='''
#ifdef CONFIG_HOTPLUG_CPU
static void migrate_timer_list(struct timer_base *new_base,
                               struct hlist_head *head, bool remove_pinned)
{
\tstruct timer_list *timer;
\tstruct hlist_node *n;
\tint cpu = new_base->cpu;
\thlist_for_each_entry_safe(timer, n, head, entry) {
\t\tif (!remove_pinned && (timer->flags & TIMER_PINNED))
\t\t\tcontinue;
\t\tdetach_timer(timer, false);
\t\ttimer->flags = (timer->flags & ~TIMER_BASEMASK) | cpu;
\t\tinternal_add_timer(new_base, timer);
\t}
}

int timers_prepare_cpu(unsigned int cpu)
{
\tstruct timer_base *base;
\tint b;
\tfor (b = 0; b < NR_BASES; b++) {
\t\tbase = per_cpu_ptr(&timer_bases[b], cpu);
\t\tbase->clk = jiffies;
\t\tbase->next_expiry = base->clk + NEXT_TIMER_MAX_DELTA;
\t\tbase->is_idle = false;
\t\tbase->must_forward_clk = true;
\t}
\treturn 0;
}

static void __migrate_timers(unsigned int cpu, bool remove_pinned)
{
\tstruct timer_base *old_base, *new_base;
\tunsigned long flags;
\tint b, i;
\tfor (b = 0; b < NR_BASES; b++) {
\t\told_base = per_cpu_ptr(&timer_bases[b], cpu);
\t\tnew_base = get_cpu_ptr(&timer_bases[b]);
\t\traw_spin_lock_irqsave(&new_base->lock, flags);
\t\traw_spin_lock_nested(&old_base->lock, SINGLE_DEPTH_NESTING);
\t\tforward_timer_base(new_base);
\t\tif (!cpu_online(cpu))
\t\t\tBUG_ON(old_base->running_timer);
\t\tfor (i = 0; i < WHEEL_SIZE; i++)
\t\t\tmigrate_timer_list(new_base, old_base->vectors + i,
\t\t\t                   remove_pinned);
\t\traw_spin_unlock(&old_base->lock);
\t\traw_spin_unlock_irqrestore(&new_base->lock, flags);
\t\tput_cpu_ptr(&timer_bases);
\t}
}

int timers_dead_cpu(unsigned int cpu)
{
\tBUG_ON(cpu_online(cpu));
\t__migrate_timers(cpu, true);
\treturn 0;
}

void timer_quiesce_cpu(void *cpup)
{
\t__migrate_timers(*(unsigned int *)cpup, false);
}
#endif /* CONFIG_HOTPLUG_CPU */
'''
    return s[:a]+'\n#ifdef CONFIG_SCHED_WALT\n'+oem+'#else /* CONFIG_SCHED_WALT */\n'+original+'#endif /* CONFIG_SCHED_WALT */\n'+s[b:]

TRANSFORMS={
    'kernel/sched/core.c':patch_core,'kernel/sched/sched.h':patch_sched,
    'kernel/watchdog.c':patch_watchdog,'include/linux/nmi.h':patch_nmi,
    'kernel/time/hrtimer.c':patch_hrtimer,'include/linux/hrtimer.h':patch_hrtimer_h,
    'kernel/time/timer.c':patch_timer,'include/linux/timer.h':patch_timer_h,
}

def git(root,*args):
    p=subprocess.run(['git','-C',str(root),*args],capture_output=True)
    need(p.returncode==0,'GIT_REFERENCE_ERROR:'+p.stderr.decode(errors='replace')[:160])
    return p.stdout

def verify_previous(r17a,r17b,r17b_cmp):
    need(r17a.get('status')=='R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED','R17A_PROVENANCE_BAD')
    need(r17b.get('status')=='R17B_FAIR_OEM_SCHEDULER_APIS_STAGED_NOT_COMPILED','R17B_PROVENANCE_BAD')
    need(r17b_cmp.get('status')=='R17B_REAL_OBJECT_OR_PROVIDER_DIAGNOSTICS_RECORDED' and
         r17b_cmp.get('object_success_count')==11 and
         r17b_cmp.get('previous_eleven_preserved')==11 and
         r17b_cmp.get('qc_vas_compiled') is False and
         r17b_cmp.get('fair_symbols',{}).get('symbols_verified') is True and
         r17b_cmp.get('prior_five_provider_symbols') is True and
         r17b_cmp.get('real_arm64_make_attempted') is True,
         'R17B2_GITHUB_DIAG_NOT_PROVEN_11_OF_12')
    need(len(r17b_cmp.get('objects',{}))==12,'R17B2_NOT_ALL_OBJECTS_ATTEMPTED')
    need(r17b.get('after_sha256',{}).get('kernel/sched/sched.h')==
         r17b_cmp.get('r17b_postimages',{}).get('kernel/sched/sched.h'),
         'R17B2_POSTIMAGE_DRIFT')
    for data in (r17a,r17b,r17b_cmp):
        for flag in FORBIDDEN:
            # Source and compiler reports differ in fields; omission is OK
            # only for historically missing runtime_tested.
            if flag in data: need(data[flag] is False,'FALSE_RELEASE_FLAG:'+flag)

def stage(snapshot,canonical,r17a_path,r17b_path,r17b_cmp_path,output):
    for p in (snapshot,canonical):need(p.is_dir() and not p.is_symlink(),'SOURCE_DIR_UNSAFE')
    need(snapshot.resolve()!=canonical.resolve(),'CANONICAL_SOURCE_WRITE_FORBIDDEN')
    need(not output.exists() and not output.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    r17a=json.loads(r17a_path.read_text());r17b=json.loads(r17b_path.read_text())
    old=json.loads(r17b_cmp_path.read_text());verify_previous(r17a,r17b,old)
    inputs={}
    for path in FILES:
        p=snapshot/path
        need(p.is_file() and not p.is_symlink(),'MISSING_OR_SYMLINK_SOURCE:'+path)
        inputs[path]=p.read_bytes()
        if path in PREVIOUS_MODIFIED:
            gate=r17a if PREVIOUS_MODIFIED[path]=='r17a' else r17b
            need(sha(inputs[path])==gate['after_sha256'][path],'OLD_STAGE_DRIFT:'+path)
        else:
            # Immutable git-tree checks: never silently port into an unknown
            # vendor branch. P3/P10 might have a pinned updated copy.
            refs=[f'{ANCESTOR}:{path}',f'{P10_TREE}:{path}']
            valid=False
            for ref in refs:
                p=subprocess.run(['git','-C',str(canonical),'cat-file','-p',ref],capture_output=True)
                if p.returncode==0 and p.stdout==inputs[path]:valid=True
            need(valid,'BASELINE_NOT_POSITRON_OR_PINNED_P10:'+path)
    updated={k:TRANSFORMS[k](inputs[k].decode('utf-8')) for k in FILES}
    need(all(sha(updated[k])!=sha(inputs[k]) for k in FILES),'EMPTY_PATCH')
    diff=''.join(''.join(difflib.unified_diff(inputs[k].decode().splitlines(keepends=True),
                 updated[k].splitlines(keepends=True),fromfile='a/'+k,tofile='b/'+k)) for k in FILES)
    need(diff.count('--- a/')==8 and diff.count('+++ b/')==8,'PATCH_FILE_SCOPE_NOT_EIGHT')
    p=subprocess.run(['git','-C',str(snapshot),'apply','--check','-'],input=diff,text=True,capture_output=True)
    need(p.returncode==0,'GIT_APPLY_CHECK_FAILED:'+p.stderr[:350])
    for k in FILES:(snapshot/k).write_text(updated[k])
    post={k:sha((snapshot/k).read_bytes()) for k in FILES}
    for k in FILES:need(post[k]==sha(updated[k]),'POSTIMAGE_HASH_DRIFT:'+k)
    output.mkdir(parents=True)
    (output/'R18_OEM_CPU_ISOLATION_SOURCE.patch').write_text(diff)
    report={'status':'R18_OEM_ISOLATION_SOURCE_STAGED_NOT_COMPILED',
            'provenance':{'donor':DONOR,'positron_ancestor':ANCESTOR,'p10_tree':P10_TREE,
                          'r17b_object_status':old['status']},
            'modified_files':list(FILES),
            'before_sha256':{k:sha(v) for k,v in inputs.items()},'after_sha256':post,
            'patch_sha256':sha(diff),
            'r17b_previous_eleven_proven':True,'source_only':True,
            'requires_arm64_compile':True,'core_isolation_runtime_proven':False,
            **{key:False for key in FORBIDDEN}}
    (output/'R18_SOURCE_GATE.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    return report

def main(argv=None):
    ap=argparse.ArgumentParser()
    for arg in ['snapshot','canonical','r17a-source','r17b-source','r17b-compiler','output']:
        ap.add_argument('--'+arg,required=True,type=pathlib.Path)
    q=ap.parse_args(argv)
    try: stage(q.snapshot,q.canonical,q.r17a_source,q.r17b_source,q.r17b_compiler,q.output)
    except (GateError,OSError,ValueError,KeyError,UnicodeError) as e:
        print('R18_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr);return 2
    print('R18_OEM_ISOLATION_STAGED=8_FILES; KERNEL_BUILD=NO; FLASH=NO')
    return 0
if __name__=='__main__':sys.exit(main())
