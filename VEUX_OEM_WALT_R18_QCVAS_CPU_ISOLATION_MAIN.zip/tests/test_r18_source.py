import hashlib,importlib.util,json,pathlib,sys,tempfile,unittest,gzip,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import r18_qcvas_port as m
import r18_real_compile as c

# Genuine R17-A kernel/sched/sched.h from GitHub artifacts, then the exact
# R17-B2 source adapter. No synthetic header for the positive header test.
Z=ROOT/'fixtures'

def real_sched():
 raw=gzip.decompress((Z/'R17A_REAL_sched.h.gz').read_bytes()).decode()
 adapter=(Z/'r17b_fair_provider.py').read_text()
 import types
 a=types.ModuleType('r17b_fair_adapter')
 exec(compile(adapter,'r17b_fair_provider.py','exec'),a.__dict__)
 return a.patch_sched(raw)

CORE='''/* code */
#ifdef CONFIG_HOTPLUG_CPU
static void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf)
{
\tstruct rq *rq = dead_rq;
\tstruct task_struct *next, *stop = rq->stop;
\tstruct rq_flags orf = *rf;
\tint dest_cpu;
\trq->stop = NULL;
\tupdate_rq_clock(rq);
\tfor (;;) {
\t\tif (rq->nr_running == 1) break;
\t\tnext = __pick_migrate_task(rq);
\t\trq_unlock(rq, rf);
\t\traw_spin_lock(&next->pi_lock);
\t\trq_relock(rq, rf);
\t\tif (WARN_ON(task_rq(next) != rq || !task_on_rq_queued(next))) {
\t\t\traw_spin_unlock(&next->pi_lock);
\t\t\tcontinue;
\t\t}
\t\tdest_cpu = select_fallback_rq(dead_rq->cpu, next);
\t\trq = __migrate_task(rq, rf, next, dest_cpu);
\t\tif (rq != dead_rq) {
\t\t\trq_unlock(rq, rf);
\t\t\trq = dead_rq;
\t\t\t*rf = orf;
\t\t\trq_relock(rq, rf);
\t\t}
\t\traw_spin_unlock(&next->pi_lock);
\t}
\trq->stop = stop;
}
#endif /* CONFIG_HOTPLUG_CPU */
void core_hotplug_test(void) {
\tmigrate_tasks(rq, &rf);
}
'''
WDOG='''#ifdef CONFIG_SOFTLOCKUP_DETECTOR
static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);
static void watchdog_enable(unsigned int cpu)
{
\tstruct hrtimer *hrtimer = this_cpu_ptr(&watchdog_hrtimer);
\tstruct completion *done = this_cpu_ptr(&softlockup_completion);
\tWARN_ON_ONCE(cpu != smp_processor_id());
\tinit_completion(done);
\tcomplete(done);
\thrtimer_init(hrtimer, CLOCK_MONOTONIC, HRTIMER_MODE_REL_HARD);
\thrtimer->function = watchdog_timer_fn;
\thrtimer_start(hrtimer, ns_to_ktime(sample_period), HRTIMER_MODE_REL_PINNED_HARD);
\t__touch_watchdog();
\tif (watchdog_enabled & NMI_WATCHDOG_ENABLED)
\t\twatchdog_nmi_enable(cpu);
}
static void watchdog_disable(unsigned int cpu)
{
\tstruct hrtimer *hrtimer = this_cpu_ptr(&watchdog_hrtimer);
\tWARN_ON_ONCE(cpu != smp_processor_id());
\t/*
\t * Disable the perf event first.
\t */
\twatchdog_nmi_disable(cpu);
\thrtimer_cancel(hrtimer);
\twait_for_completion(this_cpu_ptr(&softlockup_completion));
}
static int softlockup_stop_fn(void *data) { return 0; }
'''
NMI='#ifdef CONFIG_LOCKUP_DETECTOR\nvoid lockup_detector_init(void);\nvoid lockup_detector_soft_poweroff(void);\n'
HRHEAD='#define HRTIMER_STATE_INACTIVE\t0x00\n#define HRTIMER_STATE_ENQUEUED\t0x01\n\n/* Initialize timers: */\n'
TIMEHEAD='extern void add_timer(struct timer_list *timer);\n'
HR='''WRITE_ONCE(timer->state, HRTIMER_STATE_ENQUEUED);
WRITE_ONCE(timer->state, newstate);
\t\t__remove_hrtimer(timer, base, state, reprogram);
\tfirst = enqueue_hrtimer(timer, new_base, mode);
\t\tif (timer->state != HRTIMER_STATE_INACTIVE ||
#ifdef CONFIG_HOTPLUG_CPU

static void migrate_hrtimer_list(
 body original
#endif /* CONFIG_HOTPLUG_CPU */

void __init hrtimers_init(
'''
TIMER='''
#ifdef CONFIG_HOTPLUG_CPU
static void migrate_timer_list(
 original body
#endif /* CONFIG_HOTPLUG_CPU */

static void __init init_timer_cpu(
'''

class PortRegression(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.data={'kernel/sched/sched.h':real_sched(),'kernel/sched/core.c':CORE,
   'kernel/watchdog.c':WDOG,'include/linux/nmi.h':NMI,
   'kernel/time/hrtimer.c':HR,'include/linux/hrtimer.h':HRHEAD,
   'kernel/time/timer.c':TIMER,'include/linux/timer.h':TIMEHEAD}
 def test_01_true_r17b2_sched(self):
  out=m.patch_sched(self.data['kernel/sched/sched.h'])
  self.assertIn('migrate_tasks(struct rq *dead_rq',out)
  self.assertIn('detach_one_task_core',out)
  self.assertIn('attach_tasks_core',out)
  self.assertIn('extern int find_energy_efficient_cpu',out)
 def test_02_real_header_repeated_patch_rejected(self):
  p=m.patch_sched(self.data['kernel/sched/sched.h'])
  with self.assertRaises(m.GateError):m.patch_sched(p)
 def test_03_r17b2_real_header_hash(self):
  raw=self.data['kernel/sched/sched.h']
  self.assertTrue(len(raw)>80000)
 def test_04_core_real_migration(self):
  out=m.patch_core(CORE)
  self.assertIn('migrate_tasks(rq, &rf, true)',out)
  self.assertIn('detach_one_task_core(next, rq, &tasks)',out)
  self.assertIn('attach_tasks_core(&tasks, rq)',out)
 def test_05_core_walt_off_retains_original(self):
  out=m.patch_core(CORE)
  self.assertIn('static void migrate_tasks(struct rq *dead_rq, struct rq_flags *rf)',out)
  self.assertIn('if (WARN_ON(task_rq(next)',out)
 def test_06_core_no_fake(self):
  out=m.patch_core(CORE)
  self.assertNotIn('return 0; /* fake */',out)
 def test_07_core_preimage_rejects(self):
  with self.assertRaises(m.GateError):m.patch_core(CORE.replace('static void migrate_tasks','void migrate_tasks'))
 def test_08_core_repeat_rejected(self):
  with self.assertRaises(m.GateError):m.patch_core(m.patch_core(CORE))
 def test_09_nmi_real_declarations(self):
  out=m.patch_nmi(NMI)
  for key in ('watchdog_enable','watchdog_disable','watchdog_configured'):
   self.assertIn('extern '+('bool' if key.endswith('configured') else 'void')+' '+key,out)
 def test_10_nmi_preimage_rejected(self):
  with self.assertRaises(m.GateError):m.patch_nmi(NMI.replace('void lockup_detector_init(void);','void weird(void);'))
 def test_11_watchdog_state_real(self):
  out=m.patch_watchdog(WDOG)
  self.assertIn('DEFINE_PER_CPU(unsigned int, watchdog_en)',out)
  self.assertIn('mb();\n\t*enabled = 1;',out)
  self.assertIn('*enabled = 0;',out)
 def test_12_watchdog_crosscpu(self):
  out=m.patch_watchdog(WDOG)
  self.assertIn('per_cpu_ptr(&watchdog_hrtimer, cpu)',out)
  self.assertIn('per_cpu_ptr(&softlockup_completion, cpu)',out)
 def test_13_watchdog_off_original(self):
  out=m.patch_watchdog(WDOG)
  self.assertIn('static void watchdog_enable(unsigned int cpu)',out)
  self.assertIn('static void watchdog_disable(unsigned int cpu)',out)
 def test_14_watchdog_repeat_rejected(self):
  with self.assertRaises(m.GateError):m.patch_watchdog(m.patch_watchdog(WDOG))
 def test_15_hrtimer_header(self):
  out=m.patch_hrtimer_h(HRHEAD)
  self.assertIn('HRTIMER_STATE_PINNED',out)
  self.assertIn('hrtimer_quiesce_cpu',out)
 def test_16_timer_header(self):self.assertIn('timer_quiesce_cpu',m.patch_timer_h(TIMEHEAD))
 def test_17_hrtimer_genuine(self):
  out=m.patch_hrtimer(HR)
  for x in ('timerqueue_init_head(&pinned)','!remove_pinned','hrtimer_quiesce_cpu','local_irq_save(flags)'):
   self.assertIn(x,out)
 def test_18_hrtimer_off_original(self):
  out=m.patch_hrtimer(HR)
  self.assertIn('static void migrate_hrtimer_list(\n body original',out)
  self.assertIn('#else /* CONFIG_SCHED_WALT */',out)
 def test_19_hrtimer_repeat_rejected(self):
  with self.assertRaises(m.GateError):m.patch_hrtimer(m.patch_hrtimer(HR))
 def test_20_timer_real_pinned(self):
  out=m.patch_timer(TIMER)
  self.assertIn('TIMER_PINNED',out)
  self.assertIn('timer_quiesce_cpu',out)
  self.assertIn('raw_spin_lock_irqsave',out)
 def test_21_timer_off_original(self):self.assertIn(' original body\n',m.patch_timer(TIMER))
 def test_22_timer_repeat_rejected(self):
  with self.assertRaises(m.GateError):m.patch_timer(m.patch_timer(TIMER))
 def test_23_exact_scope(self):self.assertEqual(len(m.FILES),8)
 def test_24_sha_strings(self):
  self.assertEqual(m.DONOR,'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e')
  self.assertEqual(len(m.P10_TREE),40)
 def test_25_previous_success_required(self):
  source=pathlib.Path(m.__file__).read_text()
  self.assertIn('R17B2_GITHUB_DIAG_NOT_PROVEN_11_OF_12',source)
 def test_26_no_flash(self):
  self.assertTrue({'flash_allowed','vendor_abi_proven','brene_changed'}.issubset(m.FORBIDDEN))
 def test_27_static_python_compiler(self):
  compile((ROOT/'r18_real_compile.py').read_bytes(),'r18_real_compile.py','exec')
 def test_28_15_true_objects(self):
  self.assertEqual(len(c.TARGETS_EXTRA),3)
  self.assertEqual(len(c.REQUIRED),8)
 def test_29_symbol_twelve(self):
  self.assertEqual(sum(map(len,c.REQUIRED.values())),13)
 def test_30_previous_compiler_guard(self):
  self.assertIn('R17B_PRIOR_DIAGNOSTIC_CHANGED',pathlib.Path(c.__file__).read_text())
 def test_31_genuine_qc_gate(self):
  self.assertIn('qc_vas_compiled',pathlib.Path(c.__file__).read_text())
 def test_32_no_false_success(self):
  self.assertIn('count==15 and preserved==11',pathlib.Path(c.__file__).read_text())
 def test_33_old_11_recompiled(self):self.assertIn('for target in targets:',pathlib.Path(c.__file__).read_text())
 def test_34_no_placeholder(self):
  out='\n'.join(m.TRANSFORMS[k](self.data[k]) for k in m.FILES)
  for x in ('TODO implementation','return 0; /* fake','stubbed provider'):
   self.assertNotIn(x,out)
 def test_35_wrong_version_rejected(self):
  with self.assertRaises(m.GateError):m.patch_hrtimer(HR.replace('#ifdef CONFIG_HOTPLUG_CPU','\n#ifndef CONFIG_HOTPLUG_CPU'))
 def test_36_wrong_watchdog_rejected(self):
  with self.assertRaises(m.GateError):m.patch_watchdog(WDOG.replace('static void watchdog_disable','void watchdog_disable'))
 def test_37_config_requires_softlockup(self):
  self.assertIn('R18_SOFTLOCKUP_REQUIRED_FOR_AUTHENTIC_WATCHDOG',pathlib.Path(c.__file__).read_text())
 def test_38_compile_logs_kept(self):self.assertIn('driver.run_cmd(',pathlib.Path(c.__file__).read_text())
 def test_39_no_forged_object(self):self.assertIn('obj.stat().st_size>0',pathlib.Path(c.__file__).read_text())
 def test_40_machine_report(self):self.assertIn('R18_COMPILER_RESULT.json',pathlib.Path(c.__file__).read_text())
 def test_41_real_r17b_compiler_artifact(self):
  r=json.loads((ROOT/'fixtures/R17B_COMPILER_RESULT_GITHUB.json').read_text())
  self.assertEqual(r['object_success_count'],11)
  self.assertFalse(r['qc_vas_compiled'])
  self.assertTrue(r['fair_symbols']['symbols_verified'])
 def test_42_six_real_qc_errors(self):
  src=(ROOT/'fixtures/R17B_QC_VAS_COMPILER_ERROR_GITHUB.log').read_text()
  self.assertEqual(src.count('error: '),6)
  for fn in ('migrate_tasks','watchdog_enable','watchdog_configured','hrtimer_quiesce_cpu','timer_quiesce_cpu','watchdog_disable'):
   self.assertIn(fn,src)
 def test_43_github_source_chain(self):
  gate=json.loads((ROOT/'fixtures/R17B_SOURCE_GATE_GITHUB.json').read_text())
  comp=json.loads((ROOT/'fixtures/R17B_COMPILER_RESULT_GITHUB.json').read_text())
  self.assertEqual(gate['after_sha256'],comp['r17b_postimages'])
 def test_44_genuine_prev_source_hashes(self):
  gate=json.loads((ROOT/'fixtures/R17B_SOURCE_GATE_GITHUB.json').read_text())
  self.assertIn('kernel/sched/fair.c',gate['after_sha256'])
  self.assertIn('kernel/sched/sched.h',gate['after_sha256'])
 def test_45_reject_non_pinned_real_compiler_status(self):
  gate=json.loads((ROOT/'fixtures/R17B_SOURCE_GATE_GITHUB.json').read_text())
  old=json.loads((ROOT/'fixtures/R17B_COMPILER_RESULT_GITHUB.json').read_text())
  r17a={'status':'R17A_SCHEDULER_PROVIDERS_STAGED_NOT_COMPILED'}
  m.verify_previous(r17a,gate,old)
  old['qc_vas_compiled']=True
  with self.assertRaises(m.GateError):m.verify_previous(r17a,gate,old)
if __name__=='__main__':unittest.main(verbosity=2)

