#!/usr/bin/env python3
"""R18 genuine ARM64 Clang diagnostics: 12 WALT targets + watchdog/hrtimer/timer.

No success is inferred from a successful workflow; only real object files and
llvm-nm providers count. No vmlinux, vendor ABI, flash, device runtime claim.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,os,pathlib,re,subprocess,sys

TARGETS_EXTRA=('kernel/watchdog.o','kernel/time/hrtimer.o','kernel/time/timer.o')
REQUIRED={
 'kernel/sched/core.o':('migrate_tasks','migrate_swap','calc_load_migrate'),
 'kernel/watchdog.o':('watchdog_enable','watchdog_disable','watchdog_configured'),
 'kernel/time/hrtimer.o':('hrtimer_quiesce_cpu',),
 'kernel/time/timer.o':('timer_quiesce_cpu',),
 'kernel/sched/fair.o':('find_energy_efficient_cpu','active_load_balance_cpu_stop'),
 'kernel/sysctl.o':('proc_douintvec_capacity',),
 'kernel/cpu.o':('__cpu_isolated_mask',),
 'kernel/sched/topology.o':('init_sched_groups_capacity',),
}
FORBIDDEN=('vendor_abi_proven','kernel_image_built','vmlinux_linked','flash_allowed',
           'brene_changed','bakasusu_nomount_changed','runtime_tested')
KNOWN_R17A_SHA='a92e16e2ed3685b45db09d2603ff5696dbea25a8308f2c92a9d2f00cecd043c2'
KNOWN_R9_SHA='3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
class GateError(Exception):pass

def need(b,why):
 if not b: raise GateError(why)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path)
 need(spec and spec.loader,'PINNED_MODULE_MISSING:'+name)
 m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def preflight(q):
 for d in (q.snapshot,q.canonical,q.objout,q.project,q.toolchain):
  need(d.is_dir() and not d.is_symlink(),'UNSAFE_DIR:'+str(d))
 need(len(set(str(x.resolve()) for x in (q.snapshot,q.canonical,q.project)))==3,
      'SOURCE_DIRS_NOT_ISOLATED')
 need(not q.output.exists() and not q.output.is_symlink(),'EXISTING_OUTPUT_FORBIDDEN')
 for p in (q.source_gate,q.r17b_gate,q.r17b_result,q.r17a_driver,q.r9_driver,q.config):
  need(p.is_file() and not p.is_symlink(),'MISSING_PINNED_INPUT:'+str(p))
 need(h(q.r17a_driver)==KNOWN_R17A_SHA and h(q.r9_driver)==KNOWN_R9_SHA,
      'ORIGINAL_COMPILER_ADAPTER_HASH_DRIFT')
 for name in ('clang','llvm-nm','ld.lld'):
  need((q.toolchain/'bin'/name).is_file(),'MISSING_PINNED_TOOL:'+name)
 source=read(q.source_gate);old=read(q.r17b_result); oldgate=read(q.r17b_gate)
 need(source['status']=='R18_OEM_ISOLATION_SOURCE_STAGED_NOT_COMPILED','R18_SOURCE_NOT_STAGED')
 need(source['modified_files']==[
   'kernel/sched/core.c','kernel/sched/sched.h','kernel/watchdog.c','include/linux/nmi.h',
   'kernel/time/hrtimer.c','include/linux/hrtimer.h','kernel/time/timer.c','include/linux/timer.h'],
   'R18_PATCH_SCOPE_CHANGED')
 need(source.get('r17b_previous_eleven_proven') is True,'R17B_PREVIOUS_UNVERIFIED')
 need(source['before_sha256']['kernel/sched/sched.h']==oldgate['after_sha256']['kernel/sched/sched.h'],
      'R17B_SCHED_PREIMAGE_DRIFT')
 need(old['object_success_count']==11 and old['previous_eleven_preserved']==11 and
      not old['qc_vas_compiled'] and old['real_arm64_make_attempted'] is True and
      old['fair_symbols']['symbols_verified'] and old['prior_five_provider_symbols'],
      'R17B_PRIOR_DIAGNOSTIC_CHANGED')
 need(len(old['objects'])==12,'R17B_UNEXPECTED_OBJECT_LIST')
 for path,expected in source['after_sha256'].items():
  f=q.snapshot/path
  need(f.is_file() and not f.is_symlink() and h(f)==expected,'R18_POSTIMAGE_BAD:'+path)
 conf=q.config.read_text()
 for name in ('CONFIG_SCHED_WALT','CONFIG_HOTPLUG_CPU','CONFIG_SMP','CONFIG_QGKI'):
  need(re.search(r'(?m)^'+name+r'=y$',conf) is not None,'R18_CONFIG_REQUIRED:'+name)
 # Without softlockup, upstream WALT watchdog callers need a separate
 # functional design. Never silently substitute a fake implementation.
 need(re.search(r'(?m)^CONFIG_SOFTLOCKUP_DETECTOR=y$',conf) is not None,
      'R18_SOFTLOCKUP_REQUIRED_FOR_AUTHENTIC_WATCHDOG')
 for d in (source,old):
  for key in FORBIDDEN:need(d.get(key) is False,'UNSAFE_RELEASE_FLAG:'+key)
 return source,old

def compile_one(q,driver,target,logs,env):
 need(target in TARGETS_EXTRA or target in q.r17a_targets,'COMPILER_TARGET_OUT_OF_SCOPE')
 obj=q.objout/target;src=q.snapshot/(target[:-1]+'c')
 log=logs/(target.replace('/','_')+'.log')
 if not src.is_file() or src.is_symlink():
  log.write_text('MISSING_REAL_SOURCE:'+str(src)+'\n')
  return {'compiled':False,'exit_code':None,'object_bytes':0,'log_sha256':h(log),'failure':'MISSING_REAL_SOURCE'}
 need(obj.parent.is_dir() and not obj.parent.is_symlink(),'MISSING_OUTPUT_OBJECT_DIR:'+target)
 for f in (obj,obj.parent/('.'+obj.name+'.cmd')):
  need(not f.is_symlink() and (not f.exists() or f.is_file()),'UNSAFE_OR_MISSING_STALE_OBJ:'+str(f))
  if f.exists():f.unlink()
 result=driver.run_cmd(driver.make_argv(q.snapshot,q.objout,q.toolchain,target,2),log,300,env=env)
 exists=obj.is_file() and not obj.is_symlink() and obj.stat().st_size>0
 ok=result.get('exit_code')==0 and result.get('timed_out') is False and exists
 return {**result,'compiled':bool(ok),'object_present':bool(exists),
         'object_bytes':obj.stat().st_size if exists else 0,
         **({'object_sha256':h(obj)} if exists else {})}

def providers(q,qresults,parse_nm):
 result={'tool_invoked':False,'providers':{},'all_verified':False,'count_verified':0}
 for target,names in REQUIRED.items():
  rec={'compiled':qresults[target]['compiled'],'symbols':{},'nm_rc':None}
  if rec['compiled']:
   nm=subprocess.run([str(q.toolchain/'bin/llvm-nm'),'--defined-only',str(q.objout/target)],capture_output=True,text=True,timeout=30)
   (q.output/(target.replace('/','_')+'.nm.txt')).write_text(nm.stdout+nm.stderr)
   rec['nm_rc']=nm.returncode
   result['tool_invoked']=True
   parsed=parse_nm(nm.stdout) if nm.returncode==0 else []
   for sym in names:
    # LTO may show a dashed address, but real global definitions are T.
    rec['symbols'][sym]=bool(nm.returncode==0 and any(n==sym and c in 'T' for c,n in parsed))
  else:
   rec['symbols']={sym:False for sym in names}
  result['providers'][target]=rec
 result['count_verified']=sum(x for rec in result['providers'].values() for x in rec['symbols'].values())
 result['all_verified']=result['count_verified']==sum(map(len,REQUIRED.values()))
 if qresults['kernel/sched/walt/qc_vas.o']['compiled']:
  nm=subprocess.run([str(q.toolchain/'bin/llvm-nm'),'--undefined-only',str(q.objout/'kernel/sched/walt/qc_vas.o')],capture_output=True,text=True,timeout=30)
  (q.output/'R18_QC_VAS_UNDEFINED.nm.txt').write_text(nm.stdout+nm.stderr)
  result['qc_vas_undefined_rc']=nm.returncode
  result['qc_vas_undefined']=[symbol for kind,symbol in parse_nm(nm.stdout) if kind=='U'] if nm.returncode==0 else []
 return result

def run(q):
 source,old=preflight(q)
 prev=load(q.r17a_driver,'r18_pinned_r17a_adapter');drv=load(q.r9_driver,'r18_pinned_r9_driver')
 q.r17a_targets=prev.TARGETS
 targets=tuple(prev.TARGETS)+TARGETS_EXTRA
 q.output.mkdir(parents=True)
 logs=q.output/'compiler_logs';logs.mkdir()
 result={'status':'R18_IN_PROGRESS','objects':{},'source_r18_verified':True,
         'real_arm64_make_attempted':False,'kernel_version':'5.4.274',
         'targets':list(targets),'object_success_count':0,
         'r18_postimages':source['after_sha256'],
         **{x:False for x in FORBIDDEN}}
 report=q.output/'R18_COMPILER_RESULT.json';report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 env=os.environ.copy();env['PATH']=str(q.toolchain/'bin')+os.pathsep+env.get('PATH','')
 for target in targets:
  result['real_arm64_make_attempted']=True
  result['objects'][target]=compile_one(q,drv,target,logs,env)
  report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 count=sum(v['compiled'] is True for v in result['objects'].values())
 preserved=sum(result['objects'][t]['compiled'] is True for t,o in old['objects'].items() if o['compiled'])
 providers_evidence=providers(q,result['objects'],prev.parse_nm)
 full=count==15 and preserved==11 and providers_evidence['all_verified'] and result['objects']['kernel/sched/walt/qc_vas.o']['compiled']
 result.update({'status':'R18_ALL_FIFTEEN_OBJECTS_AND_REAL_PROVIDERS_COMPILED_NO_LINK' if full
                else 'R18_REAL_OBJECT_OR_PROVIDER_DIAGNOSTICS_RECORDED',
                'object_success_count':count,'prior_eleven_preserved':preserved,
                'qc_vas_compiled':result['objects']['kernel/sched/walt/qc_vas.o']['compiled'],
                'three_support_objects_compiled':sum(result['objects'][t]['compiled'] is True for t in TARGETS_EXTRA),
                'symbol_evidence':providers_evidence,
                'note':'Object-only no vmlinux linking, vendor ABI/CRC, device runtime or flash validation'})
 report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print('R18_REAL_ARM64='+str(count)+'/15; R17B_PREVIOUS='+str(preserved)+'/11; QC_VAS='+str(int(result['qc_vas_compiled']))+
       '; OEM_SUPPORT='+str(result['three_support_objects_compiled'])+'/3; PROVIDERS='+str(providers_evidence['count_verified'])+'/'+str(sum(map(len,REQUIRED.values())))+
       '; STATUS='+result['status']+'; IMAGE=NO; ABI=OPEN; FLASH=NO')
 return result

def main():
 ap=argparse.ArgumentParser()
 for arg in ('snapshot','canonical','objout','project','toolchain','source-gate','r17b-gate','r17b-result','r17a-driver','r9-driver','config','output'):
  ap.add_argument('--'+arg,required=True,type=pathlib.Path)
 q=ap.parse_args()
 try:run(q)
 except (GateError,OSError,KeyError,ValueError,UnicodeError,subprocess.TimeoutExpired) as e:
  print('R18_COMPILER_GATE_ERROR:'+str(e),file=sys.stderr);return 2
 return 0
if __name__=='__main__':sys.exit(main())
