"""Restore the verified kernel sources and stock boot used by this build."""

import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = "3e0e740b7509aa859cf4fe90ca8bc7b310342501b06b9cc1c5ffeb4266a20a90"
TAR = "2bd98fddc4eab9b26e7dfe927052fe6e2dcbc4003d2300e14005a96e09bc0e97"
CONFIG = "783c02b0a718b6ad02c1d6a3d07a0b8ad619787b22e879eec07733bce857da8d"
M60 = "db2b5c58f5396db2b0e48bb83acbf0352df2a93ca2d644cb2c5d96f7b02c1073"
BOOT = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
STOCK_ARCHIVE = "e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(2**20), b""):
            h.update(block)
    return h.hexdigest()


def need(ok, message):
    if not ok:
        raise ValueError(message)


def prepare(w, source, stock):
    w.mkdir(parents=True, exist_ok=True)
    need(digest(source) == SOURCE, "M60 source artifact changed")
    with zipfile.ZipFile(source) as z:
        manifest = json.loads(z.read("M60_KERNEL.json"))
        need(
            manifest["image_sha256"] == M60 and manifest["config_sha256"] == CONFIG,
            "M60 manifest",
        )
        z.extract("M60-kernel-source.tar.gz", w)
        baseline = z.read("kernel.config")
    tar = w / "M60-kernel-source.tar.gz"
    need(
        digest(tar) == TAR and hashlib.sha256(baseline).hexdigest() == CONFIG,
        "M60 source/config",
    )
    stock_hash = digest(stock)
    if stock_hash == BOOT:
        shutil.copyfile(stock, w / "boot.img")
    elif stock_hash == STOCK_ARCHIVE:
        with (
            zipfile.ZipFile(stock) as z,
            zipfile.ZipFile(
                io.BytesIO(z.read("VEUX_M46_Stock_und_Geraetecheck.zip"))
            ) as inner,
        ):
            inner.extract("boot.img", w)
    else:
        raise ValueError("Unrecognized Xiaomi stock boot input")
    need(digest(w / "boot.img") == BOOT, "Factory boot.img")
    src = w / "src"
    src.mkdir()
    subprocess.run(["tar", "--no-same-owner", "-xzf", tar, "-C", src], check=True)
    patch = ROOT / "m61.patch"
    subprocess.run(["git", "apply", "--check", patch], cwd=src, check=True)
    subprocess.run(["git", "apply", patch], cwd=src, check=True)
    for file, h in json.loads((ROOT / "postimages.json").read_text()).items():
        need(digest(src / file) == h, "Patched file " + file)
    (w / "out").mkdir()
    (w / "out/.config").write_bytes(baseline)
    (w / "baseline.config").write_bytes(baseline)


if __name__ == "__main__":
    prepare(*(Path(arg).resolve() for arg in sys.argv[1:]))
