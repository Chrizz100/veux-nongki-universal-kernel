# VEUX M61 für HyperOS OS1.0.12.0.TKCMIXM

M61 baut den Kernel für das Poco X4 Pro 5G mit der Kennung `5.4.274-qgki-g82179e362f33`. Die Prüfbasis ist der von Xiaomi ausgelieferte Kernel dieser Firmware. Der SHA-256 des originalen `boot.img` ist `ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5`. Die vollständig rekonstruierte Vendor-Partition hat den SHA-256 `d9680da1f63800abb48951772b993baedeb7c09c0a94a4f9ec61a721b9597f78`.

## Manueller GitHub-Lauf

1. `VEUX_M61_MAIN.zip` ins Hauptverzeichnis des Kernel-Repositories hochladen.
2. `VEUX_M61_STOCK_QGKI_NOFLASH.yml` unter `.github/workflows/` ablegen.
3. In **Actions** den Workflow **VEUX M61 – Originale Xiaomi-Vendormodule und UFS** auswählen und starten.

Die YAML und die MAIN gehören zusammen. Der Workflow prüft die SHA-256 der MAIN, des M60-Quellstands, des Xiaomi-Bootabbilds und der OEM-Moduldateien. Der erste Bezug des M60-Quellstands verwendet das GitHub-Artefakt 14768279498. Nach einem erfolgreichen Lauf liegt der vollständige M61-Quellstand mit der zugehörigen Kbuild-Datei im Artefakt QUELLSTAND.

## Änderungen

Bei M60 überschneiden sich die Exporte des Kernels mit 733 Exporten aus 20 originalen QGKI-Modulen. Der Linux-Modullader weist eine zweite Definition zurück. Die gemessene Referenz aus Xiaomis Kernel und denselben 37 Modulen hat null Überschneidungen. Die sieben von rmnet_shs verwendeten Tracepoints kommen von rmnet_core. Das Symbol smartpa_type für den Audiotreiber stammt von aw882xx_dlkm.

M61 überlässt Audio, Kamera und die RMNET-Treiber den vorhandenen Stock-Modulen. Die übrigen Treiberpakete, darunter Display, Video und IPA, werden weiterhin über Kbuild gebaut. Das VEUX-Bauskript übergibt `VEUX_STOCK_VENDOR_MODULES=y`. Diese Make-Option gehört zu jedem Nachbau dieses Firmwareprofils. Die Prüfung liest Exporte und Versionsprüfsummen aus dem gelinkten Kernel-Image, prüft sie gegen Module.symvers und verfolgt die Abhängigkeiten aus Xiaomis modules.dep durch alle 37 Originaldateien. Der frühere M60-Befund ist unter Nachweise enthalten.

Der UFS-Treiber stellt zusätzlich dump_string_desc_serial, err_state und err_reason bereit. Der erste Eintrag zeigt die hexadezimalen Bytes des Seriennummerndeskriptors. Die beiden Fehleranzeigen liefern den Zähler und die letzten zehn tatsächlichen Gründe. Die Aufrufstellen und ihre Texte werden aus beiden fertigen Kernel-Images gelesen. Von den zehn Xiaomi-Speicheranzeigen ist hr weiterhin offen. Weitere Unterschiede, darunter Millet, sind separat zu prüfen.

## Bau und Prüfung

Der Workflow baut Image, Module und Gerätebaum in einem gemeinsamen Make-Aufruf. Clang und die unveränderlichen Eingaben werden zwischengespeichert und vor der Wiederverwendung geprüft. Für 37 Moduldateien und sechs Lade- und Metadatendateien liest er 24 gezielte Bereiche mit insgesamt 8.810.784 Bytes aus dem Original-OTA. Der zusätzliche Download für das Stock-Bootabbild erfolgt beim ersten Lauf. Der Gerätebericht stimmte für sämtliche 37 Moduldateien bytegenau mit dem ausgelieferten ROM überein.

Die Ausgabe BOOT-AK3-NOFLASH enthält das Boot-Prüfabbild und die zugehörige AK3-Prüfdatei. Der AK3-Test liest die Originalbasis und erzeugt eine reguläre Vergleichsdatei. Er ist für das unveränderte Xiaomi-boot.img ausgelegt. Die Tests simulieren beide Slots und drei ungültige Eingaben. Ein realer Start auf dem Poco und die Funktion der Hardware müssen am Gerät bestätigt werden. Eine Flash-Freigabe liegt nicht vor.
