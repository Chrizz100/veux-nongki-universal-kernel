#!/usr/bin/env python3
"""Restore the complete 44-commit SPF removal group on the authenticated R11 source.

All source changes are pinned. Build an isolated candidate and compare the
original 37-module QGKI cohort. No flashing or fabricated symbol CRCs.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
R11_ARCHIVE_SHA = '0dd3fd72701eb1f9a77ce6f9fbfc76bec8a18439b4002968d4d04523403658a7'
CONFIG_KEYS = {'CONFIG_ARCH_SUPPORTS_SPECULATIVE_PAGE_FAULT', 'CONFIG_SPECULATIVE_PAGE_FAULT'}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def helper():
    archive = ROOT / 'Dependencies/R11_MAIN.zip'
    require(sha(archive) == R11_ARCHIVE_SHA, 'R11_DEPENDENCY_CHANGED')
    dest = ROOT / 'runtime-r11'
    if not dest.exists():
        with zipfile.ZipFile(archive) as z:
            require(z.testzip() is None, 'R11_BAD_ZIP')
            for item in z.infolist():
                rel = Path(item.filename)
                require(not rel.is_absolute() and '..' not in rel.parts
                        and not (item.external_attr >> 16 & 0o170000) == 0o120000, 'UNSAFE_R11_ZIP')
            z.extractall(dest)
    module = load(dest / 'Tools/integrate_iommu.py', 'r12_r11_helper')
    module.verify_package()
    return module


def struct_tokens(text, name):
    text = re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S)
    start = re.search(r'\bstruct\s+' + re.escape(name) + r'\s*\{', text)
    require(start is not None, 'STRUCT_MISSING:' + name)
    depth = 1
    for pos in range(start.end(), len(text)):
        depth += (text[pos] == '{') - (text[pos] == '}')
        if not depth:
            return re.sub(r'\s+', '', text[start.start():pos + 1])
    raise ValueError('UNCLOSED_STRUCT:' + name)


def verify_package():
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts, 'UNSAFE_MANIFEST')
        require(sha(ROOT / rel) == digest, 'PACKAGE_FILE_CHANGED:' + name)
    require(sha(ROOT / 'Dependencies/R11_MAIN.zip') == R11_ARCHIVE_SHA, 'R11_DEPENDENCY_CHANGED')


def pins():
    return json.loads((ROOT / 'References/FINAL_R11_R12_FILE_PINS.json').read_text())


def apply_source(source):
    source = Path(source).resolve(strict=True)
    locked = pins()
    require(len(locked) == 34, 'SPF_FILE_SCOPE_CHANGED')
    for name, item in locked.items():
        path = source / name
        require(not path.is_symlink(), 'SYMLINK_SOURCE:' + name)
        require(all(not p.is_symlink() for p in path.parents if p != source.parent), 'SYMLINK_PARENT')
        if item['before_sha256'] is None:
            require(not path.exists(), 'NEW_FILE_ALREADY_EXISTS:' + name)
        else:
            require(path.is_file() and sha(path) == item['before_sha256'], 'PREIMAGE_CHANGED:' + name)
    patch = ROOT / 'References/RESTORE_FULL_SPF.patch'
    for flags in (['--check'], []):
        run = subprocess.run(['git', 'apply', '--whitespace=error', *flags, str(patch)],
                             cwd=source, capture_output=True, text=True)
        require(run.returncode == 0, 'SPF_PATCH_FAILED:' + run.stderr)
    for name, item in locked.items():
        require(sha(source / name) == item['after_sha256'], 'POSTIMAGE_CHANGED:' + name)
    actual = struct_tokens((source / 'include/linux/mm_types.h').read_text(), 'mm_struct')
    stock = struct_tokens((ROOT / 'References/STOCK_mm_types.h').read_text(), 'mm_struct')
    require(actual == stock, 'MM_STRUCT_STILL_DIFFERS_FROM_STOCK')
    return dict(changed_files=34, restored_removal_commits=44, mm_struct_matches_stock_tokens=True,
                compiled_abi_proven=False)


def config_values(text):
    result = {}
    for line in text.splitlines():
        enabled = re.fullmatch(r'(CONFIG_\w+)=(.*)', line)
        disabled = re.fullmatch(r'# (CONFIG_\w+) is not set', line)
        if enabled or disabled:
            key = enabled.group(1) if enabled else disabled.group(1)
            require(key not in result, 'DUPLICATE_KCONFIG:' + key)
            result[key] = enabled.group(2) if enabled else 'n'
    return result


def verify_config(before, after):
    delta = {key: [before.get(key), after.get(key)] for key in before.keys() | after.keys()
             if before.get(key) != after.get(key)}
    require(set(delta) == CONFIG_KEYS and all(after.get(key) == 'y' for key in CONFIG_KEYS),
            'UNEXPECTED_CONFIG_DELTA:' + repr(delta))
    return delta


def object_targets(baseline_objout):
    result = sorted(name[:-2] + '.o' for name in pins() if name.endswith('.c')
                    and (Path(baseline_objout) / (name[:-2] + '.o')).is_file())
    require({'arch/arm64/mm/fault.o', 'kernel/fork.o', 'mm/memory.o', 'mm/mmap.o'} <= set(result),
            'REQUIRED_BASELINE_OBJECTS_MISSING')
    return result


def build(args):
    verify_package()
    h = helper()
    r6 = load(Path(args.r6_tool), 'r12_r6_verifier')
    src = Path(args.source).resolve(strict=True)
    obj = Path(args.objout).resolve(strict=True)
    out = Path(args.output).resolve()
    ws = Path(os.environ['GITHUB_WORKSPACE']).resolve(strict=True)
    project = Path(args.project).resolve(strict=True)
    require(not out.exists() and out.is_relative_to(ws), 'OUTPUT_MUST_BE_NEW_IN_WORKSPACE')
    require(src.is_relative_to(ws) and obj.is_relative_to(ws)
            and not out.is_relative_to(src) and not out.is_relative_to(obj)
            and not out.is_relative_to(project) and not src.is_relative_to(project), 'UNSAFE_OUTPUT')
    base = json.loads(Path(args.r6_report).read_text())
    require(base['status'] == 'R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH', 'R6_NOT_GREEN')
    require(sha(obj / '.config') == h.CONFIG_SHA and sha(obj / 'Module.symvers') == h.SYMVERS_SHA,
            'R6_BASELINE_CHANGED')
    require(sha(obj / 'arch/arm64/boot/Image') == base['image_sha256'], 'R6_IMAGE_CHANGED')
    guards = {name: sha(obj / name) for name in ('.config', 'Module.symvers', 'arch/arm64/boot/Image')}
    expected, imports = h.references()
    r11_symbols = h.parse_symvers(h.ROOT / 'Reports/Module.symvers')
    _, _, baseline_counts = h.compare(r11_symbols, expected, imports)
    original_config = config_values((obj / '.config').read_text())
    commands = {row['target']: row['invocation'] for row in base['make_results']}
    require(set(commands) == {'Image', 'dtbs', 'modules'}, 'MISSING_BASELINE_MAKE_TARGETS')
    out.mkdir(parents=True)
    result = dict(status='R12_BUILD_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  flash_allowed=False, device_boot_tested=False, make_results=[],
                  baseline_r11_qgki_counts=baseline_counts)
    try:
        candidate = out / 'candidate-source'
        candidate_out = out / 'candidate-out'
        shutil.copytree(src, candidate, ignore=shutil.ignore_patterns('.git'), symlinks=True)
        candidate_out.mkdir()
        shutil.copyfile(obj / '.config', candidate_out / '.config')
        result['r11_iommu'] = h.apply_scoped(candidate, h.generated_patches())
        result['r11_dependencies'] = h.audit_dependencies(candidate)
        result['spf_source'] = apply_source(candidate)
        request = subprocess.run(['bash', str(candidate / 'scripts/config'), '--file',
                                  str(candidate_out / '.config'), '-e', 'SPECULATIVE_PAGE_FAULT'],
                                 capture_output=True, text=True)
        require(request.returncode == 0, 'SPF_CONFIG_REQUEST_FAILED:' + request.stderr)
        targets = ['olddefconfig'] + object_targets(obj) + ['Image', 'dtbs', 'modules']
        resolved_sha = None
        for target in targets:
            original = commands.get(target, commands['Image'])
            argv = list(original)
            require(argv[0] == 'make' and argv.count('-C') == 1
                    and argv[argv.index('-C') + 1] == str(src), 'INVALID_BASE_SOURCE_COMMAND')
            require(argv.count('O=' + str(obj)) == 1, 'INVALID_BASE_OUTPUT_COMMAND')
            argv[argv.index('-C') + 1] = str(candidate)
            argv[argv.index('O=' + str(obj))] = 'O=' + str(candidate_out)
            argv[-1] = target
            row = h.run_make(argv, out, target.replace('/', '_'), r6.pinned_llvm_tool_env(argv))
            row['target'] = target
            result['make_results'].append(row)
            require(row['exit_code'] == 0, 'ARM64_BUILD_FAILED:' + target)
            if target == 'olddefconfig':
                result['config_delta'] = verify_config(original_config,
                    config_values((candidate_out / '.config').read_text()))
                resolved_sha = sha(candidate_out / '.config')
            require(sha(candidate_out / '.config') == resolved_sha, 'CONFIG_DRIFT_DURING_BUILD')
        require(r6.is_arm64_image(candidate_out / 'arch/arm64/boot/Image')
                and r6.is_arm64_elf(candidate_out / 'vmlinux'), 'NOT_AN_ARM64_KERNEL')
        result['release'] = r6.verify_generated_release(candidate_out)
        result['rmnet_initcalls'] = r6.prove_real_linked_initcalls(candidate_out / 'System.map')
        result['real_build_log'] = r6.prove_build_log(out / 'Image.log')
        require(result['real_build_log']['linker_warning_free'], 'LINKER_WARNINGS')
        actual = h.parse_symvers(candidate_out / 'Module.symvers')
        rows, modules, counts = h.compare(actual, expected, imports)
        h.save_csv(out / 'QGKI_1423_SYMBOL_RESULTS.csv', rows)
        h.save_csv(out / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result.update(status='R12_FULL_ARM64_BUILD_AND_ABI_COMPARISON_COMPLETE_NOFLASH',
                      kernel_compiled=True, qgki_counts=counts,
                      module_layout_crc=actual.get('module_layout'),
                      fully_matching_modules=sum(row['fully_compatible'] for row in modules),
                      gained_matching_symbols=[name for name in expected
                          if r11_symbols.get(name) != expected[name] and actual.get(name) == expected[name]],
                      lost_matching_symbols=[name for name in expected
                          if r11_symbols.get(name) == expected[name] and actual.get(name) != expected[name]],
                      artifacts={name: sha(candidate_out / name) for name in
                                 ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux')})
    except Exception as error:
        result.update(status='R12_BUILD_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        result['r6_baseline_unchanged'] = all(sha(obj / name) == digest for name, digest in guards.items())
        write_json(out / 'R12_RESULT.json', result)
    require(result['r6_baseline_unchanged'], 'R6_BASELINE_MUTATED')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    patch = sub.add_parser('patch-source')
    patch.add_argument('--source', required=True)
    full = sub.add_parser('build')
    for name in ('source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        full.add_argument('--' + name, required=True)
    args = parser.parse_args()
    if args.operation == 'verify-package':
        verify_package()
        helper()
        print('R12_PACKAGE_AND_R11_DEPENDENCY=PASS')
    elif args.operation == 'patch-source':
        print(apply_source(Path(args.source)))
    else:
        build(args)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, subprocess.SubprocessError) as error:
        print('R12_BLOCKED:' + str(error), file=sys.stderr)
        sys.exit(1)
