from pathlib import Path
import importlib.util
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('spf', ROOT / 'Tools/restore_spf.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class SPFTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original_R11', self.source)

    def test_all_34_real_source_changes_and_stock_mm_struct(self):
        result = m.apply_source(self.source)
        self.assertEqual(result['changed_files'], 34)
        self.assertTrue(result['mm_struct_matches_stock_tokens'])
        self.assertIn('handle_speculative_fault', (self.source / 'arch/arm64/mm/fault.c').read_text())
        self.assertIn('mm_rb_lock', (self.source / 'include/linux/mm_types.h').read_text())

    def test_source_drift_is_rejected_before_writing(self):
        path = self.source / 'mm/memory.c'
        path.write_text(path.read_text() + '\n/* changed input */\n')
        before = {n: m.sha(self.source / n) for n in m.pins() if (self.source / n).exists()}
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_CHANGED'):
            m.apply_source(self.source)
        self.assertEqual(before, {n: m.sha(self.source / n) for n in before})

    def test_second_application_is_rejected(self):
        m.apply_source(self.source)
        with self.assertRaises(ValueError):
            m.apply_source(self.source)

    def test_only_two_spf_config_changes_are_allowed(self):
        before = {'CONFIG_QGKI': 'y', 'CONFIG_SCHED_WALT': 'y'}
        after = {**before, **dict.fromkeys(m.CONFIG_KEYS, 'y')}
        self.assertEqual(set(m.verify_config(before, after)), m.CONFIG_KEYS)
        after['CONFIG_ANDROID_KABI_RESERVE'] = 'n'
        with self.assertRaisesRegex(ValueError, 'UNEXPECTED_CONFIG_DELTA'):
            m.verify_config(before, after)

    def test_disabled_spf_is_not_accepted(self):
        with self.assertRaisesRegex(ValueError, 'UNEXPECTED_CONFIG_DELTA'):
            m.verify_config({}, {'CONFIG_ARCH_SUPPORTS_SPECULATIVE_PAGE_FAULT': 'y',
                                 'CONFIG_SPECULATIVE_PAGE_FAULT': 'n'})

    def test_complete_removal_group_is_recorded(self):
        commits = (ROOT / 'References/REMOVAL_SERIES.txt').read_text().splitlines()
        self.assertEqual(len(commits), 44)
        self.assertTrue(all(' Revert "' in line for line in commits))
        self.assertTrue(any('fix UAF with SPF' in line for line in commits))
        self.assertTrue(any('missing put_page()' in line for line in commits))

    def test_only_objects_active_in_real_baseline_are_requested(self):
        baseline = Path(self.temp.name) / 'objects'
        names = ['arch/arm64/mm/fault.o', 'kernel/fork.o', 'mm/memory.o', 'mm/mmap.o']
        for name in names:
            p = baseline / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b'baseline object')
        self.assertEqual(m.object_targets(baseline), sorted(names))
        self.assertNotIn('fs/userfaultfd.o', m.object_targets(baseline))


if __name__ == '__main__':
    unittest.main()
