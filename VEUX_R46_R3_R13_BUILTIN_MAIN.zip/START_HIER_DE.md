# VEUX R46-R3 – Historischer R13-Built-in-Patch auf rootfreiem R46-WALT

**NOFLASH / KEIN AK3 / KEINE GITHUB-WRITES AUS DEM WORKFLOW.**

## Warum dieser Test neu ist
Der historische R13-CASS-Kernel enthielt bereits eingebautes RMNET-SHS und Offload; seine originalen SHA-geprüften Kbuild-Postimages sind belegt. R46-R2 ist ein anderer, rootfreier WALT-Kernel mit beiden Treibern als separate .ko. Der hier ausgeführte GitHub-Versuch ist ausschließlich die Überprüfung der **genau gleichen zwei R13-Bauregeln** im vollständig neu gelinkten R46-WALT-Image.

## Dateien hochladen
1. `VEUX_R46_R3_R13_BUILTIN_MAIN.zip` unverändert nach `main/` (nicht entpacken).
2. `VEUX_R46_R3_ORIGINAL_R13_RMNET_BUILTIN_WALT_NOFLASH.yml` nach `.github/workflows/`.
3. GitHub Actions → `VEUX R46-R3 R13 original RMNET builtins on rootless WALT - NO FLASH` → Run workflow.

Die originale R46-R2-YAML und die ältere R46-R2-MAIN.zip bleiben unverändert im Repository; sie werden erneut als eingebaute, bereits nachgewiesene Vorprüfung verwendet. P13 und alte Artefakte ebenfalls nicht ändern.

## Was GitHub tut
- Alte R46-R2-Gates laufen mit unveränderten 26 historischen Source-Pins und bilden ihren eigenen vollständigen Image/vmlinux/DTB/6-Modul-Stand.
- Dessen bestehende Artefakte werden **vor** der neuen Veränderung hochgeladen.
- Nur in der flüchtigen Kernel-Source-Kopie werden zwei R13-Byte-historisch identische Quelländerungen gemacht: SHS-Kbuild `obj-m`→`obj-y`; Offload-Kbuild `obj-m`→`obj-y`. `KBUILD_EXTRA_SYMBOLS` bleibt ausdrücklich unverändert.
- Mit genau derselben Build-Toolchain und `make`-Argumentliste werden danach `Image`, `dtbs`, `modules` erneut gebaut und mit gesonderten SHA-256, `modules.order`, `modules.builtin` und `modules.builtin.modinfo` kontrolliert.
- Die übrigen vier `.ko` bleiben als externe Module vorgesehen; `CONFIG_MODULES=y` und `CONFIG_MODVERSIONS=y` bleiben erhalten.
- Jede falsche Preimage, fehlender Built-in-Nachweis, geänderte `.config` oder geänderter Release-String, fehlender Kernel-Link, falsches Modulziel führt zum CI-Fehlschlag. Keine grüne Diagnose bei fehlgeschlagenem Link.
- Das zusätzliche R47-Artefakt enthält Text-/JSON-Reports und Linker-Logs, kein Image, kein flashbares Paket. Die R46-Baseline-Artefakte bleiben getrennt.

## Kernelkennung
Die Xiaomi-OEM-Referenz **`5.4.274-qgki-g82179e362f33`** wird nicht verändert. Das experimentelle R46-Image wird **nicht künstlich als Stock ausgegeben**. Das Programm prüft ausdrücklich, dass dessen tatsächlicher `kernel.release` vor und nach der Änderung identisch ist.

## Grenze
Dieser Versuch beweist bei Erfolg nur den R46-WALT-Built-in-Link und die vier verbliebenen externen Module. **NICHT** die originalen Xiaomi-Vendor-CRC, den Bootvorgang, Modem-Internet, AK3, USB, SELinux-Runtime oder Flashfähigkeit. Keine CRC-Fälschung, kein Vendor-/P13-Schreibzugriff.

## Lokale Prüfungen
33+ Offline-Tests des Quell- und ABI-Schutzes; alle YAML-Bash-Blöcke werden vor Ort mit `bash -n` geprüft. Auf GitHub führen der gepinnte `actionlint` und ShellCheck den verbindlichen Green-Pass vor dem Kernbau aus. Eine reale zweite ARM64-WALT-Kompilierung ist erst durch diesen GitHub-Lauf überprüfbar.
