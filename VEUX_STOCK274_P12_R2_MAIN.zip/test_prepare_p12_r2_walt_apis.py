import copy
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import prepare_p12_r2_walt_apis as m


def make_donor():
    h='enum task_event {\n TASK_WAKE=2, TASK_MIGRATE=3, TASK_UPDATE=4, IRQ_UPDATE=5,\n};\nenum migrate_types { GROUP_TO_RQ, RQ_TO_GROUP, };\n'
    private='''enum sched_boost_policy { SCHED_BOOST_NONE, SCHED_BOOST_ON_BIG, SCHED_BOOST_ON_ALL };
#ifdef CONFIG_SCHED_WALT
struct walt_related_thread_group { int id; };
static inline int task_load(void *p) {return 5;}
static inline int task_related_thread_group(void *p) {return 1;}
static inline int task_rtg_high_prio(void *p) {return 1;}
static inline int walt_fixup_cum_window_demand(void *p, int v) {return v;}
static inline int early_detection_notify(void *p, int v) {return v;}
static inline int clear_reserved(void *p) {return 1;}
static inline int check_for_migration(void *p, int v) {return v;}
'''
    stat='''#ifdef CONFIG_SCHED_WALT
extern void sched_update_nr_prod(int cpu, long delta, bool inc);
extern unsigned int sched_get_cpu_util(int cpu);
#else
static inline void sched_update_nr_prod(int cpu, long delta, bool inc) {}
#endif
'''
    return {
      'include/linux/sched.h':('prefix\n'+h+'\n#if defined(CONFIG_HOTPLUG_CPU)\n'),
      'include/linux/sched/sysctl.h':'#define MAX_CLUSTERS 3\n/* MAX_MARGIN_LEVELS should be one less than MAX_CLUSTERS */\n#define MAX_MARGIN_LEVELS (MAX_CLUSTERS - 1)\n\nextern unsigned int sysctl_sched_latency;',
      'include/linux/sched/stat.h':stat+'\nstatic inline int sched_info_on(void) {}',
      'kernel/sched/sched.h':private+'\n#else   /* CONFIG_SCHED_WALT */\n'}

def make_before():
    v={p:b'' for p in m.R2_PATHS}
    v['include/linux/sched.h']=b'/* stuff */\n#define TASK_COMM_LEN\t\t\t16\n/* after */\n'
    v['include/linux/sched/sysctl.h']=b'extern int x;\n#ifdef CONFIG_SCHED_WALT\nextern unsigned int sysctl_sched_capacity_margin_up[MAX_MARGIN_LEVELS];\n#endif\n'
    v['include/linux/sched/stat.h']=b'extern unsigned long nr_iowait_cpu(int cpu);\nstatic inline int sched_info_on(void) {return 1;}\n'
    v['kernel/sched/sched.h']=b'''struct walt_rq { int x; };
struct walt_task_group { int x; };
#ifdef CONFIG_SPRD_ROTATION_TASK
DECLARE_PER_CPU_SHARED_ALIGNED(bool, cpu_reserved);
static inline bool is_reserved(int cpu) { return false; }
static inline u64 sched_ktime_clock(void) { return 9; }
#else
static inline bool is_reserved(int cpu)
{
return false;
}
static inline u64 sched_ktime_clock(void)
{
return sched_clock();
}
#endif
'''
    v['kernel/sched/core.c']=b'#include "sched.h"\n#include "pelt.h"\nextern int original;\n'
    v['kernel/sched/fair.c']=b'#include "sched.h"\n#include <trace/hooks/sched.h>\nextern int fair;\n'
    v['kernel/sched/rt.c']=b'#include "sched.h"\n#include "pelt.h"\nextern int rt;\n'
    v['kernel/sched/deadline.c']=b'#include "sched.h"\n#include "pelt.h"\nextern int deadline;\n'
    v['kernel/sched/stop_task.c']=b'#include "sched.h"\nextern int stop;\n'
    return v

class R2BridgeTests(unittest.TestCase):
    def setUp(self):
        self.donor={k:v.encode() for k,v in make_donor().items()}
        self.before=make_before()
    def after(self):return m.create_after(copy.deepcopy(self.before),self.donor)
    def test_01_exact_nine_modified_paths(self):self.assertEqual(set(self.after()),set(m.R2_PATHS))
    def test_02_events(self):self.assertIn('enum task_event {',self.after()['include/linux/sched.h'].decode())
    def test_03_migrate_enum(self):self.assertIn('GROUP_TO_RQ',self.after()['include/linux/sched.h'].decode())
    def test_04_margin_levels(self):self.assertIn('#define MAX_MARGIN_LEVELS (MAX_CLUSTERS - 1)',self.after()['include/linux/sched/sysctl.h'].decode())
    def test_05_margin_macro_gated(self):self.assertIn('#ifdef CONFIG_SCHED_WALT\n#define MAX_CLUSTERS',self.after()['include/linux/sched/sysctl.h'].decode())
    def test_06_stat_prototype(self):self.assertIn('extern void sched_update_nr_prod',self.after()['include/linux/sched/stat.h'].decode())
    def test_07_stat_off_stubs(self):self.assertIn('static inline void sched_update_nr_prod',self.after()['include/linux/sched/stat.h'].decode())
    def test_08_helpers(self):self.assertIn('struct walt_related_thread_group {',self.after()['kernel/sched/sched.h'].decode())
    def test_09_legacy_sprd_guard(self):self.assertIn('#error "P12: incompatible SPRD_ROTATION_TASK',self.after()['kernel/sched/sched.h'].decode())
    def test_10_legacy_stubs_config_walt_off(self):self.assertIn('#ifndef CONFIG_SCHED_WALT\nstatic inline bool is_reserved',self.after()['kernel/sched/sched.h'].decode())
    def test_11_single_walt_guard_after_helpers(self):
        s=self.after()['kernel/sched/sched.h'].decode();h=s[s.index('enum sched_boost_policy {'):];self.assertNotIn('#ifdef CONFIG_SCHED_WALT',h)
    def test_12_core_include(self):self.assertIn('#include "walt/walt.h"',self.after()['kernel/sched/core.c'].decode())
    def test_13_fair_include(self):self.assertIn('#include "walt/walt.h"',self.after()['kernel/sched/fair.c'].decode())
    def test_14_rt_include(self):self.assertIn('#include "walt/walt.h"',self.after()['kernel/sched/rt.c'].decode())
    def test_15_deadline_include(self):self.assertIn('#include "walt/walt.h"',self.after()['kernel/sched/deadline.c'].decode())
    def test_16_stop_include(self):self.assertIn('#include "walt/walt.h"',self.after()['kernel/sched/stop_task.c'].decode())
    def test_17_roundtrip(self):
        after=self.after();patch=m.patch_between(self.before,after);m.roundtrip(self.before,after,patch)
    def test_18_patch_names(self):
        s=m.patch_between(self.before,self.after());self.assertEqual(s.count('diff --git'),9)
    def test_19_negative_existing_enum(self):
        self.before['include/linux/sched.h']+=b'enum task_event { };\n'
        with self.assertRaisesRegex(ValueError,'EVENT_ALREADY_EXISTS'):self.after()
    def test_20_negative_existing_margin(self):
        self.before['include/linux/sched/sysctl.h']+=b'#define MAX_MARGIN_LEVELS 2\n'
        with self.assertRaisesRegex(ValueError,'MARGINS_ALREADY_DEFINED'):self.after()
    def test_21_negative_existing_include(self):
        self.before['kernel/sched/fair.c']+=b'#include "walt/walt.h"\n'
        with self.assertRaisesRegex(ValueError,'ALREADY_PRESENT'):self.after()
    def test_22_negative_bad_sprd(self):
        self.before['kernel/sched/sched.h']=b'not a Positron tail'
        with self.assertRaisesRegex(ValueError,'SPRD_TAIL_NOT_FOUND'):self.after()
    def test_23_negative_missing_rq(self):
        self.before['kernel/sched/sched.h']=b'no rotation support'
        with self.assertRaises(ValueError):self.after()
    def test_24_negative_missing_donor_stats(self):
        self.donor['include/linux/sched/stat.h']=b'invalid'
        with self.assertRaisesRegex(ValueError,'DONOR_DRIFT'):self.after()
    def test_25_negative_missing_donor_helpers(self):
        self.donor['kernel/sched/sched.h']=b'broken'
        with self.assertRaisesRegex(ValueError,'DONOR_DRIFT'):self.after()
    def test_26_negative_missing_donor_events(self):
        self.donor['include/linux/sched.h']=b'broken'
        with self.assertRaisesRegex(ValueError,'DONOR_DRIFT'):self.after()
    def test_27_negative_duplicate_anchor(self):
        self.before['kernel/sched/core.c']+=b'#include "pelt.h"\n'
        with self.assertRaisesRegex(ValueError,'ANCHOR_DRIFT'):self.after()
    def test_28_negative_wrong_paths(self):
        self.before.pop('kernel/sched/core.c')
        with self.assertRaisesRegex(ValueError,'INPUT_SCOPE_DRIFT'):self.after()
    def test_29_donor_blob_pin(self):self.assertEqual(m.DONOR_BLOBS['kernel/sched/sched.h'],'b5bdfa2df156cf40b368e73751eac8d71b99de55')
    def test_30_staging_tree_pin(self):self.assertEqual(m.P11_TREE,'04e3831b70ed3ba19a7bd59e3054b7df5418941d')
    def test_31_oem_scope_excluded(self):self.assertFalse(any('/walt/' in p for p in m.R2_PATHS))
    def test_32_sha_deterministic(self):self.assertEqual(m.sha(b'abc'),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
    def test_33_blob_hash_deterministic(self):self.assertEqual(len(m.oid(b'abc')),40)
    def test_34_patch_deterministic(self):
        self.assertEqual(m.patch_between(self.before,self.after()),m.patch_between(self.before,self.after()))
    def test_35_no_unexpected_output(self):self.assertEqual(len(self.after()),9)
    def test_36_negative_existing_stat(self):
        self.before['include/linux/sched/stat.h']+=b'void sched_update_nr_prod();'
        with self.assertRaisesRegex(ValueError,'SCHED_STAT_ALREADY_ADDED'):self.after()
    def test_37_negative_missing_enum_value(self):
        self.donor['include/linux/sched.h']=self.donor['include/linux/sched.h'].replace(b'IRQ_UPDATE',b'BAD_EVENT')
        with self.assertRaisesRegex(ValueError,'EVENT_DEFS_WRONG'):self.after()
    def test_38_negative_unexpected_header(self):
        self.before['kernel/sched/sched.h']+=b'\nstruct walt_related_thread_group {};'
        with self.assertRaisesRegex(ValueError,'SCHED_HELPERS_ALREADY_ADDED'):self.after()

if __name__=='__main__':unittest.main()
