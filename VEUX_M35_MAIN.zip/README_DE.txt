VEUX M35 - BQ-Adapterfehler - NOFLASH
Basis: gruener M34-Lauf 43748968131, Commit 00cda1a6db647a02babba6935fcc982324a3ca0d.

UPLOAD AM SMARTPHONE
1. VEUX_M35_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M35_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M34 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256 und komplette ZIP-CRC geprueft:
996 Dateien, 918 Textdateien, 248 JSON-Dateien, 36.689.112 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M34 unabhaengig geprueft:
echte Quellen, LLVM-Objekt/CFI-Kommando, verlinkte Fehlerzweige, 40 erfolgreiche
make-Aufrufe, eingebettete Konfiguration in Image/vmlinux und Exporttabelle.
Import-CRCs neu berechnet: 1.423 passend, keine CRC-Abweichung, kein fehlender
Export und 37 passende Module der bekannten Stock-Vendor-Kohorte.
Boot.img und AK3 byteidentisch aus gepinnten Referenzen rekonstruiert;
AVB und Stock-Ramdisk/Paar geprueft. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M34. Reports/RUN43748968131_32_ARTEFAKTE.zip und
Reports/M34_INDEPENDENT_VERIFICATION.json enthalten die Auswertung.
Kein Geraetetest: Static Boot Pass ist kein Device Pass.

M35 REPARATUR
Nur adapter_in_workfunc und adapter_out_workfunc werden gegenueber M34 geaendert.
Adapter-In prueft ADC-Start, Register-Setter, GPIO-Umschaltung und Fehler des
CDP-Kapazitaetsabrufs. Der erste Fehler beendet abhaengige Konfiguration.
Die abschliessende Benachrichtigung und die erneute Monitorplanung bleiben
aktiv; ein fehlender USB-Provider wird dort abgefangen. Bereits ausgefuehrte
Hardware-Schritte werden nicht zurueckgerollt. Fehler werden begrenzt protokolliert.
Adapter-Out versucht beide unabhaengigen Ruecksetzungen (500 mA und 4.400 mV)
auch nach dem ersten Fehler und meldet den ersten Fehler unveraendert.
Die erfolgreichen Hardware-Ablaufreihenfolgen und bisherigen Werte bleiben gleich.
Keine neue Defconfig, keine Strom-/Spannungsschwelle, kein neuer Geraetezustand.
Alle bisherigen Reparaturen bleiben enthalten. Beide Header sind byteidentisch;
bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-Zeilenumbruch.

BEWUSSTE GRENZEN
Monitor-/Temperaturcode und SDP-VINDPM-Helfer bleiben byteidentisch.
Die neue SDP-Fehlerinjektion umfasst den Konfigurationsabschnitt vor diesem
Helfer, nicht alle internen Fehler seines bestehenden Wiederherstellungsablaufs.
Der bisherige Fallback bei fehlendem Batterie-Provider bleibt erhalten.
Dies serialisiert keine parallelen Adapterarbeiten und garantiert keine atomare
Hardware-Wiederherstellung nach einem Busfehler. Provider-Abhaengigkeiten,
Monitor und Temperaturpfade benoetigen eine eigene weitere Pruefung.

LOKALE PRUEFUNGEN
35 M35-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Der neue native Test verwendet echte Worker und Register-/GPIO-Helfer:
9.128 C-Assertions, 130 Erfolgs-/Null-Provider-Faelle und 2.462 injizierte Fehler.
Er prueft Abbruch abhaengiger Konfiguration, erhaltene Monitorplanung, beide
unabhaengigen Unplug-Resets und Shutdown-Guards. Alte M34-Fehler sind reproduziert;
die neue Fehlererwartung weist den alten Code zurueck.
Alle aktuellen nativen Tests zusammen: 66.653 C-Assertions; dazu 156 Assertions
des unveraenderten Probetests auf der M31-Referenz.
Der komplette Treiber kompiliert fuer ARM64 mit gepinntem AOSP Clang 12.0.5,
CFI/ThinLTO und den Headern des aktuellen M34-Laufs.
Kein vollstaendiger lokaler M35-Kernelbau und kein Test am Geraet.

CI UND OFFENE ARBEIT
Alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue BQ-Schicht nutzt weiter den authentischen M28-R2-Baukern mit allen
Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M35 muss neue
Quellen, LLVM-Objekt, CFI-Kommando, acht verlinkte Schnittstellen und beide neuen
Adapter-Fehlerzweige in Image UND vmlinux nachweisen. Konfiguration und komplette
Exporttabelle muessen unveraendert bleiben. Boot.img/AK3 erst nach diesen Gates.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M35-GitHub-Bau und Auswertung aller Artefakte, danach
Monitor-/Temperatur- und Versorgungspfade. Kein Vollvergleich aller historischen
ueber 7.100 Quellabweichungen und kein universeller GKI-Nachweis.
Geraeteboot, Laden, OTG, Suspend, Shutdown und Wiederherstellung sind ungetestet.
Device Pass NEIN. Flashfreigabe NEIN.
