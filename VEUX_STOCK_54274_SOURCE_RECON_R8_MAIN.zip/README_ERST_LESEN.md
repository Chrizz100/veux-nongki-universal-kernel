# VEUX Stock 5.4.274 – IOMMU/ION-Quellfamilienabgleich R8 (NOFLASH)

**Ziel:** Die abweichenden `struct device`- und ION-Schnittstellen des Spenderkernels gemeinsam behandeln, statt die Stock-`device.h` isoliert zu ersetzen. Die letzte erfolgreich kompilierte Referenz bleibt R6 (`Module.symvers`, nicht bootgetestet).

## Quellen – unveränderlich gepinnt

- Ursprünglicher Spenderkernel: dereference23/kernel_xiaomi_sm6375, Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`, Linux 5.4.268.
- Alternative Qualcomm-IOMMU-Implementierung: shandongtlb/kernel_xiaomi_sm8350_M11, Commit `01cb3a8824b7b4caf3e3540274e71abba5ade538`, Linux 5.4.61, `drivers/iommu/msm_dma_iommu_mapping.c`, Blob `a23aa9a48c40ceb98ac30c798cbd5ef0a86317d6`. Diese Quelle **ist nicht** als identischer Xiaomi-Stock-Quellstand belegt.
- Drei Stock-Header mit einzeln überprüfter SHA-256-Prüfsumme aus der ursprünglichen Stock-5.4.274-kheaders-Aufnahme: `include/linux/device.h`, `include/linux/ion.h`, `include/linux/msm_dma_iommu_mapping.h`.
- Unveränderte R6-ABI-Beweisdaten aus dem bestehenden R7-MAIN-Paket, 14.648 historische Importvorkommen über QGKI/GKI (keine belegte aktive Modulgruppe).
- Android Clang 11.0.2 aus exakt verifiziertem AOSP-Git-Tree.

## Nur im isolierten Test-Arbeitsbaum

1. Die drei originalen Stock-Header werden als zusammengehörige Schnittstellen eingesetzt.
2. Der alternative Qualcomm-IOMMU-Treiber übernimmt die bufferbasierte globale Zuordnung und verwendet keine nicht existierenden `dev->iommu_map_list`/`dev->iommu_map_lock`-Felder.
3. Die zwei dazu nicht mehr passenden Initialisierungen aus `drivers/base/core.c` werden entfernt.
4. In `drivers/staging/android/ion/ion_buffer.c` entfallen zwei Initialisierungen des im Stock-`ion.h` nicht vorhandenen `iommu_data`-Feldes.
5. Die ION-Aufrufstellen in `ion_dma_buf.c` und `heaps/msm_ion_dma_buf.c` werden streng an fest überprüften Quellankern von `container_of(dmabuf->priv,...,iommu_data)` auf `dmabuf->priv` umgestellt; der Freigabeaufruf erhält `buffer` statt `&buffer->iommu_data`.
6. Neuer Compiler-Test; nur bei erfolgreicher Kompilierung erfolgt ein Delta-Vergleich der neuen `Module.symvers` gegen R6. Alle Quelländerungen sind diagnostisch, nicht produktionsfreigegeben.

## Warum dies noch kein funktionierender Stock-Kernel ist

Das Transplantat stammt von einem anderen Qualcomm-Gerät mit älterem 5.4-Kernel. Trotz formal passender Schnittstelle ist die Laufzeitsicherheit (IOMMU-Locking, DMA-Mappings, ION-Freigaben, Performance), Treiberverfügbarkeit, `module_layout`-Kompatibilität und Bootfähigkeit **nicht** bewiesen. Deshalb werden **kein** `boot.img`, **kein** AnyKernel3-ZIP und **kein** flashbares Image ausgegeben. Keine CRC-Fälschung, kein Deaktivieren von QCOM_LAZY_MAPPING, keine erzwungenen Modul-Loads. Die Workflow-Tests können erfolgreich sein, auch wenn der isolierte Compiler-Probelauf scheitert – der echte Exit-Code steht im Artefakt.

## Ausgabedateien

`R8_PAIRED_SOURCE_PROVENANCE.json`, `R8_PAIRED_IOMMU_ABI_RESULT.json`, `R8_..._BUILD.log`, `R8_TESTS.log`, bei erfolgreichem Build `R8_COMPILED_Module.symvers` und QGKI-/GKI-Modul-/Symbol-Deltas. Die ursprüngliche Donorquelle und der Repo-Inhalt bleiben unverändert.

Die R1-, R2-, R4-, R5-, R6- und R7-MAIN-ZIPs im Repository-Hauptverzeichnis müssen bestehen bleiben.
