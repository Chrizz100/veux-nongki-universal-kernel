"""R8 regression tests: strict provenance and no guessed ABI fixes."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

spec=importlib.util.spec_from_file_location('r8',str(Path(__file__).with_name('r8_iommu_pair.py')))
r8=importlib.util.module_from_spec(spec);spec.loader.exec_module(r8)

SAMPLE_ION='''struct ion_buffer *buffer = container_of(dmabuf->priv, typeof(*buffer),
                                         iommu_data);
struct ion_buffer *buffer = container_of(attachment->dmabuf->priv,
                                         typeof(*buffer), iommu_data);
'''

class R8SourcePairTests(unittest.TestCase):
    def test_pinned_source_revisions(self):
        self.assertEqual(len(r8.DONOR_SHA),40)
        self.assertEqual(len(r8.PAIR_SHA),40)
        self.assertEqual(r8.PAIR_RELEASE,'5.4.61')
    def test_three_genuine_stock_headers(self):
        self.assertEqual(len(r8.STOCK_HEADERS),3)
        self.assertEqual(r8.STOCK_HEADERS['include/linux/device.h'][1],44309)
    def test_no_stock_header_claim_is_fake(self):
        self.assertEqual(len(r8.STOCK_HEADERS['include/linux/ion.h'][0]),64)
    def test_provider_only_one_source_file(self):
        self.assertEqual(list(r8.PAIR_FILES),['drivers/iommu/msm_dma_iommu_mapping.c'])
    def test_patch_base_core_exact(self):
        s='before\n\tINIT_LIST_HEAD(&dev->iommu_map_list);\n\tmutex_init(&dev->iommu_map_lock);\nafter\n'
        self.assertEqual(r8.patch_base_core(s),'before\nafter\n')
    def test_patch_base_rejects_nonmatch(self):
        with self.assertRaises(ValueError):r8.patch_base_core('void device_initialize(void) {}')
    def test_patch_base_rejects_repeats(self):
        s='\tINIT_LIST_HEAD(&dev->iommu_map_list);\n\tmutex_init(&dev->iommu_map_lock);\n'
        with self.assertRaises(ValueError):r8.patch_base_core(s+s)
    def test_patch_ion_buffer_exact(self):
        s='start\n\tINIT_LIST_HEAD(&buffer->iommu_data.map_list);\n\tmutex_init(&buffer->iommu_data.lock);\nend\n'
        self.assertEqual(r8.patch_ion_buffer(s),'start\nend\n')
    def test_patch_ion_buffer_missing_rejected(self):
        with self.assertRaises(ValueError):r8.patch_ion_buffer('')
    def test_regex_handles_both_ion_priv_forms(self):
        match=r8.MSM_CONTAINER.findall(SAMPLE_ION)
        self.assertEqual(match,['dmabuf->priv','attachment->dmabuf->priv'])
    def test_ion_dma_refuses_incomplete_anchors(self):
        with self.assertRaises(ValueError):r8.patch_ion_dma(SAMPLE_ION)
    def test_ion_dma_valid_exact_15(self):
        s=SAMPLE_ION*7+'struct ion_buffer *buffer = container_of(dmabuf->priv, typeof(*buffer), iommu_data);\nexp_info.priv = &buffer->iommu_data;'
        out=r8.patch_ion_dma(s)
        self.assertEqual(out.count('container_of'),0)
        self.assertIn('exp_info.priv = buffer;',out)
        self.assertNotIn('iommu_data',out)
    def test_msm_ion_exact_15_release(self):
        s=SAMPLE_ION*7+'struct ion_buffer *buffer = container_of(dmabuf->priv, typeof(*buffer), iommu_data);\nmsm_dma_buf_freed(&buffer->iommu_data);'
        out=r8.patch_ion_dma(s,True)
        self.assertIn('msm_dma_buf_freed(buffer);',out)
        self.assertNotIn('iommu_data',out)
    def test_msm_ion_no_wrong_release(self):
        s=SAMPLE_ION*7+'struct ion_buffer *buffer = container_of(dmabuf->priv, typeof(*buffer), iommu_data);'
        with self.assertRaises(ValueError):r8.patch_ion_dma(s,True)
    def test_errors_separate_transport(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'build.log';f.write_text('LLVM ERROR: IO failure on output stream: Broken pipe\nfoo.c:5:2: error: bad\n')
            errors,pipes,lines=r8.parse_errors(f)
            self.assertEqual(len(errors),1)
            self.assertEqual(pipes,1)
            self.assertEqual(lines,2)
    def test_compiler_failure_never_claims_abi(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d)
            ref={'schema':'VEUX_STOCK_R6_CANDIDATE_ABI_EVIDENCE',
                 'candidate_symvers_sha256':r8.R6_SYMVERS_SHA,
                 'candidate_image_sha256':r8.R6_IMAGE_SHA}
            (d/'base.json').write_text(json.dumps(ref))
            (d/'base.symvers').write_bytes(b'error not needed')
            # Pin validation should reject false Module.symvers, even when compile failed.
            (d/'rc').write_text('2')
            (d/'log').write_text('driver.c:15:3: error: no type\n')
            from types import SimpleNamespace
            a=SimpleNamespace(baseline_report=d/'base.json',baseline_symvers=d/'base.symvers',
                              return_code=d/'rc',build_log=d/'log',reports=d,
                              r6_tool='-',imports='-',candidate_symvers='-',image='-')
            with self.assertRaisesRegex(ValueError,'R6_SYMVERS_PIN_DRIFT'):r8.summary(a)
    def test_module_orig_hashes_40_chars(self):
        self.assertTrue(all(len(s)==40 for s in r8.DONOR_FILES.values()))
    def test_no_magic_crc_patch(self):
        src=Path(__file__).with_name('r8_iommu_pair.py').read_text()
        self.assertNotIn('force_load(',src)
        self.assertNotIn('crc_override(',src)
        self.assertIn("'flash_allowed':False",src)
    def test_stock_header_tar_sha(self):
        self.assertEqual(len(r8.STOCK_HEADERS_TAR_SHA),64)

if __name__=='__main__':unittest.main()
