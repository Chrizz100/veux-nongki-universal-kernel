#!/usr/bin/env python3
"""R8 read-only source-pair diagnostic: exact stock headers and pinned vendor IOMMU implementation.

Never a production patch. Source and ABI provenance checked, no flash output.
"""
import argparse
import csv
import hashlib
import importlib.util
import io
import json
import re
import subprocess
import tarfile
from collections import Counter
from pathlib import Path

DONOR_SHA = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
PAIR_SHA = '01cb3a8824b7b4caf3e3540274e71abba5ade538'
PAIR_SOURCE = 'shandongtlb/kernel_xiaomi_sm8350_M11'
PAIR_RELEASE = '5.4.61'
R6_SYMVERS_SHA = 'd0cce8b3920dd22ab6eafc6c68e6bfb6dd1e4635835e2d6c4a5ad798bf0761e3'
R6_IMAGE_SHA = 'c54cb61c6bc1b1f815ce9a3ded00c698aeb6ce67467fbceeb9e4c2596ed71416'
R28_IMPORTS_SHA = 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394'
STOCK_HEADERS_TAR_SHA = '39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279'
STOCK_HEADERS = {
    'include/linux/device.h':('dc28c43819628f359cc3776b53a4b0a09e4cc99e321d08d25b23ab81df6eb027',44309),
    'include/linux/ion.h':('4488aee19289dba76ab23cfd46c64aa8c8ddec37c12048faec27ff460f42534f',4498),
    'include/linux/msm_dma_iommu_mapping.h':('9394f06ede665497ab41652e354683e384ee78bc1c39f2ff2659ea39f6638a54',2177),
}
PAIR_FILES = {
    'drivers/iommu/msm_dma_iommu_mapping.c':'a23aa9a48c40ceb98ac30c798cbd5ef0a86317d6',
}
DONOR_FILES = {
    'drivers/base/core.c':'777cfffd26336bb8f1a7edf06e5d8a30fb914133',
    'drivers/staging/android/ion/ion_buffer.c':'062dc9e3b9903f17966ece0765cf94d8e3e6061f',
    'drivers/staging/android/ion/ion_dma_buf.c':'88dc7815b5cad281b2a90d8f1bd2107398eb264d',
    'drivers/staging/android/ion/heaps/msm_ion_dma_buf.c':'20909a97a7dbd5599bb3613d234bc1cc691d4f8c',
    'include/linux/device.h':'3937c1c06f9c152e6272743d1536303b9eea09df',
    'include/linux/ion.h':'256da705bffe8b6f2450a1952fc677d429ec30dc',
    'include/linux/msm_dma_iommu_mapping.h':'8db505249af57fb2207f54fac01d693f6baa6ce0',
    'drivers/iommu/msm_dma_iommu_mapping.c':'885a87f839e22ed52c5f09a0ce8a8d778324397c',
}
MSM_CONTAINER = re.compile(r'container_of\(\s*(dmabuf->priv|attachment->dmabuf->priv)\s*,\s*typeof\(\*buffer\)\s*,\s*iommu_data\s*\)')


def sha(data):return hashlib.sha256(data).hexdigest()
def file_sha(p):return sha(Path(p).read_bytes())
def git(repo,*args):
    r=subprocess.run(['git','-C',str(repo),*args],check=True,capture_output=True,text=True)
    return r.stdout.strip()


def stock_headers(reference):
    arc=Path(reference)/'reference/stock_kheaders.tar.xz'
    if arc.is_symlink() or not arc.is_file() or file_sha(arc)!=STOCK_HEADERS_TAR_SHA:
        raise ValueError('STOCK_KHEADERS_ARCHIVE_DRIFT')
    found={}
    with tarfile.open(arc,'r:xz') as t:
        for m in t:
            key=m.name.removeprefix('./')
            if key in STOCK_HEADERS:
                if key in found or not m.isfile() or m.size!=STOCK_HEADERS[key][1]:
                    raise ValueError('STOCK_HEADER_MEMBER_UNSAFE:'+key)
                raw=t.extractfile(m).read()
                if sha(raw)!=STOCK_HEADERS[key][0]:raise ValueError('STOCK_HEADER_SHA_DRIFT:'+key)
                found[key]=raw
    if set(found)!=set(STOCK_HEADERS):raise ValueError('MISSING_STOCK_HEADERS')
    c=(Path(reference)/'reference/stock.config').read_text()
    if 'CONFIG_QCOM_LAZY_MAPPING=y' not in c or 'CONFIG_SCHED_WALT=y' not in c:
        raise ValueError('STOCK_CONFIG_EXPECTATION_DRIFT')
    return found


def patch_exact(text, old, new, count, label):
    if text.count(old)!=count:raise ValueError('UNEXPECTED_ANCHOR_'+label)
    return text.replace(old,new)


def patch_base_core(t):
    return patch_exact(t, '\tINIT_LIST_HEAD(&dev->iommu_map_list);\n\tmutex_init(&dev->iommu_map_lock);\n', '',1,'BASE_CORE')


def patch_ion_buffer(t):
    return patch_exact(t, '\tINIT_LIST_HEAD(&buffer->iommu_data.map_list);\n\tmutex_init(&buffer->iommu_data.lock);\n','',1,'ION_BUFFER')


def patch_ion_dma(t, msm=False):
    # The original Qualcomm ION sources used dmabuf->priv = &buffer->iommu_data.
    # The stock ABI and paired IOMMU source instead use dmabuf->priv = buffer.
    hits=MSM_CONTAINER.findall(t)
    target=15
    if len(hits)!=target:raise ValueError('ION_CONTAINER_COUNT_DRIFT:'+str((len(hits),msm)))
    t=MSM_CONTAINER.sub(lambda m:m.group(1),t)
    if msm:
        t=patch_exact(t,'msm_dma_buf_freed(&buffer->iommu_data);','msm_dma_buf_freed(buffer);',1,'MSM_ION_RELEASE')
    else:
        t=patch_exact(t,'exp_info.priv = &buffer->iommu_data;', 'exp_info.priv = buffer;',1,'ION_EXPORT_PRIV')
    if 'iommu_data' in t:raise ValueError('ION_OLD_LAYOUT_STILL_REFERENCED')
    return t


def assert_repo(repo,head,name):
    if not Path(repo).is_dir() or git(repo,'rev-parse','HEAD')!=head:
        raise ValueError(name+'_HEAD_DRIFT')


def stage(args):
    src,work,upstream=map(lambda x:Path(x).resolve(),(args.donor,args.stage,args.pair))
    if len({str(src),str(work),str(upstream)})!=3 or src in work.parents or work in src.parents:
        raise ValueError('STAGE_PATH_OVERLAP')
    assert_repo(src,DONOR_SHA,'DONOR')
    assert_repo(work,DONOR_SHA,'WORKTREE')
    assert_repo(upstream,PAIR_SHA,'PAIR_SOURCE')
    if git(src,'status','--porcelain'):raise ValueError('ORIGINAL_DONOR_DIRTY')
    mk=(upstream/'Makefile').read_text().splitlines()[:5]
    if not all(x in '\n'.join(mk) for x in ('VERSION = 5','PATCHLEVEL = 4','SUBLEVEL = 61')):
        raise ValueError('PAIR_VERSION_DRIFT')
    original=stock_headers(args.r1)
    # Check every source file, both in pristine donor and in isolated worktree.
    for path,blob in DONOR_FILES.items():
        if git(src,'rev-parse','HEAD:'+path)!=blob:raise ValueError('DONOR_BLOB_DRIFT:'+path)
        for root in (src,work):
            fp=root/path
            if fp.is_symlink() or not fp.is_file() or git(root,'hash-object',str(fp))!=blob:
                raise ValueError('DONOR_FILE_OR_STAGE_DRIFT:'+path)
    for path,blob in PAIR_FILES.items():
        if git(upstream,'rev-parse','HEAD:'+path)!=blob:
            raise ValueError('PAIR_BLOB_DRIFT:'+path)
        p=upstream/path
        if p.is_symlink() or not p.is_file() or git(upstream,'hash-object',str(p))!=blob:
            raise ValueError('PAIR_FILE_DRIFT:'+path)
    staged={}
    for path,data in original.items():staged[path]=data
    for path,fn in (
        ('drivers/base/core.c',patch_base_core),
        ('drivers/staging/android/ion/ion_buffer.c',patch_ion_buffer),
        ('drivers/staging/android/ion/ion_dma_buf.c',lambda s:patch_ion_dma(s,False)),
        ('drivers/staging/android/ion/heaps/msm_ion_dma_buf.c',lambda s:patch_ion_dma(s,True)),
    ):
        staged[path]=fn((work/path).read_text()).encode()
    staged.update({p:(upstream/p).read_bytes() for p in PAIR_FILES})
    # Confirm original source call sites are absent; no attempt to provide fake fields.
    for path,data in staged.items():
        if path.startswith('drivers/') and (b'->iommu_map_list' in data or b'->iommu_map_lock' in data or b'->iommu_data' in data):
            raise ValueError('REMNANT_INCOMPATIBLE_FIELD:'+path)
    for path,data in staged.items():
        fp=work/path
        fp.write_bytes(data)
        if file_sha(fp)!=sha(data):raise ValueError('COPY_VALIDATION_FAILED:'+path)
    if git(src,'status','--porcelain'):
        raise ValueError('ORIGINAL_DONOR_TOUCHED')
    summary={'schema':'VEUX_STOCK_R8_PAIRED_SOURCE_STAGE','donor_commit':DONOR_SHA,
        'pair_source':PAIR_SOURCE,'pair_source_commit':PAIR_SHA,'pair_source_release':PAIR_RELEASE,
        'files':{p:sha(b) for p,b in sorted(staged.items())},
        'source_file_count':len(staged),'qcom_lazy_mapping_remains_enabled':True,
        'production_source_patch_approved':False,'module_abi_verified':False,
        'runtime_iommu_locking_verified':False,'flash_allowed':False}
    out=Path(args.reports);out.mkdir(parents=True,exist_ok=True)
    (out/'R8_PAIRED_SOURCE_PROVENANCE.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'staged_files':len(staged),'provider':PAIR_SOURCE,'production_patch':False,'flash_allowed':False}))


def parse_errors(log):
    lines=Path(log).read_text(errors='replace').splitlines()
    err=[s for s in lines if 'LLVM ERROR: IO failure on output stream: Broken pipe' not in s and re.search(r'(?:fatal error:|\berror:|undefined reference|ld\.lld: error:)',s,re.I)]
    return err, sum('LLVM ERROR: IO failure on output stream: Broken pipe' in s for s in lines),len(lines)


def summary(args):
    report=json.loads(Path(args.baseline_report).read_text())
    if report.get('schema')!='VEUX_STOCK_R6_CANDIDATE_ABI_EVIDENCE' or report.get('candidate_symvers_sha256')!=R6_SYMVERS_SHA or report.get('candidate_image_sha256')!=R6_IMAGE_SHA:
        raise ValueError('R6_BASELINE_IDENTITY_DRIFT')
    if file_sha(args.baseline_symvers)!=R6_SYMVERS_SHA:raise ValueError('R6_SYMVERS_PIN_DRIFT')
    rc=int(Path(args.return_code).read_text().strip())
    err,pipes,lines=parse_errors(args.build_log)
    d={'schema':'VEUX_STOCK_R8_PAIRED_IOMMU_ABI_EXPERIMENT','build_exit_code':rc,
       'compiler_errors':err[:80],'compiler_error_count':len(err),'llvm_broken_pipe_count':pipes,
       'build_log_lines':lines,'oem_abi_green':False,'production_patch_approved':False,
       'stock_54274_source_reproduced':False,'flash_allowed':False,
       'source_lineage':'pinned donor 5.4.268 + three genuine stock headers + pinned vendor IOMMU implementation 5.4.61 + minimal ION consumers',
       'abi_compared':False,'active_module_cohort_verified':False}
    if rc==0 and not err:
        spec=importlib.util.spec_from_file_location('r6_abi',str(Path(args.r6_tool).resolve()))
        if spec is None or spec.loader is None:raise ValueError('R6_ABI_TOOL_MISSING')
        r6=importlib.util.module_from_spec(spec);spec.loader.exec_module(r6)
        if r6.R28_SOURCE_SHA!=R28_IMPORTS_SHA:raise ValueError('IMPORT_EVIDENCE_DRIFT')
        baseline,base_count=r6.parse_symvers(args.baseline_symvers)
        candidate,candidate_count=r6.parse_symvers(args.candidate_symvers)
        imports=r6.parse_imports(args.imports)
        if base_count!=report['candidate_symvers_exports'] or baseline.get('module_layout')!={'0xcfa46a10'}:
            raise ValueError('R6_MODULE_LAYOUT_DRIFT')
        d['abi_compared']=True
        d['candidate_exports']=candidate_count
        d['candidate_symvers_sha256']=file_sha(args.candidate_symvers)
        d['image_sha256']=file_sha(args.image)
        for cohort in ('QGKI','GKI'):
            old_results,old_totals,old_complete,oldmods=r6.evaluate(imports[cohort],baseline)
            new_results,new_totals,new_complete,newmods=r6.evaluate(imports[cohort],candidate)
            if old_totals['MATCH']!=report[cohort]['match']:raise ValueError('R6_BASELINE_RECOMPUTATION_FAIL')
            delta=new_totals['MATCH']-old_totals['MATCH']
            old_by={m['path']:m for m in oldmods}
            out_by={m['path']:m for m in newmods}
            table=[]
            for name in sorted(old_by):
                a,b=old_by[name],out_by[name]
                table.append([name,a['match'],b['match'],b['match']-a['match'],a['crc_mismatch'],b['crc_mismatch'],a['not_exported'],b['not_exported'],b['complete_match']])
            output=Path(args.reports)
            with (output/('R8_'+cohort+'_PER_MODULE_DELTA.csv')).open('w',newline='') as f:
                w=csv.writer(f,lineterminator='\n');w.writerow(['module','R6_match','R8_match','delta','R6_crc_mismatch','R8_crc_mismatch','R6_not_exported','R8_not_exported','R8_complete']);w.writerows(table)
            changes=Counter()
            for a,b in zip(old_results,new_results):
                if a[:3]!=b[:3]:raise ValueError('IMPORT_ALIGNMENT_DRIFT')
                if a[-1]!=b[-1]:changes[(a[1],a[-1],b[-1])]+=1
            with (output/('R8_'+cohort+'_SYMBOL_STATUS_CHANGES.csv')).open('w',newline='') as f:
                w=csv.writer(f,lineterminator='\n');w.writerow(['symbol','R6_status','R8_status','occurrences']);w.writerows([list(k)+[v] for k,v in sorted(changes.items(),key=lambda i:(-i[1],i[0]))])
            d[cohort]={'R6_match':old_totals.get('MATCH',0),'R8_match':new_totals.get('MATCH',0),'delta_matches':delta,
                'R6_crc_mismatch':old_totals.get('CRC_MISMATCH',0),'R8_crc_mismatch':new_totals.get('CRC_MISMATCH',0),
                'R6_missing':old_totals.get('NOT_EXPORTED',0),'R8_missing':new_totals.get('NOT_EXPORTED',0),
                'complete_module_count':new_complete,'module_layout_expected':r6.EXPECTED[cohort][3],
                'module_layout_candidate':sorted(candidate.get('module_layout',set()))}
        d['qgki_better_without_gki_claim']=d['QGKI']['delta_matches']>0
    else:
        d['status']='BUILD_BLOCKED_NO_ABI_DELTA'
    out=Path(args.reports);out.mkdir(parents=True,exist_ok=True)
    (out/'R8_PAIRED_IOMMU_ABI_RESULT.json').write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:d.get(k) for k in ('build_exit_code','compiler_error_count','abi_compared','QGKI','GKI','flash_allowed')},sort_keys=True))


def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='operation',required=True)
    s=sub.add_parser('stage')
    for x in ('r1','donor','stage','pair','reports'):s.add_argument('--'+x,required=True)
    s=sub.add_parser('summary')
    for x in ('baseline_report','baseline_symvers','r6_tool','imports','candidate_symvers','image','return_code','build_log','reports'):
        s.add_argument('--'+x.replace('_','-'),required=True)
    a=p.parse_args()
    if a.operation=='stage':stage(a)
    else:summary(a)
if __name__=='__main__':main()
