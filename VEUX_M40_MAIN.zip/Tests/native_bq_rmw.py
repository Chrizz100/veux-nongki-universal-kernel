import argparse, re, subprocess, tempfile
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def function(s, n):
    m = re.search('^(?:static\\s+)?[^\\n;]+\\b' + n + '\\([^;]+?\\n\\{', s, re.M)
    if not m:
        raise ValueError(n)
    return s[m.start():s.index('\n}', m.end()) + 2]

def main():
    p = argparse.ArgumentParser()
    p.add_argument('source', type=Path)
    a = p.parse_args()
    s = a.source.read_text()
    base = (ROOT / 'References/M37_PROVEN_BQ.c').read_text()
    body = '\n\n'.join((function(s, n) for n in ['bq2589x_read_byte', 'bq2589x_write_byte', 'bq2589x_update_bits']))
    if 'bq2589x_usb_changed(' in body:
        body = function(s, 'bq2589x_resolve_supply') + '\n' + function(s, 'bq2589x_usb_changed') + '\n' + body
    elif 'bq2589x_resolve_supply(' in body:
        body = function(s, 'bq2589x_resolve_supply') + '\n' + body
    ref = function(base, 'bq2589x_update_bits').replace('bq2589x_update_bits(', 'bq2589x_update_bits_reference(', 1)
    tests = '\nstatic int assertions,success_cases,fault_cases,race_cases;\nstatic struct device dev;static struct i2c_client client;static struct bq2589x bq={&dev,&client};\n#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\\n",__LINE__,#x);return 1;}}while(0)\nstatic void reset(void){memset(registers,0,sizeof(registers));reads=writes=fail_read=left=fail_write=delays=0;apply_error=false;atomic_store(&paused_mode,0);atomic_store(&second_go,0);atomic_store(&second_done,0);role=unlocks=0;}\nstatic int balanced(void){int r=pthread_mutex_trylock(&bq2589x_i2c_lock.value);if(!r)pthread_mutex_unlock(&bq2589x_i2c_lock.value);return r==0;}\nstatic int (*tested)(struct bq2589x*,u8,u8,u8);\nstruct call{int role,ret;u8 reg,mask;};\nstatic void*thread(void*p){struct call*a=p;role=a->role;unlocks=0;if(role==2)while(!atomic_load(&second_go))sched_yield();a->ret=tested(&bq,a->reg,a->mask,a->mask);if(role==2)atomic_store(&second_done,1);return NULL;}\nstatic int race(int reg,int bit,int original){\n reset();u8 a=(u8)(1<<bit),b=(u8)(1<<((bit+1)%8)),initial=(u8)(0xa5&~(a|b));registers[reg]=initial;\n tested=original?bq2589x_update_bits_reference:bq2589x_update_bits;\n atomic_store(&paused_mode,1);struct call x={1,-1,(u8)reg,a},y={2,-1,(u8)reg,b};pthread_t t1,t2;\n CHECK(!pthread_create(&t2,NULL,thread,&y));CHECK(!pthread_create(&t1,NULL,thread,&x));CHECK(!pthread_join(t1,NULL));CHECK(!pthread_join(t2,NULL));\n CHECK(x.ret==0&&y.ret==0&&reads==2&&writes==2);CHECK(registers[reg]==(u8)(original?initial|a:initial|a|b));CHECK(balanced());if(!original)race_cases++;return 0;\n}\nint main(void){\n for(int reg=0;reg<=20;reg++)for(int bit=0;bit<8;bit++){CHECK(race(reg,bit,1)==0);CHECK(race(reg,bit,0)==0);}\n puts("BQ_M37_DISJOINT_REGISTER_UPDATE_LOST=REPRODUCED");\n int masks[]={0,1,3,128,255},data[]={0,1,127,128,255},errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};\n for(int initial=0;initial<256;initial++)for(int m=0;m<5;m++)for(int d=0;d<5;d++){\n  reset();registers[0]=initial;CHECK(bq2589x_update_bits(&bq,0,masks[m],data[d])==0);CHECK(registers[0]==(u8)((initial&~masks[m])|(data[d]&masks[m])));CHECK(reads==1&&writes==1&&balanced());success_cases++;\n }\n for(int reg=0;reg<=20;reg++)for(int m=0;m<5;m++)for(int e=0;e<5;e++){\n  reset();registers[reg]=0xa5;fail_read=errors[e];left=3;CHECK(bq2589x_update_bits(&bq,reg,masks[m],255)==errors[e]);CHECK(reads==3&&writes==0&&registers[reg]==0xa5&&delays==2&&balanced());fault_cases++;\n  for(int n=1;n<=2;n++){reset();registers[reg]=0xa5;fail_read=errors[e];left=n;CHECK(bq2589x_update_bits(&bq,reg,masks[m],255)==0);CHECK(reads==n+1&&writes==1&&delays==n&&balanced());success_cases++;}\n  reset();registers[reg]=0xa5;fail_write=errors[e];CHECK(bq2589x_update_bits(&bq,reg,masks[m],255)==errors[e]);CHECK(reads==1&&writes==1&&registers[reg]==0xa5&&balanced());fault_cases++;\n  reset();registers[reg]=0xa5;fail_write=errors[e];apply_error=true;CHECK(bq2589x_update_bits(&bq,reg,masks[m],255)==errors[e]);CHECK(registers[reg]==(u8)(0xa5|masks[m])&&balanced());fault_cases++;\n }\n printf("BQ_RMW_SERIALIZATION_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; deterministic_race_cases=%d; real pthreads and atomic read-modify-write\\n",assertions,success_cases,fault_cases,race_cases);return 0;\n}\n'
    with tempfile.TemporaryDirectory(prefix='m38-bq-rmw-') as t:
        c = Path(t) / 'test.c'
        exe = Path(t) / 'test'
        c.write_text((ROOT / 'References/native_bq_rmw_stubs.h').read_text() + '\n' + body + '\n' + ref + '\n' + tests)
        subprocess.run(['cc', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter', '-pthread', '-fsanitize=undefined', '-fno-sanitize-recover=all', str(c), '-o', str(exe)], check=True)
        subprocess.run([str(exe)], check=True, timeout=25)
if __name__ == '__main__':
    main()
