"""Run the actual IIO writer, setters and register operations for numeric contracts."""
import argparse
import ast
import json
import re
import subprocess
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DRIVER='drivers/power/supply/qcom/bq2589x_charger.c'

def function(source,name):
    m=re.search(r'^(?:static\s+)?[^\n;]+\b'+name+r'\([^;]+?\n\{',source,re.M)
    if not m:raise ValueError(name)
    return source[m.start():source.index('\n}',m.end())+2]

def literal(name):
    tree=ast.parse((ROOT/'Tests/native_bq_writes.py').read_text())
    for n in ast.walk(tree):
        if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id==name for t in n.targets):
            return ast.literal_eval(n.value)
    raise ValueError(name)

def main():
    p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args()
    src=a.source.read_text();baseline=(ROOT/'References/M39_PROVEN_BQ.c').read_text()
    prefix=literal('prefix').replace('state, other, saved_state, *g_bq','state, other, *g_bq')+'\n#include <limits.h>\n'
    prefix=prefix.replace('static struct power_supply *power_supply_get_by_name(const char*n){return NULL;}',
       'static int lookups; static struct power_supply *power_supply_get_by_name(const char*n){lookups++;return NULL;}')
    ids=json.loads((ROOT/'References/BOUND_IIO_CHANNEL_IDS.json').read_text())['channels']
    constants='\n'.join('#define '+c['name']+' '+str(c['id'])for c in ids)
    definitions='\n'.join(l for l in (ROOT/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()if l.startswith('#define BQ2589X_'))
    names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_enable_otg','bq2589x_disable_otg','bq2589x_set_otg_volt','bq2589x_set_otg_current','bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_set_charge_current','bq2589x_set_term_current','bq2589x_set_chargevoltage','bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit','bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode','bq2589x_enable_term','bq2589x_usb_switch','bq2589x_resolve_supply','bq_iio_write_raw_unlocked','bq_iio_write_raw']
    body='\n\n'.join(function(src,n)for n in names)
    reference='\n\n'.join(function(baseline,n).replace('bq_iio_write_raw_unlocked(','reference_unlocked(').replace('bq_iio_write_raw(','reference_writer(')for n in ['bq_iio_write_raw_unlocked','bq_iio_write_raw'])
    reset=re.search(r'static void reset\([^\n]+ \{\n.*?\n\}',literal('tests'),re.S).group(0)
    reset=reset.replace('used=fail_kind=fail_at=fail_code=0;','lookups=0; used=fail_kind=fail_at=fail_code=0;')
    tests=r'''
#define CHECK(x) do { assertions++; if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;} }while(0)
struct observed {int term,otg,current,status,hz,usbflag,usbstate,wake,lookups,used;};
static struct observed observe(void) {
 struct observed o={0};o.term=state.cfg.enable_term;o.otg=state.cfg.otg_status;
 o.current=state.cfg.input_current;o.status=state.status;o.hz=state.hz_flag;
 o.usbflag=state.usb_switch_flag;o.usbstate=state.usb_swtich_status;o.wake=state.wakeup_flag;
 o.lookups=lookups;o.used=used;return o;
}
static int invoke(int ch,int value,bool old) {
 struct iio_chan_spec c={ch};
 return old?reference_writer(&iio,&c,value,0,0):bq_iio_write_raw(&iio,&c,value,0,0);
}
int main(void) {
 int numeric[]={PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,PSY_IIO_MAIN_INPUT_VOLTAGE_SETTLED,
   PSY_IIO_MAIN_CHAGER_CURRENT,PSY_IIO_MAIN_CHAGER_TERM,PSY_IIO_BATTERY_VOLTAGE_TERM};
 int negative[]={-1,INT_MIN,INT_MIN+1,-1000000,-3100,-2600,-100,-64,-2};
 int nonnegative[]={0,1,50,63,64,99,100,256,500,512,896,1010,1500,2000,3010,3099,3100,3101,4100,4400,4450,4608,INT_MAX};
 int controls[]={PSY_IIO_MAIN_CHAGER_HZ,PSY_IIO_CHARGING_ENABLED,PSY_IIO_OTG_ENABLE,PSY_IIO_ENABLE_CHAGER_TERM,PSY_IIO_CHARGE_DONE,999999};
 int control_values[]={INT_MIN,-1,0,1,INT_MAX};
 int rejected=0,retained=0,control_cases=0,precedence_cases=0;
 struct observed before,old_observed,now;
 reset(0,0,0,0,0);
 CHECK(invoke(PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,-1,true)==0);
 CHECK((registers[BQ2589X_REG_00]&BQ2589X_IINLIM_MASK)==62);
 puts("BQ_M39_NEGATIVE_ONE_INPUT_CURRENT_PROGRAMS_3200MA=REPRODUCED");
 for(int ch=0;ch<5;ch++)for(unsigned vi=0;vi<sizeof(negative)/sizeof(*negative);vi++)
 for(int chip=0;chip<2;chip++)for(int psy=0;psy<2;psy++)for(int warm=0;warm<2;warm++) {
  reset(chip,psy,0,0,warm);before=observe();memcpy(saved_registers,registers,sizeof(registers));
  CHECK(invoke(numeric[ch],negative[vi],false)==-EINVAL);
  now=observe();CHECK(!memcmp(&before,&now,sizeof(now)));
  CHECK(!memcmp(saved_registers,registers,sizeof(registers)));CHECK(used==0&&lookups==0);rejected++;
 }
 for(int ch=0;ch<5;ch++)for(unsigned vi=0;vi<sizeof(nonnegative)/sizeof(*nonnegative);vi++)
 for(int chip=0;chip<2;chip++)for(int psy=0;psy<2;psy++)for(int warm=0;warm<2;warm++)for(int fault=0;fault<3;fault++) {
  reset(chip,psy,0,0,warm);if(fault){fail_kind=fault==1?READ:WRITE;fail_at=1;fail_code=-EREMOTEIO;}
  int expected=invoke(numeric[ch],nonnegative[vi],true);old_observed=observe();int old_used=used;
  memcpy(saved_events,events,sizeof(events));memcpy(saved_registers,registers,sizeof(registers));
  reset(chip,psy,0,0,warm);if(fault){fail_kind=fault==1?READ:WRITE;fail_at=1;fail_code=-EREMOTEIO;}
  CHECK(invoke(numeric[ch],nonnegative[vi],false)==expected);now=observe();
  CHECK(!memcmp(&old_observed,&now,sizeof(now)));CHECK(used==old_used);
  CHECK(!memcmp(saved_events,events,used*sizeof(*events)));
  CHECK(!memcmp(saved_registers,registers,sizeof(registers)));retained++;
 }
 for(unsigned ch=0;ch<sizeof(controls)/sizeof(*controls);ch++)for(unsigned vi=0;vi<sizeof(control_values)/sizeof(*control_values);vi++)
 for(int chip=0;chip<2;chip++)for(int enabled=0;enabled<2;enabled++) {
  reset(chip,1,enabled,enabled,1);int expected=invoke(controls[ch],control_values[vi],true);
  old_observed=observe();int old_used=used;memcpy(saved_events,events,sizeof(events));memcpy(saved_registers,registers,sizeof(registers));
  reset(chip,1,enabled,enabled,1);CHECK(invoke(controls[ch],control_values[vi],false)==expected);
  now=observe();CHECK(!memcmp(&old_observed,&now,sizeof(now)));CHECK(used==old_used);
  CHECK(!memcmp(saved_events,events,used*sizeof(*events)));CHECK(!memcmp(saved_registers,registers,sizeof(registers)));control_cases++;
 }
 for(int ch=0;ch<5;ch++)for(unsigned vi=0;vi<sizeof(negative)/sizeof(*negative);vi++)for(int stop=0;stop<2;stop++) {
  reset(1,1,0,0,1);state.startup_ready=false;state.stopping=stop;
  CHECK(invoke(numeric[ch],negative[vi],false)==(stop?-ESHUTDOWN:-EPROBE_DEFER));CHECK(used==0&&lookups==0);precedence_cases++;
 }
 printf("BQ_NUMERIC_INPUT_HOST_TESTS=PASS; assertions=%d; negative_cases=%d; nonnegative_differential_cases=%d; control_differential_cases=%d; precedence_cases=%d; no bus GPIO provider or cache side effects on rejection\n",assertions,rejected,retained,control_cases,precedence_cases);
 return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='m40-numeric-')as t:
        c=Path(t)/'test.c';exe=Path(t)/'test'
        c.write_text(prefix+'\n'+definitions+'\n'+constants+'\n'+body+'\n'+reference+'\n'+reset+'\n'+tests)
        subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
        subprocess.run([str(exe)],check=True,timeout=25)

if __name__=='__main__':main()
