
#include <pthread.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sched.h>
#include <assert.h>
#define smp_load_acquire(p) __atomic_load_n((p),__ATOMIC_ACQUIRE)
#define READ_ONCE(x) __atomic_load_n(&(x),__ATOMIC_SEQ_CST)
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_SEQ_CST)
#define cmpxchg(p,o,n) __sync_val_compare_and_swap((p),(o),(n))
#define ARRAY_SIZE(x) ((int)(sizeof(x)/sizeof((x)[0])))
#define CHANNEL_COUNT 14
struct device{int unused;};struct power_supply{int kind;atomic_int refs;};
struct iio_chan_spec{int channel;};
struct bq2589x{struct device*dev;bool stopping;struct power_supply*batt_psy,*usb_psy;struct iio_chan_spec*iio_chan;};
struct iio_dev{struct bq2589x*data;};struct of_phandle_args{int args_count;uint32_t args[16];};
static int bq25890_iio_psy_channels[CHANNEL_COUNT];
static struct power_supply providers[2];static atomic_int available[2],gets[2],put_calls[2],warnings[2],notifications[2];
static atomic_int barrier_target,arrived,delay_get,get_entered,release_get;static int last_spec_error;
static void*iio_priv(struct iio_dev*d){return d->data;}
static void mock_warning(const char*name){atomic_fetch_add(&warnings[!strcmp(name,"battery")?0:1],1);}
#define dev_warn_ratelimited(dev,fmt,name)mock_warning(name)
#define dev_err_ratelimited(dev,fmt,code)do{last_spec_error=(code);}while(0)
static struct power_supply*power_supply_get_by_name(const char*name){
 int k=!strcmp(name,"battery")?0:1;atomic_fetch_add(&gets[k],1);if(!atomic_load(&available[k]))return NULL;
 atomic_fetch_add(&providers[k].refs,1);
 int target=atomic_load(&barrier_target);if(target){atomic_fetch_add(&arrived,1);while(atomic_load(&arrived)<target)sched_yield();}
 if(atomic_load(&delay_get)){atomic_store(&get_entered,1);while(!atomic_load(&release_get))sched_yield();}
 return &providers[k];
}
static void power_supply_put(struct power_supply*p){assert(atomic_load(&p->refs)>0);atomic_fetch_add(&put_calls[p->kind],1);atomic_fetch_sub(&p->refs,1);}
static void power_supply_changed(struct power_supply*p){assert(p&&p->kind==1);atomic_fetch_add(&notifications[p->kind],1);}

static const int channel_ids[CHANNEL_COUNT]={57, 146, 33, 34, 148, 118, 145, 147, 149, 27, 116, 139, 136, 260};
