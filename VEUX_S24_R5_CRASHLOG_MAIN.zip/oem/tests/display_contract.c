#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdint.h>
typedef uint32_t u32;
#define READ_ONCE(x) (x)
#define WRITE_ONCE(x,v) ((x)=(v))
enum { VEUX_BL_ACTIVE };
struct dsi_panel {int panel_lock,panel_initialized,cur_mode,host,brightness_phase; u32 last_dcs_brightness,requested_doze_brightness;};
static int commands[3], errors[3], n, brightness, expected_bl;
static int dsi_panel_tx_cmd_set(struct dsi_panel *p,int id){
 assert(p->panel_lock && n<3);commands[n]=id;return errors[n++];
}
static int dsi_panel_set_backlight(struct dsi_panel *p,u32 value){
 assert(p->panel_lock && value==(u32)expected_bl);brightness++;return 0;
}
static void mutex_lock(int *lock){assert(!*lock);*lock=1;}
static void mutex_unlock(int *lock){assert(*lock);*lock=0;}
#include "production.h"
int main(void){
 struct dsi_panel p={.panel_initialized=1,.cur_mode=1,.host=1,.last_dcs_brightness=973};
 expected_bl=973;
 for(int h=0;h<16;h++) for(int f=0;f<16;f++){
  n=brightness=0;
  assert(!dsi_panel_apply_veux_parameter(&p, ((u32)h<<16)|((u32)f<<24)));
  int pos=0;
  if(expected_hbm[h]!=DSI_CMD_SET_MAX)assert(commands[pos++]==expected_hbm[h]);
  if(f==7)assert(commands[pos++]==DSI_CMD_SET_DISP_FLAT_ON);
  if(f==8)assert(commands[pos++]==DSI_CMD_SET_DISP_FLAT_OFF);
  assert(n==pos && brightness==(h==10||h==15) && !p.panel_lock);
 }
 errors[0]=-EIO;n=brightness=0;
 assert(dsi_panel_apply_veux_parameter(&p,0x70a0000)==-EIO && n==1 && !brightness && !p.panel_lock);
 n=0;assert(dsi_panel_apply_veux_doze(&p,1)==-EIO && p.requested_doze_brightness==0);
 errors[0]=0;n=0;
 assert(!dsi_panel_apply_veux_doze(&p,1) && commands[0]==DSI_CMD_SET_DISP_DOZE_HBM && p.requested_doze_brightness==1);
 assert(!dsi_panel_apply_veux_doze(&p,2) && commands[1]==DSI_CMD_SET_DISP_DOZE_LBM && p.requested_doze_brightness==2);
 assert(!dsi_panel_apply_veux_doze(&p,0) && n==2 && p.requested_doze_brightness==0);
 assert(dsi_panel_apply_veux_doze(&p,3)==-EINVAL && n==2);
 p.panel_initialized=0;
 assert(dsi_panel_apply_veux_doze(&p,1)==-EAGAIN && n==2 && !p.panel_lock);
 assert(dsi_panel_apply_veux_parameter(&p,0xb0000)==-EAGAIN && n==2 && !p.panel_lock);
 puts("256 HBM/Flatmode-Kombinationen und 8 Fehler- bzw. Doze-Faelle bestanden.");
}
