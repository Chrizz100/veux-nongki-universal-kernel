"""Exercise the actual linked ARM64 runner's PID-1 handoff in an isolated user-mode process."""
import hashlib,json,os,socket,subprocess,sys,tempfile,time
from pathlib import Path
runner=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve()
assert hashlib.sha256(runner.read_bytes()).hexdigest()=="e67305e093dc52ceecef4a63f1d723ae1a651530868ec565e5e2b4de63495a55"
with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1",0));port=sock.getsockname()[1]
    (root/"probe.py").write_text('''
import lldb,os,json,struct,time
from pathlib import Path
def test(d):
    t=d.GetSelectedTarget(); p=t.GetProcess()
    clone=0x210af0;execve=0x210e80
    def reg(f,name):
        a=f.FindRegister(name)
        assert a.IsValid(),name
        return a.GetValueAsUnsigned()
    def stopped(at):
        e=p.Continue()
        assert e.Success(),str(e)
        f=p.GetSelectedThread().GetFrameAtIndex(0)
        assert f.GetPC()==at,(str(p.GetState()),hex(f.GetPC()),hex(at))
        return f
    def set_error(f,error):
        ok=f.FindRegister("x0").SetValueFromCString(hex(2**64-error))
        assert ok and f.SetPC(f.GetPC()+4)
    bp=t.BreakpointCreateByAddress(clone);ep=t.BreakpointCreateByAddress(execve)
    f=stopped(clone);assert reg(f,"x8")==220
    set_error(f,11)
    data=[];ids=None
    for err in (4,11,12,26,2):
        f=stopped(execve)
        args=tuple(reg(f,k) for k in ("x0","x1","x2"));assert reg(f,"x8")==221
        errbuf=lldb.SBError()
        assert p.ReadCStringFromMemory(args[0],64,errbuf)=="/system/bin/init" and errbuf.Success()
        if ids is not None: assert args==ids
        ids=args
        data.append(dict(target="/system/bin/init",returned_errno=err,argv_address=hex(args[1]),envp_address=hex(args[2])))
        set_error(f,err)
    p.Continue()
    assert p.GetState()==lldb.eStateExited and p.GetExitStatus()==127,(p.GetState(),p.GetExitStatus())
    Path(os.environ["R3_RUNNER_RESULT"]).write_text(json.dumps({"actual_runner":True,"execve_stops":data,"permanent_ENOENT_exit":p.GetExitStatus(),"device_pass":False},indent=2)+"\\n")
''')
    ret=root/"result.json"
    q=subprocess.Popen(["qemu-aarch64","-g",str(port),runner,"selinux_setup"],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        cmd=root/"test.lldb"
        cmd.write_text('settings set use-color false\ntarget create --arch aarch64 "'+str(runner)+'"\ngdb-remote 127.0.0.1:'+str(port)+'\ncommand script import "'+str(root/"probe.py")+'"\nscript probe.test(lldb.debugger)\n')
        run=subprocess.run(["lldb-19","--no-lldbinit","--batch","-s",cmd],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30,env=dict(os.environ,R3_RUNNER_RESULT=str(ret)))
        (out/"PID1-ARM64-Lauf-LLDB.txt").write_text(run.stdout)
        if not ret.is_file(): raise RuntimeError(run.stdout[-1600:])
        (out/"PID1-ARM64-Lauf.json").write_bytes(ret.read_bytes())
        print(ret.read_text())
    finally:
        if q.poll() is None:q.terminate()
        try:q.wait(timeout=2)
        except subprocess.TimeoutExpired:q.kill();q.wait()
