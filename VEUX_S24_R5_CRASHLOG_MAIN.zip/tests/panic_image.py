"""Validate the two corrected paths in the final raw ARM64 Image and the embedded PID 1 executable."""
from pathlib import Path
import hashlib
import json
import os
import re
import struct
import subprocess
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"oem"))
from image_symbols import BASE, normal

def check(ok,message):
    if not ok: raise ValueError(message)

def word(data,offset):
    return struct.unpack_from("<I",data,offset)[0]

def branch(pc,insn):
    if insn >> 26 not in (5,37): return None
    return pc+4*(((insn&0x3ffffff)^0x2000000)-0x2000000)

def disassemble(elf,ranges,evidence,name):
    command=["settings set use-color false",f'target create --arch aarch64 "{elf.resolve()}"']
    command += [f"disassemble --bytes --start-address {hex(pc)} --count {count}" for pc,count in ranges]
    cmd=evidence/(name+".lldb")
    cmd.write_text("\n".join(command)+"\n")
    log=subprocess.check_output([os.environ.get("LLDB","lldb-19"),"--no-lldbinit","--batch","-s",cmd],text=True)
    (evidence/(name+"-LLDB.txt")).write_text(log)
    rows=re.findall(r'^\S+\[0x([0-9a-f]+)\](?:\s+<[^>]*>)?:\s+(0x[0-9a-f]{8})',log,re.M)
    return {int(a,16):int(w,16) for a,w in rows}

def runner_text(data):
    check(data[:6]==b"\x7fELF\x02\x01" and struct.unpack_from("<H",data,18)[0]==183,"runner ARM64 ELF")
    offset=struct.unpack_from("<Q",data,40)[0]
    stride,count,strings=struct.unpack_from("<HHH",data,58)
    headers=[struct.unpack_from("<IIQQQQIIQQ",data,offset+i*stride) for i in range(count)]
    s=headers[strings]; names=data[s[4]:s[4]+s[5]]
    sections=[x for x in headers if names[x[0]:names.index(0,x[0])]==b".text" and x[2]&4]
    check(len(sections)==1,"executable runner .text")
    s=sections[0]
    return s[3],data[s[4]:s[4]+s[5]]

def verify(out,evidence):
    image=(out/"arch/arm64/boot/Image").read_bytes()
    syms={}
    text_addresses=set()
    for line in (out/"System.map").read_text().splitlines():
        address,kind,name=line.split(maxsplit=2)
        value=int(address,16)
        syms.setdefault(normal(name),set()).add(value)
        if kind.lower() in ("t","w"): text_addresses.add(value)
    def addr(name):
        addresses=syms.get(name,())
        check(len(addresses)==1,"Missing or ambiguous symbol "+name)
        return next(iter(addresses))
    def ptr(pc): return struct.unpack_from("<Q",image,pc-BASE)[0]
    def ins(pc): return word(image,pc-BASE)
    table=addr("fsnotify_ops");fields=[ptr(table+i*8) for i in range(5)]
    free=addr("susfs_free_sdcard_mark");thunk=addr("susfs_free_sdcard_mark.cfi_jt")
    check(fields[0]==addr("susfs_handle_sdcard_inode_event.cfi_jt") and fields[4]==thunk,"Effective fsnotify callback table")
    check(branch(thunk,ins(thunk))==free,"fsnotify free_mark CFI target")
    target=addr("kfree")
    limit=min(p for p in text_addresses if p>free)
    check(any(branch(p,ins(p))==target for p in range(free,limit,4)),"Actual mark destructor must free the allocation")
    required={"audit_tree_ops":"audit_tree_destroy_watch","audit_watch_fsnotify_ops":"audit_watch_free_mark","inotify_fsnotify_ops":"inotify_free_mark","audit_mark_fsnotify_ops":"audit_fsnotify_free_mark"}
    # Each inherited group has a concrete destructor. Their source names need not equal the table name.
    original={}
    for name,destructor in required.items():
        base=addr(name);cb=ptr(base+32)
        check(cb==addr(destructor+".cfi_jt"),"Wrong original callback "+name)
        original[name]=hex(cb)
    kernelwords=disassemble(out/"vmlinux",[(thunk,1),(free,(limit-free)//4)],evidence,"SUSFS-Freigabe")
    check(len(kernelwords)==1+(limit-free)//4 and all(ins(p)==v for p,v in kernelwords.items()),"LLDB callback instruction bytes")
    monitor=addr("susfs_sdcard_monitor_fn")
    cleanup=addr("susfs_sdcard_cleanup_fn")
    def extent(start):
        return (min(p for p in text_addresses if p>start)-start)//4
    routines=disassemble(out/"vmlinux",[(monitor,extent(monitor)),(cleanup,extent(cleanup))],evidence,"SUSFS-Lebensdauer")
    check(len(routines)==extent(monitor)+extent(cleanup) and all(ins(p)==w for p,w in routines.items()),"LLDB watcher code")
    def calls(start,name):
        return [p for p in range(start,start+4*extent(start),4) if branch(p,routines[p])==addr(name)]
    def one(start,name):
        pcs=calls(start,name);check(len(pcs)==1,"Expected one call to "+name)
        return pcs[0]
    alloc=one(monitor,"fsnotify_alloc_group")
    page,off=routines[alloc-8],routines[alloc-4]
    check(page&0x9f00001f==0x90000000 and off&0xffc003ff==0x91000000,"Table address materialized in x0")
    displacement=(((page>>5&0x7ffff)<<2)|(page>>29&3))
    displacement=((displacement^0x100000)-0x100000)<<12
    check(((alloc-8)&~4095)+displacement+(off>>10&4095)==table,"Published watcher table passed to allocator")
    attach,put=one(monitor,"fsnotify_add_mark"),one(monitor,"fsnotify_put_mark")
    # The pinned compiler saves the return value and mark, drops its reference, then tests the saved result.
    check(put==attach+12 and routines[attach+4]&0xffffffe0==0x2a0003e0 and
          routines[attach+8]&0xffe0ffff==0xaa0003e0 and routines[put+4]&0x7f000000==0x35000000,
          "Unconditional creator put before testing attachment outcome")
    creation={"alloc_group":hex(alloc),"add_mark":hex(attach),"put_creator_mark":hex(put),
              "setup_path_put":hex(one(monitor,"path_put")),"setup_destroy_group":hex(one(monitor,"fsnotify_destroy_group")),
              "cleanup_path_put":hex(one(cleanup,"path_put")),"cleanup_destroy_group":hex(one(cleanup,"fsnotify_destroy_group"))}
    begin,end=addr("ksu_preinit_runner_start"),addr("ksu_preinit_runner_end")
    data=image[begin-BASE:end-BASE];runner=out/"drivers/kernelsu/preinit/runner.elf"
    check(data==runner.read_bytes(),"Published runner differs from linked runner")
    text_va,code=runner_text(data)
    words=disassemble(runner,[(text_va,len(code)//4)],evidence,"PID1-Runner")
    check(len(words)==len(code)//4 and all(words.get(text_va+i)==word(code,i) for i in range(0,len(code),4)),"LLDB runner words")
    # Verify the actual fixed compiler output, including the branch that runs execve again after the wait.
    retries=[]
    for p,w in words.items():
        if w&0xff00001f != 0x54000001: continue  # b.ne
        imm=(w>>5)&0x7ffff;dest=p+4*((imm^0x40000)-0x40000)
        if not 0<p-dest<512:continue
        block=[words[q] for q in range(dest,p,4)]
        calls=[(a,b) for a,b in zip(block,block[1:]) if b==0xd4000001]
        if (0x52801ba8,0xd4000001) in calls and (0x52800e68,0xd4000001) in calls and words.get(p+4)==0x52800fe0:
            retries.append((dest,p))
    check(len(retries)==1,"Expected one delayed branch back to execve before terminal return 127")
    check(b"exec /system/bin/init temporarily failed: %d, retrying" in data,"runner retry log")
    digest=hashlib.sha256(data).hexdigest()
    check(digest=="e67305e093dc52ceecef4a63f1d723ae1a651530868ec565e5e2b4de63495a55","Unexpected PID 1 binary for pinned toolchain")
    report=dict(image_sha256=hashlib.sha256(image).hexdigest(),fsnotify_ops=hex(table),handle_event=hex(fields[0]),free_mark_cfi=hex(thunk),free_mark=hex(free),kfree=hex(target),original_fsnotify_destructors=original,watcher_lifetime=creation,runner_sha256=digest,embedded_runner_bytes=len(data),runner_lldb_words=len(words),exec_retry_branch=[hex(p) for p in retries[0]],device_pass=False)
    (evidence/"Panik-Image.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(report))
if __name__=="__main__":
    verify(Path(sys.argv[1]),Path(sys.argv[2]))
