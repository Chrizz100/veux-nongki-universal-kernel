/* Test the production PID-1 parent. System calls have deterministic, harmless outcomes. */
#include <assert.h>
#include <errno.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#define INIT_PATH "/system/bin/init"
#define TOTAL_TIMEOUT_MS 30000
enum state { NORMAL, FORK_FAILED, WAIT_INTERRUPTED, WORKER_TIMEOUT, ALREADY_REAPED, WORKER_CHILD };
static enum state state;
static const int *errors;
static size_t error_count, calls, retries;
static int elapsed, waits, forks, final_status;
static int delays[256];
static jmp_buf done;
static char *args[]={"init","selinux_setup",NULL},*environment[]={"PATH=/system/bin",NULL};
static void klog(const char *s,...){errno=EIO;} /* Logging is allowed to change errno. */
static long now_ms(void){return elapsed;}
static void sleep_ms(long ms){
    if(calls){assert(retries<256);delays[retries++]=ms;}
    else {elapsed+=ms;assert(elapsed<=31000);}
}
static pid_t test_fork(void){forks++;if(state==FORK_FAILED){errno=EAGAIN;return -1;}return state==WORKER_CHILD?0:42;}
static int test_setpgid(int pid,int pg){assert((pid==42&&pg==42)||(!pid&&!pg));return 0;}
static int test_kill(int pid,int sig){assert((pid==42||pid==-42)&&sig==SIGKILL);return 0;}
static pid_t test_waitpid(int pid,int *s,int flags){
    assert(!s && flags==WNOHANG);if(pid==-1){errno=ECHILD;return -1;}
    assert(pid==42);waits++;
    if(state==WAIT_INTERRUPTED && waits==1){errno=EINTR;return -1;}
    if(state==ALREADY_REAPED){errno=ECHILD;return -1;}
    if(state==WORKER_TIMEOUT)return 0;
    return 42;
}
static int worker_main(void){return 0;}
static void test_exit(int status){assert(!status && state==WORKER_CHILD);longjmp(done,2);}
static int test_exec(const char *path,char **argv,char **envp){
    assert(!strcmp(path,INIT_PATH) && argv==args && envp==environment);
    assert(calls<error_count);int error=errors[calls++];if(!error)longjmp(done,1);errno=error;return -1;
}
#define fork test_fork
#define waitpid test_waitpid
#define kill test_kill
#define setpgid test_setpgid
#define _exit test_exit
#define execve test_exec
#include "runner-under-test.inc"

static void run(enum state mode,const int *sequence,size_t n,int terminal){
    state=mode;errors=sequence;error_count=n;calls=retries=0;waits=forks=elapsed=final_status=0;
    int status=setjmp(done);
    if(!status){final_status=runner_main(2,args,environment);status=3;}
    assert(forks==1 && status==terminal && calls==n);
    assert(retries==(n?n-1:0) && (terminal!=3||final_status==127));
    for(size_t i=0;i<retries;i++){
        int expected=i>=5?1000:50<<i;
        assert(delays[i]==expected);
    }
}
int main(void){
    const int temporary[]={EINTR,EAGAIN,ENOMEM,ETXTBSY};
    const int permanent[]={ENOENT,EACCES,ENOEXEC};
    int cases=0;
    for(int mode=NORMAL;mode<WORKER_CHILD;mode++){
        run(mode,(int[]){0},1,1);cases++;
        for(size_t i=0;i<4;i++){
            run(mode,(int[]){temporary[i],0},2,1);cases++;
            run(mode,(int[]){temporary[i],temporary[i],0},3,1);cases++;
        }
        for(size_t i=0;i<3;i++){
            run(mode,(int[]){permanent[i]},1,3);cases++;
            run(mode,(int[]){ENOMEM,permanent[i]},2,3);cases++;
        }
        int mixed[129];for(int i=0;i<128;i++)mixed[i]=temporary[i%4];mixed[128]=0;
        run(mode,mixed,129,1);cases++;
    }
    run(WORKER_CHILD,NULL,0,2);cases++;
    printf("%d PID-1 cases passed, including 128 consecutive transient errors and original argv/envp\n",cases);
    return 0;
}
