"""Build instrumented fixtures from the two C implementations in this source tree."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from preinit_test import body

def run(src,evidence):
    watcher=(src/"fs/susfs.c").read_text()
    start=watcher.index("static struct fsnotify_group *sdcard_group;")
    end=watcher.index("// - defer extra susfs works",start)
    code=(src/"KernelSU/kernel/preinit/runner/runner.c").read_text()
    parent=body(code,"int main(int argc,").replace("int main(","int runner_main(",1)
    pieces={"watch":watcher[start:end],"runner":body(code,"static void supervise(")+"\n"+parent}
    env={**os.environ,"ASAN_OPTIONS":"detect_leaks=0:halt_on_error=1","UBSAN_OPTIONS":"halt_on_error=1"}
    results={}
    with tempfile.TemporaryDirectory() as td:
        work=Path(td)
        for case,source in pieces.items():
            (work/(case+"-under-test.inc")).write_text(source)
            exe=work/case
            subprocess.run(["cc","-std=gnu11","-O2","-g","-pthread","-no-pie","-fno-omit-frame-pointer",
                            "-fsanitize=address,undefined","-fno-sanitize-recover=all","-Werror=implicit-function-declaration",
                            "-I",str(work),str(HERE/(case+".c")),"-o",str(exe)],check=True)
            results[case]=subprocess.check_output([exe],text=True,env=env).strip()
            print(results[case])
    evidence.write_text(json.dumps(results,indent=2)+"\n")

if __name__=="__main__":
    run(Path(sys.argv[1]),Path(sys.argv[2]))
