#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
work=$(realpath -m "$1")
toolchain=$(realpath "$2")
stock=$(realpath "$3")
src="$work/src"
out="$work/out"
evidence="$work/evidence"
mkdir -p "$out" "$work/sus-out" "$evidence"
export KBUILD_BUILD_TIMESTAMP='Thu Nov 26 00:00:00 UTC 2026' SOURCE_DATE_EPOCH=1795651200
export KBUILD_BUILD_USER=veux-ci KBUILD_BUILD_HOST=github-actions KBUILD_BUILD_VERSION=1
export PYTHONDONTWRITEBYTECODE=1 XZ_OPT=-T1
build=(bash "$kit/oem/tools/kbuild.sh" "$src" "$out" "$toolchain")
susbuild=(bash "$kit/oem/tools/kbuild.sh" "$src" "$work/sus-out" "$toolchain")

# Qualify the pinned stand-alone objects before the two existing integration phases.
python3 "$kit/prepare.py" susfs "$src"
cp "$kit/oem/kernel.config" "$work/sus-out/.config"
"${susbuild[@]}" olddefconfig
flags=$(awk -F= '/^CONFIG_KSU_SUSFS.*=y$/{printf "-D%s=1 ", $1}' "$kit/feature.config")
"${susbuild[@]}" CONFIG_KSU_SUSFS=y "KCFLAGS=$flags" fs/susfs.o fs/proc/cmdline.o
"$toolchain/bin/ld.lld" -r "$work/sus-out/fs/susfs.o" "$work/sus-out/fs/proc/cmdline.o" -o "$work/susfs-arm64.o"
test ! -e "$src/KernelSU" && test ! -e "$src/NoMount"
sha256sum "$work/susfs-arm64.o" > "$evidence/01-objects.sha256"

python3 "$kit/prepare.py" bakasu "$src"
test ! -e "$src/NoMount"
python3 "$kit/prepare.py" nomount "$src"
git -C "$src" apply --check "$kit/r5/display-ramoops.patch"
git -C "$src" apply "$kit/r5/display-ramoops.patch"

for t in preinit_test tests/panic_paths; do
    file=$(basename "$t")
    python3 "$kit/$t.py" "$src" "$evidence/$file.json"
done
for t in techpack_order touch_contract oem_contract r10_interfaces r11_interfaces; do
    python3 "$kit/oem/tests/$t.py" "$src" | tee "$evidence/$t.log"
done
python3 "$kit/oem/tests/display_contract.py" "$src" "$stock" | tee "$evidence/display_contract.log"
for t in display_cases esd_cases pstore_cases; do
    python3 "$kit/r5/$t.py" "$src" | tee "$evidence/$t.log"
done

# Link the final combination once, then inspect the actual shipped bytes.
cp "$kit/feature.config" "$out/.config"
"${build[@]}" olddefconfig
cmp "$kit/feature.config" "$out/.config"
"${build[@]}" Image
test -s "$out/drivers/kernelsu/preinit/runner.elf"
python3 "$kit/oem/proof.py" "$stock" "$out" "$evidence" --lldb "${LLDB:-lldb-19}" --objcopy "$toolchain/bin/llvm-objcopy"
python3 "$kit/feature_check.py" "$out" "$toolchain" "$evidence"
python3 "$kit/tests/panic_image.py" "$out" "$evidence"
python3 "$kit/tests/runner_machine.py" "$out/drivers/kernelsu/preinit/runner.elf" "$evidence"
python3 "$kit/r5/linked_changes.py" "$out" "$evidence"
python3 "$kit/r5/ak3_pair.py" "$stock" "$out/arch/arm64/boot/Image" "$work/pair"
cp "$out/.config" "$evidence/kernel.config"
cp "$kit/sources.json" "$evidence/"
