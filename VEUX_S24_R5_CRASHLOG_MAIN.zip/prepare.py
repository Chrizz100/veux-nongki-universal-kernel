"""Restore the pinned VEUX source tree and apply one independently verifiable phase."""
import argparse
from hashlib import file_digest
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import zipfile
from tempfile import TemporaryDirectory

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/"oem"))
from tools.treehash import tree
from prepare_r7 import stock

R11_TREE="bc664e3178a2cddad6247940259442614bf9255f"
R11_ARCHIVE="97ba0ac4c86ac0a7ce9eea4d9685fdb98f4985f628fdf543dd2cae46105c3646"
def sha(path):
    with path.open("rb") as f:
        return file_digest(f,"sha256").hexdigest()
def git(directory,*args,output=False):
    options={"cwd":directory,"text":True,"check":True}
    if output:
        return subprocess.check_output(["git",*args],cwd=directory,text=True).strip()
    subprocess.run(["git",*args],**options)
def apply(src,filename):
    patch=HERE/"patches"/filename
    git(src,"apply","--check",str(patch))
    git(src,"apply","--whitespace=nowarn",str(patch))
def driver(src,project):
    info=json.loads((HERE/"sources.json").read_text())[project]
    dest=src/project
    if not dest.exists():
        git(src,"clone","--no-checkout",info["url"],project)
    elif git(dest,"remote","get-url","origin",output=True)!=info["url"]:
        raise ValueError(f"Unexpected origin for {project}")
    git(dest,"checkout","--detach",info["commit"])
    if git(dest,"rev-parse","HEAD",output=True)!=info["commit"]:
        raise ValueError(project+" revision")
    count=int(git(dest,"rev-list","--count","HEAD",output=True))
    if count!=info["reachable_commits"]:
        raise ValueError(f"{project} commit history {count}")

def unpack_micode(repo,extract):
    info=json.loads((HERE/"sources.json").read_text())["base"]
    pack=HERE/"patches/r11-from-micode.pack"
    if sha(pack)!=info["r11_pack_sha256"]:
        raise ValueError("R11 source delta digest")
    if not repo.exists():
        repo.parent.mkdir(parents=True,exist_ok=True)
        subprocess.run(["git","init","--bare","--quiet",repo],check=True)
    prefix=["git","--git-dir",str(repo.resolve())]
    rev=info["xiaomi_commit"]
    if subprocess.run(prefix+["cat-file","-e",rev+"^{commit}"],stderr=subprocess.DEVNULL).returncode:
        subprocess.run(prefix+["fetch","--quiet","--no-tags","--depth=1",info["xiaomi_source"],rev],check=True)
    if subprocess.check_output(prefix+["rev-parse",rev+"^{tree}"],text=True).strip()!=info["xiaomi_tree"]:
        raise ValueError("Xiaomi source tree")
    if subprocess.run(prefix+["cat-file","-e",R11_TREE+"^{tree}"],stderr=subprocess.DEVNULL).returncode:
        with pack.open("rb") as f:
            subprocess.run(prefix+["index-pack","--stdin","--fix-thin"],stdin=f,check=True)
    with subprocess.Popen(prefix+["archive","--format=tar",R11_TREE],stdout=subprocess.PIPE) as proc:
        with tarfile.open(fileobj=proc.stdout,mode="r|") as tar:
            tar.extractall(extract,filter="tar")
        if proc.wait():
            raise ValueError("Could not export R11 from verified Xiaomi source")

def prepare(phase,src,archive,boot,micode=None):
    if phase=="base":
        if src.exists(): raise ValueError("Use a new source directory")
        if archive is not None and sha(archive)!=R11_ARCHIVE: raise ValueError("R11 archive digest")
        src.parent.mkdir(parents=True,exist_ok=True)
        with TemporaryDirectory(dir=src.parent) as tmp:
            extract=Path(tmp)/"src";extract.mkdir()
            if archive is None:
                unpack_micode(micode or src.parent/"micode.git",extract)
            else:
                with zipfile.ZipFile(archive) as z:
                    if z.read("kernel.config") != (HERE/"oem/kernel.config").read_bytes():
                        raise ValueError("R11 config mismatch")
                    with z.open("M63-R11-kernel-source.tar.gz") as stream, tarfile.open(fileobj=stream,mode="r|gz") as tar:
                        tar.extractall(extract,filter="tar")
            if tree(extract).hex()!=R11_TREE: raise ValueError("R11 tree identity")
            stock(boot.resolve())
            extract.rename(src)
        return
    if (src/".git").exists():
        raise ValueError("Use an exported kernel tree so the OEM release string is preserved")
    if phase=="susfs":
        if any((src/n).exists() for n in ("KernelSU","NoMount")): raise ValueError("Unexpected later phase")
        apply(src,"01-susfs24-qgki-veux.patch")
        apply(src,"01-sdcard-lifecycle.patch")
        if tree(src).hex()!="caf5e4f5868a81f6495b2acbbb2762621a6a33a8": raise ValueError("SUSFS tree identity")
        return
    if phase=="bakasu":
        if not (src/"fs/susfs.c").is_file() or (src/"NoMount").exists(): raise ValueError("SUSFS prerequisite")
        driver(src,"KernelSU")
        apply(src,"02-bakasu-veux.patch")
        apply(src/"KernelSU","02-bakasu-driver.patch")
        apply(src,"02-pid1-exec.patch")
        apply(src/"KernelSU","02-pid1-filename.patch")
        apply(src/"KernelSU","02-runner-exec-retry.patch")
        runner=src/"KernelSU/kernel/preinit/runner/runner.c"
        if sha(runner)!="fe4225748a0eb87fe67cb3b4ed688e359eb6c5ca2350d0386def9a0a34f1d385": raise ValueError("R3 preinit runner identity")
        return
    if not (src/"drivers/kernelsu/Kconfig").is_file(): raise ValueError("BakaSU prerequisite")
    driver(src,"NoMount")
    apply(src,"03-nomount-veux.patch")
    apply(src/"NoMount","03-nomount-stock-flags.patch")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase",choices=("base","susfs","bakasu","nomount"))
    parser.add_argument("src",type=Path)
    parser.add_argument("--archive",type=Path)
    parser.add_argument("--stock",type=Path,default=Path("boot.img"))
    parser.add_argument("--micode",type=Path,help="Persistent bare Xiaomi source cache")
    args=parser.parse_args(); prepare(args.phase,args.src.resolve(),args.archive,args.stock,args.micode)
