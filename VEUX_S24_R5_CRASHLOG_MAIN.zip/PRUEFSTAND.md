# Lokaler Prüfstand für VEUX S24-R5

Der gepinnte ARM64-Build wurde bis zum fertigen `Image` ausgeführt. LLDB hat alle fünf ausführbaren Abschnitte des lokalen `vmlinux` byteweise mit dem `Image` abgeglichen und 5.940.066 ARM64-Wortpositionen gelesen. Darin liegen auch eingebettete Daten. Für neun geänderte Display- und pstore-Funktionen wurden zusätzlich 2.300 Wörter gezielt geprüft. Der GitHub-Lauf dieser YAML und der Gerätetest stehen aus.

| Nachweis | Ergebnis |
| --- | --- |
| Original Xiaomi OS1.0.12.0.TKCMIXM | 1.187 Stock-Initialisierer mit gleicher Stufe und normalisiertem Namen vorhanden. Je 441 native und kompatible Systemaufrufziele stimmen überein. |
| Xiaomi-Original-QGKI | 3.148 Importzeilen von 37 Modulen geprüft. 2.579 Zeilen betreffen Kernel-Exporte und 569 Modulabhängigkeiten. |
| Weitere 66 GKI-Dateien aus Xiaomi `vendor_boot` | Bei allen 66 Dateien weicht `module_layout` sowohl unter Stock als auch unter R3 und R5 ab. `qpnp_pon_set_restart_reason` in `msm-poweroff.ko` hat unter R5 dieselbe Abweichung wie unter R3. |
| Display und Touch | Tests am Produktionscode decken ausstehende Panel-Wiederherstellung, unveränderte Helligkeit nach Fehlern, verspätete Wiederherstellung mit Wiederholungen, Zielwert 0 sowie Goodix-Fehler ab. 254 bisherige Touch-Fälle und 256 HBM-/Flat-Kombinationen samt acht weiteren Fällen bestanden. |
| Crashaufzeichnung | Der Test unterscheidet Panic, Notneustart und regulären Neustart. Der bisherige Ringleser konnte die erfassten Daten mit unveränderter Struktur lesen. Geprüft wurden auch belegte Sperren und die Größenbegrenzung. |
| Boot und AK3 | Stock und die exakte R13-Sicherung für Slot A beziehungsweise B ergeben jeweils das gleiche Prüfabbild. Falscher Slot, unbekanntes Ausgangsabbild und ein schon vorhandenes R5-Abbild wurden ebenfalls geprüft. Die sieben Fälle liefen auf Dateikopien. |

## Vergleich der ausführbaren Abschnitte

Die Tabelle zählt Abweichungen bei gleicher Position innerhalb des jeweiligen Abschnitts und gleicht zusätzlich eindeutige Textsymbole ab. Verschobene Funktionen, Adressen und Ausrichtungsdaten beeinflussen beide Zählungen.

| Referenz | Geprüfte Abschnitte | Vergleichbare Wortpositionen | Abweichende Wörter | Gemeinsame eindeutige Textbereiche | Bytegleiche Textbereiche |
| --- | ---: | ---: | ---: | ---: | ---: |
| Xiaomi Stock | 5 | 5.772.739 | 5.755.550 | 60.443 | 5.397 |
| GitHub S24-R3 | 5 | 5.940.056 | 5.613.400 | 61.661 | 12.326 |
| Gerätebestätigtes R13 | 3 | 5.813.300 | 5.803.647 | 47.297 | 4.222 |
| Gerätebestätigtes ConfigDiag10 | 3 | 5.810.769 | 5.801.110 | 47.232 | 4.218 |

Deckt die Referenz einen Abschnitt nur teilweise ab, reicht der Vergleich bis zur kürzeren Grenze. Teilweise eingebettete Daten und Padding sind in den Abschnittszählungen enthalten.

- Lokales R5-Kernelimage SHA-256 `e74fd8cfbe3a3e25fdbe30ee439ba73357ca3fac11a02698ade04e4651f858ab`
- Xiaomi-Stockkernel SHA-256 `6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b`
- Bootabbild aus dem lokalen R5-Build SHA-256 `c44d37c7124fb49b52054f0634d85760226ad350ddf0ca919f365239e7938211`

Beim S24-R3-Ausfall endet der vorhandene Kernelmitschnitt nach 6,75 Sekunden. Der Auslöser des späteren schwarzen Bildschirms bleibt offen. S24-R5 korrigiert reproduzierte Treiberfehler und ergänzt die Aufzeichnung für einen erneuten Ausfall. [GitHub-Lauf von S24-R3](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45582263867/job/139094982206)
