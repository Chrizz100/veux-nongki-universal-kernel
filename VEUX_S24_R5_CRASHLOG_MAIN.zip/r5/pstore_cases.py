"""Check fallback record routing against the unchanged persistent console format."""
from pathlib import Path
import re
import sys
from source_functions import function, run_case

tree=Path(sys.argv[1])
area=tree/"fs/pstore"
ram=(area/"ram.c").read_text()
ring=(area/"ram_core.c").read_text()
platform=(area/"platform.c").read_text()
header=(tree/"include/linux/pstore.h")
if header.exists():
    assert "#define PSTORE_FLAGS_DUMP_CONSOLE" in header.read_text()
assert "KMSG_DUMP_SHUTDOWN" in ram
assert re.search(r'if \(!psinfo \|\| tfm \|\| \(psinfo->flags & PSTORE_FLAGS_DUMP_CONSOLE\)\)',platform)

harness=r'''
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#define CHECK(e) do { if (!(e)) {fprintf(stderr,"line %d: %s\n",__LINE__,#e);exit(1);} } while (0)
#define notrace
#define unlikely(v) (v)
#define GFP_KERNEL 0
#define PRZ_FLAG_NO_LOCK 1
#define DEFINE_RAW_SPINLOCK(name) int name
#define raw_spin_trylock_irqsave(lock, flags) ((flags)=0, *(lock) ? 0 : (*(lock)=1))
#define raw_spin_lock_irqsave(lock, flags) do { (flags)=0; CHECK(!(*(lock))++); } while (0)
#define raw_spin_unlock_irqrestore(lock, flags) do {CHECK(--*(lock)==0);} while (0)
#define atomic_read(ptr) (*(ptr))
#define atomic_set(ptr, value) (*(ptr)=(value))
#define kmalloc(size, flags) malloc(size)
#define memcpy_toio memcpy
#define memcpy_fromio memcpy
#define pr_err(...) ((void)0)
#define pr_warn_ratelimited(...) ((void)0)
#define smp_processor_id() 0
#define RAMOOPS_FLAG_FTRACE_PER_CPU 1
#define PSTORE_FLAGS_DUMP_CONSOLE 16
struct persistent_ram_buffer { uint32_t sig; int start,size; char data[128]; };
struct persistent_ram_zone {
    struct persistent_ram_buffer *buffer;
    size_t buffer_size;
    int flags,buffer_lock;
    char *old_log;
    size_t old_log_size;
};
enum pstore_type_id { PSTORE_TYPE_DMESG,PSTORE_TYPE_CONSOLE,PSTORE_TYPE_FTRACE,PSTORE_TYPE_PMSG };
enum kmsg_dump_reason { KMSG_DUMP_UNDEF,KMSG_DUMP_PANIC,KMSG_DUMP_OOPS,KMSG_DUMP_EMERG,KMSG_DUMP_SHUTDOWN };
struct pstore_info { int flags; size_t bufsize; void *data; };
struct pstore_record { enum pstore_type_id type; enum kmsg_dump_reason reason; struct pstore_info *psi; char *buf; unsigned size, part; bool compressed; };
struct ramoops_context { struct persistent_ram_zone *cprz, **dprzs, **fprzs; unsigned flags,dump_write_cnt,max_dump_cnt; };
static void persistent_ram_update_header_ecc(struct persistent_ram_zone *z) {}
static void persistent_ram_update_ecc(struct persistent_ram_zone *z, int pos, int size) {}
static void persistent_ram_ecc_old(struct persistent_ram_zone *z) {}
static void persistent_ram_zap(struct persistent_ram_zone *z) {z->buffer->size=z->buffer->start=0;}
static size_t ramoops_write_kmsg_hdr(struct persistent_ram_zone *z,const struct pstore_record *r) { return 0; }
'''
main=r'''
int main(void) {
    struct persistent_ram_buffer memory={.sig=0x43474244};
    struct persistent_ram_zone zone={.buffer=&memory,.buffer_size=sizeof(memory.data)};
    struct ramoops_context ctx={.cprz=&zone};
    struct pstore_info info={.flags=PSTORE_FLAGS_DUMP_CONSOLE,.bufsize=50,.data=&ctx};
    char prefix[]="early boot\n", dump[]="held until crash\n";
    struct pstore_record r={.type=PSTORE_TYPE_CONSOLE,.psi=&info,
         .buf=prefix,.size=sizeof(prefix)-1,.part=1};
    CHECK(!ramoops_pstore_write(&r));

    r.type=PSTORE_TYPE_DMESG;r.buf=dump;r.size=strlen(dump);
    r.reason=KMSG_DUMP_OOPS;CHECK(ramoops_pstore_write(&r)==-ENOSPC);
    r.reason=KMSG_DUMP_PANIC;r.compressed=true;CHECK(ramoops_pstore_write(&r)==-ENOSPC);
    r.compressed=false;r.part=2;CHECK(ramoops_pstore_write(&r)==-ENOSPC);
    r.part=1;r.size=info.bufsize+1;CHECK(ramoops_pstore_write(&r)==-ENOSPC);
    r.size=strlen(dump);ramoops_console_lock=1;CHECK(ramoops_pstore_write(&r)==-EBUSY);
    CHECK(memory.size==strlen(prefix));ramoops_console_lock=0;
    CHECK(!ramoops_pstore_write(&r));
    persistent_ram_save_old(&zone);
    CHECK(zone.old_log_size==strlen(prefix)+strlen(dump));
    CHECK(!memcmp(zone.old_log,prefix,strlen(prefix)));
    CHECK(!memcmp(zone.old_log+strlen(prefix),dump,strlen(dump)));
    CHECK(memory.sig==0x43474244);

    r.reason=KMSG_DUMP_SHUTDOWN;CHECK(!ramoops_pstore_write(&r));
    r.reason=KMSG_DUMP_EMERG;CHECK(!ramoops_pstore_write(&r));
    r.reason=KMSG_DUMP_PANIC;ctx.cprz=NULL;CHECK(ramoops_pstore_write(&r)==-ENOSPC);

    free(zone.old_log);
    puts("PASS console panic, orderly and emergency restart, unchanged ring reader, size and part checks, busy lock");
}
'''
blocks=[harness,*(function(ring,n) for n in ("buffer_size","buffer_start","buffer_size_add",
                "buffer_start_add","persistent_ram_update","persistent_ram_write","persistent_ram_save_old")),
        "static DEFINE_RAW_SPINLOCK(ramoops_console_lock);",
        function(ram,"ramoops_write_console"),function(ram,"ramoops_pstore_write"),main]
run_case("\n".join(blocks),"ramoops")
