#!/bin/sh
# Repack only in the supplied working directory. The output must match the canonical build.
set -eu
original=$1
source_digest=$2
kit=$3
work=$4
magiskboot=$kit/tools/magiskboot
files=$kit/veux

fail() {
    echo "$*" >&2
    exit 1
}
check_file() {
    sum=$(sha256sum "$1") || fail "Lesefehler bei $1"
    got=${sum%% *}
    [ "$got" = "$2" ] || fail "Prüfsumme für $3 weicht ab. Ermittelt $got"
}

stock_rd=0bc8b54373b5501818e8b252517419786db207771047b6def7ec9bc89beb607a
case "$source_digest" in
    ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5)
        base=stock
        input_rd=$stock_rd
        ;;
    c6ed9ad7a90adf9d670a48da9b9edd9a2276e51598ffc7e2e4a6676434138ff6)
        base=r13
        input_rd=efa8d4af76e0582d48ddb0ab4cd60c94da18eec2b607eac41ad2fca5620b56ba
        ;;
    *) fail "Unbekannter Eingang $source_digest" ;;
esac
check_file "$original" "$source_digest" "Boot-Kopie"
check_file "$kit/Image" @KERNEL_SHA@ "Kernel"
check_file "$files/boot-header.bin" @HEADER_SHA@ "Bootheader"
check_file "$files/boot-avb-page.bin" @PAGE_SHA@ "Metadatenseite"
check_file "$files/boot-footer.bin" @FOOTER_SHA@ "Boot-Footer"

umask 077
mkdir "$work" || fail "Arbeitsverzeichnis konnte nicht angelegt werden"
cd "$work" || fail "Arbeitsverzeichnis nicht erreichbar"
"$magiskboot" unpack -n -h "$original" || fail "magiskboot konnte das Ausgangsabbild nicht entpacken"
check_file ramdisk.cpio "$input_rd" "Ramdisk im Ausgangsabbild"
if [ "$base" = r13 ]; then
    # Each recipe row copies a byte range from the exact R13 ramdisk or the bundled literal bytes.
    check_file "$files/ramdisk-r13-stock.map" 2bd6ac7c68a33f9c7c7a9e650fc76172c45fc1e0a88ae87b263d0c65a4b2db4a "Ramdisk-Bereichstabelle"
    check_file "$files/ramdisk-r13-stock.bin" 1e8f1a527ea9e510385f085f809f55d0d40b366e37ba70c8a4f27a6c517f28bc "Ramdisk-Ergänzung"
    while read -r type offset length; do
        case "$type" in
            base) part=ramdisk.cpio ;;
            patch) part=$files/ramdisk-r13-stock.bin ;;
            *) fail "Ungültiger Eintrag in der Bereichstabelle" ;;
        esac
        dd if="$part" bs=65536 iflag=skip_bytes,count_bytes skip="$offset" count="$length" 2>/dev/null ||
            fail "Ramdisk-Bereich bei $offset konnte nicht kopiert werden"
    done < "$files/ramdisk-r13-stock.map" > ramdisk.stock || fail "Ramdisk konnte nicht erstellt werden"
    check_file ramdisk.stock "$stock_rd" "rekonstruierte originale Xiaomi-Ramdisk"
    mv ramdisk.stock ramdisk.cpio || fail "Ramdisk konnte nicht übernommen werden"
fi
# The build uses the same page layout with the original Xiaomi ramdisk.
{
    cat "$files/boot-header.bin" &&
    dd if="$kit/Image" bs=4096 conv=sync &&
    dd if=ramdisk.cpio bs=4096 conv=sync &&
    cat "$files/boot-avb-page.bin"
} > draft.img || fail "Bootabbild konnte nicht gepackt werden."
dd if="$files/boot-footer.bin" of=draft.img bs=1 seek=134217664 conv=notrunc ||
    fail "Boot-Footer konnte nicht geschrieben werden."
check_file draft.img @BOOT_SHA@ "fertiges R5-Bootabbild"
mv draft.img reviewed-boot.img || fail "Geprüftes Abbild konnte nicht bereitgestellt werden."
