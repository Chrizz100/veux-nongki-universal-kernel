"""Run the changed display and touch dispatcher functions with controlled I/O."""
from pathlib import Path
import re
import sys
from source_functions import function, run_case

cfg = Path(sys.argv[1])
here = Path(__file__).resolve().parent
dsi = cfg / "techpack/display/msm/dsi"
panel = (dsi/"dsi_panel.c").read_text()
display = (dsi/"dsi_display.c").read_text()
connector = (dsi.parent/"sde/sde_connector.c").read_text()
touch = (cfg/"drivers/input/touchscreen/goodix_gtx8/goodix_ts_core.c").read_text()
touch_drm = touch[:touch.index("#else\nstatic int drm_notifier_callback")]
harness = (here/"panel_harness.h").read_text()
dec = re.search(r"enum veux_brightness_phase \{[\s\S]*?^#else", panel, re.M)[0].removesuffix("#else")
setup = r'''
#include <assert.h>
#define pr_info_ratelimited(...) ((void)0)
#define CHECK(e) do { if (!(e)) {fprintf(stderr,"line %d: %s\n",__LINE__,#e);exit(1);} } while (0)
static int calls, resume_calls, suspend_calls, resume_first, resume_next, delays;
struct goodix_ts_core { struct work_struct resume_work, suspend_work; };
static int goodix_ts_resume(struct goodix_ts_core *c) {
    return resume_calls++ ? resume_next : resume_first;
}
static int goodix_ts_suspend(struct goodix_ts_core *c) { suspend_calls++;return -EIO; }
static void usleep_range(unsigned lo, unsigned hi) { CHECK(lo==10000 && hi==12000);delays++; }
'''
main = r'''
static int counted_power(struct drm_connector *c,int mode,void *disp) {
    calls++;
    return dsi_display_set_power(c,mode,disp);
}
static void fire(struct dsi_panel *p) {
    p->wake_brightness_work.pending=0;
    dsi_panel_restore_brightness(&p->wake_brightness_work.work);
}
int main(void) {
    struct dsi_panel p={.bl_config={.type=DSI_BACKLIGHT_DCS,.bl_scale=1024,.bl_scale_sv=65535},
        .host=1,.cur_mode=1,.panel_initialized=1};
    struct dsi_display display={.panel=&p};
    struct sde_connector con={.lock=1,.display=&display,.allow_bl_update=1,.bl_scale=1024,
        .bl_scale_sv=65535,.unset_bl_level=U32_MAX,.lp_mode=SDE_MODE_DPMS_LP1,
        .ops={.set_power=counted_power,.set_backlight=dsi_display_set_backlight}};
#define POWER(mode) dsi_display_set_power(NULL,mode,&display)
#define LEVEL(value) dsi_display_set_backlight(NULL,&display,value)

    CHECK(!LEVEL(120));
    failed_command=DSI_CMD_SET_LP1;
    CHECK(_sde_connector_update_power_locked(&con)==-EIO && !notifications);
    CHECK(p.power_mode==SDE_MODE_DPMS_ON && con.last_panel_power_mode==SDE_MODE_DPMS_ON);
    CHECK(con.power_update_pending && calls==1);
    failed_command=-1;
    CHECK(!_sde_connector_update_power_locked(&con) && calls==2 && !con.power_update_pending);
    CHECK(p.power_mode==SDE_MODE_DPMS_LP1 && notifications==1);

    CHECK(!LEVEL(900) && level==120);
    CHECK(!dsi_panel_apply_veux_parameter(&p,0xa0000) && p.wake_brightness==900);
    con.lp_mode=SDE_MODE_DPMS_ON;failed_command=DSI_CMD_SET_NOLP;
    CHECK(_sde_connector_update_power_locked(&con)==-EIO);
    CHECK(p.power_mode==SDE_MODE_DPMS_LP1 && con.last_panel_power_mode==SDE_MODE_DPMS_LP1 && esd_on==0);
    failed_command=-1;
    CHECK(!_sde_connector_update_power_locked(&con) && calls==4 && esd_on==1);
    CHECK(p.wake_brightness_work.pending && p.wake_brightness_work.delay==13 && level==120);
    tx_error=-EIO;fire(&p);
    CHECK(p.wake_brightness_work.pending && p.last_dcs_brightness==120 && p.wake_retries==1);
    tx_error=0;
    CHECK(!LEVEL(0) && p.wake_brightness_valid);
    fire(&p);
    CHECK(level==0 && p.last_dcs_brightness==0 && p.brightness_phase==VEUX_BL_ACTIVE);

    CHECK(!POWER(SDE_MODE_DPMS_LP1));
    CHECK(!LEVEL(333) && !POWER(SDE_MODE_DPMS_ON));
    CHECK(!POWER(SDE_MODE_DPMS_LP1));
    unsigned old_writes=writes;fire(&p);CHECK(writes==old_writes);
    CHECK(!POWER(SDE_MODE_DPMS_ON));fire(&p);CHECK(level==333);

    CHECK(!POWER(SDE_MODE_DPMS_LP1));
    CHECK(!LEVEL(555) && !POWER(SDE_MODE_DPMS_ON));
    tx_error=-EIO;fire(&p);fire(&p);fire(&p);
    CHECK(p.last_dcs_brightness==333 && !p.wake_brightness_work.pending);
    tx_error=0;CHECK(!LEVEL(900));

    failed_command=DSI_CMD_SET_LP2;ulp_calls=0;
    CHECK(POWER(SDE_MODE_DPMS_LP2)==-EIO && ulp_calls==0 && p.power_mode==SDE_MODE_DPMS_ON);
    failed_command=-1;ulp_error=-EIO;
    CHECK(POWER(SDE_MODE_DPMS_LP2)==-EIO && ulp_calls==2 && ulp_value==0);
    CHECK(p.power_mode==SDE_MODE_DPMS_LP2);
    ulp_error=0; CHECK(!POWER(SDE_MODE_DPMS_ON));fire(&p);

    p.panel_initialized=0;old_writes=commands;
    CHECK(POWER(SDE_MODE_DPMS_LP1)==-EAGAIN && commands==old_writes);
    p.panel_initialized=1;p.esd_recovery_pending=1;
    CHECK(POWER(SDE_MODE_DPMS_LP1)==-EAGAIN && commands==old_writes);
    p.esd_recovery_pending=0;

    clock_off_error=-EBUSY;tx_error=-EIO;
    CHECK(LEVEL(77)==-EIO && p.last_dcs_brightness==900);
    clock_off_error=0;tx_error=0;
    con.unset_bl_level=0;tx_error=-EIO;
    CHECK(_sde_connector_update_bl_scale(&con)==-EIO && con.unset_bl_level==0);
    tx_error=0;
    CHECK(!_sde_connector_update_bl_scale(&con) && con.unset_bl_level==U32_MAX && level==0);

    struct goodix_ts_core goodix={0};
    resume_first=-EIO;resume_next=0;goodix_ts_resume_work(&goodix.resume_work);
    CHECK(resume_calls==2 && delays==1);
    resume_calls=0;resume_first=-ENODEV;goodix_ts_resume_work(&goodix.resume_work);
    CHECK(resume_calls==1 && delays==1);
    goodix_ts_suspend_work(&goodix.suspend_work);CHECK(suspend_calls==1);
    puts("PASS display mode errors and retries, deferred zero/HBM/ESD, bounded workers, clock and supply error ordering");
}
'''
panel_names = ("dsi_panel_update_backlight","dsi_panel_set_backlight","dsi_panel_enter_doze",
               "dsi_panel_reset_wake","dsi_panel_restore_brightness","dsi_panel_commit_power_mode",
               "dsi_panel_apply_veux_parameter","dsi_panel_set_lp1","dsi_panel_set_lp2","dsi_panel_set_nolp")
items = [harness,dec,setup,*(function(panel,n) for n in panel_names),
         *(function(display,n) for n in ("dsi_display_set_backlight","dsi_display_set_power")),
         *(function(connector,n) for n in ("_sde_connector_update_power_locked","_sde_connector_update_bl_scale")),
         *(function(touch_drm,n) for n in ("goodix_ts_resume_work","goodix_ts_suspend_work")),
         main]
run_case("\n".join(items),"display")
