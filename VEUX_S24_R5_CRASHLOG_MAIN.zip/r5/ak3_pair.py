"""Build the verified boot image and re-run the read-only AK3 entry on file copies."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
from tempfile import TemporaryDirectory
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
import sys

here = Path(__file__).resolve().parent
kit = here.parent
sys.path.insert(0, str(kit/"oem/tools/layout"))
sys.path.insert(0, str(kit))
from boot import make_image, unpack_m45
from ak3_tools import load

R13 = "c6ed9ad7a90adf9d670a48da9b9edd9a2276e51598ffc7e2e4a6676434138ff6"

def digest(blob):
    return sha256(blob).hexdigest()

def write_file(package, name, contents):
    entry = ZipInfo(name,(2026,11,26,0,0,0))
    mode = 0o755 if name.endswith(".sh") else 0o644
    entry.external_attr = (0o100000 | mode) << 16
    package.writestr(entry, contents, compress_type=ZIP_DEFLATED)

def package_ak3(out, candidate, kernel, page, digest_expected):
    parts = {"boot-header.bin":candidate[:4096],"boot-avb-page.bin":page,"boot-footer.bin":candidate[-64:]}
    replacements = {
        "@BOOT_SHA@":digest_expected, "@KERNEL_SHA@":digest(kernel),
        "@HEADER_SHA@":digest(parts["boot-header.bin"]),
        "@PAGE_SHA@":digest(page), "@FOOTER_SHA@":digest(parts["boot-footer.bin"]),
    }
    with ZipFile(kit/"oem/ak3-tools.zip") as original, ZipFile(out,"w") as z:
        for item in original.infolist():
            z.writestr(item,original.read(item))
        write_file(z,"Image",kernel)
        for name, data in parts.items():
            write_file(z,"veux/"+name,data)
        for file in sorted((here/"ak3").iterdir()):
            content=file.read_bytes()
            if file.suffix==".sh":
                for token,value in replacements.items():
                    content=content.replace(token.encode(),value.encode())
                if b"@BOOT_SHA@" in content or b"@KERNEL_SHA@" in content:
                    raise ValueError(file)
            name = file.name if file.name=="anykernel.sh" else "veux/"+file.name
            write_file(z,name,content)

def replay(package, candidate, stock, r13):
    with TemporaryDirectory(prefix="veux-r5-replay-") as path:
        root=Path(path)
        home=root/"ak"
        with ZipFile(package) as z:
            assert z.testzip() is None
            z.extractall(home)
        tool=home/"tools/magiskboot"
        original=tool.with_suffix(".arm")
        tool.rename(original)
        original.chmod(0o700)
        qemu=shutil.which("qemu-arm")
        if not qemu:
            raise RuntimeError("qemu-arm is required to run the packaged ARM tool")
        tool.write_text("#!/bin/sh\nexec "+shlex.quote(qemu)+" "+shlex.quote(str(original))+' "$@"\n')
        tool.chmod(0o700)
        core=home/"tools/ak3-core.sh"
        template=core.read_text()
        needle="\nsetup_ak;"
        if template.count(needle)!=1:
            raise ValueError("AK3 setup changed")
        core.write_text(template.replace(needle,'\nBLOCK="$TEST_BLOCK"; SLOT="$TEST_SLOT";'))
        cases=[]
        tempfiles=("slot-vorher.img","veux-pruefung.log","veux-repack")
        def run(label, filename, slot, content, success, repacked):
            for name in tempfiles:
                path=home/name
                if path.is_dir():
                    shutil.rmtree(path)
                elif path.exists():
                    path.unlink()
            block=root/filename
            block.write_bytes(content)
            saved=digest(content)
            env=dict(os.environ,AKHOME=str(home),OUTFD="1",TEST_BLOCK=str(block),TEST_SLOT=slot)
            p=subprocess.run(["sh","anykernel.sh"],cwd=home,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
            rendered=home/"veux-repack/reviewed-boot.img"
            result=(p.returncode==0, rendered.exists(), digest(block.read_bytes())==saved)
            if result!=(success,repacked,True) or (repacked and rendered.read_bytes()!=candidate):
                raise ValueError(label+"\n"+p.stdout.decode(errors="replace")[-1500:])
            cases.append(label)
        for suffix in ("a","b"):
            run("Xiaomi Stock boot_"+suffix,"boot_"+suffix,"_"+suffix,stock,True,True)
        if r13 is not None:
            raw=r13.read_bytes()
            assert digest(raw)==R13, "R13 rollback image identity"
            for suffix in ("a","b"):
                run("R13 backup boot_"+suffix,"boot_"+suffix,"_"+suffix,raw,True,True)
        run("reject wrong slot","boot_a","_b",stock,False,False)
        unknown=bytearray(stock);unknown[-1]^=1
        run("reject unknown digest","boot_a","_a",unknown,False,False)
        run("recognize existing R5","boot_a","_a",candidate,True,False)
        return cases

def build(stock_path, image, out, r13):
    load()
    stock, kernel = stock_path.read_bytes(), image.read_bytes()
    out.mkdir(parents=True,exist_ok=True)
    with TemporaryDirectory(prefix="veux-r5-avb-") as d:
        m45=unpack_m45(Path(d))
        candidate,page,_=make_image(m45,stock,kernel)
    boot_hash=digest(candidate)
    boot=out/"VEUX_S24_R5_boot_NOFLASH.img"
    ak3=out/"VEUX_S24_R5_AK3_VORPRUEFUNG_NOFLASH.zip"
    boot.write_bytes(candidate)
    package_ak3(ak3,candidate,kernel,page,boot_hash)
    cases=replay(ak3,candidate,stock,r13)
    result=dict(kernel_sha256=digest(kernel),boot_sha256=boot_hash,ak3_sha256=digest(ak3.read_bytes()),
                exact_stock_sha256=digest(stock),regular_file_tests=cases,
                r13_exact_backup_replayed=r13 is not None,device_pass=False,flash_allowed=False)
    (out/"Boot-AK3-Pruefung.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    for name in ("stock_path","image","out"): ap.add_argument(name,type=lambda s:Path(s).resolve())
    ap.add_argument("--r13",type=lambda s:Path(s).resolve())
    build(**vars(ap.parse_args()))
