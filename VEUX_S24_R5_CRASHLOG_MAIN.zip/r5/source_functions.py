"""Select complete function definitions from the C sources under test."""
from pathlib import Path
import re, subprocess, tempfile

def function(source, name):
    start, = re.finditer(r"^[a-zA-Z_][\w *\t]*\b" + name +
                           r"\([^;{}]*?\)\s*\{", source, re.M)
    return source[start.start():source.index("\n}", start.end())+2]

def run_case(source, name):
    with tempfile.TemporaryDirectory(prefix="veux-test-") as directory:
        file = Path(directory) / (name + ".c")
        file.write_text(source)
        binary = file.with_suffix("")
        subprocess.run(["cc","-std=gnu11","-O2","-Werror=implicit-function-declaration",
                        "-fsanitize=undefined","-fno-sanitize-recover=all",
                        str(file),"-o",str(binary)], check=True)
        subprocess.run([str(binary)], check=True)
