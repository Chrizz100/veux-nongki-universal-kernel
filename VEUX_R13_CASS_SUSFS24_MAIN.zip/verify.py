"""Check the R13 configuration, kernel build and module interface."""
import argparse
from collections import Counter
import csv
import gzip
from hashlib import file_digest, sha256
import json
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory

from debug import SUSFS_FEATURES

R13_CONFIG = "405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4"
R13_DTB = "42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37"
R13_KERNEL = "5.4.274-qgki-g82179e362f33"
VENDOR_ABI_FIELDS = ("crc", "symbol", "provider", "export_type", "namespace")
PRIORITY_FLAG = "CONFIG_KSU_SUSFS_PRIORITY_UID_FILTER"

def digest(path):
    with path.open("rb") as f:
        return file_digest(f, "sha256").hexdigest()

def expect(ok, name):
    if not ok:
        raise ValueError(name)

def config_flags(raw):
    values = {}
    for line in raw.decode().splitlines():
        if line.startswith("CONFIG_"):
            key, value = line.split("=", 1)
            values[key] = value
        elif line.startswith("# CONFIG_") and line.endswith(" is not set"):
            values[line.split()[1]] = "n"
    return values

def check_config(out, reference):
    old = reference / "R13.config"
    expect(digest(old) == R13_CONFIG, "R13 reference configuration digest")
    old_flags = config_flags(old.read_bytes())
    actual = config_flags((out / ".config").read_bytes())
    delta = {name: [old_flags.get(name), actual.get(name)]
             for name in sorted(set(actual) | set(old_flags)) if actual.get(name) != old_flags.get(name)}
    expect(delta == {PRIORITY_FLAG: [None, "y"]}, f"Unexpected R13 configuration delta: {delta}")
    enabled = {name for name, value in actual.items()
               if name.startswith("CONFIG_KSU_SUSFS_") and value == "y"}
    expect(enabled == SUSFS_FEATURES, f"Unexpected SUSFS feature set: {sorted(enabled)}")
    return delta

def read_symvers(path):
    result = []
    for line in path.read_text().splitlines():
        values = line.split()
        expect(len(values) in (4, 5) and re.fullmatch(r"0x[0-9a-fA-F]{8}", values[0]), path.name)
        if len(values) == 4:
            values.append("")
        result.append(tuple(values))
    return Counter(result)

def firmware_rows(path, symbols):
    exports = {symbol: crc.lower() for crc, symbol, provider, kind, name in symbols if provider == "vmlinux"}
    counts = Counter()
    with path.open(newline="") as f:
        for row in csv.DictReader(f):
            symbol, expected = row["symbol"], row["expected_crc"].lower()
            exported = exports.get(symbol)
            if exported is None:
                counts["kernel_symbol_unavailable"] += 1
            elif int(exported, 16) == int(expected, 16):
                counts["kernel_crc_matches_stock"] += 1
            else:
                counts["kernel_crc_differs_from_stock"] += 1
    return dict(counts)

def check_image(out, reference, evidence, objcopy):
    evidence.mkdir(parents=True, exist_ok=True)
    config_delta = check_config(out, reference)
    source = out / "arch/arm64/boot/Image"
    raw = source.read_bytes()
    expect(raw[56:60] == b"ARMd", "ARM64 Image magic")
    start = raw.index(b"IKCFG_ST\x1f\x8b") + 8
    config = gzip.decompress(raw[start:raw.index(b"IKCFG_ED", start)])
    expect(config == (out / ".config").read_bytes(), "Kernel IKCONFIG bytes")
    expect((out / "include/config/kernel.release").read_text().strip() == R13_KERNEL, "Broken R13 kernel release")
    expect(b"Linux version " + R13_KERNEL.encode() + b" " in raw and b" #2 SMP " in raw, "Kernel build marker")
    expect(b"v2.4.0\0" in raw, "SUSFS 2.4.0 marker")
    expect(b"v4.2.0-rc3-d2537b13@BakaSU\0" in raw, "Original BakaSU 35254 marker")
    with TemporaryDirectory(prefix="veux-image-") as temp:
        temp_img = Path(temp) / "Image"
        subprocess.run([objcopy, "-O", "binary", "-R", ".note", "-R", ".note.gnu.build-id",
                        "-R", ".comment", "-S", out / "vmlinux", temp_img], check=True)
        expect(temp_img.read_bytes() == raw, "Image must match vmlinux export")
    lower = read_symvers(reference / "R13.Module.symvers")
    newer = read_symvers(out / "Module.symvers")
    boot_data = json.loads((reference / "R13_Boot_Daten.json").read_text())
    dtb = digest(out / "arch/arm64/boot/dts/vendor/xiaomi/veux.dtb")
    record = {
        "kernel_SHA256": sha256(raw).hexdigest(),
        "kernel_bytes": len(raw),
        "release": R13_KERNEL,
        "Image_und_ELF_bytegleich": True,
        "SUSFS": "2.4.0",
        "BakaSU": "35254",
        "NoMount": "Kernel-API 22",
        "R13_Konfigurationsdelta": config_delta,
        "eingebettete_Konfiguration_SHA256": sha256(config).hexdigest(),
        "DTB_SHA256": dtb,
        "DTB_entspricht_R13": dtb == R13_DTB,
        "ABI_Felder": VENDOR_ABI_FIELDS,
        "ABI_Zeilen_R13": sum(lower.values()),
        "ABI_Zeilen_Kandidat": sum(newer.values()),
        "ABI_gemeinsame_Zeilen": sum((lower & newer).values()),
        "ABI_fehlende_R13_Zeilen": list((lower - newer).elements()),
        "ABI_neue_Zeilen": list((newer - lower).elements()),
        "Stock_Originalmodule_Kernelimporte_R13": firmware_rows(reference / "Xiaomi-QGKI-Importe.csv", lower),
        "Stock_Originalmodule_Kernelimporte_Kandidat": firmware_rows(reference / "Xiaomi-QGKI-Importe.csv", newer),
        "R13_Boot_Partitionsgroesse": boot_data["slot_size"],
        "R13_Boot_Header_Version": boot_data["version"],
        "device_pass": False,
        "flash_allowed": False,
    }
    (evidence / "R13-SUSFS24-Kernelpruefung.json").write_text(json.dumps(record, indent=2) + "\n")
    expect(dtb == R13_DTB, "VEUX device tree changed")
    expect(not lower - newer and not newer - lower, "R13 module ABI differs")
    print(json.dumps(record, indent=2))

def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_subparsers(dest="action", required=True)
    for name in ("config", "image"):
        sub = mode.add_parser(name)
        sub.add_argument("out", type=Path)
        sub.add_argument("reference", type=Path)
        if name == "image":
            sub.add_argument("evidence", type=Path)
            sub.add_argument("--objcopy", required=True)
    args = parser.parse_args()
    if args.action == "config":
        print(json.dumps(check_config(args.out, args.reference)))
    else:
        check_image(args.out, args.reference, args.evidence, args.objcopy)

if __name__ == "__main__":
    main()
