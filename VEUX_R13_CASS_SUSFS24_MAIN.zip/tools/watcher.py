"""Exercise the exact v2.4 watcher compiled into the R13 candidate."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse
import json
import os
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("source", type=Path)
parser.add_argument("evidence", type=Path)
args = parser.parse_args()
source = (args.source / "fs/susfs.c").read_text()
start = source.index("static struct fsnotify_group *sdcard_group;")
end = source.index("// - defer extra susfs works", start)
fixture = Path(__file__).with_name("watch.c")
with TemporaryDirectory(prefix="r13-watch-") as tmp:
    work = Path(tmp)
    (work / "watch-under-test.inc").write_text(source[start:end])
    exe = work / "watch"
    subprocess.run(["cc", "-std=gnu11", "-O2", "-g", "-pthread", "-no-pie",
                    "-fno-omit-frame-pointer", "-fsanitize=address,undefined",
                    "-fno-sanitize-recover=all", "-Werror=implicit-function-declaration",
                    "-I", work, fixture, "-o", exe], check=True)
    env = os.environ | {"ASAN_OPTIONS": "detect_leaks=0:halt_on_error=1",
                        "UBSAN_OPTIONS": "halt_on_error=1"}
    message = subprocess.check_output([exe], env=env, text=True, timeout=25).strip()
args.evidence.mkdir(parents=True, exist_ok=True)
(args.evidence / "R13-SUSFS24-Watcher.json").write_text(json.dumps({"tests": message}) + "\n")
print(message)
