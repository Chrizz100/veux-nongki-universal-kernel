"""Verify a v3 boot layout in memory using the device-confirmed R13 backup."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
from zipfile import ZipFile

PAGE = 4096
R13_BOOT = "c6ed9ad7a90adf9d670a48da9b9edd9a2276e51598ffc7e2e4a6676434138ff6"

def align(size):
    return (size + PAGE - 1) // PAGE * PAGE

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def split(raw):
    if raw[:8] != b"ANDROID!" or struct.unpack_from("<I", raw, 40)[0] != 3:
        raise ValueError("Need an Android boot header v3")
    kernel_size, ramdisk_size, _, header_size = struct.unpack_from("<4I", raw, 8)
    if header_size != 1580 or not kernel_size or not ramdisk_size:
        raise ValueError("Invalid boot sections")
    ramdisk_offset = PAGE + align(kernel_size)
    if ramdisk_offset + ramdisk_size > len(raw):
        raise ValueError("Truncated ramdisk")
    return raw[:PAGE], raw[PAGE:PAGE + kernel_size], raw[ramdisk_offset:ramdisk_offset + ramdisk_size]

def padding(raw):
    return b"\0" * (align(len(raw)) - len(raw))

def probe(backup, candidate, output):
    with ZipFile(backup) as z:
        original = z.read("Rueckweg/boot_a_2026-11-21.img")
    if sha(original) != R13_BOOT:
        raise ValueError("The backup is not the device-confirmed R13")
    old_header, old_image, ramdisk = split(original)
    image = candidate.read_bytes()
    if image[56:60] != b"ARMd":
        raise ValueError("Need an ARM64 Image")
    header = bytearray(old_header)
    struct.pack_into("<I", header, 8, len(image))
    layout = b"".join((header, image, padding(image), ramdisk, padding(ramdisk)))
    new_header, new_image, new_ramdisk = split(layout)
    if (len(layout) > len(original) or new_image != image or new_ramdisk != ramdisk
            or new_header[:8] != old_header[:8] or new_header[12:] != old_header[12:]):
        raise ValueError("R13 boot layout comparison failed")
    evidence = {
        "R13_boot_SHA256": R13_BOOT,
        "R13_Image_SHA256": sha(old_image),
        "Kandidat_Image_SHA256": sha(image),
        "R13_Ramdisk_SHA256": sha(ramdisk),
        "Kandidat_Ramdisk_SHA256": sha(new_ramdisk),
        "boot_header_version": 3,
        "slot_bytes": len(original),
        "payload_bytes": len(layout),
        "R13_cmdline_und_os_felder_bytegleich": True,
        "R13_Ramdisk_bytegleich": True,
        "partition_image_published": False,
        "device_pass": False,
    }
    output.write_text(json.dumps(evidence, indent=2) + "\n")
    print(json.dumps(evidence, indent=2))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    for name in ("backup", "candidate", "output"):
        p.add_argument(name, type=Path)
    probe(**vars(p.parse_args()))
