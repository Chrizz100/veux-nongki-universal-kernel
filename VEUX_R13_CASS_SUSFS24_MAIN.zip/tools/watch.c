/* File-notification ownership test. The implementation under test is extracted from fs/susfs.c. */
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define KERNEL_VERSION(a,b,c) (((a)<<16)|((b)<<8)|(c))
#define LINUX_VERSION_CODE KERNEL_VERSION(5,4,274)
#define GFP_KERNEL 0
#define LOOKUP_FOLLOW 1
#define FS_EVENT_ON_CHILD 1
#define FS_ISDIR 2
#define FS_OPEN_PERM 4
#define HZ 100
#define SUSFS_LOGE(...) ((void)0)
#define SUSFS_LOGI(...) ((void)0)
#define SDCARD_ANDROID_PATH "/data/media/0/Android"
#define DEFINE_MUTEX(k) pthread_mutex_t k=PTHREAD_MUTEX_INITIALIZER
#define mutex_lock(m) pthread_mutex_lock(m)
#define mutex_unlock(m) pthread_mutex_unlock(m)
#define IS_ERR(p) ((uintptr_t)(p)>=(uintptr_t)-4095)
#define PTR_ERR(p) ((long)(intptr_t)(p))
#define ERR_PTR(v) ((void *)(intptr_t)(v))
typedef unsigned int u32;
struct cred {int value;};
struct work_struct {int value;};
struct delayed_work {void (*fn)(struct work_struct *);};
#define DECLARE_DELAYED_WORK(n,f) struct delayed_work n={f}
struct qstr {unsigned int len; const char *name;};
struct inode {int value;};
struct dentry {struct inode *inode;};
struct path {void *mnt; struct dentry *dentry;};
struct fsnotify_group;
struct fsnotify_mark {struct fsnotify_group *group; unsigned int mask; int refs;};
struct fsnotify_iter_info;
struct fsnotify_ops {
    int (*handle_event)(struct fsnotify_group *,struct inode *,u32,const void *,int,const struct qstr *,u32,struct fsnotify_iter_info *);
    void (*free_mark)(struct fsnotify_mark *);
};
struct fsnotify_group {const struct fsnotify_ops *ops; struct fsnotify_mark *attached; int refs;};
enum failure {OK, THREAD, CRED, DOMAIN, GROUP, PATH, INODE, ALLOCATION, ATTACH};
static enum failure failure;
static struct cred cred;
static struct inode inode;
static struct dentry dentry={&inode};
static struct fsnotify_group group;
static struct delayed_work *pending;
static int susfs_is_sdcard_android_data_not_decrypted=1,system_unbound_wq;
static int path_refs,marks,groups,starts,last_result,work_queued,freed,expect_event_during_add;
static pthread_t cleanup_thread;
static pthread_barrier_t cleanup_barrier;
static unsigned long test_and_set_bit(int bit,unsigned long *bits){return __atomic_fetch_or(bits,1UL<<bit,__ATOMIC_SEQ_CST)&(1UL<<bit);}
static void clear_bit(int bit,unsigned long *bits){__atomic_fetch_and(bits,~(1UL<<bit),__ATOMIC_SEQ_CST);}
static int static_key_enabled(int *v){return *v;}
static void static_branch_disable(int *v){assert(*v);*v=0;}
static struct cred *prepare_creds(void){return failure==CRED?NULL:&cred;}
static void setup_selinux(const char *s,struct cred *c){assert(c==&cred && s);}
static void commit_creds(struct cred *c){assert(c==&cred);}
static bool susfs_is_current_ksu_domain(void){return failure!=DOMAIN;}
static void *kthread_run(int (*fn)(void *),void *p,const char *name){
    assert(name);starts++;if(failure==THREAD)return ERR_PTR(-EAGAIN);
    last_result=fn(p);return &cred;
}
static struct fsnotify_group *fsnotify_alloc_group(const struct fsnotify_ops *ops){
    assert(!groups);if(failure==GROUP)return ERR_PTR(-ENOMEM);
    assert(ops->handle_event && ops->free_mark);group=(struct fsnotify_group){.ops=ops,.refs=1};groups++;return &group;
}
static void group_put(struct fsnotify_group *g){assert(g==&group && g->refs>0);if(!--g->refs)groups--;}
static int kern_path(const char *s,int flags,struct path *p){
    assert(!strcmp(s,"/data/media/0") && flags==LOOKUP_FOLLOW);
    if(failure==PATH)return -ENOENT;
    *p=(struct path){&inode,&dentry};path_refs++;return 0;
}
static struct inode *d_backing_inode(struct dentry *d){assert(d==&dentry);return failure==INODE?NULL:d->inode;}
static void path_put(struct path *p){assert(p->mnt && p->dentry && path_refs==1);path_refs--;}
static void *kzalloc(size_t size,int flags){if(failure==ALLOCATION)return NULL;marks++;return calloc(1,size);}
static void kfree(struct fsnotify_mark *m){assert(!m->refs && marks==1);marks--;freed++;free(m);}
static void fsnotify_init_mark(struct fsnotify_mark *m,struct fsnotify_group *g){m->refs=1;m->group=g;g->refs++;}
static void fsnotify_put_mark(struct fsnotify_mark *m){
    assert(m->refs>0);if(--m->refs==0){struct fsnotify_group *g=m->group;g->ops->free_mark(m);group_put(g);}
}
static void release_attachment(struct fsnotify_group *g){
    if(g->attached){struct fsnotify_mark *m=g->attached;g->attached=NULL;fsnotify_put_mark(m);}
}
static void fsnotify_destroy_group(struct fsnotify_group *g){assert(g==&group);release_attachment(g);group_put(g);}
static void event(const struct qstr *name){assert(group.attached);group.ops->handle_event(&group,&inode,FS_ISDIR,NULL,0,name,0,NULL);}
static void queue_delayed_work(int wq,struct delayed_work *work,int delay){
    assert(!pending && delay==5*HZ);pending=work;work_queued++;
}
static void *cleanup_early(void *arg){struct delayed_work *w=arg;pthread_barrier_wait(&cleanup_barrier);w->fn(NULL);return NULL;}
static int fsnotify_add_inode_mark(struct fsnotify_mark *m,struct inode *i,int allow_dup){
    assert(i==&inode && !allow_dup && !group.attached && m->mask==(FS_ISDIR|FS_OPEN_PERM|FS_EVENT_ON_CHILD));
    if(failure==ATTACH)return -EEXIST;
    group.attached=m;m->refs++;
    if(expect_event_during_add){
        event(&(struct qstr){7,"Android"});assert(pending);
        pthread_barrier_init(&cleanup_barrier,NULL,2);
        assert(!pthread_create(&cleanup_thread,NULL,cleanup_early,pending));
        pthread_barrier_wait(&cleanup_barrier);
    }
    return 0;
}

#include "watch-under-test.inc"

static void reset_case(void){
    assert(!marks && !groups && !path_refs);pending=NULL;starts=0;last_result=123;
    work_queued=freed=0;sdcard_monitor_started=sdcard_cleanup_scheduled=0;
    susfs_is_sdcard_android_data_not_decrypted=1;expect_event_during_add=0;
}
static void finish(bool evict){
    assert(group.attached && group.attached->refs==1 && path_refs==1);
    event(NULL);event(&(struct qstr){6,"Androi"});event(&(struct qstr){7,"another"});
    assert(!pending);event(&(struct qstr){7,"Android"});event(&(struct qstr){7,"Android"});
    assert(pending && work_queued==1);
    if(evict)release_attachment(&group);
    pending->fn(NULL);pending->fn(NULL);
    assert(!marks && !groups && !path_refs && freed==1 && !sdcard_group && !sdcard_path.mnt);
}
int main(void){
    for(int i=THREAD;i<=ATTACH;i++){
        reset_case();failure=i;susfs_start_sdcard_monitor_fn();
        int expected[]={0,123,-ENOMEM,-EINVAL,-ENOMEM,-ENOENT,-ENOENT,-ENOMEM,-EEXIST};
        assert(last_result==expected[i] && starts==1 && !sdcard_monitor_started);
        assert(!marks && !groups && !path_refs && !pending && freed==(i==ATTACH));
        freed=0;failure=OK;susfs_start_sdcard_monitor_fn();
        assert(!last_result && starts==2);finish(false);
    }
    reset_case();failure=OK;susfs_start_sdcard_monitor_fn();susfs_start_sdcard_monitor_fn();
    assert(starts==1);finish(true);susfs_start_sdcard_monitor_fn();assert(starts==1);
    reset_case();expect_event_during_add=1;susfs_start_sdcard_monitor_fn();
    assert(!pthread_join(cleanup_thread,NULL));pthread_barrier_destroy(&cleanup_barrier);
    assert(!last_result && !marks && !groups && !path_refs && freed==1 && work_queued==1);
    puts("8 setup failures with retry, duplicate starts/events, detach, early concurrent cleanup passed");
    return 0;
}
