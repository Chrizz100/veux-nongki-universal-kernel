# VEUX R13-CASS mit SUSFS 2.4.0

26. November 2026 · POCO X4 Pro 5G · HyperOS Global OS1.0.12.0.TKCMIXM

**Der lokale ARM64-Vollbuild und die statischen Prüfungen sind bestanden.** Der neue Build hat noch keinen Gerätepass und keine Flash-Freigabe. Der zur Rückkehr bestätigte R13 besitzt einen eigenen Gerätepass. [Historischer R13-CASS-Lauf](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/40921711051)

## R13 als Basis

75.425 Dateien des äußeren Kernelbaums wurden gegen das historische Quellinventar abgeglichen. Anschließend wurde BakaSU aus dem originalen R13-Git-Baum a0fb073cc22c7cba0fce0fff5dfb33e99669cb36 rekonstruiert. Der neue Port umfasst vier Dateien. Die Buildkennzeichnung #2 unterscheidet den Kandidaten in Gerätemitschnitten.

| Komponente | Version |
| --- | --- |
| Kernel | 5.4.274-qgki-g82179e362f33, CASS |
| SUSFS | 2.4.0 auf Basis des gepinnten QGKI-5.4-Commits 7a82d707 |
| BakaSU | R13 35254, d2537b13 |
| NoMount | R13 Kernel-API 22 |

Der Port verwendet die R13-BakaSU-Schnittstellen. Zwei bestehende 5.4-Aufrufer erhalten ihre passenden Adapter. Die einzige zusätzliche Konfiguration ist CONFIG_KSU_SUSFS_PRIORITY_UID_FILTER=y. Sie bildet den im älteren R13 bereits aktiven Pfad in der neuen Struktur von SUSFS 2.4 ab. Die zusätzlichen 2.4-Steuerbefehle eines neueren Managers sind außerhalb dieses Ports. [Gepinnter SUSFS-Quellstand](https://github.com/midori01/susfs4ksu/tree/7a82d7073222f88b256b30e90e9db2db4c5df56d)

## Zehn SUSFS-Funktionen und 5.4-Backports

| Geprüftes Image | Einträge im gelinkten Statuspfad | Aufruf des Prioritäts-UID-Filters |
| --- | ---: | --- |
| Gerätebestätigter R13 mit SUSFS 2.3.0 | 9 | An Adresse 0xffffffc0102d8048 bestätigt |
| Neuer R13 mit SUSFS 2.4.0 | 10 | An Adresse 0xffffffc0102d8058 bestätigt |

Der zehnte Eintrag ist CONFIG_KSU_SUSFS_PRIORITY_UID_FILTER. Seine Referenz im gelinkten Statuspfad des neuen Images zeigt auf den Text bei Image-Offset 0x1a71b52. Beide Images enthalten den eigentlichen Funktionsaufruf. Der neue Workflow prüft sowohl die zehn Kconfig-Optionen als auch die zehn Textreferenzen direkt im gelinkten Statuspfad und den Aufruf des zehnten Pfads. Das Ergebnis steht neben den übrigen statischen Nachweisen.

JackA1ltman und cyberc3dr führen denselben 5.4-Patch mit Git-Blob 21a0bfee96231d890d5dd667fee908df13a417e4. Jacks Workflow schreibt die Prioritätsoption ohne Wert in die Defconfig. Die R13-Konfiguration aktiviert sie ausdrücklich mit =y. [JackA1ltman · SUSFS-Workflow](https://github.com/JackA1ltman/NonGKI_Kernel_Build_2nd/blob/ec069a4e34f992d602a6b40d2e211df2516e2865/.github/workflows/patch-susfs/action.yml#L35-L48) · [cyberc3dr · 5.4-Backport](https://github.com/cyberc3dr/nGKI_Kernel_Build/blob/1ae6e01ac7df095942985fa79223aaa3b5f81174/Patches/Patch/susfs_patch_to_5.4.patch)

Die drei Ergänzungen im separaten Midori-Patch von cyberc3dr sind in R13 vorhanden. Das betrifft die Kbuild-Einbindung von susfs.o, die Mount-Namespace-Anbindung und den SUSFS-Header für procfs. Der Code für den R13 stammt vom zugehörigen gepinnten 5.4-Port. [cyberc3dr · Midori-Ergänzungen](https://github.com/cyberc3dr/nGKI_Kernel_Build/blob/1ae6e01ac7df095942985fa79223aaa3b5f81174/Patches/Patch/midori_susfs_fix.patch)

## Ergebnisse am fertigen Image

- Alle 12.947 Einträge der Modulschnittstelle entsprechen R13 nach Symbol, CRC, Exporttyp, Anbieter und Namespace. Der Gerätebaum für veux hat die SHA-256 des lauffähigen R13.
- Alle Image-Kernelbytes entsprechen dem Export aus dem gelinkten ELF. LLDB prüfte 2.064 Codewörter in 21 Funktionen. Darunter sind CASS-Start, Touch, Display, Wakeup und der SUSFS-Dateiwächter. Die gelinkte Rückruf-Tabelle des Dateiwächters verweist über den korrekten CFI-Sprung auf seine Freigabefunktion.
- Die Tests mit dem Produktionscode des Dateiwächters bestanden acht erzwungene Einrichtungsfehler mit Wiederholung sowie doppelte Ereignisse und gleichzeitiges Aufräumen.
- Der Bootlayout-Test verwendet die SHA-geprüfte persönliche R13-Sicherung. Build und Rückleseprobe passen in die 128-MiB-Partition. Die Ramdisk mit 22.061.337 Bytes, die Kernel-Kommandozeile und die OS-Felder blieben in der Layoutprobe bytegleich. Die Probe arbeitet im Speicher. [Format des Android-Bootheaders](https://source.android.com/docs/core/architecture/bootloader/boot-image-header#boot-image-header-version-3)
- Die beiden Modpost-Warnungen für embms_tm_multicast_recv und ope_soc_info stehen bereits in den historischen R13- und R61-Bauprotokollen.

## Vergleich mit Xiaomi Stock und den geprüften Kontrollkerneln

| Referenz | Abschnitte | Verglichene Wörter | Abweichende Wörter | Bytegleiche gemeinsame Textbereiche |
| --- | ---: | ---: | ---: | ---: |
| Xiaomi Stock | 5 | 5.698.918 | 5.687.270 | 3.342 |
| Gerätebestätigter R13 | 3 | 5.817.056 | 5.706.914 | 16.154 |
| ConfigDiag10 | 3 | 5.810.769 | 5.783.106 | 14.275 |

Der Vergleich zählt gleiche Positionen in den verfügbaren ausführbaren Abschnitten. Layout, Adressen und Ausrichtung beeinflussen die Zahl der Unterschiede. Bei den 3.148 Importzeilen der 37 Xiaomi-QGKI-Module ergibt der statische Check dieselbe Einstufung wie für den laufenden R13. 1.303 Kernel-CRCs stimmen mit der Xiaomi-Referenz überein, 1.752 weichen ab und 93 Symbolnamen sind in der Kernel-Exportliste nicht verfügbar. Diese Auswertung ersetzt keinen Ladevorgang am Gerät.

| SHA-256 | Wert |
| --- | --- |
| R13-Kernel aus der persönlichen Sicherung | 434f36efa102262896767734263c104c4a3e5fb028add310783768cca5ee1c37 |
| Neuer lokaler R13-Kernel mit SUSFS 2.4 | 3e896597396580c4e96ea0d82fa0abee16861a400677bef41062deada296494c |
| Lokaler Gerätebaum | 42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37 |
| Quellpatch für SUSFS 2.4 auf R13 | 778533dbb761237c503c5e0239eb7965a21619c91a9d58d66c1faa4f780c215c |

Der nächste GitHub-Build erzeugt erneut das Rohimage und die passenden Debugnachweise. Der Gerätepass bleibt eine Prüfung der konkret erzeugten Fassung am POCO.
