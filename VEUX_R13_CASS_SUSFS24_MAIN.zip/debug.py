"""Inspect linked ARM64 startup and filesystem code with LLDB."""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

WORD = re.compile(r"\[(0x[0-9a-fA-F]+)\].*?:\s+(0x[0-9a-fA-F]{8})\s")
FEATURE_LABEL = re.compile(rb"CONFIG_KSU_SUSFS_[A-Z_]+\n\0")
SUSFS_FEATURES = frozenset("CONFIG_KSU_SUSFS_" + name for name in (
    "SUS_PATH", "SUS_MOUNT", "SUS_KSTAT", "SPOOF_UNAME", "ENABLE_LOG",
    "HIDE_KSU_SUSFS_SYMBOLS", "SPOOF_CMDLINE_OR_BOOTCONFIG", "OPEN_REDIRECT",
    "SUS_MAP", "PRIORITY_UID_FILTER",
))
FUNCTIONS = (
    "start_kernel", "sched_init", "kernel_init_freeable", "do_execveat_common",
    "susfs_init", "susfs_show_version", "susfs_start_sdcard_monitor_fn",
    "susfs_sdcard_monitor_fn", "susfs_handle_sdcard_inode_event",
    "susfs_sdcard_cleanup_fn", "susfs_free_sdcard_mark",
    "susfs_open_redirect_spoof_vfs_statfs", "susfs_open_redirect_spoof_seq_show",
    "susfs_is_inode_sus_path", "vfs_statfs", "nomount_init",
    "goodix_ts_core_init", "dsi_display_set_backlight", "wakeup_reason_init",
    "susfs_get_enabled_features", "__arm64_sys_getpriority",
    "susfs_is_priority_uid_filtered",
)

def symbols(path):
    result = []
    for line in path.read_text().splitlines():
        address, kind, name = line.split(maxsplit=2)
        result.append((int(address, 16), kind, name))
    return result

def reported_features(image, base, words):
    """Resolve the ARM64 literal references inside the linked status getter."""
    references = {}
    pages = {}
    for pc, word in sorted(words.items()):
        opcode = word & 0x9F000000
        if opcode in (0x10000000, 0x90000000):  # ADR and ADRP
            immediate = ((word >> 5) & 0x7FFFF) << 2 | ((word >> 29) & 3)
            immediate = (immediate ^ 0x100000) - 0x100000
            if opcode == 0x90000000:
                pages[word & 31] = (pc, (pc & ~4095) + (immediate << 12))
                continue
            target = pc + immediate
        elif word & 0xFF800000 == 0x91000000:  # ADD (64-bit immediate)
            source = pages.get((word >> 5) & 31)
            if source is None or pc - source[0] > 32:
                continue
            shift = 12 if word & (1 << 22) else 0
            target = source[1] + (((word >> 10) & 0xFFF) << shift)
        else:
            continue
        offset = target - base
        match = FEATURE_LABEL.match(image, offset) if 0 <= offset < len(image) else None
        if match:
            label = match[0][:-2].decode("ascii")
            references[label] = {"instruction": hex(pc), "image_offset": hex(offset)}
    return references

def inspect(out, evidence, lldb):
    evidence.mkdir(parents=True, exist_ok=True)
    sym = symbols(out / "System.map")
    base, = {addr for addr, _, name in sym if name == "_text"}
    text = [(addr, name) for addr, typ, name in sym if typ in "tTwW"]
    addresses = sorted({addr for addr, _ in text})
    spans = {}
    for fn in FUNCTIONS:
        label = re.compile(re.escape(fn) + r"(?:\$[0-9a-f]{32}|\.llvm\.[0-9]+)?$")
        candidates = [(addr, symname) for addr, symname in text if label.fullmatch(symname)]
        if not candidates:
            continue
        addr, symname = min(candidates)
        nxt = bisect.bisect_right(addresses, addr)
        if nxt == len(addresses):
            continue
        size = min(addresses[nxt] - addr, 4096)
        if size <= 0 or size % 4:
            raise ValueError(fn)
        spans[fn] = {"address": addr, "name": symname, "words": size // 4}
    required = (
        "start_kernel", "sched_init", "susfs_sdcard_monitor_fn", "susfs_free_sdcard_mark",
        "susfs_get_enabled_features", "__arm64_sys_getpriority", "susfs_is_priority_uid_filtered",
    )
    for name in required:
        if name not in spans:
            raise ValueError(f"Required linked path is missing: {name}")
    args = evidence / "R13-SUSFS24.lldb"
    args.write_text("".join(f"disassemble --bytes --start-address {row['address']:#x} --count {row['words']}\n"
                            for row in spans.values()))
    cmd = [lldb, "--batch", "-f", str((out / "vmlinux").resolve()), "-s", args]
    report = evidence / "R13-SUSFS24-LLDB.txt"
    with report.open("w") as f:
        subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, text=True, check=True)
    decoded = {int(pc, 16): int(bits, 16) for pc, bits in WORD.findall(report.read_text())}
    image = (out / "arch/arm64/boot/Image").read_bytes()
    for fn, row in spans.items():
        for pc in range(row["address"], row["address"] + 4 * row["words"], 4):
            if not 0 <= pc - base <= len(image) - 4:
                raise ValueError(f"{fn} points outside Image")
            bits, = struct.unpack_from("<I", image, pc - base)
            if decoded.get(pc) != bits:
                raise ValueError(f"{fn} LLDB did not confirm {pc:#x} = {bits:#x}")
    def exact(name):
        address, = {addr for addr, _, label in sym if label == name}
        return address

    def branch(pc, bits):
        if bits >> 26 not in (5, 37):
            return None
        displacement = (bits & 0x3FFFFFF) ^ 0x2000000
        return pc + 4 * (displacement - 0x2000000)

    status = spans["susfs_get_enabled_features"]
    status_words = {pc: decoded[pc] for pc in range(
        status["address"], status["address"] + 4 * status["words"], 4)}
    features = reported_features(image, base, status_words)
    if set(features) != SUSFS_FEATURES:
        raise ValueError(f"Incorrect SUSFS status feature set in linked Image: {sorted(features)}")

    getpriority = spans["__arm64_sys_getpriority"]
    priority_filter = spans["susfs_is_priority_uid_filtered"]["address"]
    priority_calls = [pc for pc in range(getpriority["address"],
                    getpriority["address"] + 4 * getpriority["words"], 4)
                      if branch(pc, decoded[pc]) == priority_filter]
    if len(priority_calls) != 1:
        raise ValueError("Missing or ambiguous linked SUSFS priority filter")

    table = exact("fsnotify_ops")
    free = spans["susfs_free_sdcard_mark"]
    watcher = spans["susfs_handle_sdcard_inode_event"]
    free_entry = exact(free["name"] + ".cfi_jt")
    event_entry = exact(watcher["name"] + ".cfi_jt")
    handler, = struct.unpack_from("<Q", image, table - base)
    destructor, = struct.unpack_from("<Q", image, table - base + 32)
    jump, = struct.unpack_from("<I", image, free_entry - base)
    free_words = range(free["address"], free["address"] + 4 * free["words"], 4)
    kfree = exact("kfree")
    if (handler != event_entry or destructor != free_entry
            or branch(free_entry, jump) != free["address"]
            or not any(branch(pc, decoded[pc]) == kfree for pc in free_words)):
        raise ValueError("Incorrect fsnotify callback or destructor in candidate")
    result = {"Kern_SHA256": hashlib.sha256(image).hexdigest(),
              "Funktionen": spans, "mit_Image_abgeglichene_Woerter": len(decoded),
              "SUSFS_Statusfunktionen": features,
              "SUSFS_Prioritaetsfilter_Aufruf": hex(priority_calls[0]),
              "fsnotify_CFITable_und_Freigabe_pass": True,
              "device_pass": False}
    (evidence / "R13-SUSFS24-LLDB.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{len(spans)} linked functions, {len(decoded)} LLDB words matched Image")
    print(f"SUSFS 10/10: {len(features)} feature entries confirmed in the linked status getter")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("out", type=Path)
    p.add_argument("evidence", type=Path)
    p.add_argument("--lldb", default="lldb-19")
    inspect(**vars(p.parse_args()))
