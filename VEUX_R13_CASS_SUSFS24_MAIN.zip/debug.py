"""Inspect linked ARM64 startup and filesystem code with LLDB."""
import argparse
import bisect
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess

WORD = re.compile(r"\[(0x[0-9a-fA-F]+)\].*?:\s+(0x[0-9a-fA-F]{8})\s")
FUNCTIONS = (
    "start_kernel", "sched_init", "kernel_init_freeable", "do_execveat_common",
    "susfs_init", "susfs_show_version", "susfs_start_sdcard_monitor_fn",
    "susfs_sdcard_monitor_fn", "susfs_handle_sdcard_inode_event",
    "susfs_sdcard_cleanup_fn", "susfs_free_sdcard_mark",
    "susfs_open_redirect_spoof_vfs_statfs", "susfs_open_redirect_spoof_seq_show",
    "susfs_is_inode_sus_path", "vfs_statfs", "nomount_init",
    "goodix_ts_core_init", "dsi_display_set_backlight", "wakeup_reason_init",
)

def symbols(path):
    result = []
    for line in path.read_text().splitlines():
        address, kind, name = line.split(maxsplit=2)
        result.append((int(address, 16), kind, name))
    return result

def inspect(out, evidence, lldb):
    evidence.mkdir(parents=True, exist_ok=True)
    sym = symbols(out / "System.map")
    base, = {addr for addr, _, name in sym if name == "_text"}
    text = [(addr, name) for addr, typ, name in sym if typ in "tTwW"]
    addresses = sorted({addr for addr, _ in text})
    spans = {}
    for fn in FUNCTIONS:
        label = re.compile(re.escape(fn) + r"(?:\$[0-9a-f]{32}|\.llvm\.[0-9]+)?$")
        candidates = [(addr, symname) for addr, symname in text if label.fullmatch(symname)]
        if not candidates:
            continue
        addr, symname = min(candidates)
        nxt = bisect.bisect_right(addresses, addr)
        if nxt == len(addresses):
            continue
        size = min(addresses[nxt] - addr, 4096)
        if size <= 0 or size % 4:
            raise ValueError(fn)
        spans[fn] = {"address": addr, "name": symname, "words": size // 4}
    for name in ("start_kernel", "sched_init", "susfs_sdcard_monitor_fn", "susfs_free_sdcard_mark"):
        if name not in spans:
            raise ValueError(f"Required linked path is missing: {name}")
    args = evidence / "R13-SUSFS24.lldb"
    args.write_text("".join(f"disassemble --bytes --start-address {row['address']:#x} --count {row['words']}\n"
                            for row in spans.values()))
    cmd = [lldb, "--batch", "-f", str((out / "vmlinux").resolve()), "-s", args]
    report = evidence / "R13-SUSFS24-LLDB.txt"
    with report.open("w") as f:
        subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, text=True, check=True)
    decoded = {int(pc, 16): int(bits, 16) for pc, bits in WORD.findall(report.read_text())}
    image = (out / "arch/arm64/boot/Image").read_bytes()
    for fn, row in spans.items():
        for pc in range(row["address"], row["address"] + 4 * row["words"], 4):
            if not 0 <= pc - base <= len(image) - 4:
                raise ValueError(f"{fn} points outside Image")
            bits, = struct.unpack_from("<I", image, pc - base)
            if decoded.get(pc) != bits:
                raise ValueError(f"{fn} LLDB did not confirm {pc:#x} = {bits:#x}")
    def exact(name):
        address, = {addr for addr, _, label in sym if label == name}
        return address

    def branch(pc, bits):
        if bits >> 26 not in (5, 37):
            return None
        displacement = (bits & 0x3FFFFFF) ^ 0x2000000
        return pc + 4 * (displacement - 0x2000000)

    table = exact("fsnotify_ops")
    free = spans["susfs_free_sdcard_mark"]
    watcher = spans["susfs_handle_sdcard_inode_event"]
    free_entry = exact(free["name"] + ".cfi_jt")
    event_entry = exact(watcher["name"] + ".cfi_jt")
    handler, = struct.unpack_from("<Q", image, table - base)
    destructor, = struct.unpack_from("<Q", image, table - base + 32)
    jump, = struct.unpack_from("<I", image, free_entry - base)
    free_words = range(free["address"], free["address"] + 4 * free["words"], 4)
    kfree = exact("kfree")
    if (handler != event_entry or destructor != free_entry
            or branch(free_entry, jump) != free["address"]
            or not any(branch(pc, decoded[pc]) == kfree for pc in free_words)):
        raise ValueError("Incorrect fsnotify callback or destructor in candidate")
    result = {"Kern_SHA256": hashlib.sha256(image).hexdigest(),
              "Funktionen": spans, "mit_Image_abgeglichene_Woerter": len(decoded),
              "fsnotify_CFITable_und_Freigabe_pass": True,
              "device_pass": False}
    (evidence / "R13-SUSFS24-LLDB.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{len(spans)} linked functions, {len(decoded)} LLDB words matched Image")

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("out", type=Path)
    p.add_argument("evidence", type=Path)
    p.add_argument("--lldb", default="lldb-19")
    inspect(**vars(p.parse_args()))
