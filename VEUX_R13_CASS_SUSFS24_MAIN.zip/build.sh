#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
work=$(realpath -m "$1")
clang_path=$(realpath "$2")
jobs=${KBUILD_JOBS:-4}
src="$work/source"
out="$work/out"
evidence="$work/evidence"
mkdir -p "$work" "$evidence"
test ! -e "$src"
test ! -e "$out"

vendor=b2b7a3bbc36d120ee523ebc8d68e0f13a97df632
git init -q "$src"
git -C "$src" remote add origin https://github.com/dereference23/kernel_xiaomi_sm6375.git
git -C "$src" fetch -q --depth=1 --no-tags origin "$vendor"
git -C "$src" checkout -q --detach "$vendor"
test "$(git -C "$src" write-tree)" = 1783b5008fc971b795ccaa374efe97aa996eef49
for patch in "$kit/patches/P14/p5i/vendor-20240619-to-p5i-outer.patch" \
             "$kit/patches/P14/p5i-to-p6-source-compat.patch" \
             "$kit/patches/P14/p6v10-to-p6v11-full-susfs-outer.patch"; do
    git -C "$src" apply --index --binary --whitespace=nowarn "$patch"
done
test "$(git -C "$src" write-tree)" = 19b68131d7a3955085f60c4fb8cf64442427af0c
git -C "$src" apply --index --binary --whitespace=nowarn "$kit/patches/R13-Quellstand.patch"
test "$(git -C "$src" write-tree)" = f6333fd7ea31238fe38553498f806f48a8c0fdda
git -C "$src" apply --index --binary --whitespace=nowarn "$kit/patches/SUSFS-2.4-R13.patch"
test "$(git -C "$src" write-tree)" = "$(cat "$kit/referenz/Kandidat.git-tree")"

ksu="$src/KernelSU"
git init -q "$ksu"
git -C "$ksu" remote add origin https://github.com/Baka-SU/BakaSU.git
git -C "$ksu" fetch -q --no-tags origin d5e9e025b8b49155f8014684d64c91742b465f65 \
    refs/tags/v4.2.0-rc3:refs/tags/v4.2.0-rc3
git -C "$ksu" fetch -q "$kit/referenz/BAKASU_CASS_R4.bundle" 2cbbcc2363aa8d4b6286fc2266a338063b2b77a7
git -C "$ksu" fetch -q "$kit/referenz/BAKASU_R13.bundle" d2537b13ab15fce72e8c0d99e7788805f071aeb4
git -C "$ksu" checkout -q --detach d2537b13ab15fce72e8c0d99e7788805f071aeb4
test "$(git -C "$ksu" rev-parse HEAD^{tree})" = a0fb073cc22c7cba0fce0fff5dfb33e99669cb36
test "$(git -C "$ksu" rev-list --count HEAD)" = 4554
test "$(git -C "$ksu" describe --abbrev=0 --tags)" = v4.2.0-rc3
test "$(readlink -f "$src/drivers/kernelsu")" = "$ksu/kernel"
test -z "$(git -C "$ksu" status --porcelain)"

python3 "$kit/tools/treehash.py" "$clang_path"
export PATH="$clang_path/bin:$PATH" PYTHONDONTWRITEBYTECODE=1
export KBUILD_BUILD_USER=builder KBUILD_BUILD_HOST=pangu-build-component-vendor-345942-54r9t-tw0tk-tq90c
export KBUILD_BUILD_TIMESTAMP='Thu Dec 5 14:47:59 UTC 2024' SOURCE_DATE_EPOCH=1733410079
export KBUILD_BUILD_VERSION=2 KBUILD_FIXED_SCM_SUFFIX=-g82179e362f33
mkdir "$out"
cp "$kit/referenz/R13.config" "$out/.config"
compile=(make -C "$src" O="$out" ARCH=arm64 CC=clang LD=ld.lld LLVM=1 LLVM_IAS=1
         "KCFLAGS=-D__ANDROID_COMMON_KERNEL__ -I$out/security/selinux")
"${compile[@]}" olddefconfig
python3 "$kit/verify.py" config "$out" "$kit/referenz"
python3 "$kit/tools/watcher.py" "$src" "$evidence"
"${compile[@]}" -j"$jobs" init/version.o security/selinux/
"${compile[@]}" -j"$jobs" Image dtbs modules
python3 "$kit/verify.py" image "$out" "$kit/referenz" "$evidence" --objcopy "$clang_path/bin/llvm-objcopy"
python3 "$kit/debug.py" "$out" "$evidence" --lldb "${LLDB:-lldb-19}"
cp "$out/.config" "$evidence/kernel.config"
cp "$out/System.map" "$out/Module.symvers" "$evidence/"
cp "$kit/referenz/R13_Boot_Daten.json" "$evidence/"
