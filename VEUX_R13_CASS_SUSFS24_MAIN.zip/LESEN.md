# VEUX R13-CASS · SUSFS 2.4 · GitHub Actions

Lege VEUX_R13_CASS_SUSFS24_MAIN.zip direkt ins Repository-Hauptverzeichnis.
Lege VEUX_R13_CASS_SUSFS24_NOFLASH.yml unter .github/workflows/ ab.
Der Workflow heißt **VEUX R13 CASS · SUSFS 2.4 · NOFLASH** und startet über **Run workflow**.

Die Prüfsumme in der YAML bindet das vollständige MAIN-Paket. Der Build rekonstruiert zuerst die historische R13-CASS-Basis, prüft ihre Git-Bäume und kompiliert dann die SUSFS-2.4-Variante. Die Protokolle, ARM64-Kerneldatei, der Gerätebaum und das Debug-ELF stehen nach erfolgreichem Lauf zur statischen Prüfung bereit.

Die geprüfte Konfiguration und das Layout stammen direkt aus deiner laufenden R13-Referenz. Der [Prüfbericht](PRUEFBERICHT.md) enthält die Gegenprobe mit der R13-Sicherung und dem originalen Xiaomi-Kernel. Gerätepass und Flash-Freigabe stehen für den neuen Build aus.
