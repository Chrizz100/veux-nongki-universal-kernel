# VEUX M63-R2 für HyperOS OS1.0.12.0.TKCMIXM

M62 geriet auf dem POCO X4 Pro 5G in eine Bootschleife. Der Rückflash auf die funktionierende Sicherung war erfolgreich. Die erhaltene Konsole trägt die Startkennung der Sicherung. Android meldete für SYSTEM_LAST_KMSG keine Einträge. Die genaue Absturzstelle auf dem Gerät bleibt offen.

M63-R2 enthält die fünf Scheduler-Initialisierungen aus M63. Wiederholte Starts von M63 zeigten zusätzlich einen negativen Lastzähler in update_history. Der Kandidat stellt die Buchung beim Einreihen und Herausnehmen von Tasks für Fair-, Echtzeit-, Deadline- und Stop-Tasks wieder her. Er setzt die zugehörigen Initialisierungen bei Prozessstart und CPU-Start, die Aktualisierungen beim Aufwachen, bei Migration und Kontextwechsel sowie die Freigabe bei Prozessende und abgebrochenem Fork wieder ein. Die Prüfung auf negative Lastwerte bleibt aktiv.

Die Änderung an der Fehlerprotokollierung stellt in fs/pstore/platform.c und fs/pstore/ram.c die Xiaomi-Namen für dmesg und console wieder her. Der mitgebaute VEUX-Gerätebaum verwendet dieselbe Aufteilung des persistenten Speichers wie der zum VEUX passende Xiaomi-Gerätebaum. Die Firmware weist dem Konsolenprotokoll und pmsg je 1 MiB zu. Der Bootcontainer und das AK3 enthalten den Kernel und verwenden Xiaomis originales Bootlayout. Der mitgebaute Gerätebaum wird als Nachweis gesichert.

## Auf GitHub bauen

1. VEUX_M63_R2_MAIN.zip ins Hauptverzeichnis des Repositories legen.
2. VEUX_M63_R2_STOCK_PSTORE_NOFLASH.yml unter .github/workflows/ ablegen.
3. In Actions den Workflow VEUX M63-R2 starten. Er verwendet den über SHA-256 geprüften M62-Quellstand, die M62-Negativkontrolle und den bestehenden Cache für Compiler und Stock-Eingaben.

## Was der Lauf prüft

Der Bau vergleicht den final verlinkten Scheduler mit Xiaomis ausgeliefertem Kernel. Er prüft die Hersteller-Module, die Speicheranzeigen und die Millet-Funktionen. Er vergleicht beide Namenstabellen des Protokolltreibers und den kompilierten ramoops-Knoten mit Xiaomis signierten Daten aus vendor_boot und dtbo. Die Teilbereiche der beiden Firmwarepartitionen werden mit den Hash-Deskriptoren aus dem zugehörigen Xiaomi-vbmeta abgeglichen.

Für den Neustarttest erhält eine ARM64-Prüfmaschine dieselben Puffergrößen. Zwei parallele Prozesse erzeugen in der Prüfmaschine reguläre Kindprozesse und je einen FIFO-Echtzeitprozess. Anschließend schreibt der erste Prozess eine Kennung in die Kernelkonsole und startet die Prüfmaschine neu. Der zweite Start muss die Kennung aus console-ramoops-0 lesen. Der alte M62 dient als Kontrolle für den frühen Scheduler-Absturz. Die Test-Ramdisk dient ausschließlich der Prüfmaschine.

Die Artefakte BOOT-AK3-NOFLASH und NACHWEISE gehören zum selben Build. Der vollständige HyperOS-Start auf einem realen POCO steht aus. Es besteht keine Flash-Freigabe.
