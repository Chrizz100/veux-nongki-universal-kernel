"""Verify the previous boot's console file by rebooting the same ARM64 VM."""
import os
from pathlib import Path
import re
import selectors
import shutil
import struct
import subprocess
import tempfile
import time
import zipfile

from fruehstart import COMMAND_LINE, MACHINE, digest, require

HERE = Path(__file__).resolve().parent
RAMOOPS = """
/ {
    reserved-memory {
        #address-cells = <2>;
        #size-cells = <2>;
        ranges;
        ramoops@70000000 {
            compatible = "ramoops";
            reg = <0 0x70000000 0 %#x>;
            console-size = <%#x>;
            pmsg-size = <%#x>;
        };
    };
};
"""


def run(image, out, log_path, expected_name, geometry):
    qemu = shutil.which('qemu-system-aarch64')
    require(qemu, 'qemu-system-aarch64 missing')
    dtc = out / 'scripts/dtc/dtc'
    base = [qemu, '-no-user-config', '-nodefaults', '-cpu', 'cortex-a76',
            '-accel', 'tcg', '-smp', '2', '-m', '1024M', '-display', 'none',
            '-monitor', 'none', '-nic', 'none', '-seed', '1']
    with tempfile.TemporaryDirectory() as directory:
        temp = Path(directory)
        dtb = temp / 'virt.dtb'
        subprocess.run(base + ['-machine', f'{MACHINE},dumpdtb={dtb}'], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        dts = subprocess.check_output([dtc, '-qqq', '-I', 'dtb', '-O', 'dts', dtb])
        _, size = struct.unpack('>QQ', bytes.fromhex(geometry['reg']))
        require(set(geometry) == {'reg', 'compatible', 'console-size', 'pmsg-size'},
                'Unexpected layout in the VEUX pstore test')
        region = RAMOOPS % (size, int(geometry['console-size'], 16), int(geometry['pmsg-size'], 16))
        subprocess.run([dtc, '-qqq', '-I', 'dts', '-O', 'dtb', '-o', dtb],
                       input=dts + region.encode(), check=True)
        with zipfile.ZipFile(HERE.parent / 'ak3-tools.zip') as archive:
            (temp / 'busybox').write_bytes(archive.read('tools/busybox'))
        manifest = temp / 'initramfs.list'
        manifest.write_text(
            'dir /dev 0755 0 0\nnod /dev/console 0600 0 0 c 5 1\nnod /dev/null 0666 0 0 c 1 3\n'
            'nod /dev/kmsg 0600 0 0 c 1 11\ndir /store 0755 0 0\ndir /proc 0755 0 0\n'
            f'file /init {HERE / "pstore-init.sh"} 0755 0 0\n'
            f'file /busybox {temp / "busybox"} 0755 0 0\n')
        initrd = temp / 'initramfs.cpio'
        with initrd.open('wb') as stream:
            subprocess.run([out / 'usr/gen_init_cpio', '-t', '0', manifest], stdout=stream, check=True)
        command = base + ['-machine', MACHINE, '-serial', 'stdio', '-kernel', str(image),
                          '-initrd', str(initrd), '-dtb', str(dtb), '-append', COMMAND_LINE]
        data = bytearray()
        with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT) as proc:
            try:
                with selectors.DefaultSelector() as ready:
                    ready.register(proc.stdout, selectors.EVENT_READ)
                    deadline = time.monotonic() + 75
                    while time.monotonic() < deadline:
                        if not ready.select(timeout=0.5):
                            continue
                        chunk = os.read(proc.stdout.fileno(), 32768)
                        if not chunk:
                            break
                        data.extend(chunk)
                        if (re.search(rb'(?m)^VEUX_PSTORE_READ [\w-]+\r?\n', data)
                                or b'VEUX_PSTORE_FAIL ' in data or re.search(rb'Kernel panic - not syncing:[^\r\n]+\r?\n', data)
                                or data.count(b'VEUX_PSTORE_WROTE') > 1 or len(data) > 2_000_000):
                            break
            finally:
                proc.kill()
                proc.wait()
                log_path.write_bytes(data)
        if expected_name is None:
            require(b'Kernel panic - not syncing: Fatal exception in interrupt' in data
                    and re.search(rb'pc\s*:\s*update_task_rq_cpu_cycles\+', data)
                    and b'walt_update_task_ravg+' in data and b'scheduler_tick+' in data
                    and b'Registered ramoops as persistent store backend' not in data
                    and b'Run /init as init process' not in data, 'Missing early M62 negative control')
            return dict(walt_panic_before_ramoops=True, serial_sha256=digest(data), serial_log=log_path.name)
        read = re.findall(rb'(?m)^VEUX_PSTORE_READ ([\w-]+)\r?$', data)
        boots = len(re.findall(rb'Linux version 5\.4\.274', data))
        wrote = list(re.finditer(rb'(?m)^VEUX_PSTORE_WROTE\r?$', data))
        restarts = list(re.finditer(rb'(?im)sysrq:\s*Resetting\r?$', data))
        read_pos = data.find(b'VEUX_PSTORE_READ ')
        require(boots == 2 and len(wrote) == 1 and len(restarts) == 1 and
                len(re.findall(rb'(?m)^VEUX_WALT_QUEUE_OK\r?$', data)) == 1 and
                wrote[0].start() < restarts[0].start() < read_pos and
                read == [expected_name.encode()] and b'Kernel panic - not syncing' not in data,
                f'Previous-boot marker check failed in {log_path}')
        return dict(boots=boots, previous_boot_marker_read=True, fair_and_fifo_workload=True,
                    filename=read[0].decode(),
                    serial_sha256=digest(data), serial_log=log_path.name)
