"""Compare the VEUX pstore binding and kernel record types with the shipped firmware."""
import ctypes
import gzip
import json
from pathlib import Path
import struct
import sys
import tempfile

from fruehstart import digest, require, M62_BOOT, M62_IMAGE, STOCK_BOOT, STOCK_IMAGE, unpack_boot
from pstore_restart import run

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tools'))
from layout.boot import align, unpack_m45
from memory_image import mapped_symbols, stock_symbols
from mi_memory_image import Linked
from thermal_dtb import enabled, nodes

VEUX = b'Qualcomm Technologies, Inc. VEUX QRD NOPMI\0'


def signed_regions(temp):
    factory = unpack_m45(temp)
    vbmeta = (factory.ROOT / 'stock-vbmeta.bin').read_bytes()
    header = factory.avb.AvbVBMetaHeader(vbmeta[:256])
    start = 256 + header.authentication_data_block_size + header.descriptors_offset
    descriptors = factory.avb.parse_descriptors(vbmeta[start:start + header.descriptors_size])
    regions = {}
    for name in ('dtbo', 'vendor_boot'):
        desc, = [d for d in descriptors if isinstance(d, factory.avb.AvbHashDescriptor)
                 and d.partition_name == name]
        raw = gzip.decompress((HERE / 'oem' / (name + '.verified.gz')).read_bytes())
        require(desc.hash_algorithm == 'sha256' and len(raw) == desc.image_size
                and digest(desc.salt + raw) == desc.digest.hex(), 'Factory AVB digest for ' + name)
        regions[name] = raw
    return regions


def device_tree(regions):
    overlays = regions['dtbo']
    magic, size, _, entry_bytes, entries, table = struct.unpack_from('>6I', overlays)
    require(magic == 0xd7b7ab1e and size == len(overlays) and entry_bytes == 32, 'Android DTBO header')
    selected = []
    for i in range(entries):
        size, start = struct.unpack_from('>2I', overlays, table + i * entry_bytes)
        raw = overlays[start:start + size]
        root = nodes(raw)['/']
        if root.get('model') == VEUX:
            selected.append((raw, root['qcom,msm-id']))
    (overlay, soc), = selected
    vendor = regions['vendor_boot']
    require(vendor[:8] == b'VNDRBOOT' and struct.unpack_from('<2I', vendor, 8) == (3, 4096),
            'Xiaomi vendor_boot v3, 4096-byte pages')
    rd_size, = struct.unpack_from('<I', vendor, 24)
    header_size, dt_size = struct.unpack_from('<2I', vendor, 2096)
    start = align(header_size) + align(rd_size)
    end = start + dt_size
    require(end <= len(vendor), 'vendor_boot DTB range')
    bases = []
    while start < end:
        size, = struct.unpack_from('>I', vendor, start + 4)
        require(40 <= size <= end - start, 'Base DTB length')
        raw = vendor[start:start + size]
        if nodes(raw)['/'].get('qcom,msm-id') == soc:
            bases.append(raw)
        start += size
    base, = bases
    fdt = ctypes.CDLL('libfdt.so.1')
    merged = ctypes.create_string_buffer(len(base) + len(overlay) + 131072)
    require(fdt.fdt_open_into(base, merged, len(merged)) == 0 and
            fdt.fdt_overlay_apply(merged, ctypes.create_string_buffer(overlay)) == 0 and
            fdt.fdt_pack(merged) == 0, 'Apply the VEUX overlay to the matching Xiaomi base')
    size, = struct.unpack_from('>I', merged.raw, 4)
    return merged.raw[:size]


def geometry(dtb):
    tree = nodes(dtb)
    path, = [p for p, props in tree.items() if p.startswith('/reserved-memory/') and
             props.get('compatible') == b'ramoops\0' and enabled(tree, p)]
    return {k: v.hex() for k, v in tree[path].items() if k not in ('phandle', 'linux,phandle')}


def labels(image, symbols, factory, tools, temp):
    linked = Linked(image, symbols, factory, tools, temp)
    table = linked.names['pstore_type_names']
    names = [linked.string(linked.ptr(table + 8 * i)) for i in range(9)]
    targets = {linked.names[name] for name in ('ramoops_init_prz', 'ramoops_init_przs')}
    setup = linked.access('ramoops_probe')
    zones = []
    for index, (_, op, argument) in enumerate(setup):
        if op == 'bl' and argument.startswith('0x') and int(argument, 16) in targets:
            zones.append(linked.string(linked.register_address(setup[:index], 'x0')))
    return {'pstore_type_names': names, 'ramoops_zone_names': zones}


def main(work, dest):
    out = work / 'out'
    candidate_path = out / 'arch/arm64/boot/Image'
    stock = unpack_boot(work / 'boot.img', STOCK_BOOT, STOCK_IMAGE)
    candidate = unpack_boot(work / 'pair/VEUX_M63-R2_boot_NOFLASH.img')
    require(candidate == candidate_path.read_bytes(), 'Final boot must contain the linked kernel')
    dest.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        temp = Path(tmp)
        signed = signed_regions(temp)
        factory_geometry = geometry(device_tree(signed))
        built_geometry = geometry((out / 'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb').read_bytes())
        require(factory_geometry == built_geometry, 'ramoops device-tree properties differ from Xiaomi')
        toolchain = work / 'clang/bin'
        original = labels(stock, stock_symbols(stock), True, toolchain, temp)
        built = labels(candidate, mapped_symbols(out / 'System.map'), False, toolchain, temp)
        require(original['pstore_type_names'][:3] == ['dmesg', 'mce', 'console'] and
                original['ramoops_zone_names'] == ['dmesg', 'console', 'ftrace', 'pmsg'] and
                built == original, 'Linked pstore or ramoops names differ from Xiaomi')
        stock_path = temp / 'Xiaomi.Image'
        stock_path.write_bytes(stock)
        m62 = temp / 'M62.Image'
        m62.write_bytes(unpack_boot(work / 'M62-Kontrolle.img', M62_BOOT, M62_IMAGE))
        boots = {}
        for name, image, expect in [('Xiaomi', stock_path, 'console-ramoops-0'),
                                    ('M62', m62, None), ('M63-R2', candidate_path, 'console-ramoops-0')]:
            boots[name] = run(image, out, dest / (name + '.log'), expect, factory_geometry)
    result = {'model': VEUX.rstrip(b'\0').decode(), 'signed_regions_sha256': {k: digest(v) for k,v in signed.items()},
              'oem_ramoops': factory_geometry, 'compiled_ramoops': built_geometry,
              'images': {'Xiaomi': digest(stock), 'M63-R2': digest(candidate)},
              'oem_labels': original, 'compiled_labels': built, 'arm64_restarts': boots,
              'device_pass': False, 'flash_allowed': False}
    (dest / 'pstore.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS VEUX ramoops DT, both label tables, previous-boot console on Xiaomi and M63-R2')


if __name__ == '__main__':
    main(*(Path(path).resolve() for path in sys.argv[1:]))
