# VEUX Stock 5.4.274-QGKI – verifizierte Referenz / Quellbaum-Rekonstruktion R1

**Ziel:** Die aus der von dir bereitgestellten `stock_boot.img` SHA-256-verifizierten Informationen reproduzierbar in einen GitHub-Quellbaum-Kandidaten integrieren. **Nicht:** behaupten, der originale Xiaomi-Quellcode ließe sich aus Maschinencode 1:1 zurückübersetzen.

## Verifizierte Referenzdaten aus der bereitgestellten `stock_boot.img`

- `reference/stock.config`: bytegenau aus `IKCFG_ST…IKCFG_ED` im Stock-Kernel (SHA-256 im Manifest).
- `reference/stock_kheaders.tar.xz`: exakt der im Image enthaltene komprimierte Headerblock (7.717 reguläre Dateien). Das sind Header, **nicht alle `.c`-Dateien**.
- `reference/R13_ACTUAL.config`: die nachweisbare frühere Custom-Build-Konfiguration als Vergleich.
- `reference/stock_provenance.json`: Original-BOOT-/Kernel-/Config-/Header-Prüfsummen, Quellstand-Grenzen und gepinnter Donor.
- Die Herstellerherkunft der als Stock bereitgestellten `boot.img` ist durch SHA-256 allein **nicht kryptografisch gegenüber Xiaomi bestätigt**. Das vollständige originale **5.4.274**-`Module.symvers` fehlt. Kein Kernel-`vmlinux` mit vollständigen Debug-Informationen und keine vollständigen OEM-Quellen sind vorhanden.

## Gepinnter öffentlicher Ausgangs-Quellbaum

`https://github.com/dereference23/kernel_xiaomi_sm6375`, Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`, ursprüngliches Makefile **5.4.268**. Es handelt sich um einen nachvollziehbaren **Quellbaum-Kandidaten**, der bereits in der R13-Linie genutzt wurde – nicht um Xiaomis unbekannten 5.4.274-Quellstand. Xiaomi `veux-r-oss` ist nur eine ältere 5.4.134-Quelle.

## GitHub-Nutzung – genau MAIN-ZIP + YAML

1. `VEUX_STOCK_54274_SOURCE_RECON_R1_MAIN.zip` in das **Hauptverzeichnis** der Repo `Chrizz100/veux-nongki-universal-kernel` hochladen.
2. `VEUX_STOCK_54274_SOURCE_RECON_R1_NOFLASH.yml` nach `.github/workflows/` hochladen.
3. Den Workflow unter **Actions → VEUX STOCK 5.4.274 source candidate R1 (NOFLASH) → Run workflow** starten.
4. Das Ergebnisartefakt enthält den **vollständigen Vergleich aller 7.717 eingebetteten Headerdateien** sowie den Quellstand-Abgleich als JSON/CSV und die Konfigurationsanpassung aus `olddefconfig`, **keinen Kernel, keine AK3 und keine Bootdatei**.

Der Workflow prüft zuerst die SHA-256 des MAIN-Archivs und alle enthaltenen Dateihashes, extrahiert nur vorgegebene sichere Pfade in einen temporären Ordner, testet den Stock-Referenzstand, holt den gepinnten Donor-Commit und überprüft seine Originaldateien. `olddefconfig` wird nur in einem **separaten Build-Verzeichnis** erstellt. Weder Stock-Header noch generierte Header werden in den Quellcode hineinkopiert; das wäre ein gefährlicher Schein-Fix.

## Bekannter ABI-Blocker (nicht umgangen)

Historischer R13-Vergleich: **14.648 externe Importe** aus zwei Vendor-Kohorten, **6.286** passend, **7.827** abweichende CRC und **535** fehlend; zusätzlich 836 Symbol-CRC-Konflikte GKI/QGKI. Im originalen `stock_vendor_boot.img` sind zudem 66 frühe GKI-Module enthalten, deren Boot-Pfad noch geprüft werden muss. Diese alten Daten beweisen nicht, welche Module auf dem aktuell laufenden Gerät tatsächlich verwendet werden. Einzelne GKI-/QGKI-Profile nicht zusammenwerfen.

**Wichtig:** Ein grüner *Quellen-Diagnose-Workflow* beweist ausschließlich Authentizität/Lesbarkeit der Eingaben und reproduzierbaren Quellabruf – **nicht** Kernel-Build, OEM-Kompatibilität oder Flashfähigkeit. Für eine echte funktionale Rekonstruktion sind mindestens ein pinbarer 5.4.274-Patchstand, ein vollständiger Build mit Stock-Konfiguration und Compiler, konkrete Module.symvers-Vergleiche mit der tatsächlich verwendeten Vendor-Kohorte sowie DTB/DTBO/Boot-/Geräteprüfungen erforderlich.

**Keine Umstellung von CASS/WALT, keine Fake-CRC, keine Symbolmanipulation, kein Flash.**

*Hinweis:* Der MAIN-ZIP enthält originale aus dem Stock-Image extrahierte Kernel-Header. Prüfe vor dem öffentlichen Hochladen, ob du diese Dateien auf deiner öffentlichen GitHub-Repo veröffentlichen möchtest und darfst; alternativ die Untersuchung privat fortführen. Die ZIP enthält keine vollständige `boot.img`, keine OEM-`.ko`-Binärdateien und keine privaten Geräteprotokolle.
