#!/usr/bin/env python3
"""Local/offline tests of the stock reference and deliberately strict release gates."""
import json
import pathlib
import tempfile
import unittest
from verify_reference import config_options, verify
from compare_candidate import DONOR_MAKEFILE_GIT_BLOB, STOCK_HEADER_COUNT

MAIN=pathlib.Path(__file__).resolve().parents[1]
class ReadOnlyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.meta=json.loads((MAIN/'reference/stock_provenance.json').read_text())
        cls.options=config_options((MAIN/'reference/stock.config').read_bytes())
    def test_01_authenticates_manifest(self):
        self.assertTrue(verify(MAIN)['stock_reference_validated'])
    def test_02_stock_version(self):
        self.assertEqual(self.meta['release'],'5.4.274-qgki-g82179e362f33')
    def test_03_no_false_source_claim(self):
        self.assertFalse(self.meta['source_tree_original_complete'])
    def test_04_no_flash(self):
        self.assertFalse(self.meta['flash_allowed'])
    def test_05_known_kernel_image_sha(self):
        self.assertEqual(self.meta['kernel_sha256'],'6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b')
    def test_06_stock_qgki(self):
        self.assertEqual(self.options['CONFIG_QGKI'],'y')
    def test_07_stock_walt_not_cass(self):
        self.assertEqual(self.options['CONFIG_SCHED_WALT'],'y')
    def test_08_stock_nr_cpus_32(self):
        self.assertEqual(self.options['CONFIG_NR_CPUS'],'32')
    def test_09_stock_modversions(self):
        self.assertEqual(self.options['CONFIG_MODVERSIONS'],'y')
    def test_10_donor_pin(self):
        self.assertEqual(self.meta['donor_commit'],'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632')
    def test_11_expected_header_count(self):
        self.assertEqual(STOCK_HEADER_COUNT,7717)
    def test_12_no_oem_symvers_claim(self):
        self.assertFalse(self.meta['complete_stock_Module_symvers'])
    def test_13_ikconfig(self):
        self.assertEqual(self.options['CONFIG_IKCONFIG'],'y')
    def test_14_ikheaders(self):
        self.assertEqual(self.options['CONFIG_IKHEADERS'],'y')
    def test_15_ipc_logging(self):
        self.assertEqual(self.options['CONFIG_IPC_LOGGING'],'y')
    def test_16_stock_tracing(self):
        self.assertEqual(self.options['CONFIG_TRACING'],'y')
    def test_17_header_archive_sha(self):
        self.assertEqual(self.meta['kheaders_tar_xz_sha256'],'39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279')
    def test_18_stock_config_sha(self):
        self.assertEqual(self.meta['stock_config_sha256'],'334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868')
    def test_19_makefile_pin(self):
        self.assertEqual(DONOR_MAKEFILE_GIT_BLOB,'ac80e0c2a17d82b66d1588941b5760b2e1661609')
    def test_20_config_parser_no_value(self):
        self.assertEqual(config_options(b'# CONFIG_XYZ is not set\n'),{'CONFIG_XYZ':'n'})
    def test_21_immutability_no_overrides(self):
        self.assertFalse(self.meta.get('flash_allowed'))
        self.assertFalse(self.meta.get('complete_stock_Module_symvers'))
if __name__=='__main__':unittest.main()
