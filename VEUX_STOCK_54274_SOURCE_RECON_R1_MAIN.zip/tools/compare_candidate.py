#!/usr/bin/env python3
"""Compare exact-pinned PUBLIC donor source with all stock-embedded headers and configs.

The verified donor is not assumed to be the unknown OEM 5.4.274 source.
No symbol CRCs are adjusted, no compiled outputs and no flash artifacts are made.
"""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
from verify_reference import config_options, verify

DONOR_MAKEFILE_GIT_BLOB = 'ac80e0c2a17d82b66d1588941b5760b2e1661609'
STOCK_HEADER_COUNT = 7717

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def git(src, *args):
    return subprocess.check_output(['git', '-C', str(src), *args], text=True, stderr=subprocess.STDOUT).strip()

def write_csv(path, columns, rows):
    with path.open('w', newline='', encoding='utf-8') as fh:
        wr=csv.DictWriter(fh, fieldnames=columns)
        wr.writeheader()
        wr.writerows(rows)

def compare(main, source, out, resolved_config=None):
    main, src, out = Path(main).resolve(), Path(source).resolve(), Path(out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    verify(main)
    ref=json.loads((main/'reference/stock_provenance.json').read_text('utf-8'))

    # Git SHA verifies the *donor checkout*, not a byte-identical OEM source.
    commit=git(src, 'rev-parse', '--verify', 'HEAD')
    if commit != ref['donor_commit']:
        raise ValueError('DONOR_GIT_PIN_DRIFT: '+commit)
    if git(src, 'status', '--porcelain'):
        raise ValueError('DONOR_SOURCE_TREE_DIRTY')
    blob=git(src, 'hash-object', 'Makefile')
    if blob != DONOR_MAKEFILE_GIT_BLOB:
        raise ValueError('DONOR_MAKEFILE_GIT_BLOB_DRIFT: '+blob)
    mf=(src/'Makefile').read_text('utf-8')
    def ver(v):
        x=re.search(r'^'+v+r'\s*=\s*(\d+)\s*$',mf,re.M)
        if not x: raise ValueError('DONOR_MAKEFILE_MISSING:'+v)
        return x.group(1)
    donor_version='.'.join(map(ver, ['VERSION','PATCHLEVEL','SUBLEVEL']))
    if donor_version!='5.4.268':
        raise ValueError('DONOR_VERSION_UNEXPECTED:'+donor_version)

    stock=config_options((main/'reference/stock.config').read_bytes())
    r13=config_options((main/'reference/R13_ACTUAL.config').read_bytes())
    diffs=[{'option':k,'stock':stock.get(k,'(not present)'), 'r13':r13.get(k,'(not present)')}
           for k in sorted(set(stock)|set(r13)) if stock.get(k)!=r13.get(k)]
    if len(diffs)!=934:
        raise ValueError('STOCK_TO_R13_CONFIG_DIFF_COUNT_DRIFT:'+str(len(diffs)))
    write_csv(out/'R13_vs_Stock_config_differences.csv', ('option','stock','r13'), diffs)

    # Check every ORIGINAL embedded regular header. Generated headers are
    # expected to differ/be absent in a clean donor checkout.
    headers=[]
    with tarfile.open(main/'reference/stock_kheaders.tar.xz',mode='r:xz') as tf:
        seen=set()
        for member in tf:
            if not member.isfile(): continue
            name=member.name.removeprefix('./')
            rel=PurePosixPath(name)
            if rel.is_absolute() or '..' in rel.parts or str(rel)!=name or name in seen:
                raise ValueError('INVALID_STOCK_HEADER_PATH:'+name)
            seen.add(name)
            # No extraction or symlink traversal outside source root.
            donor=src.joinpath(*rel.parts)
            donor_real=donor.resolve()
            in_tree=donor_real == src or src in donor_real.parents
            original=tf.extractfile(member).read()
            actual=donor.read_bytes() if in_tree and donor.is_file() else None
            eq=actual is not None and original==actual
            headers.append({'path':name, 'stock_sha256':sha(original),
                           'donor_sha256':sha(actual) if actual is not None else '',
                           'status':'identical' if eq else ('different' if actual is not None else 'missing'),
                           'stock_size':member.size,'donor_size':len(actual) if actual is not None else ''})
    if len(headers)!=STOCK_HEADER_COUNT:raise ValueError('STOCK_HEADER_COUNT_DRIFT')
    write_csv(out/'ALL_7717_Stock_vs_Donor_headers.csv',
              ('path','stock_sha256','donor_sha256','status','stock_size','donor_size'),headers)
    counts={x:sum(r['status']==x for r in headers) for x in ('identical','different','missing')}

    cfg={'olddefconfig_attempted':False}
    if resolved_config:
        target=Path(resolved_config)
        if not target.is_file():raise ValueError('RESOLVED_CONFIG_NOT_PRESENT:'+str(target))
        current=config_options(target.read_bytes())
        cfg_diffs=[{'option':k,'stock':stock.get(k,'(not present)'),
                    'donor_olddefconfig':current.get(k,'(not present)')}
                   for k in sorted(set(stock)|set(current)) if stock.get(k)!=current.get(k)]
        write_csv(out/'Stock_vs_Donor_olddefconfig.csv',
                  ('option','stock','donor_olddefconfig'),cfg_diffs)
        cfg={'olddefconfig_attempted':True,'olddefconfig_source_option_differences':len(cfg_diffs),
             'olddefconfig_exact_stock_config':len(cfg_diffs)==0}

    report={'stock_reference_verified':True,'reference_header_files':len(headers),
            'header_byte_equal_count':counts['identical'],
            'header_different_count':counts['different'],
            'header_missing_in_donor_count':counts['missing'],
            'donor_repo':ref['donor_repo'],'donor_commit':commit,'donor_makefile_version':donor_version,
            'stock_release':ref['release'],'r13_vs_stock_config_differences':len(diffs),
            'stock_source_original_recovered':False,
            'stock_built_kernel_reproduced_byte_identical':False,
            'complete_stock_Module_symvers':False,'oem_abi_verified':False,'flash_allowed':False,
            'verdict':'PINNED_DONOR_AND_STOCK_REFERENCE_ONLY_NOT_OEM_REPRODUCTION', **cfg}
    (out/'STOCK_SOURCE_REPRO_REPORT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    (out/'RELEASE_GATE.json').write_text(json.dumps({
       'STOCK_REFERENCE_VERIFIED':True, 'DONOR_CHECKOUT_PIN_VERIFIED':True,
       'STOCK_SOURCE_EXACT':False,'KERNEL_IMAGE_BUILD_GREEN':False,
       'OEM_ABI_GREEN':False,'DTBO_BOOT_AK3_DEVICE_PASS':False,
       'FLASH_ALLOWED':False},indent=2,sort_keys=True)+'\n')
    print(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True))
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--main',required=True)
    p.add_argument('--source',required=True)
    p.add_argument('--out',required=True)
    p.add_argument('--resolved-config')
    a=p.parse_args()
    compare(a.main,a.source,a.out,a.resolved_config)
