#!/usr/bin/env python3
"""Read-only, standard-library preflight of embedded Xiaomi stock evidence.
Does NOT authenticate the origin of the boot image and does NOT prove a stock source tree.
"""
import argparse
import hashlib
import io
import json
import pathlib
import tarfile

REQUIRED_FLAGS = {
    'CONFIG_QGKI': 'y',
    'CONFIG_SCHED_WALT': 'y',
    'CONFIG_NR_CPUS': '32',
    'CONFIG_IPC_LOGGING': 'y',
    'CONFIG_TRACING': 'y',
    'CONFIG_MODVERSIONS': 'y',
    'CONFIG_IKCONFIG': 'y',
    'CONFIG_IKHEADERS': 'y',
}

def digest(blob):
    return hashlib.sha256(blob).hexdigest()

def config_options(data):
    r={}
    for line in data.decode('utf-8').splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            key,value=line.split('=',1)
            r[key]=value
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            r[line[2:-11]]='n'
    return r

def verify(root):
    root = pathlib.Path(root).resolve()
    files = json.loads((root/'MANIFEST_SHA256.json').read_text('utf-8'))
    assert files['schema']=='VEUX_STOCK_54274_REFERENCE_MAIN_R1', 'wrong archive schema'
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    expected=set(files['files'])|{'MANIFEST_SHA256.json'}
    assert actual==expected, 'MAIN files unexpectedly added/deleted: '+str(actual^expected)
    for name,expected_sha in files['files'].items():
        assert pathlib.PurePosixPath(name).parts and '..' not in pathlib.PurePosixPath(name).parts, 'unsafe path'
        p=root/name
        assert p.is_file() and not p.is_symlink(), f'missing or symlink {name}'
        assert digest(p.read_bytes())==expected_sha, f'hash drift: {name}'
    ref=root/'reference'
    meta=json.loads((ref/'stock_provenance.json').read_text('utf-8'))
    assert meta['schema']=='VEUX_STOCK_54274_SOURCE_REFERENCE_R1'
    assert meta['source_tree_original_complete'] is False
    assert meta['complete_stock_Module_symvers'] is False
    assert meta['flash_allowed'] is False
    assert meta['donor_commit']=='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
    config=(ref/'stock.config').read_bytes()
    assert digest(config)==meta['stock_config_sha256'], 'stock config hash mismatch'
    assert len(config)==180621, 'stock embedded .config length mismatch'
    options=config_options(config)
    for key,value in REQUIRED_FLAGS.items():
        assert options.get(key)==value, f'non-stock config {key}: {options.get(key)}'
    headers=(ref/'stock_kheaders.tar.xz').read_bytes()
    assert digest(headers)==meta['kheaders_tar_xz_sha256'], 'headers hash mismatch'
    with tarfile.open(fileobj=io.BytesIO(headers),mode='r:xz') as tf:
        regular=sum(1 for m in tf.getmembers() if m.isfile())
        assert regular==7717, 'stock kheaders regular count differs'
        uts=tf.extractfile('./include/generated/utsrelease.h').read().decode().strip()
        assert uts=='#define UTS_RELEASE "5.4.274-qgki-g82179e362f33"', 'stock UTS release drift'
    assert meta['kernel_sha256']=='6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
    r13=(ref/'R13_ACTUAL.config').read_bytes()
    assert digest(r13)==meta['r13_actual_config_sha256'], 'R13 snapshot differs'
    return {'stock_reference_validated':True,'kheaders_files':regular,'stock_kernel_sha256':meta['kernel_sha256'],
            'provenance_scope':'embedded stock config + headers (NOT complete source)', 'source_tree_exact':False,
            'oem_abi_reproduced':False,'flash_allowed':False}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--main',default=str(pathlib.Path(__file__).resolve().parents[1]))
    p.add_argument('--out')
    a=p.parse_args()
    result=verify(a.main)
    if a.out:
        pathlib.Path(a.out).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
