#!/system/bin/sh
# VEUX R32 – Read-only, privacy-limited device snapshot.
# NEVER writes settings, loads modules, performs a network request, or flashes.
set -u
LC_ALL=C
export LC_ALL

printf 'VEUX_R32_DEVICE_READONLY_V1\n'
printf 'OUTPUT_SCOPE=PRIVATE_SEND_TO_ANALYSIS_NOT_GITHUB\n'
if [ "$(id -u 2>/dev/null)" != 0 ]; then
    printf 'STATUS=ROOT_READ_ACCESS_REQUIRED\nEND_VEUX_R32_DEVICE_READONLY_V1\n'
    exit 2
fi
printf 'UID=0\n'

readprop() {
    p="$1"
    if command -v getprop >/dev/null 2>&1; then
        getprop "$p" 2>/dev/null | tr -d '\r\n'
    else
        printf 'UNAVAILABLE'
    fi
}

file_sha() {
    f="$1"
    if [ -f "$f" ] && [ -r "$f" ] && command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$f" 2>/dev/null | awk '{ print $1 }'
    else
        printf 'UNAVAILABLE\n'
    fi
}

safe_field() {
    printf '%s' "$1" | tr -cd '[:alnum:]._-'
}

printf 'DEVICE=%s\n' "$(safe_field "$(readprop ro.product.device)")"
printf 'ROM=%s\n' "$(safe_field "$(readprop ro.build.version.incremental)")"
printf 'ANDROID=%s\n' "$(safe_field "$(readprop ro.build.version.release)")"
printf 'RELEASE=%s\n' "$(safe_field "$(uname -r 2>/dev/null)")"
if [ -r /sys/kernel/notes ]; then
    printf 'KERNEL_NOTES_SHA256=%s\n' "$(file_sha /sys/kernel/notes)"
else
    printf 'KERNEL_NOTES_SHA256=UNAVAILABLE\n'
fi
if [ -r /proc/sys/kernel/random/boot_id ]; then
    printf 'BOOT_ID_SHA256=%s\n' "$(file_sha /proc/sys/kernel/random/boot_id)"
else
    printf 'BOOT_ID_SHA256=UNAVAILABLE\n'
fi
for p in init.svc.vendor.netmgrd init.svc.vendor.shsusrd persist.vendor.data.shs_ko_load persist.vendor.data.offload_ko_load persist.vendor.data.mode ro.vendor.use_data_netmgrd; do
    v="$(readprop "$p")"
    [ -n "$v" ] || v=EMPTY
    printf 'PROPERTY|%s|%s\n' "$p" "$(safe_field "$v")"
done

printf 'ROM_INIT_HASH_BEGIN\n'
for f in /vendor/etc/init/netmgrd.rc /system/vendor/etc/init/netmgrd.rc; do
    if [ -f "$f" ]; then
        printf 'INIT|%s|%s\n' "$f" "$(file_sha "$f")"
    else
        printf 'INIT|%s|ABSENT\n' "$f"
    fi
done
printf 'ROM_INIT_HASH_END\n'

printf 'MODULE_RUNTIME_BEGIN\n'
if [ -r /proc/modules ]; then
    printf 'PROC_MODULES_READABLE=YES\n'
else
    printf 'PROC_MODULES_READABLE=NO\n'
fi
for mod in ipa_fmwk rmnet_ctl rmnet_core rmnet_shs rmnet_offload; do
    if [ -r /proc/modules ]; then
        proc_present="$(awk -v wanted="$mod" '$1 == wanted { found=1 } END { if (found) print "YES"; else print "NO" }' /proc/modules)"
    else
        proc_present=UNAVAILABLE
    fi
    if [ -d "/sys/module/$mod" ]; then
        visible=YES
        if [ -r "/sys/module/$mod/initstate" ]; then
            initstate="$(tr -cd '[:alnum:]_-' < "/sys/module/$mod/initstate")"
            [ -n "$initstate" ] || initstate=EMPTY
        else
            initstate=UNAVAILABLE
        fi
    else
        visible=NO
        initstate=ABSENT
    fi
    printf 'MODULE|%s|PROC=%s|SYSFS=%s|INITSTATE=%s\n' "$mod" "$proc_present" "$visible" "$initstate"
done
printf 'MODULE_RUNTIME_END\n'

printf 'MODULE_FILES_BEGIN\n'
for path in \
 /vendor/lib/modules/rmnet_ctl.ko \
 /vendor/lib/modules/5.4-gki/ipa_fmwk.ko \
 /vendor/lib/modules/5.4-gki/rmnet_ctl.ko \
 /vendor/lib/modules/rmnet_core.ko \
 /vendor/lib/modules/5.4-gki/rmnet_core.ko \
 /vendor/lib/modules/rmnet_shs.ko \
 /vendor/lib/modules/5.4-gki/rmnet_shs.ko \
 /vendor/lib/modules/rmnet_offload.ko \
 /vendor/lib/modules/5.4-gki/rmnet_offload.ko; do
    if [ -f "$path" ]; then
        printf 'FILE|%s|%s\n' "$path" "$(file_sha "$path")"
    else
        printf 'FILE|%s|ABSENT\n' "$path"
    fi
done
printf 'MODULE_FILES_END\n'

printf 'COMPANION_PRESENCE_BEGIN\n'
for path in /data/adb/boot-completed.d/50-veux-rmnet.sh /data/adb/veux-rmnet/identity.txt; do
    if [ -f "$path" ]; then
        printf 'COMPANION|%s|PRESENT_HASH=%s\n' "$path" "$(file_sha "$path")"
    else
        printf 'COMPANION|%s|ABSENT\n' "$path"
    fi
done
printf 'COMPANION_PRESENCE_END\n'

printf 'NETWORK_COUNTERS_BEGIN\n'
for dev in rmnet_data0 rmnet_ipa0 wlan0; do
    if [ -d "/sys/class/net/$dev" ]; then
        rx=UNAVAILABLE;tx=UNAVAILABLE
        [ ! -r "/sys/class/net/$dev/statistics/rx_packets" ] || rx="$(cat "/sys/class/net/$dev/statistics/rx_packets" 2>/dev/null)"
        [ ! -r "/sys/class/net/$dev/statistics/tx_packets" ] || tx="$(cat "/sys/class/net/$dev/statistics/tx_packets" 2>/dev/null)"
        printf 'COUNTERS|%s|RX=%s|TX=%s\n' "$dev" "$rx" "$tx"
    else
        printf 'COUNTERS|%s|ABSENT\n' "$dev"
    fi
done
printf 'NETWORK_COUNTERS_END\n'
printf 'NETWORK_FUNCTIONAL_TEST=NOT_PERFORMED\n'
printf 'CURRENT_BOOT_LOADER_ERRORS=NOT_CAPTURED\n'
printf 'NO_PROPERTY_WRITES_NO_INSMOD_NO_NETWORK_NO_FLASH=YES\n'
printf 'END_VEUX_R32_DEVICE_READONLY_V1\n'
