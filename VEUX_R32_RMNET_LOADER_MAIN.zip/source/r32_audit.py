#!/usr/bin/env python3
"""VEUX R32: read-only ROM loader vs genuine CI-built kernel metadata.
No device interaction. No ability to rebuild, patch, flash or modify a kernel.
"""
from __future__ import annotations
import argparse, collections, csv, hashlib, io, json, re, stat, sys, zipfile
from pathlib import Path, PurePosixPath

REQUIRED_MODULES=('ipa_fmwk','rmnet_ctl','rmnet_core','rmnet_shs','rmnet_offload')
MAP_SYMS={
    'ipa_fmwk': 'ipa_fmwk_register_ipa',
    'rmnet_ctl': 'rmnet_ctl_probe',
    'rmnet_core': 'rmnet_core_genl_init',
    'rmnet_shs': '__tracepoint_ptr_rmnet_shs_low',
    'rmnet_offload': '__param_str_rmnet_offload_stat',
}
REQUIRED_R30=("inputs/R13_ACTUAL.config","inputs/STOCK_5_4_274.config","inputs/A_STOCK_IPC_ACTUAL.config", "inputs/R13_Module.symvers", "inputs/A_STOCK_IPC_Module.symvers", "inputs/R28_ERGEBNIS.json", "inputs/R30_AB_EXPERIMENT_SUMMARY.json")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(ok: bool, message: str):
    if not ok: raise ValueError(message)


def file_ok(root: Path, reference: dict):
    # Always verify pinned files before trusting any cross-document claim.
    for name, key in [('R13_BUILTIN_EVIDENCE.modinfo','R13_modules_builtin_modinfo_sha256'),
                       ('R30_A_ACTUAL_System.map','R30_A_System_map_sha256')]:
        path=root/'inputs'/name
        require(path.is_file() and sha(path.read_bytes())==reference[key], 'R32_EVIDENCE_HASH_FAILED:'+name)


def safe_manifest_zip(path: Path, expected_sha: str):
    data=path.read_bytes();require(sha(data)==expected_sha,'R32_ARCHIVE_PIN_CHANGED:'+path.name)
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        records=z.infolist(); names=[x.filename for x in records]
        require(len(names)==len(set(names)) and z.testzip() is None,'R32_INVALID_ZIP_CRC_OR_DUPLICATES')
        for e in records:
            p=PurePosixPath(e.filename)
            require(not p.is_absolute() and '..' not in p.parts and not e.is_dir() and stat.S_IFMT(e.external_attr>>16)!=stat.S_IFLNK, 'R32_UNSAFE_ARCHIVE_ENTRY')
            require(len(p.parts) <= 6,'R32_DEEP_ARCHIVE_PATH')
        require('MANIFEST_SHA256.json' in names, 'R32_ARCHIVE_MANIFEST_MISSING')
        m=json.loads(z.read('MANIFEST_SHA256.json'))
        require(m.get('schema')==1 and m.get('files') and set(m['files'])|{'MANIFEST_SHA256.json'}==set(names),'R32_UNTRUSTED_ARCHIVE_MANIFEST')
        for name,expected in m['files'].items():
            require(sha(z.read(name))==expected,'R32_ARCHIVE_MEMBER_CHANGED:'+name)
        return {n:z.read(n) for n in names}


def cfg(raw:bytes):
    result={}
    for line in raw.decode().splitlines():
        m=re.fullmatch(r'(CONFIG_[A-Z0-9_]+)=(.*)',line)
        if m:
            require(m[1] not in result, 'R32_DUPLICATE_CONFIG');result[m[1]]=m[2]
        else:
            m=re.fullmatch(r'# (CONFIG_[A-Z0-9_]+) is not set',line)
            if m:
                require(m[1] not in result,'R32_DUPLICATE_CONFIG');result[m[1]]='n'
    return result


def symvers(raw:bytes):
    symbols={}
    for line in raw.decode().splitlines():
        bits=line.split()
        require(len(bits)>=4 and re.fullmatch('0x[0-9a-fA-F]{8}',bits[0]) is not None,'R32_BAD_SYMVERS_ROW')
        k=bits[1];require(k not in symbols, 'R32_DUPLICATE_EXPORT:'+k)
        symbols[k]=bits[0].lower()
    return symbols


def builtin(raw:bytes):
    names=set()
    for e in raw.split(b'\0'):
        if b'.' in e and b'=' in e:
            k=e.split(b'.',1)[0].decode('utf8','replace')
            if re.fullmatch('[a-zA-Z0-9_]+',k):names.add(k)
    return names


def map_symbols(raw:bytes):
    result={}
    for line in raw.decode('utf8','replace').splitlines():
        s=line.split()
        if len(s)==3 and s[2] in MAP_SYMS.values():
            result.setdefault(s[2],[]).append(s[1])
    for key in MAP_SYMS.values():
        require(len(result.get(key,[]))==1,'R32_COMPILED_SYMBOL_NOT_UNIQUE:'+key)
    return {k:v[0] for k,v in result.items()}


def rom_rules(data:dict):
    require(data['schema']==1 and data['source_raw_not_in_public_zip'] is True,'R32_PRIVATE_ROM_BOUNDARY')
    require(data['source_sha256']=='568143f3edf386dda7a13503cea2df6cc03904cfa798e14dfab5487aa8e6403b','R32_ROM_SOURCE_HASH_UNEXPECTED')
    rules=data['rules'];require(len(rules)==12,'R32_ROM_RULE_COUNT')
    require(len(set((x['event'],x['name'],x['root_dir'],x['operation']) for x in rules))==12,'R32_DUPLICATE_INIT_RULE')
    dirs={'/vendor/lib/modules','/vendor/lib/modules/5.4-gki'}
    groups=collections.defaultdict(set)
    for x in rules:
        require(x['root_dir'] in dirs and x['name'] in ('rmnet_ctl','rmnet_core','rmnet_shs','rmnet_offload') and x['operation'] in ('LOAD','REMOVE'),'R32_BAD_ROM_MODULE_RULE')
        groups[(x['event'],x['name'],x['operation'])].add(x['root_dir'])
    for mod in ['rmnet_ctl','rmnet_core']:
        require(groups[('on boot',mod,'LOAD')]==dirs,'R32_ROM_BOOT_DUAL_PATH_MISSING:'+mod)
    for mod,prop in [('rmnet_shs','shs_ko_load'),('rmnet_offload','offload_ko_load')]:
        for status,op in [('1','LOAD'),('0','REMOVE')]:
            require(groups[(f'on property:persist.vendor.data.{prop}={status}',mod,op)]==dirs,'R32_ROM_PROPERTY_RULE_MISSING:'+mod+'='+status)
    return groups


def analyze(source:Path,r30zip:Path,r31zip:Path):
    refs=json.loads((source/'inputs/R32_SOURCE_PROVENANCE.json').read_text())
    require(refs['schema']==1 and refs['private_original_rc_published'] is False, 'R32_PROVENANCE_BAD')
    file_ok(source,refs)
    r30=safe_manifest_zip(r30zip,refs['R30_R2_main_sha256'])
    r31=safe_manifest_zip(r31zip,refs['R31_main_sha256'])
    for name in REQUIRED_R30:require(name in r30,'R32_R30_INPUT_MISSING:'+name)
    r31_flags=json.loads(r31['preview/R31_FINDINGS.json'])
    require(r31_flags['priority_module_paths']==9 and r31_flags['priority_module_paths_fully_compatible_A']==0,'R32_R31_GATE_CHANGED')
    c13=cfg(r30['inputs/R13_ACTUAL.config'])
    ca=cfg(r30['inputs/A_STOCK_IPC_ACTUAL.config'])
    cs=cfg(r30['inputs/STOCK_5_4_274.config'])
    require(c13['CONFIG_SCHED_CASS']=='y' and ca['CONFIG_SCHED_CASS']=='y','R32_CASS_BASE_CHANGED')
    require(c13['CONFIG_NR_CPUS']=='8' and ca['CONFIG_NR_CPUS']=='8' and cs['CONFIG_NR_CPUS']=='32','R32_CPU_GEOMETRY_CHANGED')
    require(c13['CONFIG_IPA3']=='y' and ca['CONFIG_IPA3']=='y','R32_IPA3_NOT_BUILT_IN')
    require(c13.get('CONFIG_TRACING','n')=='n' and ca['CONFIG_TRACING']=='y','R32_TRACE_CONTRACT_CHANGED')
    require(c13.get('CONFIG_MODVERSIONS')=='y' and ca.get('CONFIG_MODVERSIONS')=='y','R32_MODVERSIONS_CHANGED')
    a_sym=symvers(r30['inputs/A_STOCK_IPC_Module.symvers']);r13_sym=symvers(r30['inputs/R13_Module.symvers'])
    require(a_sym['module_layout']=='0xa6bdffa3','R32_A_MODULE_LAYOUT_CHANGED')
    require(r13_sym['module_layout']=='0xbff14f69','R32_R13_MODULE_LAYOUT_CHANGED')
    r30results=json.loads(r30['inputs/R30_AB_EXPERIMENT_SUMMARY.json'])
    assert r30results['A_STOCK_IPC']['oem_abi']['QGKI']['counts']=={'MATCH':1326,'CRC_MISMATCH':1792,'NOT_EXPORTED':30}
    orig_names=builtin((source/'inputs/R13_BUILTIN_EVIDENCE.modinfo').read_bytes())
    require(all(x in orig_names for x in REQUIRED_MODULES),'R32_MISSING_R13_BUILTIN_METADATA')
    amap=map_symbols((source/'inputs/R30_A_ACTUAL_System.map').read_bytes())
    rules=json.loads((source/'inputs/R50_NETMGRD_NORMALIZED_RULES.json').read_text())
    groups=rom_rules(rules)
    hist=json.loads((source/'inputs/R15_HISTORICAL_SANITIZED.json').read_text())
    require(hist['observation_not_current'] is True and hist['proc_modules']=='EMPTY','R32_HISTORY_NOT_PINNED')
    require(len(hist['vendor_modules'])==9 and all(re.fullmatch('[0-9a-f]{64}',v) for v in hist['vendor_modules'].values()),'R32_VENDOR_HASH_SET_INVALID')
    require(hist['kernel_notes_sha256']=='a11414e37b7b5941c9488ce22ac5db19a24e801672a0c222f9a721382b8c1f53','R32_WRONG_R15_KERNEL_NOTE')
    expected=['rmnet_ctl','rmnet_core','ipa_fmwk','rmnet_shs','rmnet_offload']
    status={'schema':1,'stage':'VEUX_R32_COMPILED_SYMBOL_AND_ROM_MODULE_LOADER_READONLY',
      'status':'STATIC_EVIDENCE_PASS__CURRENT_DEVICE_LOADER_UNVERIFIED__OEM_ABI_BLOCKED__NO_FLASH',
      'github_r31_run':41283292936,'github_r30_run':41207776770,'r13_candidate_github_run':40921711051,
      'kernel_built':False,'kernel_modified':False,'device_test_performed':False,'flash_allowed':False,
      'source_tree_final_post_overlay_verified':False,
      'r13_ci_builtin_metadata':{x:(x in orig_names) for x in expected},
      'r30_a_compiled_symbol_evidence':{x:{'symbol':MAP_SYMS[x],'type':amap[MAP_SYMS[x]],'found':True} for x in expected},
      'rom_historical_loader_rules':{'original_rc_sha256':rules['source_sha256'],'rule_count':len(rules['rules']),
          'boot_dual_directory_load_attempts':4,'shs_property_rules':4,'offload_property_rules':4,'current_rom_identity_verified':False,
          'note':'Both cohort commands appear; observed rules do not establish successful load or fallback behavior.'},
      'historical_r15_2026_10_31':{'proc_modules':hist['proc_modules'],'netmgrd':hist['properties']['VENDOR_NETMGRD'],
          'rmnet_data0':hist['net_counters'].get('rmnet_data0'),'rmnet_ipa0':hist['net_counters'].get('rmnet_ipa0'),
          'sysfs':hist['sys_module'],'nine_vendor_modules_hash_checked':9,'kernel_notes_sha256':hist['kernel_notes_sha256']},
      'module_layout':{'QGKI_expected':'0x945d02f2','GKI_expected':'0x1e5b7ab7','R13_actual':r13_sym['module_layout'],'R30_A_actual':a_sym['module_layout']},
      'OEM_external_nine_module_paths_ABI':{'fully_compatible':0,'incompatible':9},
      'binary_symbol_evidence_not_device_activation':True,
      'next_needed':'Run R32_DEVICE_READONLY.sh on currently active device and provide private capture; only then identify active driver, netmgrd state and which external .ko paths matter.'}
    csv_rows=[]
    for name in expected:
        csv_rows.append({'module':name,'r13_builtin_metadata':'YES','r30_a_compiled_symbol':MAP_SYMS[name],
                         'r30_a_symbol_type':amap[MAP_SYMS[name]],'running_state':'NOT_PROVEN','current_external_load_success':'NOT_PROVEN'})
    loader_rows=[{'boot_event':x['event'],'operation':x['operation'],'module':x['name'],'module_directory':x['root_dir'],
                  'original_rc_line':x['line'],'current_rom_confirmed':'NO'} for x in rules['rules']]
    msg='''VEUX R32 – ROM-Ladepfad gegen R13/R30-A Compiled Symbols (NO FLASH)\n\nA. Belege\n- R13 Build (Run 40921711051) enthält modules.builtin.modinfo-Einträge für ipa_fmwk, rmnet_ctl, rmnet_core, rmnet_shs, rmnet_offload. Das ist Build-Metadaten-, kein Live-Beweis.\n- Das echte R30-A System.map (Run 41207776770) enthält für alle fünf eine exemplarische, unabhängig geprüfte Kompilatsymbol-Signatur. Weder ausgeführte Initcalls noch gegenwärtige Hardwarefunktion sind dadurch belegt.\n- Originale historische netmgrd.rc (R50, SHA256 568143f3edf386dda7a13503cea2df6cc03904cfa798e14dfab5487aa8e6403b) enthält 12 relevante modprobe-Befehle (Boot + SHS/Offload-Lade-/Entladeregeln). Sie liegen in beiden Verzeichnissen /vendor/lib/modules und /vendor/lib/modules/5.4-gki. Kein Beweis, dass beide erfolgreich geladen werden.\n- Die private R15-Historie (31.10.) meldete netmgrd=running, PROC_MODULES=EMPTY, SHS/Offload unter /sys/module, rx_packets/tx_packets auf RMNET > 0 und neun unveränderte OEM-.ko-Hashes. Weder Live-Build-Identität noch aktuelle Mobilfunkfunktion sind damit vollständig bewiesen.\n\nB. Grenze und Priorität\n- Alle neun externen OEM-RMNET/IPA-Modulpfade bleiben laut R30-R2/R31 nicht vollständig ABI-kompatibel (QGKI/GKI getrennt).\n- Dieses Ergebnis ist nicht automatisch ein Nachweis, dass die entsprechenden Treiber auf dem Gerät fehlen: Built-in-Treiber können externe Ladeversuche überflüssig machen. Ebenso wenig dürfen fehlgeschlagene modprobe-Aufrufe pauschal ignoriert werden.\n- Aktuelle ROM-Datei und echter Modul-/Treiber-Laufzeitpfad stehen noch aus. Genaue gepatchte R13-Endquellen sind mit den vorliegenden CI-Artefakten nicht rekonstruiert.\n- Für den nächsten konkreten Beweis: optionales rein lesendes R32_DEVICE_READONLY.sh auf dem Gerät, privat auswerten. Niemals private Rohlogs/Boot-IDs/Moduldaten in ein öffentliches GitHub-Repo hochladen.\n\nC. Sicherheitsgrenze\n- Keine Kconfig-, Scheduler-, BReNE-, BakaSU-, SUSFS-, NoMount-, vendor- oder init-Änderung. Kein CRC-Spoofing, kein insmod/modprobe, kein Kernelbau, kein Flash.\n- STATIC_EVIDENCE_PASS != REAL_DEVICE_PASS != FULL_OEM_ABI_PASS.\n'''
    return status,csv_rows,loader_rows,msg


def write_csv(dest, rows):
    with dest.open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('--input',type=Path);p.add_argument('--r30',type=Path);p.add_argument('--r31',type=Path);p.add_argument('--out',type=Path);p.add_argument('--selftest',action='store_true');a=p.parse_args(argv)
    if a.selftest:
        assert sha(b'abc')=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'
        try:require(False,'R32_EXPECTED_FAILURE')
        except ValueError:pass
        else:raise AssertionError('R32_GATE_FAIL')
        print('R32_PURE_FUNCTION_SELFTEST=PASS');return
    require(all((x is not None for x in [a.input,a.r30,a.r31,a.out])),'R32_MISSING_FLAGS')
    data,mods,rules,report=analyze(a.input,a.r30,a.r31)
    a.out.mkdir(parents=True,exist_ok=True)
    (a.out/'R32_RESULTS.json').write_text(json.dumps(data,indent=2,sort_keys=True,ensure_ascii=False)+'\n')
    write_csv(a.out/'R32_COMPILED_SYMBOL_PROOF.csv',mods)
    write_csv(a.out/'R32_ROM_LOADER_RULES.csv',rules)
    (a.out/'R32_PRUEFBERICHT_DE.txt').write_text(report)
    print(data['status'])

if __name__=='__main__':main()
