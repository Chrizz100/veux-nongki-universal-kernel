"""R32 regression + fail-closed negative tests. Never access hardware."""
import copy, hashlib, io, json, os, pathlib, re, shutil, stat, sys, tempfile, unittest, zipfile
from unittest import mock
THIS=pathlib.Path(__file__).resolve()
ROOT=THIS.parents[1]
sys.path.insert(0,str(ROOT/'source'))
import r32_audit as r

class R32Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.refs=json.loads((ROOT/'inputs/R32_SOURCE_PROVENANCE.json').read_text())
        cls.r30=pathlib.Path(os.environ.get('R32_TEST_R30',str(ROOT.parent/'VEUX_R30_R2_OEM_CRC_MAIN.zip')))
        cls.r31=pathlib.Path(os.environ.get('R32_TEST_R31',str(ROOT.parent/'VEUX_R31_OEM_ABI_ROOTCAUSE_MAIN.zip')))
        cls.r30_data=r.safe_manifest_zip(cls.r30,cls.refs['R30_R2_main_sha256'])
        cls.r31_data=r.safe_manifest_zip(cls.r31,cls.refs['R31_main_sha256'])
        cls.rules=json.loads((ROOT/'inputs/R50_NETMGRD_NORMALIZED_RULES.json').read_text())
        cls.hist=json.loads((ROOT/'inputs/R15_HISTORICAL_SANITIZED.json').read_text())
        cls.sysmap=(ROOT/'inputs/R30_A_ACTUAL_System.map').read_bytes()
        cls.modinfo=(ROOT/'inputs/R13_BUILTIN_EVIDENCE.modinfo').read_bytes()

    def test_01_r30_archive_hash_and_members(self):
        self.assertEqual(r.sha(self.r30.read_bytes()),self.refs['R30_R2_main_sha256'])
        self.assertIn('inputs/R13_Module.symvers',self.r30_data)
    def test_02_r31_archive_hash_and_members(self):
        self.assertEqual(r.sha(self.r31.read_bytes()),self.refs['R31_main_sha256'])
        self.assertIn('preview/R31_FINDINGS.json',self.r31_data)
    def test_03_wrong_sha_archive_refused(self):
        with self.assertRaisesRegex(ValueError,'R32_ARCHIVE_PIN_CHANGED'):
            r.safe_manifest_zip(self.r30,'0'*64)
    def test_04_builtin_raw_pin(self):
        self.assertEqual(r.sha(self.modinfo),self.refs['R13_modules_builtin_modinfo_sha256'])
    def test_05_map_raw_pin(self):
        self.assertEqual(r.sha(self.sysmap),self.refs['R30_A_System_map_sha256'])
    def test_06_builtins_all_five(self):
        self.assertTrue(set(r.REQUIRED_MODULES).issubset(r.builtin(self.modinfo)))
    def test_07_builtin_absent_rejected(self):
        self.assertFalse(set(r.REQUIRED_MODULES).issubset(r.builtin(b'rmnet_core.license=GPL\0')))
    def test_08_exact_map_five(self):
        self.assertEqual(len(r.map_symbols(self.sysmap)),5)
    def test_09_missing_map_symbol_rejected(self):
        self.assertRaisesRegex(ValueError,'R32_COMPILED_SYMBOL_NOT_UNIQUE',r.map_symbols,b'1234 T rmnet_ctl_probe\n')
    def test_10_duplicate_map_symbol_rejected(self):
        self.assertRaisesRegex(ValueError,'R32_COMPILED_SYMBOL_NOT_UNIQUE',r.map_symbols,self.sysmap+b'ffffaaaa T rmnet_ctl_probe\n')
    def test_11_stock_cpu_32(self):
        c=r.cfg(self.r30_data['inputs/STOCK_5_4_274.config']);self.assertEqual(c['CONFIG_NR_CPUS'],'32')
    def test_12_r13_cpu_8(self):
        c=r.cfg(self.r30_data['inputs/R13_ACTUAL.config']);self.assertEqual(c['CONFIG_NR_CPUS'],'8')
    def test_13_a_cpu_8(self):
        c=r.cfg(self.r30_data['inputs/A_STOCK_IPC_ACTUAL.config']);self.assertEqual(c['CONFIG_NR_CPUS'],'8')
    def test_14_r13_cass_on(self):
        c=r.cfg(self.r30_data['inputs/R13_ACTUAL.config']);self.assertEqual(c['CONFIG_SCHED_CASS'],'y')
    def test_15_r13_ipa_builtin(self):
        c=r.cfg(self.r30_data['inputs/R13_ACTUAL.config']);self.assertEqual(c['CONFIG_IPA3'],'y')
    def test_16_trace_a_on_r13_off(self):
        c=r.cfg(self.r30_data['inputs/R13_ACTUAL.config']);a=r.cfg(self.r30_data['inputs/A_STOCK_IPC_ACTUAL.config']);self.assertEqual((c.get('CONFIG_TRACING','n'),a['CONFIG_TRACING']),('n','y'))
    def test_17_fake_duplicate_config_rejected(self):
        with self.assertRaisesRegex(ValueError,'R32_DUPLICATE_CONFIG'):r.cfg(b'CONFIG_X=y\n# CONFIG_X is not set\n')
    def test_18_r13_module_crc(self):
        self.assertEqual(r.symvers(self.r30_data['inputs/R13_Module.symvers'])['module_layout'],'0xbff14f69')
    def test_19_a_module_crc(self):
        self.assertEqual(r.symvers(self.r30_data['inputs/A_STOCK_IPC_Module.symvers'])['module_layout'],'0xa6bdffa3')
    def test_20_fake_symvers_duplicate_rejected(self):
        with self.assertRaisesRegex(ValueError,'R32_DUPLICATE_EXPORT'):r.symvers(b'0x11111111 abc vmlinux EXPORT_SYMBOL\n0x22222222 abc vmlinux EXPORT_SYMBOL\n')
    def test_21_fake_bad_symvers_rejected(self):
        with self.assertRaisesRegex(ValueError,'R32_BAD_SYMVERS_ROW'):r.symvers(b'BADVERSION name vmlinux EXPORT_SYMBOL\n')
    def test_22_twelve_init_rules(self):
        self.assertEqual(len(self.rules['rules']),12);self.assertEqual(len(r.rom_rules(self.rules)),6)
    def test_23_boot_both_dirs(self):
        self.assertEqual(len([x for x in self.rules['rules'] if x['event']=='on boot']),4)
    def test_24_no_fake_fallback_proof(self):
        self.assertIn('NOT',self.rules['assumption']);self.assertTrue(self.rules['exact_current_rom_file_not_verified'])
    def test_25_missing_rom_loader_rule_rejected(self):
        rule=copy.deepcopy(self.rules);rule['rules']=[x for x in rule['rules'] if not (x['name']=='rmnet_ctl' and x['root_dir'].endswith('5.4-gki'))]
        with self.assertRaisesRegex(ValueError,'R32_ROM_RULE_COUNT'):r.rom_rules(rule)
    def test_26_faked_rom_rule_group_rejected(self):
        rule=copy.deepcopy(self.rules);rule['rules'][0]['name']='rmnet_shs'
        with self.assertRaises(ValueError):r.rom_rules(rule)
    def test_27_bad_rom_original_hash_rejected(self):
        rule=copy.deepcopy(self.rules);rule['source_sha256']='0'*64
        with self.assertRaises(ValueError):r.rom_rules(rule)
    def test_28_private_raw_rc_excluded(self):
        self.assertNotIn('VEUX_R50_OEM_NETMGRD_ORIGINAL.rc',[str(x.relative_to(ROOT)) for x in ROOT.rglob('*') if x.is_file()]);self.assertTrue(self.rules['source_raw_not_in_public_zip'])
    def test_29_r15_is_historical(self):
        self.assertTrue(self.hist['observation_not_current']);self.assertEqual(self.hist['proc_modules'],'EMPTY')
    def test_30_r15_vendor_nine(self):
        self.assertEqual(len(self.hist['vendor_modules']),9)
    def test_31_r15_notes_exact(self):
        self.assertEqual(self.hist['kernel_notes_sha256'],'a11414e37b7b5941c9488ce22ac5db19a24e801672a0c222f9a721382b8c1f53')
    def test_32_r31_gate_still_blocked(self):
        d=json.loads(self.r31_data['preview/R31_FINDINGS.json']);self.assertEqual(d['priority_module_paths_fully_compatible_A'],0)
    def test_33_no_kernel_build(self):
        d,*_=r.analyze(ROOT,self.r30,self.r31);self.assertFalse(d['kernel_built']);self.assertFalse(d['flash_allowed'])
    def test_34_no_runtime_claim(self):
        d,*_=r.analyze(ROOT,self.r30,self.r31);self.assertFalse(d['device_test_performed']);self.assertFalse(d['source_tree_final_post_overlay_verified'])
    def test_35_map_edited_rejected(self):
        with mock.patch.object(r,'sha',wraps=r.sha) as spy:
            r.file_ok(ROOT,self.refs);self.assertGreater(spy.call_count,0)
        # wrong pinned digest must fail even though the underlying file is legitimate
        bad=dict(self.refs);bad['R30_A_System_map_sha256']='f'*64
        with self.assertRaisesRegex(ValueError,'R32_EVIDENCE_HASH_FAILED'):r.file_ok(ROOT,bad)
    def test_36_rom_modified_binary_rejected(self):
        bad=copy.deepcopy(self.refs);bad['R13_modules_builtin_modinfo_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'R32_EVIDENCE_HASH_FAILED'):r.file_ok(ROOT,bad)
    def test_37_bytes_repeatable(self):
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as t1,TemporaryDirectory() as t2:
            for t in [t1,t2]:
                r.main(['--input',str(ROOT),'--r30',str(self.r30),'--r31',str(self.r31),'--out',t])
            for n in ['R32_RESULTS.json','R32_COMPILED_SYMBOL_PROOF.csv','R32_ROM_LOADER_RULES.csv','R32_PRUEFBERICHT_DE.txt']:
                self.assertEqual((pathlib.Path(t1)/n).read_bytes(),(pathlib.Path(t2)/n).read_bytes())
    def test_38_readonly_script_no_write(self):
        script=(ROOT/'R32_DEVICE_READONLY.sh').read_text()
        for term in ['modprobe ','insmod ','dd if=','flash_','fastboot ','setprop ','settings put','curl ','wget ','ifconfig ','ip route add']:
            # Comments can contain words like insmod; restrict to non-comment script code.
            body='\n'.join(x for x in script.splitlines() if not x.strip().startswith('#'))
            self.assertNotIn(term,body,term)
        self.assertIn('NO_PROPERTY_WRITES_NO_INSMOD_NO_NETWORK_NO_FLASH=YES',script)
    def test_39_sysfs_not_built_in_proof(self):
        d,*_=r.analyze(ROOT,self.r30,self.r31)
        self.assertTrue(d['binary_symbol_evidence_not_device_activation']);self.assertFalse(d['rom_historical_loader_rules']['current_rom_identity_verified'])
    def test_40_vendor_two_cohorts_not_merged(self):
        d,*_=r.analyze(ROOT,self.r30,self.r31)
        self.assertNotEqual(d['module_layout']['QGKI_expected'],d['module_layout']['GKI_expected'])
    def test_41_release_gate_explicitly_blocked(self):
        d,*_=r.analyze(ROOT,self.r30,self.r31)
        self.assertIn('ABI_BLOCKED',d['status']);self.assertIn('NO_FLASH',d['status'])
    def test_42_manifest_rejects_missing_files(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'wrong.zip'
            with zipfile.ZipFile(p,'w') as z:z.writestr('x.txt','secret')
            with self.assertRaisesRegex(ValueError,'R32_ARCHIVE_MANIFEST_MISSING'):r.safe_manifest_zip(p,r.sha(p.read_bytes()))
    def test_43_manifest_rejects_zip_traversal(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'unsafe.zip';d=b'hi';m={'schema':1,'files':{'../secret.txt':r.sha(d)}}
            with zipfile.ZipFile(p,'w') as z:z.writestr('../secret.txt',d);z.writestr('MANIFEST_SHA256.json',json.dumps(m))
            with self.assertRaisesRegex(ValueError,'R32_UNSAFE_ARCHIVE_ENTRY'):r.safe_manifest_zip(p,r.sha(p.read_bytes()))
    def test_44_manifest_rejects_symlink(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'symlink.zip';d=b'hi';m={'schema':1,'files':{'link.txt':r.sha(d)}}
            with zipfile.ZipFile(p,'w') as z:
                zi=zipfile.ZipInfo('link.txt');zi.create_system=3;zi.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(zi,d)
                z.writestr('MANIFEST_SHA256.json',json.dumps(m))
            with self.assertRaisesRegex(ValueError,'R32_UNSAFE_ARCHIVE_ENTRY'):r.safe_manifest_zip(p,r.sha(p.read_bytes()))
    def test_45_manifest_rejects_wrong_content_hash(self):
        with tempfile.TemporaryDirectory() as t:
            p=pathlib.Path(t)/'bad.zip';m={'schema':1,'files':{'file.txt':'0'*64}}
            with zipfile.ZipFile(p,'w') as z:z.writestr('file.txt','abc');z.writestr('MANIFEST_SHA256.json',json.dumps(m))
            with self.assertRaisesRegex(ValueError,'R32_ARCHIVE_MEMBER_CHANGED'):r.safe_manifest_zip(p,r.sha(p.read_bytes()))

if __name__=='__main__':unittest.main()
