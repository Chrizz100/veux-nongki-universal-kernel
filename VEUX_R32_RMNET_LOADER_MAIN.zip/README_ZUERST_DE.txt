VEUX R32 – ROM RMNET Loader vs. R13 Built-ins + R30-A Compiled Symbols (NO FLASH)
Datum 01.11.2026

ZWECK
- Historische originale netmgrd.rc-Datei nur als maschinell reduzierte Laderegeln auswerten.
- Prüfen, was R13 nach CI-Modul-Metadaten bereits integriert hat.
- Echtes R30-A System.map aus dem bereits erfolgreich gebauten GitHub-R30 vergleichen.
- Einordnung der neun externen OEM-Modulpfade ohne unzulässige CRC-Korrektur.
- Optional aktuellen echten Geräte-Ladepfad rein lesend erfassen.

GITHUB (EINFACH, KEINE SECRETS)
1. Die vorhandenen VEUX_R30_R2_OEM_CRC_MAIN.zip und VEUX_R31_OEM_ABI_ROOTCAUSE_MAIN.zip
   im Repository-Hauptverzeichnis BELASSEN.
2. Diese VEUX_R32_RMNET_LOADER_MAIN.zip ins Repository-Hauptverzeichnis hochladen.
3. VEUX_R32_RMNET_LOADER_NOFLASH.yml nach .github/workflows/ hochladen.
4. GitHub Actions > VEUX R32 ROM-RMNET Loader and Compiled ABI - NO FLASH > Run workflow.
5. Einzige Ausgabe: kleines Analyseartefakt; kein Kernel-/Boot-/AK3-Image.

OPTIONAL: AKTUELLEN TREIBER-/LADESTATUS PRIVAT NACHWEISEN
- R32_DEVICE_READONLY.sh aus dieser ZIP entpacken und in /sdcard/Download/ kopieren.
- In Termux (kein PC nötig) als Root ausführen:
  su -c 'sh /sdcard/Download/R32_DEVICE_READONLY.sh' > /sdcard/Download/R32_DEVICE_RESULT.txt 2>&1
- R32_DEVICE_RESULT.txt NUR IM PRIVATEN CHAT hochladen, NIEMALS ins öffentliche GitHub.
- Kein Root-Modul deaktivieren oder deinstallieren. Kein WLAN- oder Mobilfunkwechsel nötig.
- Das Skript prüft keine Mobilfunkfunktion, sondern nur den aktiven Modul-/ROM-Zustand.

WICHTIGE BEFUNDGRENZEN
- R13 modules.builtin.modinfo ist Beweis der CI-Built-in-Metadaten, NICHT des Handy-Zustands.
- R30-A System.map beweist kompilierte Symbole, NICHT deren Aktivierung auf dem Handy.
- Originale historische netmgrd.rc SHA256: 568143f3edf386dda7a13503cea2df6cc03904cfa798e14dfab5487aa8e6403b;
  nicht in der öffentlichen ZIP enthalten, nur die normalisierten Befehle.
- Private R15-Gerätedaten sind auf historische Status-/SHA-Werte reduziert.
- Die finalen kompletten R13-Quellen nach allen Overlays sind nicht identisch rekonstruiert.
- Neun OEM-Module bleiben nach R30-R2/R31 extern ABI-inkompatibel. Das allein ist kein
  Beleg für fehlende Mobilfunkfunktion, sofern Built-in-Treiber bereits aktiv sind.

SCHUTZ
R13/CASS/BReNE/BakaSU/SUSFS/NoMount unverändert. Keine Vendor-/Init-/Moduländerung,
kein insmod, kein CRC-Spiegeln, kein Kernelbau, keine Flashfreigabe.
