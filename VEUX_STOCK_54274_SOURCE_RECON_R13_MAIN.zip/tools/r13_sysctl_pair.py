#!/usr/bin/env python3
"""R13: import the *real* pinned WALT sysctl parser + original Stock declaration.

This is a temporary compiler-probe overlay only, NEVER a production patch.
The original 5.4.268 donor Git worktree and actual 5.4.274 OEM boot stay unchanged.
"""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

SCHEMA='VEUX_R13_VERIFIED_STOCK_SYSCTL_FUNCTION_PAIR_NOFLASH'
R12_SHA='71a2984347ce1302f9503e240b832b8fb07506961879dceec1790e3572bfe6ee'
STOCK_SYSCTL_SHA='a40790ea7884c5fad110f17d56445bef069fb7eed1251c8d0ea1a00611cafe60'
STOCK_SCHED_SHA='a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
PAIR_SHA='01cb3a8824b7b4caf3e3540274e71abba5ade538'
DONOR_SHA='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
PAIR_C_BLOB='ce8cff2a5d8f2657e5bf8e00db0337b86cb78ff0'
PAIR_H_BLOB='40d14f940e284faabfec852e6bdf28dfb634a39a'
DONOR_C_BLOB='648dfa089f589e4755980ad82b8dd1d136f93d49'
DONOR_H_BLOB='aa615a0863f5cab4467d88ec0558a0c914db4163'
FUNC='proc_douintvec_ravg_window'

def sha(buf):return hashlib.sha256(buf).hexdigest()
def blob_sha(buf):return hashlib.sha1(b'blob '+str(len(buf)).encode()+b'\0'+buf).hexdigest()
def git(repo,*args):
    return subprocess.check_output(['git','-C',str(repo),*args],text=True,stderr=subprocess.PIPE).strip()

def load_main(root):
    root=Path(root)
    if root.is_symlink():raise ValueError('R13_SYMLINK_ROOT')
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (m.get('schema')!=SCHEMA or m.get('flash_allowed') is not False or
        m.get('production_patch_approved') is not False or m.get('oem_abi_verified') is not False or
        m.get('full_walt_ported') is not False or m.get('object_compile_requested') is not True):
        raise ValueError('R13_UNSAFE_MANIFEST')
    if (m.get('r12_sha256')!=R12_SHA or m.get('stock_sysctl_sha256')!=STOCK_SYSCTL_SHA or
        m.get('pair_commit')!=PAIR_SHA or m.get('donor_commit')!=DONOR_SHA or
        m.get('pair_sysctl_c_git_blob')!=PAIR_C_BLOB or m.get('pair_sysctl_h_git_blob')!=PAIR_H_BLOB):
        raise ValueError('R13_SOURCE_PROVENANCE_DRIFT')
    from zipfile import ZipFile
    if sha((root/'reference/R12_MAIN_ORIGINAL.zip').read_bytes())!=R12_SHA:
        raise ValueError('R13_R12_NESTED_DRIFT')
    if sha((root/'reference/stock_sysctl.h').read_bytes())!=STOCK_SYSCTL_SHA:
        raise ValueError('R13_STOCK_HEADER_DRIFT')
    paths={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if paths != set(m['files'])|{'MANIFEST_SHA256.json'} or any(p.is_symlink() for p in root.rglob('*')):
        raise ValueError('R13_UNEXPECTED_FILESET')
    for rel,expected in m['files'].items():
        p=root/rel
        if not p.is_file() or p.is_symlink() or sha(p.read_bytes())!=expected:
            raise ValueError('R13_FILE_TAMPERING:'+rel)
    with ZipFile(root/'reference/R12_MAIN_ORIGINAL.zip') as z:
        if z.testzip() is not None:raise ValueError('R13_NESTED_CORRUPT')
        d=json.loads(z.read('MANIFEST_SHA256.json'))
        if (d.get('schema')!='VEUX_R12_WALT_PINNED_INTERFACE_HEADER_PROBE_NOFLASH' or
            d.get('stock_task_sha256')!=STOCK_SCHED_SHA or d.get('flash_allowed') is not False):
            raise ValueError('R13_NESTED_SCHEMA_OR_STOCK_DRIFT')
    return m

def extract_original_source(pair_source):
    if pair_source.count('static int do_proc_douintvec_rwin(')!=1:
        raise ValueError('R13_PINNED_CONVERTER_MISSING_OR_DUPLICATED')
    start=pair_source.index('static int do_proc_douintvec_rwin(')
    boundary='\n#else /* CONFIG_PROC_SYSCTL */'
    if pair_source.count(boundary)!=1:raise ValueError('R13_UPSTREAM_CONFIG_SCOPE_DRIFT')
    end=pair_source.index(boundary,start)
    real=pair_source[start:end].strip()
    if (real.count('int proc_douintvec_ravg_window(')!=1 or
        real.count('do_proc_dointvec(table, write, buffer, lenp, ppos,')!=1 or
        '#else' in real or '#endif' in real or len(real)>1800 or
        not all(k in real for k in ['*lvalp == 2','*lvalp == 3','*lvalp == 4','*lvalp == 5','*lvalp == 8','return -EINVAL'])):
        raise ValueError('R13_UPSTREAM_FUNCTION_SEMANTICS_DRIFT')
    after=pair_source.index(boundary)+len(boundary)
    stub_start=pair_source.index('\nint proc_douintvec_ravg_window(',after)+1
    stub_end=pair_source.index('\nint proc_douintvec_capacity(',stub_start)
    stub=pair_source[stub_start:stub_end].strip()
    if (stub.count('int proc_douintvec_ravg_window(')!=1 or
        'return -ENOSYS;' not in stub or len(stub)>400):
        raise ValueError('R13_UPSTREAM_FALLBACK_SEMANTICS_DRIFT')
    return real,stub

def extract_stock_declaration(stock_header):
    matches=re.findall(r'(?m)^extern int proc_douintvec_ravg_window\([\s\S]*?\);',stock_header)
    if len(matches)!=1 or len(matches[0])>250:
        raise ValueError('R13_GENUINE_STOCK_DECLARATION_MISSING')
    return matches[0]

def apply_pinned_pair_to_donor(donor_h,donor_c,stock_h,pair_h,pair_c):
    decl=extract_stock_declaration(stock_h)
    pair_decl=extract_stock_declaration(pair_h)
    if re.sub(r'\s+','',decl)!=re.sub(r'\s+','',pair_decl):
        raise ValueError('R13_DECLARATION_INCOMPATIBLE_WITH_PAIR_SOURCE')
    if FUNC in donor_h or FUNC in donor_c or 'do_proc_douintvec_rwin' in donor_c:
        raise ValueError('R13_ALREADY_PORTED_OR_DUPLICATE')
    anchor='/*\n * Register a set of sysctl names'
    if donor_h.count(anchor)!=1:raise ValueError('R13_DONOR_HEADER_ANCHOR_DRIFT')
    patched_h=donor_h.replace(anchor,decl+'\n\n'+anchor,1)
    if 'static int do_proc_dointvec(' not in donor_c:
        raise ValueError('R13_REQUIRED_DONOR_CONVERSION_ENGINE_MISSING')
    real,stub=extract_original_source(pair_c)
    first='\n#else /* CONFIG_PROC_SYSCTL */'
    last='\n#endif /* CONFIG_PROC_SYSCTL */'
    if donor_c.count(first)!=1 or donor_c.count(last)!=1:
        raise ValueError('R13_DONOR_SYSCTL_CONFIG_ANCHOR_DRIFT')
    patched_c=donor_c.replace(first,'\n\n'+real+'\n'+first,1)
    patched_c=patched_c.replace(last,'\n\n'+stub+'\n'+last,1)
    if (patched_c.count('int proc_douintvec_ravg_window(')!=2 or
        patched_c.count('static int do_proc_douintvec_rwin(')!=1):
        raise ValueError('R13_BAD_SOURCE_PATCH_COUNT')
    return patched_h,patched_c,{'stock_declaration':decl,'real_source':real,'fallback_source':stub}

def stage(root,donor,pair,trial,reports):
    root=Path(root);donor=Path(donor);pair=Path(pair);trial=Path(trial);reports=Path(reports)
    load_main(root)
    if (git(donor,'rev-parse','HEAD')!=DONOR_SHA or git(donor,'status','--porcelain') or
        git(trial,'rev-parse','HEAD')!=DONOR_SHA or
        git(pair,'rev-parse','HEAD')!=PAIR_SHA or git(pair,'status','--porcelain')):
        raise ValueError('R13_GIT_COMMIT_OR_CLEAN_GUARD')
    for rel,sha_g in {'kernel/sysctl.c':PAIR_C_BLOB,'include/linux/sysctl.h':PAIR_H_BLOB}.items():
        data=(pair/rel).read_bytes()
        if (git(pair,'rev-parse','HEAD:'+rel)!=sha_g or blob_sha(data)!=sha_g or
            (pair/rel).is_symlink()):
            raise ValueError('R13_PINNED_PAIR_CONTENT_DRIFT:'+rel)
    for rel,sha_g in {'kernel/sysctl.c':DONOR_C_BLOB,'include/linux/sysctl.h':DONOR_H_BLOB}.items():
        data=(trial/rel).read_bytes()
        if git(trial,'rev-parse','HEAD:'+rel)!=sha_g or blob_sha(data)!=sha_g or (trial/rel).is_symlink():
            raise ValueError('R13_DONOR_SYSCTL_ANCHOR_DRIFT:'+rel)
    stock_task=trial/'include/linux/sched.h'
    if sha(stock_task.read_bytes())!=STOCK_SCHED_SHA:
        raise ValueError('R13_STOCK_TASK_WOULD_CHANGE')
    s=(root/'reference/stock_sysctl.h').read_text()
    ph=(pair/'include/linux/sysctl.h').read_text()
    pc=(pair/'kernel/sysctl.c').read_text()
    target_h=trial/'include/linux/sysctl.h';target_c=trial/'kernel/sysctl.c'
    hd,cd,prov=apply_pinned_pair_to_donor(target_h.read_text(),target_c.read_text(),s,ph,pc)
    old_h,old_c=sha(target_h.read_bytes()),sha(target_c.read_bytes())
    target_h.write_text(hd);target_c.write_text(cd)
    if (git(donor,'status','--porcelain') or sha(stock_task.read_bytes())!=STOCK_SCHED_SHA or
        FUNC not in target_h.read_text() or FUNC not in target_c.read_text()):
        raise ValueError('R13_DONOR_OR_STOCK_GUARD_AFTER_STAGE')
    report={'schema':SCHEMA,'source_commits':{'pair':PAIR_SHA,'donor':DONOR_SHA},
            'upstream_source_git_blobs':{'kernel/sysctl.c':PAIR_C_BLOB,'include/linux/sysctl.h':PAIR_H_BLOB},
            'reference':'genuine OEM stock_sysctl.h via R1 kheaders + genuine pinned Qualcomm source function',
            'stock_sysctl_header_sha256':STOCK_SYSCTL_SHA,'stock_task_struct_sha256':STOCK_SCHED_SHA,
            'source_functions_proven':{'real_sha256':sha(prov['real_source'].encode()),
                                       'fallback_sha256':sha(prov['fallback_source'].encode()),
                                       'declaration_sha256':sha(prov['stock_declaration'].encode())},
            'files_changed_in_experimental_worktree':{
                'include/linux/sysctl.h':{'before':old_h,'after':sha(target_h.read_bytes())},
                'kernel/sysctl.c':{'before':old_c,'after':sha(target_c.read_bytes())}},
            'full_walt_ported':False,'vmlinux_linked':False,'oem_abi_verified':False,
            'stock_5_4_274_source_reproduced':False,'production_patch_approved':False,'flash_allowed':False}
    reports.mkdir(parents=True,exist_ok=True)
    (reports/'R13_VERIFIED_ORIGINAL_SYSCTL_PROVENANCE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R13_PAIR_SOURCE_STAGED':True,'STOCK_TASK_PRESERVED':True,'DONOR_ORIGINAL_CLEAN':True,'FLASH_ALLOWED':False}))
    return report

def summary(reports):
    reports=Path(reports); stages={}
    for name in ['prepare','weak','real','sysctl']:
        nameup=name.upper()
        rcpath=reports/f'R13_{nameup}_RC.txt';logpath=reports/f'R13_{nameup}_BUILD.log'
        rc=int(rcpath.read_text().strip()) if rcpath.exists() else None
        body=logpath.read_text(errors='replace') if logpath.exists() else ''
        errors=[x[:550] for x in body.splitlines() if re.search(r'\berror:|\bfatal error:|make(?:\[\d+\])?: \*\*\*',x)]
        stages[name]={'rc':rc,'compiler_error_count':len(errors),'first_errors':errors[:55],
                      'log_lines':len(body.splitlines())}
    ok=all(v['rc']==0 for v in stages.values())
    out={'schema':SCHEMA,'status':'R13_THREE_OBJECT_COMPILER_PASS_NOT_ABI' if ok else 'R13_WALT_SYSCTL_COMPILER_BLOCKERS',
         'stages':stages,'three_object_compilation_pass':ok,'vmlinux_linked':False,
         'full_walt_ported':False,'stock_rtmm_implemented':False,
         'stock_5_4_274_source_reproduced':False,'oem_abi_verified':False,
         'boot_tested':False,'production_patch_approved':False,'flash_allowed':False}
    (reports/'R13_THREE_OBJECT_COMPILER_SUMMARY.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R13_OBJECT_COMPILER_PASS':ok,'RC':{k:x['rc'] for k,x in stages.items()},'FLASH':False}))
    return out

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['verify','stage','summary'])
    p.add_argument('--root');p.add_argument('--donor');p.add_argument('--pair');p.add_argument('--trial');p.add_argument('--reports')
    a=p.parse_args()
    if a.mode=='verify':print(json.dumps({'manifest':load_main(a.root)['schema'],'flash':False}))
    elif a.mode=='stage':stage(a.root,a.donor,a.pair,a.trial,a.reports)
    else:summary(a.reports)
if __name__=='__main__':main()
