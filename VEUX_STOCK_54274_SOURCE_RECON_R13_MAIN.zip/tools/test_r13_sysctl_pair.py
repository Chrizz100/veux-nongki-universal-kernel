import hashlib
import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r13sysctl',HERE/'r13_sysctl_pair.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
ROOT=HERE.parent

STOCK_DEC='''extern int proc_douintvec_ravg_window(struct ctl_table *table, int write,
                              void __user *buffer, size_t *lenp,
                              loff_t *ppos);'''
PAIR_SOURCE='''
#ifdef CONFIG_PROC_SYSCTL
static int do_proc_douintvec_rwin(bool *negp, unsigned long *lvalp,
                                 int *valp, int write, void *data)
{
    if (write) {
        if (*lvalp == 2 || *lvalp == 3 || *lvalp == 4 || *lvalp == 5 ||
            *lvalp == 8)
            *valp = *lvalp;
        else
            return -EINVAL;
    } else {
        *negp = false;
        *lvalp = *valp;
    }
    return 0;
}
int proc_douintvec_ravg_window(struct ctl_table *table, int write,
                              void __user *buffer, size_t *lenp, loff_t *ppos)
{
    return do_proc_dointvec(table, write, buffer, lenp, ppos,
                           do_proc_douintvec_rwin, NULL);
}
#else /* CONFIG_PROC_SYSCTL */
int proc_douintvec_ravg_window(struct ctl_table *table, int write,
                              void __user *buffer, size_t *lenp, loff_t *ppos)
{
    return -ENOSYS;
}
int proc_douintvec_capacity(struct ctl_table *table, int write,
                              void __user *buffer, size_t *lenp, loff_t *ppos)
{
    return -ENOSYS;
}
#endif /* CONFIG_PROC_SYSCTL */
'''
DONOR_H='''extern int proc_do_static_key(struct ctl_table *, int);
/*
 * Register a set of sysctl names etc */
'''
DONOR_C='''#ifdef CONFIG_PROC_SYSCTL
static int do_proc_dointvec(struct ctl_table *table, int write,
    void __user *buffer, size_t *lenp, loff_t *ppos,
    void *conv, void *ctx) { return 0; }
#else /* CONFIG_PROC_SYSCTL */
int proc_dointvec(struct ctl_table *t, int w) {return -ENOSYS;}
#endif /* CONFIG_PROC_SYSCTL */
'''

class R13Tests(unittest.TestCase):
    def test_01_bundle_manifest_original_hash(self):
        v=m.load_main(ROOT);self.assertEqual(v['schema'],m.SCHEMA)
    def test_02_stock_reference_unchanged(self):
        v=(ROOT/'reference/stock_sysctl.h').read_bytes();self.assertEqual(m.sha(v),m.STOCK_SYSCTL_SHA)
    def test_03_nested_r12_original(self):
        v=(ROOT/'reference/R12_MAIN_ORIGINAL.zip').read_bytes();self.assertEqual(m.sha(v),m.R12_SHA)
    def test_04_extract_real_original_source(self):
        real,stub=m.extract_original_source(PAIR_SOURCE)
        self.assertIn('do_proc_douintvec_rwin',real);self.assertIn('return -ENOSYS;',stub)
    def test_05_real_converter_rejects_unlisted_windows(self):
        real,_=m.extract_original_source(PAIR_SOURCE)
        self.assertIn('return -EINVAL',real)
        for x in ('2','3','4','5','8'):self.assertIn('*lvalp == '+x,real)
    def test_06_pair_and_stock_declaration_matching(self):
        h,_c,_=m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C,STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
        self.assertIn(STOCK_DEC,h)
    def test_07_source_insert_both_config_branches(self):
        _h,c,prov=m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C,STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
        self.assertEqual(c.count('int proc_douintvec_ravg_window('),2)
        self.assertIn('do_proc_douintvec_rwin',c)
        self.assertIn('return -ENOSYS;',c)
        self.assertEqual(len(prov),3)
    def test_08_bad_upstream_function_rejected(self):
        with self.assertRaises(ValueError):m.extract_original_source(PAIR_SOURCE.replace('*lvalp == 8','*lvalp == 9'))
    def test_09_upstream_missing_implementation_rejected(self):
        with self.assertRaises(ValueError):m.extract_original_source(PAIR_SOURCE.replace('static int do_proc_douintvec_rwin','static int other_func'))
    def test_10_missing_pair_fallback_rejected(self):
        with self.assertRaises(ValueError):m.extract_original_source(PAIR_SOURCE.replace('return -ENOSYS;','return 0;'))
    def test_11_original_stock_type_incompatible_rejected(self):
        with self.assertRaises(ValueError):m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C,STOCK_DEC,STOCK_DEC.replace('int write','long write'),PAIR_SOURCE)
    def test_12_duplicate_def_rejected(self):
        with self.assertRaises(ValueError):m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C+'\nvoid proc_douintvec_ravg_window();\n',STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
    def test_13_missing_donor_converter_rejected(self):
        with self.assertRaises(ValueError):m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C.replace('static int do_proc_dointvec(', 'static int nonsense('),STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
    def test_14_missing_config_boundary_rejected(self):
        with self.assertRaises(ValueError):m.apply_pinned_pair_to_donor(DONOR_H,DONOR_C.replace('/* CONFIG_PROC_SYSCTL */','/* INVALID */'),STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
    def test_15_missing_header_anchor_rejected(self):
        with self.assertRaises(ValueError):m.apply_pinned_pair_to_donor('no anchor',DONOR_C,STOCK_DEC,STOCK_DEC,PAIR_SOURCE)
    def test_16_missing_stock_decl_rejected(self):
        with self.assertRaises(ValueError):m.extract_stock_declaration('only unrelated functions')
    def test_17_provenance_git_hash_formula(self):
        self.assertEqual(m.blob_sha(b'hello'),hashlib.sha1(b'blob 5\0hello').hexdigest())
    def test_18_summary_failure_not_flash(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for key,val in {'PREPARE':0,'WEAK':0,'REAL':2,'SYSCTL':0}.items():
                (p/f'R13_{key}_RC.txt').write_text(str(val));(p/f'R13_{key}_BUILD.log').write_text('error: example\n' if val else 'CC success')
            r=m.summary(p)
            self.assertFalse(r['three_object_compilation_pass']);self.assertFalse(r['flash_allowed'])
    def test_19_summary_success_still_noflash(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            for key in ['PREPARE','WEAK','REAL','SYSCTL']:(p/f'R13_{key}_RC.txt').write_text('0');(p/f'R13_{key}_BUILD.log').write_text('CC success')
            r=m.summary(p)
            self.assertTrue(r['three_object_compilation_pass']);self.assertFalse(r['oem_abi_verified'])
            self.assertFalse(r['flash_allowed']);self.assertFalse(r['vmlinux_linked'])
    def test_20_missing_return_codes_are_failure(self):
        with tempfile.TemporaryDirectory() as d:
            r=m.summary(d)
            self.assertFalse(r['three_object_compilation_pass']);self.assertIsNone(r['stages']['sysctl']['rc'])
    def test_21_no_production_patch_or_crc_spoof(self):
        c=(HERE/'r13_sysctl_pair.py').read_text()
        self.assertIn("'production_patch_approved':False",c)
        self.assertNotIn('CONFIG_MODVERSIONS=n',c)
        self.assertNotIn('disable_walt',c)
    def test_22_pair_commit_and_blob_anchored(self):
        self.assertEqual(m.PAIR_C_BLOB,'ce8cff2a5d8f2657e5bf8e00db0337b86cb78ff0')
        self.assertEqual(m.DONOR_C_BLOB,'648dfa089f589e4755980ad82b8dd1d136f93d49')

if __name__=='__main__':unittest.main()
