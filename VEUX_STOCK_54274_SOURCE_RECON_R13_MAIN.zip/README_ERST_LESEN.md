# VEUX R13: Original-Stock-Sysctl und echte Qualcomm-WALT-Funktion (NOFLASH)

Ergebnis R12: `kernel/sched/walt.o` erfolgreich; `techpack/sched/walt.o` scheitert allein an
`proc_douintvec_ravg_window`. Diese Schnittstelle ist im **originalen Stock-Header**
`include/linux/sysctl.h` tatsächlich deklariert (R1-Stock-`ikheaders`).

Originale Qualcomm-Implementierung: `shandongtlb/kernel_xiaomi_sm8350_M11`, exakt
Commit `01cb3a8824b7b4caf3e3540274e71abba5ade538`,
`kernel/sysctl.c` Git-Blob `ce8cff2a5d8f2657e5bf8e00db0337b86cb78ff0`.
R13 übernimmt genau die Funktion mit ihrer **echten Werteprüfung** (2, 3, 4, 5, 8),
zusammen mit dem `CONFIG_PROC_SYSCTL=n`-Fallback. Keine Dummy-Funktion.

R13 arbeitet ausschließlich in einem temporären Git-Worktree. Enthalten ist das
originale R12-MAIN-Archiv, das wiederum R11 enthält. Der bestehende 5.4.268-Spender
bleibt unverändert; der tatsächliche Xiaomi-Stock-5.4.274-Quellbaum ist noch nicht
wiederhergestellt.

R13 prüft 3 **einzelne** Objekte: `kernel/sched/walt.o`,
`techpack/sched/walt.o` und `kernel/sysctl.o` mit gepinntem Android Clang 11.0.2.
Ein erfolgreicher Objekt-Compilerlauf ist **kein** vollständiger WALT-Port und
**keine** OEM-ABI-, Boot- oder Flashfreigabe. RTMM ist noch nicht portiert.

Zwei Dateien auf GitHub: `VEUX_STOCK_54274_SOURCE_RECON_R13_MAIN.zip` ins Repo-Hauptverzeichnis,
`VEUX_STOCK_54274_SOURCE_RECON_R13_NOFLASH.yml` nach `.github/workflows/`. Frühere MAIN-Archive werden von R13
nicht vorausgesetzt, weil R12/R11 schreibgeschützt geschachtelt enthalten sind.
