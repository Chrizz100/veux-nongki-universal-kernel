# VEUX 5.4.274 R20 R2 – source-pin hotfix, NOFLASH

Target: `Chrizz100/veux-nongki-universal-kernel` / `main`, parent snapshot `57288b194c7736ce26a91533c5c65eca3b07650c`. This R20 MAIN archive is **not** an AK3 ZIP, boot image, ready-to-flash kernel, or stock firmware. All files are for GitHub Actions diagnostics only.

R19 had four failing real object compilers. R17 compiled 12 individual objects but did **not** link an OEM-compatible kernel. R6/R9 showed large vendor-CRC incompatibilities. Do not confuse a green source compiler result with a working or flashable OEM build.

## Strategy

1. Pin R19 script, R19 `MAIN.zip`, earlier parent archives and both donor commits.
2. Replay original R19 foundations and R17 12-object tests without modifying their scripts or source archives.
3. In a separate donor Git worktree, reproduce exact R19 pinned core/pelt/vmscan stage. Then stage a source-coherent Qualcomm scheduler family: `core.c`, `fair.c`, `rt.c`, `features.h`, wake queue, and only the required WALT trace event, while keeping pinned R17 `include/linux/sched.h` untouched.
4. Preserve the genuine **3-argument SM6375 Android vendor hook** and its `allowed = false` / override logic, not a dummy argument. Restore the SM6375 vendor `vmscan.c` (instead of replacing the entire memory-management implementation) and introduce the genuine rwsem declaration for the lock API already used by that source.
5. Compile four new objects with real Clang 11.0.2, fail closed on any `make` error, missing output or detected compiler error. Recompile the 12 original R17 components under the modified headers. Only then try the exact R18 full-image link + ABI diagnostic. **No binary artifacts are uploaded.**

## Source provenance

* Qualcomm comparison: `shandongtlb/kernel_xiaomi_sm8350_M11`, immutable commit `01cb3a8824b7b4caf3e3540274e71abba5ade538` (5.4.61 lineage).
* SM6375 donor: `dereference23/kernel_xiaomi_sm6375`, immutable commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632` (trial 5.4.268 source history; not the entire stock 5.4.274 OEM tree).
* R19 parent archive: `VEUX_STOCK_54274_SOURCE_RECON_R19_MAIN.zip`, SHA-256 `ac894f380411d0df694688cb108daed98d7bcf3330262c051af09705b7b7fdaa`.
* R19 parent workflow Git blob: `bd8d4b47ecfa6779279d5ebc6e3bd3203777fca5`.
* Every source file read from either donor is verified against its exact upstream Git blob SHA-1. Every local R20 MAIN ZIP member is verified against its SHA-256 manifest. All original donor source trees must remain git clean.

## Limitations and failure policy

* An R20 candidate **may still fail** on additional vendor APIs; those failures must be preserved in unmodified logs, not suppressed with warning flags or fake success.
* Replacing experimental scheduler parts may omit donor changes (e.g. local CASS/custom scheduler changes). A compiler pass alone never qualifies for promotion; complete source and semantic review plus OEM ABI, device boot, and runtime gates remain mandatory.
* `stock_5_4_274_source_reproduced=false`, `flash_allowed=false`, `oem_abi_verified=false`, `boot_verified=false` are unconditional in this archive.
* Do not flash or distribute generated Image/boot.img until a separate OEM-approved build and device validation exists. No binaries, installers, private credentials, or repository writes in this workflow.

## R20 R2 change after real GitHub CI failure

The original R20 run [42173648750](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42173648750) passed the 33 offline tests and immutable R19/R17 foundation replay, then failed in the disposable stage with `('pair', 'mm/vmscan.c')` before any R20 compilation.

The staging code at `tools/r20_compat.py` checks the original R19 staged Qualcomm `mm/vmscan.c` against `sources[('pair','mm/vmscan.c')]`. The source was missing from `PAIR_SOURCE`, even though the original R19 probe actually stages it. R2 adds this already-verified, pinned Qualcomm Git blob (`d81fc723be0c1a127d4acb7079cad23a2ee0a543`) to `PAIR_SOURCE`, retaining the donor `mm/vmscan.c` blob for restoration. No kernel implementation, C code, compiler arguments or R19 parent assets were changed. Two new regression tests detect missing hardcoded stage pins and explicitly verify both vmscan blobs.

No claim of successful R20 compilation, kernel link, OEM ABI, device boot, or flash is made. Every flag remains `false` until independent real validation.


## R20 R3 (2026-11-06) -- targeted RT/fair compiler dependencies

Original R20 R2 run 42175004453: CORE and VMSCAN object PASS; RT and FAIR failed.
This experiment pins the exact original Qualcomm include/linux/interrupt.h and kernel/softirq.c *plus* donor equivalents and imports only upstream-sourced LONG_SOFTIRQ_MASK, active_softirqs per-CPU accounting, true scheduler load-balancing trace events, the complete original WALT trace event family, and the original CONFIG_SCHED_WALT sched_domain_shared.overutilized field.
Donor softirq dispatch is preserved; this IS NOT a full Qualcomm RT scheduler port.
New independent kernel/softirq.o true compiler target is REQUIRED, not assumed green.
Source guard, 5 true source object builds, R17 12 regressions and Image+dtbs/ABI diagnostics must all succeed to advance, but NO FLASH even then.

Expected initial source provenance:
* shandongtlb/kernel_xiaomi_sm8350_M11 01cb3a8824b7b4caf3e3540274e71abba5ade538
* dereference23/kernel_xiaomi_sm6375 b2b7a3bbc36d120ee523ebc8d68e0f13a97df632
* R20 R2 SHA256 338b6f4aedd5fbfb0b4e5559b3b4cc37cc73348532aeff8f5ccc50cc1bc031e6
