import unittest
from r20_replay import (EXPECTED_START, EXPECTED_BEFORE_TRIAL, EXPECTED_TRIAL,
                        EXPECTED_FULL, EXPECTED_LAST, git_blob_sha, parse_workflow)


def sample_workflow():
    labels=list(EXPECTED_START)
    labels.extend("verified original step " + str(i) for i in range(3,21))
    labels.extend([EXPECTED_BEFORE_TRIAL,EXPECTED_TRIAL,EXPECTED_FULL,EXPECTED_LAST])
    assert len(labels)==25
    out=[]
    for i,name in enumerate(labels):
        out.append("      - name: " + name + "\n")
        if i not in (0,24):
            out.extend(["        shell: bash\n", "        run: |\n",
                        "          set -euo pipefail\n", f"          echo R19_STEP_{i+1}\n"])
    return "".join(out).encode("utf-8")


class ReplayTests(unittest.TestCase):
    def test_01_valid_but_inert_fixture_parses(self):
        self.assertEqual(len(parse_workflow(sample_workflow())),25)
    def test_02_23_real_bash_blocks(self):
        self.assertEqual(sum(x['run'] is not None for x in parse_workflow(sample_workflow())),23)
    def test_03_copy_script_exact_line(self):
        self.assertIn('set -euo pipefail\necho R19_STEP_2',parse_workflow(sample_workflow())[1]['run'])
    def test_04_no_shell_step_at_first(self):
        self.assertIsNone(parse_workflow(sample_workflow())[0]['run'])
    def test_05_no_shell_step_at_last(self):
        self.assertIsNone(parse_workflow(sample_workflow())[-1]['run'])
    def test_06_last_foundation(self):
        self.assertEqual(parse_workflow(sample_workflow())[21]['name'],EXPECTED_BEFORE_TRIAL)
    def test_07_new_source_stage_is_not_original_replay(self):
        self.assertEqual(parse_workflow(sample_workflow())[22]['name'],EXPECTED_TRIAL)
    def test_08_full_link_exact(self):
        self.assertEqual(parse_workflow(sample_workflow())[23]['name'],EXPECTED_FULL)
    def test_09_reject_changed_order(self):
        with self.assertRaises(ValueError):parse_workflow(sample_workflow().replace(b'verified original step 3',b'NOPE_R20',1).replace(EXPECTED_FULL.encode(),b'ADULTERATED'))
    def test_10_reject_injected_expression(self):
        with self.assertRaises(ValueError):parse_workflow(sample_workflow().replace(b'echo R19_STEP_2',b'echo ${{ secrets.GITHUB_TOKEN }}'))
    def test_11_reject_missing_pipefail(self):
        with self.assertRaises(ValueError):parse_workflow(sample_workflow().replace(b'set -euo pipefail',b'set -eu',1))
    def test_12_reject_missing_section(self):
        with self.assertRaises(ValueError):parse_workflow(sample_workflow().replace(("      - name: "+EXPECTED_BEFORE_TRIAL+"\n").encode(), b'',1))
    def test_13_sha1_git_blob_header(self):
        self.assertEqual(git_blob_sha(b"test\n"), "9daeafb9864cf43055ae93beb0afd6c7d144bfa4")

if __name__=="__main__":unittest.main()
