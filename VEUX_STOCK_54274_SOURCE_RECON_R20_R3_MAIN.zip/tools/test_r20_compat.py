import unittest
from r20_compat import (PAIR_SOURCE, DONOR_SOURCE, TARGETS, R17_REGRESSION,
                        blob_sha, modify_vendor_hook, extract_pair_trace_event,
                        reconcile_vmscan, reconcile_interrupt_headers, reconcile_softirq, reconcile_full_trace, reconcile_scheduler_topology)

CORE = '''void set_user_nice(struct task_struct *p, long nice)
{
    bool queued, running;
    int old_prio, delta;
    struct rq_flags rf;
    struct rq *rq;

    if (task_nice(p) == nice || nice < MIN_NICE || nice > MAX_NICE)
        return;
    rq = task_rq_lock(p, &rf);
    update_rq_clock(rq);
    trace_android_rvh_set_user_nice(p, &nice);
    something_else();
}
'''
PAIR_TRACE = '''/*
 * Tracepoint for task enqueue/dequeue:
 */
TRACE_EVENT(sched_enq_deq_task,
TP_PROTO(struct task_struct *p, bool enqueue,
  unsigned int cpus_allowed),
TP_ARGS(p, enqueue, cpus_allowed),
TP_fast_assign(__entry->demand = task_load(p);
 __entry->pred_demand = task_pl(p);),
);

/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_TRACE = '''/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_VM = '''static LIST_HEAD(shrinker_list);
static DEFINE_SPINLOCK(shrinker_lock);
static DEFINE_RWLOCK(shrinker_rwlock);
static void foo(void) {
down_write(&shrinker_rwsem);
up_write(&shrinker_rwsem);
if (!down_read_trylock(&shrinker_rwsem)) return;
up_read(&shrinker_rwsem);
}
'''

class R20SourceTests(unittest.TestCase):
    def test_01_pinned_source_count(self):
        self.assertEqual(len(PAIR_SOURCE),11)
        self.assertEqual(len(DONOR_SOURCE),10)
    def test_02_blob_sha(self):
        self.assertEqual(blob_sha(b"test\n"),"9daeafb9864cf43055ae93beb0afd6c7d144bfa4")
    def test_03_four_real_object_targets(self):
        self.assertEqual(set(TARGETS), {"CORE","RT","FAIR","VMSCAN","SOFTIRQ"})
    def test_04_twelve_r17_distinct(self):
        self.assertEqual(len(R17_REGRESSION),12)
        self.assertEqual(len(set(R17_REGRESSION)),12)
    def test_05_vendor_hook_3args(self):
        x=modify_vendor_hook(CORE)
        self.assertIn("trace_android_rvh_set_user_nice(p, &nice, &allowed);",x)
        self.assertNotIn("trace_android_rvh_set_user_nice(p, &nice);",x)
    def test_06_vendor_hook_original_default_false(self):
        self.assertIn("allowed = false;",modify_vendor_hook(CORE))
    def test_07_vendor_hook_used_before_rejection(self):
        x=modify_vendor_hook(CORE)
        self.assertLess(x.index("trace_android_rvh_set_user_nice"),x.index("if ((task_nice"))
    def test_08_vendor_hook_preserves_override(self):
        self.assertIn("&& !allowed",modify_vendor_hook(CORE))
    def test_09_vendor_hook_rejects_bad_source(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("bool queued, running;", "bool queued;"))
    def test_10_vendor_hook_rejects_double_hook(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("something_else();", "trace_android_rvh_set_user_nice(p, &nice);"))
    def test_11_trace_integration_once(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertEqual(x.count("TRACE_EVENT(sched_enq_deq_task,"),1)
    def test_12_trace_retains_donor_wakeup(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertIn("DECLARE_EVENT_CLASS(sched_wakeup_template);",x)
    def test_13_trace_rejects_duplicate_event(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE+"\nTRACE_EVENT(sched_enq_deq_task,\n")
    def test_14_trace_requires_real_task_api(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE.replace("task_load(p)","zero(p)"),DONOR_TRACE)
    def test_15_donor_shrinker_lock(self):
        self.assertIn("static DECLARE_RWSEM(shrinker_rwsem);", reconcile_vmscan(DONOR_VM))
    def test_16_donor_shrinker_no_reset(self):
        x=reconcile_vmscan(DONOR_VM)
        self.assertIn("static DEFINE_SPINLOCK(shrinker_lock);",x)
        self.assertIn("static DEFINE_RWLOCK(shrinker_rwlock);",x)
    def test_17_donor_shrinker_reject_duplicate(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM+"\nstatic DECLARE_RWSEM(shrinker_rwsem);\n")
    def test_18_donor_shrinker_reject_removed_usage(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM.replace("up_read(&shrinker_rwsem)","up_read(&some_lock)"))
    def test_19_no_warning_bypass_flags_in_source(self):
        import inspect,r20_compat
        src=inspect.getsource(r20_compat)
        self.assertIn('"-j2"',src)
        self.assertIn('"LLVM=1"',src)
        self.assertIn('"flash_allowed": False',src)
    def test_20_unmodified_pin_bijection(self):
        self.assertIn("kernel/sched/core.c", PAIR_SOURCE)
        self.assertIn("mm/vmscan.c", DONOR_SOURCE)
        self.assertIn("mm/vmscan.c", PAIR_SOURCE)
        self.assertEqual(PAIR_SOURCE["mm/vmscan.c"], "d81fc723be0c1a127d4acb7079cad23a2ee0a543")

    def test_21_stage_all_constant_sources_are_pinned(self):
        """Catch the exact R20 KeyError before another GitHub run."""
        import ast, inspect, textwrap
        from r20_compat import stage
        tree=ast.parse(textwrap.dedent(inspect.getsource(stage)))
        keys=[]
        for node in ast.walk(tree):
            if not isinstance(node, ast.Subscript):
                continue
            if not (isinstance(node.value, ast.Name) and node.value.id == 'sources'):
                continue
            try:
                key=ast.literal_eval(node.slice)
            except (ValueError, TypeError, SyntaxError):
                continue  # Dynamic loop variables are handled by their own source list.
            if isinstance(key, tuple) and len(key)==2 and key[0] in {'pair','donor'}:
                keys.append(key)
        self.assertGreaterEqual(len(keys), 9)
        for origin, path in keys:
            self.assertIn(path, PAIR_SOURCE if origin=='pair' else DONOR_SOURCE,
                          f'Missing hard-coded source pin for {origin}:{path}')

    def test_22_vmscan_trial_matches_r19_original_provenance(self):
        self.assertEqual(PAIR_SOURCE['mm/vmscan.c'],
                         'd81fc723be0c1a127d4acb7079cad23a2ee0a543')
        self.assertEqual(DONOR_SOURCE['mm/vmscan.c'],
                         'fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa')


    def test_23_pinned_softirq_sources(self):
        self.assertEqual(PAIR_SOURCE['kernel/softirq.c'],'0ee55ec4f7a0fc065441295351970d4b3f047cf9')
        self.assertEqual(DONOR_SOURCE['kernel/softirq.c'],'7ff73dfad7c5f81b4a955569ce0725aa6c16317f')
    def test_24_pinned_interrupt_headers(self):
        self.assertEqual(PAIR_SOURCE['include/linux/interrupt.h'],'2ccad949658b86265730c12d4df28f933983c800')
        self.assertEqual(DONOR_SOURCE['include/linux/interrupt.h'],'01517747214a4d53b8df9d2db5e325064d6acce7')
    def test_25_softirq_original_mask(self):
        pair='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
/* Softirq's where the handling might be long: */
#define LONG_SOFTIRQ_MASK ((1 << NET_TX_SOFTIRQ) | (1 << NET_RX_SOFTIRQ) | \
    (1 << BLOCK_SOFTIRQ) | (1 << IRQ_POLL_SOFTIRQ) | (1 << TASKLET_SOFTIRQ))
/* map softirq index to softirq name. update 'softirq_to_name' by source */
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
DECLARE_PER_CPU(__u32, active_softirqs);
'''
        donor='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
'''
        x=reconcile_interrupt_headers(pair,donor)
        self.assertIn('LONG_SOFTIRQ_MASK',x)
        self.assertEqual(x.count('DECLARE_PER_CPU(__u32, active_softirqs);'),1)
    def test_26_softirq_mask_rejects_fake(self):
        pair='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
/* Softirq's where the handling might be long: */
#define LONG_SOFTIRQ_MASK (0)
/* map softirq index to softirq name. update 'softirq_to_name' */
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
DECLARE_PER_CPU(__u32, active_softirqs);
'''
        donor='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
'''
        with self.assertRaises(ValueError):reconcile_interrupt_headers(pair,donor)
    def test_27_softirq_instrumentation(self):
        pair='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
/* active_softirqs genuine Qualcomm */
DEFINE_PER_CPU(__u32, active_softirqs);
const char * const softirq_to_name[NR_SOFTIRQS] = {
__this_cpu_write(active_softirqs, pending);
__this_cpu_write(active_softirqs, 0);
'''
        donor='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
const char * const softirq_to_name[NR_SOFTIRQS] = {
set_softirq_pending(0);

    local_irq_enable();
if (__this_cpu_read(ksoftirqd) == current)
'''.replace('    local_irq_enable();','\tlocal_irq_enable();')
        x=reconcile_softirq(pair,donor)
        self.assertEqual(x.count('DEFINE_PER_CPU(__u32, active_softirqs);'),1)
        self.assertEqual(x.count('__this_cpu_write(active_softirqs, pending);'),1)
        self.assertEqual(x.count('__this_cpu_write(active_softirqs, 0);'),1)
        self.assertIn('set_softirq_pending(0);',x)
    def test_28_softirq_fails_closed_on_changed_dispatch(self):
        pair='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
DEFINE_PER_CPU(__u32, active_softirqs);
const char * const softirq_to_name[NR_SOFTIRQS] = {
__this_cpu_write(active_softirqs, pending);
__this_cpu_write(active_softirqs, 0);
'''
        donor='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
set_softirq_pending(1);
if (__this_cpu_read(ksoftirqd) == current)
'''
        with self.assertRaises(ValueError): reconcile_softirq(pair,donor)
    def test_29_trace_block_missing_rejected(self):
        with self.assertRaises(ValueError):reconcile_full_trace(PAIR_TRACE,DONOR_TRACE)
    def test_30_pinned_true_trace_not_mocked(self):
        import inspect, r20_compat
        s=inspect.getsource(r20_compat)
        for term in ('TRACE_EVENT(sched_cpu_util,','TRACE_EVENT(sched_load_balance_sg_stats,',
                     'TRACE_EVENT(sched_load_balance_stats,',
                     'TRACE_EVENT(sched_load_balance_nohz_kick,',
                     'trace_sched_cpu_util'):
            if term=='trace_sched_cpu_util': continue
            self.assertIn(term,s)
    def test_31_softirq_selected_as_required_fifth_target(self):
        self.assertEqual(TARGETS['SOFTIRQ'],'kernel/softirq.o')
    def test_32_source_constants_pinned_at_stage(self):
        import ast,inspect,textwrap
        import r20_compat
        tree=ast.parse(textwrap.dedent(inspect.getsource(r20_compat.stage)))
        keys=[]
        for node in ast.walk(tree):
            if not isinstance(node,ast.Subscript) or not isinstance(node.value,ast.Name) or node.value.id!='sources':continue
            try:k=ast.literal_eval(node.slice)
            except (ValueError,TypeError,SyntaxError):continue
            if isinstance(k,tuple) and len(k)==2 and k[0] in {'pair','donor'}:keys.append(k)
        self.assertGreaterEqual(len(keys),15)
        for label,path in keys:self.assertIn(path,PAIR_SOURCE if label=='pair' else DONOR_SOURCE)
    def test_33_sched_domain_shared_field_from_qualcomm(self):
        pair='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\n#ifdef CONFIG_SCHED_WALT\n\tbool            overutilized;\n#endif\n};'
        donor='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n};'
        x=reconcile_scheduler_topology(pair,donor)
        self.assertEqual(x.count('bool            overutilized;'),1)
    def test_34_sched_domain_shared_rejects_wrong_source(self):
        pair='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\n#ifdef CONFIG_SCHED_WALT\n\tbool            overutilized;\n#endif\n};'
        donor='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\nint unrelated;\n};'
        with self.assertRaises(ValueError):reconcile_scheduler_topology(pair,donor)
    def test_35_original_topology_git_blobs_pinned(self):
        self.assertEqual(PAIR_SOURCE['include/linux/sched/topology.h'],'ce91928f2df7fbfa46a64f1cb02e91100db73e03')
        self.assertEqual(DONOR_SOURCE['include/linux/sched/topology.h'],'509c0d1b9c0cbea9955064463c5a664b0d5c8c00')
    def test_36_full_qualcomm_walt_trace_family_import(self):
        # Fixture matching the original GitHub source event names and block guards.
        load='''/*
 * Tracepoint for load balancing:
 */
#ifdef CONFIG_SMP
TRACE_EVENT(sched_load_balance,
);
TRACE_EVENT(sched_load_balance_sg_stats,
);
TRACE_EVENT(sched_load_balance_stats,
);
TRACE_EVENT(sched_load_balance_nohz_kick,
);
#endif /* CONFIG_SMP */
'''
        walt='''#ifdef CONFIG_SCHED_WALT
TRACE_EVENT(sched_load_balance_skip_tasks,
);
TRACE_EVENT(sched_cpu_util,
);
TRACE_EVENT(sched_compute_energy,
);
TRACE_EVENT(sched_task_util,
);
TRACE_EVENT(sched_find_best_target,
);
TRACE_EVENT_CONDITION(sched_overutilized,
);
#endif /* CONFIG_SCHED_WALT */
'''
        pair=PAIR_TRACE + load + 'DECLARE_EVENT_CLASS(sched_process_template,\n' + walt + '#endif /* _TRACE_SCHED_H */'
        donor=DONOR_TRACE + 'DECLARE_EVENT_CLASS(sched_process_template,\n' + '#endif /* _TRACE_SCHED_H */'
        result=reconcile_full_trace(pair,donor)
        self.assertEqual(result.count('TRACE_EVENT(sched_cpu_util,'),1)
        self.assertEqual(result.count('TRACE_EVENT(sched_find_best_target,'),1)
        self.assertEqual(result.count('TRACE_EVENT_CONDITION(sched_overutilized,'),1)
        self.assertEqual(result.count('TRACE_EVENT(sched_load_balance_nohz_kick,'),1)
        self.assertIn('DECLARE_EVENT_CLASS(sched_wakeup_template);',result)
    def test_37_upstream_duplicate_walt_trace_rejected(self):
        pair=PAIR_TRACE + 'TRACE_EVENT(sched_cpu_util,\n' + 'TRACE_EVENT(sched_cpu_util,\n'
        with self.assertRaises(ValueError):reconcile_full_trace(pair,DONOR_TRACE)

if __name__=="__main__":unittest.main()
