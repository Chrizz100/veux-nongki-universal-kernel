#!/usr/bin/env python3
"""Replay ONLY exact R19 diagnostic run blocks on a disposable runner.

This is a CI helper, not a production-kernel patch or a success oracle.
The immutable Git blob check is mandatory before extracting any bash blocks.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

ORIGINAL_R19_GIT_BLOB = "bd8d4b47ecfa6779279d5ebc6e3bd3203777fca5"
R19_WORKFLOW = ".github/workflows/VEUX_STOCK_54274_SOURCE_RECON_R19_NOFLASH.yml"
EXPECTED_SOURCE_STEP_COUNT = 25
EXPECTED_RUN_BLOCKS = 23
EXPECTED_START = (
    "Checkout read-only exact workflow revision",
    "Validate R19 workflow using pinned actionlint",
    "R19 authenticate only uploaded MAIN, automatically restore genuine R18 parent and run 25 tests",
)
EXPECTED_BEFORE_TRIAL = "R17 publish exact twelve-unique-object results; verify no link/ABI/flash claims"
EXPECTED_TRIAL = "R19 stage genuine entire Qualcomm core pelt vmscan files and compile 4 affected objects before FULL link"
EXPECTED_FULL = "R18 compile full Image dtbs in isolated R17 worktree and calculate QGKI GKI ABI if successful"
EXPECTED_LAST = "Always upload R19 source compatibility and optional R18 full-build ABI reports, NEVER binary images"


def git_blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\x00" + data).hexdigest()


def parse_workflow(raw):
    """Deliberately strict parser for the pinned YAML subset: literal run blocks only."""
    lines = raw.decode("utf-8").splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if line.startswith("      - name: ")]
    sections = []
    for j, start in enumerate(starts):
        end = starts[j+1] if j+1 < len(starts) else len(lines)
        header = lines[start].strip().removeprefix("- name: ")
        body = lines[start+1:end]
        script = None
        for k, s in enumerate(body):
            if s.rstrip("\r\n") != "        run: |":
                continue
            if script is not None:
                raise ValueError("R20_DUPLICATE_LITERAL_RUN")
            code = []
            for row in body[k+1:]:
                if row.strip() and not row.startswith("          "):
                    break
                if row.strip():
                    code.append(row[10:])
                else:
                    code.append("\n")
            script = "".join(code).rstrip() + "\n"
            if not script.startswith("set -euo pipefail\n"):
                raise ValueError("R20_UNSAFE_SHELL_PREAMBLE:"+header)
            if "${{" in script:
                raise ValueError("R20_UNEXPANDED_GITHUB_EXPRESSION")
        sections.append({"name": header, "run": script})
    labels = [s["name"] for s in sections]
    if not (len(sections) == EXPECTED_SOURCE_STEP_COUNT and
            sum(s["run"] is not None for s in sections) == EXPECTED_RUN_BLOCKS and
            tuple(labels[:3]) == EXPECTED_START and
            labels[21] == EXPECTED_BEFORE_TRIAL and
            labels[22] == EXPECTED_TRIAL and
            labels[23] == EXPECTED_FULL and labels[24] == EXPECTED_LAST):
        raise ValueError("R20_PINNED_STEP_LIST_OR_ORDER_CHANGED")
    if any(s["run"] is None for s in sections[1:24]):
        raise ValueError("R20_MISSING_RUN_SCRIPT")
    return sections


def read_exact_r19(path, workspace):
    path = Path(path).resolve()
    workspace = Path(workspace).resolve()
    if path != workspace / R19_WORKFLOW:
        raise ValueError("R20_R19_FILE_OUTSIDE_CHECKED_OUT_WORKSPACE")
    raw = path.read_bytes()
    if git_blob_sha(raw) != ORIGINAL_R19_GIT_BLOB:
        raise ValueError("R20_R19_WORKFLOW_GIT_BLOB_CHANGED")
    return parse_workflow(raw)


def execute(script, log_path, workspace, timeout):
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    with tempfile.TemporaryDirectory(prefix="veux-r20-shell-") as tmp:
        runner_script = Path(tmp) / "exact_r19_step.sh"
        runner_script.write_text(script, encoding="utf8")
        with open(log_path, "wb") as out:
            try:
                p = subprocess.run(
                    ["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", str(runner_script)],
                    cwd=workspace, env=env, stdout=out, stderr=subprocess.STDOUT,
                    check=False, timeout=timeout)
                return p.returncode
            except subprocess.TimeoutExpired:
                out.write(b"\nR20_REPLAY_TIMEOUT\n")
                return 124


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--workflow", required=True)
    p.add_argument("--workspace", required=True)
    p.add_argument("--reports", required=True)
    p.add_argument("--phase", choices=("foundations", "full"), required=True)
    args = p.parse_args()
    reports = Path(args.reports).resolve()
    reports.mkdir(parents=True, exist_ok=True)
    try:
        steps = read_exact_r19(args.workflow, args.workspace)
        indices = range(1, 22) if args.phase == "foundations" else (23,)
        report = {"schema": "VEUX_R20_PINNED_R19_REPLAY", "phase": args.phase,
                  "r19_workflow_git_blob": ORIGINAL_R19_GIT_BLOB,
                  "flash_allowed": False, "boot_verified": False,
                  "production_tree_modified": False, "steps": []}
        out_path = reports / ("R20_FOUNDATIONS.json" if args.phase == "foundations" else "R20_FULL_LINK_EXECUTION.json")
        for idx in indices:
            item = steps[idx]
            log = reports / f"R20_{args.phase.upper()}_{idx+1:02d}.log"
            # R19's full link has timeout=3600s; other R19 stages use <= 30 min.
            limit = 4200 if args.phase == "full" else 2400
            rc = execute(item["run"], log, args.workspace, timeout=limit)
            entry = {"index": idx+1, "name": item["name"], "rc": rc,
                     "log": log.name, "log_sha256": hashlib.sha256(log.read_bytes()).hexdigest()}
            report["steps"].append(entry)
            out_path.write_text(json.dumps(report, indent=2, ensure_ascii=False)+"\n")
            print(f"R20_{args.phase.upper()}_STEP_{idx+1:02d}_RC={rc}; {item['name']}", flush=True)
            if rc:
                print("\n===== FAILURE LOG TAIL =====", flush=True)
                print("\n".join(log.read_text(errors="replace").splitlines()[-85:]), flush=True)
                raise RuntimeError(f"R20_PINNED_R19_REPLAY_STEP_FAILED:{idx+1}:{rc}")
        print(f"R20_{args.phase.upper()}_REPLAY_PASS; NOT A FLASH/ABI APPROVAL")
    except Exception as ex:
        print(f"::error::{ex}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
