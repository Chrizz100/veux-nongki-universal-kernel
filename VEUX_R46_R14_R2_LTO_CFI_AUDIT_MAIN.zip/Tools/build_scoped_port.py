from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil

ROOT = Path(__file__).resolve().parents[1]
out = ROOT / 'Candidate_R14'
if out.exists():
    shutil.rmtree(out)
shutil.copytree(ROOT / 'Original_R13', out)
stock = ROOT / 'StockReference'

# Restore the original OEM registration surface, with bounded strings and
# complete error/unload cleanup where the published driver had correctness bugs.
driver = (stock / 'drivers/misc/hardware_info.c').read_text()
items = '''static const char * const hardwareinfo_items[HARDWARE_MAX_ITEM] = {
    [HARDWARE_LCD] = "LCD", [HARDWARE_TP] = "TP", [HARDWARE_FLASH] = "MEMORY",
    [HARDWARE_FRONT_CAM] = "CAM_FRONT", [HARDWARE_BACK_CAM] = "CAM_BACK",
    [HARDWARE_BACK_WIDE_CAM] = "CAM_WIDE", [HARDWARE_BACK_SUBCAM] = "CAM_SUB",
    [HARDWARE_BACK_MACRO_CAM] = "CAM_MACRO", [HARDWARE_BT] = "BT",
    [HARDWARE_WIFI] = "WIFI", [HARDWARE_ACCELEROMETER] = "GSENSOR",
    [HARDWARE_ALSPS] = "PLSENSOR", [HARDWARE_GYROSCOPE] = "GYROSENSOR",
    [HARDWARE_MAGNETOMETER] = "MSENSOR", [HARDWARE_SAR] = "SAR",
    [HARDWARE_GPS] = "GPS", [HARDWARE_FM] = "FM", [HARDWARE_NFC] = "NFC",
    [HARDWARE_SMARTPA] = "SMARTPA", [HARDWARE_BATTERY_ID] = "BATTERY",
    [HARDWARE_BACK_CAM_MOUDULE_ID] = "CAM_BACK_MODULE",
    [HARDWARE_BACK_WIDE_CAM_MOUDULE_ID] = "CAM_WIDE_MODULE",
    [HARDWARE_BACK_SUBCAM_MODULEID] = "CAM_SUB_MODULE",
    [HARDWARE_FRONT_CAM_MOUDULE_ID] = "CAM_FRONT_MODULE",
    [HARDWARE_BACK_MACRO_CAM_MOUDULE_ID] = "CAM_MACRO_MODULE",
    [HARDWARE_BOARD_ID] = "BOARD_ID", [HARDWARE_HARDWARE_ID] = "HARDWARE_ID",
    [HARDWARE_CHARGER_IC] = "CHARGER_IC", [HARDWARE_BMS_GAUGE] = "BMS_GAUGE",
    [HARDWARE_SUB_CHARGER_MASTER] = "SUB_CHARGER_MASTER",
    [HARDWARE_SUB_CHARGER_SLAVE] = "SUB_CHARGER_SLAVE",
    [HARDWARE_USB_PD] = "USB_PD",
};'''
driver, count = re.subn(r'char\* hardwareinfo_items\[HARDWARE_MAX_ITEM\] =\s*\{.*?\};',
                         items, driver, count=1, flags=re.S)
assert count == 1
driver = driver.replace('if(cmd < 0 || cmd >= HARDWARE_MAX_ITEM)',
                        'if(!name || cmd < 0 || cmd >= HARDWARE_MAX_ITEM)', 1)
driver = driver.replace('strcpy(hardwareinfo_name[cmd], name);',
                        'strscpy(hardwareinfo_name[cmd], name, HARDWARE_MAX_ITEM_LONGTH);', 1)
driver = driver.replace('//char info[HARDWARE_MAX_ITEM_LONGTH];',
                        'char info[HARDWARE_MAX_ITEM_LONGTH];', 1)
for enum in ('HARDWARE_BACK_CAM_MOUDULE_ID', 'HARDWARE_FRONT_CAM_MOUDULE_ID'):
    pattern = (r'if\(copy_from_user\(hardwareinfo_name\[' + enum
               + r'\], data,sizeof\(data\)\)\)\s*\{.*?\}\s*goto set_ok;')
    replacement = '''if (copy_from_user(info, data, sizeof(info))) {
                        ret = -EFAULT;
                } else {
                        info[sizeof(info) - 1] = '\\0';
                        ret = hardwareinfo_set_prop(ENUM, info);
                }
                goto set_ok;'''.replace('ENUM', enum)
    driver, count = re.subn(pattern, lambda _: replacement, driver, count=1, flags=re.S)
    assert count == 1, enum
driver = driver.replace('strlen(hardwareinfo_name[hardwareinfo_num])))',
                        'strnlen(hardwareinfo_name[hardwareinfo_num], HARDWARE_MAX_ITEM_LONGTH - 1) + 1))', 1)
start = driver.index('static ssize_t show_boardinfo(')
stop = driver.index('static DEVICE_ATTR(boardinfo', start)
show = '''static ssize_t show_boardinfo(struct device *dev, struct device_attribute *attr, char *buf)
{
        int i;
        size_t len = 0;

        for (i = 0; i < HARDWARE_MAX_ITEM && len < PAGE_SIZE; i++) {
                const char *value = hardwareinfo_name[i];

                if (i == HARDWARE_LCD)
                        value = Lcm_name;
                else if (i == HARDWARE_BT || i == HARDWARE_WIFI ||
                         i == HARDWARE_GPS || i == HARDWARE_FM)
                        value = "Qualcomm";

                len += scnprintf(buf + len, PAGE_SIZE - len, "%s : %.*s\\n",
                                 hardwareinfo_items[i], HARDWARE_MAX_ITEM_LONGTH, value);
        }
        return len;
}
'''
driver = driver[:start] + show + driver[stop:]
driver = driver.replace('''if(ret < 0){
                return -ENODEV;
        }''', '''if(ret < 0){
                return ret;
        }''', 1)
driver = driver.replace('''if(ret != 0)
        {
                return -ENODEV;
        }''', '''if(ret != 0)
        {
                misc_deregister(&hardwareinfo_device);
                return ret;
        }''', 1)
driver = driver.replace('''static void __exit hardwareinfo_exit_module(void)
{
        misc_deregister''', '''static void __exit hardwareinfo_exit_module(void)
{
        platform_driver_unregister(&boardinfo_driver);
        misc_deregister''', 1)
(out / 'drivers/misc/hardware_info.c').write_text(driver)
(out / 'include/linux').mkdir(exist_ok=True)
shutil.copyfile(stock / 'include/linux/hardware_info.h', out / 'include/linux/hardware_info.h')

kconfig = out / 'drivers/misc/Kconfig'
text = kconfig.read_text()
marker = 'source "drivers/misc/c2port/Kconfig"'
assert text.count(marker) == 1
block = '''config HARDWARE_INFO
\ttristate "show hardware info"
\tdefault n
\thelp
\t  This adds support for hardware info.

'''
kconfig.write_text(text.replace(marker, block + marker, 1))
makefile = out / 'drivers/misc/Makefile'
makefile.write_text(makefile.read_text() + 'obj-$(CONFIG_HARDWARE_INFO) += hardware_info.o\n')

soc = out / 'sound/soc/soc-core.c'
text = soc.read_text()
text = text.replace('#include <sound/initval.h>',
                    '#include <sound/initval.h>\n#include <linux/hardware_info.h>', 1)
text = text.replace('static enum smartpa_type smartpa_type = PA_INVALID;',
                    'int smartpa_type = PA_INVALID;\nEXPORT_SYMBOL(smartpa_type);', 1)
text = text.replace('module_param(smartpa_type, int, S_IRUSR | S_IRGRP | S_IROTH);',
                    'module_param(smartpa_type, int, 0664);', 1)
start = text.index('void snd_soc_set_smartpa_type(')
stop = text.index('EXPORT_SYMBOL_GPL(snd_soc_set_smartpa_type);', start)
stock_soc = (stock / 'sound/soc/soc-core.c').read_text()
stock_start = stock_soc.index('int snd_soc_set_smartpa_type(')
stock_stop = stock_soc.index('EXPORT_SYMBOL_GPL(snd_soc_set_smartpa_type);', stock_start)
setter = stock_soc[stock_start:stock_stop]
# Preserve the exact OEM int(int) interface and complete state/reporting behavior.
# IS_REACHABLE also permits the original tristate driver in other configurations.
setter = setter.replace('#ifdef CONFIG_WT_QGKI', '#if IS_REACHABLE(CONFIG_HARDWARE_INFO)')
text = text[:start] + setter + text[stop:]
soc.write_text(text)
header = out / 'include/sound/soc.h'
text = header.read_text()
old = 'void snd_soc_set_smartpa_type(const char *name, enum smartpa_type pa_type);'
new = 'int snd_soc_set_smartpa_type(const char *name, int pa_type);'
assert text.count(old) == 1
header.write_text(text.replace(old, new, 1))

# Keep the published references byte-exact, but make added kernel files pass
# git's strict whitespace checks without changing any C tokens.
for name in ('drivers/misc/hardware_info.c', 'include/linux/hardware_info.h'):
    path = out / name
    path.write_text('\n'.join(line.rstrip() for line in path.read_text().splitlines()).rstrip() + '\n')

names = ['drivers/misc/Kconfig', 'drivers/misc/Makefile', 'drivers/misc/hardware_info.c',
         'include/linux/hardware_info.h', 'sound/soc/soc-core.c', 'include/sound/soc.h']
patches = []
pins = {}
for name in names:
    before_path = ROOT / 'Original_R13' / name
    before = before_path.read_bytes() if before_path.exists() else None
    after = (out / name).read_bytes()
    patches.extend(difflib.unified_diff((before or b'').decode().splitlines(keepends=True),
                                      after.decode().splitlines(keepends=True),
                                      fromfile='a/' + name if before is not None else '/dev/null',
                                      tofile='b/' + name))
    pins[name] = {'before_sha256': hashlib.sha256(before).hexdigest() if before is not None else None,
                  'after_sha256': hashlib.sha256(after).hexdigest()}
(ROOT / 'References').mkdir(exist_ok=True)
(ROOT / 'References/RESTORE_OEM_HARDWARE_SMARTPA.patch').write_text(''.join(patches))
(ROOT / 'References/FILE_PINS.json').write_text(json.dumps(pins, indent=2) + '\n')
print(json.dumps({'changed_files': len(names), 'pins': pins}, indent=2))
