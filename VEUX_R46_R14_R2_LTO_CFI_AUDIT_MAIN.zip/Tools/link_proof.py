"""Verify genuine ELF exports and the actual LTO/CFI device-initcall target."""
import mmap
from pathlib import Path
import re
import struct


def require(condition, message):
    if not condition:
        raise ValueError(message)


class ELF64:
    def __init__(self, path):
        path = Path(path)
        require(path.is_file(), 'ELF_KERNEL_REQUIRED')
        self.file = path.open('rb')
        self.data = mmap.mmap(self.file.fileno(), 0, access=mmap.ACCESS_READ)
        try:
            self._parse()
        except Exception:
            self.close()
            raise

    def _parse(self):
        data = self.data
        require(len(data) >= 64 and data[:6] == b'\x7fELF\x02\x01', 'NOT_ELF64_LITTLE_ENDIAN')
        header = struct.unpack_from('<16sHHIQQQIHHHHHH', data, 0)
        # Relocatable/KASLR kernels are linked ET_DYN; reject unlinked ET_REL.
        require(header[1] in (2, 3) and header[2] == 183, 'NOT_LINKED_AARCH64_KERNEL')
        offset, width, count, strings_index = header[6], header[11], header[12], header[13]
        require(width == 64 and 0 < count < 65535 and offset + width * count <= len(data),
                'BAD_ELF_SECTION_TABLE')
        require(0 < strings_index < count, 'BAD_SECTION_STRING_TABLE')
        self.sections = [struct.unpack_from('<IIQQQQIIQQ', data, offset + i * width) for i in range(count)]
        names = self.sections[strings_index]
        require(names[4] + names[5] <= len(data), 'BAD_SECTION_NAMES')
        section_strings = data[names[4]:names[4] + names[5]]
        self.section_names = [self._string(section_strings, s[0]) for s in self.sections]
        tables = [s for s in self.sections if s[1] == 2]
        require(len(tables) == 1, 'ORIGINAL_ELF_SYMBOL_TABLE_REQUIRED')
        table = tables[0]
        require(table[9] == 24 and table[5] % 24 == 0 and table[4] + table[5] <= len(data)
                and 0 <= table[6] < count, 'BAD_ELF_SYMBOL_TABLE')
        strings = self.sections[table[6]]
        require(strings[4] + strings[5] <= len(data), 'BAD_ELF_SYMBOL_STRINGS')
        text = data[strings[4]:strings[4] + strings[5]]
        self.symbols = []
        for off in range(table[4], table[4] + table[5], 24):
            name, info, _, index, value, size = struct.unpack_from('<IBBHQQ', data, off)
            if not name:
                continue
            self.symbols.append({'name': self._string(text, name), 'binding': info >> 4,
                                 'type': info & 15, 'section_index': index,
                                 'value': value, 'size': size})

    @staticmethod
    def _string(table, offset):
        require(0 <= offset < len(table), 'BAD_ELF_STRING_OFFSET')
        end = table.find(b'\0', offset)
        require(end >= offset, 'UNTERMINATED_ELF_STRING')
        return table[offset:end].decode('utf-8', errors='strict')

    def section_name(self, symbol):
        index = symbol['section_index']
        require(0 < index < len(self.sections), 'SYMBOL_HAS_NO_REAL_SECTION')
        return self.section_names[index]

    def read(self, address, count):
        require(0 < count <= 16, 'UNBOUNDED_ELF_READ')
        for section in self.sections:
            _, kind, flags, start, offset, size, *_ = section
            if kind != 8 and flags & 2 and start <= address and address + count <= start + size:
                at = offset + address - start
                require(at + count <= len(self.data), 'ELF_READ_OUTSIDE_FILE')
                return self.data[at:at + count]
        raise ValueError('CALLBACK_ADDRESS_NOT_IN_FILE_BACKED_KERNEL_SECTION')

    def close(self):
        self.data.close()
        self.file.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def one(items, message):
    items = list(items)
    require(len(items) == 1, message)
    return items[0]


def prove_from_view(elf, system_map_text):
    maps = {}
    for line in system_map_text.splitlines():
        fields = line.split()
        if len(fields) == 3:
            maps.setdefault(fields[2], []).append((int(fields[0], 16), fields[1]))
    symbols = elf.symbols

    def in_map(symbol, kinds):
        require(any(value == symbol['value'] and kind in kinds
                    for value, kind in maps.get(symbol['name'], [])),
                'ELF_SYSTEM_MAP_DISAGREE:' + symbol['name'])

    definitions = {}
    for name, kind in (('hardwareinfo_set_prop', 2), ('snd_soc_set_smartpa_type', 2), ('smartpa_type', 1)):
        symbol = one((s for s in symbols if s['name'] == name and s['binding'] in (1, 2)
                      and s['type'] == kind and s['size'] > 0), 'REAL_PUBLIC_OEM_DEFINITION_MISSING:' + name)
        in_map(symbol, 'Tt' if kind == 2 else 'DdBb')
        section = elf.section_name(symbol)
        require(section.startswith('.text') if kind == 2 else section.startswith(('.data', '.bss')),
                'PUBLIC_OEM_SYMBOL_IN_WRONG_SECTION:' + name)
        if name == 'smartpa_type':
            require(symbol['size'] == 4, 'SMARTPA_STATE_NOT_ORIGINAL_INT_WIDTH')
        export = one((s for s in symbols if s['name'] == '__ksymtab_' + name),
                     'REAL_OEM_EXPORT_TABLE_MISSING:' + name)
        require(elf.section_name(export).startswith('__ksymtab'), 'EXPORT_TABLE_OUTSIDE_KSYMTAB')
        in_map(export, 'rRdD')
        definitions[name] = {'address': hex(symbol['value']), 'binding': symbol['binding'],
                             'size': symbol['size'], 'section': section}

    family = re.compile(r'hardwareinfo_init_module(?:\$[0-9a-fA-F]{32}|\.llvm\.[0-9]+)?\Z')
    body = one((s for s in symbols if family.fullmatch(s['name']) and s['type'] == 2 and s['size'] > 0),
               'REAL_HARDWARE_INFO_INIT_BODY_MISSING_OR_DUPLICATE')
    require(elf.section_name(body).startswith('.init.text'), 'DRIVER_INIT_BODY_NOT_IN_INIT_TEXT')
    in_map(body, 'tT')
    entry = one((s for s in symbols if s['name'].startswith('__initcall_')
                 and s['name'].endswith('hardwareinfo_init_module6') and s['type'] == 1),
                'HARDWARE_INFO_INITCALL_MISSING_OR_DUPLICATE')
    in_map(entry, 'dDrR')
    start = one((s for s in symbols if s['name'] == '__initcall6_start'), 'INITCALL6_START_MISSING')
    stop = one((s for s in symbols if s['name'] == '__initcall7_start'), 'INITCALL7_START_MISSING')
    require(entry['size'] in (4, 8) and start['value'] <= entry['value']
            and entry['value'] + entry['size'] <= stop['value'], 'OEM_INITCALL_OUTSIDE_DEVICE_INIT_RANGE')
    raw = elf.read(entry['value'], entry['size'])
    if entry['size'] == 8:
        target = int.from_bytes(raw, 'little')
        encoding = 'absolute64'
    else:
        target = (entry['value'] + int.from_bytes(raw, 'little', signed=True)) & ((1 << 64) - 1)
        encoding = 'prel32'
    route = 'direct'
    jump = None
    branch_word = None
    if target != body['value']:
        jump = one((s for s in symbols if s['name'] == body['name'] + '.cfi_jt'
                    and s['type'] == 2 and s['value'] == target), 'INITCALL_TARGET_NOT_REAL_INIT_OR_CFI_ENTRY')
        in_map(jump, 'tT')
        require(elf.section_name(jump).startswith('.text'), 'CFI_ENTRY_NOT_IN_TEXT')
        branch_word = int.from_bytes(elf.read(target, 4), 'little')
        require(branch_word & 0xfc000000 == 0x14000000, 'CFI_ENTRY_NOT_AARCH64_UNCONDITIONAL_BRANCH')
        immediate = branch_word & 0x03ffffff
        if immediate & (1 << 25):
            immediate -= 1 << 26
        require((target + immediate * 4) & ((1 << 64) - 1) == body['value'],
                'CFI_ENTRY_BRANCHES_TO_WRONG_FUNCTION')
        route = 'cfi_jump_table_branch'
    return {'proof': 'ELF_PUBLIC_EXPORTS_AND_REAL_DEVICE_INITCALL_TARGET_VERIFIED',
            'definitions': definitions, 'device_initcall': entry['name'],
            'initcall_address': hex(entry['value']), 'entry_encoding': encoding,
            'initcall_target': hex(target), 'route': route,
            'init_function': body['name'], 'init_function_address': hex(body['value']),
            'cfi_entry': jump['name'] if jump else None,
            'cfi_branch_instruction': hex(branch_word) if branch_word is not None else None}


def prove_oem(vmlinux, system_map):
    with ELF64(vmlinux) as elf:
        return prove_from_view(elf, Path(system_map).read_text())
