#!/usr/bin/env python3
"""Reproduce genuine R13 controls, then compile the complete R14 ARM64 units."""
import argparse
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

import restore_oem as repair


def run(command, **kwargs):
    result = subprocess.run(command, capture_output=True, text=True, **kwargs)
    repair.require(result.returncode == 0, 'COMMAND_FAILED:' + repr(command) + '\n' + result.stderr[-4000:])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--clang', required=True)
    parser.add_argument('--work-dir', required=True)
    args = parser.parse_args()
    repair.verify_package()
    r13, _, _ = repair.dependency()
    clang = Path(args.clang).resolve(strict=True)
    repair.require(repair.sha(clang) ==
                   'b2ce016755bddbab76549895bca07b1dc8d14a3e315b8b3567097fef04eadae1',
                   'WRONG_ANDROID_CLANG_BINARY')
    work = Path(args.work_dir).resolve()
    repair.require(not work.exists(), 'WORK_DIRECTORY_MUST_BE_NEW')
    headers = work / 'include-tree'
    headers.mkdir(parents=True)
    with tarfile.open(repair.ROOT / 'References/R13_COMPILED_HEADERS.tar.xz') as archive:
        archive.extractall(headers, filter='data')
    with tarfile.open(r13.ROOT / 'References/R12_COMPILED_HEADER_CAPSULE.tar.xz') as archive:
        members = [m for m in archive.getmembers() if m.name.startswith('genksyms/')
                   or m.name in ('module.c', 'module-internal.h')]
        archive.extractall(work, members=members, filter='data')
    gen = work / 'genksyms'
    run(['cc', '-O2', '-I' + str(gen), str(gen / 'genksyms.c'),
         str(gen / 'parse.tab.c'), str(gen / 'lex.lex.c'), '-o', str(gen / 'genksyms')])
    include = run(['cc', '-print-file-name=include']).stdout.strip()
    common = [str(clang), '--target=aarch64-linux-gnu', '-D__KERNEL__', '-nostdinc', '-isystem', include]
    for name in ('arch/arm64/include', 'arch/arm64/include/generated', 'include',
                 'arch/arm64/include/uapi', 'arch/arm64/include/generated/uapi',
                 'include/uapi', 'include/generated/uapi'):
        common.append('-I' + str(headers / name))
    common += ['-include', str(headers / 'include/linux/kconfig.h')]

    def probe(source, label):
        output = run(common + ['-E', '-D__GENKSYMS__', str(source)]).stdout
        result = run([str(gen / 'genksyms'), '-T', str(work / (label + '.symtypes'))], input=output)
        (work / (label + '.ver')).write_text(result.stdout)
        return {name: '0x' + crc.lower().zfill(8)
                for name, crc in re.findall(r'__crc_(\w+) = 0x([0-9a-fA-F]+);', result.stdout)}

    expected_r13 = {}
    for line in (repair.ROOT / 'References/R13_Module.symvers').read_text().splitlines():
        f = line.split()
        expected_r13[f[1]] = f[0].lower()
    original_header = (repair.ROOT / 'Original_R13/include/sound/soc.h').read_text()
    compiled_header = (headers / 'include/sound/soc.h').read_text()
    clean = lambda text: re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '', text, flags=re.S))
    repair.require(clean(original_header) == clean(compiled_header), 'SOC_HEADER_BASELINE_CHANGED')
    baseline = probe(repair.ROOT / 'Original_R13/sound/soc/soc-core.c', 'r13-soc')
    bad = {n: [crc, expected_r13.get(n)] for n, crc in baseline.items() if expected_r13.get(n) != crc}
    repair.require(len(baseline) == 43 and not bad, 'REAL_R13_EXPORTS_NOT_REPRODUCED:' + repr(bad))
    before_layout = probe(work / 'module.c', 'r13-module')['module_layout']
    repair.require(before_layout == '0x71c13c49', 'REAL_R13_MODULE_LAYOUT_NOT_REPRODUCED')
    print('43 genuine R13 ASoC export CRCs and module_layout reproduced', flush=True)

    for name in ('include/sound/soc.h', 'include/linux/hardware_info.h'):
        shutil.copyfile(repair.ROOT / 'Candidate_R14' / name, headers / name)
    auto = headers / 'include/generated/autoconf.h'
    text = auto.read_text()
    repair.require('CONFIG_HARDWARE_INFO' not in text, 'R13_HARDWARE_INFO_ALREADY_CONFIGURED')
    auto.write_text(text + '\n#define CONFIG_HARDWARE_INFO 1\n')
    actual = {}
    for name in ('sound/soc/soc-core.c', 'drivers/misc/hardware_info.c'):
        label = Path(name).stem
        source = repair.ROOT / 'Candidate_R14' / name
        actual.update(probe(source, label))
        module = 'snd_soc_core' if label == 'soc-core' else 'hardware_info'
        command = common + ['-O2', '-mgeneral-regs-only', '-fno-pic', '-fno-stack-protector',
                            '-Werror=implicit-function-declaration', '-Werror=incompatible-pointer-types',
                            '-Werror=return-type', '-Wno-unused-value', '-Wno-pointer-sign',
                            '-Wno-gnu-variable-sized-type-not-at-end', '-Wno-address-of-packed-member',
                            '-DKBUILD_MODNAME="' + module + '"',
                            '-DKBUILD_BASENAME="' + label.replace('-', '_') + '"',
                            '-c', str(source), '-o', str(work / (label + '.o'))]
        result = run(command)
        (work / (label + '-compile.log')).write_text(result.stdout + result.stderr)
        (work / (label + '-compile-command.json')).write_text(json.dumps(command, indent=2) + '\n')
    repair.require(all(actual.get(n) == crc for n, crc in repair.EXPECTED.items()),
                   'OEM_INTERFACES_DO_NOT_MATCH_STOCK')
    changed = {n: [crc, actual.get(n)] for n, crc in baseline.items() if actual.get(n) != crc}
    repair.require(changed == {'snd_soc_set_smartpa_type': ['0xde9e3baf', '0x777f6815']},
                   'UNEXPECTED_ASOC_EXPORT_CHANGE:' + repr(changed))
    after_layout = probe(work / 'module.c', 'r14-module')['module_layout']
    repair.require(after_layout == before_layout, 'UNEXPECTED_MODULE_LAYOUT_CHANGE')
    result = {'status': 'TWO_COMPLETE_ARM64_UNITS_COMPILED_AND_THREE_OEM_STOCK_CRCS_MATCH',
              'baseline_asoc_exports_verified_against_real_r13': 43,
              'repaired_interfaces': repair.EXPECTED, 'changed_existing_asoc_exports': changed,
              'module_layout_unchanged': after_layout,
              'full_r14_kernel_built': False, 'device_boot_tested': False, 'flash_allowed': False}
    repair.write_json(work / 'LOCAL_OEM_ABI_PROOF.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
