#!/usr/bin/env python3
"""Read one pinned GitHub Actions artifact; never forward its API credential."""
import argparse
import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.parse
import urllib.request

from audit_existing import ARCHIVE_SHA, ARCHIVE_SIZE, ARTIFACT_ID, COMMIT, RUN_ID
from restore_oem import require, sha

BASE = 'https://api.github.com/repos/Chrizz100/veux-nongki-universal-kernel/actions/artifacts/' + str(ARTIFACT_ID)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, new_url):
        return None


def fetch(destination):
    destination = Path(destination).resolve()
    require(not destination.exists(), 'DOWNLOAD_DESTINATION_MUST_BE_NEW')
    token = os.environ.get('GITHUB_TOKEN')
    require(bool(token), 'READ_ONLY_GITHUB_ACTIONS_TOKEN_REQUIRED')
    headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json',
               'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'VEUX-R14-R2-artifact-audit'}
    opener = urllib.request.build_opener(NoRedirect())
    with opener.open(urllib.request.Request(BASE, headers=headers), timeout=60) as stream:
        metadata = json.load(stream)
    require(metadata['id'] == ARTIFACT_ID and metadata['workflow_run']['id'] == RUN_ID
            and metadata['workflow_run']['head_sha'] == COMMIT
            and metadata['size_in_bytes'] == ARCHIVE_SIZE and not metadata['expired']
            and metadata['digest'] == 'sha256:' + ARCHIVE_SHA,
            'GITHUB_ARTIFACT_IDENTITY_CHANGED_OR_EXPIRED')
    require(metadata['name'] == 'VEUX-R46-R14-OEM-EXPORT-REPAIR-NOFLASH-43278002694',
            'WRONG_GITHUB_ARTIFACT_NAME')
    try:
        opener.open(urllib.request.Request(BASE + '/zip', headers=headers), timeout=60)
    except urllib.error.HTTPError as response:
        require(response.code in (302, 303, 307), 'ARTIFACT_REDIRECT_NOT_RETURNED')
        location = response.headers.get('Location', '')
    else:
        raise ValueError('ARTIFACT_REDIRECT_NOT_RETURNED')
    parsed = urllib.parse.urlparse(location)
    require(parsed.scheme == 'https' and parsed.hostname and not parsed.username and not parsed.password,
            'UNSAFE_ARTIFACT_TRANSFER_LOCATION')
    # A new request intentionally has no Authorization header. The token is
    # scoped only to the fixed api.github.com URL above, including on redirects.
    temporary = destination.with_name(destination.name + '.partial')
    destination.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(urllib.request.Request(location), timeout=90) as incoming, temporary.open('wb') as out:
                while True:
                    block = incoming.read(1024 * 1024)
                    if not block:
                        break
                    out.write(block)
            require(temporary.stat().st_size == ARCHIVE_SIZE and sha(temporary) == ARCHIVE_SHA,
                    'DOWNLOADED_ARTIFACT_DIGEST_MISMATCH')
            temporary.rename(destination)
            print('PINNED_ORIGINAL_R14_ARTIFACT_DOWNLOADED_AND_SHA256_VERIFIED')
            return
        except Exception:
            temporary.unlink(missing_ok=True)
            if attempt == 2:
                raise RuntimeError('PINNED_ARTIFACT_TRANSFER_FAILED') from None
            time.sleep(attempt + 1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    fetch(parser.parse_args().output)
