#!/usr/bin/env python3
"""Validate the already built R14 products without rebuilding or changing them."""
import argparse
import json
from pathlib import Path
import shutil
import struct
import zipfile

import restore_oem as repair

ARTIFACT_ID = 13972898829
RUN_ID = 43278002694
COMMIT = '982b297187970669c4bbb4fcde8de55adce9b30d'
ARCHIVE_SHA = '1769c8ee14f2159f98453d72f97e6b914d79f60726d5ca5444a7d1453fcff7ed'
ARCHIVE_SIZE = 273019834
ORIGINAL_ERROR = 'REAL_OEM_CODE_MISSING:hardwareinfo_init_module'


def audit(archive, output):
    repair.verify_package()
    r13, r12, helper = repair.dependency()
    archive = Path(archive).resolve(strict=True)
    output = Path(output).resolve()
    repair.require(not output.exists(), 'AUDIT_OUTPUT_MUST_BE_NEW')
    repair.require(archive.stat().st_size == ARCHIVE_SIZE and repair.sha(archive) == ARCHIVE_SHA,
                   'NOT_THE_AUTHENTICATED_R14_RUN_ARTIFACT')
    output.mkdir(parents=True)
    result = dict(status='R14_R2_AUDIT_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  device_boot_tested=False, flash_allowed=False, kernel_rebuilt=False,
                  original_workflow_run=RUN_ID, original_commit=COMMIT,
                  original_workflow_conclusion='failure', original_validator_error=ORIGINAL_ERROR,
                  authenticated_original_artifact_sha256=ARCHIVE_SHA)
    try:
        products = output / 'Original_R14_Products'
        with zipfile.ZipFile(archive) as z:
            items = z.infolist()
            repair.require(len(items) < 200 and sum(x.file_size for x in items) < 2_000_000_000,
                           'ORIGINAL_ARTIFACT_SCOPE_CHANGED')
            repair.require(z.testzip() is None and len(items) == len({x.filename for x in items}),
                           'BAD_OR_DUPLICATE_ORIGINAL_ARCHIVE')
            for item in items:
                path = Path(item.filename)
                repair.require(not path.is_absolute() and '..' not in path.parts
                               and '\\' not in item.filename and not item.is_dir()
                               and (item.external_attr >> 16 & 0o170000) != 0o120000,
                               'UNSAFE_ORIGINAL_ARCHIVE')
            z.extractall(products)
        report = json.loads((products / 'R14_RESULT.json').read_text())
        repair.require(report['status'] == 'R14_BUILD_OR_ABI_GATE_FAILED_NOFLASH'
                       and report.get('error') == ORIGINAL_ERROR, 'DIFFERENT_ORIGINAL_FAILURE_REQUIRES_REVIEW')
        builds = report['make_results']
        targets = [row['target'] for row in builds]
        repair.require(len(builds) == len(set(targets)) == 25
                       and all(row['exit_code'] == 0 for row in builds)
                       and {'olddefconfig', 'Image', 'dtbs', 'modules', 'sound/soc/soc-core.o',
                            'drivers/misc/hardware_info.o', 'kernel/smp.o', 'lib/cpumask.o'} <= set(targets),
                       'ORIGINAL_KERNEL_BUILD_NOT_COMPLETE')
        for row in builds:
            log = products / (row['target'].replace('/', '_') + '.log')
            repair.require(repair.sha(log) == row['log_sha256'], 'COMPILER_LOG_CHANGED:' + row['target'])
        real = report['real_build_log']
        repair.require(real['all_real_build_traces_seen'] and real['linker_warning_free']
                       and real['linker_warnings_requires_review'] == 0 and real['missing_llvm_nm_errors'] == 0,
                       'ORIGINAL_LINK_TRACE_NOT_GREEN')
        repair.require(report['r6_baseline_unchanged'] is True, 'R6_CONTROL_CHANGED')
        repair.require(report['r14_oem']['source_pins'] == repair.pins()
                       and report['r14_oem']['real_hardwareinfo_driver'] is True
                       and report['r14_oem']['public_smartpa_state_and_int_api_restored'] is True,
                       'ORIGINAL_OEM_SOURCE_PORT_CHANGED')
        repair.require(all(repair.sha(repair.ROOT / 'Candidate_R14' / name) == pin['after_sha256']
                           for name, pin in repair.pins().items()), 'PACKAGED_R14_KERNEL_SOURCES_CHANGED')
        result['kernel_source_port_unchanged_from_r14'] = True
        candidate = products / 'candidate-out'
        config = r12.config_values((candidate / '.config').read_text())
        result['config_delta_against_r13'] = repair.verify_config(
            r12.config_values((repair.ROOT / 'References/R13.config').read_text()), config)
        repair.require(report['config_delta_against_r13'] == result['config_delta_against_r13'],
                       'ORIGINAL_CONFIG_REPORT_DISAGREES')
        release = report['release']
        repair.require(release['verified_release'] == '5.4.274-qgki'
                       and release['unchanged_stock_reference'] == '5.4.274-qgki-g82179e362f33'
                       and release['no_stock_git_id_spoof'] and release['release_from_config_only'],
                       'ORIGINAL_RELEASE_NOT_PROVEN')
        recorded = {row['file']: row['sha256'] for row in release['artifacts']}
        hashes = {name: repair.sha(candidate / name) for name in ('arch/arm64/boot/Image', 'vmlinux')}
        repair.require(all(recorded.get(name) == digest for name, digest in hashes.items()),
                       'ORIGINAL_LINK_PRODUCTS_CHANGED')
        image = candidate / 'arch/arm64/boot/Image'
        with image.open('rb') as stream:
            header = stream.read(64)
        repair.require(len(header) == 64 and header[56:60] == b'ARMd', 'NOT_AN_ARM64_IMAGE')
        with (candidate / 'vmlinux').open('rb') as stream:
            header = stream.read(64)
        repair.require(header[:6] == b'\x7fELF\x02\x01' and struct.unpack_from('<H', header, 18)[0] == 183,
                       'NOT_AARCH64_VMLINUX')
        result['kernel_compiled'] = True
        result['original_make_targets_passed'] = 25
        result['original_compiler_log_hashes_verified'] = True
        result['original_release_evidence'] = release
        result['original_link_product_hashes_verified'] = hashes
        result['linked_cpu_exports'] = r13.prove_linked_exports(candidate / 'System.map')
        result['linked_oem_exports'] = repair.prove_linked(candidate / 'System.map')
        expected, imports = helper.references()
        actual = helper.parse_symvers(candidate / 'Module.symvers')
        reference = helper.parse_symvers(repair.ROOT / 'References/R13_Module.symvers')
        rows, modules, counts = helper.compare(actual, expected, imports)
        helper.save_csv(output / 'QGKI_1423_SYMBOL_RESULTS.csv', rows)
        helper.save_csv(output / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result.update(qgki_counts=counts, module_layout_crc=actual.get('module_layout'),
                      fully_matching_modules=sum(row['fully_compatible'] for row in modules),
                      abi_progress=repair.verify_abi(actual, reference, expected))
        result['changed_imported_symbols_against_r13'] = [
            {'symbol': name, 'r13_crc': reference.get(name), 'r14_crc': actual.get(name), 'stock_crc': expected[name]}
            for name in sorted(expected) if reference.get(name) != actual.get(name)]
        repair.require(all(repair.sha(candidate / name) == digest for name, digest in hashes.items()),
                       'AUDIT_MODIFIED_KERNEL_PRODUCTS')
        result['kernel_products_unchanged_by_audit'] = True
        result['status'] = 'R14_R2_EXISTING_ARM64_BUILD_AND_OEM_EXPORT_GROUP_VERIFIED_NOFLASH'
    except Exception as error:
        result.update(status='R14_R2_AUDIT_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        repair.write_json(output / 'R14_R2_RESULT.json', result)
    print(result['status'], result['qgki_counts'], 'REBUILD=NO FLASH=NO')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    audit(args.archive, args.output)


if __name__ == '__main__':
    main()
