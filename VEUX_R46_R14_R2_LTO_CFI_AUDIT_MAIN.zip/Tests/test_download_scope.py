import hashlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Tools'))
import fetch_original_artifact as fetch


class DownloadScopeTests(unittest.TestCase):
    def exercise(self, *, wrong_digest=False, location='https://blob.example.invalid/signed-artifact'):
        payload = b'authenticated test artifact'
        digest = hashlib.sha256(payload).hexdigest()
        metadata = {'id': fetch.ARTIFACT_ID, 'workflow_run': {'id': fetch.RUN_ID, 'head_sha': fetch.COMMIT},
                    'size_in_bytes': len(payload), 'expired': False,
                    'digest': 'sha256:' + ('0' * 64 if wrong_digest else digest),
                    'name': 'VEUX-R46-R14-OEM-EXPORT-REPAIR-NOFLASH-43278002694'}
        api_requests, storage_requests = [], []

        class API:
            def open(self, request, **_):
                api_requests.append(request)
                if request.full_url == fetch.BASE:
                    return io.BytesIO(json.dumps(metadata).encode())
                if request.full_url == fetch.BASE + '/zip':
                    raise urllib.error.HTTPError(request.full_url, 302, 'redirect',
                                                 {'Location': location}, io.BytesIO())
                raise AssertionError('Unexpected API URL')

        def storage(request, **_):
            storage_requests.append(request)
            return io.BytesIO(payload)

        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'artifact.zip'
            with mock.patch.dict(os.environ, {'GITHUB_TOKEN': 'unit-test-read-token'}), \
                 mock.patch.object(fetch, 'ARCHIVE_SIZE', len(payload)), \
                 mock.patch.object(fetch, 'ARCHIVE_SHA', digest), \
                 mock.patch.object(fetch.urllib.request, 'build_opener', return_value=API()), \
                 mock.patch.object(fetch.urllib.request, 'urlopen', side_effect=storage):
                if wrong_digest:
                    with self.assertRaisesRegex(ValueError, 'GITHUB_ARTIFACT_IDENTITY_CHANGED_OR_EXPIRED'):
                        fetch.fetch(path)
                elif not location.startswith('https:'):
                    with self.assertRaisesRegex(ValueError, 'UNSAFE_ARTIFACT_TRANSFER_LOCATION'):
                        fetch.fetch(path)
                else:
                    fetch.fetch(path)
                    self.assertEqual(path.read_bytes(), payload)
                exists = path.exists()
        return api_requests, storage_requests, exists

    def test_token_is_scoped_to_fixed_api_and_never_sent_to_storage(self):
        api, storage, exists = self.exercise()
        self.assertTrue(exists)
        self.assertEqual(len(api), 2)
        self.assertEqual(len(storage), 1)
        self.assertTrue(all(r.get_header('Authorization') == 'Bearer unit-test-read-token' for r in api))
        self.assertFalse(any(k.lower() == 'authorization' for k, _ in storage[0].header_items()))

    def test_wrong_artifact_identity_stops_before_transfer(self):
        api, storage, exists = self.exercise(wrong_digest=True)
        self.assertEqual(len(api), 1)
        self.assertFalse(storage)
        self.assertFalse(exists)

    def test_non_https_transfer_is_rejected(self):
        _, storage, exists = self.exercise(location='http://blob.example.invalid/artifact')
        self.assertFalse(storage)
        self.assertFalse(exists)


if __name__ == '__main__':
    unittest.main()
