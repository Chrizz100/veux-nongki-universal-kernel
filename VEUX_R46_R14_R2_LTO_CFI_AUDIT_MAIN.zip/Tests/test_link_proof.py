import copy
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('real_link', ROOT / 'Tools/link_proof.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Snapshot:
    def __init__(self, data):
        self.symbols = copy.deepcopy(data['symbols'])
        self.map = data['system_map']
        self.regions = {int(address): bytes.fromhex(value) for address, value in data['regions'].items()}

    def section_name(self, symbol):
        return symbol['section_name']

    def read(self, address, size):
        for base, data in self.regions.items():
            if base <= address and address + size <= base + len(data):
                return data[address - base:address - base + size]
        raise ValueError('CALLBACK_ADDRESS_NOT_IN_FILE_BACKED_KERNEL_SECTION')


class LinkProofTests(unittest.TestCase):
    def setUp(self):
        data = json.loads((ROOT / 'Tests/Fixtures/ACTUAL_R14_LTO_CFI_LINK_SNAPSHOT.json').read_text())
        self.elf = Snapshot(data)
        self.entry = next(s for s in self.elf.symbols if s['name'].startswith('__initcall_'))
        self.body = next(s for s in self.elf.symbols if s['name'].startswith('hardwareinfo_init_module$')
                         and not s['name'].endswith('.cfi_jt'))

    def test_actual_failed_run_lto_hash_and_cfi_route_pass(self):
        proof = m.prove_from_view(self.elf, self.elf.map)
        self.assertEqual(proof['route'], 'cfi_jump_table_branch')
        self.assertEqual(proof['init_function_address'], '0xffffffc0126c86f4')
        self.assertEqual(proof['initcall_target'], '0xffffffc0117be68c')
        self.assertEqual(proof['definitions']['smartpa_type']['address'], '0xffffffc01298fd00')

    def test_direct_non_lto_initialization_is_supported(self):
        old = self.body['name']
        self.body['name'] = 'hardwareinfo_init_module'
        self.elf.map = self.elf.map.replace(old + '\n', self.body['name'] + '\n')
        self.elf.regions[self.entry['value']] = self.body['value'].to_bytes(8, 'little')
        self.assertEqual(m.prove_from_view(self.elf, self.elf.map)['route'], 'direct')

    def test_real_prel32_callback_math_is_supported(self):
        self.entry['size'] = 4
        target = 0xffffffc0117be68c
        self.elf.regions[self.entry['value']] = (target - self.entry['value']).to_bytes(4, 'little', signed=True)
        self.assertEqual(m.prove_from_view(self.elf, self.elf.map)['entry_encoding'], 'prel32')

    def test_wrong_cfi_branch_target_is_rejected(self):
        target = 0xffffffc0117be68c
        self.elf.regions[target] = (0x143c281b).to_bytes(4, 'little')
        with self.assertRaisesRegex(ValueError, 'CFI_ENTRY_BRANCHES_TO_WRONG_FUNCTION'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_nonbranch_cfi_entry_is_rejected(self):
        self.elf.regions[0xffffffc0117be68c] = (0xd65f03c0).to_bytes(4, 'little')
        with self.assertRaisesRegex(ValueError, 'CFI_ENTRY_NOT_AARCH64_UNCONDITIONAL_BRANCH'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_unrelated_initcall_target_is_rejected(self):
        self.elf.regions[self.entry['value']] = (0xffffffc010123456).to_bytes(8, 'little')
        with self.assertRaisesRegex(ValueError, 'INITCALL_TARGET_NOT_REAL_INIT_OR_CFI_ENTRY'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_private_codec_state_cannot_replace_public_smartpa_export(self):
        self.elf.symbols = [s for s in self.elf.symbols
                            if not (s['name'] == 'smartpa_type' and s['binding'] == 1)]
        with self.assertRaisesRegex(ValueError, 'REAL_PUBLIC_OEM_DEFINITION_MISSING:smartpa_type'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_wrong_smartpa_width_is_rejected(self):
        next(s for s in self.elf.symbols if s['name'] == 'smartpa_type' and s['binding'] == 1)['size'] = 8
        with self.assertRaisesRegex(ValueError, 'SMARTPA_STATE_NOT_ORIGINAL_INT_WIDTH'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_duplicate_device_initcall_is_rejected(self):
        another = dict(self.entry, name='__initcall_999_999_hardwareinfo_init_module6')
        self.elf.symbols.append(another)
        with self.assertRaisesRegex(ValueError, 'HARDWARE_INFO_INITCALL_MISSING_OR_DUPLICATE'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_system_map_must_agree_with_real_elf(self):
        self.elf.map = self.elf.map.replace(self.body['name'] + '\n', 'unrelated_function\n')
        with self.assertRaisesRegex(ValueError, 'ELF_SYSTEM_MAP_DISAGREE'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_export_table_entry_must_exist(self):
        self.elf.symbols = [s for s in self.elf.symbols if s['name'] != '__ksymtab_hardwareinfo_set_prop']
        with self.assertRaisesRegex(ValueError, 'REAL_OEM_EXPORT_TABLE_MISSING'):
            m.prove_from_view(self.elf, self.elf.map)

    def test_unlinked_aarch64_object_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'not-vmlinux.o'
            path.write_bytes(struct.pack('<16sHHIQQQIHHHHHH', b'\x7fELF\x02\x01' + bytes(10),
                                         1, 183, 1, 0, 0, 0, 0, 64, 0, 0, 64, 1, 0))
            with self.assertRaisesRegex(ValueError, 'NOT_LINKED_AARCH64_KERNEL'):
                m.ELF64(path)


if __name__ == '__main__':
    unittest.main()
