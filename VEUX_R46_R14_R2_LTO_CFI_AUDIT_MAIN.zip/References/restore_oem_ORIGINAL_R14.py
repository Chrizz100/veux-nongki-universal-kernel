#!/usr/bin/env python3
"""Restore the complete stock hardware-info and SmartPA interfaces on R13."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
R13_ARCHIVE_SHA = 'fa79878c2d6a80a66a0be7884bc13aab16b2c5d84fa0505e28239ae79fb9af8d'
R13_SYMVERS_SHA = '3f6915529d668d54251b2e5ed05021c49746daab34f1c370b5abed0df972bb2e'
R13_CONFIG_SHA = '606c0c6ac975871d13e4f0f52914e07c661a4e6fd8cc59e48e5210c66691cdb2'
EXPECTED = {'hardwareinfo_set_prop': '0x8124e3e6', 'smartpa_type': '0xed687ffd',
            'snd_soc_set_smartpa_type': '0x777f6815'}
FILES = ('drivers/misc/Kconfig', 'drivers/misc/Makefile', 'drivers/misc/hardware_info.c',
         'include/linux/hardware_info.h', 'sound/soc/soc-core.c', 'include/sound/soc.h')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def verify_package():
    listed = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts and name not in listed,
                'UNSAFE_MANIFEST')
        require(not (ROOT / rel).is_symlink() and sha(ROOT / rel) == digest,
                'PACKAGE_FILE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and 'runtime-r13' not in p.parts
              and p.name != 'MANIFEST_SHA256.txt'}
    require(listed == actual, 'PACKAGE_MANIFEST_SCOPE_CHANGED')
    require(sha(ROOT / 'Dependencies/R13_MAIN.zip') == R13_ARCHIVE_SHA, 'R13_DEPENDENCY_CHANGED')
    require(sha(ROOT / 'References/R13_Module.symvers') == R13_SYMVERS_SHA, 'R13_ABI_REFERENCE_CHANGED')
    require(sha(ROOT / 'References/R13.config') == R13_CONFIG_SHA, 'R13_CONFIG_REFERENCE_CHANGED')


def dependency():
    archive = ROOT / 'Dependencies/R13_MAIN.zip'
    require(sha(archive) == R13_ARCHIVE_SHA, 'R13_DEPENDENCY_CHANGED')
    destination = ROOT / 'runtime-r13'
    if not destination.exists():
        with zipfile.ZipFile(archive) as z:
            items = z.infolist()
            require(len(items) < 200 and sum(p.file_size for p in items) < 64_000_000,
                    'R13_ARCHIVE_SCOPE_CHANGED')
            require(z.testzip() is None and len(items) == len({p.filename for p in items}), 'R13_BAD_ZIP')
            for item in items:
                p = Path(item.filename)
                require(not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename
                        and not item.is_dir() and (item.external_attr >> 16 & 0o170000) != 0o120000,
                        'UNSAFE_R13_ZIP')
            z.extractall(destination)
    r13 = load(destination / 'Tools/restore_cpu_exports.py', 'r14_r13_helper')
    r13.verify_package()
    r12, h = r13.dependency()
    return r13, r12, h


def pins():
    result = json.loads((ROOT / 'References/FILE_PINS.json').read_text())
    require(set(result) == set(FILES), 'OEM_FILE_SCOPE_CHANGED')
    return result


def check_source(source):
    source = Path(source).resolve(strict=True)
    for name, item in pins().items():
        path = source / name
        require(not path.is_symlink()
                and all(not p.is_symlink() for p in path.parents if p.is_relative_to(source)),
                'UNSAFE_SOURCE:' + name)
        if item['before_sha256'] is None:
            require(not path.exists(), 'NEW_OEM_FILE_ALREADY_PRESENT:' + name)
        else:
            require(path.is_file() and sha(path) == item['before_sha256'],
                    'OEM_PREIMAGE_CHANGED:' + name)
    run = subprocess.run(['git', 'apply', '--check', '--whitespace=error',
                          str((ROOT / 'References/RESTORE_OEM_HARDWARE_SMARTPA.patch').resolve())],
                         cwd=source, capture_output=True, text=True)
    require(run.returncode == 0, 'OEM_PATCH_CHECK_FAILED:' + run.stderr)
    return {'exact_source_preimages_verified': 6, 'source_changed': False}


def apply_source(source):
    source = Path(source).resolve(strict=True)
    check_source(source)
    run = subprocess.run(['git', 'apply', '--whitespace=error',
                          str((ROOT / 'References/RESTORE_OEM_HARDWARE_SMARTPA.patch').resolve())],
                         cwd=source, capture_output=True, text=True)
    require(run.returncode == 0, 'OEM_PATCH_FAILED:' + run.stderr)
    for name, item in pins().items():
        require(sha(source / name) == item['after_sha256'], 'OEM_POSTIMAGE_CHANGED:' + name)
    return {'changed_files': 6, 'stock_source_commit': '61397e524093d1ccb94769b5460825e2eaf8871e',
            'real_hardwareinfo_driver': True, 'public_smartpa_state_and_int_api_restored': True,
            'source_pins': pins()}


def verify_config(before, after):
    delta = {key: [before.get(key), after.get(key)] for key in before.keys() | after.keys()
             if before.get(key) != after.get(key)}
    require(delta == {'CONFIG_HARDWARE_INFO': [None, 'y']}, 'UNEXPECTED_R13_R14_CONFIG_DELTA:' + repr(delta))
    require(after.get('CONFIG_WT_QGKI') == 'y', 'STOCK_SMARTPA_CONFIGURATION_DISABLED')
    return delta


def verify_abi(actual, reference, expected):
    for name, crc in EXPECTED.items():
        require(expected[name] == crc and actual.get(name) == crc,
                'OEM_EXPORT_NOT_STOCK_COMPATIBLE:' + name)
    missing = sorted(name for name in expected if name not in actual)
    require(not missing, 'ORIGINAL_IMPORTS_STILL_NOT_EXPORTED:' + repr(missing))
    lost = sorted(name for name, crc in expected.items()
                  if reference.get(name) == crc and actual.get(name) != crc)
    require(not lost, 'PREVIOUS_STOCK_MATCH_REGRESSED:' + repr(lost))
    return {'repaired_stock_interfaces': EXPECTED, 'lost_matching_symbols': lost,
            'remaining_missing_symbols': missing,
            'gained_matching_symbols': sorted(name for name, crc in expected.items()
                                             if reference.get(name) != crc and actual.get(name) == crc)}


def prove_linked(system_map):
    symbols = {}
    for line in Path(system_map).read_text().splitlines():
        f = line.split()
        if len(f) == 3:
            symbols[f[2]] = f[1]
    for name in ('hardwareinfo_set_prop', 'snd_soc_set_smartpa_type', 'hardwareinfo_init_module'):
        require(symbols.get(name) in ('T', 't'), 'REAL_OEM_CODE_MISSING:' + name)
    require(symbols.get('smartpa_type') in ('D', 'd', 'B', 'b'), 'PUBLIC_SMARTPA_DATA_MISSING')
    require(all('__ksymtab_' + name in symbols for name in EXPECTED), 'REAL_OEM_EXPORT_TABLE_MISSING')
    initcalls = [name for name in symbols if name.startswith('__initcall_')
                 and name.endswith('hardwareinfo_init_module6') and symbols[name] in ('d', 'D', 'r', 'R')]
    require(len(initcalls) == 1, 'HARDWARE_INFO_INITCALL_MISSING_OR_DUPLICATE')
    return {'definitions': {name: symbols[name] for name in (*EXPECTED, 'hardwareinfo_init_module')},
            'device_initcall': initcalls[0]}


def build(args):
    verify_package()
    r13, r12, h = dependency()
    r6 = load(Path(args.r6_tool), 'r14_r6_verifier')
    src = Path(args.source).resolve(strict=True)
    obj = Path(args.objout).resolve(strict=True)
    out = Path(args.output).resolve()
    ws = Path(os.environ['GITHUB_WORKSPACE']).resolve(strict=True)
    project = Path(args.project).resolve(strict=True)
    require(not out.exists() and out.is_relative_to(ws), 'OUTPUT_MUST_BE_NEW_IN_WORKSPACE')
    require(src.is_relative_to(ws) and obj.is_relative_to(ws)
            and not out.is_relative_to(src) and not out.is_relative_to(obj)
            and not out.is_relative_to(project) and not src.is_relative_to(project), 'UNSAFE_OUTPUT')
    base = json.loads(Path(args.r6_report).read_text())
    require(base['status'] == 'R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH', 'R6_NOT_GREEN')
    require(sha(obj / '.config') == h.CONFIG_SHA and sha(obj / 'Module.symvers') == h.SYMVERS_SHA,
            'R6_BASELINE_CHANGED')
    require(sha(obj / 'arch/arm64/boot/Image') == base['image_sha256'], 'R6_IMAGE_CHANGED')
    guards = {name: sha(obj / name) for name in ('.config', 'Module.symvers', 'arch/arm64/boot/Image')}
    expected, imports = h.references()
    reference = h.parse_symvers(ROOT / 'References/R13_Module.symvers')
    _, _, old_counts = h.compare(reference, expected, imports)
    require(old_counts == dict(MATCH=580, CRC_MISMATCH=841, NOT_EXPORTED=2), 'R13_COUNTS_CHANGED')
    before_config = r12.config_values((ROOT / 'References/R13.config').read_text())
    commands = {row['target']: row['invocation'] for row in base['make_results']}
    require(set(commands) == {'Image', 'dtbs', 'modules'}, 'MISSING_BASELINE_MAKE_TARGETS')
    out.mkdir(parents=True)
    result = dict(status='R14_BUILD_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  flash_allowed=False, device_boot_tested=False, make_results=[],
                  baseline_run=43250100191, baseline_r13_qgki_counts=old_counts)
    try:
        candidate = out / 'candidate-source'
        candidate_out = out / 'candidate-out'
        shutil.copytree(src, candidate, ignore=shutil.ignore_patterns('.git'), symlinks=True)
        candidate_out.mkdir()
        shutil.copyfile(obj / '.config', candidate_out / '.config')
        result['r11_iommu'] = h.apply_scoped(candidate, h.generated_patches())
        result['r11_dependencies'] = h.audit_dependencies(candidate)
        result['r12_spf'] = r12.apply_source(candidate)
        result['r13_cpu_exports'] = r13.apply_source(candidate)
        result['r14_oem'] = apply_source(candidate)
        request = subprocess.run(['bash', str(candidate / 'scripts/config'), '--file',
                                  str(candidate_out / '.config'), '-e', 'SPECULATIVE_PAGE_FAULT',
                                  '-e', 'HARDWARE_INFO'], capture_output=True, text=True)
        require(request.returncode == 0, 'OEM_CONFIG_REQUEST_FAILED:' + request.stderr)
        units = sorted(set(r12.object_targets(obj) + ['kernel/smp.o', 'lib/cpumask.o',
                                                     'sound/soc/soc-core.o', 'drivers/misc/hardware_info.o']))
        resolved_sha = None
        for target in ['olddefconfig'] + units + ['Image', 'dtbs', 'modules']:
            argv = list(commands.get(target, commands['Image']))
            require(argv[0] == 'make' and argv.count('-C') == 1
                    and argv[argv.index('-C') + 1] == str(src), 'INVALID_BASE_SOURCE_COMMAND')
            require(argv.count('O=' + str(obj)) == 1, 'INVALID_BASE_OUTPUT_COMMAND')
            argv[argv.index('-C') + 1] = str(candidate)
            argv[argv.index('O=' + str(obj))] = 'O=' + str(candidate_out)
            argv[-1] = target
            row = h.run_make(argv, out, target.replace('/', '_'), r6.pinned_llvm_tool_env(argv))
            row['target'] = target
            result['make_results'].append(row)
            require(row['exit_code'] == 0, 'ARM64_BUILD_FAILED:' + target)
            if target == 'olddefconfig':
                result['config_delta_against_r13'] = verify_config(before_config,
                    r12.config_values((candidate_out / '.config').read_text()))
                resolved_sha = sha(candidate_out / '.config')
            require(sha(candidate_out / '.config') == resolved_sha, 'CONFIG_DRIFT_DURING_BUILD')
        require(r6.is_arm64_image(candidate_out / 'arch/arm64/boot/Image')
                and r6.is_arm64_elf(candidate_out / 'vmlinux'), 'NOT_AN_ARM64_KERNEL')
        result['release'] = r6.verify_generated_release(candidate_out)
        result['rmnet_initcalls'] = r6.prove_real_linked_initcalls(candidate_out / 'System.map')
        result['real_build_log'] = r6.prove_build_log(out / 'Image.log')
        require(result['real_build_log']['linker_warning_free'], 'LINKER_WARNINGS')
        result['linked_cpu_exports'] = r13.prove_linked_exports(candidate_out / 'System.map')
        result['linked_oem_exports'] = prove_linked(candidate_out / 'System.map')
        actual = h.parse_symvers(candidate_out / 'Module.symvers')
        rows, modules, counts = h.compare(actual, expected, imports)
        h.save_csv(out / 'QGKI_1423_SYMBOL_RESULTS.csv', rows)
        h.save_csv(out / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result.update(kernel_compiled=True, qgki_counts=counts,
                      module_layout_crc=actual.get('module_layout'),
                      fully_matching_modules=sum(row['fully_compatible'] for row in modules),
                      artifacts={name: sha(candidate_out / name) for name in
                                 ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux')})
        result['abi_progress'] = verify_abi(actual, reference, expected)
        result['status'] = 'R14_FULL_ARM64_BUILD_AND_COMPLETE_OEM_EXPORT_GROUP_PROVEN_NOFLASH'
    except Exception as error:
        result.update(status='R14_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        result['r6_baseline_unchanged'] = all(sha(obj / name) == digest for name, digest in guards.items())
        write_json(out / 'R14_RESULT.json', result)
    require(result['r6_baseline_unchanged'], 'R6_BASELINE_MUTATED')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    for operation in ('patch-source', 'check-source'):
        sub.add_parser(operation).add_argument('--source', required=True)
    build_parser = sub.add_parser('build')
    for name in ('source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        build_parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    if args.operation == 'verify-package':
        verify_package()
        dependency()
        print('R14_PACKAGE_AND_R13_R12_R11_DEPENDENCIES_AUTHENTICATED')
    elif args.operation == 'check-source':
        verify_package()
        print(json.dumps(check_source(args.source), sort_keys=True))
    elif args.operation == 'patch-source':
        verify_package()
        print(json.dumps(apply_source(args.source), sort_keys=True))
    else:
        build(args)


if __name__ == '__main__':
    main()
