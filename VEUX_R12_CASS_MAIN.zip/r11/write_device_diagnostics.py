#!/usr/bin/env python3
"""Bind the read-only diagnostic to the packaged kernel's actual ELF notes."""
import argparse
import json
from pathlib import Path
import re


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--checks", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    checks = json.loads(a.checks.read_text())
    digest = checks.get("kernel_notes_sha256", "")
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("Actual validated kernel notes hash is required")
    template = Path(__file__).with_name("device_diagnostics.sh.in").read_text()
    if template.count("@KERNEL_NOTES_SHA256@") != 1:
        raise ValueError("Diagnostic template changed")
    a.out.write_text(template.replace("@KERNEL_NOTES_SHA256@", digest))
    a.out.chmod(0o755)


if __name__ == "__main__":
    main()
