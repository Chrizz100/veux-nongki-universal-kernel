#!/usr/bin/env python3
"""Export a completed VEUX built-in kernel with explicit CI/local provenance."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

from builtin_validation import BAKASU_MARKER, REQUIRED, RMNET_SOURCES, compile_command_check, file_hash, record, validate_inputs
from boot_common import require

HERE = Path(__file__).resolve().parent
OUTPUT_PATHS = {
    'Image': 'arch/arm64/boot/Image', 'actual-build.config': '.config',
    'System.map': 'System.map', 'Module.symvers': 'Module.symvers',
    'veux.dtb': 'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb', 'vmlinux': 'vmlinux',
    'modules.builtin': 'modules.builtin', 'modules.order': 'modules.order',
}


def git(source, *arguments):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(source), *arguments], text=True).strip()


def load(path):
    require(path.is_file() and not path.is_symlink(), 'missing regular evidence: ' + str(path))
    return json.loads(path.read_text())


def collect(args):
    require(not args.out.exists(), 'collection output must be a new directory')
    require(re.fullmatch('[0-9a-f]{40}', args.repo_commit), 'repository commit must be an exact SHA')
    source_contract = load(args.source_contract)
    require(source_contract.get('schema') == 'veux-r11-source-v1', 'wrong source contract')
    for name, item in source_contract['files'].items():
        require(file_hash(args.source / name) == item['after_sha256'], 'source postimage mismatch: ' + name)
    require(git(args.source / 'KernelSU', 'rev-parse', 'HEAD') == source_contract['bakasu_port_commit'], 'BakaSU port changed')
    subprocess.run(['git', '-C', str(args.source / 'KernelSU'), 'diff', '--quiet', 'HEAD', '--'], check=True)
    command_record = load(args.evidence / 'BUILD_COMMAND.json')
    require(Path(command_record['source']).resolve() == args.source.resolve(), 'command/source path mismatch')
    variables = command_record['variables']
    require(Path(variables['O']).resolve() == args.build.resolve(), 'command/build path mismatch')
    command = ['/usr/bin/make', '-C', str(args.source)] + [f'{k}={v}' for k, v in variables.items()]
    command += [f'-j{command_record["jobs"]}', 'Image', 'dtbs', 'modules']
    source_commit = git(args.source, 'rev-parse', 'HEAD')
    evidence_names = ['BUILD_COMMAND.json', 'FULL_BUILD.log']
    if args.evidence_mode == 'ci':
        require(os.environ.get('GITHUB_ACTIONS') == 'true', 'CI provenance requires a real GitHub Actions environment')
        require(os.environ.get('GITHUB_SHA') == args.repo_commit, 'workflow commit does not match repository pin')
        native = load(args.evidence / 'NATIVE_BUILD_RESULT.json')
        require(native.get('status') == 'NATIVE_CASS_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
                and native.get('native_compile_completed') is True
                and native.get('static_gates_passed') is True
                and native.get('kernel_image_generated') is True, 'R4 native compile/ABI gates not passed')
        r4 = load(args.evidence / 'R4_RESULT.json')
        require(r4.get('status') == 'CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
                and r4.get('original_baseline_unchanged') is True, 'R4 baseline/full-build gates not passed')
        updated = load(args.evidence / 'R11_SOURCE_UPDATE.json')
        require(updated.get('status') == 'SOURCE_UPDATE_PASS'
                and updated.get('all_other_source_files_unchanged') is True
                and updated.get('source_contract_sha256') == file_hash(args.source_contract), 'R11 source update not proven')
        hook = load(args.evidence / 'R11_COMPILE_HOOK.json')
        require(hook.get('schema') == 'veux-r11-compile-hook-v1'
                and hook.get('r4_compile_and_static_gates_passed') is True
                and hook.get('candidate_source_unchanged_during_compile') is True
                and hook.get('original_r4_build_script_sha256') == '12519a7d94825d3bc2006a46420f8884773a659443e56ba542f48057929dd3a0'
                and hook.get('precompile_source_update_sha256') == file_hash(args.evidence / 'R11_SOURCE_UPDATE.json'),
                'R11 guarded compiler/source-preservation hook not proven')
        git_index = load(args.evidence / 'R11_GIT_INDEX.json')
        require(git_index.get('status') == 'CLEAN_INDEX_AND_WORKTREE'
                and git_index.get('source_bytes_unchanged') is True
                and git_index.get('version_overrides') is False
                and git_index.get('only_isolated_git_metadata_refreshed') is True,
                'R11 real Git identity/index correction not proven')
        for original, expected in native['proof']['outputs'].items():
            require(record(args.build / original) == expected, 'R4 output changed after validation: ' + original)
        evidence_names += ['NATIVE_BUILD_RESULT.json', 'R4_RESULT.json', 'R11_SOURCE_UPDATE.json', 'R11_COMPILE_HOOK.json', 'R11_GIT_INDEX.json']
        origin = 'same-build-invocation'
        extra = {'github_run_id': os.environ.get('GITHUB_RUN_ID'),
                 'github_run_attempt': os.environ.get('GITHUB_RUN_ATTEMPT'),
                 'github_repository': os.environ.get('GITHUB_REPOSITORY')}
    else:
        local = load(args.evidence / 'LOCAL_BUILD_RESULT.json')
        require(local.get('kernel_compile_exit') == 0 and local.get('full_kernel_linked') is True
                and local.get('source_checks_passed') is True and local.get('baseline_unchanged') is True
                and local.get('kernel_compile_reused') is False, 'local full-build/source checks not passed')
        require(local.get('source_commit') == source_commit, 'local source commit mismatch')
        require(local.get('kernel_command'), 'local actual command missing')
        command = local['kernel_command']
        evidence_names += ['LOCAL_BUILD_RESULT.json']
        if (args.evidence / 'FULL_BUILD.log.json').is_file():
            evidence_names.append('FULL_BUILD.log.json')
        phases = local.get('build_phases', [])
        require(isinstance(phases, list) and phases and all(isinstance(phase, dict) for phase in phases),
                'local actual invocation phases are required')
        if phases:
            require(phases[-1].get('accepted_for_delivery') is True, 'final local compile phase not accepted')
            for phase in phases:
                require(phase.get('exit') == 0, 'local build/relink phase failed')
                for field in ['log', 'receipt']:
                    name = phase[field]
                    require(Path(name).name == name, 'invalid local phase evidence path')
                    if name not in evidence_names:
                        evidence_names.append(name)
                phase_receipt = load(args.evidence / phase['receipt'])
                require(phase_receipt.get('exit_code') == 0
                        and phase_receipt.get('log') == phase['log']
                        and phase_receipt.get('log_sha256') == file_hash(args.evidence / phase['log'])
                        and Path(phase_receipt['cwd']).resolve() == args.source.resolve(),
                        'local actual invocation/log receipt mismatch')
                if phase is phases[-1]:
                    require(phase_receipt.get('argv') == command, 'local final command differs from actual invocation')
        require(set(local.get('final_files', {})) == set(REQUIRED), 'local final output identity incomplete')
        for name, expected in local['final_files'].items():
            require(record(args.build / OUTPUT_PATHS[name]) == expected, 'local final output changed: ' + name)
        origin, extra = 'local-native-full-build', {'build_phases': phases,
            'kernel_compile_reused_scope': 'No baseline objects or foreign Image reused; same candidate may have a documented identity relink.'}
    args.out.mkdir(parents=True)
    (args.out / 'COLLECTION_INCOMPLETE').write_text('This directory is not accepted until BUILTIN_COLLECTION.json reports PASS.\n')
    provenance_dir = args.out / 'provenance'; provenance_dir.mkdir()
    methods = {}
    for name in REQUIRED:
        src, dst = args.build / OUTPUT_PATHS[name], args.out / name
        require(src.is_file() and not src.is_symlink(), 'missing regular build output: ' + name)
        try:
            os.link(src, dst)
            methods[name] = 'hardlink-to-completed-output'
        except OSError:
            shutil.copyfile(src, dst)
            methods[name] = 'independent-copy'
    evidence = {}
    for name in evidence_names:
        source_path = args.evidence / name
        require(source_path.is_file() and not source_path.is_symlink(), 'missing evidence: ' + name)
        shutil.copyfile(source_path, provenance_dir / name)
        evidence[name] = record(provenance_dir / name)
    shutil.copyfile(args.source_contract, provenance_dir / 'SOURCE_CONTRACT.json')
    evidence['SOURCE_CONTRACT.json'] = record(provenance_dir / 'SOURCE_CONTRACT.json')
    # Preserve optional metadata generated by the real kernel build. Its
    # presence is additional evidence, never a synthesized replacement list.
    modinfo = args.build / 'modules.builtin.modinfo'
    if modinfo.is_file():
        require(not modinfo.is_symlink(), 'linked built-in module metadata')
        shutil.copyfile(modinfo, provenance_dir / modinfo.name)
        evidence[modinfo.name] = record(provenance_dir / modinfo.name)
    compile_objects = {}
    for relative in RMNET_SOURCES:
        source_file = Path(relative)
        obj = args.build / source_file.with_suffix('.o')
        command_file = args.build / source_file.parent / ('.' + source_file.stem + '.o.cmd')
        compile_command_check(command_file.read_text(), relative)
        with obj.open('rb') as stream:
            require(stream.read(4) == b'BC\xc0\xde', 'RMNET output is not actual ThinLTO bitcode: ' + relative)
        saved = Path('provenance/rmnet_cmd') / source_file.parent.name / command_file.name
        (args.out / saved).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(command_file, args.out / saved)
        compile_objects[relative] = {'source_record': record(args.source / source_file),
                                    'object_record': record(obj), 'object_format': 'LLVM_BITCODE',
                                    'command_file': saved.as_posix(), 'command_record': record(args.out / saved)}
    release = (args.build / 'include/config/kernel.release').read_text().strip()
    metadata = {
        'schema': 'veux-builtin-build-output-v1', 'origin': origin, 'rmnet_mode': 'builtin',
        'kernel_release': release, 'bakasu_marker': BAKASU_MARKER, 'nomount_api': 22,
        'provenance': {'evidence_mode': args.evidence_mode, 'kernel_compile_exit': 0,
                       'kernel_compile_exit_evidence': 'successful guarded native compiler result' if args.evidence_mode == 'ci' else 'LOCAL_BUILD_RESULT.json',
                       'kernel_command': command, 'kernel_compile_reused': False, 'full_kernel_linked': True,
                       'source_commit': source_commit, 'repository_commit': args.repo_commit,
                       'source_checks_passed': True, 'source_contract_sha256': file_hash(args.source_contract),
                       'evidence': evidence, 'export_methods': methods, 'rmnet_compile_objects': compile_objects, **extra},
        'files': {name: record(args.out / name) for name in REQUIRED},
    }
    receipt = args.out / 'BUILD_OUTPUTS.json'
    receipt.write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
    _, _, checks = validate_inputs(args.out, receipt)
    proof = {'status': 'PASS', 'origin': origin, 'evidence_mode': args.evidence_mode,
             'receipt_sha256': file_hash(receipt), 'checks': checks, 'device_test': False}
    (args.out / 'BUILTIN_COLLECTION.json').write_text(json.dumps(proof, indent=2) + '\n')
    (args.out / 'COLLECTION_INCOMPLETE').unlink()
    print(json.dumps({'status': 'PASS', 'origin': origin, 'inputs': str(args.out), 'receipt': str(receipt)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['source', 'build', 'evidence', 'out']:
        parser.add_argument('--' + name, type=lambda p: Path(p).absolute(), required=True)
    parser.add_argument('--repo-commit', required=True)
    parser.add_argument('--evidence-mode', choices=['ci', 'local-native'], required=True)
    parser.add_argument('--source-contract', type=Path, default=HERE.parent / 'SOURCE_CONTRACT.json')
    args = parser.parse_args()
    try:
        collect(args)
    except (OSError, ValueError, KeyError, subprocess.CalledProcessError) as error:
        print('BUILTIN_COLLECTION_BLOCKED: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
