#!/usr/bin/env python3
"""Package a verified full kernel with built-in RMNET; no external module payload."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

import boot_common as common
from builtin_validation import file_hash, record, validate_inputs

HERE = Path(__file__).resolve().parent
TEMPLATE_SHA256 = '873f73c5ee5bd8fd1d055ac055e168686436f54ec79a9717c5bd0aa401484d02'
BOOT_COMMON_SHA256 = 'cbdbb3835193d4ea386e146a38b618404ad96b7ca1a735df8738adcf5f52160f'
INSTALLER_NAME = 'VEUX_CASS_BUILTIN_INSTALL_R11.zip'
RAW_NAME = 'VEUX_CASS_BUILTIN_BUILD_DATA_R11.zip'
require = common.require


def make_installer(args, boot, checks):
    def git(*arguments):
        return subprocess.check_output(['git', '--no-optional-locks', '-C', str(args.ak3), *arguments], text=True).strip()
    require(git('rev-parse', 'HEAD') == common.AK3_COMMIT and git('rev-parse', 'HEAD^{tree}') == common.AK3_TREE, 'AnyKernel3 pin mismatch')
    require(not git('status', '--porcelain', '--untracked-files=all'), 'AnyKernel3 checkout is not clean')
    template = common.pinned(HERE / 'assets/anykernel_builtin.sh.in', TEMPLATE_SHA256)
    script = template.replace(b'@BOOT_SHA256@', common.sha(boot).encode())
    require(b'@BOOT_SHA256@' not in script and b'payload/rmnet' not in script and b'RMNET_MANIFEST' not in script,
            'unexpected external RMNET payload/placeholder')
    script_file = args.out / 'anykernel.sh'; script_file.write_bytes(script)
    subprocess.run(['shellcheck', '--shell=ash', '--severity=warning', str(script_file)], check=True)
    members = {'anykernel.sh': (script, 0o755), 'payload/boot.img': (boot, 0o644)}
    for folder in ('tools', 'META-INF'):
        for path in sorted((args.ak3 / folder).rglob('*')):
            if path.is_file() and not path.name.endswith('placeholder'):
                require(not path.is_symlink(), 'linked AnyKernel3 payload')
                members[path.relative_to(args.ak3).as_posix()] = (path.read_bytes(), path.stat().st_mode & 0o777)
    for path in args.ak3.glob('LICENSE*'):
        members[path.name] = (common.regular(path), 0o644)
    readme = (
        'VEUX CASS R11: RMNET offload and SHS are linked into this exact kernel.\n'
        'Full Image/vmlinux and both device initcalls verified; device boot is untested.\n'
        'No external RMNET generation is installed. Existing launcher/data stay available for rollback.\n'
        'Preserved R3 NoMount 21-to-22 transition, verified NoMount605 handling, boot backup and direct readback.\n'
        'Only active boot is written. The Spoofed Manager and official NoMount605 remain separate companions.\n'
        'ROM unload/reload/property behavior still needs a device test.\n'
        'Boot SHA256: ' + common.sha(boot) + '\nKernel notes SHA256: ' + checks['kernel_notes_sha256'] + '\n')
    members['READ_ME.txt'] = (readme.encode(), 0o644)
    members['SHA256SUMS'] = (''.join(f'{common.sha(value[0])}  {name}\n' for name, value in sorted(members.items())).encode(), 0o644)
    require(not any(name.endswith('.ko') or name.startswith('payload/rmnet/') for name in members), 'external RMNET payload forbidden')
    output = args.out / INSTALLER_NAME
    common.write_zip(output, members)
    result = {'file': INSTALLER_NAME, **record(output), 'boot_sha256': common.sha(boot),
              'installer_sha256': common.sha(script), 'template_sha256': TEMPLATE_SHA256,
              'ak3_commit': common.AK3_COMMIT, 'ak3_tree': common.AK3_TREE,
              'external_rmnet_payload': False, 'existing_rmnet_generations_and_launchers_untouched': True,
              'nomount_backup_readback_logic_preserved': True, 'device_test': False,
              'archive_crc_and_members': 'PASS'}
    (args.out / 'INSTALLER_PACKAGE_CHECK.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def build(args):
    require(not args.out.exists(), 'output directory must be new')
    private = (args.base_boot, args.magiskboot, args.avbtool, args.ak3)
    require(all(private) or not any(private), 'boot packaging requires all four private/tool inputs')
    common.pinned(HERE / 'boot_common.py', BOOT_COMMON_SHA256)
    common.pinned(HERE / 'assets/anykernel_builtin.sh.in', TEMPLATE_SHA256)
    data, receipt, checks = validate_inputs(args.inputs, args.receipt)
    args.out.mkdir(parents=True)
    (args.out / 'BUILD_OUTPUTS.json').write_bytes(common.regular(args.receipt))
    (args.out / 'BUILD_PACKAGE_CHECK.json').write_text(json.dumps(checks, indent=2) + '\n')
    members = {name: (value, 0o644) for name, value in data.items()}
    for name in ['BUILD_OUTPUTS.json', 'BUILD_PACKAGE_CHECK.json']:
        members[name] = ((args.out / name).read_bytes(), 0o644)
    provenance = args.inputs / 'provenance'
    require(provenance.is_dir() and not provenance.is_symlink(), 'compiler provenance directory missing')
    approved = {Path('provenance') / name for name in receipt['provenance']['evidence']}
    approved |= {Path(item['command_file']) for item in receipt['provenance']['rmnet_compile_objects'].values()}
    for relative in sorted(approved):
        content = common.regular(args.inputs / relative)
        output = args.out / relative
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_bytes(content)
        members[relative.as_posix()] = (content, 0o644)
    members['READ_ME.txt'] = (
        b'VEUX CASS R11 real full-build evidence. RMNET is built in; there are no external driver payloads.\n'
        b'vmlinux is identified by hash and verified against Image; its large debug ELF is retained in the build inputs.\n'
        b'modules.builtin is the genuine vendor-build metadata and may omit hard obj-y RMNET targets.\n'
        b'Driver presence is proven by final ELF/Image bytes and the two resolved level-6 initcalls.\n'
        b'Boot and ROM runtime behavior require a device test.\n', 0o644)
    common.write_zip(args.out / RAW_NAME, members)
    result = {'status': 'RAW_BUILTIN_VALIDATED', 'origin': receipt['origin'],
              'evidence_mode': receipt['provenance']['evidence_mode'], 'rmnet_mode': 'builtin',
              'kernel_release': checks['kernel_release'], 'kernel_notes_sha256': checks['kernel_notes_sha256'],
              'device_test': False, 'external_rmnet_payload': False,
              'boot_packaging': 'NOT_REQUESTED_PRIVATE_INPUT_REQUIRED',
              'raw_archive': {'file': RAW_NAME, **record(args.out / RAW_NAME)}}
    if all(private):
        boot, boot_report = common.make_boot(args, data, checks)
        installer = make_installer(args, boot, checks)
        result.update(status='BUILTIN_BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED',
                      boot_packaging='COMPLETED', boot_sha256=boot_report['boot_sha256'], installer=installer)
    companions = {}
    for argument, pin_name, output_name in [
        (args.manager_apk, 'manager_apk', 'BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk'),
        (args.nomount_zip, 'nomount_zip', 'NoMount-v2.2.0-release-bf1847f-605.zip')]:
        if argument:
            (args.out / output_name).write_bytes(common.pinned(argument, common.PINS[pin_name]))
            companions[pin_name] = {'file': output_name, **record(args.out / output_name)}
    result['companions'] = companions
    (args.out / 'PACKAGE_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['inputs', 'receipt', 'out']:
        parser.add_argument('--' + name, type=lambda p: Path(p).absolute(), required=True)
    for name in ['base-boot', 'magiskboot', 'avbtool', 'ak3', 'manager-apk', 'nomount-zip']:
        parser.add_argument('--' + name, type=lambda p: Path(p).absolute())
    args = parser.parse_args()
    try:
        print(json.dumps(build(args), indent=2))
    except Exception as error:
        print('BUILTIN_PACKAGING_BLOCKED: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
