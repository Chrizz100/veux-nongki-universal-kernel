#!/usr/bin/env python3
"""Rehash built-in packages and enforce the declared CI/local final status."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import zipfile

import boot_common as common
from builtin_validation import file_hash, record
from package_builtin_build import INSTALLER_NAME, RAW_NAME, TEMPLATE_SHA256


def verify(directory, mode, evidence_mode=None):
    result = json.loads((directory / 'PACKAGE_RESULT.json').read_text())
    expected_status = ('RAW_BUILTIN_VALIDATED' if mode == 'raw'
                       else 'BUILTIN_BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED')
    common.require(result.get('status') == expected_status and result.get('device_test') is False,
                   'packaging terminal status not passed')
    common.require(result.get('rmnet_mode') == 'builtin' and result.get('external_rmnet_payload') is False,
                   'wrong RMNET packaging mode')
    receipt = json.loads((directory / 'BUILD_OUTPUTS.json').read_text())
    checks = json.loads((directory / 'BUILD_PACKAGE_CHECK.json').read_text())
    origin = receipt.get('origin'); provenance = receipt.get('provenance', {})
    actual_mode = provenance.get('evidence_mode')
    common.require((origin, actual_mode) in {('same-build-invocation', 'ci'), ('local-native-full-build', 'local-native')},
                   'invalid provenance classification')
    if evidence_mode:
        common.require(actual_mode == evidence_mode, 'CI/local provenance cannot be relabeled')
    common.require(result.get('origin') == checks.get('origin') == origin
                   and result.get('evidence_mode') == checks.get('evidence_mode') == actual_mode,
                   'provenance changed after packaging')
    common.require(checks.get('source_receipt_sha256') == file_hash(directory / 'BUILD_OUTPUTS.json')
                   and checks.get('status') == 'ACTUAL_BUILTIN_IMAGE_AND_INITCALLS_PASS'
                   and checks.get('vmlinux_sha256') == receipt['files']['vmlinux']['sha256']
                   and checks.get('rmnet_compile_objects_validated') == 15
                   and checks.get('image_matches_all_allocated_file_sections') is True,
                   'full ELF/Image/built-in proof missing')
    common.require(set(checks.get('drivers', {})) == {'rmnet_offload', 'rmnet_shs'}
                   and all(x.get('in_image_and_vmlinux') is True and x.get('initcall_level') == 6
                           for x in checks['drivers'].values()), 'two built-in initcalls not proven')
    for name, expected in provenance['evidence'].items():
        common.require(Path(name).name == name and record(directory / 'provenance' / name) == expected,
                       'compiler/source evidence changed')
    for item in provenance['rmnet_compile_objects'].values():
        path = Path(item['command_file'])
        common.require(not path.is_absolute() and '..' not in path.parts
                       and record(directory / path) == item['command_record'], 'compile-command evidence changed')
    raw = result.get('raw_archive', {})
    common.require(raw.get('file') == RAW_NAME and record(directory / RAW_NAME) == {k: raw[k] for k in ['sha256', 'bytes']},
                   'raw archive changed')
    with zipfile.ZipFile(directory / RAW_NAME) as archive:
        names = archive.namelist()
        common.require(len(names) == len(set(names)) and archive.testzip() is None, 'invalid raw archive')
        common.require(not any(n.endswith('.ko') or n.startswith('rmnet/') for n in names), 'external driver archive forbidden')
        for name, expected in receipt['files'].items():
            if name == 'vmlinux':
                continue
            value = archive.read(name)
            common.require(len(value) == expected['bytes'] and common.sha(value) == expected['sha256'], 'raw member changed: ' + name)
        for name in ['BUILD_OUTPUTS.json', 'BUILD_PACKAGE_CHECK.json']:
            common.require(archive.read(name) == (directory / name).read_bytes(), 'raw evidence member changed: ' + name)
    names = [RAW_NAME, 'BUILD_OUTPUTS.json', 'BUILD_PACKAGE_CHECK.json', 'PACKAGE_RESULT.json']
    if mode == 'boot':
        common.require(file_hash(directory / 'boot.img') == result['boot_sha256'], 'boot output changed')
        item = result['installer']
        common.require(item['file'] == INSTALLER_NAME and record(directory / INSTALLER_NAME) == {k: item[k] for k in ['sha256', 'bytes']},
                       'installer output changed')
        common.require(item.get('external_rmnet_payload') is False and item.get('nomount_backup_readback_logic_preserved') is True,
                       'installer contract changed')
        with zipfile.ZipFile(directory / INSTALLER_NAME) as archive:
            members = archive.namelist()
            common.require(len(members) == len(set(members)) and archive.testzip() is None, 'installer archive corrupt')
            common.require(not any(n.endswith('.ko') or n.startswith('payload/rmnet/') for n in members), 'external driver payload forbidden')
            common.require(common.sha(archive.read('payload/boot.img')) == result['boot_sha256'], 'installer boot differs')
            template = common.pinned(Path(__file__).parent / 'assets/anykernel_builtin.sh.in', TEMPLATE_SHA256)
            script = template.replace(b'@BOOT_SHA256@', result['boot_sha256'].encode())
            common.require(archive.read('anykernel.sh') == script, 'installer template changed')
        boot = json.loads((directory / 'BOOT_PACKAGE_CHECK.json').read_text())
        common.require(boot.get('boot_sha256') == result['boot_sha256']
                       and boot.get('magiskboot_roundtrip_identical') is True
                       and boot.get('independent_salted_hash') is True
                       and boot.get('ramdisk_unchanged') is True, 'boot/AVB proof missing')
        names += ['boot.img', INSTALLER_NAME, 'BOOT_PACKAGE_CHECK.json', 'INSTALLER_PACKAGE_CHECK.json']
    for key, item in result.get('companions', {}).items():
        common.require(key in ('manager_apk', 'nomount_zip') and Path(item['file']).name == item['file'], 'unknown companion')
        common.require(file_hash(directory / item['file']) == item['sha256'] == common.PINS[key], 'official companion changed')
        common.require((directory / item['file']).stat().st_size == item['bytes'], 'companion size changed')
        names.append(item['file'])
    files = {name: record(directory / name) for name in names}
    for path in sorted((directory / 'provenance').rglob('*')):
        if path.is_file():
            files[path.relative_to(directory).as_posix()] = record(path)
    manifest = {'status': expected_status, 'origin': origin, 'evidence_mode': actual_mode,
                'rmnet_mode': 'builtin', 'device_test': False, 'files': files}
    (directory / 'FINAL_OUTPUT_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (directory / 'SHA256SUMS').write_text(''.join(item['sha256'] + '  ' + name + '\n' for name, item in files.items()))
    print(expected_status + '; EVIDENCE_MODE=' + actual_mode)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--mode', choices=['raw', 'boot'], required=True)
    parser.add_argument('--evidence-mode', choices=['ci', 'local-native'])
    args = parser.parse_args()
    verify(args.directory, args.mode, args.evidence_mode)
