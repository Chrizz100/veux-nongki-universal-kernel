#!/usr/bin/env python3
"""Validate actual built-in RMNET outputs, independently of receipt assertions."""
from __future__ import annotations

import hashlib
import json
import mmap
from pathlib import Path
import re
import struct

import boot_common as common

REQUIRED = ('Image', 'actual-build.config', 'System.map', 'Module.symvers',
            'veux.dtb', 'vmlinux', 'modules.builtin', 'modules.order')
CONFIG_SHA256 = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
BAKASU_MARKER = 'v4.2.0-rc3-2cbbcc23@BakaSU'
INIT_FUNCTIONS = {'rmnet_offload': 'DATARMNETb1c42acd9c', 'rmnet_shs': 'DATARMNET163e93649e'}
BUILTIN_PATHS = {name: 'techpack/datarmnet-ext/' + folder + '/' + name + '.ko'
                 for name, folder in [('rmnet_offload', 'offload'), ('rmnet_shs', 'shs')]}
RMNET_SOURCES = tuple('techpack/datarmnet-ext/' + folder + '/' + stem + '.c'
                     for folder, stems in [('offload', ('rmnet_offload_engine', 'rmnet_offload_knob',
                         'rmnet_offload_main', 'rmnet_offload_state', 'rmnet_offload_stats', 'rmnet_offload_tcp', 'rmnet_offload_udp')),
                         ('shs', ('rmnet_shs_common', 'rmnet_shs_config', 'rmnet_shs_freq', 'rmnet_shs_main',
                         'rmnet_shs_modules', 'rmnet_shs_wq', 'rmnet_shs_wq_genl', 'rmnet_shs_wq_mem'))]
                     for stem in stems)
require = common.require


def file_hash(path):
    require(path.is_file() and not path.is_symlink(), f'not a regular input: {path}')
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def record(path):
    return {'sha256': file_hash(path), 'bytes': path.stat().st_size}


def compile_command_check(text, source):
    lines = [line.split(' := ', 1)[1] for line in text.splitlines() if line.startswith('cmd_') and ' := ' in line]
    require(len(lines) == 1, 'ambiguous compiler command: ' + source)
    command = lines[0]
    require(not re.search(r'(^|\s)-DMODULE(?:=\S+)?(?:\s|$)', command), 'RMNET still compiled as a loadable module: ' + source)
    for flag in ['-flto=thin', '-fsanitize=cfi', '-fsanitize-cfi-cross-dso', '-fsanitize=shadow-call-stack', '-fstack-protector-strong']:
        require(flag in command.split(), 'missing compiler protection ' + flag + ': ' + source)
    require(source in command and ' -c ' in command and ' -o ' in command, 'compile command/source mismatch')
    return command


def _cstring(blob, offset):
    require(0 <= offset < len(blob), 'ELF string offset out of bounds')
    stop = blob.find(b'\0', offset)
    require(stop >= offset, 'unterminated ELF string')
    return blob[offset:stop].decode('utf-8')


def system_symbols(text):
    rows = {}
    for line in text.splitlines():
        fields = line.split()
        require(len(fields) == 3, 'invalid System.map row')
        rows.setdefault(fields[2], []).append((int(fields[0], 16), fields[1]))
    return rows


def elf_builtin_check(path, image, system_map):
    """Prove Image bytes correspond to a final kernel ELF and its initcall slots.

    Loadable file-backed sections reproduce objcopy -O binary, while zero gaps
    and the final length prevent an unrelated Image being paired with vmlinux.
    Debug sections stay memory-mapped; the 600+ MiB file is never copied to RAM.
    """
    smap = system_symbols(system_map)
    with path.open('rb') as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as elf:
        require(elf[:7] == b'\x7fELF\x02\x01\x01', 'vmlinux is not ELF64 little endian')
        header = struct.unpack_from('<HHIQQQIHHHHHH', elf, 16)
        # CONFIG_RELOCATABLE=y makes this KASLR kernel an ET_DYN image. ET_REL
        # is only a partial link and must never pass as a completed kernel.
        require(header[0] in (2, 3) and header[1] == 183, 'vmlinux must be final AArch64 ET_EXEC/ET_DYN, not ET_REL')
        offset, width, count, names_index = header[5], header[10], header[11], header[12]
        require(width == 64 and count and offset + count * width <= len(elf), 'invalid ELF section table')
        rows = [struct.unpack_from('<IIQQQQIIQQ', elf, offset + i * width) for i in range(count)]
        require(names_index < count, 'invalid ELF section name index')
        names_row = rows[names_index]
        names = elf[names_row[4]:names_row[4] + names_row[5]]
        sections = {}
        for row in rows:
            name = _cstring(names, row[0])
            if name:
                require(name not in sections, 'duplicate ELF section name')
                require(row[1] == 8 or row[4] + row[5] <= len(elf), 'ELF section out of bounds')
                sections[name] = row
        require('.symtab' in sections, 'vmlinux symbol table absent')
        sym = sections['.symtab']
        require(sym[9] == 24 and sym[5] % 24 == 0 and sym[6] < len(rows), 'invalid ELF symbols')
        sr = rows[sym[6]]
        strings = elf[sr[4]:sr[4] + sr[5]]
        wanted = {'_text', '__start_notes', '__stop_notes', '__initcall6_start', '__initcall7_start'}
        relevant = {}
        undefined = []
        for pos in range(sym[4], sym[4] + sym[5], 24):
            no, info, other, index, value, size = struct.unpack_from('<IBBHQQ', elf, pos)
            name = _cstring(strings, no)
            if index == 0 and info >> 4 == 1 and name:
                undefined.append(name)
            if name in wanted or name.startswith('__initcall_') or any(name.startswith(v) for v in INIT_FUNCTIONS.values()):
                relevant.setdefault(name, []).append({'value': value, 'size': size, 'index': index, 'type': info & 15})
        require(not undefined, 'unresolved strong symbols in final vmlinux: ' + repr(undefined[:10]))

        def one(name):
            require(len(relevant.get(name, [])) == 1, 'missing/ambiguous vmlinux symbol: ' + name)
            item = relevant[name][0]
            require(item['index'] and len(smap.get(name, [])) == 1 and smap[name][0][0] == item['value'],
                    'System.map does not match vmlinux symbol: ' + name)
            return item

        base = one('_text')['value']
        alloc = []
        for name, row in sections.items():
            if row[2] & 2 and row[1] != 8 and row[5] and name not in {'.note', '.note.gnu.build-id', '.comment'}:
                lo, hi = row[3] - base, row[3] - base + row[5]
                require(0 <= lo < hi <= len(image), 'allocated section outside Image: ' + name)
                require(image[lo:hi] == elf[row[4]:row[4] + row[5]], 'Image/vmlinux section mismatch: ' + name)
                alloc.append((lo, hi, name))
        end = 0
        for lo, hi, name in sorted(alloc):
            require(lo >= end, 'overlapping allocated sections')
            require(not any(image[end:lo]), 'nonzero Image padding')
            end = hi
        require(end == len(image), 'Image has unexplained trailing bytes')
        notes_lo, notes_hi = one('__start_notes')['value'] - base, one('__stop_notes')['value'] - base
        require(0 <= notes_lo < notes_hi <= len(image), 'invalid kernel notes range')
        notes = image[notes_lo:notes_hi]
        build_id = common.note_build_id(notes)
        level_lo, level_hi = one('__initcall6_start')['value'], one('__initcall7_start')['value']
        require(base <= level_lo < level_hi, 'invalid device-initcall level range')
        drivers = {}
        for driver, function in INIT_FUNCTIONS.items():
            pattern = re.compile(r'^__initcall_(?:[0-9]+_[0-9]+_)?' + function + r'6(?:\..+)?$')
            matches = [name for name in relevant if pattern.fullmatch(name)]
            require(len(matches) == 1, 'missing/ambiguous built-in initcall for ' + driver)
            name = matches[0]
            entry = one(name)
            require(entry['size'] == 8 and entry['type'] == 1, 'initcall is not a 64-bit function pointer')
            require(level_lo <= entry['value'] and entry['value'] + 8 <= level_hi, 'driver initcall outside level 6')
            offset = entry['value'] - base
            pointer = struct.unpack_from('<Q', image, offset)[0]
            targets = []
            function_name = re.compile(r'^' + function + r'(?:\$[0-9a-f]+)?(?:\.cfi_jt)?$')
            for fn, symbols in relevant.items():
                # ThinLTO uniquifies a static initializer as name$<hash>.
                # The address-taken pointer uses its real .cfi_jt entry.
                if function_name.fullmatch(fn):
                    for item in symbols:
                        if item['value'] == pointer and item['type'] == 2 and 0 < item['index'] < len(rows):
                            section = rows[item['index']]
                            require(section[2] & 4 and section[3] <= pointer < section[3] + section[5], 'initializer is not executable')
                            require(any(v == pointer for v, kind in smap.get(fn, [])), 'initializer missing in System.map')
                            targets.append(fn)
            require(targets, 'initcall pointer does not target its RMNET initializer/CFI entry')
            cfi_branches = []
            for fn in targets:
                if fn.endswith('.cfi_jt'):
                    opcode = struct.unpack_from('<I', image, pointer - base)[0]
                    require(opcode & 0xfc000000 == 0x14000000, 'CFI entry is not an AArch64 B instruction')
                    immediate = opcode & 0x03ffffff
                    if immediate & 0x02000000:
                        immediate -= 0x04000000
                    branch_target = pointer + immediate * 4
                    body = fn.removesuffix('.cfi_jt')
                    require(any(item['value'] == branch_target and item['type'] == 2
                                for item in relevant.get(body, [])), 'CFI branch does not reach its own initializer body')
                    cfi_branches.append({'entry_symbol': fn, 'body_symbol': body, 'body_address': hex(branch_target)})
            drivers[driver] = {'initcall': name, 'initcall_address': hex(entry['value']),
                               'initcall_image_offset': offset, 'target_address': hex(pointer),
                               'target_symbols': sorted(set(targets)), 'initcall_level': 6,
                               'in_image_and_vmlinux': True, 'cfi_entry_to_initializer_branch': cfi_branches}
        return {'elf_type': 'AARCH64_ET_DYN' if header[0] == 3 else 'AARCH64_ET_EXEC', 'image_matches_all_allocated_file_sections': True,
                'allocated_sections_checked': len(alloc), 'no_unresolved_strong_symbols': True,
                'kernel_notes_sha256': common.sha(notes), 'kernel_notes_offset': notes_lo,
                'kernel_notes_bytes': len(notes), 'kernel_build_id': build_id, 'drivers': drivers}


def validate_inputs(inputs, receipt_path):
    metadata = json.loads(common.regular(receipt_path))
    require(metadata.get('schema') == 'veux-builtin-build-output-v1', 'unsupported built-in receipt schema')
    require(metadata.get('rmnet_mode') == 'builtin', 'built-in receipt mode required')
    provenance = metadata.get('provenance', {})
    origin = metadata.get('origin')
    require((origin, provenance.get('evidence_mode')) in {
        ('same-build-invocation', 'ci'), ('local-native-full-build', 'local-native')}, 'origin/evidence mode mismatch')
    require(provenance.get('kernel_compile_exit') == 0 and provenance.get('full_kernel_linked') is True,
            'successful full kernel compile/link provenance absent')
    require(provenance.get('kernel_compile_reused') is False and provenance.get('source_checks_passed') is True,
            'fresh compile/source preservation provenance absent')
    require(provenance.get('kernel_command'), 'kernel compile command absent')
    require(re.fullmatch('[0-9a-f]{40}', provenance.get('source_commit', '')), 'source Git commit absent')
    evidence = provenance.get('evidence', {})
    require({'BUILD_COMMAND.json', 'FULL_BUILD.log', 'SOURCE_CONTRACT.json'} <= set(evidence), 'compiler/source evidence absent')
    for name, expected in evidence.items():
        require(Path(name).name == name, 'invalid evidence filename')
        require(record(inputs / 'provenance' / name) == expected, 'compiler/source evidence changed: ' + name)
    require(evidence['SOURCE_CONTRACT.json']['sha256'] == provenance.get('source_contract_sha256'), 'source contract provenance mismatch')
    compile_objects = provenance.get('rmnet_compile_objects', {})
    require(set(compile_objects) == set(RMNET_SOURCES), '15 actual RMNET compile receipts required')
    for source, item in compile_objects.items():
        relative = Path(item['command_file'])
        require(not relative.is_absolute() and '..' not in relative.parts, 'invalid command-evidence path')
        path = inputs / relative
        require(record(path) == item['command_record'], 'compiler command evidence changed: ' + source)
        compile_command_check(path.read_text(), source)
        require(item.get('object_format') == 'LLVM_BITCODE' and item.get('object_record', {}).get('bytes', 0) > 0,
                'real ThinLTO object evidence absent: ' + source)
    require(set(metadata.get('files', {})) == set(REQUIRED), 'built-in output list differs (no .ko accepted)')
    require(not list(inputs.rglob('*.ko')), 'external modules must not be staged as built-in outputs')
    data = {}
    for name in REQUIRED:
        path = inputs / name
        require(record(path) == metadata['files'][name], 'receipt/content mismatch: ' + name)
        if name != 'vmlinux':
            data[name] = common.regular(path)
    image = data['Image']
    require(image[56:60] == b'ARM\x64', 'not an ARM64 Image')
    require(common.sha(data['actual-build.config']) == CONFIG_SHA256, 'proven configuration changed')
    require(common.embedded_config(image) == data['actual-build.config'], 'Image embedded config mismatch')
    config = set(data['actual-build.config'].decode().splitlines())
    flags = {'CONFIG_SCHED_CASS=y', 'CONFIG_CFI_CLANG=y', 'CONFIG_THINLTO=y', 'CONFIG_KSU=y',
             'CONFIG_KSU_SUSFS=y', 'CONFIG_MODVERSIONS=y', 'CONFIG_MODULES=y',
             'CONFIG_STACKPROTECTOR_STRONG=y', '# CONFIG_MODULE_FORCE_LOAD is not set',
             '# CONFIG_MODULE_FORCE_UNLOAD is not set'}
    require(flags <= config and 'CONFIG_SCHED_WALT=y' not in config, 'required CASS/CFI/SUSFS policy missing')
    releases = re.findall(rb'Linux version ([0-9]+\.[0-9]+\.[^ \x00\n]+) ', image)
    require(len(set(releases)) == 1 and releases[0].decode() == metadata['kernel_release'], 'kernel release mismatch')
    require(metadata.get('bakasu_marker') == BAKASU_MARKER and image.count(BAKASU_MARKER.encode()) == 1, 'BakaSU marker mismatch')
    require(metadata.get('nomount_api') == 22, 'NoMount API 22 required')
    require(common.sha(data['veux.dtb']) == common.PINS['dtb'], 'DTB changed')
    builtin = data['modules.builtin'].decode().splitlines()
    order = data['modules.order'].decode().splitlines()
    builtin_metadata = {}
    for name, path in BUILTIN_PATHS.items():
        # This vendor 5.4 scripts/Makefile.modbuiltin collects obj-Y from
        # tristate.conf, not hard-coded obj-y. Preserve the genuine list;
        # absence here is not evidence against the independently proven ELF
        # initcall. Never synthesize module metadata or add an obj-Y source hack.
        require(builtin.count(path) <= 1, 'duplicate modules.builtin entry for ' + name)
        builtin_metadata[name] = {'path': path, 'occurrences': builtin.count(path)}
        require(not any(Path(line).name == name + '.ko' for line in order), 'RMNET remains in external modules.order')
    linked = elf_builtin_check(inputs / 'vmlinux', image, data['System.map'].decode())
    checks = {'status': 'ACTUAL_BUILTIN_IMAGE_AND_INITCALLS_PASS', 'kernel_release': metadata['kernel_release'],
              'image_sha256': common.sha(image), 'config_sha256': CONFIG_SHA256,
              'symvers_sha256': common.sha(data['Module.symvers']), 'vmlinux_sha256': metadata['files']['vmlinux']['sha256'],
              'dtb_unchanged': True, 'rmnet_mode': 'builtin', 'external_rmnet_payload': False,
              'source_receipt_sha256': file_hash(receipt_path), 'origin': origin,
              'evidence_mode': provenance['evidence_mode'], 'device_test': False, **linked}
    checks['rmnet_compile_objects_validated'] = len(compile_objects)
    checks['modules_builtin_metadata'] = {
        'actual_rmnet_entries': builtin_metadata,
        'authoritative_driver_presence_proof': 'ELF/Image bytes and resolved device initcalls',
        'vendor_5_4_limitation': 'Makefile.modbuiltin lists obj-Y from tristate.conf; the hard obj-y targets need not appear.',
        'output_list_modified': False,
    }
    if 'modules.builtin.modinfo' in evidence:
        modinfo = (inputs / 'provenance/modules.builtin.modinfo').read_bytes().split(b'\0')
        checks['modules_builtin_modinfo'] = {
            driver: {'gpl_v2_license_present': (driver + '.license=GPL v2').encode() in modinfo,
                     'parameter_records': sum(entry.startswith((driver + '.parm').encode()) for entry in modinfo)}
            for driver in INIT_FUNCTIONS
        }
    return data, metadata, checks
