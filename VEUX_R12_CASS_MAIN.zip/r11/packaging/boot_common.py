#!/usr/bin/env python3
"""Unchanged R9 boot/container helpers; no external RMNET packaging code."""

from __future__ import annotations

import argparse

import gzip

import hashlib

import importlib.machinery

import importlib.util

import json

import re

import stat

import struct

import subprocess

import sys

import zipfile

from pathlib import Path

PINS = {
    'base_boot': 'fe7093b0bf154e162c4474a4ded3c9a89be431bc8f12b0d0be1738b88091a263',
    'base_kernel': '32588b4f06dc122c6582729c63b62ef68acdeca0806c7d351f6ef7238f0c6ac3',
    'dtb': '42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
    'raw_ramdisk': 'efa8d4af76e0582d48ddb0ab4cd60c94da18eec2b607eac41ad2fca5620b56ba',
    'decoded_ramdisk': 'aa8cc84af0da90cc29201f0f21a76891e98b5e759122ee813b450d3e71d09321',
    'magiskboot': 'a18ecbd7981179494b7d281453d6c4e25b5c719e7d2ef7f6eba3c6be3043c58e',
    'avbtool': '2ae13d6926094c86e67ea124c93990caaf67fc9b6e4e32cdf55c9c2cd3f36df6',
    'manager_apk': '43ccd6ec08844bf656b0800d84567c4f04412203446e6dada9570008f180fe25',
    'nomount_zip': 'd40277cb8f495b78711fb72e5f19a79ab2627eba2f0eb2aec60b5fc8019fae83',
}

AK3_COMMIT = 'af770f7b16cf8f8eb7c68614b2a693b3b361c90c'

AK3_TREE = 'c6af9eb7018bce852819ab1585de426a426e6806'

PARTITION_SIZE = 134217728

PAGE = 4096

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def regular(path):
    require(path.is_file() and not path.is_symlink(), f'not a regular input file: {path.name}')
    return path.read_bytes()

def output_record(path):
    data = regular(path)
    return {'file': path.name, 'sha256': sha(data), 'bytes': len(data)}

def pinned(path, expected):
    data = regular(path)
    require(sha(data) == expected, f'input checksum differs: {path.name}')
    return data

def align(value, boundary=PAGE):
    return (value + boundary - 1) // boundary * boundary

def embedded_config(image):
    require(image.count(b'IKCFG_ST') == 1, 'missing or ambiguous embedded configuration')
    start = image.index(b'IKCFG_ST') + 8
    stop = image.index(b'IKCFG_ED', start)
    return gzip.decompress(image[start:stop])

def note_build_id(data):
    """Validate aligned ELF note records before deriving a runtime generation."""
    offset, build_ids = 0, []
    while offset < len(data):
        require(offset + 12 <= len(data), 'truncated ELF note header')
        namesize, descsize, kind = struct.unpack_from('<III', data, offset)
        name_start = offset + 12
        desc_start = align(name_start + namesize, 4)
        next_note = align(desc_start + descsize, 4)
        require(namesize and next_note <= len(data), 'invalid ELF note bounds')
        name = data[name_start:name_start + namesize]
        if name == b'GNU\0' and kind == 3:
            require(0 < descsize <= 64, 'invalid GNU build ID size')
            build_ids.append(data[desc_start:desc_start + descsize].hex())
        offset = next_note
    require(len(build_ids) == 1, 'missing or ambiguous GNU build ID')
    return build_ids[0]

def write_zip(path, members):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (data, mode) in sorted(members.items()):
            require(not name.startswith('/') and '..' not in Path(name).parts, 'invalid output archive path')
            info = zipfile.ZipInfo(name, (2026, 10, 28, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), 'archive integrity failed')
        for name, (data, mode) in members.items():
            info = archive.getinfo(name)
            require(archive.read(name) == data and stat.S_ISREG(info.external_attr >> 16), 'archive member mismatch')
            require((info.external_attr >> 16) & 0o777 == mode, 'archive member mode mismatch')

def run(command, cwd, log):
    result = subprocess.run([str(x) for x in command], cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    log.write_text(result.stdout)
    require(result.returncode == 0, f'command failed: {log.name}; exit={result.returncode}')
    return result.stdout

def boot_layout(data):
    require(len(data) == PARTITION_SIZE and data[:8] == b'ANDROID!', 'unsupported boot container')
    ksize, rsize, os_version, header_size = struct.unpack_from('<4I', data, 8)
    require(struct.unpack_from('<I', data, 40)[0] == 3 and header_size == 1580, 'boot must use proven header v3')
    roff = PAGE + align(ksize)
    end = roff + align(rsize)
    require(ksize > 64 and rsize > 0 and end < PARTITION_SIZE - 65536, 'invalid boot payload sizes')
    require(data[PAGE + 56:PAGE + 60] == b'ARM\x64', 'boot payload is not ARM64 Image')
    return {'kernel_size': ksize, 'ramdisk_size': rsize, 'ramdisk_offset': roff, 'payload_end': end,
            'os_version': os_version, 'header_sha256': sha(data[:PAGE])}

def avb_state(module, image):
    footer, header, descriptors, size = module.Avb()._parse_image(module.ImageHandler(str(image)))
    require(footer and header.algorithm_type == 0 and header.authentication_data_block_size == 0, 'unexpected AVB policy')
    require(header.flags == header.rollback_index == header.rollback_index_location == 0, 'unexpected AVB flags/rollback policy')
    hashes = [x for x in descriptors if isinstance(x, module.AvbHashDescriptor)]
    props = [x for x in descriptors if isinstance(x, module.AvbPropertyDescriptor)]
    require(len(hashes) == 1 and len(hashes) + len(props) == len(descriptors), 'unexpected AVB descriptors')
    desc = hashes[0]
    require(desc.partition_name == 'boot' and desc.hash_algorithm == 'sha256' and desc.flags == 0, 'unexpected boot AVB hash contract')
    text = lambda value: value.decode() if isinstance(value, bytes) else value
    return {'salt': desc.salt.hex(), 'digest': desc.digest.hex(), 'hash_image_size': desc.image_size,
            'props': [[text(x.key), text(x.value)] for x in props], 'original_size': footer.original_image_size,
            'algorithm': 'NONE', 'flags': header.flags, 'rollback_index': header.rollback_index,
            'rollback_index_location': header.rollback_index_location, 'release_string': header.release_string,
            'non_hash_descriptors': [sha(x.encode()) for x in props], 'partition_size': size}

def make_boot(args, data, checks):
    base = pinned(args.base_boot, PINS['base_boot'])
    pinned(args.magiskboot, PINS['magiskboot'])
    avbtool = args.avbtool.resolve(strict=True)
    pinned(avbtool, PINS['avbtool'])
    before = boot_layout(base)
    old_kernel = base[PAGE:PAGE + before['kernel_size']]
    require(sha(old_kernel) == PINS['base_kernel'], 'private base kernel changed')
    require(embedded_config(old_kernel) == data['actual-build.config'], 'new config differs from proven private boot configuration')
    raw_ramdisk = base[before['ramdisk_offset']:before['ramdisk_offset'] + before['ramdisk_size']]
    require(sha(raw_ramdisk) == PINS['raw_ramdisk'], 'private ramdisk changed')
    loader = importlib.machinery.SourceFileLoader('pinned_veux_avbtool', str(avbtool))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    avb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(avb)
    original_avb = avb_state(avb, args.base_boot)
    require(original_avb['original_size'] == before['payload_end'], 'base AVB payload size mismatch')
    image = data['Image']
    header = bytearray(base[:PAGE])
    struct.pack_into('<I', header, 8, len(image))
    payload = bytes(header) + image + bytes(align(len(image)) - len(image))
    payload += raw_ramdisk + bytes(align(len(raw_ramdisk)) - len(raw_ramdisk))
    require(len(payload) < PARTITION_SIZE - 65536, 'new kernel and preserved ramdisk exceed boot partition')
    directory = args.out / 'boot_check'
    directory.mkdir()
    logs = directory / 'logs'; logs.mkdir()
    output = args.out / 'boot.img'
    output.write_bytes(payload)
    command = [sys.executable, avbtool, 'add_hash_footer', '--image', output,
               '--partition_name', 'boot', '--partition_size', str(PARTITION_SIZE),
               '--hash_algorithm', 'sha256', '--algorithm', 'NONE', '--salt', original_avb['salt']]
    for key, value in original_avb['props']:
        command.extend(['--prop', f'{key}:{value}'])
    run(command, directory, logs / 'avb_generation.log')
    final = output.read_bytes()
    after = boot_layout(final)
    require(final[:8] + final[12:PAGE] == base[:8] + base[12:PAGE], 'boot header changed outside kernel length')
    require(final[PAGE:PAGE + after['kernel_size']] == image, 'final kernel content mismatch')
    require(final[after['ramdisk_offset']:after['ramdisk_offset'] + after['ramdisk_size']] == raw_ramdisk,
            'final raw ramdisk differs')
    final_avb = avb_state(avb, output)
    for key in ('salt', 'props', 'algorithm', 'flags', 'rollback_index', 'rollback_index_location', 'release_string', 'non_hash_descriptors', 'partition_size'):
        require(final_avb[key] == original_avb[key], f'AVB metadata changed: {key}')
    require(final_avb['hash_image_size'] == final_avb['original_size'] == len(payload), 'final AVB range differs')
    require(final_avb['digest'] == sha(bytes.fromhex(final_avb['salt']) + final[:len(payload)]), 'independent AVB hash mismatch')
    run([sys.executable, avbtool, 'verify_image', '--image', output], directory, logs / 'avb_verify.log')
    for label, options, expected in [('raw', ['-n', '-h'], PINS['raw_ramdisk']), ('decoded', ['-h'], PINS['decoded_ramdisk'])]:
        work = directory / label; work.mkdir()
        run([args.magiskboot, 'unpack', *options, output], work, logs / f'magiskboot_{label}.log')
        require((work / 'kernel').read_bytes() == image, 'MagiskBoot extracted kernel mismatch')
        require(sha((work / 'ramdisk.cpio').read_bytes()) == expected, 'MagiskBoot ramdisk mismatch')
    roundtrip_dir = directory / 'roundtrip'; roundtrip_dir.mkdir()
    roundtrip = roundtrip_dir / 'boot.img'
    run([args.magiskboot, 'repack', '-n', output, roundtrip], directory / 'raw', logs / 'magiskboot_roundtrip.log')
    require(roundtrip.read_bytes() == final, 'MagiskBoot byte roundtrip mismatch')
    run([sys.executable, avbtool, 'verify_image', '--image', roundtrip], directory, logs / 'roundtrip_avb_verify.log')
    roundtrip.unlink()
    require(sha(regular(args.base_boot)) == PINS['base_boot'], 'private base changed')
    report = {'status': 'STATIC_BOOT_AND_ROUNDTRIP_PASS_DEVICE_UNTESTED', 'boot_sha256': sha(final),
              'boot_bytes': len(final), 'image_sha256': checks['image_sha256'],
              'kernel_notes_sha256': checks['kernel_notes_sha256'], 'ramdisk_unchanged': True,
              'header_changes': ['kernel_size'] if len(image) != before['kernel_size'] else [],
              'avb_metadata_preserved': True, 'independent_salted_hash': True,
              'magiskboot_roundtrip_identical': True, 'private_base_unchanged': True,
              'base_sha256': PINS['base_boot'], 'before': before, 'after': after,
              'device_test': False, 'private_ramdisk_in_generated_boot': True}
    (args.out / 'BOOT_PACKAGE_CHECK.json').write_text(json.dumps(report, indent=2) + '\n')
    return final, report
