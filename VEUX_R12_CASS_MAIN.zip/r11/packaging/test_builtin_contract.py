#!/usr/bin/env python3
"""Meaningful host checks; never fabricate a positive full-kernel fixture."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

import boot_common as common
from builtin_validation import RMNET_SOURCES, compile_command_check, elf_builtin_check

HERE = Path(__file__).resolve().parent


def must_reject(function, message):
    try:
        function()
    except ValueError as error:
        common.require(message in str(error), 'unexpected rejection: ' + str(error))
        return str(error)
    raise ValueError('invalid fixture was accepted')


def run(args):
    checks = {}
    preserved = json.loads((HERE / 'BOOT_HELPERS_PRESERVATION.json').read_text())
    reference = (args.reference_pipeline / 'package_build.py').read_text()
    copied = (HERE / 'boot_common.py').read_text()
    original_functions = {n.name: ast.get_source_segment(reference, n) for n in ast.parse(reference).body if isinstance(n, ast.FunctionDef)}
    copied_functions = {n.name: ast.get_source_segment(copied, n) for n in ast.parse(copied).body if isinstance(n, ast.FunctionDef)}
    for name, expected in preserved['copied_functions_exact_source_sha256'].items():
        common.require(copied_functions[name] == original_functions[name], 'boot/AVB function changed: ' + name)
        common.require(hashlib.sha256(copied_functions[name].encode()).hexdigest() == expected, 'function pin mismatch')
    checks['thirteen_boot_container_functions_byte_identical_to_R9'] = True
    original = (args.reference_pipeline / 'assets/anykernel.sh.in').read_text()
    template = (HERE / 'assets/anykernel_builtin.sh.in').read_text()
    expected = original.replace(
        '# VEUX R5 installer R3: prebuilt boot, pinned RMNET data and NoMount 21-to-22 transition.',
        '# VEUX R11: prebuilt boot with built-in RMNET and the preserved NoMount 21-to-22 transition.').replace(
        'kernel.string=VEUX CASS R5 Installer R3 RMNET and NoMount 21-to-22 transition',
        'kernel.string=VEUX CASS R11 Built-in RMNET and NoMount 21-to-22 transition').replace(
        "EXPECTED_RMNET_MANIFEST_SHA256='@RMNET_MANIFEST_SHA256@'\n", '')
    lo = expected.index('# Stage the build-bound data companion even when this exact boot is already\n')
    hi = expected.index('CURRENT_SHA=$(r5_sha "$BLOCK")', lo)
    expected = expected[:lo] + (
        '# Both RMNET drivers are linked into the verified kernel Image.\n'
        '# Existing external generations and launchers remain available for rollback.\n'
        "ui_print 'RMNET offload and SHS are built into this kernel.'\n\n") + expected[hi:]
    common.require(template == expected, 'installer changed outside explicit RMNET staging removal/display fields')
    checks['NoMount605_transition_backup_readback_and_marker_rollback_exactly_preserved'] = True
    common.require('payload/rmnet' not in template and '.ko' not in template, 'external module staging remains')
    subprocess.run(['shellcheck', '--shell=ash', '--severity=warning', str(HERE / 'assets/anykernel_builtin.sh.in')], check=True)
    checks['installer_shellcheck_and_no_external_module_stage'] = True
    if args.candidate_build:
        for source in RMNET_SOURCES:
            relative = Path(source)
            command_file = args.candidate_build / relative.parent / ('.' + relative.stem + '.o.cmd')
            text = command_file.read_text()
            compile_command_check(text, source)
            must_reject(lambda: compile_command_check(text.replace(' := ', ' := -DMODULE ', 1), source), 'still compiled as a loadable module')
            must_reject(lambda: compile_command_check(text.replace('-flto=thin ', '', 1), source), 'missing compiler protection')
        checks['fifteen_real_candidate_commands_and_MODULE_or_LTO_tamper_rejection'] = True
    if args.baseline_build:
        old = args.baseline_build
        image = (old / 'arch/arm64/boot/Image').read_bytes()
        symbols = (old / 'System.map').read_text()
        checks['real_external_module_baseline_rejected'] = must_reject(
            lambda: elf_builtin_check(old / 'vmlinux', image, symbols), 'missing/ambiguous built-in initcall')
        damaged = bytearray(image); damaged[4096] ^= 1
        checks['unrelated_Image_bytes_rejected'] = must_reject(
            lambda: elf_builtin_check(old / 'vmlinux', bytes(damaged), symbols), 'Image/vmlinux section mismatch')
    result = {'status': 'PASS', 'checks': checks, 'positive_built_in_kernel_fixture_fabricated': False,
              'device_execution': False, 'full_candidate_kernel_acceptance': 'SEPARATE_AFTER_COMPILER_COMPLETION'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-pipeline', type=Path, required=True)
    parser.add_argument('--candidate-build', type=Path)
    parser.add_argument('--baseline-build', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    run(parser.parse_args())
