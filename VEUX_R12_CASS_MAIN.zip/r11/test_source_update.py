#!/usr/bin/env python3
"""Regression gates for patch replay and refusal to mutate a different source."""
from pathlib import Path
import tempfile
import unittest

import source_update


class SourceUpdateTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="veux-r11-update-test-")
        self.root = Path(self.temporary.name)
        self.kernel = self.root / "kernel"
        self.kernel.mkdir()
        for relative in source_update.EXPECTED_PATHS:
            target = self.kernel / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes((source_update.HERE / "test_inputs" / relative).read_bytes())
        (self.kernel / "unchanged.txt").write_text("preserved source\n")

    def tearDown(self):
        self.temporary.cleanup()

    def test_exact_patch_and_unchanged_sibling(self):
        result = source_update.apply(self.kernel, self.root / "proof")
        self.assertEqual(result["changed_paths"], sorted(source_update.EXPECTED_PATHS))
        self.assertEqual((self.kernel / "unchanged.txt").read_text(), "preserved source\n")

    def test_no_double_application(self):
        source_update.apply(self.kernel, self.root / "proof")
        before = source_update.inventory(self.kernel)
        with self.assertRaisesRegex(ValueError, "R11_PREIMAGE_MISMATCH:"):
            source_update.apply(self.kernel, self.root / "second-proof")
        self.assertEqual(before, source_update.inventory(self.kernel))

    def test_wrong_source_rejected_before_write(self):
        source = self.kernel / "fs/susfs.c"
        source.write_bytes(source.read_bytes() + b"\n")
        before = source_update.inventory(self.kernel)
        with self.assertRaisesRegex(ValueError, "R11_PREIMAGE_MISMATCH:"):
            source_update.apply(self.kernel, self.root / "proof")
        self.assertEqual(before, source_update.inventory(self.kernel))

    def test_symlink_to_reference_rejected(self):
        source = self.kernel / "fs/susfs.c"
        source.unlink()
        source.symlink_to(source_update.HERE / "test_inputs/fs/susfs.c")
        with self.assertRaisesRegex(ValueError, "R11_SOURCE_NOT_REGULAR:"):
            source_update.apply(self.kernel, self.root / "proof")


if __name__ == "__main__":
    unittest.main()
