#!/usr/bin/env python3
"""Apply the three explicitly pinned R11 source changes to an isolated candidate."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
EXPECTED_PATHS = frozenset(("fs/susfs.c", "techpack/datarmnet-ext/offload/Kbuild",
                            "techpack/datarmnet-ext/shs/Kbuild"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def inventory(root):
    """Content and symlink inventory, excluding Git's internal administration."""
    result = {}
    for directory, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d != ".git")
        for name in sorted(files + [d for d in dirs if (Path(directory) / d).is_symlink()]):
            p = Path(directory) / name
            key = str(p.relative_to(root))
            result[key] = {"symlink": os.readlink(p)} if p.is_symlink() else {
                "bytes": p.stat().st_size, "sha256": sha(p)}
    return result


def apply(kernel, evidence):
    kernel = Path(kernel).resolve(strict=True)
    evidence = Path(evidence)
    evidence.mkdir(parents=True, exist_ok=True)
    report = evidence / "R11_SOURCE_UPDATE.json"
    require(not report.exists(), "R11_SOURCE_UPDATE_ALREADY_RECORDED")
    contract = json.loads((HERE / "SOURCE_CONTRACT.json").read_text())
    require(contract.get("schema") == "veux-r11-source-v1", "R11_CONTRACT_SCHEMA")
    require(set(contract["files"]) == EXPECTED_PATHS, "R11_CHANGED_PATH_SET")
    for relative, item in contract["files"].items():
        p = kernel / relative
        require(p.is_file() and not p.is_symlink(), "R11_SOURCE_NOT_REGULAR:" + relative)
        require(sha(p) == item["before_sha256"], "R11_PREIMAGE_MISMATCH:" + relative)
    patches = []
    for name, digest in sorted(contract["patches"].items()):
        p = HERE / "patches" / name
        require(p.is_file() and not p.is_symlink() and sha(p) == digest, "R11_PATCH_PIN:" + name)
        patches.append(str(p))
    before = inventory(kernel)
    commands = [["git", "apply", "--check", *patches], ["git", "apply", *patches]]
    for command in commands:
        subprocess.run(command, cwd=kernel, check=True, capture_output=True, text=True)
    after = inventory(kernel)
    changed = {p for p in before.keys() | after.keys() if before.get(p) != after.get(p)}
    require(changed == EXPECTED_PATHS, "R11_UNEXPECTED_SOURCE_DELTA:" + repr(sorted(changed)))
    for relative, item in contract["files"].items():
        require(sha(kernel / relative) == item["after_sha256"], "R11_POSTIMAGE_MISMATCH:" + relative)
    proof = {"schema": "veux-r11-source-update-v1", "status": "SOURCE_UPDATE_PASS",
             "source": str(kernel), "changed_paths": sorted(changed),
             "files": {p: {"before": before[p], "after": after[p]} for p in sorted(changed)},
             "inventory_files": len(before), "all_other_source_files_unchanged": True,
             "source_contract_sha256": sha(HERE / "SOURCE_CONTRACT.json"),
             "patches": contract["patches"], "susfs_upstream_commit": contract["susfs_upstream_commit"],
             "rmnet_mode": "built-in", "device_test": False}
    report.write_text(json.dumps(proof, indent=2, sort_keys=True) + "\n")
    return proof


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--kernel", type=Path, required=True)
    p.add_argument("--evidence", type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(apply(a.kernel, a.evidence), indent=2))
