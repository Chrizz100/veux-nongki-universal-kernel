#!/usr/bin/env python3
"""Read-only verification of the pinned VEUX BakaSU port and Spoofed Manager.

The frozen lock is the reproducible input. This script never fetches a floating
branch, changes Git history, patches sources, installs an APK, or flashes a device.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import zipfile


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def run(argv):
    result = subprocess.run(argv, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {argv!r}\n{result.stdout}{result.stderr}")
    return result.stdout.strip()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--lock', type=Path, default=Path(__file__).with_name('BAKASU_LOCK.json'))
    parser.add_argument('--kernelsu', type=Path, required=True)
    parser.add_argument('--manager-apk', type=Path, required=True)
    parser.add_argument('--apksigner-jar', type=Path, required=True)
    parser.add_argument('--build', type=Path, help='Optional compiled kernel output, for config and package-pin check')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    lock = json.loads(args.lock.read_text())
    candidate, source, manager = lock['candidate'], lock['source'], lock['manager']
    root = args.kernelsu.resolve()

    def git(*argv):
        return run(['git', '-C', str(root), *argv])

    def read(relative):
        return (root / relative).read_text()

    actual = {
        'head': git('rev-parse', 'HEAD'),
        'parent': git('rev-parse', 'HEAD^'),
        'tree': git('rev-parse', 'HEAD^{tree}'),
        'upstream_tree': git('rev-parse', source['commit'] + '^{tree}'),
        'tag_commit': git('rev-parse', candidate['tag'] + '^{commit}'),
        'commit_count': int(git('rev-list', '--count', 'HEAD')),
        'shallow': git('rev-parse', '--is-shallow-repository'),
    }
    for observed, expected in [
        ('head', candidate['commit']), ('parent', candidate['parent']),
        ('tree', candidate['tree']), ('upstream_tree', source['tree']),
        ('tag_commit', candidate['tag_commit']), ('commit_count', candidate['commit_count']),
        ('shallow', 'false'),
    ]:
        require(actual[observed] == expected, f"BakaSU {observed} mismatch: {actual[observed]!r} != {expected!r}")
    git('diff', '--quiet', 'HEAD', '--')
    git('merge-base', '--is-ancestor', source['commit'], 'HEAD')
    changed = git('diff', '--name-only', source['commit'], 'HEAD').splitlines()
    require(sorted(changed) == sorted(candidate['protected_local_port_files']), 'Unexpected local port scope')
    require(actual['commit_count'] + 30700 == candidate['version_code'], 'Version/history mismatch')
    # The local port changes only kernel code. Manager, daemon and common UAPI
    # retain the exact official d5e9 sources used for the selected manager run.
    git('diff', '--quiet', source['commit'], 'HEAD', '--', 'manager', 'userspace', 'uapi')
    uapi = read('uapi/supercall.h')
    require(re.search(r'KERNEL_SU_UAPI_VERSION\s*=\s*6\b', uapi), 'Expected UAPI 6 missing')
    signature_header = read('kernel/manager/manager_sign.h')
    require(manager['certificate_sha256'] in signature_header, 'Official manager certificate not accepted')
    require('#define EXPECTED_SIZE_BAKASU 0x377' in signature_header, 'Unexpected certificate size')

    tracker = read('kernel/manager/throne_tracker.c')
    observer = read('kernel/manager/pkg_observer.c')
    require(tracker.count('susfs_parse_priority_app_strings();') == 1, 'Expected exactly one priority-parser integration')
    require('revert_creds(old_cred);\n#ifdef CONFIG_KSU_SUSFS' in tracker, 'Priority-parser placement changed')
    require('susfs_parse_priority_app_strings' not in observer, 'Do not duplicate legacy SUSFS observer hunk')
    require('cb->func = ksu_track_throne_tw_func;' in observer, 'Task-work observer path missing')
    require('track_throne(TRACK_THRONE_FORCE_SYNCHRONOUS);' in observer, 'Synchronous worker tracker missing')
    require('track_throne(TRACK_THRONE_FROM_RENAMEAT | TRACK_THRONE_FORCE_SYNCHRONOUS);' in tracker, 'Native 5.4 rename hook missing')

    raw = args.manager_apk.read_bytes()
    require(len(raw) == manager['apk_bytes'], 'Manager APK size mismatch')
    require(sha256(raw) == manager['apk_sha256'], 'Manager APK identity mismatch: expected the pinned official Spoofed APK')
    with zipfile.ZipFile(args.manager_apk) as apk:
        require(apk.testzip() is None, 'Manager APK ZIP CRC failure')
        daemon = apk.read(manager['embedded_daemon_path'])
    require(len(daemon) == manager['embedded_daemon_bytes'], 'Embedded daemon size mismatch')
    require(sha256(daemon) == manager['embedded_daemon_sha256'], 'Embedded daemon hash mismatch')
    signer = run(['java', '-jar', str(args.apksigner_jar), 'verify', '--verbose', '--print-certs', str(args.manager_apk)])
    require('Verified using v2 scheme (APK Signature Scheme v2): true' in signer, 'APK v2 signature not verified')
    require(manager['certificate_sha256'] in signer, 'APK cryptographic signer mismatch')

    build_checks = None
    if args.build:
        config = (args.build / '.config').read_text()
        for symbol in ('CONFIG_KSU=y', 'CONFIG_KSU_SUSFS=y'):
            require(symbol in config.splitlines(), f'Missing {symbol}')
        command = (args.build / 'drivers/kernelsu/manager/.apk_sign.o.cmd').read_text()
        require('-DKSU_MANAGER_PACKAGE' not in command, 'Package-name override would reject the random Spoofed package')
        build_checks = {'ksu_builtin': True, 'susfs_enabled': True, 'manager_package_override': False}

    evidence_files = sorted((args.lock.parent / 'evidence').glob('*.json'))
    report = {
        'status': 'PASS_PINNED_BAKASU_PORT_AND_OFFICIAL_SPOOFED_MANAGER',
        'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'upstream_observed_at_utc': lock['retrieved_at_utc'],
        'lock_sha256': sha256(args.lock.read_bytes()),
        'source': actual,
        'source_tracked_files_match_pinned_tree': True,
        'port_files': changed,
        'kernel_version_code': candidate['version_code'],
        'uapi': manager['uapi'],
        'manager_apk_sha256': sha256(raw),
        'manager_artifact_id': manager['artifact_id'],
        'manager_package_from_pinned_apk_identity': manager['package'],
        'manager_signature_v2': True,
        'embedded_daemon_sha256': sha256(daemon),
        'observer_review': {
            'priority_hook_in_do_track_throne': True,
            'task_work_calls_force_synchronous_tracker': True,
            'priority_hook_duplicated_in_pkg_observer': False,
            'native_5_4_rename_path_preserved': True,
            'scope': 'Static call-graph identity; native 5.4 manual hook is the active target. No runtime concurrency proof.',
        },
        'build_checks': build_checks,
        'evidence_sha256': {p.name: sha256(p.read_bytes()) for p in evidence_files},
        'complete_kernel_build_or_device_boot_verified': False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    args.output.with_suffix('.apksigner.log').write_text(signer + '\n')
    print(json.dumps({k: report[k] for k in ['status', 'kernel_version_code', 'uapi', 'manager_apk_sha256', 'manager_signature_v2']}, indent=2))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, zipfile.BadZipFile, KeyError) as error:
        print(f'BakaSU pin verification FAILED: {error}', file=sys.stderr)
        sys.exit(1)
