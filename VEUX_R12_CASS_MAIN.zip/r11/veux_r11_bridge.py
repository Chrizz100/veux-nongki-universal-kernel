#!/usr/bin/env python3
"""Invoke the pinned R4 bridge with the explicit R11 precompile hook."""
from pathlib import Path

from source_update import require, sha

BRIDGE_PIN = "97d0c5796c8317a16378661133d5c551f9ab27de222f83c3dd7ab63c97ac1b52"
OLD_HOOK = ("        from cass_r4_build import run_update as __r4_run_update\n"
            "        __r4_update_proof = __r4_run_update(src, state, work, args.jobs)\n")
NEW_HOOK = OLD_HOOK.replace("from cass_r4_build import", "from veux_r11_build_hook import")


def main():
    import cass_r4_bridge as original
    require(sha(Path(original.__file__)) == BRIDGE_PIN, "R11_R4_BRIDGE_SOURCE_PIN")
    require(original.HOOK == OLD_HOOK, "R11_R4_HOOK_LAYOUT_CHANGED")
    original.HOOK = NEW_HOOK
    try:
        original.main()
    finally:
        original.HOOK = OLD_HOOK


if __name__ == "__main__":
    main()
