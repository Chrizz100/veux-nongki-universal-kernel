#!/usr/bin/env python3
"""Add the authenticated R11 changes immediately before the existing R4 compile.

The original R4 baseline build, source port, version checks, compilation and
132-import ABI audit still run. Only the isolated candidate is patched.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess

from source_update import apply, inventory, require, sha

BUILD_PIN = "12519a7d94825d3bc2006a46420f8884773a659443e56ba542f48057929dd3a0"


def run_update(kernel, state, baseline_work, jobs):
    import cass_r4_build as original
    require(sha(Path(original.__file__)) == BUILD_PIN, "R11_R4_COMPILER_SOURCE_PIN")
    before = original.compile_candidate
    calls = []

    def compile_r11(candidate, obj, baseline_config, captured, version, evidence,
                    compile_jobs, original_work=None):
        candidate, evidence = Path(candidate).resolve(strict=True), Path(evidence)
        temporary = Path(os.environ["RUNNER_TEMP"]).resolve(strict=True)
        expected = temporary / "veux-r55h17-r4/source/kernel"
        require(candidate == expected and candidate != Path(kernel).resolve(),
                "R11_REQUIRES_ISOLATED_R4_CANDIDATE")
        require(not Path(obj).exists(), "R11_FRESH_OBJECT_TREE_REQUIRED")
        proof = apply(candidate, evidence)
        calls.append(proof)
        after_patch = inventory(candidate)
        # A copied Git index can retain the old inode/stat cache and make
        # diff-index report "dirty" for byte-identical tracked files. Refresh
        # only the isolated checkout's metadata before genuine Kbuild versioning.
        bakasu = candidate / "KernelSU"
        git_commands = [
            ["git", "-C", str(bakasu), "update-index", "--refresh"],
            ["git", "-C", str(bakasu), "diff-index", "--quiet", "HEAD", "--"],
        ]
        for command in git_commands:
            subprocess.run(command, check=True, capture_output=True, text=True)
        status = subprocess.check_output(
            ["git", "-C", str(bakasu), "status", "--porcelain", "--untracked-files=all"], text=True)
        require(not status, "R11_BAKASU_CHECKOUT_NOT_CLEAN")
        (evidence / "R11_GIT_INDEX.json").write_text(json.dumps({
            "status": "CLEAN_INDEX_AND_WORKTREE", "commands": git_commands,
            "only_isolated_git_metadata_refreshed": True, "source_bytes_unchanged":
            after_patch == inventory(candidate), "version_overrides": False,
        }, indent=2) + "\n")
        require(after_patch == inventory(candidate), "R11_INDEX_REFRESH_CHANGED_SOURCE")
        result = None
        try:
            result = before(candidate, obj, baseline_config, captured, version,
                            evidence, compile_jobs, original_work)
            return result
        finally:
            unchanged = after_patch == inventory(candidate)
            report = {"schema": "veux-r11-compile-hook-v1", "rmnet_mode": "built-in",
                      "precompile_source_update_sha256": sha(evidence / "R11_SOURCE_UPDATE.json"),
                      "r4_compile_and_static_gates_passed": result is not None,
                      "candidate_source_unchanged_during_compile": unchanged,
                      "original_r4_build_script_sha256": BUILD_PIN,
                      "device_test": False}
            (evidence / "R11_COMPILE_HOOK.json").write_text(json.dumps(report, indent=2) + "\n")
            require(unchanged, "R11_SOURCE_CHANGED_DURING_COMPILE")

    original.compile_candidate = compile_r11
    try:
        result = original.run_update(kernel, state, baseline_work, jobs)
    finally:
        original.compile_candidate = before
    require(len(calls) == 1, "R11_COMPILE_HOOK_CALL_COUNT")
    return result
