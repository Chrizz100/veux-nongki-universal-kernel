#!/usr/bin/env python3
"""Focused replay/negative checks of packaging with recorded real R5 artifacts.

No kernel build or phone is simulated as a success. All generated files are in
this agent's own test directory. The original reference inputs remain untouched.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess
import tempfile
import zipfile
import package_build as p

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[2]

def jsonwrite(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def main():
    results = {}
    originals = [WORK / 'work_cass_r5/private_reference/VEUX_BOOT_A_VOR_H13.img']
    original_hashes = {str(path):p.sha(path.read_bytes()) for path in originals}
    work = ROOT / 'test_workspace'
    work.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='replay-', dir=work) as scratch:
        scratch = Path(scratch)
        inputs = scratch / 'inputs'; inputs.mkdir()
        for name in p.REQUIRED:
            if name.endswith('.ko'):
                source = WORK / 'work_cass_r4/audit_delivery/raw/modules' / name
            else:
                source = WORK / 'work_cass_r5/ci_raw' / name
            shutil.copyfile(source, inputs / name)
        provenance = {'source_commit':'e47f720530ef2d98986f2ee1d2e25c51349247f6',
                      'source_checks_passed':True, 'kernel_compile_exit':0, 'module_compile_exit':0,
                      'kernel_command':['recorded GitHub run40704046049 attempt2'],
                      'module_command':['recorded earlier CASS reference module build; ABI revalidated in R5'],
                      'fixture_note':'historical artifacts; no compiler executed by this test'}
        metadata = {'schema':'veux-build-output-v1','origin':'historical-reference-replay',
                    'kernel_release':'5.4.274-qgki-g82179e362f33',
                    'bakasu_marker':'v4.2.0-rc3-2cbbcc23@BakaSU','nomount_api':22,
                    'provenance':provenance,
                    'files':{name:{'sha256':p.sha((inputs/name).read_bytes()),'bytes':(inputs/name).stat().st_size} for name in p.REQUIRED}}
        receipt = scratch / 'BUILD_OUTPUTS.json'; jsonwrite(receipt, metadata)
        data, loaded, proof = p.validate_inputs(inputs, receipt)
        assert proof['kernel_notes_sha256'] == '922746276a41b6f6bd644bfb37a05187ac751435e9aa3b2b0dbf068c6ca9cf8f'
        assert sum(row['version_entries'] for row in proof['modules'].values()) == 132
        assert not proof['same_invocation_recorded']
        results['actual_r5_image_config_notes_and_132_module_crcs'] = 'PASS'

        # The old generic make command must not claim fresh external modules.
        bad = json.loads(json.dumps(metadata)); bad['origin'] = 'same-build-invocation'
        bad_receipt = scratch / 'bad_receipt.json'; jsonwrite(bad_receipt, bad)
        try: p.validate_inputs(inputs, bad_receipt)
        except ValueError as error: assert 'external RMNET build receipts missing' in str(error)
        else: raise AssertionError('missing external module build origin was accepted')
        results['make_image_dtbs_modules_does_not_prove_external_rmnet_origin'] = 'PASS'

        bad['provenance']['kernel_compile_reused'] = True
        jsonwrite(bad_receipt, bad)
        try: p.validate_inputs(inputs, bad_receipt)
        except ValueError as error: assert 'cannot reuse an earlier kernel compile' in str(error)
        else: raise AssertionError('reused kernel accepted as same-build-invocation')
        results['reused_kernel_cannot_claim_same_build_invocation'] = 'PASS'

        bad['origin'] = 'existing-native-kernel-plus-fresh-external-modules'
        bad['provenance']['evidence_mode'] = 'local-native'
        jsonwrite(bad_receipt, bad)
        try: p.validate_inputs(inputs, bad_receipt)
        except ValueError as error: assert 'external RMNET build receipts missing' in str(error)
        else: raise AssertionError('native reused kernel accepted without external module receipts')
        results['reused_native_kernel_requires_same_external_module_proofs'] = 'PASS'

        # Change a real imported CRC and update the receipt: semantic ABI check
        # must still reject, independently of transport/content hashes.
        original = (inputs / 'Module.symvers').read_bytes()
        changed = []
        for line in original.decode().splitlines():
            words = line.split()
            if words[1] == 'module_layout':
                line = line.replace(words[0], '0x00000000', 1)
            changed.append(line)
        (inputs / 'Module.symvers').write_text('\n'.join(changed) + '\n')
        bad = json.loads(json.dumps(metadata))
        content = (inputs / 'Module.symvers').read_bytes()
        bad['files']['Module.symvers'] = {'sha256':p.sha(content),'bytes':len(content)}
        jsonwrite(bad_receipt, bad)
        try: p.validate_inputs(inputs, bad_receipt)
        except ValueError as error: assert 'module import ABI mismatch: module_layout' in str(error)
        else: raise AssertionError('wrong module_layout CRC accepted')
        (inputs / 'Module.symvers').write_bytes(original)
        results['module_layout_crc_rejected_even_with_updated_receipt'] = 'PASS'

        # A changed DTB must not silently enter a boot-header-v3-only package.
        original = (inputs / 'veux.dtb').read_bytes()
        content = original[:-1] + bytes([original[-1] ^ 1])
        (inputs / 'veux.dtb').write_bytes(content)
        bad = json.loads(json.dumps(metadata)); bad['files']['veux.dtb'] = {'sha256':p.sha(content),'bytes':len(content)}
        jsonwrite(bad_receipt, bad)
        try: p.validate_inputs(inputs, bad_receipt)
        except ValueError as error: assert 'DTB changed' in str(error)
        else: raise AssertionError('changed DTB accepted without integration')
        (inputs / 'veux.dtb').write_bytes(original)
        results['changed_dtb_requires_separate_integration'] = 'PASS'

        args = argparse.Namespace(inputs=inputs, receipt=receipt, out=scratch/'raw_only',
                                  base_boot=None, magiskboot=None, avbtool=None, ak3=None,
                                  manager_apk=None, nomount_zip=None)
        raw_report = p.build(args)
        assert raw_report['boot_packaging'] == 'NOT_REQUESTED_PRIVATE_INPUT_REQUIRED'
        assert raw_report['rmnet_archive'] == p.output_record(args.out / 'VEUX_CASS_RMNET_BUILD_DATA.zip')
        assert not (args.out / 'boot.img').exists()
        old = WORK / 'work_r6_device_integration/agents/drivers/delivery/VEUX_R5_CASS_RMNET_DATA_REPAIR_R1/rmnet'
        assert all((args.out/'rmnet'/name).read_bytes() == (old/name).read_bytes() for name in ('install.sh','launcher.sh','runtime.sh','identity.txt','SHA256SUMS','rmnet_offload.ko','rmnet_shs.ko'))
        results['raw_only_mode_and_exact_existing_rmnet_payload_reproduced'] = 'PASS'

        args.out = scratch / 'full_package'
        args.base_boot = originals[0]
        args.magiskboot = WORK / 'work_cass_r5/tools/magiskboot-x86_64'
        args.avbtool = WORK / 'work_cass_r5/tools/avb/avbtool'
        args.ak3 = WORK / 'work_cass_r5/tools/AnyKernel3'
        args.manager_apk = WORK / 'work_cass_r5/delivery/BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk'
        args.nomount_zip = WORK / 'work_cass_r5/delivery/NoMount-v2.2.0-release-bf1847f-605.zip'
        full_report = p.build(args)
        assert full_report['rmnet_archive'] == raw_report['rmnet_archive']
        assert full_report['boot_sha256'] == '40c44d00cdea1f8c4aa54d9b5c87dbf8d3c9cd8fd2cdc37963645471be6c4ba7'
        installer = (args.out / 'anykernel.sh').read_bytes()
        tested = WORK / 'work_r6_device_integration/agents/installer/implementation/anykernel.sh'
        assert installer == tested.read_bytes()
        assert p.sha(installer) == '426912dd7fe30b6eb82a40c8687897ee035dbcbcde7d46e1cc10cd1535ff119d'
        with zipfile.ZipFile(args.out/'VEUX_CASS_BUILD_INSTALL_R3.zip') as archive:
            members = {name:(archive.read(name),(archive.getinfo(name).external_attr >> 16)&0o777) for name in archive.namelist()}
        repeated = scratch / 'repeat.zip'; p.write_zip(repeated, members)
        assert repeated.read_bytes() == (args.out/'VEUX_CASS_BUILD_INSTALL_R3.zip').read_bytes()
        assert full_report['companions'] == {'manager_spoofed35252':True,'nomount605':True}
        results['full_boot_avb_magiskboot_and_r3_script_byte_reproduction'] = 'PASS'
        results['deterministic_installer_zip_and_official_companions'] = 'PASS'
        # Persist only test evidence, not private boot/ramdisk or huge fixtures.
        evidence = ROOT / 'test_evidence'; evidence.mkdir(exist_ok=True)
        for name in ('BUILD_PACKAGE_CHECK.json','BOOT_PACKAGE_CHECK.json','INSTALLER_PACKAGE_CHECK.json','PACKAGE_RESULT.json'):
            shutil.copyfile(args.out/name,evidence/name)
        shutil.copytree(args.out/'boot_check/logs', evidence/'boot_logs', dirs_exist_ok=True)
        # A synthetic length-only fixture checks the changed-header/repositioned
        # ramdisk path. It is never described as a newly compiled kernel.
        original_boot_output = args.out
        args.out = scratch / 'longer_layout'; args.out.mkdir()
        longer = dict(data); longer['Image'] = data['Image'] + bytes(4096)
        length_checks = dict(proof); length_checks['image_sha256'] = p.sha(longer['Image'])
        length_boot, length_report = p.make_boot(args, longer, length_checks)
        assert length_report['header_changes'] == ['kernel_size']
        assert length_report['after']['ramdisk_offset'] == length_report['before']['ramdisk_offset'] + 4096
        assert length_report['ramdisk_unchanged'] and length_report['magiskboot_roundtrip_identical']
        jsonwrite(evidence/'SYNTHETIC_LENGTH_ONLY_CHECK.json',{'synthetic_not_compiled':True,**length_report})
        results['synthetic_length_change_preserves_ramdisk_avb_and_roundtrip'] = 'PASS'
        args.out = original_boot_output
        for path, expected in original_hashes.items():
            assert p.sha(Path(path).read_bytes()) == expected
        results['private_reference_unchanged'] = 'PASS'
    result = {'status':'PASS','checks':results,'count':len(results),
              'runner_sha256':p.sha((ROOT/'package_build.py').read_bytes()),
              'kernel_compilation_performed':False,'device_execution':False,
              'fixture_origin':'historical-reference-replay',
              'critical_installer_and_rmnet_runtime_bytes_identical_to_tested_r3':True,
              'prior_r3_installer_regressions':43,'prior_r3_entrypoint_tests':3,
              'scope':'host packaging and fail-closed content checks; not a new kernel/device acceptance'}
    jsonwrite(ROOT/'PACKAGING_TEST_RESULT.json',result)
    print(json.dumps(result,indent=2))

if __name__ == '__main__':
    main()
