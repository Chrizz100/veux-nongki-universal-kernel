#!/usr/bin/env python3
"""Validate one VEUX CASS build and create its generation-bound RMNET/boot packages.

No device access, network fetch, kernel compilation or binary patching. Inputs
must be staged with their explicit build provenance in BUILD_OUTPUTS.json.
Without the four explicit private-boot/tool inputs, only raw/RMNET evidence is
produced. A successful package check is never a device boot/performance result.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.machinery
import importlib.util
import json
import re
import stat
import struct
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REQUIRED = ('Image', 'actual-build.config', 'System.map', 'Module.symvers',
            'veux.dtb', 'rmnet_offload.ko', 'rmnet_shs.ko')
FRESH_MODULE_ORIGINS = ('same-build-invocation', 'existing-native-kernel-plus-fresh-external-modules')
ORIGINS = FRESH_MODULE_ORIGINS + ('historical-reference-replay', 'revalidated-reference-modules')
PINS = {
    'base_boot': 'fe7093b0bf154e162c4474a4ded3c9a89be431bc8f12b0d0be1738b88091a263',
    'base_kernel': '32588b4f06dc122c6582729c63b62ef68acdeca0806c7d351f6ef7238f0c6ac3',
    'dtb': '42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
    'raw_ramdisk': 'efa8d4af76e0582d48ddb0ab4cd60c94da18eec2b607eac41ad2fca5620b56ba',
    'decoded_ramdisk': 'aa8cc84af0da90cc29201f0f21a76891e98b5e759122ee813b450d3e71d09321',
    'magiskboot': 'a18ecbd7981179494b7d281453d6c4e25b5c719e7d2ef7f6eba3c6be3043c58e',
    'avbtool': '2ae13d6926094c86e67ea124c93990caaf67fc9b6e4e32cdf55c9c2cd3f36df6',
    'manager_apk': '43ccd6ec08844bf656b0800d84567c4f04412203446e6dada9570008f180fe25',
    'nomount_zip': 'd40277cb8f495b78711fb72e5f19a79ab2627eba2f0eb2aec60b5fc8019fae83',
}
REFERENCE_MODULES = {
    'rmnet_offload.ko': 'a391f7991f96da6d0f0ccd567e7f410e75ddf69fe43d62bfda6c7b88d34da724',
    'rmnet_shs.ko': 'ce30767b130fb0ddc2daffecf0d2379f12959450921d35ef3370097b2b04fd99',
}
ASSETS = {
    'assets/anykernel.sh.in': '8081c90c5a80bb3f8a911a2d48d11675c856fa7d5e092421df16641fde0b29ca',
    'assets/rmnet/install.sh': '232e37c8cf84c1fc8150e3d5e6bde10ac041a921dcb355799f112ea9a7aad526',
    'assets/rmnet/launcher.sh': '31fe2485b6249d3ee208313dad39c85f92ef701b7705cbd2221a53b679539d61',
    'assets/rmnet/runtime.sh': '9a46a7b00524e66d69ead4c255d42e51d17fca97c24b0c2593c1127a9c3c4f26',
}
AK3_COMMIT = 'af770f7b16cf8f8eb7c68614b2a693b3b361c90c'
AK3_TREE = 'c6af9eb7018bce852819ab1585de426a426e6806'
PARTITION_SIZE = 134217728
PAGE = 4096


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    require(path.is_file() and not path.is_symlink(), f'not a regular input file: {path.name}')
    return path.read_bytes()


def output_record(path):
    data = regular(path)
    return {'file': path.name, 'sha256': sha(data), 'bytes': len(data)}


def pinned(path, expected):
    data = regular(path)
    require(sha(data) == expected, f'input checksum differs: {path.name}')
    return data


def align(value, boundary=PAGE):
    return (value + boundary - 1) // boundary * boundary


def embedded_config(image):
    require(image.count(b'IKCFG_ST') == 1, 'missing or ambiguous embedded configuration')
    start = image.index(b'IKCFG_ST') + 8
    stop = image.index(b'IKCFG_ED', start)
    return gzip.decompress(image[start:stop])


def note_build_id(data):
    """Validate aligned ELF note records before deriving a runtime generation."""
    offset, build_ids = 0, []
    while offset < len(data):
        require(offset + 12 <= len(data), 'truncated ELF note header')
        namesize, descsize, kind = struct.unpack_from('<III', data, offset)
        name_start = offset + 12
        desc_start = align(name_start + namesize, 4)
        next_note = align(desc_start + descsize, 4)
        require(namesize and next_note <= len(data), 'invalid ELF note bounds')
        name = data[name_start:name_start + namesize]
        if name == b'GNU\0' and kind == 3:
            require(0 < descsize <= 64, 'invalid GNU build ID size')
            build_ids.append(data[desc_start:desc_start + descsize].hex())
        offset = next_note
    require(len(build_ids) == 1, 'missing or ambiguous GNU build ID')
    return build_ids[0]


def elf_sections(data):
    require(data[:7] == b'\x7fELF\x02\x01\x01', 'module is not ELF64 little-endian')
    header = struct.unpack_from('<HHIQQQIHHHHHH', data, 16)
    require(header[0] == 1 and header[1] == 183, 'module is not AArch64 ET_REL')
    offset, width, count, names_index = header[5], header[10], header[11], header[12]
    require(width == 64 and count and offset + count * width <= len(data), 'invalid ELF section table')
    rows = [struct.unpack_from('<IIQQQQIIQQ', data, offset + i * width) for i in range(count)]
    require(names_index < count, 'invalid ELF section name table')
    names_row = rows[names_index]
    strings = data[names_row[4]:names_row[4] + names_row[5]]
    sections = {}
    for row in rows:
        require(row[0] < len(strings), 'invalid ELF section name offset')
        name = strings[row[0]:].split(b'\0', 1)[0].decode()
        if name:
            require(name not in sections, 'duplicate ELF section')
            sections[name] = row
    return sections, rows


def module_check(data, release, exports):
    sections, rows = elf_sections(data)
    def read(name):
        require(name in sections, f'missing module section {name}')
        row = sections[name]
        require(row[1] != 8 and row[4] + row[5] <= len(data), 'truncated module section')
        return data[row[4]:row[4] + row[5]]
    raw_versions = read('__versions')
    require(len(raw_versions) % 64 == 0, 'invalid modversion entry width')
    imports = {}
    for offset in range(0, len(raw_versions), 64):
        crc = struct.unpack_from('<Q', raw_versions, offset)[0]
        name = raw_versions[offset + 8:offset + 64].split(b'\0', 1)[0].decode()
        require(name and name not in imports, 'duplicate/empty module import')
        require(exports.get(name) == crc, f'module import ABI mismatch: {name}')
        imports[name] = crc
    require('module_layout' in imports, 'module_layout CRC missing')
    modinfo = {}
    for item in read('.modinfo').split(b'\0'):
        if b'=' in item:
            key, value = item.decode().split('=', 1)
            modinfo.setdefault(key, []).append(value)
    require(modinfo.get('depends') == [''], 'unexpected RMNET module dependency')
    expected_magic = release + ' SMP preempt mod_unload modversions aarch64'
    require(modinfo.get('vermagic') == [expected_magic], 'module/kernel vermagic mismatch')
    symrow = sections['.symtab']
    require(symrow[6] < len(rows) and symrow[9] == 24, 'invalid module symbol table')
    strrow = rows[symrow[6]]
    strings = data[strrow[4]:strrow[4] + strrow[5]]
    defined, strong = set(), []
    symdata = read('.symtab')
    require(len(symdata) % 24 == 0, 'truncated module symbols')
    for offset in range(0, len(symdata), 24):
        no, info, other, index, value, size = struct.unpack_from('<IBBHQQ', symdata, offset)
        require(no < len(strings), 'invalid module symbol name')
        name = strings[no:].split(b'\0', 1)[0].decode()
        if index and name:
            defined.add(name)
        if index == 0 and info >> 4 == 1 and name:
            require(name in imports, f'unversioned strong module import: {name}')
            strong.append(name)
    require({'init_module', 'cleanup_module', '__cfi_check'} <= defined, 'module CFI/init/exit evidence missing')
    note = read('.note.gnu.build-id')
    build_id = note_build_id(note)
    return {'sha256': sha(data), 'bytes': len(data), 'vermagic': expected_magic,
            'version_entries': len(imports), 'strong_imports': len(strong),
            'module_layout_crc': hex(imports['module_layout']), 'note_sha256': sha(note), 'build_id': build_id,
            'aarch64_modversions_cfi': True}


def validate_inputs(inputs, receipt):
    metadata = json.loads(regular(receipt))
    require(metadata.get('schema') == 'veux-build-output-v1', 'unsupported build receipt schema')
    require(metadata.get('origin') in ORIGINS, 'invalid output origin')
    provenance = metadata.get('provenance', {})
    if metadata['origin'] == 'same-build-invocation':
        require(provenance.get('kernel_compile_reused') in (None, False),
                'same-build-invocation cannot reuse an earlier kernel compile')
    elif metadata['origin'] == 'existing-native-kernel-plus-fresh-external-modules':
        require(provenance.get('kernel_compile_reused') is True and provenance.get('evidence_mode') == 'local-native',
                'existing native kernel origin needs explicit local-native reused-compile provenance')
    require(provenance.get('kernel_compile_exit') == 0 and provenance.get('module_compile_exit') == 0,
            'receipt must record successful kernel and module compile commands')
    require(provenance.get('kernel_command') and provenance.get('module_command'), 'compile commands absent')
    require(re.fullmatch(r'[0-9a-f]{40}', provenance.get('source_commit', '')) is not None, 'source commit absent')
    require(provenance.get('source_checks_passed') is True, 'source/config preservation gate absent')
    require(set(metadata.get('files', {})) == set(REQUIRED), 'receipt output list differs')
    data = {}
    for name in REQUIRED:
        content = regular(inputs / name)
        item = metadata['files'][name]
        require(item['bytes'] == len(content) and item['sha256'] == sha(content), f'build receipt mismatch: {name}')
        data[name] = content
    if metadata['origin'] in FRESH_MODULE_ORIGINS:
        external = provenance.get('external_module_builds', {})
        require(set(external) == {'rmnet_offload', 'rmnet_shs'}, 'separate external RMNET build receipts missing')
        for name, item in external.items():
            require(item.get('exit') == 0 and item.get('command') and item.get('output_path'), 'external RMNET build receipt incomplete')
            require(item.get('sha256') == sha(data[name + '.ko']), 'external build output does not match staged module')
    else:
        for name, expected in REFERENCE_MODULES.items():
            require(sha(data[name]) == expected, 'reference-module mode requires the exact known reference bytes')
        if metadata['origin'] == 'historical-reference-replay':
            require(sha(data['Image']) == '2d835d75cc14aac0c288d1176800caa0642d8475cbb259d768e738ffa2687d55',
                    'historical replay requires the actual R5 Image')
    image = data['Image']
    require(image[56:60] == b'ARM\x64', 'kernel is not an ARM64 Image')
    require(embedded_config(image) == data['actual-build.config'], 'embedded config differs from actual build config')
    config = set(data['actual-build.config'].decode().splitlines())
    flags = ('CONFIG_SCHED_CASS=y', 'CONFIG_CFI_CLANG=y', 'CONFIG_THINLTO=y',
             'CONFIG_MODVERSIONS=y', 'CONFIG_MODULES=y', 'CONFIG_STACKPROTECTOR_STRONG=y',
             '# CONFIG_MODULE_FORCE_LOAD is not set', '# CONFIG_MODULE_FORCE_UNLOAD is not set')
    require(set(flags) <= config and 'CONFIG_SCHED_WALT=y' not in config, 'CASS/CFI/module policy mismatch')
    releases = re.findall(rb'Linux version ([0-9]+\.[0-9]+\.[^ \x00\n]+) ', image)
    require(len(set(releases)) == 1, 'kernel release missing or ambiguous')
    release = releases[0].decode()
    require(release == metadata['kernel_release'], 'receipt/kernel release mismatch')
    marker = metadata.get('bakasu_marker', '')
    require(marker and marker.startswith('v') and marker.endswith('@BakaSU') and image.count(marker.encode()) == 1,
            'expected BakaSU marker missing or ambiguous')
    require(metadata.get('nomount_api') == 22, 'this installer implements the fixed NoMount 21-to-22 path')
    # This boot-only packaging path intentionally cannot publish a changed DTB.
    require(sha(data['veux.dtb']) == PINS['dtb'], 'DTB changed; separate vendor-boot/DTBO integration required')
    exports = {}
    for line in data['Module.symvers'].decode().splitlines():
        words = line.split()
        require(len(words) >= 3 and words[1] not in exports, 'invalid/duplicate Module.symvers entry')
        exports[words[1]] = int(words[0], 16)
    syms = {}
    for line in data['System.map'].decode().splitlines():
        words = line.split()
        if len(words) == 3 and words[2] in {'_text', '__start_notes', '__stop_notes'}:
            require(words[2] not in syms, 'ambiguous System.map notes symbol')
            syms[words[2]] = int(words[0], 16)
    require(len(syms) == 3, 'kernel notes symbols missing')
    lo, hi = syms['__start_notes'] - syms['_text'], syms['__stop_notes'] - syms['_text']
    require(0 <= lo < hi <= len(image), 'kernel note offsets out of bounds')
    notes = image[lo:hi]
    kernel_build_id = note_build_id(notes)
    modules = {name: module_check(data[name + '.ko'], release, exports) for name in ('rmnet_offload', 'rmnet_shs')}
    return data, metadata, {'kernel_release': release, 'image_sha256': sha(image),
            'kernel_notes_sha256': sha(notes), 'kernel_notes_offset': lo, 'kernel_notes_bytes': len(notes), 'kernel_build_id': kernel_build_id,
            'config_sha256': sha(data['actual-build.config']), 'symvers_sha256': sha(data['Module.symvers']),
            'exported_symbol_count': len(exports), 'modules': modules,
            'source_receipt_sha256': sha(regular(receipt)), 'origin': metadata['origin'],
            'same_invocation_recorded': metadata['origin'] == 'same-build-invocation',
            'kernel_compile_reused': provenance.get('kernel_compile_reused') is True,
            'same_invocation_claim_is_workflow_provenance_not_an_elf_proof': True,
            'dtb_unchanged': True, 'device_test': False}


def write_zip(path, members):
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, (data, mode) in sorted(members.items()):
            require(not name.startswith('/') and '..' not in Path(name).parts, 'invalid output archive path')
            info = zipfile.ZipInfo(name, (2026, 10, 28, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | mode) << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None and set(archive.namelist()) == set(members), 'archive integrity failed')
        for name, (data, mode) in members.items():
            info = archive.getinfo(name)
            require(archive.read(name) == data and stat.S_ISREG(info.external_attr >> 16), 'archive member mismatch')
            require((info.external_attr >> 16) & 0o777 == mode, 'archive member mode mismatch')


def make_rmnet(data, checks, output):
    output.mkdir()
    members = {}
    for name in ('install.sh', 'launcher.sh', 'runtime.sh'):
        content = pinned(HERE / 'assets/rmnet' / name, ASSETS['assets/rmnet/' + name])
        members[name] = (content, 0o644)
    identity = ('FORMAT=veux-rmnet-v1\n' + 'KERNEL_RELEASE=' + checks['kernel_release'] + '\n' +
                'KERNEL_NOTES_SHA256=' + checks['kernel_notes_sha256'] + '\n' +
                'OFFLOAD_NOTE_SHA256=' + checks['modules']['rmnet_offload']['note_sha256'] + '\n' +
                'SHS_NOTE_SHA256=' + checks['modules']['rmnet_shs']['note_sha256'] + '\n')
    members['identity.txt'] = (identity.encode(), 0o644)
    for name in ('rmnet_offload.ko', 'rmnet_shs.ko'):
        members[name] = (data[name], 0o644)
    members['SHA256SUMS'] = (''.join(f'{sha(value[0])}  {name}\n' for name, value in sorted(members.items())).encode(), 0o644)
    for name, (content, mode) in members.items():
        (output / name).write_bytes(content)
        (output / name).chmod(mode)
    return members


def run(command, cwd, log):
    result = subprocess.run([str(x) for x in command], cwd=cwd, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
    log.write_text(result.stdout)
    require(result.returncode == 0, f'command failed: {log.name}; exit={result.returncode}')
    return result.stdout


def boot_layout(data):
    require(len(data) == PARTITION_SIZE and data[:8] == b'ANDROID!', 'unsupported boot container')
    ksize, rsize, os_version, header_size = struct.unpack_from('<4I', data, 8)
    require(struct.unpack_from('<I', data, 40)[0] == 3 and header_size == 1580, 'boot must use proven header v3')
    roff = PAGE + align(ksize)
    end = roff + align(rsize)
    require(ksize > 64 and rsize > 0 and end < PARTITION_SIZE - 65536, 'invalid boot payload sizes')
    require(data[PAGE + 56:PAGE + 60] == b'ARM\x64', 'boot payload is not ARM64 Image')
    return {'kernel_size': ksize, 'ramdisk_size': rsize, 'ramdisk_offset': roff, 'payload_end': end,
            'os_version': os_version, 'header_sha256': sha(data[:PAGE])}


def avb_state(module, image):
    footer, header, descriptors, size = module.Avb()._parse_image(module.ImageHandler(str(image)))
    require(footer and header.algorithm_type == 0 and header.authentication_data_block_size == 0, 'unexpected AVB policy')
    require(header.flags == header.rollback_index == header.rollback_index_location == 0, 'unexpected AVB flags/rollback policy')
    hashes = [x for x in descriptors if isinstance(x, module.AvbHashDescriptor)]
    props = [x for x in descriptors if isinstance(x, module.AvbPropertyDescriptor)]
    require(len(hashes) == 1 and len(hashes) + len(props) == len(descriptors), 'unexpected AVB descriptors')
    desc = hashes[0]
    require(desc.partition_name == 'boot' and desc.hash_algorithm == 'sha256' and desc.flags == 0, 'unexpected boot AVB hash contract')
    text = lambda value: value.decode() if isinstance(value, bytes) else value
    return {'salt': desc.salt.hex(), 'digest': desc.digest.hex(), 'hash_image_size': desc.image_size,
            'props': [[text(x.key), text(x.value)] for x in props], 'original_size': footer.original_image_size,
            'algorithm': 'NONE', 'flags': header.flags, 'rollback_index': header.rollback_index,
            'rollback_index_location': header.rollback_index_location, 'release_string': header.release_string,
            'non_hash_descriptors': [sha(x.encode()) for x in props], 'partition_size': size}


def make_boot(args, data, checks):
    base = pinned(args.base_boot, PINS['base_boot'])
    pinned(args.magiskboot, PINS['magiskboot'])
    avbtool = args.avbtool.resolve(strict=True)
    pinned(avbtool, PINS['avbtool'])
    before = boot_layout(base)
    old_kernel = base[PAGE:PAGE + before['kernel_size']]
    require(sha(old_kernel) == PINS['base_kernel'], 'private base kernel changed')
    require(embedded_config(old_kernel) == data['actual-build.config'], 'new config differs from proven private boot configuration')
    raw_ramdisk = base[before['ramdisk_offset']:before['ramdisk_offset'] + before['ramdisk_size']]
    require(sha(raw_ramdisk) == PINS['raw_ramdisk'], 'private ramdisk changed')
    loader = importlib.machinery.SourceFileLoader('pinned_veux_avbtool', str(avbtool))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    avb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(avb)
    original_avb = avb_state(avb, args.base_boot)
    require(original_avb['original_size'] == before['payload_end'], 'base AVB payload size mismatch')
    image = data['Image']
    header = bytearray(base[:PAGE])
    struct.pack_into('<I', header, 8, len(image))
    payload = bytes(header) + image + bytes(align(len(image)) - len(image))
    payload += raw_ramdisk + bytes(align(len(raw_ramdisk)) - len(raw_ramdisk))
    require(len(payload) < PARTITION_SIZE - 65536, 'new kernel and preserved ramdisk exceed boot partition')
    directory = args.out / 'boot_check'
    directory.mkdir()
    logs = directory / 'logs'; logs.mkdir()
    output = args.out / 'boot.img'
    output.write_bytes(payload)
    command = [sys.executable, avbtool, 'add_hash_footer', '--image', output,
               '--partition_name', 'boot', '--partition_size', str(PARTITION_SIZE),
               '--hash_algorithm', 'sha256', '--algorithm', 'NONE', '--salt', original_avb['salt']]
    for key, value in original_avb['props']:
        command.extend(['--prop', f'{key}:{value}'])
    run(command, directory, logs / 'avb_generation.log')
    final = output.read_bytes()
    after = boot_layout(final)
    require(final[:8] + final[12:PAGE] == base[:8] + base[12:PAGE], 'boot header changed outside kernel length')
    require(final[PAGE:PAGE + after['kernel_size']] == image, 'final kernel content mismatch')
    require(final[after['ramdisk_offset']:after['ramdisk_offset'] + after['ramdisk_size']] == raw_ramdisk,
            'final raw ramdisk differs')
    final_avb = avb_state(avb, output)
    for key in ('salt', 'props', 'algorithm', 'flags', 'rollback_index', 'rollback_index_location', 'release_string', 'non_hash_descriptors', 'partition_size'):
        require(final_avb[key] == original_avb[key], f'AVB metadata changed: {key}')
    require(final_avb['hash_image_size'] == final_avb['original_size'] == len(payload), 'final AVB range differs')
    require(final_avb['digest'] == sha(bytes.fromhex(final_avb['salt']) + final[:len(payload)]), 'independent AVB hash mismatch')
    run([sys.executable, avbtool, 'verify_image', '--image', output], directory, logs / 'avb_verify.log')
    for label, options, expected in [('raw', ['-n', '-h'], PINS['raw_ramdisk']), ('decoded', ['-h'], PINS['decoded_ramdisk'])]:
        work = directory / label; work.mkdir()
        run([args.magiskboot, 'unpack', *options, output], work, logs / f'magiskboot_{label}.log')
        require((work / 'kernel').read_bytes() == image, 'MagiskBoot extracted kernel mismatch')
        require(sha((work / 'ramdisk.cpio').read_bytes()) == expected, 'MagiskBoot ramdisk mismatch')
    roundtrip_dir = directory / 'roundtrip'; roundtrip_dir.mkdir()
    roundtrip = roundtrip_dir / 'boot.img'
    run([args.magiskboot, 'repack', '-n', output, roundtrip], directory / 'raw', logs / 'magiskboot_roundtrip.log')
    require(roundtrip.read_bytes() == final, 'MagiskBoot byte roundtrip mismatch')
    run([sys.executable, avbtool, 'verify_image', '--image', roundtrip], directory, logs / 'roundtrip_avb_verify.log')
    roundtrip.unlink()
    require(sha(regular(args.base_boot)) == PINS['base_boot'], 'private base changed')
    report = {'status': 'STATIC_BOOT_AND_ROUNDTRIP_PASS_DEVICE_UNTESTED', 'boot_sha256': sha(final),
              'boot_bytes': len(final), 'image_sha256': checks['image_sha256'],
              'kernel_notes_sha256': checks['kernel_notes_sha256'], 'ramdisk_unchanged': True,
              'header_changes': ['kernel_size'] if len(image) != before['kernel_size'] else [],
              'avb_metadata_preserved': True, 'independent_salted_hash': True,
              'magiskboot_roundtrip_identical': True, 'private_base_unchanged': True,
              'base_sha256': PINS['base_boot'], 'before': before, 'after': after,
              'device_test': False, 'private_ramdisk_in_generated_boot': True}
    (args.out / 'BOOT_PACKAGE_CHECK.json').write_text(json.dumps(report, indent=2) + '\n')
    return final, report


def make_installer(args, boot, rmnet, checks):
    ak3 = args.ak3
    def git(*arguments):
        return subprocess.check_output(['git', '--no-optional-locks', '-C', str(ak3), *arguments], text=True).strip()
    require(git('rev-parse', 'HEAD') == AK3_COMMIT and git('rev-parse', 'HEAD^{tree}') == AK3_TREE, 'AnyKernel3 revision differs')
    require(not git('status', '--porcelain', '--untracked-files=all'), 'AnyKernel3 checkout is not clean')
    template = pinned(HERE / 'assets/anykernel.sh.in', ASSETS['assets/anykernel.sh.in'])
    script = template.replace(b'@BOOT_SHA256@', sha(boot).encode()).replace(b'@RMNET_MANIFEST_SHA256@', sha(rmnet['SHA256SUMS'][0]).encode())
    require(b'@BOOT_SHA256@' not in script and b'@RMNET_MANIFEST_SHA256@' not in script, 'unresolved installer placeholders')
    script_file = args.out / 'anykernel.sh'; script_file.write_bytes(script)
    subprocess.run(['shellcheck', '--shell=ash', '--severity=warning', str(script_file)], check=True)
    members = {'anykernel.sh': (script, 0o755), 'payload/boot.img': (boot, 0o644)}
    for folder in ('tools', 'META-INF'):
        for path in sorted((ak3 / folder).rglob('*')):
            if path.is_file() and not path.name.endswith('placeholder'):
                require(not path.is_symlink(), 'AnyKernel3 contains linked payload')
                members[path.relative_to(ak3).as_posix()] = (path.read_bytes(), path.stat().st_mode & 0o777)
    for path in ak3.glob('LICENSE*'):
        members[path.name] = (regular(path), 0o644)
    for name, entry in rmnet.items():
        members['payload/rmnet/' + name] = entry
    readme = ('VEUX R5/CASS build-derived installer; static checks, no device boot claim.\n'
              'RMNET identity and hashes are derived from this exact build output set.\n'
              'The unchanged R3 flow stages RMNET before already-present boot exit.\n'
              'NoMount 21-to-22 transition, boot backup and readback are preserved.\n'
              'Only active boot is written; no vendor_boot, DTBO, vbmeta or live module load.\n'
              'The known Spoofed Manager and official NoMount605 remain separate companions.\n'
              'Boot SHA256: ' + sha(boot) + '\nKernel notes SHA256: ' + checks['kernel_notes_sha256'] + '\n')
    members['READ_ME.txt'] = (readme.encode(), 0o644)
    members['SHA256SUMS'] = (''.join(f'{sha(value[0])}  {name}\n' for name, value in sorted(members.items())).encode(), 0o644)
    output = args.out / 'VEUX_CASS_BUILD_INSTALL_R3.zip'
    write_zip(output, members)
    result = {'file': output.name, 'sha256': sha(output.read_bytes()), 'bytes': output.stat().st_size,
              'boot_sha256': sha(boot), 'installer_sha256': sha(script),
              'rmnet_manifest_sha256': sha(rmnet['SHA256SUMS'][0]),
              'unchanged_installer_template_sha256': ASSETS['assets/anykernel.sh.in'],
              'ak3_commit': AK3_COMMIT, 'ak3_tree': AK3_TREE, 'runtime_payloads_unchanged': True,
              'generated_identity': True, 'device_test': False, 'archive_crc_and_members': 'PASS'}
    (args.out / 'INSTALLER_PACKAGE_CHECK.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def build(args):
    require(not args.out.exists(), 'output directory must be new')
    private = (args.base_boot, args.magiskboot, args.avbtool, args.ak3)
    require(all(private) or not any(private), 'boot packaging needs all four explicit private/tool inputs')
    data, receipt, checks = validate_inputs(args.inputs, args.receipt)
    for name, expected in ASSETS.items():
        pinned(HERE / name, expected)
    args.out.mkdir(parents=True)
    (args.out / 'BUILD_OUTPUTS.json').write_bytes(regular(args.receipt))
    (args.out / 'BUILD_PACKAGE_CHECK.json').write_text(json.dumps(checks, indent=2) + '\n')
    rmnet = make_rmnet(data, checks, args.out / 'rmnet')
    write_zip(args.out / 'VEUX_CASS_RMNET_BUILD_DATA.zip', {'rmnet/' + name: value for name, value in rmnet.items()})
    result = {'status': 'RAW_AND_RMNET_VALIDATED', 'kernel_release': checks['kernel_release'],
              'kernel_notes_sha256': checks['kernel_notes_sha256'], 'origin': receipt['origin'],
              'device_test': False, 'boot_packaging': 'NOT_REQUESTED_PRIVATE_INPUT_REQUIRED',
              'rmnet_archive': output_record(args.out / 'VEUX_CASS_RMNET_BUILD_DATA.zip')}
    if all(private):
        boot, boot_report = make_boot(args, data, checks)
        installer = make_installer(args, boot, rmnet, checks)
        result.update(status='BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED',
                      boot_packaging='COMPLETED', boot_sha256=boot_report['boot_sha256'], installer=installer)
    for argument, pin_name, output_name in (
        (args.manager_apk, 'manager_apk', 'BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk'),
        (args.nomount_zip, 'nomount_zip', 'NoMount-v2.2.0-release-bf1847f-605.zip')):
        if argument:
            content = pinned(argument, PINS[pin_name])
            (args.out / output_name).write_bytes(content)
    result['companions'] = {'manager_spoofed35252': bool(args.manager_apk), 'nomount605': bool(args.nomount_zip)}
    (args.out / 'PACKAGE_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs', 'receipt', 'out'):
        parser.add_argument('--' + name, type=lambda value: Path(value).absolute(), required=True)
    for name in ('base-boot', 'magiskboot', 'avbtool', 'ak3', 'manager-apk', 'nomount-zip'):
        parser.add_argument('--' + name, type=lambda value: Path(value).absolute())
    args = parser.parse_args()
    try:
        result = build(args)
    except Exception as error:
        print('PACKAGING_BLOCKED: ' + str(error), file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
