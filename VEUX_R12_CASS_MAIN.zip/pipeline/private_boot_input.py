#!/usr/bin/env python3
"""Read an explicitly enabled private HTTPS boot input; never print its URL."""
import argparse
import hashlib
import os
from pathlib import Path
import urllib.parse
import urllib.request

EXPECTED_SHA = 'fe7093b0bf154e162c4474a4ded3c9a89be431bc8f12b0d0be1738b88091a263'
MAX_BYTES = 128 * 1024 * 1024


class HTTPSOnly(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme != 'https':
            raise ValueError('PRIVATE_INPUT_REDIRECT_NOT_HTTPS')
        return super().redirect_request(request, fp, code, message, headers, newurl)


def obtain(target):
    value = os.environ.get('VEUX_BOOT_TEMPLATE_URL', '')
    url = urllib.parse.urlsplit(value)
    if (url.scheme != 'https' or not url.hostname or url.username or url.password
            or any(c in value for c in '\r\n\x00')):
        raise ValueError('PRIVATE_BOOT_SECRET_MISSING_OR_NOT_HTTPS')
    if target.exists() or target.is_symlink():
        raise ValueError('PRIVATE_BOOT_DESTINATION_EXISTS')
    target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    digest, total = hashlib.sha256(), 0
    try:
        opener = urllib.request.build_opener(HTTPSOnly())
        with opener.open(value, timeout=90) as response, target.open('xb') as out:
            target.chmod(0o600)
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                total += len(block)
                if total > MAX_BYTES:
                    raise ValueError('PRIVATE_BOOT_TOO_LARGE')
                digest.update(block)
                out.write(block)
        if digest.hexdigest() != EXPECTED_SHA:
            raise ValueError('PRIVATE_BOOT_SHA_MISMATCH')
    except Exception:
        target.unlink(missing_ok=True)
        # urllib exception strings can contain the private signed URL.
        raise ValueError('PRIVATE_BOOT_DOWNLOAD_OR_SHA_CHECK_FAILED') from None
    print('PRIVATE_BOOT_INPUT_AUTHENTICATED')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    try:
        obtain(a.out)
    except Exception as exc:
        raise SystemExit(str(exc)) from None


if __name__ == '__main__':
    main()
