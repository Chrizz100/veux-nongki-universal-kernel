#!/usr/bin/env python3
"""Validate the final workflow bytes and authenticated payload before a build."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import yaml


def run(command):
    result = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        raise ValueError('STATIC_COMMAND_FAILED:' + json.dumps(command) + '\n' + result.stdout)
    return {'command': command, 'exit': 0, 'output': result.stdout}


def audit(payload, workflow, actionlint, out):
    payload, workflow = payload.resolve(), workflow.resolve()
    out.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((payload / 'PAYLOAD_MANIFEST.json').read_text())
    for name, expected in manifest['files'].items():
        file = payload / name
        if file.is_symlink() or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
            raise ValueError('EXTRACTED_PAYLOAD_CHANGED:' + name)
    document = yaml.safe_load(workflow.read_text())
    if set(document['on']) != {'workflow_dispatch'} or document['permissions'] != {'contents': 'read'}:
        raise ValueError('UNEXPECTED_TRIGGER_OR_WRITE_PERMISSION')
    job = document['jobs']['r5s2_bakasu_522']
    if "github.ref == 'refs/heads/main'" not in job['if']:
        raise ValueError('MAIN_GUARD_MISSING')
    seen, records, embedded, python_files = set(), [], 0, 0
    for file in payload.rglob('*.py'):
        ast.parse(file.read_text(), filename=str(file))
        python_files += 1
    for i, step in enumerate(job['steps']):
        if 'id' in step:
            if step['id'] in seen:
                raise ValueError('DUPLICATE_STEP_ID')
            seen.add(step['id'])
        if 'uses' in step and not re.fullmatch(r'[^@]+@[0-9a-f]{40}', step['uses']):
            raise ValueError('ACTION_NOT_COMMIT_PINNED')
        if 'run' not in step:
            continue
        if step.get('shell') != 'bash':
            raise ValueError('UNREVIEWED_SHELL')
        script = out / f'workflow-step-{i:02}.sh'
        script.write_text(step['run'])
        records.append(run(['bash', '-n', str(script)]))
        records.append(run(['shellcheck', '--shell=bash', '--severity=error', str(script)]))
        lines = step['run'].splitlines()
        for j, line in enumerate(lines):
            match = re.search(r"<<'(PY[A-Za-z0-9_]*)'", line)
            if match:
                marker = match.group(1)
                end = next(k for k in range(j + 1, len(lines)) if lines[k] == marker)
                ast.parse('\n'.join(lines[j + 1:end]) + '\n', filename=str(script))
                embedded += 1
    required = {'r9_auth', 'r9_static', 'r9_environment', 'r9_fresh_rmnet', 'r9_raw',
                'r9_boot_input', 'r9_boot', 'r4_verify', 'r9_private_cleanup'}
    if not required <= seen:
        raise ValueError('REQUIRED_STAGE_MISSING')
    raw = next(s for s in job['steps'] if s.get('id') == 'r9_raw_upload')
    boot = next(s for s in job['steps'] if s.get('id') == 'r9_boot_upload')
    if "steps.r9_raw.conclusion == 'success'" not in raw.get('if', ''):
        raise ValueError('RAW_UPLOAD_NOT_GATED')
    if "steps.r9_boot.conclusion == 'success'" not in boot.get('if', ''):
        raise ValueError('BOOT_UPLOAD_NOT_GATED')
    for step in job['steps']:
        if step.get('uses', '').startswith('actions/upload-artifact@'):
            paths = step['with']['path'].splitlines()
            if any('r9-private' in p or 'ramdisk.cpio' in p for p in paths):
                raise ValueError('PRIVATE_INPUT_IN_ARTIFACT_PATH')
            if any(p.rstrip('/').endswith('/r9-boot') for p in paths):
                raise ValueError('BOOT_WORK_DIRECTORY_UPLOADED_WHOLE')
    for file in sorted((payload / 'pipeline/assets').rglob('*')):
        if file.suffix == '.sh' or file.name == 'anykernel.sh.in':
            records.append(run(['sh', '-n', str(file)]))
            records.append(run(['shellcheck', '--shell=sh', '--severity=error', str(file)]))
    records.append(run([str(actionlint.resolve()), '-oneline', str(workflow)]))
    report = {'status': 'STATIC_GREEN_PASS', 'workflow_sha256': hashlib.sha256(workflow.read_bytes()).hexdigest(),
              'payload_files': len(manifest['files']), 'python_files_ast_checked': python_files,
              'embedded_python_blocks': embedded, 'steps': len(job['steps']), 'commands': records,
              'scope': 'workflow syntax, pinned inputs, shell/Python syntax, actionlint/ShellCheck, artifact gates',
              'kernel_compile_performed': False, 'device_test': False}
    (out / 'STATIC_GREEN_PASS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'commands'}))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--payload', type=Path, required=True)
    p.add_argument('--workflow', type=Path, required=True)
    p.add_argument('--actionlint', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    audit(a.payload, a.workflow, a.actionlint, a.out)
