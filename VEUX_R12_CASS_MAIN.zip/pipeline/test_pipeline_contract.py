#!/usr/bin/env python3
"""Negative tests of archive authentication, private-input and upload contracts."""
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import bootstrap_payload
import private_boot_input
import verify_final_outputs


def digest(data):
    return hashlib.sha256(data).hexdigest()


class PayloadTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def fixture(self, entries=None, manifest_files=None, duplicate=False, symlink=False):
        entries = {'pipeline/entry.py': b'print("fixture")\n'} if entries is None else entries
        manifest = {'schema': 1, 'automatic_flash': False,
                    'files': manifest_files if manifest_files is not None
                    else {k: digest(v) for k, v in entries.items()}}
        raw = json.dumps(manifest).encode()
        archive = self.root / 'fixture.zip'
        with zipfile.ZipFile(archive, 'w') as z:
            z.writestr('PAYLOAD_MANIFEST.json', raw)
            for name, data in entries.items():
                info = zipfile.ZipInfo(name)
                info.external_attr = (stat.S_IFLNK | 0o777) << 16 if symlink else (stat.S_IFREG | 0o644) << 16
                z.writestr(info, data)
                if duplicate:
                    import warnings
                    with warnings.catch_warnings():
                        warnings.simplefilter('ignore', UserWarning)
                        z.writestr(info, data)
        return [archive, self.root / 'extracted', digest(archive.read_bytes()), digest(raw)]

    def test_valid_bytes_extract_once(self):
        args = self.fixture()
        result = bootstrap_payload.extract(*args)
        self.assertEqual(result['status'], 'AUTHENTICATED')
        self.assertEqual((args[1] / 'pipeline/entry.py').read_bytes(), b'print("fixture")\n')
        with self.assertRaisesRegex(ValueError, 'DESTINATION_EXISTS'):
            bootstrap_payload.extract(*args)

    def test_wrong_archive_sha(self):
        args = self.fixture(); args[2] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'ARCHIVE_SHA_CHANGED'):
            bootstrap_payload.extract(*args)

    def test_wrong_manifest_sha(self):
        args = self.fixture(); args[3] = '0' * 64
        with self.assertRaisesRegex(ValueError, 'MANIFEST_SHA_CHANGED'):
            bootstrap_payload.extract(*args)

    def test_file_hash_changed(self):
        args = self.fixture(manifest_files={'pipeline/entry.py': '0' * 64})
        with self.assertRaisesRegex(ValueError, 'FILE_SHA_CHANGED'):
            bootstrap_payload.extract(*args)

    def test_missing_and_extra_entries(self):
        for files in ({'absent.py': '0' * 64}, {'pipeline/entry.py': digest(b'print("fixture")\n'), 'absent.py': '0' * 64}):
            with self.subTest(files=files), self.assertRaisesRegex(ValueError, 'UNMANIFESTED_OR_MISSING'):
                bootstrap_payload.extract(*self.fixture(manifest_files=files))

    def test_duplicate_entry(self):
        with self.assertRaisesRegex(ValueError, 'DUPLICATE'):
            bootstrap_payload.extract(*self.fixture(duplicate=True))

    def test_symlink_entry(self):
        with self.assertRaisesRegex(ValueError, 'UNSAFE'):
            bootstrap_payload.extract(*self.fixture(symlink=True))

    def test_unsafe_paths(self):
        for name in ('../escape.py', '/escape.py', 'pipeline\\entry.py', './entry.py', 'pipeline//entry.py'):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, 'UNSAFE'):
                bootstrap_payload.extract(*self.fixture(entries={name: b'fixture'}))
        self.assertFalse((self.root.parent / 'escape.py').exists())

    def test_private_input_without_valid_https_never_opens_network(self):
        for value in ('', 'http://example.invalid/boot', 'https://a:b@example.invalid/boot', 'https://example.invalid/\n'):
            with self.subTest(value=value), patch.dict(os.environ, {'VEUX_BOOT_TEMPLATE_URL': value}), \
                    patch('urllib.request.build_opener') as network, self.assertRaises(ValueError):
                private_boot_input.obtain(self.root / 'private.img')
            network.assert_not_called()

    def test_private_existing_target_is_not_replaced(self):
        target = self.root / 'private.img'; target.write_bytes(b'keep')
        with patch.dict(os.environ, {'VEUX_BOOT_TEMPLATE_URL': 'https://example.invalid/boot'}), \
                patch('urllib.request.build_opener') as network, self.assertRaisesRegex(ValueError, 'DESTINATION_EXISTS'):
            private_boot_input.obtain(target)
        network.assert_not_called(); self.assertEqual(target.read_bytes(), b'keep')


class FinalGateTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def result(self, status, origin='same-build-invocation', device=False):
        archive = self.root / 'VEUX_CASS_RMNET_BUILD_DATA.zip'; archive.write_bytes(b'unit test fixture')
        (self.root / 'PACKAGE_RESULT.json').write_text(json.dumps({'status': status, 'device_test': device,
            'origin': origin, 'rmnet_archive': {'file': archive.name, 'sha256': digest(archive.read_bytes()),
                                               'bytes': archive.stat().st_size}}))
        receipt = self.root / 'BUILD_OUTPUTS.json'; receipt.write_text(json.dumps({'origin': origin}))
        (self.root / 'BUILD_PACKAGE_CHECK.json').write_text(json.dumps({
            'origin': origin, 'source_receipt_sha256': digest(receipt.read_bytes())}))

    def test_failed_or_incomplete_status_cannot_upload(self):
        for status in ('RUNNING', 'FAILED', 'RAW_AND_RMNET_VALIDATED'):
            self.result(status)
            with self.assertRaisesRegex(ValueError, 'TERMINAL_STATUS'):
                verify_final_outputs.verify(self.root, 'boot')

    def test_local_replay_cannot_be_exported_as_new_ci_build(self):
        self.result('RAW_AND_RMNET_VALIDATED', 'existing-native-kernel-plus-fresh-external-modules')
        with self.assertRaisesRegex(ValueError, 'SAME_INVOCATION'):
            verify_final_outputs.verify(self.root, 'raw')

    def test_false_device_pass_is_rejected(self):
        self.result('RAW_AND_RMNET_VALIDATED', device=True)
        with self.assertRaisesRegex(ValueError, 'TERMINAL_STATUS'):
            verify_final_outputs.verify(self.root, 'raw')

    def test_missing_raw_file_is_not_uploaded(self):
        self.result('RAW_AND_RMNET_VALIDATED')
        (self.root / 'VEUX_CASS_RMNET_BUILD_DATA.zip').unlink()
        with self.assertRaisesRegex(ValueError, 'RMNET_ARCHIVE_CHANGED'):
            verify_final_outputs.verify(self.root, 'raw')

    def test_modified_rmnet_archive_is_rejected(self):
        self.result('RAW_AND_RMNET_VALIDATED')
        (self.root / 'VEUX_CASS_RMNET_BUILD_DATA.zip').write_bytes(b'substituted archive')
        with self.assertRaisesRegex(ValueError, 'RMNET_ARCHIVE_CHANGED'):
            verify_final_outputs.verify(self.root, 'raw')

    def test_replaced_receipt_is_rejected(self):
        self.result('RAW_AND_RMNET_VALIDATED')
        (self.root / 'BUILD_OUTPUTS.json').write_text('{"origin":"same-build-invocation","different":true}')
        with self.assertRaisesRegex(ValueError, 'RECEIPT_PROVENANCE_CHANGED'):
            verify_final_outputs.verify(self.root, 'raw')

    def test_modified_boot_hash_is_rejected(self):
        self.result('BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED')
        (self.root / 'boot.img').write_bytes(b'changed fixture')
        result = json.loads((self.root / 'PACKAGE_RESULT.json').read_text()); result['boot_sha256'] = '0' * 64
        (self.root / 'PACKAGE_RESULT.json').write_text(json.dumps(result))
        with self.assertRaisesRegex(ValueError, 'BOOT_OUTPUT_CHANGED'):
            verify_final_outputs.verify(self.root, 'boot')

    def test_consistent_raw_unit_fixture_produces_verifiable_manifest(self):
        self.result('RAW_AND_RMNET_VALIDATED')
        verify_final_outputs.verify(self.root, 'raw')
        result = json.loads((self.root / 'FINAL_OUTPUT_MANIFEST.json').read_text())
        for name, item in result['files'].items():
            self.assertEqual(digest((self.root / name).read_bytes()), item['sha256'])
        self.assertEqual(len(result['files']), 4)

    def test_consistent_boot_unit_fixture_produces_verifiable_manifest(self):
        self.result('BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED')
        boot = self.root / 'boot.img'; boot.write_bytes(b'unit fixture, not a device image')
        installer = self.root / 'VEUX_CASS_BUILD_INSTALL_R3.zip'; installer.write_bytes(b'unit fixture')
        for name in ('BOOT_PACKAGE_CHECK.json', 'INSTALLER_PACKAGE_CHECK.json'):
            (self.root / name).write_text('{}')
        result = json.loads((self.root / 'PACKAGE_RESULT.json').read_text())
        result.update(boot_sha256=digest(boot.read_bytes()), installer={
            'file': installer.name, 'sha256': digest(installer.read_bytes())})
        (self.root / 'PACKAGE_RESULT.json').write_text(json.dumps(result))
        verify_final_outputs.verify(self.root, 'boot')
        self.assertEqual(len(json.loads((self.root / 'FINAL_OUTPUT_MANIFEST.json').read_text())['files']), 8)


if __name__ == '__main__':
    unittest.main(verbosity=2)
