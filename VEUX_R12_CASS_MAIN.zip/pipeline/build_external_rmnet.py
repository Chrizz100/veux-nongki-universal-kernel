#!/usr/bin/env python3
"""Compile the two external RMNET modules against the recorded candidate build."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

PARSER_SHA = 'a7c0c2d9782d65852a2374ed7b54644c1c19f33f943957c921eac4862c310e0c'
PAIRS = {'rmnet_offload': 'offload', 'rmnet_shs': 'shs'}
DTB = 'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def need(ok, message):
    if not ok:
        raise ValueError(message)

def run(command, env, log):
    with log.open('w') as f:
        f.write('COMMAND=' + json.dumps(command) + '\n')
        f.flush()
        result = subprocess.run(command, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=1800)
    need(result.returncode == 0, 'command failed: ' + str(log))
    return {'exit': result.returncode, 'command': command, 'log_sha256': sha(log)}

def build(args):
    stage = args.stage.resolve(strict=True)
    obj, source, evidence = stage / 'build', stage / 'source/kernel', stage / 'evidence'
    command_record = json.loads((evidence / 'BUILD_COMMAND.json').read_text())
    native = json.loads((evidence / 'NATIVE_BUILD_RESULT.json').read_text())
    need(native.get('status') == 'NATIVE_CASS_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
         and native.get('native_compile_completed') is True and native.get('static_gates_passed') is True,
         'native candidate build has not passed')
    if args.evidence_mode == 'ci':
        result = json.loads((evidence / 'R4_RESULT.json').read_text())
        need(result.get('status') == 'CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
             and result.get('original_baseline_unchanged') is True, 'R4 complete build proof missing')
    need(re.fullmatch('[0-9a-f]{40}', args.repo_commit), 'invalid integration repository commit')
    need(1 <= args.jobs <= 12, 'jobs out of range')
    need(not args.out.exists(), 'output directory already exists')
    need(Path(command_record['source']).resolve() == source.resolve(), 'recorded candidate source changed')
    variables = dict(command_record['variables'])
    need(Path(variables['O']).resolve() == obj.resolve(), 'recorded object tree changed')
    need(variables.get('ARCH') == 'arm64', 'not ARM64')
    env = dict(os.environ, **command_record['original_captured_env'])
    env.pop('VEUX_CAPTURE', None)
    # The historical worker's make wrapper must never intercept the new M= build.
    env['PATH'] = os.pathsep.join(p for p in env['PATH'].split(os.pathsep)
                                if not p.rstrip('/').endswith('/source-temp/bin'))
    for key in ('KSU_NO_PREINIT', 'KSU_VERSION', 'KSU_LOCAL_VERSION', 'KSU_COMMIT_SHA', 'KSU_TAG_NAME'):
        need(key not in variables and not env.get(key), 'forbidden provider override: ' + key)
    parser = Path(__file__).parent / 'vendor/veux_rmnet.py'
    need(sha(parser) == PARSER_SHA, 'audited RMNET parser changed')
    spec = importlib.util.spec_from_file_location('repro_rmnet_parser', parser)
    rm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rm)
    image = obj / 'arch/arm64/boot/Image'
    tracked = [image, obj / '.config', obj / 'Module.symvers', obj / 'System.map', obj / DTB]
    before = {str(p): sha(p) for p in tracked}
    proof = native['proof']
    for name, item in proof['outputs'].items():
        need(sha(obj / name) == item['sha256'], 'recorded build output changed: ' + name)
    notes = rm.note_from_kernel(image.read_bytes(), (obj / 'System.map').read_bytes())
    need(rm.Elf64((obj / 'vmlinux').read_bytes()).section('.notes') == notes,
         'Image and vmlinux notes differ')
    exports = rm.exports_from((obj / 'Module.symvers').read_bytes())
    release = (obj / 'include/config/kernel.release').read_text().strip()
    args.out.mkdir(parents=True)
    logs = args.out / 'logs'
    logs.mkdir()
    base = ['/usr/bin/make', '-C', str(source)] + [f'{k}={v}' for k, v in variables.items()]
    run([*base, f'-j{args.jobs}', 'modules_prepare'], env, logs / 'modules_prepare.log')
    need(all(sha(Path(p)) == digest for p, digest in before.items()), 'modules_prepare changed candidate')
    module_builds, module_proofs = {}, {}
    for name, folder in PAIRS.items():
        module_source = source / 'techpack/datarmnet-ext' / folder
        need(module_source.is_dir() and not module_source.is_symlink(), 'external module source missing')
        inventory = {p.name: sha(p) for p in module_source.iterdir() if p.is_file()
                     and (p.suffix in ('.c', '.h') or p.name in ('Makefile', 'Kbuild'))
                     and not p.name.endswith('.mod.c')}
        need('Kbuild' in inventory, 'module Kbuild missing')
        clean = run([*base, 'M=' + str(module_source), 'clean'], env, logs / (name + '-clean.log'))
        module_file = module_source / (name + '.ko')
        need(not module_file.exists(), 'old module survived clean')
        command = [*base, f'-j{args.jobs}', 'M=' + str(module_source),
                   'RMNET_CORE_INC_DIR=' + str(source / 'techpack/datarmnet/core'),
                   'KBUILD_EXTRA_SYMBOLS=', 'modules']
        record = run(command, env, logs / (name + '-compile.log'))
        messages = (logs / (name + '-compile.log')).read_text(errors='replace')
        need(not re.search(r'\bwarning:|fatal error:|\berror:|undefined reference', messages),
             'module compiler diagnostics need review: ' + name)
        need(all(sha(module_source / p) == h for p, h in inventory.items()), 'module sources changed')
        protected = []
        for filename in inventory:
            if filename.endswith('.c'):
                cmdfile = module_source / ('.' + Path(filename).stem + '.o.cmd')
                command_text = cmdfile.read_text()
                need(all(flag in command_text for flag in ('-fsanitize=cfi', '-flto=thin', '-fstack-protector-strong')),
                     'compiled module protections missing: ' + filename)
                protected.append(filename)
        need(protected, 'no module translation unit compiled')
        module_proofs[name] = rm.inspect_module(module_file, exports, release, name)
        record.update(output_path=str(module_file), sha256=sha(module_file),
                      clean=clean, source_files_sha256=inventory, protected_units=sorted(protected))
        module_builds[name] = record
        shutil.copy2(module_file, args.out / module_file.name)
    need(all(sha(Path(p)) == digest for p, digest in before.items()), 'external module build changed candidate')
    for source_file, target in ((image, 'Image'), (obj / '.config', 'actual-build.config'),
                                (obj / 'System.map', 'System.map'), (obj / 'Module.symvers', 'Module.symvers'),
                                (obj / DTB, 'veux.dtb')):
        shutil.copy2(source_file, args.out / target)
    files = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p)}
             for p in sorted(args.out.iterdir()) if p.is_file()}
    receipt = {
        'schema': 'veux-build-output-v1',
        'origin': ('same-build-invocation' if args.evidence_mode == 'ci'
                   else 'existing-native-kernel-plus-fresh-external-modules'),
        'kernel_release': release, 'bakasu_marker': proof['bakasu_version_marker'], 'nomount_api': 22,
        'provenance': {'source_commit': args.repo_commit, 'source_checks_passed': True,
                       'evidence_mode': args.evidence_mode,
                       'kernel_compile_reused': args.evidence_mode == 'local-native',
                       'kernel_compiled_by_this_helper': False,
                       'kernel_compile_evidence_reused_from_existing_local_build': args.evidence_mode == 'local-native',
                       'kernel_compile_exit': 0, 'module_compile_exit': 0,
                       'kernel_command': [*base, f'-j{command_record["jobs"]}', 'Image', 'dtbs', 'modules'],
                       'module_command': ['see external_module_builds for both independently logged M= invocations'],
                       'external_module_builds': module_builds,
                       'kernel_build_record_sha256': sha(evidence / 'BUILD_COMMAND.json'),
                       'native_build_result_sha256': sha(evidence / 'NATIVE_BUILD_RESULT.json')},
        'files': files,
    }
    (args.out / 'BUILD_OUTPUTS.json').write_text(json.dumps(receipt, indent=2) + '\n')
    (args.out / 'FRESH_RMNET_ABI.json').write_text(json.dumps(module_proofs, indent=2) + '\n')
    print(json.dumps({'fresh_external_modules': True, 'base_kernel_unchanged': True,
                      'input_receipt': str(args.out / 'BUILD_OUTPUTS.json'), 'device_test': False}))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--repo-commit', required=True)
    p.add_argument('--jobs', type=int, default=4)
    p.add_argument('--evidence-mode', choices=('ci', 'local-native'), default='ci')
    args = p.parse_args()
    try:
        build(args)
    except Exception as exc:
        raise SystemExit('EXTERNAL_RMNET_BLOCKED: ' + str(exc))

if __name__ == '__main__':
    main()
