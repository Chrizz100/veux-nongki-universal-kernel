#!/usr/bin/env python3
"""Exercise final RMNET archive metadata against real local build outputs.

This runs only raw packaging. The earlier full boot run is read for an explicit
metadata postcheck; it is not presented as a new full boot/installer replay.
"""
from pathlib import Path
import argparse
import hashlib
import json
import tempfile
import zipfile
import package_build as p

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parents[2]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    inputs = WORK / 'work_r9_reproducible_build/local_fresh_inputs'
    evidence = ROOT / 'test_evidence/result_metadata'
    evidence.mkdir(parents=True, exist_ok=True)
    scratch_root = ROOT / 'test_workspace'
    scratch_root.mkdir(exist_ok=True)
    checks = {}
    with tempfile.TemporaryDirectory(prefix='archive-metadata-', dir=scratch_root) as temp:
        args = argparse.Namespace(inputs=inputs, receipt=inputs/'BUILD_OUTPUTS.json',
                                  out=Path(temp)/'raw', base_boot=None, magiskboot=None,
                                  avbtool=None, ak3=None, manager_apk=None, nomount_zip=None)
        result = p.build(args)
        archive = args.out / 'VEUX_CASS_RMNET_BUILD_DATA.zip'
        expected = {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size}
        assert result['rmnet_archive'] == expected
        assert json.loads((args.out/'PACKAGE_RESULT.json').read_text()) == result
        checks['actual_raw_result_binds_archive_filename_hash_and_size'] = 'PASS'

        receipt = json.loads(args.receipt.read_text())
        proof = json.loads((args.out/'BUILD_PACKAGE_CHECK.json').read_text())
        assert proof['source_receipt_sha256'] == sha(args.receipt)
        assert receipt['origin'] == proof['origin'] == result['origin'] == 'existing-native-kernel-plus-fresh-external-modules'
        checks['exact_report_fields_and_receipt_origin_binding'] = 'PASS'

        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            assert len(z.namelist()) == 7
            for name in ('rmnet_offload.ko','rmnet_shs.ko'):
                assert hashlib.sha256(z.read('rmnet/'+name)).hexdigest() == receipt['files'][name]['sha256']
            identity = z.read('rmnet/identity.txt').decode()
            assert 'KERNEL_NOTES_SHA256='+proof['kernel_notes_sha256']+'\n' in identity
            for line in z.read('rmnet/SHA256SUMS').decode().splitlines():
                digest, name = line.split('  ', 1)
                assert hashlib.sha256(z.read('rmnet/'+name)).hexdigest() == digest
        checks['archive_members_match_receipt_current_notes_and_manifest'] = 'PASS'

        previous_full = ROOT / 'local_native_full/VEUX_CASS_RMNET_BUILD_DATA.zip'
        previous_record = p.output_record(previous_full)
        assert previous_record == expected
        assert previous_full.read_bytes() == archive.read_bytes()
        checks['previous_full_rmnet_bytes_equal_new_raw_bytes'] = 'PASS'
        prior = json.loads((ROOT/'LOCAL_NATIVE_PACKAGING_CHECK.json').read_text())
        postcheck = {'scope':'metadata-only postcheck of an earlier complete boot run',
                     'prior_full_runner_sha256':prior['runner_sha256'],
                     'prior_boot_sha256':prior['boot_sha256'], 'full_boot_reexecuted':False,
                     'rmnet_archive':previous_record}
        (evidence/'EARLIER_FULL_ARCHIVE_POSTCHECK.json').write_text(json.dumps(postcheck,indent=2)+'\n')
        for name in ('PACKAGE_RESULT.json','BUILD_PACKAGE_CHECK.json'):
            (evidence/name).write_bytes((args.out/name).read_bytes())

    report = {'status':'PASS', 'runner_sha256':sha(ROOT/'package_build.py'),
              'checks':checks,'count':len(checks), 'actual_raw_packaging_executed':True,
              'kernel_compile_performed':False,'full_boot_reexecuted':False,'device_test':False,
              'prior_full_runner_sha256':prior['runner_sha256'],
              'rmnet_archive':expected,
              'scope':'Final result-metadata extension only; prior full boot evidence retains its original runner hash.'}
    (ROOT/'PACKAGING_METADATA_TEST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
