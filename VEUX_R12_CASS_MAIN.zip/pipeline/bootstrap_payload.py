#!/usr/bin/env python3
"""Authenticate every executable payload byte before extracting a new directory."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile


def extract(archive, destination, archive_sha, manifest_sha):
    archive, destination = Path(archive), Path(destination)
    if destination.exists() or destination.is_symlink():
        raise ValueError('PAYLOAD_DESTINATION_EXISTS')
    if hashlib.sha256(archive.read_bytes()).hexdigest() != archive_sha:
        raise ValueError('PAYLOAD_ARCHIVE_SHA_CHANGED')
    with zipfile.ZipFile(archive) as source:
        items = source.infolist()
        names = [item.filename for item in items]
        if len(names) != len(set(names)):
            raise ValueError('DUPLICATE_ZIP_ENTRY')
        if sum(item.file_size for item in items) > 100 * 1024 * 1024:
            raise ValueError('PAYLOAD_TOO_LARGE')
        for item in items:
            path = PurePosixPath(item.filename)
            if (path.is_absolute() or '..' in path.parts or '.' in path.parts
                    or str(path) != item.filename or '\\' in item.filename
                    or item.is_dir() or '\x00' in item.filename
                    or stat.S_ISLNK(item.external_attr >> 16)):
                raise ValueError('UNSAFE_PAYLOAD_PATH')
        if source.testzip() is not None:
            raise ValueError('PAYLOAD_ZIP_CRC_FAILED')
        raw = source.read('PAYLOAD_MANIFEST.json')
        if hashlib.sha256(raw).hexdigest() != manifest_sha:
            raise ValueError('PAYLOAD_MANIFEST_SHA_CHANGED')
        manifest = json.loads(raw)
        if manifest.get('schema') != 1 or manifest.get('automatic_flash') is not False:
            raise ValueError('UNTRUSTED_MANIFEST_SCHEMA')
        files = manifest.get('files')
        if (not isinstance(files, dict) or not files
                or not all(isinstance(k, str) and isinstance(v, str)
                           and re.fullmatch('[0-9a-f]{64}', v) for k, v in files.items())):
            raise ValueError('INVALID_PAYLOAD_HASH_MAP')
        if set(names) != set(files) | {'PAYLOAD_MANIFEST.json'}:
            raise ValueError('UNMANIFESTED_OR_MISSING_ENTRY')
        for name, expected in files.items():
            if hashlib.sha256(source.read(name)).hexdigest() != expected:
                raise ValueError('PAYLOAD_FILE_SHA_CHANGED:' + name)
        destination.mkdir(parents=True)
        for name in sorted(names):
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read(name))
    return {'status': 'AUTHENTICATED', 'files': len(files),
            'archive_sha256': archive_sha, 'manifest_sha256': manifest_sha,
            'automatic_flash': False}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--archive-sha256', required=True)
    p.add_argument('--manifest-sha256', required=True)
    a = p.parse_args()
    print(json.dumps(extract(a.archive, a.out, a.archive_sha256, a.manifest_sha256)))


if __name__ == '__main__':
    main()
