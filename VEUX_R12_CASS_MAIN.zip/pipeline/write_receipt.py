#!/usr/bin/env python3
"""Record completed build outputs; this command does not compile or invent provenance.

The caller supplies its actual command/exit/source evidence as JSON. Fresh
external modules need separate build receipts; make Image/dtbs/modules alone
does not establish their origin. Full content gates run in package_build.py.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import package_build

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, required=True)
    parser.add_argument('--provenance', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--origin', choices=package_build.ORIGINS, required=True)
    parser.add_argument('--bakasu-marker', required=True)
    args = parser.parse_args()
    package_build.require(not args.out.exists(), 'receipt output must not exist')
    records = {}
    image = None
    for name in package_build.REQUIRED:
        data = package_build.regular(args.inputs / name)
        records[name] = {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        if name == 'Image': image = data
    releases = re.findall(rb'Linux version ([0-9]+\.[0-9]+\.[^ \x00\n]+) ', image)
    package_build.require(len(set(releases)) == 1, 'kernel release missing or ambiguous')
    result = {'schema':'veux-build-output-v1','origin':args.origin,
              'kernel_release':releases[0].decode(),'bakasu_marker':args.bakasu_marker,
              'nomount_api':22,'provenance':json.loads(package_build.regular(args.provenance)),
              'files':records}
    args.out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    try:
        _, _, checked = package_build.validate_inputs(args.inputs, args.out)
    except Exception:
        args.out.unlink()
        raise
    print(json.dumps({'receipt':str(args.out),'sha256':package_build.sha(args.out.read_bytes()),
                      'kernel_notes_sha256':checked['kernel_notes_sha256'],
                      'origin':args.origin},indent=2))

if __name__ == '__main__':
    main()
