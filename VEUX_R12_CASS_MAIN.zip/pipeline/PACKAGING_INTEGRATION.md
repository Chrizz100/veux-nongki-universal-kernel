# VEUX: wiederholbare Verpackung eines geprüften CASS-Builds

Diese Komponente führt keine Kernelkompilierung, keinen Download und keinen
Gerätezugriff aus. Sie übernimmt die tatsächlichen Ergebnisse des Buildjobs,
prüft Image/Config/Modversions und erzeugt die dazu passende RMNET-Generation.
Bei explizit vorhandener privater Bootvorlage erstellt und prüft sie zusätzlich
Boot.img und den bekannten R3-Installer.

## Dateien für das Pipelinepaket

Zusammen unter demselben Verzeichnis übernehmen:

- `package_build.py`
- `write_receipt.py`
- `assets/anykernel.sh.in`
- `assets/rmnet/install.sh`
- `assets/rmnet/launcher.sh`
- `assets/rmnet/runtime.sh`
- `ASSET_SHA256.json`

Die vier Shellvorlagen sind byteidentisch mit dem bereits geprüften R3-Stand.
`package_build.py` kontrolliert ihre bekannten SHA256 zusätzlich selbst.
Die 43 früheren Installerfälle und drei Einstiegstests gelten weiterhin für
die reproduzierten identischen R3-Skriptbytes; das ersetzt keinen Test eines
neu kompilierten Kernels auf dem Telefon.

## 1. Ergebnisse einer Buildausführung flach bereitstellen

Das Eingabeverzeichnis enthält exakt diese sieben benötigten Dateien:

```text
Image
actual-build.config
System.map
Module.symvers
veux.dtb
rmnet_offload.ko
rmnet_shs.ko
```

Der frühere kombinierte `make Image dtbs modules` erzeugte nicht die beiden
externen RMNET-Module. Eine neue Ausführung, die frische Module beansprucht,
muss diese zusätzlich mit dem gleichen Kernelquellbaum, O-Verzeichnis und
Compiler über `M=techpack/datarmnet-ext/offload` und `M=.../shs` bauen. Die
konkreten Befehle und die tatsächlich erzeugten Dateien gehören in den
Provenienzdatensatz; ein bloßer Dateiname oder erfolgreicher Haupt-Make-Lauf
beweist diese Herkunft nicht.

## 2. Build-Provenienz aufzeichnen

Die Pipeline schreibt ihre tatsächlichen Ergebnisse in `provenance.json`.
Beispielstruktur; Platzhalter sind nicht auszuführende Beispielwerte:

```json
{
  "source_commit": "FULL_40_HEX_SOURCE_COMMIT",
  "source_checks_passed": true,
  "kernel_compile_exit": 0,
  "module_compile_exit": 0,
  "kernel_command": ["make", "... actual arguments ...", "Image", "dtbs", "modules"],
  "module_command": [["make", "... offload arguments ..."], ["make", "... shs arguments ..."]],
  "external_module_builds": {
    "rmnet_offload": {
      "exit": 0,
      "command": ["make", "... actual offload arguments ..."],
      "output_path": "... actual generated rmnet_offload.ko path ...",
      "sha256": "ACTUAL_OFFLOAD_SHA256"
    },
    "rmnet_shs": {
      "exit": 0,
      "command": ["make", "... actual shs arguments ..."],
      "output_path": "... actual generated rmnet_shs.ko path ...",
      "sha256": "ACTUAL_SHS_SHA256"
    }
  }
}
```

Die Schlüsselnamen sind fest. Weitere Angaben wie Compiler-Hash,
Quellbaum-Tree, Buildzeitvariablen, Herkunft der Inputs und Provider-Commits
können ergänzt werden und bleiben im gespeicherten Datensatz erhalten.
Die Pipeline muss `source_checks_passed` aus ihrem echten Quell-/Config-Gate
ableiten. Der Packaging-Runner übernimmt diesen Beleg; er behauptet nicht,
den gesamten Quellbaum aus den sieben Binärdateien rekonstruieren zu können.

Die eindeutige Herkunft steht im Receipt-Feld `origin`:

| Wert | Bedeutung |
| --- | --- |
| `same-build-invocation` | Der Workflow baut den Kernel und beide externen Module in derselben Ausführung. Beide Module besitzen erfolgreiche eigene Buildbelege mit passenden Ausgabehashes; eine wiederverwendete Kernelkompilierung ist ausgeschlossen. |
| `existing-native-kernel-plus-fresh-external-modules` | Ein vorhandener nativer Kernelbuild wird ausdrücklich wiederverwendet; nur die externen Module werden frisch dazu kompiliert. Erfordert `provenance.kernel_compile_reused=true` und `provenance.evidence_mode=local-native` sowie dieselben vollständigen externen Modulbelege und Inhaltsprüfungen. |
| `revalidated-reference-modules` | Ausschließlich die zwei bekannten unveränderten Referenzmodule werden gegen den neuen Kernel erneut geprüft. Dies ist ausdrücklich kein frischer Modulcompile. |
| `historical-reference-replay` | Lokale Wiederholung mit dem exakt bekannten historischen R5-Image und den bekannten Modulen; nur für die Reproduktionsprüfung. |

Referenzmodulmodus akzeptiert nur:

```text
a391f7991f96da6d0f0ccd567e7f410e75ddf69fe43d62bfda6c7b88d34da724  rmnet_offload.ko
ce30767b130fb0ddc2daffecf0d2379f12959450921d35ef3370097b2b04fd99  rmnet_shs.ko
```

Auch im Referenzmodus müssen alle Imports, `module_layout`, Vermagic, CFI und
die echte eingebettete Kernelkonfiguration passen. Die Identität der
RMNET-Datengeneration wird immer aus dem aktuellen Image/System.map neu
berechnet. Die historischen R5-Notes werden nicht in einen fremden Build kopiert.

## 3. Receipt erzeugen und prüfen

```sh
python3 pipeline/write_receipt.py \
  --inputs "$RUNNER_TEMP/veux-flat-build" \
  --provenance "$RUNNER_TEMP/provenance.json" \
  --origin same-build-invocation \
  --bakasu-marker 'v4.2.0-rc3-2cbbcc23@BakaSU' \
  --out "$RUNNER_TEMP/BUILD_OUTPUTS.json"
```

Der Marker muss zur tatsächlich festgelegten BakaSU-Quellversion passen.
Der Helfer leitet Kernelrelease, Dateigrößen und SHA256 aus den Dateien ab;
ein Receipt-Ziel muss neu sein. Der Receipt wird nur nach erfolgreicher
vollständiger Eingangsprüfung behalten.

## 4. Raw/RMNET-Paket ohne private Bootvorlage

```sh
python3 pipeline/package_build.py \
  --inputs "$RUNNER_TEMP/veux-flat-build" \
  --receipt "$RUNNER_TEMP/BUILD_OUTPUTS.json" \
  --out "$RUNNER_TEMP/veux-package"
```

Ausgaben:

- `BUILD_PACKAGE_CHECK.json`: tatsächliche Kernel- und Modulbelege.
- `BUILD_OUTPUTS.json`: unveränderter Receipt.
- `rmnet/`: die sieben generationseigenen Dateien.
- `VEUX_CASS_RMNET_BUILD_DATA.zip`: Datenpaket; kein allein flashbarer Installer.
- `PACKAGE_RESULT.json`: `RAW_AND_RMNET_VALIDATED`, Bootverpackung ausdrücklich
  `NOT_REQUESTED_PRIVATE_INPUT_REQUIRED`.

`PACKAGE_RESULT.json` bindet die fertig geprüfte RMNET-ZIP über
`rmnet_archive.file`, `rmnet_archive.sha256` und `rmnet_archive.bytes`.
Ein nachgelagertes Upload-Gate muss diese Werte gegen die tatsächliche Datei
prüfen. Es muss außerdem `BUILD_PACKAGE_CHECK.source_receipt_sha256` gegen
`BUILD_OUTPUTS.json` sowie `origin` zwischen Receipt, Prüfung und Ergebnis
vergleichen. Ein neu berechnetes Summenverzeichnis allein bestätigt keine
Übereinstimmung mit den vorher geprüften Ausgaben.

Es wird kein Platzhalter-Bootimage erzeugt. Die reguläre Kernelkompilierung
und ihre Raw-Ausgaben benötigen die private Vorlage nicht.

## 5. Optional vollständige Boot-/AK3-Verpackung

Alle vier Parameter müssen gemeinsam vorhanden sein:

```sh
python3 pipeline/package_build.py \
  --inputs "$RUNNER_TEMP/veux-flat-build" \
  --receipt "$RUNNER_TEMP/BUILD_OUTPUTS.json" \
  --out "$RUNNER_TEMP/veux-package-full" \
  --base-boot '/explicit/private/path/VEUX_BOOT_A_VOR_H13.img' \
  --magiskboot "$RUNNER_TEMP/tools/magiskboot-x86_64" \
  --avbtool "$RUNNER_TEMP/tools/avb/avbtool" \
  --ak3 "$RUNNER_TEMP/tools/AnyKernel3"
```

Die Vorlage ist nur mit SHA256
`fe7093b0bf154e162c4474a4ded3c9a89be431bc8f12b0d0be1738b88091a263`
zugelassen. Sie wird nie als Pipelinequelle veröffentlicht und nie verändert.
Ein optionaler GitHub-Download muss aus einem ausdrücklich gewählten
vorhandenen Artefakt kommen und vor Übergabe an diesen Runner authentifiziert
werden. Eine andere alte Bootdatei ist kein stillschweigender Ersatz.

MagiskBoot-, AVB- und AnyKernel3-Pins sind im Runner festgelegt und stimmen
mit der bereits erfolgreich geprüften Verpackung überein. Der AK3-Checkout
muss sauber am Commit `af770f7b16cf8f8eb7c68614b2a693b3b361c90c` stehen.

Die neue Kernelgröße wird in Header v3 korrekt aktualisiert; der Ramdisk wird
an seine daraus folgende ausgerichtete Position verschoben und bytegetreu
erhalten. Weitere Headerwerte und die AVB-Politik bleiben erhalten. AOSP AVB,
ein unabhängig berechneter gesalzener Digest und MagiskBoot-Aus-/Einpacken
prüfen das Ergebnis. Der MagiskBoot-Roundtrip muss byteidentisch sein.

Solange dieser Boot-only-Pfad benutzt wird, muss `veux.dtb` weiterhin SHA256
`42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37`
tragen. Header v3 enthält hier keinen DTB. Ein geändertes DTB benötigt eine
gesonderte Vendor-Boot-/DTBO-Integration und wird daher nicht mitgeflasht.

Zusätzliche Ausgaben bei Erfolg:

- `boot.img`
- `VEUX_CASS_BUILD_INSTALL_R3.zip`
- `BOOT_PACKAGE_CHECK.json`, `INSTALLER_PACKAGE_CHECK.json`
- `anykernel.sh` mit zwei frisch berechneten Payloadhashes
- `boot_check/logs/` mit Werkzeugergebnissen

Das Statusfeld lautet erst nach allen Prüfungen:
`BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED`.
Es ist keine erfolgreiche Geräteboot-, Mobilfunk- oder Performanceprüfung.

Bei einem Fehler kann das neue Ausgabeverzeichnis Zwischenstände enthalten.
Die YAML darf diese nicht als fertiges Boot-/Installationsprodukt ausgeben.
Für Erfolgsartefakte den abschließenden Status und die zugehörigen Hashes
prüfen; bei Fehlern nur ausdrücklich gewählte Logs und Befunde sichern.
Die private Basis sowie extrahierte `ramdisk.cpio`-Zwischenverzeichnisse
gehören nicht in öffentliche Quellen oder pauschale Debug-Uploads.

## Offizielle Begleitdateien

Optional akzeptiert derselbe Aufruf:

```text
--manager-apk /path/BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk
--nomount-zip /path/NoMount-v2.2.0-release-bf1847f-605.zip
```

Nur die bekannten offiziellen Binärhashes werden kopiert; kein normaler
Manager und kein anderes NoMount-Paket werden still akzeptiert. Die Dateien
bleiben separate Begleiter. Der unveränderte R3-Installer erhält den bereits
geprüften Übergang von NoMount21 auf22 einschließlich Sicherung, Marker-
Rücknahme vor einem begonnenen Bootschreiben und Schutz bestehender Zustände.
Die CPUBW-/Gruppenmodule werden von dieser Komponente nicht umgebaut.

## Lokale Reproduktionsprüfung

`test_packaging.py` verwendet die bereits vorhandenen historischen Build-
Dateien im Arbeitsverzeichnis. Der Test dokumentiert diese Herkunft und
führt keinen neuen Kernelcompile aus. Das R5-Boot wird bytegenau reproduziert,
die sieben RMNET-Dateien und das ausgefüllte Installer-Skript stimmen mit
den früher geprüften R3-Dateien überein. Negativfälle prüfen die tatsächliche
ABI, Herkunftsanforderung und DTB-Grenze. Ein separat gekennzeichneter
synthetischer Größenfall prüft Header-/Ramdisk-Ausrichtung und AVB-Roundtrip.

Maßgebliches Ergebnis: `PACKAGING_TEST_RESULT.json`; nur dessen konkrete
Runner-SHA und die dazugehörigen Protokolle beschreiben den geprüften Stand.

Zusätzlich dokumentiert `LOCAL_NATIVE_PACKAGING_CHECK.json` die erfolgreiche
Verpackung des vorhandenen nativen Kernels mit den danach frisch kompilierten
externen RMNET-Modulen. Diese Prüfung verwendet ausdrücklich den Origin
`existing-native-kernel-plus-fresh-external-modules`: Der Kernel wurde für
diesen Test nicht neu kompiliert. Raw-Verpackung, 132 Modversions-Einträge,
Kernel-/Modulnotes, vollständiger Boot-/AVB-/MagiskBoot-Roundtrip und der
R3-Installer bestanden. `test_evidence/local_native/` enthält nur die
Datensätze und Werkzeugprotokolle; keine Boot- oder Ramdisk-Binärdateien.

Für die Auslieferung ist ausschließlich `COMPONENT_MANIFEST.json` maßgeblich.
Nicht gelistete lokale Prüfverzeichnisse gehören nicht in das Pipelinepaket.

Die abschließende Ergänzung der RMNET-Archivmetadaten ist separat in
`PACKAGING_METADATA_TEST_RESULT.json` geprüft. Diese gezielte Prüfung führt
den Raw-Pfad mit den echten lokalen Inputs aus und berechnet zusätzlich die
Archivmetadaten der bereits geprüften vollständigen Ausgabe. Die früheren
vollständigen Boot-Replays behalten ihren ursprünglichen Runner-Hash; sie
werden nicht als erneute vollständige Ausführung der Metadatenänderung
ausgewiesen.
