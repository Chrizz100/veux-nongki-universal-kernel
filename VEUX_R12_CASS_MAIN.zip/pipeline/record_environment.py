#!/usr/bin/env python3
"""Record selected public build provenance without dumping secrets or all env vars."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

EXPECTED = {
    'clang': 'b2ce016755bddbab76549895bca07b1dc8d14a3e315b8b3567097fef04eadae1',
    'ld.lld': '51dc9705420c136f583478ac08a3258cd970710296928b3bf24dc3ee2e6208e3',
    'llvm-ar': 'dfe6c18a46138a81220768cabe385fe09a851bab05d18914fc2cd15bbbde8d4a',
}


def record(stage, output):
    command = json.loads((stage / 'evidence/BUILD_COMMAND.json').read_text())
    path = os.pathsep.join(p for p in command['original_captured_env']['PATH'].split(os.pathsep)
                          if not p.rstrip('/').endswith('/source-temp/bin'))
    tools = {}
    for name, expected in EXPECTED.items():
        executable = shutil.which(name, path=path)
        if not executable:
            raise ValueError('TOOLCHAIN_EXECUTABLE_MISSING:' + name)
        resolved = Path(executable).resolve(strict=True)
        digest = hashlib.sha256(resolved.read_bytes()).hexdigest()
        if digest != expected:
            raise ValueError('TOOLCHAIN_EXECUTABLE_CHANGED:' + name)
        tools[name] = {'resolved_path': str(resolved), 'sha256': digest}
    selected = ('GITHUB_REPOSITORY', 'GITHUB_SHA', 'GITHUB_RUN_ID', 'GITHUB_RUN_ATTEMPT',
                'GITHUB_WORKFLOW_REF', 'RUNNER_OS', 'RUNNER_ARCH', 'ImageOS', 'ImageVersion')
    packages = subprocess.run(['dpkg-query', '-W', '-f=${Package}\t${Version}\n'],
                              text=True, check=True, stdout=subprocess.PIPE).stdout
    output.mkdir(parents=True, exist_ok=True)
    (output / 'INSTALLED_PACKAGES.tsv').write_text(packages)
    data = {'status': 'TOOLCHAIN_PINS_PASS', 'toolchain': tools,
            'runner': {k: os.environ[k] for k in selected if k in os.environ},
            'build_command_record_sha256': hashlib.sha256(
                (stage / 'evidence/BUILD_COMMAND.json').read_bytes()).hexdigest(),
            'apt_runner_packages_byte_pinned': False,
            'device_test': False}
    (output / 'BUILD_ENVIRONMENT.json').write_text(json.dumps(data, indent=2) + '\n')
    print('BUILD_ENVIRONMENT_RECORDED_AND_COMPILER_HASHES_PASS')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--stage', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    a = p.parse_args()
    record(a.stage, a.out)
