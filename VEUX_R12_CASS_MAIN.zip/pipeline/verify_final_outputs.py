#!/usr/bin/env python3
"""Gate product upload on terminal packaging status and rehashed actual bytes."""
import argparse
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(directory, mode):
    result = json.loads((directory / 'PACKAGE_RESULT.json').read_text())
    status = ('RAW_AND_RMNET_VALIDATED' if mode == 'raw'
              else 'BOOT_AND_INSTALLER_STATIC_PASS_DEVICE_UNTESTED')
    if result.get('status') != status or result.get('device_test') is not False:
        raise ValueError('PACKAGE_TERMINAL_STATUS_NOT_PASSED')
    receipt = json.loads((directory / 'BUILD_OUTPUTS.json').read_text())
    if receipt.get('origin') != 'same-build-invocation':
        raise ValueError('CI_REQUIRES_SAME_INVOCATION_OUTPUTS')
    checks = json.loads((directory / 'BUILD_PACKAGE_CHECK.json').read_text())
    if (checks.get('source_receipt_sha256') != sha(directory / 'BUILD_OUTPUTS.json')
            or checks.get('origin') != receipt['origin'] or result.get('origin') != receipt['origin']
            or receipt.get('provenance', {}).get('kernel_compile_reused') is True):
        raise ValueError('RECEIPT_PROVENANCE_CHANGED_AFTER_PACKAGING')
    archive = result.get('rmnet_archive', {})
    if archive.get('file') != 'VEUX_CASS_RMNET_BUILD_DATA.zip':
        raise ValueError('RMNET_ARCHIVE_RECORD_MISSING_OR_PATH_CHANGED')
    archive_path = directory / archive['file']
    if (archive_path.is_symlink() or not archive_path.is_file()
            or sha(archive_path) != archive.get('sha256')
            or archive_path.stat().st_size != archive.get('bytes')):
        raise ValueError('RMNET_ARCHIVE_CHANGED_AFTER_PACKAGING')
    if mode == 'boot':
        if sha(directory / 'boot.img') != result['boot_sha256']:
            raise ValueError('BOOT_OUTPUT_CHANGED')
        item = result['installer']
        if item['file'] != 'VEUX_CASS_BUILD_INSTALL_R3.zip':
            raise ValueError('UNEXPECTED_INSTALLER_PATH')
        if sha(directory / item['file']) != item['sha256']:
            raise ValueError('INSTALLER_OUTPUT_CHANGED')
    files = {}
    names = ['VEUX_CASS_RMNET_BUILD_DATA.zip', 'BUILD_OUTPUTS.json',
             'BUILD_PACKAGE_CHECK.json', 'PACKAGE_RESULT.json']
    if mode == 'boot':
        names += ['boot.img', 'VEUX_CASS_BUILD_INSTALL_R3.zip',
                  'BOOT_PACKAGE_CHECK.json', 'INSTALLER_PACKAGE_CHECK.json']
    for name in names:
        path = directory / name
        if not path.is_file() or path.is_symlink():
            raise ValueError('FINAL_OUTPUT_MISSING:' + name)
        files[name] = {'sha256': sha(path), 'bytes': path.stat().st_size}
    (directory / 'FINAL_OUTPUT_MANIFEST.json').write_text(json.dumps(
        {'status': status, 'device_test': False, 'files': files}, indent=2) + '\n')
    (directory / 'SHA256SUMS').write_text(''.join(
        item['sha256'] + '  ' + name + '\n' for name, item in files.items()))
    print(status)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--mode', choices=('raw', 'boot'), required=True)
    a = p.parse_args()
    verify(a.directory, a.mode)
