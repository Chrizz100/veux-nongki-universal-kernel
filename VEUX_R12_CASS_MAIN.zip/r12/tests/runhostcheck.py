#!/usr/bin/env python3
"""Small precompile regressions using genuine CI ABI files and real source.

No positive kernel fixture, boot image or device execution is synthesized.
Full Image/ELF acceptance remains mandatory after actual compilation.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import re
import shutil
import subprocess
import sys
import tempfile

sys.dont_write_bytecode = True
REFERENCE_SHA = '6b660c141f99cbe5d45c4e84bfb83498553a5b5e68e273c26afa17b1fdeaf0ec'
REORDERED_SHA = '0b5f909c68ec375533e961ac106da49c71b25f4fc99e6d13d0d093a52a540ec2'
CANONICAL_SHA = 'bc8c9db3aff0f0a6af92f0574792676fcc71ba260351bb57a9d42f1d79cdba12'
SHELLCHECK_SHA = '4da528ddb3a4d1b7b24a59d4e16eb2f5fd960f4bd9a3708a15baddbdf1d5a55b'
PRESERVED_FUNCTIONS = {
    'r5_fail', 'r5_rollback_marker', 'r5_cleanup_temp', 'r5_rollback_nomount',
    'r5_exit_cleanup', 'r5_sha', 'r5_nomount_is_verified_605',
    'r5_check_module_parents', 'r5_inspect_nomount', 'r5_create_disable', 'r5_check_ready_marker',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    require(path.is_file() and not path.is_symlink(), 'HOST_INPUT_NOT_REGULAR:' + str(path))
    return path.read_bytes()


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    require(spec is not None and spec.loader is not None, 'HOST_MODULE_SPEC_FAILED')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def command(argv, expect_failure=False):
    result = subprocess.run([str(x) for x in argv], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    require((result.returncode != 0) if expect_failure else (result.returncode == 0),
            'HOST_COMMAND_WRONG_RESULT:' + json.dumps([str(x) for x in argv]) + '\n' + result.stdout)
    return {'command': [str(x) for x in argv], 'exit': result.returncode, 'output': result.stdout,
            'expected_failure': expect_failure}


def functions(source):
    pairs = list(re.finditer(r'^([A-Za-z0-9_]+)\(\) \{\n.*?^\}', source, re.MULTILINE | re.DOTALL))
    names = [pair.group(1) for pair in pairs]
    require(len(names) == len(set(names)), 'DUPLICATE_SHELL_FUNCTION')
    return {pair.group(1): pair.group(0) for pair in pairs}


def check_abi(payload, cases):
    guard = load_module(payload / 'r12/veux_r11_ci_abi_hook.py', 'r12_host_abi_guard')
    reference_path = payload / 'r12/reference/baseline-reference.symvers'
    reordered_path = payload / 'r12/reference/baseline-reordered.symvers'
    reference, reordered = regular(reference_path), regular(reordered_path)
    require(digest(reference) == REFERENCE_SHA and digest(reordered) == REORDERED_SHA,
            'GENUINE_CI_ABI_FIXTURE_CHANGED')
    require(guard.REFERENCE_RAW_SHA256 == REFERENCE_SHA
            and guard.REFERENCE_CANONICAL_SHA256 == CANONICAL_SHA
            and guard.REFERENCE_RECORDS == 12947, 'ABI_REFERENCE_CONTRACT_CHANGED')
    rows = reference[:-1].split(b'\n')
    shuffled = rows.copy()
    random.Random(40704046049).shuffle(shuffled)
    for name, data in [('reference_ci', reference), ('reordered_ci', reordered),
                       ('reversed_records', b'\n'.join(reversed(rows)) + b'\n'),
                       ('random_record_permutation', b'\n'.join(shuffled) + b'\n')]:
        proof = guard.validate_symvers_bytes(data)
        require(proof['canonical_sha256'] == CANONICAL_SHA and proof['records'] == 12947
                and proof['unique_symbols'] == 12947, 'ABI_POSITIVE_CHECK_INCOMPLETE')
        cases.append({'name': name, 'kind': 'real ABI data or its row permutation', 'status': 'PASS'})
    negative = {}
    for name, field in [('crc', 0), ('symbol', 1), ('provider', 2), ('export', 3), ('namespace', 4)]:
        fields = rows[0].split(b'\t')
        if field == 0:
            fields[field] = f'0x{int(fields[field], 16) ^ 1:08x}'.encode()
        elif field == 3:
            fields[field] = b'EXPORT_SYMBOL_GPL' if fields[field] == b'EXPORT_SYMBOL' else b'EXPORT_SYMBOL'
        else:
            fields[field] = fields[field] + b'_CHANGED'
        negative['changed_' + name] = b'\n'.join([b'\t'.join(fields), *rows[1:]]) + b'\n'
    negative.update({
        'missing_record': b'\n'.join(rows[:-1]) + b'\n',
        'extra_record': reference + rows[0] + b'\n',
        'duplicate_symbol_same_count': b'\n'.join([rows[1], *rows[1:]]) + b'\n',
        'missing_final_lf': reference[:-1],
        'crlf': reference.replace(b'\n', b'\r\n'),
        'non_ascii': b'\xff' + reference[1:],
        'nul': b'\x00' + reference[1:],
        'wrong_tab_fields': reference.replace(b'\t', b' ', 1),
        'uppercase_crc': b'0xABCDEF12' + reference[10:],
        'extra_tab': reference.replace(b'\t', b'\t\t', 1),
    })
    for name, data in negative.items():
        try:
            guard.validate_symvers_bytes(data)
        except guard.AbiOrderBlocked as error:
            cases.append({'name': name, 'kind': 'negative ABI mutation', 'status': 'PASS', 'rejected': str(error)})
        else:
            raise ValueError('ABI_MUTATION_ACCEPTED:' + name)
    require(regular(reference_path) == reference and regular(reordered_path) == reordered,
            'HOST_TEST_CHANGED_ORIGINAL_ABI_FILES')
    return {'genuine_reference_run': 40704046049, 'genuine_reordered_run': 40805535950,
            'canonical_full_record_sha256': CANONICAL_SHA, 'records': 12947,
            'reference_files_unchanged': True}


def check_shell_contract(payload, cases):
    old = regular(payload / 'r11/packaging/assets/anykernel_builtin.sh.in').decode()
    template_path = payload / 'r12/assets/anykernel.sh.in'
    new = regular(template_path).decode()
    old_functions, new_functions = functions(old), functions(new)
    require(PRESERVED_FUNCTIONS == set(old_functions), 'ORIGINAL_TRANSITION_FUNCTION_SET_CHANGED')
    pins = {}
    for name in sorted(PRESERVED_FUNCTIONS):
        require(new_functions.get(name) == old_functions[name], 'PRESERVED_NOMOUNT_FUNCTION_CHANGED:' + name)
        pins[name] = digest(old_functions[name].encode())
    cases.append({'name': 'eleven_original_transition_and_rollback_functions_preserved', 'status': 'PASS'})
    require('device.name1=veux\n' in new and 'supported.versions=13\n' in new
            and 'SLOT_SELECT=active\n' in new and 'PATCH_VBMETA_FLAG=0\n' in new,
            'DEVICE_SLOT_OR_BOOT_POLICY_CHANGED')
    require('payload/boot.img' not in new and '@BOOT_SHA256@' not in new
            and 'VEUX_BOOT_TEMPLATE_URL' not in new, 'PRIVATE_PREBUILT_BOOT_DEPENDENCY_REMAINS')
    for token in ('@IMAGE_SHA256@', '@REPACK_SHA256@', '@MAGISKBOOT_SHA256@'):
        require(new.count(token) == 1, 'MISSING_OR_DUPLICATE_DYNAMIC_PACKAGE_PIN:' + token)
    sequence = [
        'dd if="$BLOCK" of="$BACKUP_FILE" bs=1048576 count=128 iflag=fullblock conv=fsync',
        '[ "$BACKUP_SHA" = "$CURRENT_SHA" ]',
        'sh "$REPACK_HELPER" --original "$BACKUP_FILE" --kernel "$KERNEL_PAYLOAD"',
        'EXPECTED_BOOT_SHA256=$(r5_sha "$PAYLOAD")',
        '[ "$NM_LIVE_NEEDS_DISABLE" = 0 ] || r5_create_disable',
        'WRITE_STARTED=1\n',
        'dd if="$PAYLOAD" of="$BLOCK" bs=1048576 count=128 iflag=fullblock conv=notrunc,fsync',
        'READBACK_LINE=$(dd if="$BLOCK" bs=1048576 count=128 iflag=fullblock,direct',
        '[ "$READBACK_SHA" = "$EXPECTED_BOOT_SHA256" ]',
    ]
    positions = []
    for token in sequence:
        require(new.count(token) == 1, 'BACKUP_REPACK_TRANSITION_WRITE_SEQUENCE_CHANGED:' + token)
        positions.append(new.index(token))
    require(positions == sorted(positions), 'DEVICE_WRITE_BEFORE_BACKUP_OR_REPACK_CHECK')
    cases.append({'name': 'backup_repack_nomount_write_direct_readback_order', 'status': 'PASS'})
    shellcheck = Path(shutil.which('shellcheck') or '').resolve(strict=True)
    require(shellcheck.is_file() and digest(regular(shellcheck)) == SHELLCHECK_SHA, 'PINNED_SHELLCHECK_NOT_ACTIVE')
    commands = []
    for file in (template_path, payload / 'r12/assets/r12_boot_repack.sh'):
        regular(file)
        commands.append(command(['sh', '-n', file]))
        commands.append(command([shellcheck, '--shell=ash', '--severity=warning', file]))
    cases.append({'name': 'own_device_shell_syntax_and_shellcheck', 'status': 'PASS'})
    return {'preserved_function_sha256': pins, 'commands': commands,
            'device_script_not_executed': True, 'new_boot_repack_correctness': 'SEPARATE_REAL_FILE_FIXTURE_TEST'}


def check_bridge_and_diagnostics(payload, cases, temporary):
    before = regular(payload / 'r11/veux_r11_bridge.py').decode()
    after = regular(payload / 'r12/veux_r11_bridge.py').decode()
    original_import = 'from veux_r11_build_hook import'
    fixed_import = 'from veux_r11_ci_abi_hook import'
    require(before.count(original_import) == 1
            and after == before.replace(original_import, fixed_import, 1),
            'CHILD_WORKER_BRIDGE_CHANGED_OUTSIDE_ABI_WRAPPER_IMPORT')
    ast.parse(after)
    cases.append({'name': 'exact_child_worker_bridge_import', 'status': 'PASS'})
    template = regular(payload / 'r12/device_diagnostics.sh.in').decode()
    require(template.count('@KERNEL_NOTES_SHA256@') == 1
            and 'VEUX_R12_READ_ONLY_DIAGNOSIS_V2' in template
            and 'stream_log() {' in template
            and 'READ_EXIT_STATUS=' in template, 'R2_STREAMING_DIAGNOSIS_CONTRACT_CHANGED')
    notes = '0123456789abcdef' * 4
    check = temporary / 'diagnostic-fixture.json'
    check.write_text(json.dumps({'kernel_notes_sha256': notes}))
    diagnostic = temporary / 'diagnostic-fixture.sh'
    writer = payload / 'r12/write_device_diagnostics.py'
    commands = [command([sys.executable, '-B', writer, '--checks', check, '--out', diagnostic])]
    generated = diagnostic.read_text()
    require(generated == template.replace('@KERNEL_NOTES_SHA256@', notes)
            and generated.count(notes) == 1, 'DIAGNOSTIC_NOT_BOUND_TO_SUPPLIED_VALIDATED_NOTES')
    commands.append(command(['sh', '-n', diagnostic]))
    commands.append(command(['shellcheck', '--shell=sh', '--severity=warning', diagnostic]))
    check.write_text(json.dumps({'kernel_notes_sha256': 'invalid'}))
    rejected_output = temporary / 'diagnostic-rejected.sh'
    rejection = command([sys.executable, '-B', writer, '--checks', check, '--out', rejected_output], True)
    require(not rejected_output.exists(), 'INVALID_DIAGNOSTIC_IDENTITY_CREATED_OUTPUT')
    commands.append(rejection)
    cases.append({'name': 'R2_diagnostic_hash_binding_and_invalid_hash_rejection', 'status': 'PASS',
                  'notes_are_explicit_unit_fixture_not_kernel_build': True})
    return {'commands': commands, 'device_diagnosis_executed': False}


def check_packaging_rejection(payload, cases, temporary):
    packager = payload / 'r12/package_anykernel.py'
    source = regular(packager).decode()
    tree = ast.parse(source)
    imports = [node for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)
               and node.module == 'builtin_validation']
    require(any(any(alias.name == 'validate_inputs' for alias in node.names) for node in imports),
            'PACKAGER_ORIGINAL_KERNEL_VALIDATOR_NOT_IMPORTED')
    calls = [node for node in ast.walk(tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Name) and node.func.id == 'validate_inputs']
    require(bool(calls), 'PACKAGER_ORIGINAL_KERNEL_VALIDATOR_NOT_CALLED')
    inputs = temporary / 'invalid-inputs'
    inputs.mkdir()
    receipt = inputs / 'BUILD_OUTPUTS.json'
    # An explicit negative receipt exercises the real provenance gate. It is
    # never represented as a completed compile or accepted positive kernel.
    receipt.write_text(json.dumps({'provenance': {'evidence_mode': 'local-native'}}))
    out = temporary / 'rejected-package'
    rejection = command([sys.executable, '-B', packager, '--inputs', inputs, '--receipt', receipt,
                         '--out', out, '--payload', payload, '--evidence-mode', 'ci'], True)
    require('CI/local provenance cannot be relabeled' in rejection['output'],
            'PACKAGER_FAILED_FOR_UNEXPECTED_REASON')
    require(not out.exists(), 'REJECTED_PROVENANCE_CREATED_PACKAGE_OUTPUT')
    cases.append({'name': 'real_packager_rejects_local_receipt_labeled_as_CI', 'status': 'PASS'})
    return {'commands': [rejection], 'positive_full_kernel_fixture_fabricated': False}


def run(payload, output):
    payload = payload.resolve(strict=True)
    output = output.resolve()
    require(not output.is_relative_to(payload), 'HOST_REPORT_MUST_NOT_MODIFY_PAYLOAD')
    output.parent.mkdir(parents=True, exist_ok=True)
    cases = []
    report = {'schema': 'veux-r12-precompile-host-regression-v1', 'status': 'BLOCKED',
              'kernel_compile_performed': False, 'positive_full_kernel_fixture_fabricated': False,
              'private_boot_fixture_required': False, 'device_execution': False, 'cases': cases}
    try:
        report['abi'] = check_abi(payload, cases)
        report['shell_contract'] = check_shell_contract(payload, cases)
        with tempfile.TemporaryDirectory(prefix='r12-hostcheck-') as directory:
            temporary = Path(directory)
            report['diagnostic'] = check_bridge_and_diagnostics(payload, cases, temporary)
            report['packager_rejection'] = check_packaging_rejection(payload, cases, temporary)
        parsed = []
        for path in sorted((payload / 'r12').rglob('*.py')):
            ast.parse(path.read_text(), filename=str(path))
            parsed.append(path.relative_to(payload).as_posix())
        report['new_python_ast_checked'] = parsed
        cases.append({'name': 'all_new_python_sources_parse', 'status': 'PASS'})
        report.update(status='HOST_REGRESSION_PASS', cases_passed=len(cases),
                      full_kernel_and_package_acceptance='MANDATORY_AFTER_REAL_COMPILER_COMPLETION')
    except Exception as error:
        report['failure'] = type(error).__name__ + ': ' + str(error)
        output.write_text(json.dumps(report, indent=2) + '\n')
        raise
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'cases_passed': len(cases),
                      'kernel_compile_performed': False, 'device_execution': False}, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--payload', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    run(args.payload, args.out)
