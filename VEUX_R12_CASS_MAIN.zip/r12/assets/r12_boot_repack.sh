#!/sbin/sh
# File-only VEUX boot-v3 repack. No block-device, mount, module or property writes.
# MagiskBoot preserves the original vbmeta blob. For the supported AVB NONE /
# sha256 profile below, update its real image-size and digest, then verify again.
# AVB offsets follow the pinned AOSP avbtool de53827b226bccef7407e4c253b0152e8d9f8e04.
# shellcheck shell=ash
set -eu
set -o pipefail

fail() { printf 'R12_REPACK_ABORT: %s\n' "$*" >&2; exit 1; }
ORIGINAL='' KERNEL='' OUTPUT='' MAGISKBOOT='' WORK=''
while [ "$#" -gt 0 ]; do
  [ "$#" -ge 2 ] || fail 'Missing option value'
  case "$1" in
    --original) [ -z "$ORIGINAL" ] || fail 'Duplicate original option'; ORIGINAL=$2 ;;
    --kernel) [ -z "$KERNEL" ] || fail 'Duplicate kernel option'; KERNEL=$2 ;;
    --output) [ -z "$OUTPUT" ] || fail 'Duplicate output option'; OUTPUT=$2 ;;
    --magiskboot) [ -z "$MAGISKBOOT" ] || fail 'Duplicate magiskboot option'; MAGISKBOOT=$2 ;;
    --work) [ -z "$WORK" ] || fail 'Duplicate work option'; WORK=$2 ;;
    *) fail 'Unknown option' ;;
  esac
  shift 2
done
for value in "$ORIGINAL" "$KERNEL" "$OUTPUT" "$MAGISKBOOT" "$WORK"; do
  case "$value" in /*) ;; *) fail 'All five paths must be absolute' ;; esac
  case "$value" in *'
'*|*'/../'*|*'/./'*|*/..|*/.) fail 'Noncanonical path' ;; esac
done
for file in "$ORIGINAL" "$KERNEL" "$MAGISKBOOT"; do
  [ -f "$file" ] && [ ! -L "$file" ] || fail 'Input is not a regular unlinked file'
done
[ -x "$MAGISKBOOT" ] || fail 'MagiskBoot is not executable'
[ ! -e "$WORK" ] && [ ! -L "$WORK" ] || fail 'Work directory already exists'
[ ! -e "$OUTPUT" ] && [ ! -L "$OUTPUT" ] || fail 'Output already exists'
for tool in dd od tr sha256sum wc cmp cp mkdir ln cat printf; do
  command -v "$tool" >/dev/null 2>&1 || fail "Missing tool: $tool"
done
BOOT_BYTES=134217728
PAGE=4096
FOOTER_OFFSET=$((BOOT_BYTES - 64))

size_of() { wc -c < "$1" | tr -d '[:space:]'; }
hash_file() {
  local line result
  line=$(sha256sum "$1") || return 1
  result=${line%% *}
  [ "${#result}" = 64 ] || return 1
  case "$result" in *[!0-9a-f]*) return 1 ;; esac
  printf '%s\n' "$result"
}

# Large reads always use pages. Byte-sized reads cover only small header,
# descriptor or last-page fragments, never a whole kernel/ramdisk/partition.
range_stream() {
  local file offset length pages tail
  file=$1; offset=$2; length=$3
  [ "$offset" -ge 0 ] && [ "$length" -ge 0 ] && [ "$((offset + length))" -le "$BOOT_BYTES" ] || return 1
  if [ "$((offset % PAGE))" = 0 ] && [ "$length" -ge "$PAGE" ]; then
    pages=$((length / PAGE)); tail=$((length % PAGE))
    dd if="$file" bs=4096 skip="$((offset / PAGE))" count="$pages" 2>/dev/null || return 1
    if [ "$tail" -gt 0 ]; then
      dd if="$file" bs=1 skip="$((offset + pages * PAGE))" count="$tail" 2>/dev/null || return 1
    fi
  else
    [ "$length" -le 65536 ] || return 1
    dd if="$file" bs=1 skip="$offset" count="$length" 2>/dev/null || return 1
  fi
}
hex_at() {
  local result
  result=$(range_stream "$1" "$2" "$3" | od -An -v -tx1 | tr -d '[:space:]') || return 1
  [ "${#result}" -eq "$(( $3 * 2 ))" ] || return 1
  printf '%s\n' "$result"
}
u32be() {
  local hex
  hex=$(hex_at "$1" "$2" 4) || return 1
  printf '%u\n' "$((0x$hex))"
}
u64be_bounded() {
  local high
  high=$(hex_at "$1" "$2" 4) || return 1
  [ "$high" = 00000000 ] || return 1
  u32be "$1" "$(( $2 + 4 ))"
}
u32le() {
  local octets
  octets=$(range_stream "$1" "$2" 4 | od -An -v -tu1) || return 1
  # Only decimal bytes emitted by od enter these positional parameters.
  # shellcheck disable=SC2086
  set -- $octets
  [ "$#" = 4 ] || return 1
  printf '%u\n' "$(( $1 + ($2 << 8) + ($3 << 16) + ($4 << 24) ))"
}
write_hex_file() {
  local text rest pair octal destination
  text=$1; destination=$2
  case "$text" in ''|*[!0-9a-f]*) return 1 ;; esac
  [ "$(( ${#text} % 2 ))" = 0 ] || return 1
  : > "$destination"
  while [ -n "$text" ]; do
    rest=${text#??}; pair=${text%"$rest"}
    octal=$(printf '%03o' "$((0x$pair))") || return 1
    printf '%b' "\\$octal" >> "$destination" || return 1
    text=$rest
  done
}
zero_field() {
  local value
  value=$(hex_at "$1" "$2" "$3") || return 1
  case "$value" in *[!0]*) return 1 ;; esac
}
range_to_file() {
  range_stream "$1" "$2" "$3" > "$4" || return 1
  [ "$(size_of "$4")" -eq "$3" ] || return 1
}
range_hash() {
  local line
  line=$(range_stream "$1" "$2" "$3" | sha256sum) || return 1
  printf '%s\n' "${line%% *}"
}

parse_boot() {
  local file
  file=$1
  [ "$(size_of "$file")" = "$BOOT_BYTES" ] || fail 'Boot must be exactly 128 MiB'
  [ "$(hex_at "$file" 0 8)" = 414e44524f494421 ] || fail 'Android boot magic mismatch'
  [ "$(u32le "$file" 40)" = 3 ] && [ "$(u32le "$file" 20)" = 1580 ] || fail 'Only the VEUX boot-v3/1580 profile is supported'
  B_KERNEL=$(u32le "$file" 8) || fail 'Cannot read kernel length'
  B_RAMDISK=$(u32le "$file" 12) || fail 'Cannot read ramdisk length'
  [ "$B_KERNEL" -gt 64 ] && [ "$B_RAMDISK" -gt 0 ] || fail 'Invalid boot payload sizes'
  [ "$B_KERNEL" -lt "$BOOT_BYTES" ] && [ "$B_RAMDISK" -lt "$BOOT_BYTES" ] || fail 'Unbounded boot payload sizes'
  B_RAMDISK_OFFSET=$((PAGE + (B_KERNEL + PAGE - 1) / PAGE * PAGE))
  B_END=$((B_RAMDISK_OFFSET + (B_RAMDISK + PAGE - 1) / PAGE * PAGE))
  [ "$B_END" -lt "$((BOOT_BYTES - 65536))" ] || fail 'Boot payload exceeds supported capacity'
  [ "$(hex_at "$file" "$((PAGE + 56))" 4)" = 41524d64 ] || fail 'Original/repacked kernel is not raw ARM64 Image'
}

# Globals A_* describe a bounded, unsigned AVB blob containing exactly one
# sha256 boot-hash descriptor plus property descriptors. No keys, signatures,
# chain/hashtree descriptors, vbmeta flags or rollback changes are supported.
parse_avb() {
  local file field aux desc_offset desc_size pos end tag following total keys values expected flags hashes saltlen pad
  file=$1
  [ "$(hex_at "$file" "$FOOTER_OFFSET" 4)" = 41564266 ] || fail 'Missing AVB footer'
  [ "$(u32be "$file" "$((FOOTER_OFFSET + 4))")" = 1 ] && [ "$(u32be "$file" "$((FOOTER_OFFSET + 8))")" = 0 ] || fail 'Unsupported AVB footer version'
  A_ORIGINAL_SIZE=$(u64be_bounded "$file" "$((FOOTER_OFFSET + 12))") || fail 'Unbounded footer image size'
  A_META_OFFSET=$(u64be_bounded "$file" "$((FOOTER_OFFSET + 20))") || fail 'Unbounded vbmeta offset'
  A_META_SIZE=$(u64be_bounded "$file" "$((FOOTER_OFFSET + 28))") || fail 'Unbounded vbmeta size'
  zero_field "$file" "$((FOOTER_OFFSET + 36))" 28 || fail 'Nonzero reserved AVB footer bytes'
  [ "$A_ORIGINAL_SIZE" = "$B_END" ] && [ "$A_META_OFFSET" = "$B_END" ] || fail 'AVB footer does not describe the current page-aligned boot payload'
  [ "$A_META_SIZE" -ge 256 ] && [ "$A_META_SIZE" -le 65536 ] && [ "$((A_META_OFFSET + A_META_SIZE))" -lt "$FOOTER_OFFSET" ] || fail 'Invalid vbmeta bounds'
  [ "$(hex_at "$file" "$A_META_OFFSET" 4)" = 41564230 ] || fail 'Missing vbmeta header'
  [ "$(u32be "$file" "$((A_META_OFFSET + 4))")" = 1 ] && [ "$(u32be "$file" "$((A_META_OFFSET + 8))")" = 0 ] || fail 'Unsupported required AVB version'
  [ "$(u64be_bounded "$file" "$((A_META_OFFSET + 12))")" = 0 ] || fail 'Signed AVB images are outside this profile'
  [ "$(u32be "$file" "$((A_META_OFFSET + 28))")" = 0 ] || fail 'AVB algorithm must be NONE'
  for field in 32 40 48 56 72 88 112; do
    [ "$(u64be_bounded "$file" "$((A_META_OFFSET + field))")" = 0 ] || fail 'Unexpected AVB authentication, key, or rollback data'
  done
  [ "$(u32be "$file" "$((A_META_OFFSET + 120))")" = 0 ] && [ "$(u32be "$file" "$((A_META_OFFSET + 124))")" = 0 ] || fail 'Unsupported AVB flags or rollback location'
  zero_field "$file" "$((A_META_OFFSET + 176))" 80 || fail 'Nonzero reserved vbmeta header bytes'
  aux=$(u64be_bounded "$file" "$((A_META_OFFSET + 20))") || fail 'Unbounded auxiliary size'
  [ "$aux" -gt 0 ] && [ "$((aux % 64))" = 0 ] && [ "$A_META_SIZE" = "$((256 + aux))" ] || fail 'Invalid auxiliary block bounds'
  for field in 64 80; do
    expected=$(u64be_bounded "$file" "$((A_META_OFFSET + field))") || fail 'Unbounded empty key offset'
    [ "$expected" -le "$aux" ] || fail 'Empty key offset outside auxiliary block'
  done
  desc_offset=$(u64be_bounded "$file" "$((A_META_OFFSET + 96))") || fail 'Unbounded descriptor offset'
  desc_size=$(u64be_bounded "$file" "$((A_META_OFFSET + 104))") || fail 'Unbounded descriptor length'
  [ "$desc_offset" = 0 ] && [ "$desc_size" -gt 0 ] && [ "$((desc_size % 8))" = 0 ] && [ "$desc_size" -le "$aux" ] || fail 'Unsupported descriptor layout'
  zero_field "$file" "$((A_META_OFFSET + 256 + desc_size))" "$((aux - desc_size))" || fail 'Unexpected auxiliary data after descriptors'
  pos=$((A_META_OFFSET + 256)); end=$((pos + desc_size)); hashes=0; A_PROPERTIES=0
  while [ "$pos" -lt "$end" ]; do
    [ "$((end - pos))" -ge 16 ] || fail 'Truncated descriptor header'
    tag=$(u64be_bounded "$file" "$pos") || fail 'Unbounded descriptor type'
    following=$(u64be_bounded "$file" "$((pos + 8))") || fail 'Unbounded descriptor length'
    total=$((16 + following))
    [ "$((total % 8))" = 0 ] && [ "$total" -ge 32 ] && [ "$total" -le "$((end - pos))" ] || fail 'Invalid descriptor bounds'
    case "$tag" in
      2)
        hashes=$((hashes + 1)); [ "$hashes" = 1 ] || fail 'Duplicate hash descriptor'
        [ "$total" -ge 168 ] || fail 'Short hash descriptor'
        A_HASH_OFFSET=$pos
        A_HASH_SIZE=$(u64be_bounded "$file" "$((pos + 16))") || fail 'Unbounded hash image size'
        [ "$(hex_at "$file" "$((pos + 24))" 32)" = 7368613235360000000000000000000000000000000000000000000000000000 ] || fail 'Hash algorithm is not sha256'
        [ "$(u32be "$file" "$((pos + 56))")" = 4 ] || fail 'Hash partition name length differs'
        saltlen=$(u32be "$file" "$((pos + 60))") || fail 'Cannot read salt length'
        [ "$saltlen" -gt 0 ] && [ "$saltlen" -le 64 ] || fail 'Unsupported AVB salt length'
        [ "$(u32be "$file" "$((pos + 64))")" = 32 ] || fail 'Unsupported digest length'
        flags=$(u32be "$file" "$((pos + 68))") || fail 'Cannot read hash flags'
        [ "$flags" = 0 ] || fail 'Hash descriptor flags differ'
        zero_field "$file" "$((pos + 72))" 60 || fail 'Nonzero hash reserved bytes'
        [ "$(hex_at "$file" "$((pos + 132))" 4)" = 626f6f74 ] || fail 'Hash descriptor is not for boot'
        expected=$(((132 + 4 + saltlen + 32 + 7) / 8 * 8))
        [ "$total" = "$expected" ] || fail 'Hash descriptor size mismatch'
        A_SALT_OFFSET=$((pos + 136)); A_SALT_SIZE=$saltlen
        A_DIGEST_OFFSET=$((A_SALT_OFFSET + saltlen))
        A_DIGEST=$(hex_at "$file" "$A_DIGEST_OFFSET" 32) || fail 'Cannot read hash digest'
        pad=$((total - 136 - saltlen - 32))
        zero_field "$file" "$((A_DIGEST_OFFSET + 32))" "$pad" || fail 'Nonzero hash padding'
        ;;
      0)
        keys=$(u64be_bounded "$file" "$((pos + 16))") || fail 'Unbounded property key length'
        values=$(u64be_bounded "$file" "$((pos + 24))") || fail 'Unbounded property value length'
        [ "$keys" -gt 0 ] && [ "$keys" -le "$total" ] && [ "$values" -le "$total" ] || fail 'Invalid property lengths'
        expected=$(((32 + keys + 1 + values + 1 + 7) / 8 * 8))
        [ "$total" = "$expected" ] || fail 'Property descriptor length mismatch'
        zero_field "$file" "$((pos + 32 + keys))" 1 || fail 'Property key terminator missing'
        zero_field "$file" "$((pos + 33 + keys + values))" "$((total - 33 - keys - values))" || fail 'Property terminator/padding invalid'
        A_PROPERTIES=$((A_PROPERTIES + 1))
        ;;
      *) fail 'Unsupported AVB descriptor type' ;;
    esac
    pos=$((pos + total))
  done
  [ "$pos" = "$end" ] && [ "$hashes" = 1 ] || fail 'Missing or truncated boot hash descriptor'
}

salted_digest() {
  local line
  line=$({
    range_stream "$1" "$A_SALT_OFFSET" "$A_SALT_SIZE" || exit 1
    range_stream "$1" 0 "$B_END" || exit 1
  } | sha256sum) || return 1
  printf '%s\n' "${line%% *}"
}

MAGISK_SHA=$(hash_file "$MAGISKBOOT") || fail 'Cannot identify MagiskBoot'
case "$MAGISK_SHA" in
  a18ecbd7981179494b7d281453d6c4e25b5c719e7d2ef7f6eba3c6be3043c58e|d7440e2cd89899426e809554bf793baef9804ccbe5a52ce34a8b6242725d3c77) ;;
  *) fail 'MagiskBoot is not the pinned official v30.7 host/ARM64 binary' ;;
esac
ORIGINAL_SHA=$(hash_file "$ORIGINAL") || fail 'Cannot hash original'
KERNEL_SHA=$(hash_file "$KERNEL") || fail 'Cannot hash kernel'
KERNEL_SIZE=$(size_of "$KERNEL") || fail 'Cannot size kernel'
[ "$KERNEL_SIZE" -gt 64 ] && [ "$KERNEL_SIZE" -lt "$((BOOT_BYTES - 65536))" ] || fail 'Invalid kernel size'
[ "$(hex_at "$KERNEL" 56 4)" = 41524d64 ] || fail 'Replacement is not raw ARM64 Image'
parse_boot "$ORIGINAL"
OLD_KERNEL_SIZE=$B_KERNEL; OLD_RAMDISK_SIZE=$B_RAMDISK; OLD_RAMDISK_OFFSET=$B_RAMDISK_OFFSET; OLD_END=$B_END
parse_avb "$ORIGINAL"
[ "$A_HASH_SIZE" = "$B_END" ] || fail 'Original AVB hash range differs from payload'
[ "$(salted_digest "$ORIGINAL")" = "$A_DIGEST" ] || fail 'Original AVB salted hash is invalid'
OLD_META_OFFSET=$A_META_OFFSET; OLD_META_SIZE=$A_META_SIZE; OLD_HASH_REL=$((A_HASH_OFFSET - A_META_OFFSET)); OLD_DIGEST_REL=$((A_DIGEST_OFFSET - A_META_OFFSET))
OLD_PROPERTIES=$A_PROPERTIES
OLD_RAMDISK_SHA=$(range_hash "$ORIGINAL" "$OLD_RAMDISK_OFFSET" "$OLD_RAMDISK_SIZE") || fail 'Cannot hash original raw ramdisk'
mkdir -m 700 "$WORK" || fail 'Cannot create new work directory'
mkdir -m 700 "$WORK/raw" "$WORK/candidate" || fail 'Cannot create work subdirectories'
range_to_file "$ORIGINAL" "$OLD_META_OFFSET" "$OLD_META_SIZE" "$WORK/original.vbmeta" || fail 'Cannot capture original vbmeta'
range_to_file "$ORIGINAL" 0 4096 "$WORK/original.header" || fail 'Cannot capture original header'
range_to_file "$ORIGINAL" "$FOOTER_OFFSET" 64 "$WORK/original.footer" || fail 'Cannot capture original footer'
(
  cd "$WORK/raw"
  "$MAGISKBOOT" unpack -n -h "$ORIGINAL"
) > "$WORK/unpack-original.log" 2>&1 || fail 'Raw original boot unpack failed'
[ "$(hash_file "$WORK/raw/ramdisk.cpio")" = "$OLD_RAMDISK_SHA" ] || fail 'MagiskBoot raw ramdisk differs'
[ "$(size_of "$WORK/raw/kernel")" = "$OLD_KERNEL_SIZE" ] || fail 'Unexpected original kernel extraction size'
cp "$KERNEL" "$WORK/raw/kernel" || fail 'Cannot stage replacement kernel'
(
  cd "$WORK/raw"
  PATCHVBMETAFLAG=false "$MAGISKBOOT" repack -n "$ORIGINAL" "$WORK/candidate/boot.img"
) > "$WORK/repack.log" 2>&1 || fail 'Boot repack failed'
CANDIDATE="$WORK/candidate/boot.img"
parse_boot "$CANDIDATE"
[ "$B_KERNEL" = "$KERNEL_SIZE" ] && [ "$B_RAMDISK" = "$OLD_RAMDISK_SIZE" ] || fail 'Repacked payload lengths differ'
[ "$(range_hash "$CANDIDATE" 4096 "$B_KERNEL")" = "$KERNEL_SHA" ] || fail 'Repacked kernel differs'
[ "$(range_hash "$CANDIDATE" "$B_RAMDISK_OFFSET" "$B_RAMDISK")" = "$OLD_RAMDISK_SHA" ] || fail 'Raw ramdisk changed'
NEW_END=$B_END
range_to_file "$CANDIDATE" 0 4096 "$WORK/normalized.header" || fail 'Cannot capture repacked header'
dd if="$WORK/original.header" of="$WORK/normalized.header" bs=1 skip=8 seek=8 count=4 conv=notrunc 2>/dev/null || fail 'Cannot normalize allowed kernel-size field'
cmp -s "$WORK/original.header" "$WORK/normalized.header" || fail 'Boot header changed outside kernel length'
parse_avb "$CANDIDATE"
[ "$A_META_SIZE" = "$OLD_META_SIZE" ] && [ "$((A_HASH_OFFSET - A_META_OFFSET))" = "$OLD_HASH_REL" ] && [ "$((A_DIGEST_OFFSET - A_META_OFFSET))" = "$OLD_DIGEST_REL" ] || fail 'Repack changed descriptor positions'
[ "$A_HASH_SIZE" = "$OLD_END" ] && [ "$A_PROPERTIES" = "$OLD_PROPERTIES" ] || fail 'Repack unexpectedly changed the original AVB descriptor'
range_to_file "$CANDIDATE" "$A_META_OFFSET" "$A_META_SIZE" "$WORK/staged.vbmeta" || fail 'Cannot capture staged vbmeta'
cmp -s "$WORK/original.vbmeta" "$WORK/staged.vbmeta" || fail 'MagiskBoot changed AVB metadata'
range_to_file "$CANDIDATE" "$FOOTER_OFFSET" 64 "$WORK/normalized.footer" || fail 'Cannot capture repacked footer'
dd if="$WORK/original.footer" of="$WORK/normalized.footer" bs=1 skip=12 seek=12 count=16 conv=notrunc 2>/dev/null || fail 'Cannot normalize allowed footer sizes'
cmp -s "$WORK/original.footer" "$WORK/normalized.footer" || fail 'AVB footer changed outside original size and vbmeta offset'

# Exactly two bounded fields are changed in the original unsigned vbmeta:
# the boot-hash image_size and sha256(salt || actual boot payload).
NEW_DIGEST=$(salted_digest "$CANDIDATE") || fail 'Cannot hash new boot payload with its original salt'
write_hex_file "$(printf '%016x' "$NEW_END")" "$WORK/new-size.bin" || fail 'Cannot encode the real payload size'
write_hex_file "$NEW_DIGEST" "$WORK/new-digest.bin" || fail 'Cannot encode the real payload digest'
[ "$(size_of "$WORK/new-size.bin")" = 8 ] && [ "$(size_of "$WORK/new-digest.bin")" = 32 ] || fail 'Encoded AVB fields have wrong lengths'
dd if="$WORK/new-size.bin" of="$CANDIDATE" bs=1 seek="$((A_HASH_OFFSET + 16))" count=8 conv=notrunc 2>/dev/null || fail 'AVB image-size update failed'
dd if="$WORK/new-digest.bin" of="$CANDIDATE" bs=1 seek="$A_DIGEST_OFFSET" count=32 conv=notrunc 2>/dev/null || fail 'AVB hash update failed'

# Reparse actual output bytes and recompute independently of the saved digest.
parse_boot "$CANDIDATE"
parse_avb "$CANDIDATE"
[ "$A_HASH_SIZE" = "$B_END" ] && [ "$B_END" = "$NEW_END" ] || fail 'Final AVB range mismatch'
[ "$(salted_digest "$CANDIDATE")" = "$A_DIGEST" ] && [ "$A_DIGEST" = "$NEW_DIGEST" ] || fail 'Final independent AVB hash mismatch'
[ "$(range_hash "$CANDIDATE" 4096 "$B_KERNEL")" = "$KERNEL_SHA" ] || fail 'Final kernel bytes changed'
[ "$(range_hash "$CANDIDATE" "$B_RAMDISK_OFFSET" "$B_RAMDISK")" = "$OLD_RAMDISK_SHA" ] || fail 'Final ramdisk bytes changed'
range_to_file "$CANDIDATE" "$A_META_OFFSET" "$A_META_SIZE" "$WORK/normalized.vbmeta" || fail 'Cannot capture final vbmeta'
dd if="$WORK/original.vbmeta" of="$WORK/normalized.vbmeta" bs=1 skip="$((OLD_HASH_REL + 16))" seek="$((OLD_HASH_REL + 16))" count=8 conv=notrunc 2>/dev/null || fail 'Cannot normalize AVB size field'
dd if="$WORK/original.vbmeta" of="$WORK/normalized.vbmeta" bs=1 skip="$OLD_DIGEST_REL" seek="$OLD_DIGEST_REL" count=32 conv=notrunc 2>/dev/null || fail 'Cannot normalize AVB digest field'
cmp -s "$WORK/original.vbmeta" "$WORK/normalized.vbmeta" || fail 'AVB metadata changed outside real size/digest fields'
[ "$(hash_file "$ORIGINAL")" = "$ORIGINAL_SHA" ] && [ "$(hash_file "$KERNEL")" = "$KERNEL_SHA" ] && [ "$(hash_file "$MAGISKBOOT")" = "$MAGISK_SHA" ] || fail 'Original input or tool changed'
OUTPUT_SHA=$(hash_file "$CANDIDATE") || fail 'Cannot hash final boot'
printf 'status=FILE_REPACK_AND_AVB_HASH_PASS\noriginal_sha256=%s\nkernel_sha256=%s\noutput_sha256=%s\noutput_bytes=%s\npayload_bytes=%s\nraw_ramdisk_sha256=%s\nraw_ramdisk_unchanged=true\nheader_changes=kernel_size_only\navb_changes=hash_image_size_and_digest_only\nproperties_preserved=%s\ndevice_test=false\n' \
  "$ORIGINAL_SHA" "$KERNEL_SHA" "$OUTPUT_SHA" "$BOOT_BYTES" "$NEW_END" "$OLD_RAMDISK_SHA" "$OLD_PROPERTIES" > "$WORK/REPACK_RESULT.txt" || fail 'Cannot write result'
# Atomic, no-clobber publication; work and output must be on the same filesystem.
ln -T "$CANDIDATE" "$OUTPUT" || fail 'Cannot publish new output on the same filesystem without replacing a path'
printf 'R12_BOOT_REPACK=PASS; SHA256=%s; DEVICE_TEST=NO\n' "$OUTPUT_SHA"
