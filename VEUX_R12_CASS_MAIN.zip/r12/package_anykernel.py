#!/usr/bin/env python3
"""Package a fully validated CASS Image as a self-contained AnyKernel ZIP.

No private boot image or remote packaging input is required. The device-side
script backs up the current boot, replaces its kernel and preserves the checked
ramdisk/header/unsigned AVB policy before the existing write/readback lifecycle.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'r11/packaging'))
import boot_common as common
from builtin_validation import file_hash, record, validate_inputs

KERNEL_NAME = 'VEUX_R12_CASS_KERNEL.zip'
MAGISKBOOT_SHA = 'd7440e2cd89899426e809554bf793baef9804ccbe5a52ce34a8b6242725d3c77'
AK3_CORE_SHA = 'f7a51cfe2e093016a34a76e16de6c9885c2d1992c3482fcabc668680e1f0f6bb'
AK3_UPDATE_BINARY_SHA = 'cf3ebe7183d5e3f25e9215cde7ef9dd956e836232a70f2a671891ab4889c7e7d'
require = common.require


def authenticated(payload, relative):
    """Require the exact member already authenticated by the workflow bootstrap."""
    path = payload / relative
    data = common.regular(path)
    manifest = json.loads(common.regular(payload / 'PAYLOAD_MANIFEST.json'))
    require(common.sha(data) == manifest.get('files', {}).get(relative),
            'authenticated MAIN member changed: ' + relative)
    return data


def assets(payload):
    template = authenticated(payload, 'r12/assets/anykernel.sh.in')
    helper = authenticated(payload, 'r12/assets/r12_boot_repack.sh')
    root = payload / 'r12/ak3'
    require(root.is_dir() and not root.is_symlink(), 'AnyKernel tool tree missing')
    files = {}
    for file in sorted(root.rglob('*')):
        require(not file.is_symlink(), 'linked AnyKernel member')
        if file.is_file():
            relative = file.relative_to(root).as_posix()
            files[relative] = authenticated(payload, 'r12/ak3/' + relative)
    require(common.sha(files.get('tools/ak3-core.sh', b'')) == AK3_CORE_SHA,
            'proven AnyKernel core differs')
    require(common.sha(files.get('META-INF/com/google/android/update-binary', b'')) == AK3_UPDATE_BINARY_SHA,
            'proven AnyKernel bootstrap differs')
    require(common.sha(files.get('tools/r12-magiskboot', b'')) == MAGISKBOOT_SHA,
            'official ARM64 Magiskboot differs')
    require('LICENSE' in files, 'AnyKernel license missing')
    require(b'@BOOT_SHA256@' not in template and b'payload/boot.img' not in template,
            'prebuilt/private boot dependency remains')
    require(b'--original "$BACKUP_FILE"' in template and b'--kernel "$KERNEL_PAYLOAD"' in template,
            'current-boot/kernel repack call absent')
    return template, helper, files


def write_json(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def verify_archive(path, expected_image, expected_script, expected_helper, expected_assets):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) and archive.testzip() is None, 'kernel ZIP integrity failed')
        forbidden = {'boot.img', 'payload/boot.img', 'dtb', 'dtbo', 'vendor_boot.img', 'init_boot.img'}
        require(not any(name in forbidden or name.endswith('.ko') for name in names),
                'prebuilt boot, extra partition or external module payload is forbidden')
        reserved = {'Image', 'anykernel.sh', 'tools/r12-boot-repack.sh',
                    'README.txt', 'BUILD_PACKAGE_CHECK.json', 'SHA256SUMS'}
        require(not reserved.intersection(expected_assets), 'AnyKernel assets collide with package members')
        require(set(names) == reserved | set(expected_assets), 'kernel ZIP member set differs')
        require(archive.read('Image') == expected_image, 'kernel ZIP Image differs from validated Image')
        require(archive.read('anykernel.sh') == expected_script, 'kernel ZIP script differs')
        require(archive.read('tools/r12-boot-repack.sh') == expected_helper, 'kernel ZIP repack helper differs')
        for name, data in expected_assets.items():
            require(archive.read(name) == data, 'kernel ZIP tool differs: ' + name)
        hashed_names = set()
        for line in archive.read('SHA256SUMS').decode('ascii').splitlines():
            require(re.fullmatch(r'[0-9a-f]{64}  [^\r\n]+', line) is not None,
                    'kernel ZIP checksum format differs')
            digest, name = line.split('  ', 1)
            require(name in set(names) - {'SHA256SUMS'} and name not in hashed_names,
                    'kernel ZIP checksum name missing, duplicated or unexpected')
            hashed_names.add(name)
            require(common.sha(archive.read(name)) == digest, 'kernel ZIP member SHA mismatch: ' + name)
        require(hashed_names == set(names) - {'SHA256SUMS'}, 'kernel ZIP checksum coverage incomplete')
    return {'zip_crc': 'PASS', 'every_member_hash': 'PASS', 'no_prebuilt_boot': True,
            'exact_member_set': 'PASS', 'complete_unique_checksum_coverage': 'PASS',
            'no_vendor_boot_dtb_dtbo_or_init_boot_payload': True, 'no_external_rmnet_modules': True}


def build(args):
    require(not args.out.exists() and not args.out.is_symlink(), 'output directory must be new')
    require(args.payload.resolve() == HERE.parent.resolve(), 'packager must run from authenticated MAIN')
    # Reject the wrong evidence class before any expensive validation and never
    # relabel restored local test fixtures as results of this CI invocation.
    preliminary = json.loads(common.regular(args.receipt))
    require(preliminary.get('provenance', {}).get('evidence_mode') == args.evidence_mode,
            'CI/local provenance cannot be relabeled')
    data, receipt, checks = validate_inputs(args.inputs, args.receipt)
    require(checks['evidence_mode'] == args.evidence_mode, 'validated evidence mode differs')
    template, helper, ak3_files = assets(args.payload)
    image_sha = common.sha(data['Image'])
    replacements = {b'@IMAGE_SHA256@': image_sha.encode(),
                    b'@REPACK_SHA256@': common.sha(helper).encode(),
                    b'@MAGISKBOOT_SHA256@': MAGISKBOOT_SHA.encode()}
    script = template
    for before, after in replacements.items():
        require(script.count(before) == 1, 'missing/duplicate kernel template placeholder')
        script = script.replace(before, after)
    require(b'@IMAGE_SHA256@' not in script and b'@REPACK_SHA256@' not in script,
            'unresolved kernel script identity')
    args.out.mkdir(parents=True)
    script_path = args.out / 'anykernel.checked.sh'
    script_path.write_bytes(script)
    subprocess.run(['sh', '-n', str(script_path)], check=True)
    subprocess.run(['shellcheck', '--shell=ash', '--severity=warning', str(script_path)], check=True)
    subprocess.run(['sh', '-n', str(HERE / 'assets/r12_boot_repack.sh')], check=True)
    subprocess.run(['shellcheck', '--shell=ash', '--severity=warning', str(HERE / 'assets/r12_boot_repack.sh')], check=True)
    members = {'Image': (data['Image'], 0o644), 'anykernel.sh': (script, 0o755),
               'tools/r12-boot-repack.sh': (helper, 0o755)}
    for name, content in ak3_files.items():
        mode = 0o644 if name == 'LICENSE' or name.endswith('updater-script') else 0o755
        members[name] = (content, mode)
    readme = (
        'VEUX R12 CASS – Kernel-ZIP\n\n'
        'Geraet: VEUX; Android13; aktiver Boot-Slot.\n'
        'Der vollstaendig gebaute Kernel enthaelt BakaSU, SUSFS2.3, NoMountAPI22\n'
        'und beide eingebauten RMNET-Treiber. CASS bleibt aktiv; WALT bleibt aus.\n'
        'Beim Flashen wird die aktuelle Bootdatei zuerst dauerhaft gesichert.\n'
        'Nur der Kernel wird ersetzt; Ramdisk und gepruefte Boot-Metadaten bleiben erhalten.\n'
        'vendor_boot, dtbo und der andere Boot-Slot werden nicht geschrieben.\n'
        'Backup: Download/VEUX_R5_Backups/. Kein automatischer Neustart.\n'
        'NoMount21 darf vor dem Kernelwechsel vorhanden sein. Bei Bedarf wird es\n'
        'fuer den ersten Start deaktiviert; anschliessend die beigefuegte offizielle\n'
        'NoMount605-ZIP im passenden Spoofed Manager installieren und neu starten.\n'
        'Eine unveraenderte bereits installierte NoMount605 wird beibehalten.\n'
        'Ein Schreib- oder Readbackfehler ist kein erfolgreicher Flash: dann nicht\n'
        'ungeprueft neu starten; die zuvor gesicherte Bootdatei steht zur Wiederherstellung bereit.\n\n'
        'Build/Paket geprueft; Geraeteboot und Laufzeitverhalten noch nicht getestet.\n'
        'ImageSHA256: ' + image_sha + '\n'
        'KernelNotesSHA256: ' + checks['kernel_notes_sha256'] + '\n')
    members['README.txt'] = (readme.encode(), 0o644)
    members['BUILD_PACKAGE_CHECK.json'] = ((json.dumps(checks, indent=2) + '\n').encode(), 0o644)
    members['SHA256SUMS'] = (''.join(common.sha(content) + '  ' + name + '\n'
                                    for name, (content, mode) in sorted(members.items())).encode(), 0o644)
    archive = args.out / KERNEL_NAME
    common.write_zip(archive, members)
    verified = verify_archive(archive, data['Image'], script, helper, ak3_files)
    package_check = {'status': 'ANYKERNEL_PACKAGE_STATIC_PASS_DEVICE_UNTESTED',
                     'kernel_zip': {'file': KERNEL_NAME, **record(archive)},
                     'image_sha256': image_sha, 'script_sha256': common.sha(script),
                     'repack_helper_sha256': common.sha(helper),
                     'arm64_magiskboot_sha256': MAGISKBOOT_SHA,
                     'ak3_commit': common.AK3_COMMIT, 'ak3_core_sha256': AK3_CORE_SHA,
                     'ramdisk_source': 'current device boot after verified persistent backup',
                     'boot_generation': 'on-device-current-boot', 'device_test': False, **verified}
    write_json(args.out / 'ANYKERNEL_PACKAGE_CHECK.json', package_check)
    write_json(args.out / 'BUILD_PACKAGE_CHECK.json', checks)
    (args.out / 'BUILD_OUTPUTS.json').write_bytes(common.regular(args.receipt))
    (args.out / 'README.txt').write_text('Die aeussere GitHub-Artefakt-ZIP entpacken.\n'
                                      'Die Datei ' + KERNEL_NAME + ' ist die Kernel-ZIP.\n\n' + readme)
    companions = {}
    for key, name in [('manager_apk', 'BakaSU_v4.2.0-rc3_35252-arm64-v8a-spoofed-release.apk'),
                      ('nomount_zip', 'NoMount-v2.2.0-release-bf1847f-605.zip')]:
        content = common.pinned(args.payload / 'companions' / name, common.PINS[key])
        (args.out / name).write_bytes(content)
        companions[key] = {'file': name, 'sha256': common.sha(content), 'bytes': len(content)}
    result = {'schema': 'veux-r12-anykernel-package-v1',
              'status': 'KERNEL_ZIP_STATIC_PASS_DEVICE_UNTESTED',
              'origin': receipt['origin'], 'evidence_mode': args.evidence_mode,
              'kernel_release': checks['kernel_release'], 'kernel_notes_sha256': checks['kernel_notes_sha256'],
              'rmnet_mode': 'builtin', 'external_rmnet_payload': False,
              'kernel_zip': package_check['kernel_zip'], 'companions': companions,
              'private_ci_boot_input_required': False, 'prebuilt_boot_image': False,
              'device_test': False, 'automatic_flash': False,
              'actual_kernel_validation': checks['status']}
    write_json(args.out / 'PACKAGE_RESULT.json', result)
    # The workflow adds the newly bound R2 diagnostic after this stage and
    # appends its hash. The checksum file is deliberately not self-hashed.
    names = [KERNEL_NAME, 'BUILD_PACKAGE_CHECK.json', 'BUILD_OUTPUTS.json',
             'ANYKERNEL_PACKAGE_CHECK.json', 'PACKAGE_RESULT.json', 'README.txt']
    names.extend(item['file'] for item in companions.values())
    (args.out / 'SHA256SUMS').write_text(''.join(file_hash(args.out / name) + '  ' + name + '\n' for name in names))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('inputs', 'receipt', 'out', 'payload'):
        parser.add_argument('--' + name, type=lambda value: Path(value).absolute(), required=True)
    parser.add_argument('--evidence-mode', choices=('ci', 'local-native'), default='ci')
    args = parser.parse_args()
    try:
        print(json.dumps(build(args), indent=2))
    except Exception as error:
        print('R12_PACKAGE_BLOCKED: ' + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
