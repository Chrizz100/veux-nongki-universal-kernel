#!/usr/bin/env python3
"""Validate the real local kernel package and reject wrong CI provenance/bytes."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parent
PAYLOAD = ROOT / 'payload'
BUILD = ROOT / 'fixtures/fullbuild/Build'
PACKAGE = ROOT / 'local_package_final'
MODULE_PATH = PAYLOAD / 'r12/package_anykernel.py'
spec = importlib.util.spec_from_file_location('r12_test_packager', MODULE_PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class ActualPackageTests(unittest.TestCase):
    def test_actual_package_matches_validated_outputs(self):
        template, helper, assets = module.assets(PAYLOAD)
        script = (PACKAGE / 'anykernel.checked.sh').read_bytes()
        result = module.verify_archive(PACKAGE / module.KERNEL_NAME, (BUILD / 'Image').read_bytes(), script, helper, assets)
        self.assertEqual(result['every_member_hash'], 'PASS')
        self.assertTrue(result['no_prebuilt_boot'])
        self.assertTrue(result['no_vendor_boot_dtb_dtbo_or_init_boot_payload'])

    def test_local_fixture_is_never_accepted_as_this_ci_build(self):
        with tempfile.TemporaryDirectory(prefix='r12-package-mode-') as tmp:
            output = Path(tmp) / 'out'
            args = argparse.Namespace(payload=PAYLOAD, inputs=BUILD, receipt=BUILD / 'BUILD_OUTPUTS.json',
                                      out=output, evidence_mode='ci')
            with self.assertRaisesRegex(ValueError, 'CI/local provenance cannot be relabeled'):
                module.build(args)
            self.assertFalse(output.exists())

    def test_modified_image_and_script_are_detected(self):
        template, helper, assets = module.assets(PAYLOAD)
        script = (PACKAGE / 'anykernel.checked.sh').read_bytes()
        image = (BUILD / 'Image').read_bytes()
        for field in ('Image', 'anykernel.sh', 'tools/r12-boot-repack.sh'):
            with self.subTest(field=field), tempfile.TemporaryDirectory(prefix='r12-package-change-') as tmp:
                target = Path(tmp) / 'changed.zip'
                with zipfile.ZipFile(PACKAGE / module.KERNEL_NAME) as original, zipfile.ZipFile(target, 'w', zipfile.ZIP_STORED) as changed:
                    for item in original.infolist():
                        raw = original.read(item.filename)
                        if item.filename == field:
                            raw = bytes([raw[0] ^ 1]) + raw[1:]
                        changed.writestr(item.filename, raw)
                with self.assertRaises(ValueError):
                    module.verify_archive(target, image, script, helper, assets)

    def test_extra_partition_payload_rejected(self):
        template, helper, assets = module.assets(PAYLOAD)
        script = (PACKAGE / 'anykernel.checked.sh').read_bytes()
        with tempfile.TemporaryDirectory(prefix='r12-package-partition-') as tmp:
            target = Path(tmp) / 'changed.zip'
            with zipfile.ZipFile(PACKAGE / module.KERNEL_NAME) as original, zipfile.ZipFile(target, 'w', zipfile.ZIP_STORED) as changed:
                for item in original.infolist():
                    changed.writestr(item.filename, original.read(item.filename))
                changed.writestr('dtb', b'must never switch AK3 into vendor_boot mode')
            with self.assertRaisesRegex(ValueError, 'extra partition'):
                module.verify_archive(target, (BUILD / 'Image').read_bytes(), script, helper, assets)

    def test_artifact_checksums_and_local_origin_are_honest(self):
        result = subprocess.run(['sha256sum', '--check', '--strict', 'SHA256SUMS'], cwd=PACKAGE,
                                text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        self.assertEqual(result.returncode, 0, result.stdout)
        data = json.loads((PACKAGE / 'PACKAGE_RESULT.json').read_text())
        self.assertEqual(data['origin'], 'local-native-full-build')
        self.assertEqual(data['evidence_mode'], 'local-native')
        self.assertFalse(data['device_test'])
        self.assertFalse(data['automatic_flash'])

    def test_incomplete_duplicate_or_malformed_checksums_rejected(self):
        template, helper, assets = module.assets(PAYLOAD)
        script = (PACKAGE / 'anykernel.checked.sh').read_bytes()
        with zipfile.ZipFile(PACKAGE / module.KERNEL_NAME) as original:
            entries = {name: original.read(name) for name in original.namelist()}
        lines = entries['SHA256SUMS'].splitlines(keepends=True)
        variants = {'missing': b''.join(lines[1:]),
                    'duplicate': entries['SHA256SUMS'] + lines[0],
                    'empty': b'', 'malformed': b'not-a-checksum  Image\n'}
        for name, content in variants.items():
            with self.subTest(name=name), tempfile.TemporaryDirectory(prefix='r12-checksums-') as tmp:
                target = Path(tmp) / 'changed.zip'
                with zipfile.ZipFile(target, 'w', zipfile.ZIP_STORED) as changed:
                    for member, data in entries.items():
                        changed.writestr(member, content if member == 'SHA256SUMS' else data)
                with self.assertRaisesRegex(ValueError, 'checksum'):
                    module.verify_archive(target, (BUILD / 'Image').read_bytes(), script, helper, assets)

    def test_unexpected_and_missing_members_rejected(self):
        template, helper, assets = module.assets(PAYLOAD)
        script = (PACKAGE / 'anykernel.checked.sh').read_bytes()
        with zipfile.ZipFile(PACKAGE / module.KERNEL_NAME) as original:
            entries = {name: original.read(name) for name in original.namelist()}
        for variant in ('extra', 'missing'):
            with self.subTest(variant=variant), tempfile.TemporaryDirectory(prefix='r12-members-') as tmp:
                target = Path(tmp) / 'changed.zip'
                with zipfile.ZipFile(target, 'w', zipfile.ZIP_STORED) as changed:
                    for member, data in entries.items():
                        if variant != 'missing' or member != 'README.txt':
                            changed.writestr(member, data)
                    if variant == 'extra':
                        changed.writestr('unapproved.txt', b'unapproved extra member')
                with self.assertRaisesRegex(ValueError, 'member set'):
                    module.verify_archive(target, (BUILD / 'Image').read_bytes(), script, helper, assets)


if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ActualPackageTests))
    out = ROOT / 'payload/r12/review/ACTUAL_KERNEL_PACKAGE_TESTS.json'
    proof = {'status': 'PASS' if result.wasSuccessful() else 'FAIL', 'tests': result.testsRun,
             'kernel_zip_sha256': hashlib.sha256((PACKAGE / module.KERNEL_NAME).read_bytes()).hexdigest(),
             'fixture_origin': 'genuine restored local-native-full-build', 'new_kernel_compile_performed': False,
             'new_github_build': False, 'device_test': False}
    out.write_text(json.dumps(proof, indent=2) + '\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
