#!/usr/bin/env python3
"""File-only tests on two genuine kernel builds; no device/partition writes."""
from pathlib import Path
import argparse
import hashlib
import importlib.machinery
import importlib.util
import json
import os
import shutil
import struct
import subprocess
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent
WORKSPACE = PROJECT.parent
BASE = PROJECT / 'fixtures/installer/payload/boot.img'
NEW_KERNEL = PROJECT / 'fixtures/fullbuild/Build/Image'
TEMP_ZIP = WORKSPACE / 'work_r11_ci_revision/packaging_review/VEUX_5.4.274_TempR1_Flash.zip'
MAGISK = PROJECT / 'ak3_review/runtime_repack_evidence/magiskboot-x86_64'
AVB = WORKSPACE / 'work_r11_ci_revision/original/payload/tools/avbtool'
OUT = ROOT / 'tests'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()


def avb_module():
    loader = importlib.machinery.SourceFileLoader('r12_pinned_avb', str(AVB))
    spec = importlib.util.spec_from_loader(loader.name, loader)
    mod = importlib.util.module_from_spec(spec)
    loader.exec_module(mod)
    return mod


def metadata(path):
    m = avb_module()
    footer, header, desc, size = m.Avb()._parse_image(m.ImageHandler(str(path)))
    props = [d.encode().hex() for d in desc if isinstance(d, m.AvbPropertyDescriptor)]
    hashes = [d for d in desc if isinstance(d, m.AvbHashDescriptor)]
    assert len(hashes) == 1
    h = hashes[0]
    with path.open('rb') as f:
        page = f.read(4096)
        k, r = struct.unpack_from('<II', page, 8)
        kernel = f.read(k)
        roff = 4096 + (k + 4095) // 4096 * 4096
        f.seek(roff); ramdisk = f.read(r)
    return {'size':size, 'payload_size':footer.original_image_size, 'kernel_sha256':hashlib.sha256(kernel).hexdigest(),
            'ramdisk_sha256':hashlib.sha256(ramdisk).hexdigest(), 'raw_header':page,
            'props':props, 'salt':h.salt.hex(), 'digest':h.digest.hex(),
            'algorithm':header.algorithm_type, 'flags':header.flags,
            'rollback_index':header.rollback_index, 'rollback_index_location':header.rollback_index_location,
            'avb_hash_image_size':h.image_size}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--shell',default='bash',help='Shell executable; optional BusyBox ash wrapper')
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    assert sha(BASE) == '7b7f27d75d3dab4b29fc3c326be6864556f5980ca6be85c7960fdc0611e09aee'
    assert sha(NEW_KERNEL) == '4184f3ea55fb667af03de34f3bc0344c94cbfe3ce4e6634dd1a78dfe86045c44'
    assert sha(MAGISK) == 'a18ecbd7981179494b7d281453d6c4e25b5c719e7d2ef7f6eba3c6be3043c58e'
    assert sha(AVB) == '2ae13d6926094c86e67ea124c93990caaf67fc9b6e4e32cdf55c9c2cd3f36df6'
    with zipfile.ZipFile(TEMP_ZIP) as z:
        old_bytes = z.read('Image')
    assert hashlib.sha256(old_bytes).hexdigest() == '0a7f53dc067ad943cda460406512b6d1c7d74ad3900365d84ba63c8d6cb01991'
    old_kernel = OUT/'TempR1_Image'
    old_kernel.write_bytes(old_bytes)
    before = {str(p):sha(p) for p in (BASE,NEW_KERNEL,MAGISK,AVB,old_kernel)}
    cases = []

    def invoke(name, source, kernel, outdir, *, tool=MAGISK, output=None, work=None, expected=0):
        output = output or outdir/'boot.img'
        work = work or outdir/'work'
        cmd = [args.shell, str(ROOT/'r12_boot_repack.sh'), '--original', str(source),
               '--kernel', str(kernel), '--output', str(output), '--magiskboot', str(tool), '--work', str(work)]
        p = subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (OUT/(name+'.log')).write_text(p.stdout)
        assert p.returncode == expected, name+': '+p.stdout
        cases.append({'name':name,'exit':p.returncode,'expected':expected,'status':'PASS'})
        return output

    original_meta = metadata(BASE)
    for name, kernel in (('unchanged_real_r11_kernel',NEW_KERNEL),('changed_real_tempr1_kernel',old_kernel)):
        case_dir = OUT/name
        case_dir.mkdir(exist_ok=True)
        output = invoke(name,BASE,kernel,case_dir)
        m = metadata(output)
        assert m['kernel_sha256'] == sha(kernel)
        for key in ('size','ramdisk_sha256','props','salt','algorithm','flags','rollback_index','rollback_index_location'):
            assert m[key] == original_meta[key], (name,key)
        assert m['avb_hash_image_size'] == m['payload_size']
        h = bytearray(m['raw_header']); h[8:12] = original_meta['raw_header'][8:12]
        assert h == original_meta['raw_header']
        p = subprocess.run(['python3',str(AVB),'verify_image','--image',str(output)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (OUT/(name+'_independent_avb.log')).write_text(p.stdout)
        assert p.returncode == 0,p.stdout
        cases.append({'name':name+'_independent_avbtool','exit':0,'expected':0,'status':'PASS'})
        if kernel == NEW_KERNEL:
            assert sha(output) == sha(BASE)

    # The helper accepts a different valid runtime boot, with no hard-coded
    # private-base digest. Replacing its older genuine kernel with R11 reverses
    # the real size change and reproduces the original R11 boot byte-for-byte.
    reverse = OUT/'reverse_to_r11';reverse.mkdir(exist_ok=True)
    result = invoke('reverse_to_r11',OUT/'changed_real_tempr1_kernel/boot.img',NEW_KERNEL,reverse)
    assert sha(result) == sha(BASE)
    cases.append({'name':'reverse_reproduces_original_exact_boot','status':'PASS'})

    with BASE.open('rb') as f:
        f.seek(-64,2); footer = f.read(64)
        metaoff = struct.unpack_from('>Q',footer,20)[0]
        f.seek(metaoff+256+8); nbf = struct.unpack('>Q',f.read(8))[0]
        first_property = metaoff+256+16+nbf
    hash_offset = metaoff+256
    bad_inputs = [
        ('wrong_boot_magic',0,b'NOTBOOT!'),
        ('unsupported_header_version',40,struct.pack('<I',4)),
        ('invalid_ramdisk_length',12,struct.pack('<I',0xffffffff)),
        ('missing_avb',134217728-64,b'NONE'),
        ('oversized_vbmeta_offset',134217728-64+20,struct.pack('>Q',2**40)),
        ('signed_algorithm',metaoff+28,struct.pack('>I',1)),
        ('vbmeta_flags',metaoff+120,struct.pack('>I',3)),
        ('rollback_index',metaoff+112,struct.pack('>Q',1)),
        ('descriptor_flags',hash_offset+68,struct.pack('>I',1)),
        ('foreign_partition',hash_offset+132,b'vend'),
        ('wrong_digest_length',hash_offset+64,struct.pack('>I',31)),
        ('unsupported_descriptor',hash_offset,struct.pack('>Q',4)),
        ('duplicate_hash',first_property,struct.pack('>Q',2)),
        ('altered_payload_invalid_old_digest',8192,b'R12_NEGATIVE_TEST'),
    ]
    for name, offset, replacement in bad_inputs:
        with tempfile.TemporaryDirectory(prefix='reject-',dir=OUT) as td:
            case = Path(td); source = case/'original.img'
            shutil.copyfile(BASE,source)
            with source.open('r+b') as f:
                f.seek(offset);f.write(replacement)
            input_sha = sha(source)
            output = invoke(name,source,NEW_KERNEL,case,expected=1)
            assert not output.exists()
            assert sha(source) == input_sha
    with tempfile.TemporaryDirectory(prefix='reject-',dir=OUT) as td:
        case = Path(td); alias=case/'source-link.img';alias.symlink_to(BASE)
        result=invoke('symlink_original_rejected',alias,NEW_KERNEL,case,expected=1)
        assert not result.exists()
    with tempfile.TemporaryDirectory(prefix='reject-',dir=OUT) as td:
        case=Path(td); output=case/'boot.img'; output.write_bytes(b'keep-existing-output')
        invoke('existing_output_preserved',BASE,NEW_KERNEL,case,output=output,expected=1)
        assert output.read_bytes()==b'keep-existing-output'
    with tempfile.TemporaryDirectory(prefix='reject-',dir=OUT) as td:
        case=Path(td); fake=case/'magiskboot';fake.write_text('#!/bin/sh\nexit 0\n');fake.chmod(0o755)
        result=invoke('untrusted_magiskboot_rejected',BASE,NEW_KERNEL,case,tool=fake,expected=1)
        assert not result.exists()
    with tempfile.TemporaryDirectory(prefix='reject-',dir=OUT) as td:
        case=Path(td);bad=case/'bad-kernel';bad.write_bytes(b'Not a kernel.'*128)
        result=invoke('invalid_kernel_magic_rejected',BASE,bad,case,expected=1)
        assert not result.exists()
    after={str(p):sha(p) for p in (BASE,NEW_KERNEL,MAGISK,AVB,old_kernel)}
    assert after==before
    report={'schema':'veux-r12-runtime-boot-repack-host-v1','status':'PASS','helper_sha256':sha(ROOT/'r12_boot_repack.sh'),
            'test_source_sha256':sha(Path(__file__)),'shell':args.shell,'cases':cases,'cases_passed':len(cases),
            'fixtures':before,'original_inputs_unchanged':True,'real_changed_kernel_fixture':True,
            'independent_avbtool_verification':True,'same_kernel_byte_roundtrip':True,
            'different_runtime_boot_accepted_and_reverse_exact':True,
            'device_test':False,'kernel_compile_performed':False,'test_outputs_not_deliverable_kernel_releases':True}
    (OUT/'R12_REPACK_TEST_RESULT.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ('cases','fixtures')},indent=2))


if __name__=='__main__': main()
