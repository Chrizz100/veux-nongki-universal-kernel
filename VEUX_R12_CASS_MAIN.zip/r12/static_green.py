#!/usr/bin/env python3
"""Authenticate and statically check the one-MAIN, one-output R12 workflow.

This proves source/workflow integrity and syntax, not kernel compilation or a
device boot. The complete build and package stages produce separate evidence.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import zipfile

import yaml

R11_MANIFEST_SHA = '51188d8e4e5621efdb700f6f4d9d63d5af2b234e96574af3c9bb9dc2dee4fe61'
SHELLCHECK_SHA = '4da528ddb3a4d1b7b24a59d4e16eb2f5fd960f4bd9a3708a15baddbdf1d5a55b'
ACTIONLINT_SHA = 'c872d6db8c6bf83a8eaa704fc93999f027d55dffbc63b8a6abdccb47df5f4cd4'
WORKFLOW_FILE = 'VEUX_R12_CASS_BUILD.yml'
LEGACY_ZIPS = {
    'VEUX_R5S2_BAKASU522_MAIN.zip': '37a85d967df5cd9fa4dd3302e2073bc3b9ce461a6e03cd0ef51914fa5f5358b8',
    'VEUX_R5S2_GENUINE_BAKASU35234_MAIN.zip': 'd3c0b0da02af4355d1cc0b77b14320c0e8a32fd15995dee7bfbe9acd263e2457',
    'VEUX_R55H17_R4_CASS_UPDATE_MAIN.zip': '88907c8f1bd0a39826092edcd3bf824c05a40bb70d894a53437e001927f75380',
}
VENDOR_SHELL = {
    'r12/ak3/META-INF/com/google/android/update-binary': {
        'sha256': 'cf3ebe7183d5e3f25e9215cde7ef9dd956e836232a70f2a671891ab4889c7e7d',
        'known_upstream_findings': [{'code': 'SC2218', 'line': 208,
            'context': 'getprop command is tried before defining its shell fallback'}]},
    'r12/ak3/tools/ak3-core.sh': {
        'sha256': 'f7a51cfe2e093016a34a76e16de6c9885c2d1992c3482fcabc668680e1f0f6bb',
        'known_upstream_findings': [{'code': 'SC2144', 'line': 979,
            'context': 'unchanged upstream block-device fallback tests a glob with -e'},
            {'code': 'SC2144', 'line': 981,
             'context': 'unchanged upstream block-device fallback tests a glob with -e'}]},
}
REQUIRED_STAGE_IDS = {
    'r12_repository', 'r12_auth', 'r12_legacy_inputs', 'r12_shellcheck',
    'r12_static', 'r12_compile', 'r4_verify', 'r12_environment', 'r12_builtin',
    'r12_package', 'r12_diagnostics', 'r12_repo_unchanged', 'r12_kernel_upload',
    'r12_reports_upload', 'r12_complete',
}
# These full run bodies protect the independent postcompile gates, including
# all 132 actual RMNET imports. R12 CI-R2 changes the first gate's script path
# to an explicit complete-row ABI revision and restores the original pinned
# R4 CRC-reference bytes in the next gate. All other checks are preserved.
PRESERVED_FINAL_GATES = {
    'Independently require R5S1 module ABI boot AK3 and new 522 compiled proof':
        '62adcb902b30c16b4040e8fcbc53dcfa8ab5934645a9d764d745b573ce6a59c8',
    'R55H17-R1 require unchanged CASS config and 132 loaded RMNET CRC imports - NO FLASH':
        '3641e72cb0bb21066b1b0d3995ed9033f88aa131f3d8abe64828b81c449a4ea2',
    'R4 require genuine candidate build CASS config DTB version preinit and 132 RMNET proofs':
        'f79b8d3c36a86391cf934e2bcfb6aef762904791d178fa0fd9aec3cd26af67de',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


def command(argv):
    result = subprocess.run([str(x) for x in argv], text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    require(result.returncode == 0, 'STATIC_COMMAND_FAILED:' + json.dumps(
        [str(x) for x in argv]) + '\n' + result.stdout)
    return {'command': [str(x) for x in argv], 'exit': 0, 'output': result.stdout}


def authenticate_payload(payload, document):
    manifest_path = payload / 'PAYLOAD_MANIFEST.json'
    manifest_raw = manifest_path.read_bytes()
    manifest = json.loads(manifest_raw)
    require(manifest.get('schema') == 1 and manifest.get('automatic_flash') is False,
            'R12_MANIFEST_SCHEMA_CHANGED')
    files = manifest.get('files')
    require(isinstance(files, dict) and files, 'R12_EMPTY_MANIFEST')
    for name, digest in files.items():
        require(isinstance(name, str) and isinstance(digest, str)
                and re.fullmatch('[0-9a-f]{64}', digest), 'R12_MANIFEST_ENTRY_INVALID')
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts
                and str(relative) == name and '\\' not in name,
                'R12_UNSAFE_MANIFEST_PATH')
        file = payload / name
        require(file.is_file() and not file.is_symlink(), 'R12_INPUT_NOT_REGULAR:' + name)
        require(sha(file) == digest, 'R12_PAYLOAD_CHANGED:' + name)
    actual = set()
    for path in payload.rglob('*'):
        require(not path.is_symlink(), 'R12_PAYLOAD_SYMLINK:' + str(path))
        if path.is_file():
            actual.add(path.relative_to(payload).as_posix())
    require(actual == set(files) | {'PAYLOAD_MANIFEST.json'}, 'R12_UNMANIFESTED_OR_MISSING_FILE')
    environment = document['env']
    require(environment.get('REPRO_PACKAGE') == 'VEUX_R12_CASS_MAIN.zip', 'R12_MAIN_NAME_CHANGED')
    archive_sha = environment.get('REPRO_ARCHIVE_SHA256', '')
    require(re.fullmatch('[0-9a-f]{64}', archive_sha) and archive_sha != '0' * 64,
            'R12_ARCHIVE_PIN_MISSING_OR_PLACEHOLDER')
    require(environment.get('REPRO_MANIFEST_SHA256') == hashlib.sha256(manifest_raw).hexdigest(),
            'R12_YAML_MANIFEST_PIN_MISMATCH')
    reference_path = payload / 'r12/reference/R11_PAYLOAD_MANIFEST.json'
    require(sha(reference_path) == R11_MANIFEST_SHA, 'R11_REFERENCE_MANIFEST_CHANGED')
    reference = json.loads(reference_path.read_text())
    require(len(reference.get('files', {})) == 189, 'R11_REFERENCE_FILE_COUNT_CHANGED')
    for name, digest in reference['files'].items():
        # Only the user-facing root README is updated. Its original bytes remain
        # available under an explicitly named, authenticated historical copy.
        checked = payload / ('r12/reference/R11_ANLEITUNG.txt' if name == 'ANLEITUNG.txt' else name)
        require(checked.is_file() and not checked.is_symlink() and sha(checked) == digest,
                'R11_ORIGINAL_SOURCE_OR_REFERENCE_CHANGED:' + name)
    for name, digest in LEGACY_ZIPS.items():
        require(sha(payload / 'reference/root_inputs' / name) == digest,
                'R12_LEGACY_ARCHIVE_CHANGED:' + name)
    require(sha(payload / 'r12/host-tools/shellcheck') == SHELLCHECK_SHA,
            'R12_SHELLCHECK_BINARY_CHANGED')
    require(sha(payload / 'r12/reference/legacy_r5s1_verify_result.py') ==
            '74f6df5b4300b7dd21556b5dc21dc8128831368541e709df66369021e50e8537',
            'R12_ORIGINAL_POSTCOMPILE_REFERENCE_CHANGED')
    return {'manifest_files': len(files), 'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
            'archive_sha256': archive_sha, 'original_source_and_executable_files_preserved': True,
            'unchanged_original_members': 188, 'documented_root_readme_update': True,
            'original_readme_copy_verified': True, 'legacy_archives_inside_main': True}


def workflow_contract(document, raw):
    require(document.get('on') == {'workflow_dispatch': {}}, 'R12_REQUIRES_INPUT_FREE_MANUAL_TRIGGER')
    require(document.get('permissions') == {'contents': 'read'}, 'R12_WRITE_PERMISSION_OR_MISSING_GUARD')
    require(set(document.get('jobs', {})) == {'r5s2_bakasu_522'}, 'R12_JOB_SET_CHANGED')
    job = document['jobs']['r5s2_bakasu_522']
    require("github.repository == 'Chrizz100/veux-nongki-universal-kernel'" in job.get('if', '')
            and "github.ref == 'refs/heads/main'" in job.get('if', ''), 'R12_REPOSITORY_OR_MAIN_GUARD_MISSING')
    forbidden = ('secrets.', 'VEUX_BOOT_TEMPLATE_URL', 'private_boot_input.py',
                 'create_boot_artifacts', 'build_target', 'inputs.', '--evidence-mode local-native',
                 '$GITHUB_WORKSPACE/$R5S2_MAIN_ZIP', '$GITHUB_WORKSPACE/$VERSION_MAIN_ZIP',
                 '$GITHUB_WORKSPACE/$R4_PACKAGE_NAME')
    require(not any(token in raw for token in forbidden), 'R12_REMOVED_DEPENDENCY_OR_LOCAL_PROVENANCE')
    seen = {}
    for position, step in enumerate(job['steps']):
        require('continue-on-error' not in step, 'R12_ERROR_SUPPRESSION_FORBIDDEN')
        if 'id' in step:
            require(step['id'] not in seen, 'R12_DUPLICATE_STAGE_ID')
            seen[step['id']] = (position, step)
        if 'uses' in step:
            require(re.fullmatch(r'[^@]+@[0-9a-f]{40}', step['uses']), 'R12_ACTION_NOT_COMMIT_PINNED')
    require(REQUIRED_STAGE_IDS <= set(seen), 'R12_REQUIRED_STAGE_MISSING')
    chain = ['r12_repository', 'r12_auth', 'r12_legacy_inputs', 'r12_shellcheck',
             'r12_static', 'r12_compile', 'r4_verify', 'r12_environment', 'r12_builtin',
             'r12_package', 'r12_diagnostics', 'r12_repo_unchanged', 'r12_kernel_upload', 'r12_complete']
    require([seen[key][0] for key in chain] == sorted(seen[key][0] for key in chain),
            'R12_REQUIRED_STAGE_ORDER_CHANGED')
    for key in chain[:11]:
        require('if' not in seen[key][1], 'R12_FULL_BUILD_STAGE_CAN_BE_SKIPPED:' + key)
    for name, expected_sha in PRESERVED_FINAL_GATES.items():
        matches = [(position, step) for position, step in enumerate(job['steps'])
                   if step.get('name') == name]
        require(len(matches) == 1, 'R12_PRESERVED_POSTCOMPILE_GATE_MISSING:' + name)
        position, step = matches[0]
        require('if' not in step and seen['r12_compile'][0] < position < seen['r12_builtin'][0],
                'R12_POSTCOMPILE_GATE_SKIPPABLE_OR_MISPLACED:' + name)
        require(hashlib.sha256(step.get('run', '').encode()).hexdigest() == expected_sha,
                'R12_PRESERVED_POSTCOMPILE_GATE_CHANGED:' + name)
    compile_script = seen['r12_compile'][1]['run']
    require('-p test_postcompile_abi.py -v' in seen['r12_static'][1]['run'],
            'R12_POSTCOMPILE_ABI_REGRESSION_MISSING')
    require('PYTHONPATH="$REPRO_PAYLOAD/r11:$R4_PAYLOAD/workflow:$REPRO_PAYLOAD/r12:' in compile_script,
            'R12_CHILD_IMPORT_PATH_MISSING')
    require(compile_script.count('"$REPRO_PAYLOAD/r12/veux_r11_bridge.py"') == 1,
            'R12_REAL_BUILD_BRIDGE_MISSING_OR_DUPLICATED')
    require('--repo "$GITHUB_WORKSPACE"' in compile_script and '--jobs 4' in compile_script,
            'R12_BASELINE_BUILD_ARGUMENTS_CHANGED')
    collector = seen['r12_builtin'][1]['run']
    for token in ('"$REPRO_PAYLOAD/r11/packaging/collect_builtin.py"',
                  '--source "$RUNNER_TEMP/veux-r55h17-r4/source/kernel"',
                  '--build "$RUNNER_TEMP/veux-r55h17-r4/build"',
                  '--evidence "$RUNNER_TEMP/veux-r55h17-r4/evidence"',
                  '--out "$RUNNER_TEMP/r12-flat-build"', '--repo-commit "$GITHUB_SHA" --evidence-mode ci'):
        require(token in collector, 'R12_ACTUAL_BUILD_COLLECTION_CONTRACT_CHANGED:' + token)
    pack = seen['r12_package'][1]['run']
    for token in ('"$REPRO_PAYLOAD/r12/package_anykernel.py"',
                  '--inputs "$RUNNER_TEMP/r12-flat-build"',
                  '--receipt "$RUNNER_TEMP/r12-flat-build/BUILD_OUTPUTS.json"',
                  '--out "$RUNNER_TEMP/r12-kernel"', '--payload "$REPRO_PAYLOAD"', '--evidence-mode ci'):
        require(token in pack, 'R12_PACKAGING_PROVENANCE_CHANGED:' + token)
    upload = seen['r12_kernel_upload'][1]
    condition = upload.get('if', '')
    for token in ('success()', "steps.r12_package.conclusion == 'success'",
                  "steps.r12_diagnostics.conclusion == 'success'", "steps.r12_repo_unchanged.conclusion == 'success'"):
        require(token in condition, 'R12_KERNEL_UPLOAD_NOT_GATED')
    require(upload['with']['name'] == 'VEUX_R12_KERNEL'
            and upload['with'].get('if-no-files-found') == 'error', 'R12_KERNEL_ARTIFACT_CONTRACT_CHANGED')
    required_uploads = {'${{ runner.temp }}/r12-kernel/' + name for name in (
        'VEUX_R12_CASS_KERNEL.zip', 'VEUX_R12_GERAETEDIAGNOSE_R2.sh', 'SHA256SUMS',
        'BUILD_OUTPUTS.json', 'BUILD_PACKAGE_CHECK.json', 'PACKAGE_RESULT.json')}
    upload_paths = set(upload['with']['path'].splitlines())
    require(required_uploads <= upload_paths, 'R12_REQUIRED_ARTIFACT_FILE_MISSING')
    require(all(path.startswith('${{ runner.temp }}/r12-kernel/') and '*' not in path
                and not path.endswith('/') for path in upload_paths), 'R12_ARTIFACT_REQUIRES_EXPLICIT_PACKAGE_FILES')
    upload_steps = [s for s in job['steps'] if s.get('uses', '').startswith('actions/upload-artifact@')]
    require(len(upload_steps) == 2, 'R12_REQUIRES_ONE_KERNEL_AND_ONE_REPORT_ARTIFACT')
    report = seen['r12_reports_upload'][1]
    require(report.get('if') == '${{ always() }}' and report['with']['name'] == 'VEUX_R12_PRUEFBERICHTE',
            'R12_FAILURE_REPORT_UPLOAD_MISSING')
    for step in upload_steps:
        paths = step['with']['path']
        require(not any(token in paths for token in ('r11-private', 'ramdisk.cpio', 'R5S2_FINAL_CASS_SOURCE.tar.gz',
                                                     '/r12-flat-build/vmlinux', '/boot.img')),
                'R12_PRIVATE_OR_GIANT_ARTIFACT_PATH')
    final = seen['r12_complete'][1]
    require(final.get('if') == '${{ always() }}'
            and final.get('env', {}).get('KERNEL_UPLOAD_RESULT') == '${{ steps.r12_kernel_upload.conclusion }}'
            and 'raise SystemExit(1)' in final.get('run', ''), 'R12_FINAL_COMPLETION_GATE_MISSING')
    return job, {'required_stages': chain, 'user_inputs': [], 'secrets_required': False,
                 'full_baseline_and_candidate_compile_required': True, 'ci_provenance_required': True,
                 'preserved_postcompile_gate_sha256': PRESERVED_FINAL_GATES,
                 'one_kernel_and_one_report_artifact': True, 'error_suppression': False}


def verify_crc_reference(job, payload):
    """Evaluate the authenticated reference table before a costly compilation.

    The old YAML parsed successfully although a version-label replacement had
    corrupted one character inside compressed Base64. Require the entire
    embedded gate to equal the original R4 source, then load its real table.
    """
    name = 'R55H17-R1 require unchanged CASS config and 132 loaded RMNET CRC imports - NO FLASH'
    step = next(step for step in job['steps'] if step.get('name') == name)
    lines = step['run'].splitlines()
    start = next(i for i, line in enumerate(lines) if "<<'PY_R55H17_GATE'" in line) + 1
    end = next(i for i in range(start, len(lines)) if lines[i] == 'PY_R55H17_GATE')
    embedded = ('\n'.join(lines[start:end]) + '\n').encode()
    with zipfile.ZipFile(payload / 'reference/root_inputs/VEUX_R55H17_R4_CASS_UPDATE_MAIN.zip') as archive:
        original = archive.read('workflow/cass_reference_gate.py')
    expected_sha = 'ee181cd6d1357c53e6d92e835d9fa93f2b57c9abfcc665ce6915dac24e181e35'
    require(hashlib.sha256(original).hexdigest() == expected_sha, 'R12_ORIGINAL_CRC_GATE_SOURCE_CHANGED')
    require(embedded == original, 'R12_EMBEDDED_CRC_REFERENCE_DIFFERS_FROM_AUTHENTIC_R4')
    # All executed bytes are the SHA-pinned historical gate. Its __main__ CLI
    # remains inactive; evaluating constants exercises the actual Base64/JSON.
    namespace = {'__name__': 'r12_preflight_authenticated_crc_reference'}
    exec(compile(original, 'authenticated_cass_reference_gate.py', 'exec'), namespace)
    records = namespace['REFERENCE']
    require(isinstance(records, list) and len(records) == 132, 'R12_CRC_REFERENCE_COUNT_CHANGED')
    require(all(isinstance(row, (list, tuple)) and len(row) == 3
                and all(isinstance(value, str) for value in row)
                and re.fullmatch(r'0x[0-9a-f]{8}', row[2]) for row in records),
            'R12_CRC_REFERENCE_RECORD_INVALID')
    return {'status': 'AUTHENTIC_R4_CRC_REFERENCE_RUNTIME_PASS',
            'source_sha256': expected_sha, 'records': len(records),
            'embedded_source_byte_equal_to_original': True,
            'base64_zlib_json_evaluated': True, 'kernel_compilation': False}


def audit(payload, workflow, actionlint, out):
    payload, workflow = payload.resolve(strict=True), workflow.resolve(strict=True)
    out = out.resolve()
    require(not out.is_relative_to(payload), 'STATIC_OUTPUT_MUST_NOT_MODIFY_PAYLOAD')
    out.mkdir(parents=True, exist_ok=True)
    report = {'status': 'BLOCKED', 'workflow_sha256': sha(workflow),
              'kernel_compile_performed': False, 'device_test': False}
    records = []
    try:
        require((payload / 'r12/static_green.py').resolve(strict=True) == Path(__file__).resolve(),
                'R12_STATIC_CHECKER_MUST_RUN_FROM_AUTHENTICATED_PAYLOAD')
        raw = workflow.read_text()
        document = yaml.safe_load(raw)
        require(workflow.name == WORKFLOW_FILE, 'R12_WORKFLOW_FILENAME_MISMATCH')
        report['payload'] = authenticate_payload(payload, document)
        job, report['workflow_contract'] = workflow_contract(document, raw)
        report['crc_reference_runtime'] = verify_crc_reference(job, payload)
        shellcheck = Path(shutil.which('shellcheck') or '').resolve(strict=True)
        require(shellcheck.is_file() and sha(shellcheck) == SHELLCHECK_SHA, 'R12_PINNED_SHELLCHECK_NOT_ACTIVE')
        actionlint = actionlint.resolve(strict=True)
        require(sha(actionlint) == ACTIONLINT_SHA, 'R12_ACTIONLINT_BINARY_CHANGED')
        records.append(command([shellcheck, '--version']))
        records.append(command([actionlint, '--version']))
        python_files = 0
        for file in sorted(payload.rglob('*.py')):
            ast.parse(file.read_text(), filename=str(file))
            python_files += 1
        embedded = 0
        referenced = set()
        for i, step in enumerate(job['steps']):
            if 'run' not in step:
                continue
            require(step.get('shell') == 'bash', 'R12_UNREVIEWED_WORKFLOW_SHELL')
            script = out / f'workflow-step-{i:02d}.sh'
            script.write_text(step['run'])
            records.append(command(['bash', '-n', script]))
            records.append(command([shellcheck, '--shell=bash', '--severity=error', script]))
            for relative in re.findall(r'\$REPRO_PAYLOAD/([^"$:\s]+)', step['run']):
                target = payload / relative
                require(target.exists() and not target.is_symlink(), 'R12_REFERENCED_INPUT_MISSING:' + relative)
                referenced.add(relative)
            lines = step['run'].splitlines()
            require(not any(line.endswith('\\') and not lines[j + 1].strip()
                            for j, line in enumerate(lines[:-1])), 'R12_BROKEN_COMMAND_CONTINUATION')
            for j, line in enumerate(lines):
                match = re.search(r"<<'(PY[A-Za-z0-9_]*)'", line)
                if match:
                    end = next(k for k in range(j + 1, len(lines)) if lines[k] == match.group(1))
                    ast.parse('\n'.join(lines[j + 1:end]) + '\n', filename=str(script))
                    embedded += 1
        vendor_report = []
        for relative, info in VENDOR_SHELL.items():
            path = payload / relative
            require(sha(path) == info['sha256'], 'R12_PINNED_UPSTREAM_SHELL_CHANGED:' + relative)
            records.append(command(['sh', '-n', path]))
            vendor_report.append({'file': relative, **info, 'shell_syntax': 'PASS',
                'source': 'unchanged pinned AnyKernel3 af770f7b16cf8f8eb7c68614b2a693b3b361c90c',
                'semantic_shellcheck_gate': 'not applied to unchanged upstream vendor shell',
                'known_findings_reviewed_with': 'ShellCheck 0.11.0 BusyBox dialect'})
        shell_files = 0
        for file in sorted(payload.rglob('*')):
            relative = file.relative_to(payload).as_posix()
            if relative in VENDOR_SHELL or not file.is_file():
                continue
            if file.suffix == '.sh' or file.name.endswith('.sh.in'):
                records.append(command(['sh', '-n', file]))
                new_source = relative.startswith('r12/')
                dialect = 'ash' if relative.startswith('r12/assets/') else 'sh'
                severity = 'warning' if new_source else 'error'
                records.append(command([shellcheck, '--shell=' + dialect, '--severity=' + severity, file]))
                shell_files += 1
        records.append(command([actionlint, '-oneline', workflow]))
        report.update(status='STATIC_GREEN_PASS', steps=len(job['steps']), python_files_ast_checked=python_files,
                      embedded_python_blocks=embedded, shell_files_checked=shell_files,
                      referenced_payload_inputs_checked=sorted(referenced),
                      unchanged_upstream_shell_review=vendor_report, commands=records,
                      scope='authenticated original/new payload, complete mandatory workflow, source syntax, tool pins and gated artifacts')
    except Exception as error:
        report.update(failure=type(error).__name__ + ': ' + str(error), commands=records)
        (out / 'STATIC_GREEN_FAIL.json').write_text(json.dumps(report, indent=2) + '\n')
        raise
    (out / 'STATIC_GREEN_PASS.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'commands'}, indent=2))
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('payload', 'workflow', 'actionlint', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    args = parser.parse_args()
    audit(args.payload, args.workflow, args.actionlint, args.out)
