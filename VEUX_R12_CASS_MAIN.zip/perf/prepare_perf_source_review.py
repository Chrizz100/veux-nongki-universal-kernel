#!/usr/bin/env python3
"""Prepare a pinned source-review patch, never a device/ROM replacement.

Only the two resource-bitmap methods are changed. The test compiles the exact
extracted method bodies with a narrow data fixture and UBSan/ASan. It is not a
complete Android HAL build and does not imply ROM ABI compatibility.
"""
from pathlib import Path
import argparse
import difflib
import hashlib
import json
import os
import subprocess
import tempfile

PIN = 'bb2e8a7c97a29c15a98429e9f253a4cfbd31198940705853714d5abff13fdeba'
COMMIT = 'd1a994bb35bc685700c1bbfabae9bed43500899e'
METHODS = ('bool Target::isResourceSupported', 'void Target::mResetResourceSupported')

def function(source, marker):
    start = source.index(marker)
    opening = source.index('{', start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

NEW_QUERY = '''bool Target::isResourceSupported(uint16_t major, uint16_t minor) {
    if (major >= MAX_MAJOR_RESOURCES || minor >= 64 ||
            minor >= ResourceInfo::GetMinorIndex(major)) {
        return false;
    }

    return (mResourceSupported[major] & (uint64_t(1) << minor)) != 0;
}'''
NEW_CLEAR = '''void Target::mResetResourceSupported(uint16_t major, uint16_t minor) {
    if (major >= MAX_MAJOR_RESOURCES || minor >= 64 ||
            minor >= ResourceInfo::GetMinorIndex(major)) {
        return;
    }

    mResourceSupported[major] &= ~(uint64_t(1) << minor);
}'''
PRELUDE = r'''
#include <array>
#include <bitset>
#include <cassert>
#include <cstdint>
#include <iostream>
#define MAX_MAJOR_RESOURCES 4
struct ResourceInfo {
    static uint16_t GetMinorIndex(uint16_t major) {
        static constexpr uint16_t count[4] = {0,17,62,64};
        assert(major < MAX_MAJOR_RESOURCES);
        return count[major];
    }
};
struct Target {
    std::array<uint64_t,4> mResourceSupported;
    bool isResourceSupported(uint16_t,uint16_t);
    void mResetResourceSupported(uint16_t,uint16_t);
};
'''
TEST = r'''
int main() {
    unsigned cases = 0;
    for (uint16_t major=0; major<MAX_MAJOR_RESOURCES; ++major) {
        for (uint16_t bit=0; bit<64; ++bit) {
            for (uint64_t pattern : {UINT64_MAX, UINT64_C(0),
                                    UINT64_C(0xAAAAAAAAAAAAAAAA),
                                    UINT64_C(0x5555555555555555)}) {
                Target t{{UINT64_C(0x1020304050607080), UINT64_C(0xfedcba9876543210),
                          UINT64_C(0x123456789abcdef0), UINT64_C(0xff00ff00ff00ff00)}};
                t.mResourceSupported[major] = pattern;
                const auto before = t.mResourceSupported;
                std::bitset<64> expected(pattern);
                if (bit < ResourceInfo::GetMinorIndex(major)) expected.reset(bit);
                t.mResetResourceSupported(major,bit);
                assert(t.mResourceSupported[major] == expected.to_ullong());
                for (uint16_t other=0;other<MAX_MAJOR_RESOURCES;++other)
                    if (other != major) assert(t.mResourceSupported[other] == before[other]);
                for (uint16_t probe=0;probe<64;++probe) {
                    const bool wanted = probe < ResourceInfo::GetMinorIndex(major) && expected[probe];
                    assert(t.isResourceSupported(major,probe) == wanted);
                }
                ++cases;
            }
        }
    }
    for (uint16_t major : {uint16_t(0),uint16_t(1),uint16_t(2),uint16_t(3),
                          uint16_t(4),uint16_t(65535)}) {
        for (uint16_t minor : {uint16_t(64),uint16_t(65),uint16_t(65535)}) {
            Target t{{UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX}};
            const auto before=t.mResourceSupported;
            t.mResetResourceSupported(major,minor);
            assert(t.mResourceSupported == before);
            assert(!t.isResourceSupported(major,minor));
            ++cases;
        }
    }
    for (uint16_t major : {uint16_t(4),uint16_t(65535)}) {
        Target t{{UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX}};
        const auto before=t.mResourceSupported;
        t.mResetResourceSupported(major,0);
        assert(t.mResourceSupported == before && !t.isResourceSupported(major,0));
        ++cases;
    }
    std::cout << "CASES=" << cases << "\n";
}
'''
BAD_TEST = r'''
int main() {
    Target t{{UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX}};
    t.mResetResourceSupported(3,41);
    return 0;
}
'''

def run(argv, **kwargs):
    return subprocess.run(argv, capture_output=True, text=True, timeout=60, **kwargs)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    raw = args.source.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == PIN, 'Unexpected source revision; patch not prepared'
    original = raw.decode()
    modified = original.replace(function(original, METHODS[0]), NEW_QUERY, 1)
    modified = modified.replace(function(modified, METHODS[1]), NEW_CLEAR, 1)
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    patch = ''.join(difflib.unified_diff(original.splitlines(keepends=True), modified.splitlines(keepends=True),
                                      fromfile='a/perflocks/Target.cpp', tofile='b/perflocks/Target.cpp'))
    patch_path = out / '0001-REVIEW-ONLY-resource-bitmap-width-and-bounds.patch'
    patch_path.write_text(patch)
    with tempfile.TemporaryDirectory(prefix='veux-perf-source-') as temporary:
        td=Path(temporary)
        (td/'perflocks').mkdir(); (td/'perflocks/Target.cpp').write_bytes(raw)
        applied=run(['git','apply','--check',str(patch_path)],cwd=td)
        assert applied.returncode == 0, applied.stderr
        applied=run(['git','apply',str(patch_path)],cwd=td)
        assert applied.returncode == 0, applied.stderr
        assert (td/'perflocks/Target.cpp').read_text() == modified
        tested=PRELUDE+'\n'+'\n'.join(function(modified,m) for m in METHODS)+'\n'+TEST
        (td/'test.cpp').write_text(tested)
        compiler=['g++','-std=c++14','-O1','-g','-Wall','-Wextra','-Werror',
                  '-fsanitize=undefined,address','-fno-sanitize-recover=all','-fno-omit-frame-pointer']
        compiled=run(compiler+[str(td/'test.cpp'),'-o',str(td/'test')])
        assert compiled.returncode == 0, compiled.stderr
        # This fixture checks stack/array bounds, not heap ownership. LeakSanitizer
        # cannot inspect threads under the executor's ptrace environment.
        test_environment=dict(os.environ, ASAN_OPTIONS='detect_leaks=0')
        tested_result=run([str(td/'test')],env=test_environment)
        assert tested_result.returncode == 0, tested_result.stderr
        assert tested_result.stdout.strip() == 'CASES=1044', tested_result.stdout
        # Compile the exact old method bodies separately. UBSan must catch the
        # genuine source error for a high scheduler minor, not a simulated one.
        old=PRELUDE+'\n'+'\n'.join(function(original,m) for m in METHODS)+'\n'+BAD_TEST
        (td/'before.cpp').write_text(old)
        before_compiled=run(['g++','-std=c++14','-O1','-fsanitize=undefined',
                             '-fno-sanitize-recover=undefined',str(td/'before.cpp'),'-o',str(td/'before')])
        assert before_compiled.returncode == 0, before_compiled.stderr
        before=run([str(td/'before')])
        assert before.returncode != 0 and 'shift exponent 41 is too large' in before.stderr, before.stderr
        # Preserve the self-contained test and failure log, never test executables.
        (out/'bitmap_regression_test.cpp').write_text(tested)
        (out/'ORIGINAL_WIDTH_ERROR.txt').write_text(before.stderr)
    result = {
        'source_commit':COMMIT, 'source_path':'perflocks/Target.cpp', 'source_sha256':PIN,
        'patched_source_sha256':hashlib.sha256(modified.encode()).hexdigest(),
        'patch_file':patch_path.name, 'patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),
        'git_apply_check_and_byte_comparison':'PASS', 'exact_extracted_methods_tested':list(METHODS),
        'regression_cases':1044,'undefined_and_address_sanitizers':'PASS',
        'leak_sanitizer':'NOT_RUN; ptrace environment; no heap ownership under test',
        'old_high_minor_failure_reproduced':True,
        'tests_cover':['all 64 bit positions','0/17/62/64 declared resources',
                       'four bit patterns','unchanged other majors','invalid major/minor bounds'],
        'full_android_hal_build':False,'rom_replacement_ready':False,'device_execution':False,
        'automatic_kernel_build_integration':False,
        'scope':'Review-only source prerequisite; does not implement XML intersection, reset guards or CASS translation.'
    }
    (out/'SOURCE_PATCH_CHECKS.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
