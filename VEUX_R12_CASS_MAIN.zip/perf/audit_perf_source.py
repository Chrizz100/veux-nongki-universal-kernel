#!/usr/bin/env python3
"""Reproducible read-only Perf-HAL source/ROM audit; no build or installation.

Exit 0 means the audit completed and its pinned evidence matched. It never
means that the source patch is suitable for the device or that CASS boosts
have been implemented. A ROM byte audit is optional and explicitly labelled.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import struct

HERE=Path(__file__).resolve().parent
ROM_SHA='dd7ba8fbbde15cb7b74b1b951623b232c22eb9a70a6c8bbe7002fb775115bddf'
ROM_SIZE=264168

def elf_sections(data):
    assert data[:6] == b'\x7fELF\x02\x01', 'Expected little-endian ELF64'
    assert struct.unpack_from('<H',data,18)[0] == 183, 'Expected AArch64'
    offset=struct.unpack_from('<Q',data,40)[0]
    size,count,names_index=struct.unpack_from('<HHH',data,58)
    headers=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*size) for i in range(count)]
    h=headers[names_index];names=data[h[4]:h[4]+h[5]]
    return {names[h[0]:].split(b'\0',1)[0].decode():h for h in headers}

def audit_rom(path):
    data=path.read_bytes()
    assert len(data)==ROM_SIZE and hashlib.sha256(data).hexdigest()==ROM_SHA, 'Unknown ROM bytes; fixed offsets must not be reused'
    sections=elf_sections(data)
    def section(name):
        h=sections[name];return data[h[4]:h[4]+h[5]]
    def instruction(address):
        for h in sections.values():
            if h[1] != 8 and h[3]<=address and address+4<=h[3]+h[5]:
                return struct.unpack_from('<I',data,h[4]+address-h[3])[0]
        raise ValueError(hex(address))
    strings=section('.dynstr');dynamic=section('.dynamic')
    needed=[]
    for i in range(0,len(dynamic),16):
        tag,value=struct.unpack_from('<qQ',dynamic,i)
        if tag==1:needed.append(strings[value:].split(b'\0',1)[0].decode())
    assert 'libhidlbase.so' in needed and 'vendor.qti.hardware.perf@2.0.so' in needed
    assert 'vendor.qti.memory.pasrmanager@1.1.so' in needed
    assert 'libbinder_ndk.so' not in needed
    # Source-layout comparison: the real sched_boost release loads value at
    # Resource+12 and qindex at Resource+10. It also negates the value.
    checkpoints={0x1d97c:0xb9400c08,0x1d980:0x6b0803e4,0x1d988:0x79401414}
    for address,expected in checkpoints.items():assert instruction(address)==expected
    return {'status':'PINNED_BYTES_VERIFIED','sha256':ROM_SHA,'bytes':ROM_SIZE,
            'needed_libraries':needed,'resource_qindex_offset':10,'resource_value_offset':12,
            'instruction_words':{hex(k):hex(v) for k,v in checkpoints.items()},
            'loaded_or_executed':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-dir',type=Path,default=HERE/'reference')
    parser.add_argument('--manifest',type=Path,default=HERE/'PRIMARY_BUILD_FILES.json')
    parser.add_argument('--rom-library',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    manifest=json.loads(args.manifest.read_text())
    assert manifest['commit']=='d1a994bb35bc685700c1bbfabae9bed43500899e'
    verified=[]
    for item in manifest['files']:
        name=Path(item['path']);assert not name.is_absolute() and '..' not in name.parts
        data=(args.reference_dir/name).read_bytes()
        assert hashlib.sha256(data).hexdigest()==item['sha256'],name
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        assert blob==item['git_blob_sha1'],name
        verified.append({'path':str(name),'bytes':len(data),'sha256':item['sha256']})
    perf=(args.reference_dir/'perflocks/Android.bp').read_text()
    service=(args.reference_dir/'service/Android.bp').read_text()
    resource=(args.reference_dir/'perflocks/ResourceInfo.h').read_text()
    target=(args.reference_dir/'perflocks/Target.cpp').read_text()
    assert 'vendor.qti.hardware.perf2-V1-ndk' in perf and 'libbinder_ndk' in perf
    assert 'vendor.qti.memory.pasrmanager-V1-ndk' in perf
    assert 'vendor.qti.hardware.perf2-hal-service' in service
    assert 'typedef struct resource {' in resource and '}Resource;' in resource
    assert 'mResourceSupported[major] &= ~(1 << minor);' in target
    result={'audit_status':'COMPLETE','source_repository':manifest['repository'],
      'source_commit':manifest['commit'],'reference_files':verified,
      'android_buildfiles_exist':True,'source_service':'vendor.qti.hardware.perf2-hal-service',
      'source_performance_interface':'vendor.qti.hardware.perf2-V1-ndk',
      'source_pasr_interface':'vendor.qti.memory.pasrmanager-V1-ndk',
      'recorded_device_service':'vendor.qti.hardware.perf@2.2-service',
      'recorded_rom_sha256':ROM_SHA,
      'source_resource_typedef':'Resource is an alias for struct resource; name case is not an ABI difference',
      'source_bitmap_width_bug_present':True,
      'rom_binary_audit':audit_rom(args.rom_library) if args.rom_library else {'status':'NOT_RUN; no ROM library supplied'},
      'production_hal_replacement':'NOT_VERIFIED_SERVICE_ABI_AND_LAYOUT_DIFFER',
      'source_patch_review_only':True,'performance_payload_applied_to_kernel':False,
      'kernel_build_should_depend_on_new_hal':False,
      'outstanding_work':['matching Android HIDL build basis and dependency compatibility',
        'XML/hardware support intersection before requests without a second consuming getter pass',
        'separate reset and earlier initialization paths',
        'CASS-native functional profile values and device validation']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'audit_status':result['audit_status'],'source_files_verified':len(verified),
                      'rom_binary_audit':result['rom_binary_audit']['status'],
                      'production_hal_replacement':result['production_hal_replacement'],
                      'output':str(args.output)},indent=2))

if __name__=='__main__':main()
