
#include <array>
#include <bitset>
#include <cassert>
#include <cstdint>
#include <iostream>
#define MAX_MAJOR_RESOURCES 4
struct ResourceInfo {
    static uint16_t GetMinorIndex(uint16_t major) {
        static constexpr uint16_t count[4] = {0,17,62,64};
        assert(major < MAX_MAJOR_RESOURCES);
        return count[major];
    }
};
struct Target {
    std::array<uint64_t,4> mResourceSupported;
    bool isResourceSupported(uint16_t,uint16_t);
    void mResetResourceSupported(uint16_t,uint16_t);
};

bool Target::isResourceSupported(uint16_t major, uint16_t minor) {
    if (major >= MAX_MAJOR_RESOURCES || minor >= 64 ||
            minor >= ResourceInfo::GetMinorIndex(major)) {
        return false;
    }

    return (mResourceSupported[major] & (uint64_t(1) << minor)) != 0;
}
void Target::mResetResourceSupported(uint16_t major, uint16_t minor) {
    if (major >= MAX_MAJOR_RESOURCES || minor >= 64 ||
            minor >= ResourceInfo::GetMinorIndex(major)) {
        return;
    }

    mResourceSupported[major] &= ~(uint64_t(1) << minor);
}

int main() {
    unsigned cases = 0;
    for (uint16_t major=0; major<MAX_MAJOR_RESOURCES; ++major) {
        for (uint16_t bit=0; bit<64; ++bit) {
            for (uint64_t pattern : {UINT64_MAX, UINT64_C(0),
                                    UINT64_C(0xAAAAAAAAAAAAAAAA),
                                    UINT64_C(0x5555555555555555)}) {
                Target t{{UINT64_C(0x1020304050607080), UINT64_C(0xfedcba9876543210),
                          UINT64_C(0x123456789abcdef0), UINT64_C(0xff00ff00ff00ff00)}};
                t.mResourceSupported[major] = pattern;
                const auto before = t.mResourceSupported;
                std::bitset<64> expected(pattern);
                if (bit < ResourceInfo::GetMinorIndex(major)) expected.reset(bit);
                t.mResetResourceSupported(major,bit);
                assert(t.mResourceSupported[major] == expected.to_ullong());
                for (uint16_t other=0;other<MAX_MAJOR_RESOURCES;++other)
                    if (other != major) assert(t.mResourceSupported[other] == before[other]);
                for (uint16_t probe=0;probe<64;++probe) {
                    const bool wanted = probe < ResourceInfo::GetMinorIndex(major) && expected[probe];
                    assert(t.isResourceSupported(major,probe) == wanted);
                }
                ++cases;
            }
        }
    }
    for (uint16_t major : {uint16_t(0),uint16_t(1),uint16_t(2),uint16_t(3),
                          uint16_t(4),uint16_t(65535)}) {
        for (uint16_t minor : {uint16_t(64),uint16_t(65),uint16_t(65535)}) {
            Target t{{UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX}};
            const auto before=t.mResourceSupported;
            t.mResetResourceSupported(major,minor);
            assert(t.mResourceSupported == before);
            assert(!t.isResourceSupported(major,minor));
            ++cases;
        }
    }
    for (uint16_t major : {uint16_t(4),uint16_t(65535)}) {
        Target t{{UINT64_MAX,UINT64_MAX,UINT64_MAX,UINT64_MAX}};
        const auto before=t.mResourceSupported;
        t.mResetResourceSupported(major,0);
        assert(t.mResourceSupported == before && !t.isResourceSupported(major,0));
        ++cases;
    }
    std::cout << "CASES=" << cases << "\n";
}
