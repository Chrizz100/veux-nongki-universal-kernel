#include <cstdint>
#include <cstddef>
#include <cstdio>
typedef struct resource {
    uint32_t opcode;
    uint8_t version;
    uint16_t major;
    uint16_t minor;
    uint32_t mapping;
    int8_t cluster;
    int8_t core;
    uint16_t qindex;
    union {
        uint32_t value;
        uint32_t level;
    };
}Resource;
int main(){std::printf("%zu %zu %zu\n",offsetof(Resource,qindex),offsetof(Resource,value),sizeof(Resource));}
