#!/usr/bin/env python3
"""Independently compare the new YAML to the authenticated successful R4 workflow."""
from copy import deepcopy
from pathlib import Path
import argparse,hashlib,json,zipfile,yaml
ROOT=Path('/workspace/scratch/8060ea03935b')
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--reference',type=Path,
                    default=ROOT/'work_cass_r4_ci_fix/evidence/RUN_40704046049_WORKFLOW.yml',
                    help='Authenticated successful R4 workflow YAML')
parser.add_argument('--workflow',type=Path,
                    default=ROOT/'work_r9_reproducible_build/delivery/VEUX_R5_CASS_REPRODUCIBLE_BUILD_R1.yml',
                    help='New workflow YAML; its paired MAIN ZIP must be in the same directory')
parser.add_argument('--out',type=Path,
                    default=ROOT/'work_r9_reproducible_build/agents/provenance/WORKFLOW_PRESERVATION_REVIEW.json',
                    help='JSON review output')
args=parser.parse_args()
BASE=args.reference.resolve(strict=True)
NEW=args.workflow.resolve(strict=True)
OUT=args.out.resolve()
def sha(data):return hashlib.sha256(data).hexdigest()
def need(ok,message):
 if not ok:raise AssertionError(message)
old=yaml.safe_load(BASE.read_text());new=yaml.safe_load(NEW.read_text())
need(sha(BASE.read_bytes())=='f0ef66f6dd679e7d233e0bfdd363af7879aea3f2ca04fd2a13607f39303c07ec','reference identity')
a=old['jobs']['r5s2_bakasu_522'];b=new['jobs']['r5s2_bakasu_522']
need(a['if']==b['if'] and a['runs-on']==b['runs-on'] and a['timeout-minutes']==b['timeout-minutes'],'job guard/runner/timeout changed')
need(new['permissions']=={'contents':'read'},'unexpected write permissions')
need(set(new['on'])=={'workflow_dispatch'},'unexpected trigger')
need(new['on']['workflow_dispatch']['inputs']['enable_build']['default'] is True,'default native build disabled')
need(all(new['env'][k]==v for k,v in old['env'].items()),'historical input/env pin changed')
need(len(b['steps'])==38,'unexpected stage count')
byname={s['name']:s for s in b['steps']};need(len(byname)==len(b['steps']),'duplicate step name')
rows=[]
for i,orig in enumerate(a['steps']):
 expected=deepcopy(orig);changes=[]
 if i in [4,9]:
  expected['run']=expected['run'].replace('R55H17_R4_CASS_UPDATE_BUILD_NOFLASH.yml','VEUX_R5_CASS_REPRODUCIBLE_BUILD_R1.yml');changes.append('self-lint filename only')
 if i==8:
  expected['name']='Install documented build dependencies and pinned Python packages'
  expected['run']=expected['run'].replace('bc binutils bison','bc binutils binutils-aarch64-linux-gnu bison').replace('perl python3','openssl perl python3')
  changes.append('dependency stage renamed; added binutils-aarch64-linux-gnu and openssl only')
 if expected.get('uses','').startswith('actions/upload-artifact@'):
  expected['with']['name']+='-${{ github.run_attempt }}';changes.append('attempt suffix prevents artifact name collisions')
 if i==23:
  expected['if']="${{ always() && steps.r4_verify.conclusion == 'success' && steps.r9_repo_unchanged.conclusion == 'success' }}";changes.append('historical raw preserved after its own successful gate and successful repository guard')
 if i==24:
  expected['id']='r9_repo_unchanged';changes.append('repository guard id added; same Bash before uploads')
 actual=byname.get(expected['name'])
 # Only these two known trailing echo spaces are harmless formatting cleanup.
 # Do not normalize arbitrary whitespace, heredocs, or continuation lines.
 if i in (1,7) and actual is not None and actual != expected:
  exact_line = ("echo 'R5S2_AND_TRUE_VERSION_ARCHIVE_HASHES=PASS' \n" if i == 1
                else "echo 'R5S2_HISTORICAL_AND_REAL_GIT_VERSION_TESTS=PASS' \n")
  normalized = deepcopy(expected)
  normalized['run'] = expected['run'].replace(exact_line, exact_line[:-2] + '\n')
  if actual == normalized:
   expected = normalized
   changes.append('one harmless trailing space after final echo quote removed for literal YAML block')
 need(actual==expected,'unreviewed change in original step '+str(i+1)+': '+orig['name'])
 rows.append({'old_index':i+1,'new_index':b['steps'].index(actual)+1,'name':actual['name'],'exact_original_step':not changes,'reviewed_changes':changes,'run_sha256':sha(actual['run'].encode()) if 'run'in actual else None})
# Preserve ordering of all core compilation/source/validation stages before extension.
core=[r for r in rows if r['old_index']<=19]
need([r['new_index'] for r in core]==sorted(r['new_index'] for r in core),'core stage reorder')
fresh_i=next(i for i,s in enumerate(b['steps']) if s.get('id')=='r9_fresh_rmnet')
r4_i=next(i for i,s in enumerate(b['steps']) if s.get('id')=='r4_verify')
need(fresh_i>r4_i,'fresh modules before validated candidate')
need('--stage "$RUNNER_TEMP/veux-r55h17-r4"' in b['steps'][fresh_i]['run'] and '--evidence-mode ci' in b['steps'][fresh_i]['run'],'wrong module candidate inputs')
archive=NEW.parent/new['env']['REPRO_PACKAGE'];need(sha(archive.read_bytes())==new['env']['REPRO_ARCHIVE_SHA256'],'new archive SHA mismatch')
with zipfile.ZipFile(archive) as z:
 raw=z.read('PAYLOAD_MANIFEST.json');need(sha(raw)==new['env']['REPRO_MANIFEST_SHA256'],'new manifest SHA mismatch')
 manifest=json.loads(raw)
 need(len(z.namelist())==len(set(z.namelist())),'duplicate ZIP member')
 need(set(z.namelist())==set(manifest['files'])|{'PAYLOAD_MANIFEST.json'},'missing/extra member')
 for name,digest in manifest['files'].items():need(sha(z.read(name))==digest,'payload member SHA '+name)
 for name,expected in [(old['env']['R5S2_MAIN_ZIP'],old['env']['R5S2_MAIN_SHA256']),(old['env']['VERSION_MAIN_ZIP'],old['env']['VERSION_MAIN_SHA256']),(old['env']['R4_PACKAGE_NAME'],new['env']['R4_ARCHIVE_SHA256'])]:
  need(sha(z.read('reference/root_inputs/'+name))==expected,'backup source archive mismatch')
 need(sha(z.read('reference/RUN_40704046049_WORKFLOW.yml'))==sha(BASE.read_bytes()),'embedded reference changed')
report={'status':'REFERENCE_SEMANTICS_PASS_AT_REVIEWED_HASH','snapshot_review_only':True,'final_delivery_green_pass':False,'scope':'Historical build-stage preservation, input/archive/env pins, source/compile ordering and selected path/condition checks','reviewed_workflow':str(NEW),'workflow_sha256':sha(NEW.read_bytes()),'reference_workflow_sha256':sha(BASE.read_bytes()),'original_stages':len(rows),'new_stages':len(b['steps']),'added_stages':len(b['steps'])-len(rows),'exact_original_steps':sum(r['exact_original_step'] for r in rows),'original_core_order_preserved':True,'historical_env_pins_preserved':True,'root_archives_in_backup_byte_identical':True,'authenticated_payload_files':len(manifest['files']),'archive_sha256':new['env']['REPRO_ARCHIVE_SHA256'],'manifest_sha256':new['env']['REPRO_MANIFEST_SHA256'],'steps':rows,'blocking_findings':[],'not_claimed':['Approval of any future or final artifact hash','Execution of new full GitHub workflow','New full kernel compilation in this review','New device boot test'],'other_reviewers':['New raw/boot terminal gates and private-input handling reviewed separately'],'observations':['Historical raw export condition deliberately changed and repository guard moved before artifact uploads; not merely an artifact-name change. Both were verified explicitly.','Two known trailing echo spaces may be normalized for readability; no arbitrary script whitespace normalization accepted.']}
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='steps'},indent=2,ensure_ascii=False))
