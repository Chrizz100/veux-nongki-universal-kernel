#!/usr/bin/env python3
"""Read-only checks of actual local module bytes without importing pipeline parser."""
from pathlib import Path
import gzip,hashlib,json,re,struct
ROOT=Path('/workspace/scratch/8060ea03935b')
INPUT=ROOT/'work_r9_reproducible_build/local_fresh_inputs'
STAGE=ROOT/'work_cass_r4/native_r2'
OUT=ROOT/'work_r9_reproducible_build/agents/provenance/FRESH_EXTERNAL_MODULE_REVIEW.json'
def digest(data): return hashlib.sha256(data).hexdigest()
def check(ok,message):
 if not ok:raise AssertionError(message)
def section(file,name):
 with Path(file).open('rb') as f:
  header=f.read(64)
  check(header[:7]==b'\x7fELF\x02\x01\x01','not LE ELF64')
  typ,machine,_,_,_,off,_,_,_,_,size,count,strings=struct.unpack_from('<HHIQQQIHHHHHH',header,16)
  check(size==64 and 0<strings<count and count<65535,'bad section table')
  f.seek(off);table=f.read(size*count)
  rows=[struct.unpack_from('<IIQQQQIIQQ',table,i*64) for i in range(count)]
  names=rows[strings];f.seek(names[4]);text=f.read(names[5])
  found=[]
  for row in rows:
   start=row[0];end=text.find(b'\0',start)
   check(0<=start<len(text) and end>=start,'bad section name')
   if text[start:end].decode('ascii')==name:
    check(row[1]!=8,'section is NOBITS');f.seek(row[4]);found.append(f.read(row[5]))
  check(len(found)==1,'section missing/duplicate '+name)
  return typ,machine,found[0]
receipt=json.loads((INPUT/'BUILD_OUTPUTS.json').read_text())
for name,row in receipt['files'].items():
 data=(INPUT/name).read_bytes();check(digest(data)==row['sha256'] and len(data)==row['bytes'],'receipt file '+name)
image=(INPUT/'Image').read_bytes();config=(INPUT/'actual-build.config').read_bytes()
check(image[56:60]==b'ARM\x64','image ARM64')
a=image.index(b'IKCFG_ST')+8;b=image.index(b'IKCFG_ED',a)
check(gzip.decompress(image[a:b])==config,'embedded config')
exports={}
for line in (INPUT/'Module.symvers').read_text().splitlines():
 fields=line.split();check(len(fields)>=4 and fields[2]=='vmlinux','unexpected export module')
 check(fields[1] not in exports,'duplicate export');exports[fields[1]]=int(fields[0],16)
addresses={}
for line in (INPUT/'System.map').read_text().splitlines():
 fields=line.split()
 if len(fields)==3 and fields[2] in ['_text','__start_notes','__stop_notes']:
  check(fields[2] not in addresses,'duplicate note addr');addresses[fields[2]]=int(fields[0],16)
start=addresses['__start_notes']-addresses['_text'];stop=addresses['__stop_notes']-addresses['_text']
check(0<=start<stop<=len(image),'notes bounds');notes=image[start:stop]
check(section(STAGE/'build/vmlinux','.notes')[2]==notes,'Image/vmlinux notes')
report={'status':'PASS','reviewer':'independent ELF/receipt/log byte checks; pipeline parser not imported','kernel_notes_sha256':digest(notes),'kernel_image_sha256':digest(image),'embedded_config_matches':True,'image_vmlinux_notes_match':True,'new_full_kernel_compile_claimed':False,'kernel_reference':'Existing local native_r2 output, not original GitHub CI bytes','modules':{}}
for name,expected_count,oldhash in [('rmnet_offload',32,'a391f7991f96da6d0f0ccd567e7f410e75ddf69fe43d62bfda6c7b88d34da724'),('rmnet_shs',100,'ce30767b130fb0ddc2daffecf0d2379f12959450921d35ef3370097b2b04fd99')]:
 p=INPUT/(name+'.ko');typ,mach,versions=section(p,'__versions')
 check(typ==1 and mach==183,'module AArch64 relocatable')
 check(len(versions)==expected_count*64,'version entry count')
 imports={}
 for offset in range(0,len(versions),64):
  crc=struct.unpack_from('<Q',versions,offset)[0]
  raw=versions[offset+8:offset+64];symbol,padding=raw.split(b'\0',1);symbol=symbol.decode('ascii')
  check(not any(padding) and symbol not in imports,'invalid CRC entry')
  check(exports.get(symbol)==crc,'mismatching CRC '+symbol);imports[symbol]=crc
 fields={}
 for entry in section(p,'.modinfo')[2].split(b'\0'):
  if b'=' in entry:
   key,value=entry.decode().split('=',1);fields.setdefault(key,[]).append(value)
 expected=receipt['kernel_release']+' SMP preempt mod_unload modversions aarch64'
 check(fields.get('name')==[name] and fields.get('vermagic')==[expected],'modinfo')
 note=section(p,'.note.gnu.build-id')[2];check(note[12:16]==b'GNU\0','GNU buildnote')
 row=receipt['provenance']['external_module_builds'][name]
 log=(INPUT/'logs'/(name+'-compile.log')).read_bytes();clean=(INPUT/'logs'/(name+'-clean.log')).read_bytes()
 check(digest(log)==row['log_sha256'] and digest(clean)==row['clean']['log_sha256'],'log hash')
 check(json.loads(log.decode().splitlines()[0].removeprefix('COMMAND='))==row['command'],'recorded command')
 check(row['command'][0]=='/usr/bin/make' and row['command'][-1]=='modules','actual make command')
 check(b'  LD [M]' in log and b'  LTO [M]' in log,'real module linking log')
 ccount=0
 source=Path(row['output_path']).parent
 for fname,source_hash in row['source_files_sha256'].items():
  check(digest((source/fname).read_bytes())==source_hash,'source hash changed')
  if fname.endswith('.c'):
   ccount+=1;obj=Path(fname).with_suffix('.o').name
   check(any(b'CC [M]' in line and line.endswith(obj.encode()) for line in log.splitlines()),'missing real compile '+fname)
   cmd=(source/('.'+obj+'.cmd')).read_text()
   check(all(flag in cmd for flag in ['-fsanitize=cfi','-flto=thin','-fstack-protector-strong']),'missing flags')
 check(digest(p.read_bytes())!=oldhash,'old reference module passed as fresh')
 report['modules'][name]={'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size,'version_imports_matched':len(imports),'build_note_sha256':digest(note),'compiled_c_units':ccount,'native_compile_log_checked':True,'compiled_flags_checked':True,'not_old_reference_module':True,'module_layout_crc':hex(imports['module_layout'])}
report['pipeline_script_sha256']=digest((ROOT/'work_r9_reproducible_build/payload/pipeline/build_external_rmnet.py').read_bytes())
OUT.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
