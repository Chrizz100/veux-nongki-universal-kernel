"""Measure real destination runqueue lock words on normal migrations in an eight-vCPU guest."""
import json
from pathlib import Path
import re
import socket
import subprocess
import sys
import tempfile
import time
import zipfile

from fruehstart import MACHINE, STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot
from pstore_stock import device_tree, nodes, signed_regions
from probe_epss import BASE, model_tree, registers, stock_domains
from runqueue import R4_BOOT, R4_IMAGE

HERE = Path(__file__).resolve().parent
MARKER = b'VEUX_RUNQUEUE_PID1_DONE'
OOPS = (b'Internal error: Oops', b'kernel BUG at', b'Kernel panic - not syncing')


def run(label, path, boot, spec, root, work, dest, machine):
    negative = label == 'M63-R4'
    kernel = root / (label + '.Image')
    expected = {'Xiaomi': (STOCK_BOOT, STOCK_IMAGE), 'M63-R4': (R4_BOOT, R4_IMAGE),
                'M63-R5': (None, spec['image_sha256'])}
    kernel.write_bytes(unpack_boot(boot, *expected[label]))
    require(digest(kernel.read_bytes()) == spec['image_sha256'], 'Static and live inputs differ')
    tag = label + '-' + path
    uart = dest / (tag + '-Sperren-UART.log')
    log = dest / (tag + '-Sperren-LLDB.log')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        port = probe.getsockname()[1]
    pidfile = root / (tag + '.pid')
    command = machine + ['-kernel', str(kernel), '-S', '-pidfile', str(pidfile),
                         '-gdb', f'tcp:127.0.0.1:{port}']
    pcs = [int(a, 16) for a in spec['migration_pc'][path]]
    symbols = spec['kernel_symbols']
    lines = ['settings set target.default-arch aarch64',
             'target create --arch aarch64 ' + json.dumps(str(root / 'pid1.elf')),
             'command script import ' + json.dumps(str(HERE / 'lock_sample.py')),
             f'gdb-remote 127.0.0.1:{port}']
    for addr in pcs:
        lines.append(f'breakpoint set --hardware --address {addr:#x}')
    # A stop at the WALT diagnostic must never be mistaken for a migration sample.
    lines.append('breakpoint set --hardware --address ' + spec['walt_guard_pc'])
    for _ in range(1 if negative else 3):
        lines += ['continue', f"script lock_sample.sample({pcs!r}, {symbols['__per_cpu_offset']}, {symbols['runqueues']})"]
    lines += ['process detach', 'quit']
    script = root / (tag + '.lldb')
    script.write_text('\n'.join(lines) + '\n')
    with uart.open('wb') as serial, subprocess.Popen(command, stdout=serial, stderr=subprocess.STDOUT) as guest:
        try:
            until = time.monotonic() + 15
            while not pidfile.exists() and guest.poll() is None and time.monotonic() < until:
                time.sleep(.05)
            require(pidfile.exists(), 'QEMU debugger unavailable: ' + str(uart))
            with log.open('wb') as output:
                subprocess.run([work / 'clang/bin/lldb.sh', '--batch', '-s', script],
                               stdout=output, stderr=subprocess.STDOUT, timeout=150, check=True)
            rows = [json.loads(m) for m in re.findall(r'^VEUX_LOCK (.+)$', log.read_text(), re.M)]
            require(len(rows) == (1 if negative else 3), 'Incomplete LLDB measurements: ' + str(log))
            if not negative:
                require(all(row['locked_byte'] == 1 for row in rows), 'R5/stock destination unlocked: ' + str(log))
                guest.wait(timeout=100)
                require(guest.returncode == 0 and MARKER in uart.read_bytes() and
                        all(word not in uart.read_bytes() for word in OOPS), 'Guest workload: ' + str(uart))
        finally:
            if guest.poll() is None:
                guest.terminate()
                try:
                    guest.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    guest.kill()
                    guest.wait()
    return dict(image_sha256=spec['image_sha256'], samples=rows, userspace_marker=MARKER in uart.read_bytes(),
                oops_observed=any(word in uart.read_bytes() for word in OOPS))


def main(work, dest):
    dest.mkdir(parents=True, exist_ok=True)
    contracts = json.loads((dest / 'Runqueue.json').read_text())
    inputs = {'Xiaomi': work / 'boot.img', 'M63-R4': work / 'M63-R4-Kontrolle.img',
              'M63-R5': work / 'pair/VEUX_M63-R5_boot_NOFLASH.img'}
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        groups = stock_domains(nodes(device_tree(signed_regions(root))))
        base = ['qemu-system-aarch64', '-no-user-config', '-nodefaults', '-cpu', 'cortex-a55',
                '-smp', '8', '-m', '1024M', '-accel', 'tcg', '-display', 'none', '-monitor', 'none', '-nic', 'none']
        dtb = model_tree(base, work / 'out/scripts/dtc/dtc', root, groups)
        bank = root / 'epss.bin'
        bank.write_bytes(registers(groups))
        subprocess.run([work / 'clang/bin/clang', '--target=aarch64-linux-gnu', '-fuse-ld=lld', '-static',
                        '-nostdlib', '-Wl,-e,_start', '-o', root / 'pid1.elf', HERE / 'pid1.S'], check=True)
        subprocess.run([work / 'clang/bin/clang', '--target=aarch64-linux-gnu', '-fuse-ld=lld', '-static',
                        '-nostdlib', '-Wl,-e,_start', '-I', work / 'out/usr/include',
                        '-o', root / 'affinity', HERE / 'affinity.S'], check=True)
        with zipfile.ZipFile(HERE.parent / 'ak3-tools.zip') as bundle:
            (root / 'busybox').write_bytes(bundle.read('tools/busybox'))
        items = root / 'cpio.list'
        items.write_text('dir /bin 0755 0 0\ndir /dev 0755 0 0\ndir /proc 0755 0 0\n'
                         'nod /dev/console 0600 0 0 c 5 1\nnod /dev/null 0666 0 0 c 1 3\n' +
                         f'file /bin/affinity {root}/affinity 0755 0 0\nfile /bin/busybox {root}/busybox 0755 0 0\nfile /init {HERE}/lock-init.sh 0755 0 0\n')
        with (root / 'initrd').open('wb') as out:
            subprocess.run([work / 'out/usr/gen_init_cpio', items], stdout=out, check=True)
        machine = base + ['-machine', MACHINE, '-serial', 'stdio', '-no-reboot', '-seed', '1',
                          '-dtb', str(dtb), '-device', f'loader,file={bank},addr={BASE:#x},force-raw=on',
                          '-initrd', str(root / 'initrd'),
                          '-append', 'console=ttyAMA0 earlycon=pl011,0x09000000 nokaslr rdinit=/init mem=896M panic=-1']
        results = {label: {path: run(label, path, boot, contracts[label], root, work, dest, machine)
                           for path in ('detach_task', 'move_queued_task')} for label, boot in inputs.items()}
    # R4's code demonstrably omits locking. Another CPU may transiently hold its lock at a sample.
    # Record the observed word without making a timing-dependent R4 value a CI requirement.
    result = dict(model='QEMU virt-8.2, 8 Cortex-A55, Xiaomi 6+2 CPU domains', images=results,
                  device_pass=False, flash_allowed=False)
    (dest / 'Sperren-LLDB.json').write_text(json.dumps(result, indent=2) + '\n')
    print('PASS two scheduler paths measured independently on Xiaomi, R4 and R5')


if __name__ == '__main__':
    main(*(Path(arg).resolve() for arg in sys.argv[1:]))
