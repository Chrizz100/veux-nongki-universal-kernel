"""Compare the actual ARM64 scheduler instructions in Xiaomi, failed R4 and the packaged R5."""
import json
from pathlib import Path
import sys
import tempfile

from fruehstart import STOCK_BOOT, STOCK_IMAGE, digest, require, unpack_boot

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'tools'))
from memory_image import Code, mapped_symbols, stock_symbols

R4_BOOT = '2324ea62288882716d48ee3d8f2590652e1912b214e4a675eb8624026223eed2'
R4_IMAGE = 'eb44786ada6c9d3b71ff3fa564f94c310e00908dbefd837c3162850b28a105bc'
BASE = 0xffffffc010080000


def direct_sites(body, address):
    return [i for i, (_, op, arg) in enumerate(body)
            if op in ('b', 'bl') and arg.startswith('0x') and int(arg, 16) == address]


def inspect(image, symbols, compiler, tmp, broken):
    code = Code(image, symbols, compiler, tmp)
    active = code.instructions('active_load_balance_cpu_stop')
    passive = code.instructions('detach_tasks')
    guard = code.instructions('update_task_rq_cpu_cycles')
    dumps = direct_sites(guard, code.names['walt_dump'])
    require(len(dumps) == 1 and guard[dumps[0] + 1][1] == 'brk', 'WALT time accounting diagnostic')
    if broken:
        body = active
        remove = direct_sites(body, code.names['deactivate_task'])
        move = direct_sites(body, code.names['set_task_cpu'])
        require(len(remove) == len(move) == 2, 'Expected both R4 migration sites')
        for start, end in zip(remove, move):
            require(start < end and all(op in ('ldr', 'mov') for _, op, _ in body[start + 1:end]),
                    'R4 must exhibit the original unguarded migration')
        take = direct_sites(passive, code.names['deactivate_task'])
        shift = direct_sites(passive, code.names['set_task_cpu'])
        require(len(take) == len(shift) == 1 and take[0] < shift[0] and
                all(op in ('ldr', 'mov') for _, op, _ in passive[take[0] + 1:shift[0]]),
                'Original R4 passive load balancing')
        fair_pcs = [body[i][0] for i in move] + [passive[shift[0]][0]]
        sequence = 'three inline fair migration sites without target lock'
    else:
        detach = code.names.get('detach_task')
        require(detach is not None and len(direct_sites(active, detach)) == 2 and
                not direct_sites(active, code.names['set_task_cpu']) and
                len(direct_sites(passive, detach)) == 1 and not direct_sites(passive, code.names['set_task_cpu']),
                'Active and passive load balancing must use detach_task')
        body = code.instructions('detach_task')
        remove = direct_sites(body, code.names['deactivate_task'])
        lock = direct_sites(body, code.names['_raw_spin_lock'])
        clock = direct_sites(body, code.names['update_rq_clock'])
        move = direct_sites(body, code.names['set_task_cpu'])
        unlock = direct_sites(body, code.names['_raw_spin_unlock'])
        require(len(remove) == len(clock) == len(move) == 1 and len(lock) >= 2 and
                len(unlock) == 2 and remove[0] < unlock[0] < min(lock) and
                max(lock) < clock[0] < move[0] < unlock[1], 'Missing Xiaomi double-runqueue sequence')
        require(any(op in ('tbz', 'tbnz') for _, op, _ in body[min(lock):clock[0]]),
                'Conditional runqueue clock update')
        fair_pcs = [body[i][0] for i in move]
        sequence = 'three call sites use detach_task with locks, clock check, migration and unlock'
    queued = code.instructions('move_queued_task')
    take = direct_sites(queued, code.names['dequeue_task'])
    switch = direct_sites(queued, code.names['set_task_cpu'])
    put = direct_sites(queued, code.names['enqueue_task'])
    require(len(take) == len(switch) == len(put) == 1 and take[0] < switch[0] < put[0],
            'Queued task dequeue, migration and enqueue')
    around = queued[take[0] + 1:switch[0]]
    after = queued[switch[0] + 1:put[0]]
    if broken:
        require(all(op in ('ldr', 'mov') for _, op, _ in around), 'Original R4 queued migration')
    else:
        locks = direct_sites(around, code.names['_raw_spin_lock'])
        unlocks = direct_sites(after, code.names['_raw_spin_unlock'])
        relock = direct_sites(after, code.names['_raw_spin_lock'])
        require(len(locks) >= 2 and len(unlocks) == 2 and len(relock) == 1 and max(unlocks) < relock[0],
                'move_queued_task must lock both queues, unlock both and relock destination')
        clocks = direct_sites(around, code.names['update_rq_clock'])
        if not clocks:
            clocks = direct_sites(around, code.names['update_rq_clock_task'])
            ticks = direct_sites(queued, code.names['sched_clock'])
            require(len(ticks) == len(clocks) == 1, 'Inlined rq clock update')
            # Clang may emit the static-key clock reader after the function exit and branch back.
            low, high = around[max(locks)][0], around[clocks[0]][0]
            cold_return = any(op.startswith('b.') and low < int(arg, 16) <= high
                              for _, op, arg in queued[ticks[0] + 1:ticks[0] + 8])
            require(low < queued[ticks[0]][0] < high or cold_return, 'Clock read before rq accounting')
        require(max(locks) < clocks[0], 'Queued-task clock must be refreshed after both locks')
    data = {name: hex(BASE + addr) for addr, kind, name in symbols
            if name in ('runqueues', '__per_cpu_offset') and kind.lower() in ('d', 'b')}
    require(len(data) == 2, 'Runqueue addresses for the debugger')
    return dict(image_sha256=digest(image), migration_pc={'detach_task': [hex(BASE + pc) for pc in fair_pcs],
                                  'move_queued_task': [hex(BASE + queued[switch[0]][0])]},
                walt_guard_pc=hex(BASE + guard[dumps[0] + 1][0]), kernel_symbols=data, sequence=sequence)


def main(work, dest):
    dest.mkdir(parents=True, exist_ok=True)
    stock = unpack_boot(work / 'boot.img', STOCK_BOOT, STOCK_IMAGE)
    r4 = unpack_boot(work / 'M63-R4-Kontrolle.img', R4_BOOT, R4_IMAGE)
    new = unpack_boot(work / 'pair/VEUX_M63-R5_boot_NOFLASH.img')
    require(new == (work / 'out/arch/arm64/boot/Image').read_bytes() and
            digest(new) not in (STOCK_IMAGE, R4_IMAGE), 'R5 boot kernel and Kbuild output')
    images = [('Xiaomi', stock, stock_symbols(stock)), ('M63-R4', r4, mapped_symbols(HERE / 'ref/M63-R4-Runqueue.map')),
              ('M63-R5', new, mapped_symbols(work / 'out/System.map'))]
    with tempfile.TemporaryDirectory() as temp:
        checks = {label: inspect(data, syms, work / 'clang/bin', Path(temp), label == 'M63-R4')
                  for label, data, syms in images}
    (dest / 'Runqueue.json').write_text(json.dumps(checks, indent=2) + '\n')
    print('PASS guarded active and queued migrations in Xiaomi and R5, all four original R4 call sites verified')


if __name__ == '__main__':
    main(*(Path(arg).resolve() for arg in sys.argv[1:]))
