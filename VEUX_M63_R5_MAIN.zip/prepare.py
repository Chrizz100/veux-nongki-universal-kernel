"""Rebuild the exact GitHub R4 source with the verified Xiaomi runqueue repair."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
SOURCE = '6f82f388690f84ba9c96a05fa54059ce46d4f6a63f50a151c144fee47e0f9d39'
TAR = '609ea929825a9675f9050874cd0c0d0f749649980898ddd119b1d2cc29810020'
CONFIG = 'c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54'
R4_IMAGE = 'eb44786ada6c9d3b71ff3fa564f94c310e00908dbefd837c3162850b28a105bc'
FAIR = Path('kernel/sched/fair.c')
BEFORE = '5795101e846d2111e8aef1db99ec1152c221ea3de93cf28491291455378f8ce8'
AFTER = '32087861ed374f6ea81d9d616f5fceb68f0331bb7e3d50f31a865233880166f9'
PATCH = 'f3cb5e64775bc982d038d7cbacc29ea772905c863f016f78002c625b6967ae7a'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, text):
    if not condition:
        raise ValueError(text)


def prepare(work, archive, stock):
    require(digest(archive) == SOURCE and digest(stock) == BOOT, 'R4 source archive and Xiaomi factory boot')
    patch = ROOT / 'walt-runqueue.patch'
    require(digest(patch) == PATCH, 'Runqueue patch SHA-256')
    work.mkdir(parents=True, exist_ok=True)
    src = work / 'src'
    src.mkdir()
    with tempfile.TemporaryDirectory(dir=work) as temp, zipfile.ZipFile(archive) as bundle:
        manifest = json.loads(bundle.read('M63-R4_KERNEL.json'))
        require(manifest['image_sha256'] == R4_IMAGE and manifest['config_sha256'] == CONFIG,
                'Original GitHub R4 metadata')
        config = bundle.read('kernel.config')
        require(hashlib.sha256(config).hexdigest() == CONFIG, 'Original R4 .config')
        require(bundle.read('kbuild-veux.sh') == (ROOT / 'tools/kbuild.sh').read_bytes(), 'Original build command')
        tar = Path(bundle.extract('M63-R4-kernel-source.tar.gz', temp))
        require(digest(tar) == TAR, 'Original R4 source tree')
        subprocess.run(['tar', '--no-same-owner', '--no-same-permissions', '-xzf', tar, '-C', src], check=True)
    require(digest(src / FAIR) == BEFORE, 'R4 fair.c before repair')
    subprocess.run(['git', 'apply', '--check', patch], cwd=src, check=True)
    subprocess.run(['git', 'apply', patch], cwd=src, check=True)
    require(digest(src / FAIR) == AFTER, 'Repaired fair.c')
    core = src / 'kernel/sched/core.c'
    move_patch = ROOT / 'walt-move-queued.patch'
    core_before = 'e86d9d1739f3d6b7877be46a731475c1f0e572d6a699b56994bab64523b0d8fb'
    core_after = 'c518a1135b5140227ff036da5535a98409600449b73fe734613c115b1091528d'
    require(digest(core) == core_before and digest(move_patch) == 'a173d869461679ec4123e8ebdd0da9822d3b28b9943023d6ee7d01b4359d38c5',
            'R4 move_queued_task source and patch')
    subprocess.run(['git', 'apply', '--check', move_patch], cwd=src, check=True)
    subprocess.run(['git', 'apply', move_patch], cwd=src, check=True)
    require(digest(core) == core_after, 'Repaired move_queued_task')
    (work / 'out').mkdir()
    (work / 'out/.config').write_bytes(config)
    (work / 'baseline.config').write_bytes(config)
    shutil.copyfile(stock, work / 'boot.img')
    proof = dict(github_run=45176581001, source_artifact_sha256=SOURCE, source_tar_sha256=TAR,
                 changed_files={FAIR.as_posix(): dict(before=BEFORE, after=AFTER, patch_sha256=PATCH),
                                'kernel/sched/core.c': dict(before=core_before, after=core_after,
                                                           patch_sha256=digest(move_patch))})
    reports = work / 'evidence/walt'
    reports.mkdir(parents=True, exist_ok=True)
    (reports / 'Quellstand.json').write_text(json.dumps(proof, indent=2) + '\n')


if __name__ == '__main__':
    prepare(*(Path(arg).resolve() for arg in sys.argv[1:]))
