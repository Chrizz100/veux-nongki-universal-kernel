"""Compare the candidate to the actual stock image, M62 and the original Xiaomi vendor modules."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import json
import mmap
import struct
import tempfile

from config_proof import autoconf_check, config_values, embedded, extract_config, require
from layout.boot import make_image, unpack_m45

ROOT = Path(__file__).resolve().parent
REL = '5.4.274-qgki-g82179e362f33'
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
STOCK_IMAGE = '6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
BASE_CONFIG = 'c2f76303e870e38f5b3c81c0c8e8b582a7e632a72bb379266585414abc8f5a54'
BASE_IMAGE = '39b3d5668e8c3117a6c5b8fcbb5e6f1c3b5e3de4890072b40f422a9fa4d040d0'
DTB = 'dd11f6da482e310d855c8818dba29d6818760e6fcc71f825b0f4fb775197ebae'
BOOTINFO = ['pureason', 'powerup_reason_details', 'unknown reboot', 'long_power_key', 'dm_verity_logging',
            'Powerup reason=', 'qpnp_pon_is_lpk', 'qpnp_pon_is_ps_hold_reset']
LEGACY = ['Write Booster Configured', 'ufstw\0', 'enable_tw\0', 'enable_flush_en\0', 'enable_autoflush_in_h8\0',
          'xiaomi,simtray-status\0', 'cpumaxfreq\0', 'dp_flag\0', 'androidboot.vbmeta.invalidate_on_error\0',
          'androidboot.vbmeta.device\0', 'AVB error handler called for', 'qcom,ufshc\0',
          'qcom,ufs-phy-qmp-v4-yupik\0', 'bq2589x: fault settings restore failed', 'Linux version ' + REL + ' (']

def sha(path):
    with path.open('rb') as src:
        h = hashlib.sha256()
        for chunk in iter(lambda: src.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def stock(path):
    require(sha(path) == BOOT, 'Xiaomi boot hash')
    raw = path.read_bytes()
    require(raw[:8] == b'ANDROID!' and struct.unpack_from('<I',raw,40)[0] in (3,4), 'Xiaomi boot header')
    kernel = raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    require(hashlib.sha256(kernel).hexdigest() == STOCK_IMAGE and all(s.encode() in kernel for s in BOOTINFO+['parent xattr is set','parent dir xattr set']), 'Xiaomi bootinfo evidence')
    return config_values(extract_config(kernel))

def configs(baseline, candidate, rom, result):
    require(sha(baseline)==sha(candidate)==BASE_CONFIG, 'Pinned and unchanged M62 build configuration')
    base=config_values(baseline.read_bytes())
    c=config_values(candidate.read_bytes())
    require(all(c[k]==rom[k]=='y' for k in ('CONFIG_SCHED_WALT','CONFIG_MIHW','CONFIG_MILLET')), 'Xiaomi WALT and Millet')
    require(base.get('CONFIG_MI_MEMORY_SYSFS') == rom.get('CONFIG_MI_MEMORY_SYSFS') == 'y', 'MI_MEMORY_SYSFS baseline and Stock')
    require(c.get('CONFIG_MIUI_ZRAM_MEMORY_TRACKING') == rom.get('CONFIG_MIUI_ZRAM_MEMORY_TRACKING') == 'y',
            'Stock zRAM tracking option')
    rest={k:(rom.get(k),c.get(k)) for k in sorted(rom.keys()|c.keys()) if rom.get(k)!=c.get(k)}
    require(len(rest)==45 and c['CONFIG_QGKI']==c['CONFIG_MMU']==c['CONFIG_QTI_CPU_ISOLATE_COOLING_DEVICE']=='y', 'Unexpected Stock comparison')
    require(c['CONFIG_F2FS_CP_OPT']=='y' and c['CONFIG_BPF_JIT']=='y', 'F2FS/BPF config')
    with (result/'Restkonfiguration.csv').open('w',newline='') as f:
        w=csv.writer(f,delimiter=';'); w.writerow(['Option','Xiaomi 5.4.274','M63-R5'])
        w.writerows((k,*v) for k,v in rest.items())

def final(a):
    out=a.out
    image=out/'arch/arm64/boot/Image'
    config=(out/'.config').read_bytes()
    require(sha(image)!=BASE_IMAGE and image.read_bytes()[56:60]==b'ARM\x64','Expected new ARM64 Image')
    require((out/'include/config/kernel.release').read_text().strip()==REL and
            (out/'include/generated/utsrelease.h').read_text().split('"')[1]==REL,'Kernel release')
    require(gzip.decompress((out/'kernel/config_data.gz').read_bytes())==config, 'Kbuild config_data')
    count=autoconf_check(config,(out/'include/generated/autoconf.h').read_text())
    for path in [image,out/'vmlinux']:
        require(embedded(path)==config,'IKCONFIG: '+path.name)
        with path.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
            for s in LEGACY+BOOTINFO+['parent xattr is set']:
                require(data.find(s.encode())>=0, 'Missing marker in '+path.name+': '+repr(s))
            require(data.find(b'LSE atomic instructions\0')<0,'LSE capability active in '+path.name)
    exports=(out/'Module.symvers').read_text().splitlines()
    for name in BOOTINFO[-2:]:
        require(any(row.split()[1:3]==[name,'vmlinux'] for row in exports),'Missing PMIC export: '+name)
    dt=out/'arch/arm64/boot/dts'
    require({p.relative_to(dt).as_posix():sha(p) for p in dt.rglob('*') if p.suffix in ('.dtb','.dtbo')}==
            {'vendor/xiaomi/veux.dtb':DTB},'VEUX DTB differs')
    module_names={p.relative_to(out).as_posix() for p in out.rglob('*.ko')}
    require(module_names=={'drivers/bluetooth/btpower.ko','drivers/bluetooth/bt_fm_slim.ko',
            'drivers/char/rdbg.ko','drivers/media/rc/ir-spi.ko'},'Built module set: '+str(module_names))
    for name in module_names:
        require(('vermagic='+REL+' ').encode() in (out/name).read_bytes(),'Module vermagic: '+name)
    from providers import run as check_providers
    vendor = check_providers(a.stock, image, out/'System.map', a.vendor, a.result/'M63-R5-Vendor.json', ROOT, out/'Module.symvers')
    table = [vendor['unique_imports'], vendor['imports'], vendor['modules']]
    require(vendor['passed'] and table == [1423, 3148, 37], 'Xiaomi vendor module compatibility')
    with tempfile.TemporaryDirectory() as tmp:
        base=unpack_m45(Path(tmp))
        rebuilt,page,index=make_image(base,a.stock.read_bytes(),image.read_bytes())
        boot=base.image_info(rebuilt)
        require(boot['kernel_sha256']==sha(image) and boot['ramdisk_sha256']==base.RAMDISK and
                len(rebuilt)==134217728,'Stock layout')
    write(a.result/'M63-R5_KERNEL.json',dict(release=REL,config_sha256=sha(out/'.config'),image_sha256=sha(image),
          vmlinux_sha256=sha(out/'vmlinux'),dtb_sha256=DTB,remaining_stock_options=45,autoconf_entries=count,
          kbuild_make_args=['VEUX_STOCK_VENDOR_MODULES=y'],
          atomics_stock_equivalent_config_entries=['CONFIG_ARM64_LSE_ATOMICS','CONFIG_ARM64_USE_LSE_ATOMICS'],
          vendor_abi=dict(zip(('symbols','imports','modules'),table)),built_modules=sorted(module_names),
          stock_layout=dict(bytes=len(rebuilt),ramdisk_sha256=boot['ramdisk_sha256'],avb_page=index),
          device_pass=False,flash_allowed=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['config','final'])
    for name in ['out','stock','baseline','result','vendor']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    a.result.mkdir(parents=True,exist_ok=True)
    configs(a.baseline,a.out/'.config',stock(a.stock),a.result)
    if a.stage=='final':final(a)
