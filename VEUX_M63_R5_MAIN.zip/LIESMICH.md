# POCO X4 Pro 5G (veux) · M63-R5

Der GitHub-Kernel M63-R4 ging auf dem POCO wiederholt in einen Bootloop. Im ARM64-Debugger ließ sich ein Kernel-Oops bei der CPU-Zeitrechnung von WALT beobachten. Eine erste Korrektur in fair.c behob die ungeschützte Migration im Lastausgleich. Ein längerer HyperOS-Test dieses Zwischenstands erfasste einen weiteren Oops bei der Migration einer bereits eingereihten Aufgabe. M63-R5 enthält die mit Xiaomis Original abgeglichenen Reparaturen für beide Wege.

## Auf GitHub bauen

1. Lege die geschlossene Datei VEUX_M63_R5_MAIN.zip im Hauptverzeichnis von Chrizz100/veux-nongki-universal-kernel ab.
2. Lege VEUX_M63_R5_WALT_RUNQUEUE_NOFLASH.yml unter .github/workflows/ ab.
3. Wenn beide Dateien auf main stehen, öffne Actions, wähle „VEUX M63-R5 – WALT-Sperren gegen Xiaomi und R4“ und starte „Run workflow“ auf main.

Die YAML prüft die SHA-256 der MAIN.zip. Sie verwendet den vollständigen R4-Quellstand, seine .config und seinen Buildbefehl aus Lauf 45176581001. Die erforderlichen Eingaben prüft sie auch nach einem Cache-Treffer. Der Kernel meldet 5.4.274-qgki-g82179e362f33. Stockreferenz ist der Originalkernel aus Xiaomi HyperOS OS1.0.12.0.TKCMIXM.

## Die beiden Kerneländerungen

| Datei und Funktion | Verhalten im WALT-Build von R5 |
|---|---|
| kernel/sched/fair.c, detach_task() | Beim aktiven und passiven Lastausgleich sperrt der Scheduler vor set_task_cpu() Quell- und Ziel-Warteschlange in der vorgesehenen Reihenfolge. Nach der Sperrübernahme prüft er die Quelluhr. Nach dem Wechsel gibt er die Zielsperre frei. |
| kernel/sched/core.c, move_queued_task() | Nach dem Ausreihen löst der Scheduler die Lockdep-Zuordnung der Quellsperre, sperrt beide Warteschlangen und prüft die Quelluhr. Nach set_task_cpu() gibt er beide Sperren frei. Zum erneuten Einreihen übernimmt er die Ziel-Warteschlange wieder mit der normalen Scheduler-Sperrfunktion. |

Die Konsistenzprüfung bei negativer Laufzeit in update_task_rq_cpu_cycles() bleibt aktiv. Die beiden Änderungen stimmen im relevanten Ablauf mit der Disassemblierung des ausgelieferten Xiaomi-Kernels und dem veröffentlichten Xiaomi-Quelltext überein.

## Ergebnisse des Workflows lesen

* evidence/walt/Quellstand.json benennt beide geänderten Quelldateien und ihre Prüfsummen vor und nach der Reparatur.
* evidence/walt/Runqueue.json enthält die Aufrufstellen im ARM64-Maschinencode von Xiaomi, vom fehlgeschlagenen GitHub-R4 und vom neu gepackten R5-boot.img. Die Prüfung deckt in R4 drei Aufrufstellen im Lastausgleich und eine bei move_queued_task() ab.
* evidence/walt/Sperren-LLDB.json enthält die während der Ausführung gelesenen Sperrwörter. Der Debugger misst für jeden der zwei Wege in einer eigenen virtuellen Maschine. Bei Xiaomi und R5 werden je Weg drei Migrationen geprüft. Bei R4 wird je Weg ein Wert aufgezeichnet. Der Gast nutzt acht virtuelle CPUs, Xiaomis 6+2-Frequenzgruppen und reguläre Linux-Prozesse mit wechselnder CPU-Zuordnung. Die zugehörigen LLDB- und Kernelprotokolle liegen daneben.
* Weitere Prüfungen betreffen die 37 originalen QGKI-Vendormodule, den Gerätebaum, den UFS-Leseweg, ramoops, die Xiaomi-Ramdisk und die erste Stufe von Android-init. Der AK3-Einstieg wird an beiden simulierten Stock-Slots geprüft.

GitHub liefert die Nachweise und den Quellstand. Nach erfolgreichem Durchlauf enthält das Artefakt NOFLASH das Boot-/AK3-Paar. Der Gerätetest von R5 steht aus. Die Ursache des Neustarts am realen POCO bleibt ohne Geräte-Stacktrace offen.

[GitHub-R4](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45176581001) · [Xiaomi fair.c](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/kernel/sched/fair.c#L8376-L8388) · [Xiaomi core.c](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/61397e524093d1ccb94769b5460825e2eaf8871e/kernel/sched/core.c#L1613-L1635)
