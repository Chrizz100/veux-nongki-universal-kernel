import os, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
import r59_host
import test_r59_host

class ActualR13QcomRTICRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        pinned=os.environ.get('VEUX_R11_CC')
        if pinned:
            cc=Path(pinned)
            if not cc.is_absolute() or not cc.is_file() or cc.is_symlink():
                raise RuntimeError('PINNED_R11_COMPILER_MISSING_OR_UNSAFE')
            cls.cc=str(cc)
            version=subprocess.run([cls.cc,'--version'],text=True,capture_output=True,timeout=15)
            if version.returncode != 0 or 'based on r416183b' not in version.stdout:
                raise RuntimeError('PINNED_R11_COMPILER_VERSION_NOT_R416183B')
        else:
            cls.cc=shutil.which('clang') or shutil.which('cc')
        if not cls.cc: raise RuntimeError('REAL_C_COMPILER_UNAVAILABLE: host C syntax not tested')
        cls.baseline=(ROOT/'refs/R13_BUILD.config').read_text()

    def test_01_actual_R13_config_has_QCOM_RTIC_enabled(self):
        self.assertIn('CONFIG_QCOM_RTIC=y\n',self.baseline)
        self.assertIn('CONFIG_KSU_SUSFS=y\n',self.baseline)
        self.assertIn('CONFIG_KSU=y\n',self.baseline)
        self.assertIn('CONFIG_SECURITY_SELINUX=y\n',self.baseline)

    def _source(self,source):
        a=source.split('/* SECMARK reference count */',1)
        self.assertEqual(len(a),2,'COMPLETE_QCOM_RTIC_STOCK_ANCHOR_REQUIRED')
        fragment=re.search(r'#ifdef CONFIG_KSU_SUSFS\n/\* 5\.4 policy/LSM ABI:.*?^#endif',source,re.M|re.S)
        self.assertIsNotNone(fragment,'R59_REAL_LSM_WRAPPER_NOT_FOUND')
        return '''#include <stdbool.h>
#include <string.h>
#include <stddef.h>
#define __rticdata
struct selinux_state { int slot; };
struct uid_type { unsigned int val; };
static struct uid_type current_uid(void) { return (struct uid_type){ 10001 }; }
#define READ_ONCE(x) (x)
static int selinux_setprocattr(const char *name, void *value, size_t size)
    { (void)name; (void)value; (void)size; return 0; }
''' + a[0] + '\n' + fragment.group(0) + '''
#ifdef CONFIG_KSU_SUSFS
int test_call(void) { return r59_selinux_setprocattr("current", (void *)0, 0); }
#else
int test_call(void) { return selinux_setprocattr("current", (void *)0, 0); }
#endif
'''

    def _compile(self,src, defines):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'rtic_host.c'
            path.write_text(src)
            return subprocess.run([self.cc,'-std=gnu11','-fsyntax-only','-Werror',
                '-Werror=implicit-function-declaration',
                *defines,str(path)],capture_output=True,text=True)

    def test_02_actual_R13_QCOM_RTIC_build_compiles_visible_symbols(self):
        src=self._source(r59_host.port_hooks(test_r59_host.HEADERS))
        p=self._compile(src,['-DCONFIG_QCOM_RTIC=1','-DCONFIG_KSU_SUSFS=1'])
        self.assertEqual(p.returncode,0,p.stderr)

    def test_03_non_RTIC_build_still_compiles_visible_symbols(self):
        src=self._source(r59_host.port_hooks(test_r59_host.HEADERS))
        p=self._compile(src,['-DCONFIG_KSU_SUSFS=1'])
        self.assertEqual(p.returncode,0,p.stderr)

    def test_04_KSU_disabled_host_build_does_not_emit_undefined_symbols(self):
        src=self._source(r59_host.port_hooks(test_r59_host.HEADERS))
        for defines in [[],['-DCONFIG_QCOM_RTIC=1']]:
            p=self._compile(src,defines)
            self.assertEqual(p.returncode,0,p.stderr)

    def test_05_original_bug_is_reproduced_with_real_clang(self):
        fixed=r59_host.port_hooks(test_r59_host.HEADERS)
        b=('#ifdef CONFIG_KSU_SUSFS\n'
           'extern bool ksu_selinux_hide_running;\n'
           'extern int my_setprocattr(const char *name, void *value, size_t size);\n'
           '#endif\n')
        self.assertEqual(fixed.count(b),1)
        self.assertEqual(fixed.count('struct selinux_state selinux_state;\n#endif\n'+b),1)
        broken=fixed.replace('struct selinux_state selinux_state;\n#endif\n'+b,
            'struct selinux_state selinux_state;\n'+b+'#endif\n')
        src=self._source(broken)
        p=self._compile(src,['-DCONFIG_QCOM_RTIC=1','-DCONFIG_KSU_SUSFS=1'])
        self.assertNotEqual(p.returncode,0,'ORIGINAL_QCOM_RTIC_BUG_NO_LONGER_REPRODUCES')
        self.assertIn('ksu_selinux_hide_running',p.stderr)
        self.assertIn('my_setprocattr',p.stderr)

    def test_06_anchored_QCOM_RTIC_source_rejects_missing_or_changed_guard(self):
        raw=test_r59_host.HEADERS
        for changed in [raw.replace('#ifdef CONFIG_QCOM_RTIC','#if 0'),
                        raw.replace('__rticdata;',';'),
                        raw.replace('struct selinux_state selinux_state;\n','# broken\n')]:
            with self.assertRaises(r59_host.GateError):r59_host.port_hooks(changed)

    def test_07_declared_handler_matches_native_54_BakaSU_abi(self):
        x=r59_host.port_hooks(test_r59_host.HEADERS)
        self.assertIn('extern int my_setprocattr(const char *name, void *value, size_t size);',x)
        self.assertIn('return my_setprocattr(name, value, size);',x)
        self.assertEqual(x.count('LSM_HOOK_INIT(setprocattr, r59_selinux_setprocattr)'),1)
        self.assertIn('KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE', (ROOT/'tools/r59_host.py').read_text())

    def test_08_R13_and_R59_original_hash_pins_remain(self):
        self.assertEqual(r59_host.R13_HOST_SHA256['security/selinux/hooks.c'],
                         '57a84c1b0f41d108e9557314c0039e5bfd6fc4b15aa60532711d32e551cc2992')
        self.assertEqual(r59_host.BASE['security/selinux/hooks.c'],
                         'c30bdee06d992110fedb6a61f1c78e9d180a60af')

if __name__=='__main__': unittest.main()
