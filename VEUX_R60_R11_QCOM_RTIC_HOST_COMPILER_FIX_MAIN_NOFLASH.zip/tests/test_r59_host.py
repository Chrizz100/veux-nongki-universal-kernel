import sys
from pathlib import Path
import unittest
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'tools'))
import r59_host as p

HEADERS=('#ifdef CONFIG_QCOM_RTIC\n'
 'struct selinux_state selinux_state __rticdata;\n'
 '#else\n'
 'struct selinux_state selinux_state;\n'
 '#endif\n'
 '/* SECMARK reference count */\n'
 'static int selinux_ismaclabel(const char *name)\n'
 '\treturn 0;\n'
 '\tLSM_HOOK_INIT(setprocattr, selinux_setprocattr),\n')
AVC=(
 '#include "avc_ss.h"\n'
 '\trc = security_sid_to_context(sad->state, sad->tsid, &scontext,\n'
 '\t\t\t\t     &scontext_len);\n'
 '\tif (rc)\n'
 '\t\taudit_log_format(ab, " tsid=%d", sad->tsid);\n'
 '\telse {\n'
 '\t\taudit_log_format(ab, " tcontext=%s", scontext);\n'
 '\t\tkfree(scontext);\n'
 '\t}\n')
SELINUXFS=(
 '#include "objsec.h"\n'
 '\tstruct page    *status = selinux_kernel_status_page(fsi->state);\n\n'
 '\tif (!status)\n')
SERVICES=(
 '#ifdef CONFIG_KSU_SUSFS\n'
 '#include <linux/rcupdate.h>\n'
 'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
 '#endif\n'
 '\tstruct type_datum *typdatum;\n'
 '#ifdef CONFIG_KSU_SUSFS\n'
 '\t/* Exact native-5.4 type check, without replacing the policy parser. */\n'
 '\trcu_read_lock();\n'
 '\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
 '\t\trcu_read_unlock();\n'
 '\t\tgoto out;\n'
 '\t}\n'
 '\trcu_read_unlock();\n'
 '#endif\n'
 '#ifdef CONFIG_KSU_SUSFS\n'
 '\t/* Called only after the real policy has computed the AVD. */\n'
 '\trcu_read_lock();\n'
 '\tsusfs_spoof_avd_allowed_rcu(scontext->type, tcontext->type,\n'
 '\t\t\t\t   tclass, &avd->allowed);\n'
 '\trcu_read_unlock();\n'
 '#endif\n')

class NativeHostTests(unittest.TestCase):
 def test_01_hooks_manual_bakasu_handler(self):
  s=p.port_hooks(HEADERS)
  self.assertIn('return my_setprocattr(name, value, size);',s)
  self.assertIn('LSM_HOOK_INIT(setprocattr, r59_selinux_setprocattr)',s)
  self.assertIn('return selinux_setprocattr(name, value, size);',s)
 def test_02_hooks_uses_app_uid_and_active_mode(self):
  s=p.port_hooks(HEADERS)
  self.assertIn('current_uid().val >= 10000',s)
  self.assertIn('READ_ONCE(ksu_selinux_hide_running)',s)
  self.assertIn('!strcmp(name, "current")',s)
 def test_03_hooks_rejects_old_duplicate(self):
  with self.assertRaises(p.GateError):p.port_hooks(p.port_hooks(HEADERS))
 def test_04_hooks_rejects_wrong_lsm(self):
  with self.assertRaises(p.GateError):p.port_hooks(HEADERS.replace('LSM_HOOK_INIT(setprocattr, selinux_setprocattr)','LSM_HOOK_INIT(setprocattr, unknown)'))
 def test_05_hooks_rejects_broken_compat_marker(self):
  with self.assertRaises(p.GateError):p.port_hooks(HEADERS.replace('struct selinux_state selinux_state;',''))
 def test_06_avc_post_callback(self):
  s=p.port_avc(AVC)
  self.assertIn('susfs_is_avc_log_spoofing_enabled',s)
  self.assertIn('susfs_ksu_sid && susfs_priv_app_sid',s)
  self.assertIn('kfree(scontext);',s)
  self.assertIn('static_branch_unlikely',s)
 def test_07_avc_does_not_change_access_result(self):
  s=p.port_avc(AVC)
  self.assertNotIn('avd->allowed',s)
  self.assertNotIn('avc_denied',s)
 def test_08_avc_rejects_unexpected_callback(self):
  with self.assertRaises(p.GateError):p.port_avc(AVC.replace('audit_log_format(ab, " tsid=%d", sad->tsid);','audit_log_format(ab, "BAD", sad->tsid);'))
 def test_09_avc_double_apply_fails(self):
  with self.assertRaises(p.GateError):p.port_avc(p.port_avc(AVC))
 def test_10_selinuxfs_page_status(self):
  s=p.port_selinuxfs(SELINUXFS)
  self.assertIn('READ_ONCE(fake_status)',s)
  self.assertIn('current_uid().val >= 10000',s)
  self.assertIn('filp->private_data = status;',s+'\nfilp->private_data = status;')
 def test_11_selinuxfs_rejects_unknown_status_layout(self):
  with self.assertRaises(p.GateError):p.port_selinuxfs(SELINUXFS.replace('struct page    *status','struct page *bad'))
 def test_12_services_no_global_parser_change(self):
  s=p.scope_services(SERVICES)
  self.assertIn('current_uid().val >= 10000 && READ_ONCE(ksu_selinux_hide_running)',s)
  self.assertEqual(s.count('susfs_is_sus_type_rcu('),2)
  self.assertIn('susfs_spoof_avd_allowed_rcu',s)
 def test_13_services_rcu_guards_balanced(self):
  s=p.scope_services(SERVICES)
  self.assertEqual(s.count('rcu_read_lock();'),s.count('rcu_read_unlock();')-1) # one extra on branch before goto out
 def test_14_services_bad_preimage_blocks(self):
  with self.assertRaises(p.GateError):p.scope_services(SERVICES.replace('Called only after the real policy','Copied 5.10 without review'))
 def test_15_services_double_apply_blocks(self):
  with self.assertRaises(p.GateError):p.scope_services(p.scope_services(SERVICES))
 def test_16_original_blob_guards(self):
  self.assertEqual(len(p.BASE),3)
  self.assertEqual(len(set(p.BASE.values())),3)
 def test_17_no_root_or_device_write_commands(self):
  s=(BASE/'tools/r59_host.py').read_text()
  for forbidden in ['fastboot flash','adb reboot','flash_image','bootctl set-active-boot-slot']:
   self.assertNotIn(forbidden,s)
 def test_18_r58_original_tests_present(self):
  self.assertTrue((BASE/'tests/test_r58_contracts.py').is_file())
if __name__=='__main__':unittest.main()
