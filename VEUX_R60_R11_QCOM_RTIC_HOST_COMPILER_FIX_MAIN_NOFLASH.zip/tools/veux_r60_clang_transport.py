#!/usr/bin/env python3
"""R60: authenticated fallback for one frozen AOSP clang-r416183b tarball.

Only the legacy source-recipe curl shim is replaced, in the runner temporary
workspace. The original kernel repository, source recipe, and build worker are
left intact. All other legacy commands are delegated to the original engine.
"""
from __future__ import annotations

import hashlib
import json
import os
import posixpath
from pathlib import Path, PurePosixPath
import runpy
import shutil
import subprocess
import sys
import tarfile
import tempfile

PIN_COMMIT = "aa2e4a514a6c85eebcc4a27149eaf9244e951a1e"
PIN_ROOT_TREE = "2fdc995c25e58c0206ff32d5dd46a200431912fa"
PIN_CLANG_TREE = "0a90693130898d6f98a76538086247b374d4a57f"
VERSION = "clang-r416183b"
VERSION_FILE_GIT_BLOB = "76b2048751fe7c55ebe3c713036dc1382d628d34"
AOSP_REPO_PATH = "platform/prebuilts/clang/host/linux-x86"
PIN_URL = f"https://android.googlesource.com/{AOSP_REPO_PATH}/+archive/{PIN_COMMIT}/{VERSION}.tar.gz"
AOSP_URLS = (
    PIN_URL,
    f"https://android.1.googlesource.com/{AOSP_REPO_PATH}/+archive/{PIN_COMMIT}/{VERSION}.tar.gz",
    f"https://android.git.googlesource.com/{AOSP_REPO_PATH}/+archive/{PIN_COMMIT}/{VERSION}.tar.gz",
)
GIT_REMOTES = (
    "https://github.com/msft-mirror-aosp/platform.prebuilts.clang.host.linux-x86.git",
    f"https://android.googlesource.com/{AOSP_REPO_PATH}",
)
ENGINE_GIT_BLOB = "1b59c48392fa63af9640dce47b111057ab237b31"
TOOLS = {"bin/clang", "bin/ld.lld", "bin/llvm-ar", "bin/llvm-nm", "bin/llvm-objcopy", "bin/llvm-objdump", "bin/llvm-strip"}


class PinError(RuntimeError):
    pass


def require(yes: bool, reason: str) -> None:
    if not yes:
        raise PinError(reason)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def original_engine() -> Path:
    repo = Path(os.environ["VEUX_R60_REPO"]).resolve(strict=True)
    require(repo.is_dir() and (repo / ".git").exists(), "ORIGINAL_REPO_NOT_A_GIT_WORKTREE")
    engine = repo / "common/scripts/veux_update_engine.py"
    require(engine.is_file() and not engine.is_symlink(), "ORIGINAL_ENGINE_NOT_REGULAR")
    data = engine.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    require(blob == ENGINE_GIT_BLOB, "ORIGINAL_SOURCE_ENGINE_GIT_BLOB_CHANGED")
    return engine


def launch_legacy(args: list[str]) -> None:
    require(bool(args), "LEGACY_SCRIPT_MISSING")
    target = Path(args[0]).resolve(strict=True)
    require(target.is_file() and not target.is_symlink(), "LEGACY_SCRIPT_INVALID")
    engine = original_engine()
    sys.path.insert(0, str(engine.parent))
    import veux_update_engine as module
    require(Path(module.__file__).resolve() == engine, "LEGACY_ENGINE_IMPORT_CHANGED")
    module.HERE = Path(__file__).resolve(strict=True)
    # Preserve the normal script-dir import order of `python /path/script.py`.
    sys.path.insert(0, str(target.parent))
    sys.argv = [str(target), *args[1:]]
    print("R60_PINNED_CLANG_TRANSPORT=ACTIVE; ORIGINAL_SOURCE_ENGINE_PRESERVED", flush=True)
    # R13's Python build driver launches a fresh SELinux-R3 worker process.
    # Patch only that exact invocation, not unrelated Python/build commands.
    old_run = subprocess.run

    def run_pinned_worker(*popenargs, **kwargs):
        supplied = popenargs[0] if popenargs else kwargs.get("args")
        if (isinstance(supplied, (list, tuple)) and len(supplied) >= 4
            and str(supplied[1]) == "-u"
            and Path(str(supplied[2])).name == "release_worker_selinux_r3.py"
            and str(supplied[3]) == "worker"):
            worker = Path(str(supplied[2]))
            base = Path(os.environ["VEUX_R60_BASE_TEMP"]).resolve(strict=True)
            require(worker.is_file() and not worker.is_symlink()
                    and worker.resolve(strict=True).is_relative_to(base),
                    "PINNED_CLANG_CHILD_WORKER_OUTSIDE_VERIFIED_TEMP")
            require(Path(str(supplied[0])).resolve(strict=True) == Path(sys.executable).resolve(strict=True),
                    "PINNED_CLANG_CHILD_WORKER_INTERPRETER_CHANGED")
            replaced = [str(supplied[0]), "-B", "-u", str(Path(__file__).resolve(strict=True)),
                        "launch", str(worker), *list(supplied[3:])]
            print("R60_PINNED_CLANG_CHILD_WORKER=BRIDGED", flush=True)
            if popenargs:
                return old_run(replaced, *popenargs[1:], **kwargs)
            return old_run(*popenargs, args=replaced, **{k:v for k,v in kwargs.items() if k != "args"})
        return old_run(*popenargs, **kwargs)

    subprocess.run = run_pinned_worker
    try:
        runpy.run_path(str(target), run_name="__main__")
    finally:
        subprocess.run = old_run


def delegate_to_original(args: list[str]) -> None:
    engine = original_engine()
    os.execv(sys.executable, [sys.executable, "-B", "-u", str(engine), *args])


def safe_output_arg(args: list[str]) -> Path:
    outputs = [args[i + 1] for i, v in enumerate(args[:-1]) if v in ("-o", "--output")]
    require(len(outputs) == 1, "PINNED_CLANG_EXPECTS_EXACTLY_ONE_OUTPUT")
    raw = Path(outputs[0])
    require(raw.is_absolute(), "PINNED_CLANG_OUTPUT_MUST_BE_ABSOLUTE")
    require(not raw.is_symlink() and not raw.exists(), "PINNED_CLANG_OUTPUT_ALREADY_EXISTS")
    # Canonical source recipe writes to one of these runner-owned workspaces.
    allowed = [Path(os.environ[k]).resolve(strict=True) for k in ("VEUX_SOURCE_WORK", "VEUX_TRANSPORT_WORK")]
    dest = raw.resolve(strict=False)
    require(any(dest.is_relative_to(p) for p in allowed), "PINNED_CLANG_OUTPUT_ESCAPES_TEMP_WORKSPACE")
    require(raw.parent.is_dir() and not raw.parent.is_symlink(), "PINNED_CLANG_OUTPUT_PARENT_NOT_SAFE")
    return raw


def safe_cache_dir() -> Path:
    base = Path(os.environ["VEUX_R60_BASE_TEMP"]).resolve(strict=True)
    cache = Path(os.environ["VEUX_R60_CLANG_CACHE_DIR"])
    require(cache == base / "veux-r60-clang-cache", "PINNED_CLANG_CACHE_OUTSIDE_RUNNER_TEMP")
    require(not cache.is_symlink(), "PINNED_CLANG_CACHE_SYMLINK")
    cache.mkdir(mode=0o700, exist_ok=True)
    require(cache.is_dir() and cache.resolve(strict=True) == cache, "PINNED_CLANG_CACHE_CHANGED")
    return cache


def validate_archive(path: Path) -> None:
    require(path.is_file() and not path.is_symlink(), "PINNED_CLANG_ARCHIVE_NOT_REGULAR")
    require(path.stat().st_size > 1_000_000, "PINNED_CLANG_ARCHIVE_TOO_SMALL")
    found: set[str] = set()
    with tarfile.open(path, mode="r:gz") as tf:
        for member in tf:
            p = PurePosixPath(member.name)
            require(not p.is_absolute() and ".." not in p.parts, "PINNED_CLANG_TAR_PATH_TRAVERSAL")
            require(member.isfile() or member.isdir() or member.issym() or member.islnk(), "PINNED_CLANG_TAR_SPECIAL_FILE")
            if member.issym() or member.islnk():
                link = member.linkname
                require(not posixpath.isabs(link), "PINNED_CLANG_TAR_ABSOLUTE_LINK")
                ref = posixpath.normpath(posixpath.join(posixpath.dirname(member.name) if member.issym() else "", link))
                require(ref != ".." and not ref.startswith("../"), "PINNED_CLANG_TAR_LINK_ESCAPES")
            found.add(str(p))
        require("AndroidVersion.txt" in found, "PINNED_CLANG_ANDROID_VERSION_FILE_MISSING")
        version = tf.extractfile("AndroidVersion.txt")
        require(version is not None, "PINNED_CLANG_VERSION_FILE_UNREADABLE")
        content = version.read(256)
        git_blob = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        require(git_blob == VERSION_FILE_GIT_BLOB, "PINNED_CLANG_ANDROID_VERSION_GIT_BLOB_CHANGED")
    require(TOOLS.issubset(found), "PINNED_CLANG_TOOLS_MISSING_IN_ARCHIVE:" + ",".join(sorted(TOOLS - found)))


def try_cdn(url: str, out: Path) -> None:
    require(url in AOSP_URLS, "UNPINNED_AOSP_CDN_FORBIDDEN")
    cmd = ["/usr/bin/curl", "--fail", "--show-error", "--location", "--retry", "2",
           "--retry-all-errors", "--connect-timeout", "25", "--max-time", "900", "--output", str(out), url]
    print("R60_CLANG_CDN=" + url.split("/")[2], flush=True)
    cp = subprocess.run(cmd, timeout=940, check=False)
    require(cp.returncode == 0, "PINNED_CLANG_CDN_CURL_EXIT_" + str(cp.returncode))
    validate_archive(out)


def git_checked(args: list[str], *, timeout: int = 900) -> str:
    cp = subprocess.run(["git", *args], capture_output=True, text=True, timeout=timeout, check=False)
    require(cp.returncode == 0, "PINNED_CLANG_MIRROR_GIT_FAILED:" + cp.stderr[-1200:])
    return cp.stdout.strip()


def try_git_tree(remote: str, out: Path) -> None:
    require(remote in GIT_REMOTES, "UNPINNED_GIT_MIRROR_FORBIDDEN")
    print("R60_CLANG_GIT_MIRROR=" + remote, flush=True)
    with tempfile.TemporaryDirectory(prefix="r60-clang-git-", dir=out.parent) as tmp:
        repo = Path(tmp) / "repo"
        git_checked(["init", "-q", str(repo)])
        git_checked(["-C", str(repo), "remote", "add", "origin", remote])
        git_checked(["-C", str(repo), "-c", "http.version=HTTP/1.1", "fetch", "--no-tags", "--quiet",
                     "--depth=1", "--filter=blob:none", "origin", PIN_COMMIT], timeout=1200)
        require(git_checked(["-C", str(repo), "rev-parse", "FETCH_HEAD"]) == PIN_COMMIT,
                "PINNED_CLANG_MIRROR_COMMIT_MISMATCH")
        require(git_checked(["-C", str(repo), "rev-parse", "FETCH_HEAD^{tree}"]) == PIN_ROOT_TREE,
                "PINNED_CLANG_MIRROR_ROOT_TREE_MISMATCH")
        require(git_checked(["-C", str(repo), "rev-parse", f"FETCH_HEAD:{VERSION}"]) == PIN_CLANG_TREE,
                "PINNED_CLANG_MIRROR_SUBTREE_MISMATCH")
        git_checked(["-C", str(repo), "sparse-checkout", "init", "--cone"])
        git_checked(["-C", str(repo), "sparse-checkout", "set", VERSION])
        git_checked(["-C", str(repo), "checkout", "--quiet", "--detach", "FETCH_HEAD"], timeout=1200)
        git_checked(["-C", str(repo), "archive", "--format=tar.gz", "--output=" + str(out),
                     PIN_COMMIT + ":" + VERSION], timeout=1200)
        validate_archive(out)


def obtain_tar(cache: Path) -> Path:
    archive = cache / (VERSION + ".tar.gz")
    receipt = cache / (VERSION + ".sha256")
    if archive.exists() or receipt.exists():
        require(archive.is_file() and receipt.is_file() and not archive.is_symlink()
                and not receipt.is_symlink(), "PINNED_CLANG_CACHED_FILES_INCOMPLETE")
        digest = receipt.read_text().strip()
        require(len(digest) == 64 and all(c in "0123456789abcdef" for c in digest),
                "PINNED_CLANG_CACHE_DIGEST_INVALID")
        require(sha256(archive) == digest, "PINNED_CLANG_CACHE_TAMPERED")
        validate_archive(archive)
        print("R60_CLANG_TRANSPORT=CACHED_PINNED_ARCHIVE_SHA256_" + digest, flush=True)
        return archive

    failures: list[str] = []
    for index, url in enumerate(AOSP_URLS):
        staged = cache / (f"staged-{index}.tar.gz")
        try:
            try_cdn(url, staged)
            os.replace(staged, archive)
            receipt.write_text(sha256(archive) + "\n")
            print("R60_CLANG_TRANSPORT=AOSP_PINNED_ARCHIVE_SHA256_" + sha256(archive), flush=True)
            return archive
        except Exception as exc:
            failures.append(type(exc).__name__ + ":" + str(exc)[:220])
            staged.unlink(missing_ok=True)

    for index, remote in enumerate(GIT_REMOTES):
        staged = cache / (f"git-staged-{index}.tar.gz")
        try:
            try_git_tree(remote, staged)
            os.replace(staged, archive)
            receipt.write_text(sha256(archive) + "\n")
            print("R60_CLANG_TRANSPORT=PINNED_GIT_SUBTREE_SHA256_" + sha256(archive), flush=True)
            return archive
        except Exception as exc:
            failures.append(type(exc).__name__ + ":" + str(exc)[:220])
            staged.unlink(missing_ok=True)
    raise PinError("ALL_PINNED_CLANG_TRANSPORTS_FAILED: " + " | ".join(failures))


def transport_curl(args: list[str]) -> None:
    if args and args[0] == "--":
        args = args[1:]
    # Unrelated historical curl commands go through the immutable old engine.
    if PIN_URL not in args:
        delegate_to_original(["transport-curl", "--", *args])
        return
    require(args.count(PIN_URL) == 1 and len([a for a in args if "+archive/" in a]) == 1,
            "PINNED_CLANG_CURL_URL_MISMATCH")
    dest = safe_output_arg(args)
    cache = safe_cache_dir()
    archive = obtain_tar(cache)
    tmp = dest.with_suffix(dest.suffix + ".r60-partial")
    require(not tmp.exists() and not tmp.is_symlink(), "PINNED_CLANG_OUTPUT_PARTIAL_COLLISION")
    try:
        shutil.copyfile(archive, tmp)
        require(sha256(tmp) == sha256(archive), "PINNED_CLANG_COPIED_ARCHIVE_CHANGED")
        os.replace(tmp, dest)
    finally:
        tmp.unlink(missing_ok=True)
    print("R60_CLANG_PINNED_INSTALL_ARCHIVE_READY=" + str(dest), flush=True)




def seed_cached_clang_from_source() -> None:
    """Preserve the REAL pinned AOSP archive downloaded by source preflight.

    The historical source recipe stores its tarball under source-temp in the
    source-audit tree. That tree survives, but the later full-build worker
    deliberately deletes its own source-temp/toolchain. Record the pinned,
    authenticated preflight bytes in a separate, runner-owned cache NOW.
    """
    base = Path(os.environ["VEUX_R60_BASE_TEMP"]).resolve(strict=True)
    source = (base / "veux-r5s2-work" / "source-audit" / "5.4.274"
              / "source-temp" / (VERSION + ".tar.gz"))
    require(source.is_file() and not source.is_symlink()
            and source.resolve(strict=True).is_relative_to(base),
            "R60_CLANG_PREFLIGHT_ARCHIVE_MISSING_OR_UNSAFE")
    validate_archive(source)
    verified_sha = sha256(source)
    cache = safe_cache_dir()
    archive = cache / (VERSION + ".tar.gz")
    receipt = cache / (VERSION + ".sha256")
    if archive.exists() or receipt.exists():
        verified = verify_cached_clang()
        require(sha256(verified) == verified_sha,
                "R60_CLANG_PREFLIGHT_ARCHIVE_DIFFERS_FROM_EXISTING_CACHE")
    else:
        staged = cache / (VERSION + ".source-staged")
        require(not staged.exists() and not staged.is_symlink(),
                "R60_CLANG_PREFLIGHT_STAGING_COLLISION")
        try:
            shutil.copyfile(source, staged)
            require(sha256(staged) == verified_sha,
                    "R60_CLANG_PREFLIGHT_COPY_CHANGED")
            os.replace(staged, archive)
            receipt.write_text(verified_sha + "\n")
        finally:
            staged.unlink(missing_ok=True)
        verify_cached_clang()
    print("R60_CLANG_PREFLIGHT_SOURCE_CACHE_SEEDED=PASS; SHA256=" + verified_sha, flush=True)


def verify_cached_clang() -> Path:
    """Require the archived toolchain to survive the historical worker cleanup.

    Never use a runner-installed clang, a floating compiler, or a fake version
    string. This archive is authenticated by the frozen source's version blob,
    the runner-cache SHA-256 receipt, and the pinned transport contract.
    """
    cache = safe_cache_dir()
    archive = cache / (VERSION + ".tar.gz")
    receipt = cache / (VERSION + ".sha256")
    require(archive.is_file() and receipt.is_file() and not archive.is_symlink()
            and not receipt.is_symlink(), "R60_CLANG_ARCHIVE_CACHE_MISSING")
    return obtain_tar(cache)


def restore_pinned_clang(args: list[str]) -> None:
    """Rehydrate verified clang-r416183b into R60's own, isolated build tree.

    The R13 worker legitimately removes its temporary source/toolchain directory
    after a successful build. Reusing that deleted path caused the R9 failure.
    This operation makes no network access and never modifies the R13 tree.
    """
    require(len(args) == 1, "R60_CLANG_RESTORE_REQUIRES_ONE_PATH")
    base = Path(os.environ["VEUX_R60_BASE_TEMP"]).resolve(strict=True)
    target = Path(args[0])
    exact = base / "veux-r58" / "pinned-toolchain" / VERSION
    require(target == exact and not target.is_symlink() and not target.exists(),
            "R60_CLANG_RESTORE_PATH_OR_COLLISION")
    parent = exact.parent
    require(parent.parent.is_dir() and parent.parent.resolve(strict=True) == base / "veux-r58"
            and not parent.parent.is_symlink(), "R60_CLANG_RESTORE_PARENT_UNTRUSTED")
    require(not parent.exists() and not parent.is_symlink(), "R60_CLANG_RESTORE_PARENT_REUSED")
    archive = verify_cached_clang()
    parent.mkdir(mode=0o700)
    scratch = Path(tempfile.mkdtemp(prefix=".extract-", dir=parent))
    committed = False
    try:
        # The filter additionally blocks absolute/traversal and unsafe symlink
        # targets, even if tarfile semantics change in a future Python release.
        with tarfile.open(archive, mode="r:gz") as tf:
            tf.extractall(path=scratch, filter="data")
        version = scratch / "AndroidVersion.txt"
        require(version.is_file() and not version.is_symlink(),
                "R60_CLANG_RESTORED_VERSION_MISSING")
        version_bytes = version.read_bytes()
        version_blob = hashlib.sha1(b"blob " + str(len(version_bytes)).encode()
                                   + b"\0" + version_bytes).hexdigest()
        require(version_blob == VERSION_FILE_GIT_BLOB,
                "R60_CLANG_RESTORED_VERSION_PIN_MISMATCH")
        for rel in TOOLS:
            tool = scratch / rel
            require(tool.is_file() and tool.resolve(strict=True).is_relative_to(scratch)
                    and os.access(tool, os.X_OK),
                    "R60_CLANG_RESTORED_TOOL_INVALID:" + rel)
        result = subprocess.run([str(scratch / "bin/clang"), "--version"],
                                capture_output=True, text=True, timeout=45, check=False)
        require(result.returncode == 0 and "based on r416183b" in result.stdout
                and "clang version 12.0.5" in result.stdout,
                "R60_CLANG_RESTORED_BINARY_VERSION_MISMATCH")
        # Atomic publication only after every tool and binary version passes.
        os.rename(scratch, target)
        committed = True
        print("R60_CLANG_TOOLCHAIN_RESTORED=PASS", flush=True)
        print("R60_CLANG_ARCHIVE_SHA256=" + sha256(archive), flush=True)
        print("R60_CLANG_VERSION=" + result.stdout.splitlines()[0], flush=True)
        print("R60_CLANG_RESTORED_BIN=" + str(target / "bin"), flush=True)
    finally:
        if not committed:
            shutil.rmtree(scratch, ignore_errors=True)


def main(argv: list[str]) -> None:
    require(bool(argv), "BRIDGE_SUBCOMMAND_REQUIRED")
    command = argv[0]
    if command == "launch":
        launch_legacy(argv[1:])
    elif command == "transport-curl":
        transport_curl(argv[1:])
    elif command == "seed-source-archive":
        require(len(argv) == 1, "R60_CLANG_SEED_CACHE_REQUIRES_NO_ARGS")
        seed_cached_clang_from_source()
    elif command == "verify-cache":
        require(len(argv) == 1, "R60_CLANG_VERIFY_CACHE_REQUIRES_NO_ARGS")
        archive = verify_cached_clang()
        print("R60_CLANG_SURVIVING_CACHE=PASS; SHA256=" + sha256(archive), flush=True)
    elif command == "restore-clang":
        restore_pinned_clang(argv[1:])
    else:
        # capture-make and any other legacy command must stay byte-identical.
        delegate_to_original(argv)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except (PinError, OSError, ValueError, tarfile.TarError, subprocess.TimeoutExpired) as exc:
        print("R60_PINNED_CLANG_TRANSPORT_FAILED=" + type(exc).__name__ + ":" + str(exc), file=sys.stderr, flush=True)
        sys.exit(3)
