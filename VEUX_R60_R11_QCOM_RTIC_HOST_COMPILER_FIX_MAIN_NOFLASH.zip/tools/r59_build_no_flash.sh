#!/usr/bin/env bash
# R59 complete native-54 SELinux/BakaSU/SUSFS/CASS source compiler diagnostic: no boot/AK3, no reboot/flash/download installer.
set -Eeuo pipefail
umask 077
fail() { echo "R58_COMPILER_BLOCKED=$1" >&2; exit 3; }
: "${RUNNER_TEMP:?}" "${GITHUB_WORKSPACE:?}" "${R58_PAYLOAD:?}" "${R56_PAYLOAD:?}"
[[ "$GITHUB_REPOSITORY" == Chrizz100/veux-nongki-universal-kernel ]] || fail WRONG_REPO
[[ "$GITHUB_REF" == refs/heads/main ]] || fail WRONG_REF
[[ "$(git -C "$GITHUB_WORKSPACE" rev-parse HEAD)" == "$GITHUB_SHA" ]] || fail SHA_DRIFT
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || fail ORIGINAL_TREE_DIRTY
R13_ROOT="$RUNNER_TEMP/veux-r55h17-r4"
[[ -s "$R13_ROOT/evidence/R4_RESULT.json" ]] || fail R13_COMPILE_EVIDENCE_MISSING
python3 -I - "$R13_ROOT/evidence/R4_RESULT.json" <<'PY'
from pathlib import Path
import json,sys
r=json.loads(Path(sys.argv[1]).read_text())
assert r['status']=='CASS_UPDATED_FULL_BUILD_AND_STATIC_ABI_PASS_NOFLASH'
assert r['bakasu_version']['commit']=='d2537b13ab15fce72e8c0d99e7788805f071aeb4'
assert r['cass_linked'] and r['rmnet_imports_matched']==132
assert r['flash_allowed'] is False
PY
shopt -s nullglob
R54_STAGES=("$RUNNER_TEMP"/veux-r54-no-flash-*)
[[ ${#R54_STAGES[@]} == 1 ]] || fail R54_STAGE_AMBIGUOUS
R54="${R54_STAGES[0]}"
R56="$RUNNER_TEMP/veux-r56-real-source-proof"
[[ -s "$R56/R56_REAL_SOURCE_GATE.json" ]] || fail R56_SOURCE_PROOF_MISSING
SRC="$R13_ROOT/source/kernel"
[[ -d "$SRC" ]] || fail R13_REAL_SOURCE_NOT_FOUND
[[ ! -e "$RUNNER_TEMP/veux-r58" ]] || fail R58_DIR_REUSED
mkdir -m 0700 "$RUNNER_TEMP/veux-r58"
OUT="$RUNNER_TEMP/veux-r58"
python3 -B "$R58_PAYLOAD/tools/r58_integrate.py" --mode stage \
 --r13-main "$GITHUB_WORKSPACE/VEUX_R13_CASS_MAIN.zip" \
 --r56-main "$GITHUB_WORKSPACE/VEUX_R56_R4_STOCK_AVD_PATH_MAIN_NOFLASH.zip" \
 --r13-config "$R13_ROOT/build/.config" \
 --kernel "$SRC" --replay "$R54/NEW_BAKASU_GIT_SOURCE_NOT_BUILT" \
 --r54-stage "$R54" --r56-stage "$R56" --out "$OUT/stage" \
 > "$OUT/R58_INTEGRATION_STAGE.log" 2>&1 || { tail -n 70 "$OUT/R58_INTEGRATION_STAGE.log" >&2; fail SOURCE_INTEGRATION; }
SOURCE="$OUT/stage/kernel"
# R59: genuine native-5.4 host registration, audit and app-scoped parser.
# Host file preimages must match original compiled R13 files and signed-off inventory.
python3 -B "$R58_PAYLOAD/tools/r59_host.py" --kernel "$SOURCE" \
  --inventory "$R13_ROOT/evidence/BASELINE_SOURCE_INVENTORY.json" \
  --out "$OUT/R59_HOST_STATUS.json" > "$OUT/R59_NATIVE54_HOST_STAGE.log" 2>&1 || {
  tail -n 90 "$OUT/R59_NATIVE54_HOST_STAGE.log" >&2; fail R59_HOST_INTEGRATION;
}
BUILD="$OUT/build"
[[ ! -e "$BUILD" ]] || fail OBJECT_DIR_REUSED
mkdir -m 0700 "$BUILD"
cp "$R13_ROOT/build/.config" "$BUILD/.config"
# R10: the successful R13 worker deliberately cleans its temporary toolchain.
# Rehydrate the SAME authenticated clang-r416183b from R60's surviving cache,
# not from its deleted source-work path and never from the runner system PATH.
TC_ROOT="$OUT/pinned-toolchain/clang-r416183b"
if python3 -B "$R58_PAYLOAD/tools/veux_r60_clang_transport.py" restore-clang "$TC_ROOT" \
    > "$OUT/R60_PINNED_CLANG_RESTORE.log" 2>&1; then
  cat "$OUT/R60_PINNED_CLANG_RESTORE.log"
else
  cat "$OUT/R60_PINNED_CLANG_RESTORE.log" >&2
  fail PINNED_CLANG_CACHE_RESTORE
fi
TC="$TC_ROOT/bin"
[[ -x "$TC/clang" && -x "$TC/ld.lld" && -x "$TC/llvm-nm" ]] || fail PINNED_CLANG_RESTORE_INCOMPLETE
export PATH="$TC:$PATH"
export ARCH=arm64 CC=clang LD=ld.lld LLVM=1 LLVM_IAS=1
export KBUILD_BUILD_USER=builder
export KBUILD_BUILD_HOST=pangu-build-component-vendor-345942-54r9t-tw0tk-tq90c
export KBUILD_BUILD_TIMESTAMP='Thu Dec 5 14:47:59 UTC 2024'
export KBUILD_BUILD_VERSION=1
export KBUILD_FIXED_SCM_SUFFIX=-g82179e362f33
export SOURCE_DATE_EPOCH=1733410079
# Same Kbuild toolchain family as the successful R13 CI. Kernel version comes
# from real BakaSU history (4559 upstream+port, then 4560 local merge commit).
KFLAGS="-D__ANDROID_COMMON_KERNEL__ -I$BUILD/security/selinux"
if make -C "$SOURCE" O="$BUILD" ARCH=arm64 LLVM=1 LLVM_IAS=1 CC=clang LD=ld.lld KCFLAGS="$KFLAGS" olddefconfig > "$OUT/R58_OLDDEFCONFIG.log" 2>&1; then
  echo R58_OLDDEFCONFIG_EXIT=0
else
  tail -n 80 "$OUT/R58_OLDDEFCONFIG.log" >&2; fail OLDDEFCONFIG
fi
# Do not byte-compare a newer Kconfig's generated output: new *disabled*
# BakaSU options may appear. Every existing R13 option remains immutable.
# No device/ABI config changes or unreviewed new options are permitted.
python3 -B "$R58_PAYLOAD/tools/r60_config_guard.py" \
  --baseline "$R13_ROOT/build/.config" \
  --actual "$BUILD/.config" \
  --out "$OUT/R60_OLDDEFCONFIG_DELTA.json" \
  > "$OUT/R60_OLDDEFCONFIG_DELTA.log" 2>&1 || {
  cat "$OUT/R60_OLDDEFCONFIG_DELTA.log" >&2; fail R13_CONFIG_DELTA_NOT_AUTHORIZED;
}
if make -C "$SOURCE" O="$BUILD" ARCH=arm64 LLVM=1 LLVM_IAS=1 CC=clang LD=ld.lld KCFLAGS="$KFLAGS" -j4 Image dtbs modules > "$OUT/R58_FULL_ARM64_BUILD.log" 2>&1; then
 echo R58_KERNEL_COMPILER_EXIT=0
else
 tail -n 120 "$OUT/R58_FULL_ARM64_BUILD.log" >&2; fail ARM64_FULL_COMPILE
fi
python3 -B "$R58_PAYLOAD/tools/r58_postcompile.py" --output "$OUT/stage" \
 --objects "$BUILD" --nm "$TC/llvm-nm" \
 --reference "$R58_PAYLOAD/refs/R13_RMNET_132_ABI.json" \
 > "$OUT/R58_POSTCOMPILE.log" 2>&1 || { cat "$OUT/R58_POSTCOMPILE.log" >&2; fail ABI_OR_LINK; }
# Evaluate all 218 real OEM modules / 14,648 original imports independently.
python3 -B "$R58_PAYLOAD/tools/r14_vendor_abi_gate.py" \
 --r21-imports "$R58_PAYLOAD/refs/R21_IMPORTS.csv" \
 --r13-symvers "$R58_PAYLOAD/refs/R13_CI_Module.symvers" \
 --candidate-symvers "$BUILD/Module.symvers" \
 --r13-config "$R58_PAYLOAD/refs/R13_BUILD.config" \
 --candidate-config "$BUILD/.config" \
 --out "$OUT/R59_VENDOR_ABI.json" > "$OUT/R59_VENDOR_ABI.log" 2>&1 || {
 cat "$OUT/R59_VENDOR_ABI.log" >&2; fail OEM_ABI_RESEARCH;
}
# SHA-pinned read-only proof of the conflicting OEM module cohorts.
python3 -B "$R58_PAYLOAD/tools/r60_abi_cohorts.py" \
 --imports "$R58_PAYLOAD/refs/R21_IMPORTS.csv" \
 --out "$OUT/R60_ABI_COHORT_CONFLICTS.json" \
 > "$OUT/R60_ABI_COHORT_CONFLICTS.log" 2>&1 || {
  cat "$OUT/R60_ABI_COHORT_CONFLICTS.log" >&2; fail R60_COHORT_CONFLICT_AUDIT;
}
cp "$OUT/stage/R58_COMPILE_STATUS.json" "$OUT/R58_COMPILE_STATUS.json"
python3 -B "$R58_PAYLOAD/tools/r59_postcheck.py" --source "$SOURCE" --objects "$BUILD" \
 --report "$OUT" --nm "$TC/llvm-nm" --vendor-report "$OUT/R59_VENDOR_ABI.json" \
 > "$OUT/R59_POSTCHECK.log" 2>&1 || {
 cat "$OUT/R59_POSTCHECK.log" >&2; fail R59_SYMBOL_LINKAGE;
}
cp "$OUT/stage/R58_SOURCE_STAGE.json" "$OUT/R58_SOURCE_STAGE.json"
cp "$OUT/stage/R58_COMPILE_STATUS.json" "$OUT/R58_COMPILE_STATUS.json"
cp "$OUT/stage/R58_RMNET_132_DETAIL.json" "$OUT/R58_RMNET_132_DETAIL.json"
# Full OEM ABI / DTBO / original boot.img has not been proven, so NEVER
# publish kernel/boot artifacts. Strictly text/JSON reports only.
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || fail ORIGINAL_REPO_MUTATED
printf 'R59_FULL_NATIVE54_COMPILE_AND_218_MODULE_ABI_DIAGNOSTIC_COMPLETE; FLASH=NO\n'
