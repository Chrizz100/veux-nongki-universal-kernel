#!/usr/bin/env python3
"""Keep initial and newer HiZ isolation requests across the monitor pulse."""
import argparse,contextlib,copy,hashlib,importlib.util,json,mmap
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BQ='drivers/power/supply/qcom/bq2589x_charger.c'
BEFORE='ef9a7aec82eb3a9741c532d5816f886b6fdca5c7e4a6cbd12f6391729666aefe'
AFTER='f68af577ce9b06bfc16ab0e4d644700fa66ac46c8df6cd83f1e952efe0b1b8ec'
PARENT='7bf7c51d702a28d2b0a0fe6cfb9d0744c701798c8ed2a93b15aed93a8ef12551'
STATUS='M43_FULL_HIZ_REQUEST_ORDERING_CONFIG_1423_CRCS_37_MODULES_PASS_NOFLASH'
def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def profile():return json.loads((ROOT/'References/PROFILE.json').read_text())
def verify_package():
 names=set()
 for row in(ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
  digest,name=row.split('  ',1);p=Path(name)
  require(not p.is_absolute()and'..'not in p.parts and name not in names,'UNSAFE_MANIFEST')
  require(not(ROOT/p).is_symlink()and sha(ROOT/p)==digest,'PACKAGE_CHANGED:'+name);names.add(name)
 require(names=={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt'},'PACKAGE_SCOPE_CHANGED')
 p=profile();require(p['baseline_commit']=='cea7e75a5ba32d71d99ea024d97e1d9cfc07c28a'and p['before_sha256']==BEFORE and p['after_sha256']==AFTER and p['m42_tool_sha256']==PARENT,'INDEPENDENT_SOURCE_AND_ENGINE_PINS_REQUIRED')
 require(sha(ROOT/'Before'/BQ)==BEFORE and sha(ROOT/'After'/BQ)==AFTER,'ONLY_APPROVED_HIZ_ORDER_SOURCE_ALLOWED')
def check_file(source):
 source=Path(source).resolve(strict=True);p=source/BQ
 require(p.is_file()and all(not x.is_symlink()for x in[p,*p.parents]if x.is_relative_to(source)),'REGULAR_BQ_SOURCE_REQUIRED')
 require(sha(p)==AFTER,'M43_HIZ_ORDER_SOURCE_REQUIRED');return{BQ:AFTER}
def apply_overlay(source):
 p=Path(source)/BQ;require(sha(p)==BEFORE,'EXACT_PROVEN_M42_POSTIMAGE_REQUIRED');p.write_bytes((ROOT/'After'/BQ).read_bytes());return check_file(source)
def load_parent(path):
 path=Path(path).resolve(strict=True);require(sha(path)==PARENT,'AUTHENTIC_M42_ENGINE_REQUIRED')
 s=importlib.util.spec_from_file_location('m43_original_m42',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify_package();return m
@contextlib.contextmanager
def engine(args):
 """Retain the full immutable chain and explicitly authorize one new BQ postimage."""
 m42=load_parent(args.m42_tool);original_engine=m42.engine;original_file=m42.check_file
 @contextlib.contextmanager
 def extended_engine(a):
  with original_engine(a)as m41:
   prior_engine=m41.engine
   @contextlib.contextmanager
   def extended_bq(m40_path,m28_path):
    with prior_engine(m40_path,m28_path)as(bq,wt):
     raw=m41.load_m40(m40_path);raw_pins=raw.pins;old_check=bq.source_check;old_apply=bq.apply_source
     def checked(source,after=False):
      if not after:return old_check(source,after=False)
      check_file(source);pins=copy.deepcopy(raw_pins());require(pins[BQ]['after_sha256']==m41.profile()['bq_proven_sha256'],'ORIGINAL_M40_BQ_BASE_CHANGED');pins[BQ]['after_sha256']=AFTER;raw.pins=lambda:pins
      try:return raw.source_check(source,after=True)
      finally:raw.pins=raw_pins
     def applied(source):
      bq.source_check=old_check;m42.check_file=original_file
      try:old_apply(source)
      finally:bq.source_check=checked;m42.check_file=check_file
      apply_overlay(source);return checked(source,after=True)
     bq.source_check=checked;bq.apply_source=applied
     try:yield bq,wt
     finally:bq.source_check=old_check;bq.apply_source=old_apply;raw.pins=raw_pins
   m41.engine=extended_bq
   try:yield m41
   finally:m41.engine=prior_engine
 m42.engine=extended_engine;m42.check_file=check_file
 try:yield m42
 finally:m42.engine=original_engine;m42.check_file=original_file
def proof(build):
 build=Path(build).resolve(strict=True);source=check_file(build/'candidate-source');offsets={}
 for marker in [b'bq2589x: monitor hiz snapshot failed',b'bq2589x: monitor hiz restore superseded']:
  offsets[marker.decode()]={}
  for name in ['arch/arm64/boot/Image','vmlinux']:
   with(build/'candidate-out'/name).open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as data:at=data.find(marker)
   require(at>=0,'HIZ_ORDER_BRANCH_NOT_LINKED:'+name);offsets[marker.decode()][name]=at
 return{'hiz_order_source_hashes':source,'hiz_order_marker_offsets':offsets}
def write(path,name,value):
 if Path(path).is_dir():(Path(path)/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def verify_fresh(args):
 build=Path(args.build).resolve(strict=True);r=json.loads((build/'M43_RESULT.json').read_text())
 require(r.get('status')==STATUS and r.get('kernel_compiled')is True and r.get('hiz_order_paths_compiled_and_linked')is True and r.get('runtime_charging_tested')is False and r.get('device_pass')is False and r.get('flash_allowed')is False,'FRESH_M43_FULL_BUILD_REQUIRED')
 with engine(args)as m42:prior=m42.verify_fresh(args)
 require(all(r.get(k)==v for k,v in proof(build).items()),'HIZ_ORDER_PROOF_CHANGED')
 require(r['kernel_product_hashes']==prior['kernel_product_hashes']and r['qgki_counts']==prior['qgki_counts'],'PARENT_PRODUCT_CHANGED')
 return r
def build(args):
 verify_package();out=Path(args.output).resolve();r={'status':'M43_PENDING','kernel_compiled':False,'runtime_charging_tested':False,'device_pass':False,'flash_allowed':False,'baseline_run':44035121259}
 try:
  with engine(args)as m42:
   m42.build(args);prior=m42.verify_fresh(argparse.Namespace(**{**vars(args),'build':out}))
  require(prior['qgki_counts']=={'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0}and prior['fully_matching_modules']==37,'COMPLETE_STOCK_COHORT_REQUIRED')
  r.update(proof(out));r.update(status=STATUS,kernel_compiled=True,hiz_order_paths_compiled_and_linked=True,kernel_product_hashes=prior['kernel_product_hashes'],qgki_counts=prior['qgki_counts'],fully_matching_modules=37,release=prior['release'])
 except Exception as error:r.update(status='M43_BUILD_OR_HIZ_ORDER_FAILED_NOFLASH',error=str(error));raise
 finally:write(out,'M43_RESULT.json',r)
 print(STATUS,'DEVICE_PASS=NO FLASH=NO')
def package(args):
 verify_package();r=verify_fresh(args);out=Path(args.output).resolve();result={'status':'M43_PACKAGE_PENDING','static_boot_path_pass':False,'device_pass':False,'flash_allowed':False}
 try:
  with engine(args)as m42:m42.package(args)
  prior=json.loads((out/'M42_PACKAGE_RESULT.json').read_text());require(prior['static_boot_path_pass']is True and prior['device_pass']is False,'M42_STATIC_GATES_REQUIRED')
  for p in sorted((out/'review').iterdir()):
   require(p.is_file()and p.name.startswith('VEUX_M42_'),'REVIEW_SCOPE_CHANGED');target=p.with_name(p.name.replace('VEUX_M42_','VEUX_M43_',1));require(not target.exists(),'REVIEW_TARGET_EXISTS');p.rename(target)
  s=importlib.util.spec_from_file_location('m43_pair_audit',args.m25_tool);cfg=importlib.util.module_from_spec(s);s.loader.exec_module(cfg);cfg.verify_package();pair=cfg.audit_pair(args.build,out);verify_fresh(args)
  result.update(status='M43_STATIC_BOOT_AK3_HIZ_ORDER_PAIR_PASS_NOFLASH',static_boot_path_pass=True,review_pair_sha256=pair,kernel_release=r['release']['verified_release'])
 except Exception as error:
  result.update(status='M43_PACKAGE_FAILED_NOFLASH',error=str(error));review=out/'review'
  if review.exists():review.rename(out/'unverified-review')
  raise
 finally:write(out,'M43_PACKAGE_RESULT.json',result)
 print('M43_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')
def parser():
 p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='op',required=True);s.add_parser('verify-package')
 g=s.add_parser('check-git-source');g.add_argument('--m42-tool',required=True);g.add_argument('--m41-tool',required=True);g.add_argument('--source',required=True)
 b=s.add_parser('build')
 for n in ['m42-tool','m41-tool','m40-tool','m28-tool','m27-tool','m26-tool','m25-tool','r25-tool','r24-tool','r23-tool','r21-tool','r19-tool','r18-tool','r17-tool','base-tool','source','objout','r6-report','r6-tool','project','output']:b.add_argument('--'+n,required=True)
 a=s.add_parser('package')
 for n in ['m42-tool','m41-tool','m40-tool','m28-tool','m27-tool','m26-tool','m25-tool','r25-tool','r24-tool','r23-tool','r21-package-tool','build','packager-tool','work','output']:a.add_argument('--'+n,required=True)
 return p
def main():
 a=parser().parse_args();verify_package()
 if a.op=='build':build(a)
 elif a.op=='package':package(a)
 elif a.op=='check-git-source':print(json.dumps(load_parent(a.m42_tool).load_parent(a.m41_tool).check_git_source(a.source),sort_keys=True))
 else:print('M43_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')
if __name__=='__main__':main()
