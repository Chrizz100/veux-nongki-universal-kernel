"""Real monitor + real IIO writer; deterministic HiZ/OTG/thermal interleavings."""
import argparse,json,os,re,subprocess,tempfile
from pathlib import Path
def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]
def harness(src):
 parent=Path(os.environ['M40_DIR']);stub=(parent/'References/native_bq_vindpm_hiz_stubs.h').read_text()
 stub=stub.replace('typedef uint16_t u16;','typedef uint16_t u16; typedef uint64_t u64;')
 stub=stub.replace('struct mutex io_lock;','struct mutex io_lock, charge_lock;\n u64 charge_request_seq, hiz_request_seq;\n bool charge_requested, vindpm_active, hiz_requested, hiz_pulse_active;')
 stub=stub.replace('static void fake_msleep(int ms){event(3,ms,0);if(stop_on_sleep)WRITE_ONCE(g_bq->stopping,true);}', 'static atomic_int asleep,released;static bool pause_pulse;\nstatic void fake_msleep(int ms){event(3,ms,0);if(stop_on_sleep)WRITE_ONCE(g_bq->stopping,true);if(ms==1&&pause_pulse){atomic_store(&asleep,1);while(!atomic_load(&released))sched_yield();}}')
 stub=stub.replace('v->intval=prop==POWER_SUPPLY_PROP_TEMP?temperature_sample:voltage_sample;', 'v->intval=prop==POWER_SUPPLY_PROP_TEMP?temperature_sample:prop==POWER_SUPPLY_PROP_CAPACITY?80:voltage_sample;')
 enum=src[src.index('enum bq2589x_vbus_type {'):src.index('enum bq2589x_part_no {')]
 defs='\n'.join(l for l in(parent/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()if l.startswith('#define BQ2589X_'))
 ids=json.loads((parent/'References/BOUND_IIO_CHANNEL_IDS.json').read_text())['channels'];defs+='\n'+'\n'.join('#define '+c['name']+' '+str(c['id'])for c in ids)
 const='#define BQ2589X_STATUS_CHARGE_ENABLE 4\n#define POWER_SUPPLY_PROP_CAPACITY 1\n#define POWER_SUPPLY_PROP_TEMP 2\n#define POWER_SUPPLY_PROP_VOLTAGE_NOW 3\n'
 names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_enable_otg','bq2589x_disable_otg','bq2589x_set_otg_volt','bq2589x_set_otg_current','__bq2589x_set_charger','bq2589x_set_charger_request','bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_adc_read_vbus_volt','bq2589x_adc_read_battery_volt','bq2589x_adc_read_charge_current','bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit','bq2589x_set_charge_current','bq2589x_set_term_current','bq2589x_set_chargevoltage','bq2589x_enable_term','bq2589x_usb_switch','bq2589x_read_vindpm_volt','__bq2589x_set_hiz','bq2589x_set_hiz_request','bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode','bq2589x_get_hiz_mode','bq2589x_resolve_supply','bq2589x_monitor_hiz_pulse','bq2589x_monitor_workfunc','bq_iio_write_raw_unlocked','bq_iio_write_raw']
 body=[]
 for n in names:
  try:body.append(function(src,n))
  except ValueError:
   if n not in ['__bq2589x_set_hiz','bq2589x_set_hiz_request','bq2589x_monitor_hiz_pulse']:raise
 old='static void bq2589x_monitor_hiz_pulse('not in src
 tests=r'''
static struct bq2589x bq;static struct device dev;static struct i2c_client client;static struct iio_dev iio={&bq};static bool initialized;
static int assertions,sequential,concurrent,faults,thermal_faults;
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void reset(int hiz,int requested,int hot,int chip,int type,int curr){
 if(initialized){pthread_mutex_destroy(&bq.io_lock.value);pthread_mutex_destroy(&bq.charge_lock.value);}
 memset(&bq,0,sizeof(bq));memset(registers,0,sizeof(registers));memset(events,0,sizeof(events));memset(saved_events,0,sizeof(saved_events));
 pthread_mutex_init(&bq.io_lock.value,NULL);pthread_mutex_init(&bq.charge_lock.value,NULL);initialized=true;
 bq.dev=&dev;bq.client=&client;g_bq=&bq;bq.startup_ready=true;bq.is_bq25890h=chip;bq.vbus_type=type;bq.batt_psy=&bq;bq.usb_psy=&client;bq.curr_flag=curr;bq.charge_requested=true;bq.hiz_requested=requested;bq.status=BQ2589X_STATUS_CHARGE_ENABLE;
 bq.usb_switch1=31;bq.usb_switch2=32;bq.otg_gpio=33;bq.monitor_work.work.id=1;
 registers[BQ2589X_REG_00]=0x25|(hiz?BQ2589X_ENHIZ_MASK:0);registers[BQ2589X_REG_03]=BQ2589X_CHG_CONFIG_MASK;registers[BQ2589X_REG_11]=25;registers[BQ2589X_REG_0D]=127;
 temperature_sample=hot?481:250;voltage_sample=4200001;
 failure_event=-1;failed_write_applied=false;fail_write_at=fail_gpio_at=gpio_calls=fail_gpio=fail_property=property_calls=last_error=0;
 fail_property_prop=property_error_payload=shutdown_phase=drain_count=priv_calls=alloc_fail=0;fail_write=fail_read=read_calls=write_calls=fail_from_call=event_count=0;fail_count=fail_reg=-1;
 stop_on_sleep=stop_on_notify=stop_on_property=pause_pulse=false;atomic_store(&asleep,0);atomic_store(&released,0);atomic_store(&hold_read,0);atomic_store(&read_entered,0);atomic_store(&release_read,0);
}
static int count(int kind,int reg){int n=0;for(int i=0;i<event_count;i++)if(events[i].kind==kind&&(reg<0||events[i].a==reg))n++;return n;}
static int writes_after(int at,int reg){int n=0;for(int i=at;i<event_count;i++)if(events[i].kind==2&&events[i].a==reg)n++;return n;}
static bool unlocked(void){int rc=pthread_mutex_trylock(&bq.charge_lock.value);if(!rc)pthread_mutex_unlock(&bq.charge_lock.value);return !rc;}
static int request(int channel,int value){struct iio_chan_spec c={channel};return bq_iio_write_raw(&iio,&c,value,0,0);}
static void*monitor(void*p){bq2589x_monitor_workfunc(&bq.monitor_work.work);return NULL;}
int main(void){
#if OLD_SOURCE
 (void)sequential;(void)concurrent;(void)faults;(void)thermal_faults;
 reset(1,0,0,1,BQ2589X_VBUS_USB_SDP,1);bq2589x_monitor_workfunc(&bq.monitor_work.work);CHECK(!(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK));puts("M42_INITIAL_HIZ_CLEARED_BY_MONITOR=REPRODUCED");
 reset(0,0,0,1,BQ2589X_VBUS_USB_SDP,1);pause_pulse=true;pthread_t t;CHECK(!pthread_create(&t,NULL,monitor,NULL));while(!atomic_load(&asleep))sched_yield();CHECK(request(PSY_IIO_MAIN_CHAGER_HZ,1)==0);CHECK(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK);atomic_store(&released,1);CHECK(!pthread_join(t,NULL));CHECK(!(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK));puts("M42_NEW_IIO_HIZ_REQUEST_OVERRIDDEN_BY_MONITOR=REPRODUCED");
#else
 for(int chip=0;chip<2;chip++)for(int type=0;type<8;type++)for(int hiz=0;hiz<2;hiz++)for(int wanted=0;wanted<2;wanted++)for(int hot=0;hot<2;hot++)for(int curr=0;curr<2;curr++){
  reset(hiz,wanted,hot,chip,type,curr);bq2589x_monitor_workfunc(&bq.monitor_work.work);
  CHECK(!!(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK)==hiz);CHECK((registers[BQ2589X_REG_00]&~BQ2589X_ENHIZ_MASK)==0x25);CHECK(!bq.hiz_pulse_active&&bq.hiz_request_seq==0&&bq.hiz_requested==!!wanted&&unlocked());
  CHECK(count(4,1)==1);if(hot){CHECK(count(7,POWER_SUPPLY_PROP_VOLTAGE_NOW)==1);CHECK(!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));}
  if(hiz||wanted){CHECK(count(3,1)==0&&count(2,BQ2589X_REG_00)==0);}
  sequential++;
 }
 reset(0,0,0,1,BQ2589X_VBUS_USB_SDP,1);bq.stopping=true;bq2589x_monitor_workfunc(&bq.monitor_work.work);CHECK(event_count==0&&unlocked());
 for(int repeat=0;repeat<50;repeat++)for(int action=0;action<10;action++){
  reset(0,0,0,repeat&1,BQ2589X_VBUS_USB_SDP,1);pause_pulse=true;pthread_t t;CHECK(!pthread_create(&t,NULL,monitor,NULL));while(!atomic_load(&asleep))sched_yield();CHECK(bq.hiz_pulse_active&&unlocked());
  int at=event_count;bq2589x_monitor_hiz_pulse(&bq);CHECK(event_count==at&&bq.hiz_pulse_active);
  int rc=0,expected=0,low=0x25;
  if(action==0){rc=request(PSY_IIO_MAIN_CHAGER_HZ,1);expected=1;}
  if(action==1)rc=request(PSY_IIO_MAIN_CHAGER_HZ,0);
  if(action==2)rc=request(PSY_IIO_MAIN_CHAGER_HZ,-1);
  if(action==3){rc=request(PSY_IIO_MAIN_CHAGER_HZ,1);CHECK(!rc);rc=request(PSY_IIO_MAIN_CHAGER_HZ,0);}
  if(action==4){rc=request(PSY_IIO_MAIN_CHAGER_HZ,0);CHECK(!rc);rc=request(PSY_IIO_MAIN_CHAGER_HZ,1);expected=1;}
  if(action==5)rc=request(PSY_IIO_OTG_ENABLE,1);
  if(action==6){WRITE_ONCE(bq.stopping,true);expected=1;}
  if(action==7){if(repeat&1){fail_write=-EREMOTEIO;fail_write_at=write_calls+1;}else{fail_read=-EREMOTEIO;fail_from_call=read_calls+1;fail_count=3;}rc=request(PSY_IIO_MAIN_CHAGER_HZ,1);CHECK(rc==-EREMOTEIO);fail_write=fail_read=0;rc=0;expected=1;}
  if(action==8){rc=request(PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,1000);low=(1000-BQ2589X_IINLIM_BASE)/BQ2589X_IINLIM_LSB;}
  if(action==9)rc=request(PSY_IIO_CHARGING_ENABLED,0);
  CHECK(!rc&&unlocked());at=event_count;atomic_store(&released,1);CHECK(!pthread_join(t,NULL));
  CHECK(!!(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK)==expected);CHECK((registers[BQ2589X_REG_00]&~BQ2589X_ENHIZ_MASK)==low);CHECK(!bq.hiz_pulse_active&&unlocked());CHECK(writes_after(at,BQ2589X_REG_00)==(action>=8?1:0));
  CHECK(count(4,1)==(action==6?0:1));if(action==5)CHECK(bq.cfg.otg_status&&!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));if(action==9)CHECK(!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));concurrent++;
 }
 int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};
 for(int apply=0;apply<2;apply++)for(int kind=1;kind<=2;kind++)for(int at=1;at<=(kind==1?3:2);at++)for(int e=0;e<5;e++){
  reset(0,0,0,1,BQ2589X_VBUS_USB_SDP,1);failed_write_applied=apply;if(kind==1){fail_read=errors[e];fail_from_call=at;fail_count=3;}else{fail_write=errors[e];fail_write_at=at;}
  bq2589x_monitor_hiz_pulse(&bq);CHECK(last_error==errors[e]&&failure_event>=0);CHECK(!bq.hiz_pulse_active&&unlocked()&&!bq.hiz_requested&&bq.hiz_request_seq==0);CHECK((registers[BQ2589X_REG_00]&~BQ2589X_ENHIZ_MASK)==0x25);
  bool expected=(kind==1&&at==3)||(kind==2&&at==2&&!apply);CHECK(!!(registers[BQ2589X_REG_00]&BQ2589X_ENHIZ_MASK)==expected);if(kind==1&&at==1)CHECK(write_calls==0&&count(3,1)==0);else CHECK(count(3,1)==1);faults++;
 }
 /* A failed deliberate HiZ request retains its intent for the next monitor pass. */
 reset(0,0,1,1,BQ2589X_VBUS_USB_SDP,1);fail_write=-EIO;fail_write_at=1;CHECK(request(PSY_IIO_MAIN_CHAGER_HZ,1)==-EIO);CHECK(bq.hiz_requested&&bq.hiz_request_seq==1);fail_write=0;int before=count(2,BQ2589X_REG_00);bq2589x_monitor_workfunc(&bq.monitor_work.work);CHECK(count(2,BQ2589X_REG_00)==before);CHECK(!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));
 /* Replay each HiZ transfer failure through the complete hot monitor callback. */
 reset(0,0,1,1,BQ2589X_VBUS_USB_SDP,1);bq2589x_monitor_workfunc(&bq.monitor_work.work);int read_at[3],write_at[2],nr=0,nw=0,rd=0,wr=0;
 for(int i=0;i<event_count;i++){if(events[i].kind==1){rd++;if(events[i].a==BQ2589X_REG_00)read_at[nr++]=rd;}if(events[i].kind==2){wr++;if(events[i].a==BQ2589X_REG_00)write_at[nw++]=wr;}}
 CHECK(nr==3&&nw==2);
 for(int chip=0;chip<2;chip++)for(int apply=0;apply<2;apply++)for(int phase=0;phase<5;phase++)for(int e=0;e<5;e++){
  reset(0,0,1,chip,BQ2589X_VBUS_USB_SDP,1);failed_write_applied=apply;if(phase<3){fail_read=errors[e];fail_from_call=read_at[phase];fail_reg=BQ2589X_REG_00;fail_count=3;}else{fail_write=errors[e];fail_write_at=write_at[phase-3];}
  bq2589x_monitor_workfunc(&bq.monitor_work.work);CHECK(last_error==errors[e]);CHECK(count(7,POWER_SUPPLY_PROP_VOLTAGE_NOW)==1);CHECK(!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));CHECK(!bq.hiz_pulse_active&&unlocked()&&count(4,1)==1);thermal_faults++;
 }
 printf("M43_HIZ_ORDER=PASS; assertions=%d; sequential=%d; concurrent=%d; bus_faults=%d; thermal_faults=%d; actual_monitor_iio_otg_thermal_stop_and_input_current_preserved\n",assertions,sequential,concurrent,faults,thermal_faults);
#endif
 return 0;
}
'''
 return const+stub+'\n'+enum+'\n'+defs+'\n#define OLD_SOURCE '+str(int(old))+'\n'+'\n\n'.join(body)+'\n'+tests
def run(source):
 with tempfile.TemporaryDirectory(prefix='m43-hiz-order-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(harness(Path(source).read_text()));subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  return subprocess.run([str(exe)],capture_output=True,text=True,timeout=30)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('source',type=Path);r=run(a.parse_args().source);print(r.stdout,end='');print(r.stderr,end='',file=__import__('sys').stderr);raise SystemExit(r.returncode)
