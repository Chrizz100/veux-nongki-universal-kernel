"""Run immutable M42 charging tests with actual M43 HiZ helpers and private storage."""
import importlib.util,os,sys
from pathlib import Path
from native_hiz_order import function
def run(source):
 parent=Path(os.environ['M42_DIR']);s=importlib.util.spec_from_file_location('frozen_m42_charge_test',parent/'Tests/native_charge_order.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);old=m.harness
 def extended(src):
  c=old(src);c=c.replace('bool charge_requested, vindpm_active, stopping;','uint64_t hiz_request_seq; bool hiz_requested,hiz_pulse_active; bool charge_requested, vindpm_active, stopping;')
  base=(Path(os.environ['M40_DIR'])/'After/drivers/power/supply/qcom/bq2589x_charger.c').read_text()
  for n in ['bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode']:c=c.replace(function(base,n),function(src,n),1)
  target=function(src,'bq2589x_enter_hiz_mode')
  c=c.replace(target,function(src,'__bq2589x_set_hiz')+'\n'+function(src,'bq2589x_set_hiz_request')+'\n'+target,1);return c
 m.harness=extended
 try:return m.run(source)
 finally:m.harness=old
if __name__=='__main__':
 r=run(Path(sys.argv[1]));print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr);raise SystemExit(r.returncode)
