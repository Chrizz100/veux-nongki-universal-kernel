VEUX M43 – HiZ-Eingangssperre über Monitor-Impuls erhalten – NOFLASH

Geprüfter Ausgang: Run 44035121259, Commit cea7e75a5ba32d71d99ea024d97e1d9cfc07c28a.
Alle 32 Artefakte unabhängig heruntergeladen und geprüft: 1.577 Dateien,
1.488 Textdateien und 413 JSON-Berichte. Prüfsummen/ZIP-CRC/Dateipfade gültig.
Alte Compilerfehler sind mitgeführte Zwischenstufen. Alle sechs betroffenen
Ziele wurden später erfolgreich gebaut; der fertige M42-Bau hat 40 erfolgreiche
make-Aufrufe, 1.423 passende OEM-Import-CRCs und 37 passende bekannte Module.
.config, eingebettete Konfiguration, vmlinux und autoconf sind konsistent.
Boot.img und AK3 wurden unabhängig neu erzeugt und sind bytegleich zum Lauf.
Kennung: 5.4.274-qgki-g82179e362f33. Das beweist nicht die Identität aller
historischen Quellen oder die Funktionsfähigkeit auf dem Telefon.

M43 korrigiert einen separat reproduzierten Fehler im echten BQ-Monitor:
Ein schon aktives oder während des 1-ms-Impulses angefordertes HiZ durfte zuvor
anschließend wieder gelöscht werden. Jetzt erhält der Impuls den anfänglichen
Zustand und verwirft eine veraltete Wiederherstellung nach neueren IIO-/OTG-
Befehlen oder beginnender Abschaltung. Auch ein fehlgeschlagener neuer HiZ-
Busbefehl entwertet die alte Wiederherstellung. Die Sperre bleibt während der
Wartezeit frei. Alle übrigen Bits im gemeinsam genutzten REG00 bleiben erhalten.
Nur der private BQ-Treiber wird geändert; WT, Header, Defconfig, Release und
vollständige Exporttabellen-Prüfung bleiben erhalten. Alle M42-/M41-/M40-
Werkzeuge werden unverändert per Commit und SHA geladen. Der neue BQ-Postimage
ist ausdrücklich zusätzlich gepinnt. Quell-, Objekt-, CFI-, Link-, Konfigurations-,
ABI- und Boot-/AK3-Nachweise sind im neuen GitHub-Lauf zwingend.

Lokale Prüfung: 13 Tests unter GCC 11.4 und 14.2 sowie UBSan bestanden.
47.850 native Prüfungen insgesamt: unter anderem 500 HiZ- und 350 Lade-
Parallelabläufe, 100 Fehlerfälle im kompletten heißen Monitor und 6.960
IIO-Schreibfehlerfälle. Der vollständige geänderte Treiber kompiliert als
ARM64 ThinLTO/CFI mit dem ursprünglichen AOSP Clang 12.0.5 und echten Headern.
Paket-Lader, alle 19 realen Git-Vorprüfungen und die unveränderten M41-/M42-
Tests wurden ebenfalls mit GCC 11.4 ausgeführt. Neuer vollständiger M43-
Kernel-Neubau und dessen statisches Boot-/AK3-Paar folgen erst auf GitHub.

Upload vom Smartphone:
1. VEUX_M43_MAIN.zip unverändert ins Hauptverzeichnis der GitHub-Repo hochladen.
2. VEUX_M43_YAML.zip entpacken. Die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml
   am gleichen Pfad ersetzen. Den festen Workflow-Dateinamen beibehalten.
3. Workflow „VEUX M43 Preserve HiZ Requests across Monitor Pulse - NOFLASH“
   manuell starten. Die alten Basen lädt die YAML automatisch unverändert nach.

Offen: Fehler-Reset/Reinitialisierung unter vorhandenen Lade-/HiZ-/OTG-Befehlen,
WT-/Provider-Lebensdauer und Probe-Abbruch, restliche Werte-/Board-Abgleiche,
historische Gesamtabweichungen, danach Gerätetests mit Wiederherstellung.
Kein Device Pass. Keine Flash-Freigabe.
