# VEUX M52 · F2FS-Checkpoint und Ladetreiber

M52 verwendet den vollständig gebauten Quellstand aus GitHub-Lauf 45006367282. Der bestätigte M51-Kernel hat die Kennung 5.4.274-qgki-g82179e362f33. Seine Konfiguration weicht in 53 Punkten von Xiaomis 5.4.274 ab. M52 ergänzt CONFIG_F2FS_CP_OPT. Die lokale Kbuild-Konfiguration enthält damit 52 Abweichungen. Die vollständige Liste steht in Restkonfiguration.csv.

## GitHub

1. VEUX_M52_MAIN.zip als ZIP im Hauptverzeichnis des Repos Chrizz100/veux-nongki-universal-kernel speichern.
2. VEUX_M52_F2FS_NOFLASH.yml im gleichen Branch unter .github/workflows/ speichern.
3. Den Workflow „VEUX M52 – F2FS-Checkpoint, QGKI 5.4.274“ auf diesem Branch manuell starten.

GitHub lädt den verifizierten M51-Quellstand aus Artefakt 14748687435 und die Xiaomi-Bootreferenz aus Artefakt 14706022228. Beide müssen zu diesem Zeitpunkt verfügbar sein. Die Konfiguration und die Quelländerungen werden vor dem Vollbau geprüft. Die Kompilierung verwendet Android Clang 12.0.5 aus demselben Git-Quellstand wie M51.

## Änderungen

Bei einer erfolgreichen Änderung erweiterter Verzeichnisattribute setzte M51 ein dateisystemweites Checkpoint-Flag. Dadurch konnte auch fsync für eine Datei in einem anderen Verzeichnis einen Checkpoint auslösen. Im Xiaomi-Boot-Image sind CONFIG_F2FS_CP_OPT=y und die F2FS-Diagnosetexte für geänderte Elternattribute belegt. Die öffentliche Referenz für die Funktionsweise ist MiCode/Xiaomi_Kernel_OpenSource, Commit 61397e524093d1ccb94769b5460825e2eaf8871e, Kernel 5.4.134.

M52 merkt sich betroffene Verzeichnisse bis zum erfolgreichen Checkpoint. Dafür nutzt der 5.4.274-Port eine XArray mit Inode-Nummern. Eine Verdrängung des Inodes aus dem Cache erhält die Zuordnung. Kann der Kernel den Eintrag wegen Speichermangels nicht anlegen, erzwingt er wieder den dateisystemweiten Checkpoint. Bei einem unbekannten Elternverzeichnis greift der konservative Checkpoint-Pfad. Nach einem Checkpoint-Fehler kann fsync den Fehler zurückgeben, bevor es die Schreibmarkierungen des Inodes löscht.

Die einzige Compilerwarnung im M51-Image-Bau betraf bq2589x_write_byte. Die private Funktion hatte keinen Aufrufer. M52 entfernt diese Funktion. Beim lokalen Vergleich waren alle 56 ausführbaren ELF-Abschnitte des separat gelinkten Ladetreibers bytegleich.

## Prüfumfang

- Die Hosttests verwenden die kompilierten C-Pfade aus dem Patch und die XArray-Implementierung des Kernelbaums. Sie testen unter anderem 2.048 Verzeichnisse, das erneute Auffinden des Elternverzeichnisses, Speichermangel, harte Links, vorhandene Checkpoint-Gründe, fehlgeschlagenen Commit und Wiederholung. Für I/O und die VFS-Umgebung verwendet der Test simulierte Rückgaben.
- Die Vorprüfung baut den gesamten F2FS-Ordner und den Ladetreiber für ARM64. Sie linkt F2FS separat und kontrolliert die kompilierten Aufrufe zur Erfassung, Abfrage und Freigabe der Markierungen. Sie prüft den VEUX-Gerätebaum gegen M51 und wiederholt die Bootinfo-Tests.
- Der GitHub-Vollbau prüft Image, vmlinux, eingebettete Konfiguration, Kernelkennung, vier gebaute Module, Stock-Bootlayout sowie 3.148 Importe aus 37 Vendor-Modulen. Die Resultate stehen unter KERNEL-NACHWEISE. Der gebaute Quellstand steht unter QUELLSTAND.
- Ein Mount- und Wiederanlauftest mit dem fertigen M52-Kernel, ein Start auf dem VEUX sowie ein praktisch bestätigter Wiederherstellungsweg sind offen. Das Paket ist ein GitHub-Baupaket. Eine Flash-Freigabe steht aus.
