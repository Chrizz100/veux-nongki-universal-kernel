// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <sys/stat.h>
#include "test.h"
#include <linux/slab.h>

static bool fail_alloc;
extern void *__real_kmem_cache_alloc(struct kmem_cache *, int);
void *__wrap_kmem_cache_alloc(struct kmem_cache *cachep, int flags)
{
	return fail_alloc ? NULL : __real_kmem_cache_alloc(cachep, flags);
}
#define GFP_NOFS (__GFP_RECLAIM | __GFP_IO)
#define __GFP_NORETRY 0x1000u
enum { SBI_NEED_CP, FASTBOOT, TRANS_DIR_INO, FSYNC_MODE_STRICT, FI_APPEND_WRITE, FI_UPDATE_WRITE };
struct f2fs_sb_info {
	struct xarray xattr_dirs;
	bool global, space, node, fastboot, need_dentry, trans, cp_error;
	int active_logs, fsync_mode, commit_error, discarded, prefree;
};
struct inode {
	struct f2fs_sb_info *i_sb;
	unsigned int i_mode, i_nlink, i_ino, i_pino;
	bool compressed, wrong, append, update, fixed;
};
#define F2FS_I_SB(i) ((i)->i_sb)
#define F2FS_I(i) (i)
#define F2FS_OPTION(s) (*(s))
#define f2fs_compressed_file(i) ((i)->compressed)
#define file_wrong_pino(i) ((i)->wrong)
#define f2fs_space_for_roll_forward(s) ((s)->space)
#define f2fs_is_checkpointed_node(s,p) ((s)->node)
#define test_opt(s,opt) ((s)->fastboot)
#define is_sbi_flag_set(s,f) ((s)->global)
#define set_sbi_flag(s,f) ((s)->global = true)
#define clear_sbi_flag(s,f) ((s)->global = false)
#define f2fs_need_dentry_mark(s,i) ((s)->need_dentry)
#define f2fs_exist_written_data(s,i,t) ((s)->trans)
#define do_checkpoint(s,c) ((s)->commit_error)
#define f2fs_release_discard_addrs(s) ((s)->discarded++)
#define f2fs_clear_prefree_segments(s,c) ((s)->prefree++)
#define f2fs_sync_fs(s,wait) ((s)->commit_error)
#define f2fs_cp_error(s) ((s)->cp_error)
#define try_to_fix_pino(i) ((i)->fixed = true)
#define clear_inode_flag(i,f) ((f)==FI_APPEND_WRITE ? ((i)->append=false) : ((i)->update=false))
#include "production.inc"

int main(void)
{
	struct f2fs_sb_info sb = { .space=true, .node=true, .active_logs=6 };
	struct inode dir = {.i_sb=&sb,.i_mode=S_IFDIR,.i_nlink=2,.i_ino=101};
	struct inode child = {.i_sb=&sb,.i_mode=S_IFREG,.i_nlink=1,.i_ino=700,.i_pino=101};
	struct inode other = child;
	other.i_pino=202;
	rcu_register_thread();
	radix_tree_init();
	xa_init(&sb.xattr_dirs);
	f2fs_track_dir_xattr(&child);
	assert(!sb.global && xa_empty(&sb.xattr_dirs));
	f2fs_track_dir_xattr(&dir);
	f2fs_track_dir_xattr(&dir);
#ifdef CONFIG_F2FS_CP_OPT
	assert(!sb.global && need_do_checkpoint(&child)==CP_PARENT_XATTR_SET);
	assert(need_do_checkpoint(&other)==CP_NO_NEEDED);
	child.i_pino=0;
	assert(need_do_checkpoint(&child)==CP_WRONG_PINO);
	child.i_pino=101;
	for (unsigned int i=1000;i<3048;i++) {
		dir.i_ino=i;
		f2fs_track_dir_xattr(&dir);
		assert(xa_load(&sb.xattr_dirs,i)==xa_mk_value(1));
	}
	/* A fresh inode instance still finds the same tracked parent by number. */
	struct inode reopened=child;
	assert(need_do_checkpoint(&reopened)==CP_PARENT_XATTR_SET);
	sb.commit_error=-EIO;
	commit_fixture(&sb,0);
	assert(sb.discarded==1 && sb.prefree==0);
	assert(need_do_checkpoint(&child)==CP_PARENT_XATTR_SET);
	/* Need a new radix node, so the injected allocation failure is observed. */
	dir.i_ino=0x71000001u;
	fail_alloc=true;
	f2fs_track_dir_xattr(&dir);
	fail_alloc=false;
	assert(sb.global && !xa_load(&sb.xattr_dirs,dir.i_ino));
	assert(need_do_checkpoint(&other)==CP_SB_NEED_CP);
	commit_fixture(&sb,0);
	assert(sb.global && xa_load(&sb.xattr_dirs,101));
#else
	assert(sb.global && xa_empty(&sb.xattr_dirs));
	assert(need_do_checkpoint(&other)==CP_SB_NEED_CP);
#endif
	sb.commit_error=0;
	commit_fixture(&sb,0);
	assert(xa_empty(&sb.xattr_dirs) && !sb.global && sb.prefree==1);
	assert(need_do_checkpoint(&child)==CP_NO_NEEDED);
	child.wrong=true; assert(need_do_checkpoint(&child)==CP_WRONG_PINO);
	child.i_nlink=2; assert(need_do_checkpoint(&child)==CP_HARDLINK);
	child.i_nlink=1; child.wrong=false;
	sb.space=false; assert(need_do_checkpoint(&child)==CP_NO_SPC_ROLL);
	sb.space=true; sb.node=false; assert(need_do_checkpoint(&child)==CP_NODE_NEED_CP);
	sb.node=true; sb.fastboot=true; assert(need_do_checkpoint(&child)==CP_FASTBOOT_MODE);
	sb.fastboot=false; sb.active_logs=2; assert(need_do_checkpoint(&child)==CP_SPEC_LOG_NUM);
	sb.active_logs=6; sb.fsync_mode=FSYNC_MODE_STRICT; sb.trans=sb.need_dentry=true;
	assert(need_do_checkpoint(&child)==CP_RECOVER_DIR);
	assert(need_do_checkpoint(&dir)==CP_NON_REGULAR);
	child.compressed=true; assert(need_do_checkpoint(&child)==CP_COMPRESSED);
	child.append=child.update=true;
	sb.commit_error=-EAGAIN;
	assert(sync_fixture(&child)==-EAGAIN && child.append && child.update && !child.fixed);
	sb.commit_error=0; sb.cp_error=true;
	assert(sync_fixture(&child)==-EIO && child.append && child.update && !child.fixed);
	sb.cp_error=false;
	assert(sync_fixture(&child)==0 && !child.append && !child.update && child.fixed);
	dir.i_ino=101;
	f2fs_track_dir_xattr(&dir);
	xa_destroy(&sb.xattr_dirs);
	radix_tree_cpu_dead(1);
	rcu_barrier();
	assert(nr_allocated==0);
	rcu_unregister_thread();
#ifdef CONFIG_F2FS_CP_OPT
	puts("PASS F2FS_CP_OPT=y: real XArray, 2048 directories, ENOMEM fallback, checkpoint error/retry and fsync decisions");
#else
	puts("PASS F2FS_CP_OPT=n: global checkpoint fallback and fsync error propagation");
#endif
	return 0;
}
