"""Authenticate the M51 source and extract the matching Xiaomi reference image."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, write, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m51.zip') as archive:
    require(sha(work/'m51.zip')=='df5897d0c0171a17742b62fd3b5534cab7ae6c0308f7536985ac740a3f321bdf', 'M51 artifact digest')
    manifest=json.loads(archive.read('M51_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M51 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M51 config identity')
    archive.extract('M51-kernel-source.tar.gz',work)
tar=work/'M51-kernel-source.tar.gz'
require(sha(tar)=='9e01b1092d704a1a349127e0fe7b3d31b0ea40165f105eb8056bf87965515176','M51 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'f2fs-checkpoint.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-e','F2FS_CP_OPT'],check=True)
