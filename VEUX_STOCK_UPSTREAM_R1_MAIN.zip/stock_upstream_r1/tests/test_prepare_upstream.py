"""Regression tests using isolated local Git fixtures; no simulated Linux build."""
from __future__ import annotations
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

BASE = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "scripts"))
from prepare_upstream import run, protected, delta_paths  # noqa: E402


def command(path, *args):
    r = subprocess.run(["git", "-C", str(path), *args], check=True,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return r.stdout.decode().strip()


def init_repo(path):
    path.mkdir()
    command(path, "init", "-q")
    command(path, "config", "user.email", "fixture@example.invalid")
    command(path, "config", "user.name", "Fixture")


def commit(path, message):
    command(path, "add", "-A")
    command(path, "commit", "-q", "-m", message)
    return command(path, "rev-parse", "HEAD")


def file(path, name, content):
    target = path / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")


class TestPrepareUpstream(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.xiaomi = self.root / "xiaomi"
        self.aosp = self.root / "aosp"
        self.out = self.root / "out"
        self.manifest = self.root / "manifest.json"
        init_repo(self.xiaomi)
        init_repo(self.aosp)
        orig = {
            "drivers/misc/safe.c": "int safe = 134;\n",
            "drivers/misc/diverged.c": "int fork = 134;\n",
            "kernel/sched/walt/walt.c": "int oem_sched = 134;\n",
            "drivers/misc/deleted.c": "int deleted = 134;\n",
            "drivers/misc/already.c": "int already = 134;\n",
        }
        for path, content in orig.items():
            file(self.aosp, path, content)
            file(self.xiaomi, path, content)
        file(self.xiaomi, "drivers/misc/diverged.c", "int xiaomi_variant = 123;\n")
        file(self.xiaomi, "drivers/misc/already.c", "int already = 274;\n")
        file(self.xiaomi, "arch/arm64/configs/vendor/veux_QGKI.config", "CONFIG_SCHED_WALT=y\nCONFIG_QGKI=y\n")
        file(self.aosp, "Makefile", "VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 134\n")
        file(self.xiaomi, "Makefile", "VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 134\n")
        aosp134 = commit(self.aosp, "aosp134")
        command(self.aosp, "tag", "android11-5.4.134_r00")
        file(self.aosp, "Makefile", "VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n")
        file(self.aosp, "drivers/misc/safe.c", "int safe = 274;\n")
        file(self.aosp, "drivers/misc/diverged.c", "int fork = 274;\n")
        file(self.aosp, "kernel/sched/walt/walt.c", "int oem_sched = 274;\n")
        file(self.aosp, "drivers/misc/already.c", "int already = 274;\n")
        (self.aosp / "drivers/misc/deleted.c").unlink()
        file(self.aosp, "drivers/misc/new.c", "int added = 274;\n")
        aosp274 = commit(self.aosp, "aosp274")
        command(self.aosp, "tag", "android11-5.4.274_r00")
        xsha = commit(self.xiaomi, "xiaomi134")
        config_sha = command(self.xiaomi, "rev-parse", f"{xsha}:arch/arm64/configs/vendor/veux_QGKI.config")
        self.data = {
            "schema": "veux-stock-upstream-plan-v1",
            "source_oem": {"commit": xsha, "kernel_version": "5.4.134", "config_path":
                           "arch/arm64/configs/vendor/veux_QGKI.config", "config_git_blob": config_sha},
            "source_android_common": {"baseline_commit": aosp134, "target_commit": aosp274,
                                      "baseline_tag": "android11-5.4.134_r00",
                                      "target_tag": "android11-5.4.274_r00",
                                      "baseline_kernel_version": "5.4.134",
                                      "target_kernel_version": "5.4.274"},
        }
        self.manifest.write_text(json.dumps(self.data))

    def test_safe_staging_without_oem_loss(self):
        self.assertIn(("M", "drivers/misc/safe.c"), delta_paths(self.aosp, self.data["source_android_common"]["baseline_commit"], self.data["source_android_common"]["target_commit"]))
        result = run(self.manifest, self.xiaomi, self.aosp, self.out)
        self.assertEqual(result["status"], "SOURCE_STAGE_PARTIAL_NOT_A_BUILD_NOT_FLASHABLE")
        self.assertEqual(result["staged_paths_count"], 1)
        self.assertGreaterEqual(result["counts"]["PROTECTED_OEM"], 1)
        self.assertEqual(result["counts"]["ALREADY_TARGET"], 1)
        self.assertGreaterEqual(result["counts"]["OEM_DIVERGED_OR_MISSING"], 1)
        self.assertEqual((self.xiaomi / "drivers/misc/safe.c").read_text(), "int safe = 274;\n")
        self.assertEqual((self.xiaomi / "drivers/misc/diverged.c").read_text(), "int xiaomi_variant = 123;\n")
        self.assertEqual((self.xiaomi / "kernel/sched/walt/walt.c").read_text(), "int oem_sched = 134;\n")
        self.assertEqual((self.xiaomi / "drivers/misc/deleted.c").read_text(), "int deleted = 134;\n")
        self.assertFalse((self.xiaomi / "drivers/misc/new.c").exists())
        self.assertEqual(result["source_version_after_staging"], "5.4.134")
        self.assertFalse(result["vendor_abi_checked"])
        patch = (self.out / "SAFE_EXACT_PREIMAGE_SOURCE_ONLY.patch").read_text()
        self.assertIn("drivers/misc/safe.c", patch)
        self.assertNotIn("kernel/sched/walt/walt.c", patch)

    def test_reject_wrong_oem_pin(self):
        self.data["source_oem"]["commit"] = "0" * 40
        self.manifest.write_text(json.dumps(self.data))
        with self.assertRaisesRegex(RuntimeError, "expected"):
            run(self.manifest, self.xiaomi, self.aosp, self.out)

    def test_reject_tampered_oem_config_pin(self):
        self.data["source_oem"]["config_git_blob"] = "0" * 40
        self.manifest.write_text(json.dumps(self.data))
        with self.assertRaisesRegex(RuntimeError, "defconfig blob"):
            run(self.manifest, self.xiaomi, self.aosp, self.out)

    def test_reject_wrong_aosp_pin(self):
        self.data["source_android_common"]["target_commit"] = "0" * 40
        self.manifest.write_text(json.dumps(self.data))
        with self.assertRaisesRegex(RuntimeError, "expected"):
            run(self.manifest, self.xiaomi, self.aosp, self.out)

    def test_reject_dirty_oem_checkout(self):
        file(self.xiaomi, "drivers/misc/safe.c", "changed by user")
        with self.assertRaisesRegex(RuntimeError, "clean"):
            run(self.manifest, self.xiaomi, self.aosp, self.out)

    def test_protected_policy(self):
        for p in ("kernel/sched/walt/walt.c", "drivers/soc/qcom/foo.c",
                  "arch/arm64/configs/vendor/veux_QGKI.config", "kernel/module.c"):
            self.assertTrue(protected(p))
        self.assertFalse(protected("drivers/misc/safe.c"))

    def test_wrong_source_version_blocked(self):
        file(self.aosp, "Makefile", "VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 275\n")
        aosp_wrong = commit(self.aosp, "invalid version")
        command(self.aosp, "tag", "-f", "android11-5.4.274_r00", aosp_wrong)
        self.data["source_android_common"]["target_commit"] = aosp_wrong
        self.manifest.write_text(json.dumps(self.data))
        with self.assertRaisesRegex(RuntimeError, "versions"):
            run(self.manifest, self.xiaomi, self.aosp, self.out)


if __name__ == "__main__":
    unittest.main()
