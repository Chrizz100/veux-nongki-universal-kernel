#!/usr/bin/env python3
"""Stage conservative file-level Android 5.4.134->274 changes on Xiaomi VEUX OEM.

The result is a PARTIAL source overlay for review; never a build/flash candidate.
No fuzzy patching, no force-loading modules, no automatic replacement of OEM-divergent files.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

PROTECTED_PREFIXES = (
    "arch/arm64/configs/", "kernel/sched/", "drivers/soc/qcom/",
    "drivers/cpufreq/", "drivers/clk/qcom/", "drivers/gpu/",
    "drivers/net/wireless/", "drivers/input/touchscreen/",
    "security/selinux/", "techpack/", "vendor/",
)
PROTECTED_FILES = frozenset({
    "Makefile", "kernel/module.c", "include/linux/sched.h", "include/linux/sched/task.h",
    "include/linux/cpufreq.h", "include/trace/events/sched.h",
    "arch/arm64/Makefile", "drivers/mmc/core/core.c",
})
SHA40 = re.compile(r"^[0-9a-f]{40}$")


def git(repo: Path, *args: str, input_data: bytes | None = None,
        check: bool = True) -> bytes:
    p = subprocess.run(["git", "-C", str(repo), *args], input=input_data,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if check and p.returncode:
        raise RuntimeError(f"git {' '.join(args[:4])} failed: {p.stderr.decode(errors='replace')[:500]}")
    return p.stdout if p.returncode == 0 else b""


def oid(repo: Path, rev: str, path: str) -> str | None:
    if not SHA40.fullmatch(rev):
        raise ValueError("revision must be a complete pinned SHA")
    s = git(repo, "rev-parse", "--verify", f"{rev}:{path}", check=False).decode().strip()
    return s if SHA40.fullmatch(s) else None


def mode(repo: Path, rev: str, path: str) -> str | None:
    s = git(repo, "ls-tree", rev, "--", path, check=True).decode(errors="replace").strip()
    if not s:
        return None
    # sample: 100644 blob <sha>\tpath ; only one exact path is acceptable.
    try:
        head, found = s.split("\t", 1)
        m, typ, _ = head.split(" ")
    except ValueError as e:
        raise RuntimeError(f"unexpected git ls-tree output for {path!r}") from e
    if found != path or typ != "blob":
        raise RuntimeError(f"non-blob/unexpected path in tree: {path!r}")
    return m


def tree_index(repo: Path, rev: str) -> dict[str, tuple[str, str, str]]:
    """Read Git objects in ONE process, rather than three rev-parse calls per path."""
    data = git(repo, "ls-tree", "-r", "-z", rev)
    files = {}
    for row in data.split(b"\x00"):
        if not row:
            continue
        meta, rawname = row.split(b"\t", 1)
        m, typ, sha = meta.decode("ascii").split(" ")
        name = rawname.decode("utf-8", errors="surrogateescape")
        files[name] = (m, typ, sha)
    return files


def version(repo: Path, rev: str) -> str:
    content = git(repo, "show", f"{rev}:Makefile").decode(errors="replace")
    values = {}
    for field in ("VERSION", "PATCHLEVEL", "SUBLEVEL"):
        m = re.search(rf"^{field}\s*=\s*(\d+)\s*$", content, re.MULTILINE)
        if not m:
            raise RuntimeError(f"{field} missing from Makefile")
        values[field] = m.group(1)
    return ".".join(values[x] for x in ("VERSION", "PATCHLEVEL", "SUBLEVEL"))


def validate_sha(rev: str) -> None:
    if not SHA40.fullmatch(rev):
        raise ValueError(f"invalid commit pin {rev!r}")


def protected(path: str) -> bool:
    return path in PROTECTED_FILES or path.startswith(PROTECTED_PREFIXES)


def delta_paths(common: Path, before: str, after: str) -> list[tuple[str, str]]:
    out = git(common, "diff", "--no-ext-diff", "--no-renames", "--name-status", "-z", before, after)
    tokens = out.split(b"\x00")
    if tokens[-1] != b"":
        raise RuntimeError("git diff -z not NUL-terminated")
    tokens.pop()
    if len(tokens) % 2:
        raise RuntimeError("git diff --name-status unexpected token count")
    changed = []
    for status, path in zip(tokens[::2], tokens[1::2]):
        s = status.decode("ascii")
        p = path.decode("utf-8", errors="surrogateescape")
        if p.startswith("/") or ".." in p.split("/") or not p:
            raise RuntimeError("unsafe upstream path")
        changed.append((s, p))
    return changed


def resolve_safe_path(base: Path, path: str) -> Path:
    dest = base.joinpath(*path.split("/"))
    if not dest.resolve(strict=False).is_relative_to(base.resolve()):
        raise RuntimeError(f"path escapes checkout: {path}")
    return dest


def run(manifest: Path, xiaomi: Path, common: Path, output: Path) -> dict:
    data = json.loads(manifest.read_text(encoding="utf-8"))
    assert data["schema"] == "veux-stock-upstream-plan-v1"
    oem = data["source_oem"]
    android = data["source_android_common"]
    osha = oem["commit"]
    base = android["baseline_commit"]
    target = android["target_commit"]
    for s in (osha, base, target):
        validate_sha(s)
    xiaomi = xiaomi.resolve()
    common = common.resolve()
    output = output.resolve()
    if output == xiaomi or output == common or output.is_relative_to(xiaomi) or output.is_relative_to(common):
        raise RuntimeError("report directory must be outside both source trees")
    output.mkdir(parents=True, exist_ok=True)
    actual = git(xiaomi, "rev-parse", "HEAD").decode().strip()
    if actual != osha:
        raise RuntimeError(f"MiCode expected {osha} but checked out {actual}")
    for expected, tag_key in ((base, "baseline_tag"), (target, "target_tag")):
        tag = android[tag_key]
        observed = git(common, "rev-parse", f"refs/tags/{tag}^{{commit}}").decode().strip()
        if observed != expected:
            raise RuntimeError(f"tag {tag} expected {expected} got {observed}")
    observed_versions = {
        "xiaomi": version(xiaomi, osha), "android134": version(common, base),
        "android274": version(common, target)
    }
    expected_versions = (oem["kernel_version"], android["baseline_kernel_version"],
                         android["target_kernel_version"])
    if tuple(observed_versions.values()) != expected_versions:
        raise RuntimeError(f"unexpected Makefile versions: {observed_versions}")
    config_path = oem["config_path"]
    config_oid = oid(xiaomi, osha, config_path)
    if config_oid != oem["config_git_blob"]:
        raise RuntimeError("OEM VEUX defconfig blob doesn't match GitHub pin")
    config = git(xiaomi, "show", f"{osha}:{config_path}").decode()
    for required in ("CONFIG_SCHED_WALT=y", "CONFIG_QGKI=y"):
        if required not in config.splitlines():
            raise RuntimeError(f"original Xiaomi defconfig missing {required}")
    if git(xiaomi, "status", "--porcelain"):
        raise RuntimeError("Xiaomi source tree must be clean before staging")

    oem_tree = tree_index(xiaomi, osha)
    before_tree = tree_index(common, base)
    after_tree = tree_index(common, target)
    rows: list[dict] = []
    counter = Counter()
    updated_files: list[str] = []
    for change, path in delta_paths(common, base, target):
        old_entry = before_tree.get(path)
        new_entry = after_tree.get(path)
        cur_entry = oem_tree.get(path)
        old = old_entry[2] if old_entry is not None and old_entry[1] == "blob" else None
        new = new_entry[2] if new_entry is not None and new_entry[1] == "blob" else None
        current = cur_entry[2] if cur_entry is not None and cur_entry[1] == "blob" else None
        status = "MANUAL_REVIEW"
        if protected(path):
            status = "PROTECTED_OEM"
        elif change == "M" and current == new and current is not None:
            status = "ALREADY_TARGET"
        elif change == "M" and old and new and current == old:
            modes = (old_entry[0], new_entry[0], cur_entry[0])
            if modes[0] == modes[1] == modes[2] and modes[0] in ("100644", "100755"):
                destination = resolve_safe_path(xiaomi, path)
                if not destination.is_file() or destination.is_symlink():
                    raise RuntimeError(f"unexpected OEM file type: {path}")
                destination.write_bytes(git(common, "cat-file", "blob", new))
                destination.chmod(int(modes[0], 8) & 0o777)
                if git(xiaomi, "hash-object", "--", path).decode().strip() != new:
                    raise RuntimeError(f"post-write SHA mismatch for {path}")
                status = "SAFE_STAGED_EXACT_PREIMAGE"
                updated_files.append(path)
            else:
                status = "MODE_MISMATCH"
        elif change == "M" and current != old:
            status = "OEM_DIVERGED_OR_MISSING"
        elif change == "A":
            status = "AOSP_NEW_FILE_REVIEW"
        elif change == "D":
            status = "AOSP_REMOVAL_REVIEW"
        else:
            status = "NONTRIVIAL_CHANGE_REVIEW"
        counter[status] += 1
        rows.append({"operation": change, "path": path, "result": status,
                     "aosp134_oid": old or "", "aosp274_oid": new or "", "xiaomi134_oid": current or ""})

    # Review patch is generated from a temporary OEM checkout only.
    patch = git(xiaomi, "diff", "--no-ext-diff", "--binary", "HEAD", "--")
    diff_check = subprocess.run(["git", "-C", str(xiaomi), "diff", "--check", "HEAD"],
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if diff_check.returncode:
        raise RuntimeError("git diff --check failed: " +
                           (diff_check.stdout + diff_check.stderr).decode(errors="replace")[:300])
    (output / "SAFE_EXACT_PREIMAGE_SOURCE_ONLY.patch").write_bytes(patch)
    with (output / "CHANGED_FILES.csv").open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=("operation", "path", "result", "aosp134_oid", "aosp274_oid", "xiaomi134_oid"))
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "status": "SOURCE_STAGE_PARTIAL_NOT_A_BUILD_NOT_FLASHABLE",
        "source_version_after_staging": version(xiaomi, "HEAD"),
        "stock_image_identical": False,
        "vendor_abi_checked": False,
        "walt_y_compile_checked": False,
        "kernel_build_checked": False,
        "security_patches_beyond_5_4_274_included": False,
        "bakasu_integrated": False,
        "susfs_integrated": False,
        "nomount_integrated": False,
        "source_version_verified": observed_versions,
        "exact_pins": {"xiaomi": osha, "aosp134": base, "aosp274": target},
        "config_pin_verified": config_oid,
        "counts": dict(sorted(counter.items())),
        "changed_paths_total": len(rows),
        "staged_paths_count": len(updated_files),
        "staged_patch_sha256": hashlib.sha256(patch).hexdigest(),
        "staged_patch_size": len(patch),
        "blocked_full_upstream": True,
        "reason": "OEM-diverged paths, protected paths, new files, removals and cross-file dependencies require review",
        "original_xiaomi_git_checkout_modified_only_in_runner_temp": True,
    }
    (output / "REPORT.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    readme = """VEUX STOCK 134->274 / SOURCE-ONLY STAGING (NO BUILD / NO FLASH)\n\n"""
    readme += f"Xiaomi OEM base: {osha} / Android Common 134: {base} / 274: {target}\n"
    readme += f"Changes: {len(rows)}; provably identical-preimage files staged: {len(updated_files)}\n"
    readme += "\nResults per file: CHANGED_FILES.csv; summary: REPORT.json.\n"
    readme += "The .patch contains only files with EXACT original AOSP134 blob matches and is NOT a complete update.\n"
    readme += "Vendor changes, scheduler WALT, new files, removals, modes, cross-file deps and module ABI remain blocked.\n"
    readme += "NEVER flash; do not mark 5.4.274 complete or use a version-number-only patch.\n"
    (output / "READ_ME_FIRST.txt").write_text(readme, encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--xiaomi", type=Path, required=True)
    parser.add_argument("--aosp", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    try:
        result = run(args.manifest, args.xiaomi, args.aosp, args.out)
        print(json.dumps({k: result[k] for k in ("status", "changed_paths_total", "staged_paths_count", "counts")}, indent=2))
        return 0
    except Exception as e:
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "ERROR.txt").write_text("FAIL CLOSED: " + str(e) + "\n")
        print(f"FAIL CLOSED: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
