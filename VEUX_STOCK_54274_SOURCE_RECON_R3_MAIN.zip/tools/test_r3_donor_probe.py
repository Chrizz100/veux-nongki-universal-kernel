import tempfile
import unittest
from pathlib import Path
import r3_donor_probe as r

SCHED='''#define __P(F) 42
#define   PM(F, M) __PS(#F, p->F & (M))
PM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED);
'''
VMSCAN='''static DEFINE_RWLOCK(shrinker_rwlock);

#ifdef CONFIG_MEMCG
'''+ ('\n'.join(['x(&shrinker_rwsem);']*7))+'\n'+ ('\n'.join(['x(&shrinker_rwlock);']*6))+'\n'

class Tests(unittest.TestCase):
 def test_sched_transform(self):
  s=r.transform_sched(SCHED);self.assertIn('SEQ_printf(m',s);self.assertIn('(long long)(p->F & (M))',s);self.assertNotIn('__PS(',s)
 def test_sched_missing_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_sched(SCHED.replace('PM(F, M)','ZZ(F, M)'))
 def test_sched_duplicate_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_sched(SCHED+ r.SCHED_FROM +'\n')
 def test_sched_predefined_is_blocked(self):
  with self.assertRaisesRegex(ValueError,'UNEXPECTED'):r.transform_sched(SCHED+'#define __PS x\n')
 def test_vmscan_transform(self):
  s=r.transform_vmscan(VMSCAN);self.assertIn('static DEFINE_RWSEM(shrinker_rwsem);',s);self.assertEqual(s.count('DEFINE_RWLOCK(shrinker_rwlock)'),1)
 def test_vmscan_wrong_use_count(self):
  with self.assertRaisesRegex(ValueError,'SEM_USE_DRIFT'):r.transform_vmscan(VMSCAN.replace('&shrinker_rwsem','&other',1))
 def test_vmscan_wrong_lock_count(self):
  with self.assertRaisesRegex(ValueError,'LOCK_USE_DRIFT'):r.transform_vmscan(VMSCAN.replace('&shrinker_rwlock','&other',1))
 def test_vmscan_reject_already_defined(self):
  with self.assertRaisesRegex(ValueError,'ALREADY_DEFINED'):r.transform_vmscan(VMSCAN+'static DEFINE_RWSEM(shrinker_rwsem);')
 def test_vmscan_missing_anchor(self):
  with self.assertRaisesRegex(ValueError,'ANCHOR_MISMATCH'):r.transform_vmscan(VMSCAN.replace('#ifdef CONFIG_MEMCG','#ifdef CONFIG_NOPE'))
 def test_report_on_failure(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d); (p/'log').write_text('foo.c:17:2: error: broken\nLLVM ERROR: IO failure on output stream: Broken pipe\n');(p/'rc').write_text('2\n')
   x=r.summarize(p/'log',p/'rc',p/'report.json');self.assertFalse(x['image_flashable']);self.assertEqual(x['status'],'PROBE_COMPILER_FAILED');self.assertTrue((p/'report.json').exists());self.assertEqual(x['llvm_broken_pipe_count'],1);self.assertEqual(x['compiler_error_count'],2)
 def test_report_on_success_is_still_noflash(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'log').write_text('done\n');(p/'rc').write_text('0\n');x=r.summarize(p/'log',p/'rc',p/'report.json');self.assertEqual(x['status'],'PROBE_COMPILED');self.assertFalse(x['image_distributable']);self.assertFalse(x['oem_abi_verified'])

if __name__=='__main__':unittest.main()
