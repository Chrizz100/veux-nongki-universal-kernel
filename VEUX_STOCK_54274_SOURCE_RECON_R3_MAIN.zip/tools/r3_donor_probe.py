#!/usr/bin/env python3
"""Fail-closed, diagnostic-only donor 5.4.268 source probe.

Does NOT repair/claim to reproduce an OEM 5.4.274 kernel. Only stages
proven, minimal fixes for two R2 compiler failures in a separate Git worktree.
No firmware/device files are written; output artifacts are text only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
ORIGINAL_BLOBS = {
    'kernel/sched/debug.c': '76f74c238a5a2dada979f0e779ba31dcf1c49b0f',
    'mm/vmscan.c': 'fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa',
}
SCHED_FROM = '#define   PM(F, M) __PS(#F, p->F & (M))'
SCHED_TO = '#define   PM(F, M) SEQ_printf(m, "%-45s:%21Ld\\n", #F, (long long)(p->F & (M)))'
VMSCAN_FROM = 'static DEFINE_RWLOCK(shrinker_rwlock);\n\n#ifdef CONFIG_MEMCG\n'
VMSCAN_TO = 'static DEFINE_RWLOCK(shrinker_rwlock);\n\n#ifdef CONFIG_MEMCG\nstatic DEFINE_RWSEM(shrinker_rwsem);\n'


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def checked_replace(data: str, old: str, new: str, label: str) -> str:
    count = data.count(old)
    if count != 1:
        raise ValueError(f'R3_SOURCE_ANCHOR_MISMATCH:{label}:expected_one_found_{count}')
    return data.replace(old, new, 1)


def transform_sched(source: str) -> str:
    if '#define __PS' in source or source.count('PM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED)') != 1:
        raise ValueError('R3_SCHED_UNEXPECTED_PREEXISTING_MACRO_OR_CALLS')
    return checked_replace(source, SCHED_FROM, SCHED_TO, 'SCHED_PM_PRINT')


def transform_vmscan(source: str) -> str:
    if 'DEFINE_RWSEM(shrinker_rwsem)' in source:
        raise ValueError('R3_VMSCAN_RWSEM_ALREADY_DEFINED')
    if source.count('&shrinker_rwsem') != 7:
        raise ValueError(f'R3_VMSCAN_SEM_USE_DRIFT:{source.count("&shrinker_rwsem")}')
    if source.count('&shrinker_rwlock') != 6:
        raise ValueError(f'R3_VMSCAN_LOCK_USE_DRIFT:{source.count("&shrinker_rwlock")}')
    return checked_replace(source, VMSCAN_FROM, VMSCAN_TO, 'VMSCAN_DECL')


def cmd(*args: str, cwd: Path) -> str:
    p = subprocess.run(args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode:
        raise RuntimeError(f'R3_GIT_ERROR:{" ".join(args[:4])}:rc={p.returncode}:{p.stderr[-800:]}')
    return p.stdout.strip()


def prepare(donor: Path, stage: Path, report: Path) -> dict:
    donor, stage, report = donor.resolve(), stage.resolve(), report.resolve()
    if not donor.is_dir() or not (donor/'.git').exists() or stage.exists():
        raise ValueError('R3_PREPARE_UNSAFE_SOURCE_OR_EXISTING_STAGE')
    if cmd('git','rev-parse','HEAD',cwd=donor) != DONOR_COMMIT:
        raise ValueError('R3_DONOR_COMMIT_DRIFT')
    if cmd('git','status','--porcelain',cwd=donor):
        raise ValueError('R3_DONOR_IS_DIRTY')
    for file, blob in ORIGINAL_BLOBS.items():
        if cmd('git','hash-object',file,cwd=donor) != blob:
            raise ValueError('R3_ORIGINAL_GIT_BLOB_DRIFT:'+file)
    cmd('git','worktree','add','--detach','-q',str(stage),DONOR_COMMIT,cwd=donor)
    patch = {
        'kernel/sched/debug.c':transform_sched,
        'mm/vmscan.c':transform_vmscan,
    }
    records = []
    for filename, fn in patch.items():
        file = stage/filename
        before = file.read_bytes()
        if cmd('git','hash-object',filename,cwd=stage) != ORIGINAL_BLOBS[filename]:
            raise ValueError('R3_STAGE_GIT_BLOB_DRIFT:'+filename)
        after = fn(before.decode('utf-8')).encode('utf-8')
        file.write_bytes(after)
        records.append({'path':filename,'git_blob_before':ORIGINAL_BLOBS[filename],
                        'sha256_before':sha256(before),'sha256_after':sha256(after),
                        'diagnostic_only':True})
    changed = set(cmd('git','diff','--name-only',cwd=stage).splitlines())
    if changed != set(patch):
        raise ValueError('R3_STAGE_UNEXPECTED_FILE_DIFF:'+str(sorted(changed)))
    if cmd('git','status','--porcelain',cwd=donor):
        raise ValueError('R3_ORIGINAL_DONOR_CHANGED')
    report.mkdir(parents=True,exist_ok=True)
    diff = cmd('git','diff','--','kernel/sched/debug.c','mm/vmscan.c',cwd=stage)
    (report/'R3_DIAGNOSTIC_ONLY.patch').write_text(diff+'\n',encoding='utf-8')
    result={'status':'R3_PROBE_STAGE_ONLY','donor_version':'5.4.268',
      'donor_commit':DONOR_COMMIT,'original_donor_unchanged':True,
      'staged_file_count':2,'files':records,
      'boot_img_created':False,'kernel_5_4_274_reproduced':False,
      'oem_abi_verified':False,'flash_allowed':False,
      'caveat':'Provisional diagnostic declarations; lock ordering and runtime semantics NOT proven.'}
    (report/'R3_STAGE_MANIFEST.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def summarize(log_path: Path, exit_code_path: Path, output: Path) -> dict:
    lines=log_path.read_text(errors='replace').splitlines()
    code=int(exit_code_path.read_text().strip())
    err_lines=[{'line':n+1,'text':line.strip()[:900]}
               for n,line in enumerate(lines)
               if re.search(r'(?:\berror:|\bfatal error:|\bError [0-9]+|LLVM ERROR:)',line)]
    # llvm IO pipe failures can be independent of source errors; report separately.
    pipe_fail=sum('LLVM ERROR: IO failure on output stream: Broken pipe' in x for x in lines)
    result={'status':'PROBE_COMPILED' if code==0 else 'PROBE_COMPILER_FAILED',
      'donor_version':'5.4.268','exit_code':code,'log_lines':len(lines),
      'compiler_error_count':len(err_lines),'compiler_errors':err_lines[:140],
      'llvm_broken_pipe_count':pipe_fail,
      'image_flashable':False,'image_distributable':False,
      'oem_abi_verified':False,'stock_source_5_4_274_recovered':False,
      'full_kernel_boot_tested':False,
      'note':'The 2 source edits were applied only in an isolated diagnostic Git worktree.'}
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(result,indent=2)+'\n')
    return result


def main() -> None:
    p=argparse.ArgumentParser()
    sub=p.add_subparsers(dest='mode',required=True)
    a=sub.add_parser('prepare');a.add_argument('--donor',type=Path,required=True);a.add_argument('--stage',type=Path,required=True);a.add_argument('--report',type=Path,required=True)
    b=sub.add_parser('summarize');b.add_argument('--log',type=Path,required=True);b.add_argument('--return-code',type=Path,required=True);b.add_argument('--out',type=Path,required=True)
    opts=p.parse_args()
    val=(prepare(opts.donor,opts.stage,opts.report) if opts.mode=='prepare' else summarize(opts.log,opts.return_code,opts.out))
    print(json.dumps({k:v for k,v in val.items() if k not in ('files','compiler_errors')},sort_keys=True))

if __name__=='__main__':main()
