# VEUX Stock 5.4.274 – R3 ISOLIERTER KOMPILERPROBELAUF (NOFLASH)

**Ziel:** Die zwei nachgewiesenen Quellfehler aus GitHub R2 Run 41992167188
in einem **separaten, temporären Git-Worktree** gezielt auflösen, um weitere
Compilerfehler der **Spenderquelle 5.4.268** sichtbar zu machen.

## Behobene Diagnose-Blocker (nicht produktiv freigegeben)

1. `kernel/sched/debug.c`: Makro `PM(F,M)` ruft im gepinnten Spender-Commit
   das nie definierte `__PS` auf. R3 ersetzt ausschließlich dessen Ausgabe
   durch eine äquivalente `SEQ_printf`-Ausgabe.
2. `mm/vmscan.c`: Die Spenderquelle verwendet `shrinker_rwsem` siebenmal,
   ohne die Sperre zu deklarieren. Zusätzlich existiert `shrinker_rwlock`
   für sechs andere Zugriffe. R3 ergänzt **nur zur Kompilationsdiagnose**
   die fehlende `DEFINE_RWSEM(shrinker_rwsem)` unter `CONFIG_MEMCG`.

**Achtung:** Die Sperrkorrektur darf nicht als Laufzeit- oder ABI-Fix gelten,
solange eine vollständige Locking-/RCU-Analyse fehlt. Sie ist nicht für
Produktionskernel oder Flashpakete freigegeben. Keine CRC-Erzwingung,
kein Ignorieren von OEM-ABI-Fehlern, keine Abschaltung von Sicherheitschecks.

## Manipulationsschutz

- Git-Commit-Spender bleibt `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`.
- Vor Änderungen sind die **echten Git-Blob-SHAs** beider Quelldateien
  zu prüfen (keine Anwendung auf anderen Quellstand).
- Änderungen erfolgen nur im `git worktree --detach` unter Runner-Temp.
- Die ursprüngliche Spenderkopie bleibt byte-/Git-unverändert.
- Bei einem fehlenden/duplizierten Quelltextanker oder anderer Nutzungszahl
  bricht das Gate ab. Ein Git-Diff und ein SHA256-Manifest werden archiviert.
- Der Compiler-Rückgabecode wird separat gespeichert. GitHub-Job `success`
  bedeutet nur, dass die **Diagnose** abgeschlossen ist, nicht der Build.

## Abhängigkeiten

Die beiden bewährten Archive müssen in der Repo-Wurzel bleiben:

- `VEUX_STOCK_54274_SOURCE_RECON_R1_MAIN.zip`
- `VEUX_STOCK_54274_SOURCE_RECON_R2_MAIN.zip`

Neu in der Repo-Wurzel:

- `VEUX_STOCK_54274_SOURCE_RECON_R3_MAIN.zip`

Neue Workflow-Datei in `.github/workflows/`:

- `VEUX_STOCK_54274_SOURCE_RECON_R3_NOFLASH.yml`

Workflow ohne Checkbox ausführen. Er verwendet Clang 11.0.2, macht R1-/R2-
Vergleiche und kompiliert die **temporär angepasste 5.4.268-Spenderbasis**.
Es wird ausschließlich TEXT-DIAGNOSTIK hochgeladen, keine Images, keine AK3.

## Grundsätzlicher Stand

Das originale Xiaomi-Stock-Image 5.4.274 und seine extrahierten Header/
Config sind eine authentische **Binär-Referenz**, kein vollständiger Xiaomi-
Quellbaum und keine Stock-`Module.symvers`. Selbst ein erfolgreicher R3-Probe-
Build beweist weder einen byteidentischen Stock-Kernel noch die OEM-Vendor-
ABI. Die endgültige Flashfreigabe bleibt *NEIN*.
