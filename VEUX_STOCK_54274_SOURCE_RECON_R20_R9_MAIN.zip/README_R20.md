# VEUX R20-R9 WALT Schedutil original source integration -- NOFLASH

**Parent run:** https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42191232502 (R20-R8), commit 394089c7795cdd92de9fd0850acb086a71bf99a2.

Real CI result: ten separately compiled objects passed, twelve original R17 regressions passed, but full Image/dtbs build failed in `kernel/sched/cpufreq_schedutil.c:235` because the SM6375 donor source calls the original donor `uclamp_is_used()` helper which is **not present** in the Qualcomm WALT `kernel/sched/sched.h` used by the experimental trial.

**Correction:** stage only the **complete genuine pinned Qualcomm** `kernel/sched/cpufreq_schedutil.c` (blob `70de343383847cabf05d6a5f1773d494c32af0bd`) instead of SM6375 source (blob `6373d2b03dd6a1b6c993d462e463336ca9ce4f8d`), preserving all source semantics intact. Both git source blob hashes are checked during GitHub stage. No custom helper or semantic bypass. Pre-compile `cpufreq_schedutil.o` as 11th new object and all 12 old R17 regression objects; attempt exact original R18 full build after success. If full build fails, run additional GNU make -k diagnostic (diagnostic only) to find more errors at once. Never publish kernel images or flash payloads.

**Safety:** Production repo, R19/R20-R8 originals and BakaSU, SUSFS, NoMount remain unchanged. This is **not** the stock 5.4.274 kernel reproduced. No OEM ABI, device, boot or flash green claimed. No green flash until real OEM ABI, full boot test and verified native binary.
