import collections
import csv
import io
import json
import pathlib
import tempfile
import unittest
import unittest.mock as mock
import zipfile
import sys

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import r38_gate as a
import r37_gate
import r34_gate

class R38Evidence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (cls.r33,cls.r34,cls.paths,cls.old65,cls.r37,cls.vendor,cls.counts)=a.verify_originals(ROOT)

    def test_01_manifest(self):self.assertEqual(a.verify_file_set_and_sha(ROOT)['schema'],'VEUX_R38_PINNED_PACKAGE_V1')
    def test_02_sha_anchors(self):self.assertEqual(len(a.ORIGINAL_HASHES),8)
    def test_03_r33_slot_a(self):self.assertEqual(self.r33['reported_active_slot'],'_a')
    def test_04_r33_16_entries(self):self.assertEqual(len(self.r33['dtbo'][0]['entries']),16)
    def test_05_r33_root_metadata(self):self.assertIn('blair',str(self.r33['runtime_device_tree']['fdt']['root']))
    def test_06_r34_754(self):self.assertEqual(len(self.r34['device_nodes']),754)
    def test_07_r34_503(self):self.assertEqual(sum(bool(x['stock_bound_drivers']) for x in self.r34['device_nodes']),503)
    def test_08_r34_loaded_names(self):self.assertEqual(set(self.r34['loaded_module_names']),{'rmnet_shs','rmnet_offload'})
    def test_09_r35_65(self):self.assertEqual(len(self.old65),65)
    def test_10_r35_unique_paths(self):self.assertEqual(len({x['stock_node'] for x in self.old65}),65)
    def test_11_r37_index(self):self.assertEqual(self.r37['unique_root_metadata_candidate_index'],0)
    def test_12_r37_stock_nodes(self):self.assertEqual(self.r37['stock_base_plus_index0_merge']['nodes'],2652)
    def test_13_r37_r20_nodes(self):self.assertEqual(self.r37['r20_standalone_plus_index0_merge']['nodes'],2200)
    def test_14_r37_targets(self):self.assertEqual(len(self.paths),27)
    def test_15_r37_stock_matches(self):self.assertEqual(self.r37['stock_27_exact_target_matches'],27)
    def test_16_r37_r20_matches(self):self.assertEqual(self.r37['r20_27_exact_target_matches'],27)
    def test_17_r37_no_bootloader_selection(self):self.assertIs(self.r37['dtbo_bootloader_choice_proven'],False)
    def test_18_r37_no_flash(self):self.assertIs(self.r37['flash_allowed'],False)
    def test_19_vendor_218(self):self.assertEqual(len(self.vendor),218)
    def test_20_vendor_14648(self):self.assertEqual(sum(self.counts.values()),14648)
    def test_21_vendor_match(self):self.assertEqual(self.counts['MATCH'],6960)
    def test_22_vendor_mismatch(self):self.assertEqual(self.counts['CRC_MISMATCH'],7653)
    def test_23_vendor_missing(self):self.assertEqual(self.counts['ABSENT_IN_R20_SYMVERS'],35)
    def test_24_vendor_module_lists(self):
        g={r['path']:len(set(r['module_names'])) for r in self.r33['module_load_lists']}
        self.assertEqual(g['/vendor/lib/modules/modules.load'],37)
        self.assertEqual(g['/vendor/lib/modules/5.4-gki/modules.load'],181)
    def test_25_vendor_file_names_are_exact(self):
        rows=a.report_vendor(self.vendor,self.counts,self.r33)
        self.assertEqual(len(rows),218)
        self.assertEqual(sum(int(r['historical_total_imports']) for r in rows),14648)
    def test_26_vendor_load_list_names_not_proof(self):
        rows=a.report_vendor(self.vendor,self.counts,self.r33)
        self.assertTrue(all(r['limitation']=='HISTORICAL_IMPORTS_NOT_CURRENT_LOAD_PROOF' for r in rows))
    def test_27_runtime_rmnet_names(self):
        rows=a.report_vendor(self.vendor,self.counts,self.r33)
        self.assertEqual({pathlib.Path(r['vendor_file_path']).stem for r in rows if r['runtime_module_name_seen']=='True'},
                         {'rmnet_shs','rmnet_offload'})
    def test_28_active_status(self):self.assertTrue(a.is_enabled('okay (default)'))
    def test_29_ok_status(self):self.assertTrue(a.is_enabled('ok'))
    def test_30_disabled_status(self):self.assertFalse(a.is_enabled('disabled'))
    def test_31_norm_exact(self):
        n={'compatible':['abc'],'status':'ok'};m={'compatible':['abc'],'status':'okay (default)'}
        self.assertEqual(a.classify_runtime(n,m),'COMPAT_OVERLAP_AND_STATUS_MATCH')
    def test_32_norm_subset(self):
        n={'compatible':['foo','fallback'],'status':'okay'};m={'compatible':['fallback'],'status':'okay'}
        self.assertEqual(a.classify_runtime(n,m),'COMPAT_OVERLAP_AND_STATUS_MATCH')
    def test_33_missing(self):self.assertEqual(a.classify_runtime({'compatible':[],'status':'okay'},None),'PATH_MISSING')
    def test_34_disabled(self):
        self.assertEqual(a.classify_runtime({'compatible':['a'],'status':'ok'},
          {'compatible':['a'],'status':'disabled'}),'ENABLED_STOCK_DISABLED_R20')
    def test_35_compatible_different(self):
        self.assertEqual(a.classify_runtime({'compatible':['a'],'status':'okay'},
          {'compatible':['b'],'status':'okay'}),'COMPAT_DISJOINT_OR_ABSENT')
    def test_36_empty_compatible_both(self):
        self.assertEqual(a.classify_runtime({'compatible':[],'status':'okay'},
          {'compatible':[],'status':'ok'}),'EXACT_EMPTY_COMPAT_AND_STATUS_MATCH')
    def test_37_overlap_status_diff(self):
        self.assertEqual(a.classify_runtime({'compatible':['a'],'status':'disabled'},
          {'compatible':['a'],'status':'okay'}),'COMPAT_OVERLAP_STATUS_DIFF')
    def test_38_structural_stock_only(self):
        r,c=a.structural_diff([{'path':'/a','compatible':['foo'],'status':'okay'}],[])
        self.assertEqual((r[0]['difference'],c['STOCK_ONLY']),('STOCK_ONLY',1))
    def test_39_structural_r20_only(self):
        r,c=a.structural_diff([],[{'path':'/a','compatible':['foo'],'status':'okay'}])
        self.assertEqual((r[0]['difference'],c['R20_ONLY']),('R20_ONLY',1))
    def test_40_structural_match_normalized(self):
        r,c=a.structural_diff([{'path':'/a','compatible':['foo'],'status':'ok'}],
          [{'path':'/a','compatible':['foo'],'status':'okay'}])
        self.assertEqual((len(r),c['STRUCTURAL_METADATA_MATCH']),(0,1))
    def test_41_structural_compatible_changed(self):
        r,c=a.structural_diff([{'path':'/a','compatible':['foo'],'status':'ok'}],
          [{'path':'/a','compatible':['bar'],'status':'okay'}])
        self.assertEqual(r[0]['difference'],'COMPAT_DIFFER')
    def test_42_structural_status_changed(self):
        r,c=a.structural_diff([{'path':'/a','compatible':['foo'],'status':'disabled'}],
          [{'path':'/a','compatible':['foo'],'status':'okay'}])
        self.assertEqual(r[0]['difference'],'STATUS_DIFFER')
    def test_43_structural_two_properties_changed(self):
        r,c=a.structural_diff([{'path':'/a','compatible':['foo'],'status':'disabled'}],
          [{'path':'/a','compatible':['bar'],'status':'okay'}])
        self.assertEqual(r[0]['difference'],'COMPAT_AND_STATUS_DIFFER')
    def test_44_duplicate_path_fails(self):
        with self.assertRaisesRegex(ValueError,'DUPLICATE_FDT_PATH'):
            a.structural_diff([{'path':'/a','compatible':[],'status':'ok'}]*2,[])
    def test_45_503_bound_comparison(self):
        n=[dict(path=x['path'],compatible=x['compatible'],status=x['status']) for x in self.r34['device_nodes']]
        z=a.compare_bound_nodes(self.r34,n)
        self.assertEqual(len(z),503)
        self.assertTrue(all(x['classification'] in ('COMPAT_OVERLAP_AND_STATUS_MATCH','EXACT_EMPTY_COMPAT_AND_STATUS_MATCH') for x in z))
    def test_46_bound_difference_missing_paths(self):
        z=a.compare_bound_nodes(self.r34,[])
        self.assertTrue(all(x['classification']=='PATH_MISSING' for x in z))
    def test_47_check_all_65_without_overlay_as_missing(self):
        rows=a.compare_r35_65(self.old65,[],self.r34)
        self.assertEqual(len(rows),65)
        self.assertTrue(all(x['after_R37_overlay']=='PATH_MISSING' for x in rows))
    def test_48_check_all_65_when_present(self):
        f={x['path']:x for x in self.r34['device_nodes']}
        rows=a.compare_r35_65(self.old65,[{'path':k,'compatible':v['compatible'],'status':v['status']} for k,v in f.items()],self.r34)
        self.assertEqual(len(rows),65)
        self.assertTrue(all(x['after_R37_overlay'] in ('COMPAT_OVERLAP_AND_STATUS_MATCH','EXACT_EMPTY_COMPAT_AND_STATUS_MATCH') for x in rows))
    def test_49_known_fdt_r20_parses(self):
        n=r34_gate.fdt_nodes((ROOT/'evidence/R20_VEUX.dtb').read_bytes())
        self.assertEqual(len(n),1829)
    def test_50_no_fake_overlay_data(self):
        self.assertEqual(self.r37['r37_new_device_evidence_present'],True)
    def test_51_invalid_source_hash_precheck(self):
        self.assertEqual(len(set(a.ORIGINAL_HASHES.values())),8)
    def test_52_real_vendor_symvers_count(self):
        symbols=r34_gate.parse_symvers((ROOT/'evidence/R20_Module.symvers').read_bytes())
        self.assertGreater(len(symbols),10000)
    def test_53_metadata_not_binary(self):
        self.assertTrue(all('FLASH' not in path for path in a.ORIGINAL_HASHES))
    def test_54_no_false_boot_or_flash_in_script(self):
        src=(ROOT/'scripts/r38_gate.py').read_text()
        self.assertIn("'boot_ready':False,'flash_allowed':False",src)
    def test_55_evidence_device_zip_not_assumed_available(self):
        self.assertFalse((ROOT/a.DEVICE).exists())
    def test_56_r37_main_retains_root_overlay_id(self):
        self.assertEqual(self.r33['dtbo'][0]['entries'][0]['sha256'],r37_gate.ENTRY0_SHA)
    def test_57_r37_r34_cross_validation(self):
        self.assertEqual(len(self.r34['device_nodes']),self.r37['r34_stock_node_count'])


    @classmethod
    def synthesize_merged_trees(cls):
        # Based on actual R34 safe DT metadata; extra paths are synthetic and
        # test the accounting, not a claim about the user's device.
        base=[{'path':n['path'],'compatible':n['compatible'],'status':n['status']}
              for n in cls.r34['device_nodes']]
        paths={n['path'] for n in base}
        stock=list(base)
        r20=list(base)
        i=0
        while len(stock)<2652:
            p='/test-stock-only-'+str(i);i+=1
            if p not in paths:stock.append({'path':p,'compatible':[],'status':'okay'})
        i=0
        while len(r20)<2200:
            p='/test-r20-only-'+str(i);i+=1
            if p not in paths:r20.append({'path':p,'compatible':[],'status':'okay'})
        return stock,r20

    def test_58_simulated_e2e_real_pinned_inputs(self):
        stock,r20=self.synthesize_merged_trees()
        source={n['path']:n for n in self.r34['device_nodes']}
        rt=[{'path':p,'compatible':source[p]['compatible'],'status':source[p]['status']}
            for p in self.paths]
        filedict={'R37_VENDOR_BOOT_BASE.dtb':b'base-test-only',
                  'R37_DTBO_CANDIDATE0.dtbo':b'overlay-test-only'}
        with tempfile.TemporaryDirectory() as td:
            with (mock.patch.object(a,'verify_originals',return_value=(self.r33,self.r34,self.paths,self.old65,self.r37,self.vendor,self.counts)),
                  mock.patch.object(r37_gate,'safe_zip',return_value=filedict),
                  mock.patch.object(r37_gate,'parse_device',return_value={'runtime_target_nodes':rt}),
                  mock.patch.object(r37_gate,'run_merger',side_effect=[
                      ({'outcome':'OFFLINE_APPLY_AND_PARSE_SUCCESS','nodes':2652},stock),
                      ({'outcome':'OFFLINE_APPLY_AND_PARSE_SUCCESS','nodes':2200},r20)])):
                report=a.audit(ROOT,pathlib.Path(td)/'unneeded-test-zip',pathlib.Path(td)/'results')
            self.assertEqual(report['stock_runtime_bound_node_total'],503)
            self.assertEqual(report['r35_65_total'],65)
            self.assertEqual(report['vendor_historical_imports'],14648)
            self.assertIs(report['boot_ready'],False)
            self.assertIs(report['flash_allowed'],False)
            out=pathlib.Path(td)/'results'
            self.assertEqual(len(list(csv.DictReader(io.StringIO((out/'R38_STOCK_BOUND_503.csv').read_text())))),503)
            self.assertEqual(len(list(csv.DictReader(io.StringIO((out/'R38_VENDOR_218_ABI_PRIORITY.csv').read_text())))),218)
            for line in (out/'SHA256SUMS.txt').read_text().splitlines():
                digest,name=line.split('  ',1)
                self.assertEqual(a.sha((out/name).read_bytes()),digest)
            self.assertFalse(any(p.suffix in ('.ko','.img','.dtb','.zip') for p in out.iterdir()))

    def test_59_reject_bad_merge_count(self):
        stock,r20=self.synthesize_merged_trees()
        self.assertEqual(len(r20),2200)
        self.assertNotEqual(len(r20[:-1]),2200)

    def test_60_declared_zip_security(self):
        self.assertEqual(a.DEVICE,'VEUX_R37_DEVICE_EVIDENCE.zip')

    def test_61_r35_old65_all_bound(self):
        original={n['path']:n for n in self.r34['device_nodes']}
        self.assertTrue(all(original[r['stock_node']]['stock_bound_drivers'] for r in self.old65))

if __name__=='__main__':unittest.main()
