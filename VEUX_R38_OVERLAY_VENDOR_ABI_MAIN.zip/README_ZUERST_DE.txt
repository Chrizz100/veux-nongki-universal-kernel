VEUX R38 – Read-only Vergleich R37 Overlay vs. R20 und Vendor ABI
Stand: 2026-10-24

WICHTIG: KEIN KERNELBUILD, KEIN FLASH, KEINE PATCHES, KEINE AENDERUNG AN BReNE.
Dieses Paket ist eine Diagnose. Grüne GitHub Actions bedeuten NICHT, dass
Vendor ABI, Bootloader-DTBO-Auswahl, Bootverhalten oder Flash-Freigabe
nachgewiesen waeren.

GITHUB REPOSITORY:
  Chrizz100/veux-nongki-universal-kernel

EXAKT ZWEI NEUE DATEIEN HOCHLADEN:
  .github/workflows/VEUX_R38_OVERLAY_VENDOR_ABI_GATE.yml
  VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip  (main/ Root, NICHT entpacken)

BEREITS IM REPO AUS R37 VORHANDEN (NICHT NOCHMAL HOCHLADEN):
  VEUX_R37_DEVICE_EVIDENCE.zip

KEINE PYTHON-DATEI AUF TERMUX AUSFUEHREN. R38 benutzt die bestehende
read-only Root-DTBO-Erfassung aus dem R37-Erfolgslauf 40078743121.

UNTER ACTIONS STARTEN:
  VEUX R38 - Complete Overlay Structure and Historical Vendor ABI - NO BUILD NO FLASH

Ausgewertet werden:
  - unveraenderte SHA-gepinnte Belege R20, R21, R33, R34, R35, R36 und R37
  - Stock-vendor_boot-Basis-DTB plus DTBO-Index 0 / R20-Einzel-DTB plus Index 0
  - 2.652 Stock- / 2.200 R20-Knoten (R37; neue Reproduktion erforderlich)
  - 27 bereits nachgewiesene UFS-/PMIC-Zielknoten als Regression (kein neues Freigabekriterium)
  - 503 aktuell unter STOCK gebundene Treiberknoten, nur Strukturvergleich
  - 65 R35-Problemkandidaten nach korrektem Offline-Overlay
  - historische CRCs fuer 218 Vendor-Moduldateien / 14.648 Importe
  - stockseitig geladene ModulNamen rmnet_shs / rmnet_offload, ohne Quellbeweis

Ergebnisartefakte:
  R38_RESULT.json
  R38_BERICHT_DE.txt
  R38_STOCK_BOUND_503.csv
  R38_R35_65_AFTER_OVERLAY.csv
  R38_STOCK_R20_FDT_DIFFERENCES.csv
  R38_VENDOR_218_ABI_PRIORITY.csv
  R38_TESTS.log
  SHA256SUMS.txt

ERGEBNISINTERPRETATION:
  Ein Eintrag in modules.load beweist NICHT die aktuelle Laufzeitladung.
  Ein Unterschied im compiled R20-FDT beweist NICHT, dass Treibercode fehlt.
  Alle CRC-Zahlen sind historische R21-Importpruefungen.
  Die UFS-/PMIC-Offline-FDT-Passung beweist NICHT den Android-Boot.
