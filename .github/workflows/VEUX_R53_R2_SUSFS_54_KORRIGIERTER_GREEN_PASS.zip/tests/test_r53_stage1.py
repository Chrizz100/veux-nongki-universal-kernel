import contextlib
import os
import pathlib
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import r53_stage1 as g


def git(d, *argv):
    return subprocess.check_output(['git', *argv], cwd=d, text=True).strip()


def init(d):
    d.mkdir(parents=True)
    git(d,'init','-q')
    git(d,'config','user.name','VEUX Unit Test')
    git(d,'config','user.email','test@example.org')


class R53Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.t=pathlib.Path(self.tmp.name)
        self.src=self.t/'kernel'; self.midori=self.t/'midori'; self.jack=self.t/'jack';self.out=self.t/'out'
        init(self.src)
        for i,n in enumerate(g.SELECTION):
            p=self.src/n;p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(f'line {i} A\nline {i} B\n',encoding='utf8')
        git(self.src,'add','.');git(self.src,'commit','-qm','Base')
        self.original_sha=git(self.src,'rev-parse','HEAD')
        self.src_file_hashes={n:git(self.src,'hash-object',n) for n in g.SELECTION}
        # Generate real per-source multi-file git diffs against a cloned ancestor.
        self.patch_strings={}
        for origin,dest in [('midori',self.midori),('jack',self.jack)]:
            clone=self.t/(origin+'_draft')
            subprocess.run(['git','clone','-q',str(self.src),str(clone)],check=True)
            for n,source in g.SELECTION.items():
                if source != origin:continue
                f=clone/n
                f.write_text(f.read_text()+f'# SUSFS STAGED ({origin})\n',encoding='utf8')
            self.patch_strings[origin]=subprocess.check_output(['git','diff'],cwd=clone,text=True)
            init(dest)
            if origin=='midori': path='kernel_patches/50_add_susfs_in_qgki-android11-5.4.patch'
            else: path='Patches/Patch/susfs_patch_to_5.4.patch'
            p=dest/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(self.patch_strings[origin])
            git(dest,'add','.');git(dest,'commit','-qm','Pinned test data')
        self.midori_hash=git(self.src,'hash-object',str(self.midori/'kernel_patches/50_add_susfs_in_qgki-android11-5.4.patch'))
        self.jack_hash=git(self.src,'hash-object',str(self.jack/'Patches/Patch/susfs_patch_to_5.4.patch'))
        # Pin override is isolated to synthetic tests; R53 workflow enforces real pinned SHAs.
        changes=[patch.object(g,'SOURCE_PIN',self.original_sha),
                 patch.object(g,'MIDORI_PIN',git(self.midori,'rev-parse','HEAD')),
                 patch.object(g,'JACK_PIN',git(self.jack,'rev-parse','HEAD')),
                 patch.object(g,'MIDORI_PATCH_SHA',self.midori_hash),
                 patch.object(g,'JACK_PATCH_SHA',self.jack_hash)]
        for change in changes:change.start();self.addCleanup(change.stop)

    def test_nine_file_source_application_generates_actual_patch(self):
        r=g.stage(self.src,self.midori,self.jack,self.out)
        self.assertEqual(r['patched_file_count'],9)
        self.assertEqual({n['file'] for n in r['patched_files']},set(g.SELECTION))
        self.assertTrue((self.out/'VEUX_R53_SUSFS54_STAGE1_PARTIAL.patch').is_file())
        self.assertFalse(r['flash_allowed']);self.assertFalse(r['compile_performed'])
        self.assertFalse(r['r44_walt_recomposed']);self.assertFalse(r['susfs_5_4_full_port_complete'])
        # generated patch applies cleanly to an independent identical ancestor
        # Replay on an independent clean ancestor clone.
        base=self.t/'base'
        subprocess.run(['git','clone','-q',str(self.src),str(base)],check=True)
        subprocess.run(['git','apply','--check',str(self.out/'VEUX_R53_SUSFS54_STAGE1_PARTIAL.patch')],cwd=base,check=True)
        subprocess.run(['git','apply',str(self.out/'VEUX_R53_SUSFS54_STAGE1_PARTIAL.patch')],cwd=base,check=True)
        self.assertEqual(git(base,'diff','--name-only').splitlines(),sorted(g.SELECTION))

    def test_sibling_relative_checkout_paths_match_github_runner(self):
        """Reproduce the exact R53 error: source, midori, jack are relative siblings."""
        previous=os.getcwd()
        try:
            os.chdir(self.t)
            result=g.stage(pathlib.Path('kernel'),pathlib.Path('midori'),
                           pathlib.Path('jack'),pathlib.Path('out'))
        finally:
            os.chdir(previous)
        self.assertEqual(result['patched_file_count'],9)
        self.assertEqual({x['file'] for x in result['patched_files']},set(g.SELECTION))
        self.assertEqual(result['flash_allowed'],False)
        self.assertTrue((self.out/'VEUX_R53_SUSFS54_STAGE1_PARTIAL.patch').is_file())

    def test_actual_diff_disjoint_and_bounded(self):
        self.assertEqual(set(g.SELECTION.values()),{'midori','jack'})
        for n in g.SELECTION:self.assertNotIn(n,g.DENIED_FILES)
        self.assertNotIn('fs/namei.c',g.SELECTION)
        self.assertNotIn('fs/namespace.c',g.SELECTION)
        self.assertNotIn('security/selinux/avc.c',g.SELECTION)

    def test_malicious_patch_path_rejected(self):
        bad=self.patch_strings['midori'].replace('block/ioprio.c','../boot.img')
        with self.assertRaises(g.GateError):g.parse_file_diffs(bad)

    def test_duplicate_patch_path_rejected(self):
        chunk=self.patch_strings['jack'].split('diff --git ',2)[1]
        duplicated=self.patch_strings['jack']+'diff --git '+chunk
        with self.assertRaises(g.GateError):g.parse_file_diffs(duplicated)

    def test_malformed_index_rejected(self):
        x=self.patch_strings['midori'].replace('index ','bad-index ',1)
        with self.assertRaises(g.GateError):g.parse_file_diffs(x)

    def test_wrong_pin_rejected_before_any_change(self):
        with patch.object(g,'SOURCE_PIN','f'*40):
            with self.assertRaisesRegex(g.GateError,'WRONG_SOURCE_ANCESTOR'):
                g.stage(self.src,self.midori,self.jack,self.out)
        self.assertFalse(self.out.exists())

    def test_preimage_divergence_rejected_before_applying_target(self):
        p=self.src/'block/ioprio.c';p.write_text(p.read_text()+'bad\n')
        with self.assertRaisesRegex(g.GateError,'DIR_DIRTY'):
            g.stage(self.src,self.midori,self.jack,self.out)

    def test_blob_pin_mismatch_rejected(self):
        with patch.object(g,'MIDORI_PATCH_SHA','a'*40):
            with self.assertRaisesRegex(g.GateError,'PATCH_BLOB_SHA_WRONG'):
                g.stage(self.src,self.midori,self.jack,self.out)

    def test_unsafe_selection_rejected(self):
        with self.assertRaises(g.GateError):g.validate_selection({'fs/namei.c':'midori',**g.SELECTION})

    def test_wrong_sources_no_apply(self):
        p=self.midori/'kernel_patches/50_add_susfs_in_qgki-android11-5.4.patch'
        p.write_text('corrupt')
        with self.assertRaisesRegex(g.GateError,'DIR_DIRTY'):
            g.stage(self.src,self.midori,self.jack,self.out)

    def test_unexpected_existing_output_blocked(self):
        self.out.mkdir();(self.out/'do-not-overwrite.txt').write_text('PRIVATE')
        with self.assertRaisesRegex(g.GateError,'NONEMPTY_OUTPUT_DIR'):
            g.stage(self.src,self.midori,self.jack,self.out)
        self.assertEqual((self.out/'do-not-overwrite.txt').read_text(),'PRIVATE')

    def test_no_kconfig_or_selinux_or_ksu_source_patches(self):
        self.assertTrue(all(not p.startswith(('security/','include/','arch/','mm/')) for p in g.SELECTION))
        self.assertEqual(len(g.SELECTION),9)

    def test_metadata_false_flags_in_original_outputs(self):
        import json
        g.stage(self.src,self.midori,self.jack,self.out)
        d=json.loads((self.out/'R53_PATCH_RESULT.json').read_text())
        for flag in ('boot_ready','flash_allowed','susfs_5_4_full_port_complete','compile_performed','r44_walt_recomposed','baka_su_uapi6_integrated','nomount_v22_integrated'):
            self.assertIs(d[flag],False)

    def test_required_new_file_marker_and_blob_hex(self):
        parts=g.parse_file_diffs(self.patch_strings['jack'])
        old,chunk=parts['fs/Makefile']
        self.assertTrue(self.src_file_hashes['fs/Makefile'].startswith(old))
        self.assertTrue(chunk.startswith('diff --git a/fs/Makefile b/fs/Makefile'))


if __name__=='__main__':unittest.main()
