#!/usr/bin/env python3
"""R53: isolate and apply precisely selected SUSFS 5.4 hunks on pinned ancestor.

This does NOT compose the final R44 source, a full SUSFS port, KSU or modules.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

SOURCE_PIN = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
MIDORI_PIN = 'cfde03eed16a39775a341d16d3f6601bed11b11a'
JACK_PIN = 'dcd789634247c77d8549a42aef232c680a905585'
MIDORI_PATCH_SHA = 'e0dc048a8c9fbbd55b57ef6f048f61e3f10a6341'
JACK_PATCH_SHA = 'e2d4f7ad31f9a7b6819fbcedd1ba775bc10bb143'
# Deliberately omit fs/namei, fs/namespace, SELinux, mount.h, etc.
SELECTION = {
    'block/ioprio.c': 'midori',
    'fs/Makefile': 'jack',
    'fs/notify/fdinfo.c': 'midori',
    'fs/proc/cmdline.c': 'jack',
    'fs/proc/fd.c': 'midori',
    'fs/proc_namespace.c': 'midori',
    'fs/readdir.c': 'midori',
    'fs/statfs.c': 'midori',
    'kernel/kallsyms.c': 'jack',
}
DENIED_PREFIXES = ('security/', 'drivers/', 'arch/', 'tools/', 'include/', 'mm/')
DENIED_FILES = {'fs/namei.c', 'fs/namespace.c', 'fs/susfs.c', 'fs/exec.c', 'fs/open.c'}

class GateError(RuntimeError):
    pass


def run(argv: list[str], cwd: Path, *, data: str | None = None, timeout: int = 90) -> str:
    p = subprocess.run(argv, cwd=cwd, input=data, text=True, capture_output=True, timeout=timeout, check=False)
    if p.returncode:
        raise GateError('COMMAND_FAIL ' + ' '.join(argv) + ': ' + (p.stderr or p.stdout)[-2200:])
    return p.stdout


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_file_diffs(contents: str) -> dict[str, tuple[str, str]]:
    pat = re.compile(r'(?m)^diff --git a/(\S+) b/(\S+)\n')
    matches = list(pat.finditer(contents))
    if not matches or contents[:matches[0].start()].strip():
        raise GateError('BAD_PATCH_PREFIX')
    ans: dict[str, tuple[str, str]] = {}
    for index, match in enumerate(matches):
        src, dest = match.groups()
        pp = PurePosixPath(src)
        if (src != dest or pp.is_absolute() or '..' in pp.parts or
                src.startswith('.') or '\\' in src or src in ans):
            raise GateError('UNSAFE_PATCH_PATH: ' + src)
        end = matches[index+1].start() if index+1 < len(matches) else len(contents)
        chunk = contents[match.start():end]
        header = re.search(r'(?m)^index ([0-9a-f]{7,40})\.\.([0-9a-f]{7,40})(?: \d+)?$', chunk)
        if not header or f'--- a/{src}' not in chunk or f'+++ b/{dest}' not in chunk:
            raise GateError('BAD_PATCH_METADATA: ' + src)
        if re.search(r'(?m)^(?:new file mode|deleted file mode|rename (?:from|to)|Binary files|GIT binary patch)',chunk):
            raise GateError('UNEXPECTED_PATCH_OPERATION: ' + src)
        ans[src] = (header.group(1), chunk.rstrip('\n') + '\n')
    return ans


def validate_selection(selection: dict[str, str] = SELECTION) -> None:
    if len(selection) != 9 or set(selection.values()) != {'midori','jack'}:
        raise GateError('SELECTION_CHANGED')
    for p in selection:
        if p in DENIED_FILES or p.startswith(DENIED_PREFIXES) or '..' in PurePosixPath(p).parts:
            raise GateError('DENIED_FILE: ' + p)


def validate_pins(source: Path, midori: Path, jack: Path) -> None:
    if run(['git','rev-parse','HEAD'],source).strip() != SOURCE_PIN:
        raise GateError('WRONG_SOURCE_ANCESTOR')
    if run(['git','rev-parse','HEAD'],midori).strip() != MIDORI_PIN:
        raise GateError('WRONG_MIDORI_COMMIT')
    if run(['git','rev-parse','HEAD'],jack).strip() != JACK_PIN:
        raise GateError('WRONG_JACK_COMMIT')
    for p in (source, midori, jack):
        if run(['git','status','--porcelain','--untracked-files=all'],p).strip():
            raise GateError('INPUT_GIT_DIR_DIRTY: '+str(p))


def stage(source: Path, midori: Path, jack: Path, out: Path) -> dict:
    validate_selection()
    validate_pins(source,midori,jack)
    sourcefiles = {
        'midori': midori/'kernel_patches/50_add_susfs_in_qgki-android11-5.4.patch',
        'jack': jack/'Patches/Patch/susfs_patch_to_5.4.patch',
    }
    parsed: dict[str, dict[str, tuple[str,str]]] = {}
    for name, p in sourcefiles.items():
        if not p.is_file() or p.is_symlink():
            raise GateError('PINNED_PATCH_MISSING: '+name)
        expected = MIDORI_PATCH_SHA if name == 'midori' else JACK_PATCH_SHA
        # GitHub Actions checks out sibling repositories as *relative* paths.
        # Resolve the PATCH file to an absolute path before git -C kernel hash-object;
        # without this, Git erroneously searches kernel/midori/...
        got = run(['git','hash-object',str(p.resolve(strict=True))],source).strip()
        if got != expected:
            raise GateError('PATCH_BLOB_SHA_WRONG: '+name+' '+got)
        parsed[name] = parse_file_diffs(p.read_text(encoding='utf8'))

    # Only apply to ancestor. This is NOT yet the reconstructed R44 WALT source.
    ledger = []
    for name, origin in sorted(SELECTION.items()):
        if name not in parsed[origin]:
            raise GateError('PATCH_FILE_MISSING '+origin+':'+name)
        rel = source/name
        if not rel.is_file() or rel.is_symlink():
            raise GateError('BASE_FILE_NOT_REGULAR: '+name)
        old, patch = parsed[origin][name]
        before = run(['git','hash-object',name],source).strip()
        if not before.startswith(old):
            raise GateError('BASE_BLOB_MISMATCH: '+name+' base '+before+' expected '+old)
        # Explicitly check, then apply one isolated patch; never --3way, -R,
        # whitespace-ignore or reject/force flags.
        run(['git','apply','--check','-'],source,data=patch)
        run(['git','apply','-'],source,data=patch)
        after = run(['git','hash-object',name],source).strip()
        if before == after:
            raise GateError('NO_EFFECT: '+name)
        ledger.append({'file':name,'origin':origin,'old_git_blob':before,'new_git_blob':after,
                       'patch_chunk_sha256':sha(patch.encode('utf8'))})

    run(['git','diff','--check'],source)
    changed=set(run(['git','diff','--name-only','--no-renames'],source).splitlines())
    if changed != set(SELECTION) or len(ledger)!=len(SELECTION):
        raise GateError('UNEXPECTED_DIFF_SCOPE: '+repr(sorted(changed ^ set(SELECTION))))
    patch=run(['git','diff','--binary','--no-ext-diff','--no-renames','--',*sorted(SELECTION)],source)
    if not patch.strip() or len(patch.encode()) > 800000:
        raise GateError('PATCH_EMPTY_OR_OVERSIZED')
    result={
        'schema':'VEUX_R53_SUSFS_5_4_STAGE1_V1',
        'status':'PARTIAL_SOURCE_PATCH_APPLIED_TO_PINNED_ANCESTOR',
        'kernel_source_commit':SOURCE_PIN,
        'midori_commit':MIDORI_PIN,
        'jack_commit':JACK_PIN,
        'patched_files':ledger,
        'patched_file_count':len(ledger),
        'patch_sha256':sha(patch.encode()),
        'r44_walt_recomposed':False,
        'susfs_c_and_headers_integrated':False,
        'baka_su_uapi6_integrated':False,
        'nomount_v22_integrated':False,
        'susfs_5_4_full_port_complete':False,
        'compile_performed':False,
        'device_tested':False,
        'boot_ready':False,
        'flash_allowed':False,
    }
    if out.exists() and any(out.iterdir()):
        raise GateError('NONEMPTY_OUTPUT_DIR')
    out.mkdir(parents=True,exist_ok=True)
    (out/'VEUX_R53_SUSFS54_STAGE1_PARTIAL.patch').write_text(patch,encoding='utf8')
    (out/'R53_PATCH_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf8')
    (out/'START_HIER_NOFLASH.txt').write_text(
        'R53: ECHTE KERNEL-QUELLAENDERUNGEN; PARTIAL SOURCE STAGE ONLY.\n'
        '9 Git-Blob-gepinnte 5.4-Patchfragmente wurden auf den gepinnten\n'
        'Positron-ANCESTOR angewandt. NOCH NICHT auf den vollendeten R44-WALT-Baum.\n'
        'Fehlt: fs/susfs.c, headers, komplexe VFS/SELinux/Mount-Hooks,\n'
        'BakaSU UAPI 6, NoMount 22, Kompilierung und Devicevalidierung.\n'
        'Den Patch NICHT direkt in dein laufendes Android installieren!\n'
        'BOOT_READY=NO; FLASH_ALLOWED=NO. BReNE unveraendert.\n',encoding='utf8')
    return result


def main() -> None:
    ap=argparse.ArgumentParser()
    for arg in ('source','midori','jack','out'):ap.add_argument('--'+arg,required=True,type=Path)
    args=ap.parse_args()
    try:
        o=stage(args.source,args.midori,args.jack,args.out)
    except (GateError, ValueError, OSError, subprocess.TimeoutExpired) as exc:
        print('R53_STAGE1_BLOCKED: '+str(exc),file=sys.stderr)
        sys.exit(2)
    print('R53_STAGE1_REAL_SOURCE_PATCH_APPLIED='+str(o['patched_file_count'])+
          '; FULL_SUSFS_PORT=NO; R44_REBUILT=NO; FLASH_ALLOWED=NO')

if __name__ == '__main__':main()
