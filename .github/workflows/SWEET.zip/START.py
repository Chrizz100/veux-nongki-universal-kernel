#!/usr/bin/env python3
"""SWEET package entrypoint, runner ABI 1. Current stage: R12 error paths and unused values + full baseline Image.gz build.

Pinned source, real full baseline compilation; no device approval or flashing.
Later reviewed packages may replace this entrypoint without changing the starter.
"""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sys
import traceback
import unittest

ROOT = Path(__file__).resolve().parent


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or output.is_relative_to(ROOT):
        raise ValueError('Ausgabe muss ausserhalb des entpackten Pakets liegen.')
    output.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / 'PAKET.json').read_text())
    status = {'package_version': manifest['version'], 'package_check_passed': False,
              'test_runs': [], 'kernel_built': False, 'device_tested': False,
              'flashable': False, 'new_oem_kconfig_run': False,
              'purpose': 'R12: RNG-Anmeldefehler und ungenutzte lokale Zeiger und vollstaendiger Baseline-Image-Build; keine Stock-/Root-/Flashfreigabe.'}
    exit_code = 1
    try:
        if os.environ.get('SWEET_RUNNER_ABI') != '1':
            raise ValueError('Bitte mit dem SWEET-Starter ABI 1 ausfuehren.')
        for name, expected in manifest['files'].items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError(f'Paketdatei stimmt nicht: {name}')
        for directory, count, label in (
                ('common/update/sweet/tests', 72, 'R4.2'),
                ('common/update/sweet/tests_r5', 9, 'R5'),
                ('common/update/sweet/tests_r6', 16, 'R6'),
                ('common/update/sweet/tests_r7', 21, 'R7'),
                ('common/update/sweet/tests_r8', 23, 'R8'),
                ('common/update/sweet/tests_r9', 18, 'R9'),
                ('common/update/sweet/tests_r10', 24, 'R10'),
                ('common/update/sweet/tests_r11', 28, 'R11'),
                ('common/update/sweet/tests_r12', 22, 'R12')):
            logfile = output / f'Tests_{label}.txt'
            with logfile.open('w', encoding='utf-8') as stream:
                with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
                    suite = unittest.TestLoader().discover(str(ROOT / directory), pattern='test_*.py')
                    found = suite.countTestCases()
                    if found != count:
                        raise ValueError(f'{label}: {found} statt {count} Tests gefunden.')
                    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
            row = {'suite': label, 'found': found, 'executed': result.testsRun,
                   'passed': result.wasSuccessful() and not result.skipped,
                   'failures': len(result.failures), 'errors': len(result.errors),
                   'skipped': len(result.skipped)}
            status['test_runs'].append(row)
            if not row['passed']:
                raise RuntimeError(f'{label}: Tests nicht bestanden; siehe {logfile.name}.')
            print(f'{label}: {result.testsRun} Tests bestanden.', flush=True)
        for name, expected in manifest['files'].items():
            if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != expected:
                raise ValueError(f'Paketdatei waehrend Tests veraendert: {name}')
        status['package_check_passed'] = True
        sys.path.insert(0,str(ROOT / 'common/scripts/sweet'))
        import stage_r12
        status['r12'] = stage_r12.run_stage(output)
        status['new_oem_kconfig_run'] = status['r12']['new_oem_kconfig_run']
        status['kernel_built'] = status['r12']['kernel_built']
        exit_code = 0
    except Exception as exc:
        status['error'] = str(exc)
        (output / 'FEHLER.txt').write_text(traceback.format_exc(), encoding='utf-8')
        print(f'SWEET: {exc}', file=sys.stderr)
    finally:
        if 'r12' not in status and (output/'R12/report.json').is_file():
            status['r12']=json.loads((output/'R12/report.json').read_text())
        summary = ('# SWEET R12\n\n'
                   f"Paketpruefung: {'BESTANDEN' if status['package_check_passed'] else 'FEHLGESCHLAGEN'}\n\n"
                   f"Vollstaendiger Baseline-Image-Build: {'BESTANDEN' if status.get('r12',{}).get('completed') else 'NICHT ABGESCHLOSSEN'}\n\n"
                   '**Nur Entwicklungsartefakte: kein AK3, keine boot.img, nicht flashen.**\n\n'
                   '13 aktive Stock-Abweichungen und der Versionsabgleich bleiben offen. '
                   'Kein ReSukiSU/SUSFS/NoMount, keine Vendor-Modul- oder Geraetefreigabe.\n\n'
                   'Module und Geraetebaeume werden in dieser Image-Stufe nicht gebaut. '
                   'Die historischen Belege im Paket sind keine Ergebnisse dieses Laufs.\n')
        (output / 'ERGEBNIS.md').write_text(summary, encoding='utf-8')
        (output / 'status.json').write_text(json.dumps(status, indent=2) + '\n')
        if os.environ.get('GITHUB_STEP_SUMMARY'):
            with Path(os.environ['GITHUB_STEP_SUMMARY']).open('a', encoding='utf-8') as stream:
                stream.write(summary)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
