VEUX 5.4.274 – R6 + NoMount v2.1.1 – SOURCE-ONLY PRÜFUNG R1
Stand 16.10.2026

VERBINDLICHE REFERENZ
GitHub-R6-Run: 38530535344
BakaSU-Basis: 35222, 5b76b884c75f729a220bb317aa4a4fc78f0e0e9c
Offizieller SELinux-Fix: d7260ca1, nur bereits im R6-Prozess geprüft
SUSFS: 2.3.0, 5326e21a7eb232f9e21debdd5164e99bee3d1e2f (UNVERÄNDERT)
NoMount-R6: 1ded61dc908c511072162fa0bee44e6ccdb7b4c7
Neuer NoMount-stabil: 7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3
Wire-/Kernelprotokoll NoMount: 21

UPLOADS
1) Nur die Datei VEUX_R6_NM211_R1_MAIN.zip in ROOT der Repo main hochladen.
2) Die separate YAML VEUX_R6_NM211_R1_SOURCE_PREFLIGHT.yml in .github/workflows hochladen.
3) Danach NUR diese neue YAML unter GitHub Actions via Run workflow starten.
4) Nach Abschluss Report-Artefakt mit NOMOUNT211_R6_SOURCE_ONLY.json prüfen.

Die YAML verifiziert die ZIP SHA-256, entpackt den Inhalt ausschließlich
in GitHub Actions $RUNNER_TEMP (nicht in Repo/Main) und führt die
bestehende nachgewiesene R6-Build-/Reparaturpipeline nur bis zum
SOURCE PREFLIGHT aus. Der neue NoMount-Commit wird ausschließlich in der
temporären Laufzeit an Stelle von NoMount 1ded61dc verwendet.

SICHERHEIT
Kein Kernel-Build, kein Boot-Image, kein AK3, keine Flashfreigabe,
keine Repository-Änderung beim Ausführen des Workflows.
BakaSU-SUSFS-Buildsperre NICHT entfernen. BakaSU-/SUSFS-Pins nicht erhöhen.
Die zwei SUSFS-Abweichungen in SELinux hooks.c / selinuxfs.c sind weiterhin
separat zu portieren; diese ZIP behauptet KEINE Reparatur dieser Abweichung.
Die Testvariante verwendet die unveränderten neuen NoMount-Quellen.
Die neue NoMount-Makefile deaktiviert den lokalen Stackschutz: Für einen
späteren Kernel-Build muss das gesondert geprüft werden. Vorerst NO FLASH.

STATIC GREEN PASS bezieht sich ausschließlich auf dieses Workflow-/ZIP-
Preflight-Design und seine Offline-Tests. Eine echte CI-Ausführung,
Kernelkompilierung, Vendor-ABI-Prüfung und Gerätetest sind noch offen.
