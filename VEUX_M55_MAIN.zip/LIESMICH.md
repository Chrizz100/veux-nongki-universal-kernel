# VEUX M55 – Speicherfreigabe nach SIGKILL

Ziel ist der POCO X4 Pro 5G (veux), Xiaomi-Build V816.0.12.0.TKCMIXM mit 5.4.274-qgki-g82179e362f33. M55 ergänzt die Speicherfreigabe nach einem vom Android-Speicherdienst ausgelösten Prozessende. Das Paket dient zum Bauen und Prüfen in GitHub Actions.

## Auf GitHub starten

1. VEUX_M55_MAIN.zip als geschlossene ZIP-Datei ins Hauptverzeichnis des Repositorys hochladen.
2. VEUX_M55_REAPER_NOFLASH.yml unter .github/workflows/ im selben Branch speichern.
3. In Actions „VEUX M55 – Speicherfreigabe nach SIGKILL, QGKI 5.4.274“ manuell starten.

Der Workflow benötigt Lesezugriff auf die Actions-Artefakte 14752343203 (M54-Quellen) und 14706022228 (Xiaomi-Referenz aus M46) im selben Repository. Der M54-Quellstand ist laut GitHub bis 22. Dezember 2026 verfügbar. Die ZIPs, das Quellarchiv, die Stockdaten und die vier vom Patch betroffenen Quelldateien werden über feste SHA-256 identifiziert.

## Befund am bisherigen Bau

M54 hat alle 13 Jobschritte bestanden. Die beiden heruntergeladenen Archive enthalten 29 Nachweisdateien und vier Dateien zum erfolgreichen Quellstand. ZIP-Integrität und GitHub-Digests wurden überprüft. Image, vmlinux, eingebettete Konfigurationen und Bootlayout wurden mit den archivierten Nachweisen abgeglichen. Alle 3.148 Importverwendungen aus 37 Xiaomi-Modulen passen in CRC und Anbieter. Die Auswahl bei Speichermangel umfasst wie bei Xiaomi zwei Auswahlstellen für globale Prozesse und zwei für Speichergruppen. Bei zRAM ist lzo-rle als Standard im ausgeführten Initialisierungscode belegt. Drei ARM64-Atomikfunktionen entsprechen den geprüften Xiaomi-Instruktionsfolgen. [M54-Lauf und Job](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45016564118/job/137190037038)

Die Xiaomi-Originaldatei hat die SHA-256 ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5. Ihre eingebettete ARM64-Symboltabelle und die aufgelösten Zeichenketten zeigen, dass group_send_sig_info nach der Signalzustellung für lmkd und PreKillActionT den OOM-Reaper erreichen kann. Der Schalter vm.reap_mem_on_sigkill ist im Image mit 1 initialisiert. M54 fehlt diese Verknüpfung. Die öffentliche VEUX-Quelle dient zum Abgleich der C-Implementierung. [Xiaomi VEUX-Quelle](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/61397e524093d1ccb94769b5460825e2eaf8871e)

## Änderungen in M55

- kernel/signal.c berücksichtigt erfolgreich zugestellte SIGKILL-Signale aus dem Userspace. Die bestehende Signalberechtigungsprüfung, CAP_KILL und einer der beiden exakten Threadnamen sind Voraussetzung. Kernelinterne Signalquellen können den zusätzlichen Pfad nicht auslösen. Dazu gehören auch Aufrufe, die bereits eine Schreibsperre der Prozessliste halten.
- mm/oom_kill.c prüft unter der Tasksperre, ob der Prozess seinen Adressraum freigeben wird. Bei gemeinsamem Speicher werden weitere Prozesse berücksichtigt. Eine Referenz auf den Adressraum bleibt an die Signalstruktur gebunden. Der vorhandene Kernel-Reaper reiht jeden Speicherbereich einmal ein. Ein bereits an eine andere Adresse gebundener Reaper-Auftrag wird übersprungen.
- Das Signal löst die Speicherfreigabe ohne zusätzliche OOM-Speicherreserven für den Prozess aus. Ein erfolgreich zugelassener Auftrag setzt wie bei Xiaomi die OOM-Wartefrist zurück. Zwischen Signalpfad und Kernel-OOM werden Lese- und Schreibzugriffe auf die Frist explizit ausgeführt.
- kernel/sysctl.c und include/linux/oom.h stellen vm.reap_mem_on_sigkill für QGKI mit MMU bereit. Die Werte 0 und 1 sind zulässig, der Standard ist 1. Die Konfiguration bleibt bytegleich zu M54.
- Die Portierung deckt den Freigabepfad ab. Xiaomis zusätzliche Vordergrund-Diagnose (Speicherausgabe und optionaler Diagnose-Panic) gehört weiterhin zu den separat abzugleichenden Abweichungen. Die neuere memcg-Aufräumlogik von 5.4.274 im Seitenfehlerpfad ist erhalten.

## Prüfumfang und offene Arbeit

Die C-Tests kompilieren die betroffenen Produktivfunktionen mit simulierten Tasks, Signalzustellung und Sperren. Sie prüfen verweigerte und fehlgeschlagene Zustellung, beide erlaubten Threadnamen, Signalart, sysctl, bereits geleerte Speicherbereiche, gemeinsam genutzten Speicher und abweichende alte mm-Referenzen. In zwei Nebenläufigkeitstests senden acht Threads je 100 Signale an Ziele mit einer oder zwei Signalstrukturen. Je Adressraum entsteht ein Reaper-Auftrag. Die Tests laufen jeweils mit aktivierter und deaktivierter OOM-Priorisierung.

Vor dem Vollbau prüft der Workflow die ARM64-Verweise von Signalzustellung einschließlich Berechtigungsprüfung und Reaper-Warteschlange sowie den sysctl-Eintrag. Nach dem Linken prüft er den Pfad direkt im fertigen Image und vergleicht die Ergebnisse mit dem originalen Xiaomi-Kernel. Die vorhandenen OOM-, Atomics-, F2FS-, Bootinfo-, Konfigurations-, DTB- und ABI-Prüfungen laufen mit. Der statische Bootlayout-Test setzt das neue Image in Xiaomis Layout ein und prüft unter anderem Größe und Ramdisk.

Die 50 textlichen Abweichungen zur Stock-Konfiguration stehen vollständig in Restkonfiguration-M54.csv. Für zwei LSE- und fünf zRAM-Einträge ist das verglichene Laufzeitverhalten im Binärcode geklärt. Die übrigen 43 Zeilen bestehen aus Werkzeug-, Darstellungs- und Funktionsunterschieden. Weitere Arbeiten betreffen unter anderem die thermische CPU-Isolation, das MIUI-zRAM-Tracking und UFS-Firmware-Zuordnungen. Ein Start des Kandidaten auf dem Gerät mit Boot-, Verity-, UFS- und F2FS-Prüfung sowie ein erprobter Rückweg stehen aus. Eine Flash-Freigabe bleibt offen.

## Lokal geprüfter M55-Vollbau

Das M55-Image und alle vier vorgesehenen Kernelmodule wurden mit der Android-Clang-Werkzeugkette gebaut. Die Prüfsumme des lokalen ARM64-Image lautet c48dad956041b19e04d731421228dff4e21e36d476b052b3cf2cb6e076ddebfb. Die Vendor-CRC-Tabelle stimmt in allen 3.148 Einträgen mit M54 überein. Der neue Signalpfad ist im verlinkten Image nachgewiesen. Konfiguration, Kernelkennung, VEUX-DTB, OOM-Auswahl, zRAM-Standard, die drei geprüften Atomikpfade und das statische Bootlayout haben die jeweiligen Prüfungen bestanden. Die F2FS-Hosttests liefen lokal mit deaktiviertem LeakSanitizer, die ARM64-Atomiktests unter QEMU. Den vollständigen Lauf in GitHub Actions kann der Nutzer mit der mitgelieferten YAML auslösen. Die kompakten lokalen Nachweise stehen in Nachweise/Lokal-*.json.
