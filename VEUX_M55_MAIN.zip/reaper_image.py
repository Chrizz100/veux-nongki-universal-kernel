"""Verify the memory-reaper path in the pinned Xiaomi ROM or a linked ARM64 Image."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import tempfile
from check import BOOT, STOCK_IMAGE, BASE_IMAGE, require, sha
from memory_image import Code, mapped_symbols, stock_symbols

def direct_call(code, ins, name):
    target = code.names.get(name)
    return [pc for pc, op, arg in ins if op in ('bl','b') and int(arg,16)==target]

def strings_in_stock(code, sig, strcmp):
    # In Xiaomi's two strcmp calls the literal in x1 is loaded PC-relatively.
    strings = []
    for i,(pc,op,arg) in enumerate(sig):
        if op!='bl' or int(arg,16)!=strcmp:
            continue
        addr = None
        for _,op,args in sig[max(0,i-5):i]:
            fields = args.split(', ')
            if op=='bl' or op=='blr':
                addr = None
            if fields[0]!='x1':
                continue
            if op=='adrp':
                addr=int(fields[1],16)
            elif op=='add' and fields[1]=='x1' and addr is not None:
                addr+=int(fields[2][1:],0)
            else:
                addr=None
        require(addr is not None,'Xiaomi sender name has no resolved address')
        strings.append(code.image[addr:code.image.index(0,addr,addr+16)].decode())
    require(strings==['lmkd','PreKillActionT'],'Xiaomi sender names: '+repr(strings))

def inspect(image, syms, tc, mode):
    default = [a for a,t,n in syms if n=='sysctl_reap_mem_on_sigkill' and t.lower()=='d']
    with tempfile.TemporaryDirectory() as tmp:
        code = Code(image,syms,tc,Path(tmp))
        if mode=='m54':
            require(not default and 'add_to_oom_reaper' not in code.names and
                    b'reap_mem_on_sigkill\0' not in image,'M54 baseline unexpectedly has the path')
            return {'present':False}
        require(len(default)==1 and 0<=default[0]<=len(image)-4 and
                struct.unpack_from('<i',image,default[0])[0]==1,'Unexpected sysctl default')
        require(b'reap_mem_on_sigkill\0' in image,'Missing sysctl string')
        sig=code.instructions('group_send_sig_info')
        if mode=='stock':
            strcmp, = [a for a,t,n in syms if n=='strcmp' and t.upper() in ('T','W')]
            strings_in_stock(code,sig,strcmp)
        dispatch=direct_call(code,sig,'do_send_sig_info')
        gate=direct_call(code,sig,'capable')
        entry=direct_call(code,sig,'add_to_oom_reaper')
        require(len(dispatch)==len(gate)==1 and dispatch[0]<gate[0],'Signal delivery/capability call order')
        if entry:
            require(len(entry)==1 and gate[0]<entry[0],'Reaper call before signal checks')
            reaper=code.instructions('add_to_oom_reaper')
            lower=-1
        else:
            # ThinLTO can inline the helper directly into group_send_sig_info.
            reaper=sig
            lower=gate[0]
        eligible=direct_call(code,reaper,'task_will_free_mem')
        wake=direct_call(code,reaper,'wake_oom_reaper')
        require(len(eligible)==len(wake)==1 and lower<eligible[0]<wake[0],
                'Missing linked eligibility and wake path')
        return {'present':True,'sysctl_default':1,'signal_delivery_then_capability':True,
                'eligibility_then_reaper_wake':True}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=['stock','m54','candidate'])
    p.add_argument('tc',type=Path)
    p.add_argument('file',type=Path)
    p.add_argument('result',type=Path)
    p.add_argument('--map',type=Path)
    a=p.parse_args()
    raw=a.file.read_bytes()
    if a.mode=='stock':
        require(sha(a.file)==BOOT,'Xiaomi boot image identity')
        raw=raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
        require(hashlib.sha256(raw).hexdigest()==STOCK_IMAGE,'Xiaomi kernel identity')
        syms=stock_symbols(raw)
    else:
        if a.mode=='m54':
            require(sha(a.file)==BASE_IMAGE,'M54 image identity')
        syms=mapped_symbols(a.map)
    proof=inspect(raw,syms,a.tc,a.mode)
    a.result.write_text(json.dumps(proof,indent=2)+'\n')
    print(a.mode,proof)

if __name__=='__main__':
    main()
