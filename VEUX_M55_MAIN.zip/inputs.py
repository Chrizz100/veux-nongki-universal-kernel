"""Authenticate the M54 source and extract the matching Xiaomi reference image."""
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m54.zip') as archive:
    require(sha(work/'m54.zip')=='fc34faeda49fd335cc0ff3b2d1b23fed77043cd7d13abaee0bdfc746e395b631', 'M54 artifact digest')
    manifest=json.loads(archive.read('M54_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M54 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M54 config identity')
    archive.extract('M54-kernel-source.tar.gz',work)
tar=work/'M54-kernel-source.tar.gz'
require(sha(tar)=='57e00768cf11b27035db193c342c7ad653fb313e5ab3f836835b929d330976eb','M54 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'reaper.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
