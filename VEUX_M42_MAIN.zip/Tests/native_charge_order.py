"""Real BQ helpers + IIO callback, deterministic pthread interleavings and bus faults."""
import argparse,importlib.util,json,os,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
BQ='drivers/power/supply/qcom/bq2589x_charger.c'
def harness(source):
 parent=Path(os.environ['M41_DIR']);s=importlib.util.spec_from_file_location('native_m41_support',parent/'Tests/native_wt_current.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
 prefix,defs,body,reset,baseline=m.bq_parts()
 prefix=prefix.replace('registers[256], saved_registers[256]','registers[256]').replace('events[256], saved_events[256]','events[256]')
 prefix=prefix.replace('struct mutex io_lock; bool stopping;','struct mutex io_lock, charge_lock; uint64_t charge_request_seq; bool charge_requested, vindpm_active, stopping;')
 prefix+='\ntypedef uint64_t u64;\n#define dev_err_ratelimited(...) ((void)0)\n#define dev_info(...) ((void)0)\n#define BQ2589X_VBUS_USB_SDP 1\n'
 reset=reset.replace('if(io_initialized)pthread_mutex_destroy(&state.io_lock.value);','if(io_initialized){pthread_mutex_destroy(&state.io_lock.value);pthread_mutex_destroy(&state.charge_lock.value);}')
 reset=reset.replace('pthread_mutex_init(&state.io_lock.value,NULL);','pthread_mutex_init(&state.io_lock.value,NULL);pthread_mutex_init(&state.charge_lock.value,NULL);state.charge_requested=true;')
 for n in ['bq2589x_enable_charger','bq2589x_disable_charger','bq_iio_write_raw_unlocked','bq_iio_write_raw']:
  body=body.replace(m.function(baseline,n),m.function(source,n))
 if '__bq2589x_set_charger(' in source:
  at=body.index(m.function(source,'bq2589x_enable_charger'))
  body=body[:at]+m.function(source,'__bq2589x_set_charger')+'\n'+m.function(source,'bq2589x_set_charger_request')+'\n'+body[at:]
 sync=r'''
static atomic_int asleep,released;static int pause_measure,sleeps;
static void msleep(int ms){if(ms!=1000)abort();sleeps++;if(pause_measure){atomic_store(&asleep,1);while(!atomic_load(&released))sched_yield();}}
'''
 body+='\n'+m.function(source,'bq2589x_adc_read_vbus_volt')+'\n'+m.function(source,'bq2589x_adjust_absolute_vindpm')
 tests=r'''
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void prepare(int on,int otg,int stale,int chip){reset(chip,1,0,0,1);pause_measure=sleeps=0;atomic_store(&asleep,0);atomic_store(&released,0);state.vbus_type=BQ2589X_VBUS_USB_SDP;registers[BQ2589X_REG_03]&=~(BQ2589X_CHG_CONFIG_MASK|BQ2589X_OTG_CONFIG_MASK);if(on)registers[BQ2589X_REG_03]|=BQ2589X_CHG_CONFIG_MASK;if(otg)registers[BQ2589X_REG_03]|=BQ2589X_OTG_CONFIG_MASK;state.status=stale?BQ2589X_STATUS_CHARGE_ENABLE:0;}
static void*measurement(void*p){bq2589x_adjust_absolute_vindpm(&state);return NULL;}
static int charge(int on){struct iio_chan_spec c={PSY_IIO_CHARGING_ENABLED};return bq_iio_write_raw(&iio,&c,on,0,0);}
static int unlocked(void){int rc=pthread_mutex_trylock(&state.charge_lock.value);if(!rc)pthread_mutex_unlock(&state.charge_lock.value);return rc==0;}
static int writes_to(int start,int reg){int n=0;for(int i=start;i<used;i++)if(events[i].kind==WRITE&&events[i].a==reg)n++;return n;}
int main(void){int sequential=0,concurrent=0,faults=0;
 for(int chip=0;chip<2;chip++)for(int on=0;on<2;on++)for(int otg=0;otg<2;otg++)for(int stale=0;stale<2;stale++)for(int type=1;type<=2;type++){
  prepare(on,otg,stale,chip);state.vbus_type=type;unsigned char saved[256];memcpy(saved,registers,sizeof(saved));bq2589x_adjust_absolute_vindpm(&state);
  CHECK((registers[BQ2589X_REG_03]&(BQ2589X_CHG_CONFIG_MASK|BQ2589X_OTG_CONFIG_MASK))==(saved[BQ2589X_REG_03]&(BQ2589X_CHG_CONFIG_MASK|BQ2589X_OTG_CONFIG_MASK)));
  CHECK(state.charge_request_seq==0&&!state.vindpm_active&&unlocked());
  if(!on||otg){CHECK(sleeps==0&&counts[WRITE]==0);CHECK(!memcmp(saved,registers,sizeof(saved)));}
  else{CHECK(sleeps==1);CHECK(writes_to(0,BQ2589X_REG_03)==2&&writes_to(0,BQ2589X_REG_0D)==1);CHECK((registers[BQ2589X_REG_0D]&BQ2589X_VINDPM_MASK)==(((type==1?4400:4500)-BQ2589X_VINDPM_BASE)/BQ2589X_VINDPM_LSB));}
  sequential++;
 }
 prepare(1,0,0,1);state.stopping=true;bq2589x_adjust_absolute_vindpm(&state);CHECK(used==0&&unlocked());
 prepare(1,0,0,1);state.charge_requested=false;bq2589x_adjust_absolute_vindpm(&state);CHECK(used==0&&unlocked());
 prepare(1,0,0,1);state.vindpm_active=true;bq2589x_adjust_absolute_vindpm(&state);CHECK(used==0&&state.vindpm_active&&unlocked());
 /* Interrupt at the actual measurement sleep. The request must return before resume. */
 for(int repeat=0;repeat<50;repeat++)for(int action=0;action<7;action++){
  prepare(1,0,0,repeat&1);pause_measure=1;pthread_t thread;CHECK(!pthread_create(&thread,NULL,measurement,NULL));while(!atomic_load(&asleep))sched_yield();
  CHECK(state.vindpm_active&&!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));int rc=0,expected=0;
  if(action==0)rc=charge(0);
  if(action==1)rc=bq2589x_disable_charger(&state); /* Same helper used by actual thermal monitor. */
  if(action==2){struct iio_chan_spec c={PSY_IIO_OTG_ENABLE};rc=bq_iio_write_raw(&iio,&c,1,0,0);}
  if(action==3){rc=charge(0);CHECK(rc==0);rc=charge(1);expected=1;}
  if(action==4){state.stopping=true;}
  if(action==5){fail_kind=WRITE;fail_at=counts[WRITE]+1;fail_code=-EREMOTEIO;rc=charge(0);CHECK(rc==-EREMOTEIO);fail_kind=0;rc=0;}
  if(action==6){fail_kind=READ;fail_at=counts[READ]+1;fail_code=-EIO;rc=charge(0);CHECK(rc==-EIO);fail_kind=0;rc=0;}
  CHECK(rc==0&&unlocked());int before=used;atomic_store(&released,1);CHECK(!pthread_join(thread,NULL));
  CHECK(!!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK)==expected);CHECK(!state.vindpm_active&&unlocked());CHECK(writes_to(before,BQ2589X_REG_03)==0&&writes_to(before,BQ2589X_REG_0D)==0);
  if(action==2)CHECK(registers[BQ2589X_REG_03]&BQ2589X_OTG_CONFIG_MASK);
  concurrent++;
 }
 /* All transfers in the successful sequence, including read retries and restore. */
 prepare(1,0,0,1);bq2589x_adjust_absolute_vindpm(&state);int reads=counts[READ],writes=counts[WRITE];
 for(int err=0;err<4;err++)for(int kind=READ;kind<=WRITE;kind++)for(int at=1;at<=(kind==READ?reads:writes);at++){
  int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENXIO};prepare(1,0,0,1);fail_kind=kind;fail_at=at;fail_code=errors[err];bq2589x_adjust_absolute_vindpm(&state);
  CHECK(last_failure>=0&&!state.vindpm_active&&unlocked());CHECK(!writes_to(last_failure+1,BQ2589X_REG_0D));
  if(kind==READ&&at==1)CHECK(counts[WRITE]==0&&sleeps==0);
  CHECK(state.charge_request_seq==0);faults++;
 }
 /* A failed off request retains off intent: a later measurement cannot turn on. */
 for(int kind=READ;kind<=WRITE;kind++){
  prepare(1,0,1,1);fail_kind=kind;fail_at=1;fail_code=-EIO;CHECK(charge(0)==-EIO);CHECK(!state.charge_requested&&state.charge_request_seq==1);fail_kind=0;int before=used;bq2589x_adjust_absolute_vindpm(&state);CHECK(used==before&&unlocked());
 }
 printf("M42_CHARGE_ORDER=PASS; assertions=%d; sequential=%d; concurrent=%d; bus_faults=%d; real_iio_off_thermal_helper_otg_shutdown_and_failed_off\n",assertions,sequential,concurrent,faults);return 0;
}
'''
 return prefix+'\n'+defs+'\n'+sync+'\n'+body+'\n'+reset+'\n'+tests
def run(source):
 with tempfile.TemporaryDirectory(prefix='m42-charge-order-')as t:
  c=Path(t)/'test.c';e=Path(t)/'test';c.write_text(harness(Path(source).read_text()))
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(e)],check=True)
  return subprocess.run([str(e)],text=True,capture_output=True,timeout=30)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args();r=run(a.source);print(r.stdout,end='');print(r.stderr,end='',file=__import__('sys').stderr);raise SystemExit(r.returncode)
