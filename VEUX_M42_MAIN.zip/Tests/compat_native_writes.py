"""Run the unchanged writer fault matrix with actual M42 helpers and mutex storage."""
import ast,os,subprocess,sys,tempfile
from pathlib import Path
def run(source):
 parent=Path(os.environ['M40_DIR']).resolve();p=parent/'Tests/native_bq_writes.py';tree=ast.parse(p.read_text())
 class Storage(ast.NodeTransformer):
  def visit_Constant(self,n):
   if isinstance(n.value,str):
    s=n.value
    s=s.replace('struct mutex io_lock; bool stopping;','struct mutex io_lock, charge_lock; uint64_t charge_request_seq; bool charge_requested, vindpm_active, stopping;')
    s=s.replace('typedef uint8_t u8;','typedef uint8_t u8; typedef uint64_t u64;')
    s=s.replace('if(io_initialized)pthread_mutex_destroy(&state.io_lock.value);','if(io_initialized){pthread_mutex_destroy(&state.io_lock.value);pthread_mutex_destroy(&state.charge_lock.value);}')
    s=s.replace('pthread_mutex_init(&state.io_lock.value,NULL);','pthread_mutex_init(&state.io_lock.value,NULL);pthread_mutex_init(&state.charge_lock.value,NULL);state.charge_requested=true;')
    n.value=s
   return n
 tree=Storage().visit(tree);code=ast.unparse(ast.fix_missing_locations(tree))
 code=code.replace("ROOT = Path(__file__).resolve().parents[1]",'ROOT = Path('+repr(str(parent))+')',1)
 target="    reference = function(baseline, 'bq2589x_usb_switch')"
 assert code.count(target)==1
 code=code.replace(target,"    body = body.replace(function(source, 'bq2589x_enable_charger'), function(source, '__bq2589x_set_charger') + '\\n' + function(source, 'bq2589x_set_charger_request') + '\\n' + function(source, 'bq2589x_enable_charger'), 1)\n"+target,1)
 with tempfile.TemporaryDirectory(prefix='m42-writes-support-')as t:
  p=Path(t)/'native.py';p.write_text(code);return subprocess.run([sys.executable,'-B',str(p),str(source)],text=True,capture_output=True,timeout=45)
if __name__=='__main__':
 r=run(Path(sys.argv[1]));print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr);raise SystemExit(r.returncode)
