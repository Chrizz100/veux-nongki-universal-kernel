import argparse,contextlib,hashlib,importlib.util,io,json,os,re,shutil,subprocess,sys,tempfile,unittest,yaml
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
s=importlib.util.spec_from_file_location('m42_tested',ROOT/'Tools/m42_charge_order.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
BASE=Path(os.environ.get('M42_PARENT_ROOT',str(ROOT.parent/'m41-success-run')))
P41=Path(os.environ.get('M41_DIR',str(BASE/'veux-m41-wt-current-tools')))
P40=Path(os.environ.get('M40_DIR',str(BASE/'veux-m40-bq-numeric-tools')))
P28=Path(os.environ.get('M28_DIR',str(BASE/'veux-m28-wt-tools')))
P27=Path(os.environ.get('M27_DIR',str(BASE/'veux-m27-sc8551-tools')))
P26=Path(os.environ.get('M26_DIR',str(BASE/'veux-m26-rpm-tools')))
def args():return argparse.Namespace(m41_tool=P41/'Tools/m41_wt_current.py',m40_tool=P40/'Tools/m40_bq_numeric_inputs.py',m28_tool=P28/'Tools/m28_wt_reporting.py')
def refresh(root):
 files=sorted(p for p in root.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt');(root/'MANIFEST_SHA256.txt').write_text(''.join(m.sha(p)+'  '+p.relative_to(root).as_posix()+'\n'for p in files))
class SourceTests(unittest.TestCase):
 def test_package(self):m.verify_package()
 def test_real_parallel_charge_intent_and_bus_fault_matrix(self):
  r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_charge_order.py'),str(ROOT/'After'/m.BQ)],text=True,capture_output=True,timeout=40,env=dict(os.environ,M41_DIR=str(P41),M40_DIR=str(P40)))
  self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn('concurrent=350; bus_faults=32;',r.stdout);self.assertNotIn('runtime error:',r.stderr)
 def test_all_writer_success_traces_and_faults_on_actual_new_helpers(self):
  r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/compat_native_writes.py'),str(ROOT/'After'/m.BQ)],text=True,capture_output=True,timeout=50,env=dict(os.environ,M40_DIR=str(P40)))
  self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn('BQ_WRITE_ERROR_HOST_TESTS=PASS',r.stdout);self.assertNotIn('runtime error:',r.stderr)
 def test_original_restore_is_a_negative_control(self):
  parent=m.load_parent(args().m41_tool);new=(ROOT/'After'/m.BQ).read_text();old=(ROOT/'Before'/m.BQ).read_text();bad=new.replace(parent.function(new,'bq2589x_adjust_absolute_vindpm'),parent.function(old,'bq2589x_adjust_absolute_vindpm'))
  with tempfile.TemporaryDirectory()as t:
   p=Path(t)/'bad.c';p.write_text(bad);r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_charge_order.py'),str(p)],text=True,capture_output=True,timeout=40,env=dict(os.environ,M41_DIR=str(P41),M40_DIR=str(P40)))
   self.assertNotEqual(r.returncode,0);self.assertIn('FAIL line',r.stderr)
 def test_late_request_guard_mutation_fails_actual_parallel_test(self):
  source=(ROOT/'After'/m.BQ).read_text();old='if (request_seq != bq->charge_request_seq || READ_ONCE(bq->stopping))';self.assertEqual(source.count(old),1);source=source.replace(old,'if (request_seq != bq->charge_request_seq && false)',1)
  with tempfile.TemporaryDirectory()as t:
   p=Path(t)/'guard_removed.c';p.write_text(source);r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_charge_order.py'),str(p)],text=True,capture_output=True,timeout=40,env=dict(os.environ,M41_DIR=str(P41),M40_DIR=str(P40)))
   self.assertNotEqual(r.returncode,0);self.assertIn('FAIL line',r.stderr)
 def test_self_consistent_unapproved_source_is_rejected(self):
  with tempfile.TemporaryDirectory()as t:
   p=Path(t);shutil.copytree(ROOT,p,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'));c=p/'After'/m.BQ;c.write_text(c.read_text().replace('temperature > 480','temperature > 481'));j=json.loads((p/'References/PROFILE.json').read_text());j['after_sha256']=m.sha(c);(p/'References/PROFILE.json').write_text(json.dumps(j));refresh(p)
   with patch.object(m,'ROOT',p),self.assertRaisesRegex(ValueError,'INDEPENDENT_SOURCE'):m.verify_package()
 def test_actual_immutable_chain_and_other_headers_preserved(self):
  with tempfile.TemporaryDirectory()as t,m.engine(args())as parent:
   source=Path(t)
   for p in[P28,P40]:shutil.copytree(p/'Before',source,dirs_exist_ok=True)
   with parent.engine(args().m40_tool,args().m28_tool)as(bq,wt):
    wt.apply_source(source);bq.apply_source(source);self.assertEqual(m.check_file(source),{m.BQ:m.AFTER});parent.check_source(source,after=True)
    (source/'include/linux/power_supply.h').write_bytes(b'forged header')
    with self.assertRaises(ValueError):wt.source_check(source,after=True)
 def test_lower_build_callback_chain_before_compile_and_restoration(self):
  with tempfile.TemporaryDirectory()as t,m.engine(args())as parent:
   source=Path(t)/'candidate-source'
   for p in[P26,P27,P28,P40]:shutil.copytree(p/'Before',source,dirs_exist_ok=True)
   with parent.engine(args().m40_tool,args().m28_tool)as(bq,wt):
    sc=wt.load_parent(P27/'Tools/m27_sc8551.py');rpm=sc.load_parent(P26/'Tools/m26_rpm_sleep.py');saved=wt.apply_source
    def stop(a):
     rpm.apply_source(source);rpm.source_check(source,after=True);sc.source_check(source,after=True);wt.source_check(source,after=True);bq.source_check(source,after=True);parent.check_source(source,after=True);m.check_file(source);raise RuntimeError('ACTUAL_M42_CHAIN_BEFORE_COMPILER')
    a=args();a.output=t;a.m27_tool='fixture';a.m26_tool='fixture'
    with patch.object(wt,'load_parent',return_value=sc),patch.object(sc,'load_parent',return_value=rpm),patch.object(rpm,'build',side_effect=stop),patch.object(parent,'engine',return_value=contextlib.nullcontext((bq,wt))),patch.object(m,'engine',return_value=contextlib.nullcontext(parent)):
     with self.assertRaisesRegex(RuntimeError,'ACTUAL_M42_CHAIN'):m.build(a)
    self.assertIs(wt.apply_source,saved);r=json.loads((Path(t)/'M42_RESULT.json').read_text());self.assertFalse(r['kernel_compiled']);self.assertFalse(r['flash_allowed'])
 def test_old_source_and_missing_branch_rejected(self):
  with tempfile.TemporaryDirectory()as t:
   p=Path(t);shutil.copytree(ROOT/'Before',p/'candidate-source');(p/'candidate-out/arch/arm64/boot').mkdir(parents=True)
   with self.assertRaisesRegex(ValueError,'M42_CHARGE_ORDER_SOURCE'):m.proof(p)
   shutil.copytree(ROOT/'After',p/'candidate-source',dirs_exist_ok=True)
   for n in ['arch/arm64/boot/Image','vmlinux']:(p/'candidate-out'/n).write_bytes(b'old kernel')
   with self.assertRaisesRegex(ValueError,'NOT_LINKED'):m.proof(p)
 def test_package_failure_quarantines_pair(self):
  with tempfile.TemporaryDirectory()as t:
   out=Path(t);(out/'review').mkdir();(out/'review/untrusted').write_bytes(b'bad');a=args();a.output=out
   with patch.object(m,'verify_fresh',side_effect=[{'release':{}},RuntimeError('fail')]),patch.object(m,'engine')as e:
    e.return_value.__enter__.return_value.package.side_effect=RuntimeError('pack failed')
    with self.assertRaisesRegex(RuntimeError,'pack failed'):m.package(a)
   self.assertFalse((out/'review').exists());self.assertTrue((out/'unverified-review').is_dir());self.assertFalse(json.loads((out/'M42_PACKAGE_RESULT.json').read_text())['static_boot_path_pass'])
@unittest.skipUnless(os.environ.get('M42_WORKFLOW'),'M42_WORKFLOW required')
class WorkflowTests(unittest.TestCase):
 def workflow(self):return yaml.safe_load(Path(os.environ['M42_WORKFLOW']).read_text())
 def test_all_eighteen_preflight_calls_use_real_checkout(self):
  j=next(iter(self.workflow()['jobs'].values()));r=j['steps'][11]['run'];self.assertEqual(r.count('--source "$GITHUB_WORKSPACE/kernel"'),18);self.assertNotIn('$R9_SNAPSHOT',r)
 def test_current_commands_and_cli_with_spaces(self):
  for op,index,count in [('build',114,20),('package',115,14)]:
   with self.subTest(op=op),tempfile.TemporaryDirectory(prefix='m42 paths with spaces ')as t:
    root=Path(t);(root/'bin').mkdir();capture=root/'capture';p=root/'bin/python3';p.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M42_CAPTURE"\n');p.chmod(0o755)
    command=next(iter(self.workflow()['jobs'].values()))['steps'][index]['run'];self.assertEqual(command,(ROOT/f'References/M42_{op.upper()}_COMMAND.sh').read_text())
    names=set(re.findall(r'\$([A-Z][A-Z0-9_]*)',command));env=dict(os.environ,**{n:str(root/(n+' spaces'))for n in names},PATH=str(root/'bin')+os.pathsep+os.environ['PATH'],M42_CAPTURE=str(capture));r=subprocess.run(['bash','-c',command],env=env,text=True,capture_output=True,timeout=10);self.assertEqual(r.returncode,0,r.stderr)
    argv=capture.read_bytes().decode().split('\0');self.assertEqual(argv.pop(),'');self.assertEqual(argv.pop(0),'-B');a=m.parser().parse_args(argv[1:]);self.assertEqual(len(vars(a)),count+1);self.assertEqual(a.m41_tool,env['M41_DIR']+'/Tools/m41_wt_current.py')
if __name__=='__main__':unittest.main()
