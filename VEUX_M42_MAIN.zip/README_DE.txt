VEUX M42 – Ladeanforderung über VINDPM-Messung erhalten – NOFLASH

Geprüfter Ausgang: Run 44022208549, Commit 1953655b9f47825d1f821f93b398750ca99e7e43.
Alle 32 Artefakte geprüft. Vollständiger M41-Bau: 40 make-Aufrufe erfolgreich,
1.423 OEM-Import-CRCs passend, 37 bekannte Module, keine fehlenden/abweichenden CRCs.
.config, eingebettete Konfiguration, vmlinux und autoconf bleiben nachweislich konsistent.
Boot.img und AK3 wurden unabhängig neu zusammengesetzt und sind bytegleich zum Run.
Kernelkennung: 5.4.274-qgki-g82179e362f33.

M42 repariert den nachgewiesenen VINDPM-Konflikt: Nach der Messpause darf keine
zwischenzeitliche Ladeabschaltung überschrieben werden. Bisher ausgeschaltetes
Laden, OTG und fehlgeschlagene neuere Abschaltanforderungen werden berücksichtigt.
Die neue Sperre umfasst nur kurze Zustands-/Busoperationen; weder die Messpause
noch Provider-Aufrufe oder das Warten auf Workqueues finden unter ihr statt.
Nur der private BQ-Treiber ändert sich. WT-M41, Header, Defconfig, Release und
vollständiger Exporttabellen-Abgleich bleiben erhalten. Die originalen M41-/M40-
Werkzeuge werden unverändert per Commit/SHA geladen; nur der exakt gepinnte
M42-BQ-Postimage wird zusätzlich zugelassen. Neue Quell-/Objekt-/Link-Nachweise
sind zwingend; alte M41-Produkte dürfen den M42-Bau nicht ersetzen.

Upload vom Smartphone:
1. VEUX_M42_MAIN.zip unverändert ins Hauptverzeichnis der GitHub-Repo hochladen.
2. VEUX_M42_YAML.zip entpacken. Die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml
   am gleichen Pfad ersetzen. Den festen Workflow-Dateinamen beibehalten.
3. Workflow „VEUX M42 Charge Intent across VINDPM - NOFLASH“ manuell starten.
   Die YAML lädt M41 und ältere Basen selbst über feste Commits/Prüfsummen.

Die Dateien dienen dem nächsten GitHub-Neubau. Ein vollständiger M42-Kernel-Bau
ist lokal noch nicht erfolgt. Lokale echte ARM64/CFI-Treiberkompilierung sowie
Hosttests sind in Reports dokumentiert. Ein grüner CI-Lauf ist kein Gerätetest.

Offen: weitere HiZ-/Fehler-Reinitialisierungsabläufe, WT-/Provider-Lebensdauer,
restliche Wertebereiche und historische Abweichungen, danach kontrollierter
Gerätetest mit Wiederherstellungsmöglichkeit. Keine Flash-Freigabe.
