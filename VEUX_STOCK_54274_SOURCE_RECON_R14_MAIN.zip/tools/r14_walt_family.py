#!/usr/bin/env python3
"""R14: Hash-bound, read-only *compile* gate for complete Qualcomm WALT family.
Never a production WALT patch, boot.img, full-link, or OEM ABI approval.
"""
import argparse
import hashlib
import io
import json
import re
import tarfile
import zipfile
from pathlib import Path

SCHEMA='VEUX_R14_FULL_QUALCOMM_WALT_COMPONENT_COMPILER_NOFLASH'
R13_SHA='71badc859c4c204edef6996fa572e558b26a646a616d1b7859d07651a6cafe19'
PAIR_COMMIT='01cb3a8824b7b4caf3e3540274e71abba5ade538'
DONOR_COMMIT='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
STOCK_TASK_SHA='a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
NEW_OBJECTS={
    'BOOST':'techpack/sched/boost.o',
    'SCHED_AVG':'techpack/sched/sched_avg.o',
    'QC_VAS':'techpack/sched/qc_vas.o',
    'CORE_CTL':'techpack/sched/core_ctl.o',
    'TRACE':'techpack/sched/trace.o',
    'CPU_BOOST':'techpack/sched/cpu-boost.o',
}
PRIOR_OBJECTS={
    'WEAK':'kernel/sched/walt.o',
    'REAL':'techpack/sched/walt.o',
    'SYSCTL':'kernel/sysctl.o',
}
ALL_OBJECTS={**PRIOR_OBJECTS,**NEW_OBJECTS}
WALT_RULE=['walt.o','boost.o','sched_avg.o','qc_vas.o','core_ctl.o','trace.o']
CPU_RULE=['cpu-boost.o']

def sha256(b):return hashlib.sha256(b).hexdigest()
def sha_git_blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def verify_main(root):
    root=Path(root)
    if not root.is_dir() or root.is_symlink():raise ValueError('R14_MAIN_NOT_DIR')
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if m.get('schema')!=SCHEMA or m.get('flash_allowed') is not False or m.get('full_walt_linked') is not False or m.get('oem_abi_verified') is not False or m.get('production_patch_approved') is not False or m.get('run_full_kernel_build') is not False:
        raise ValueError('R14_UNSAFE_MANIFEST')
    if m.get('r13_sha256')!=R13_SHA or m.get('pair_commit')!=PAIR_COMMIT or m.get('donor_commit')!=DONOR_COMMIT or m.get('stock_task_sha256')!=STOCK_TASK_SHA:
        raise ValueError('R14_PIN_DRIFT')
    known={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if known != set(m['files'])|{'MANIFEST_SHA256.json'}:raise ValueError('R14_UNEXPECTED_FILESET')
    if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('R14_SYMLINK')
    for key,expected in m['files'].items():
        f=root/key
        if not f.is_file() or sha256(f.read_bytes())!=expected:raise ValueError('R14_INPUT_TAMPER:'+key)
    if sha256((root/'reference/R13_MAIN_ORIGINAL.zip').read_bytes())!=R13_SHA:raise ValueError('R14_NESTED_R13_TAMPER')
    with zipfile.ZipFile(root/'reference/R13_MAIN_ORIGINAL.zip') as z:
        if z.testzip():raise ValueError('R14_NESTED_BAD_ZIP')
        p=json.loads(z.read('MANIFEST_SHA256.json'))
        if p.get('schema')!='VEUX_R13_VERIFIED_STOCK_SYSCTL_FUNCTION_PAIR_NOFLASH' or p.get('flash_allowed') is not False or p.get('stock_sysctl_sha256')!='a40790ea7884c5fad110f17d56445bef069fb7eed1251c8d0ea1a00611cafe60':
            raise ValueError('R14_NESTED_R13_WRONG_SOURCE')
    return m

def validate_walt_rules(makefile, conf, cpu_freq_enabled):
    def rule(variable):
        ms=re.findall(r'^obj-\$\('+re.escape(variable)+r'\)\s*\+=\s*(.+?)\s*$',makefile,re.M)
        if len(ms)!=1:raise ValueError('R14_NO_UNIQUE_'+variable+'_MAKE_RULE')
        names=ms[0].split()
        if any(not x.endswith('.o') for x in names):raise ValueError('R14_SUSPICIOUS_MAKE_RULE')
        return names
    walt=rule('CONFIG_SCHED_WALT')
    cpu=rule('CONFIG_CPU_BOOST')
    if walt!=WALT_RULE or cpu!=CPU_RULE:raise ValueError('R14_WALT_MAKEFILE_GAP')
    if cpu_freq_enabled:
        if 'ifeq ($(CONFIG_CPU_FREQ), y)' not in conf or 'CONFIG_CPU_BOOST=y' not in conf:
            raise ValueError('R14_CPU_FREQ_BOOST_RULE_GAP')
    return {'WALT':walt,'CPU_BOOST':cpu,'cpu_freq_enabled':cpu_freq_enabled}

def audit_original_walt_sources(r11):
    r11=Path(r11)
    stock_config=(r11/'reference/stock.config').read_text()
    if 'CONFIG_SCHED_WALT=y' not in stock_config.splitlines() or 'CONFIG_CPU_FREQ=y' not in stock_config.splitlines():
        raise ValueError('R14_STOCK_CONFIG_DRIFT')
    if sha256((r11/'reference/stock_sched.h').read_bytes())!=STOCK_TASK_SHA:raise ValueError('R14_STOCK_TASK_DRIFT')
    tar_path=r11/'reference/R10_PINNED_WALT_SOURCES.tar.gz'
    with tarfile.open(tar_path,mode='r:gz') as t:
        entries={a.name:a for a in t.getmembers()}
        for name in ['SOURCE_PROVENANCE.json','PAIR_SOURCE/techpack/sched/Makefile','PAIR_SOURCE/techpack/sched/sched.conf',*[f'PAIR_SOURCE/{x.replace(".o",".c")}' for x in ALL_OBJECTS.values() if x.startswith('techpack/')]]:
            if name not in entries or not entries[name].isfile() or entries[name].size>250_000:
                raise ValueError('R14_MISSING_OR_NONFILE_PINNED_WALT:'+name)
        prov=json.load(t.extractfile(entries['SOURCE_PROVENANCE.json']))
        if prov.get('commit')!=PAIR_COMMIT:raise ValueError('R14_WRONG_WALT_SOURCE_COMMIT')
        for obj in (x for x in ALL_OBJECTS.values() if x.startswith('techpack/')):
            c_path=obj.replace('.o','.c')
            b=t.extractfile(entries['PAIR_SOURCE/'+c_path]).read()
            origin=prov['files'].get(c_path)
            if origin is None or origin['git_blob']!=sha_git_blob(b) or origin['sha256']!=sha256(b):
                raise ValueError('R14_WALT_SOURCE_INTEGRITY:'+c_path)
        mk=t.extractfile(entries['PAIR_SOURCE/techpack/sched/Makefile']).read().decode()
        conf=t.extractfile(entries['PAIR_SOURCE/techpack/sched/sched.conf']).read().decode()
    rules=validate_walt_rules(mk,conf,True)
    return {'rule_set':rules,'pinned_walt_source_files':len(ALL_OBJECTS)-2,'stock_cpu_freq':'y',
            'stock_task_sha256':STOCK_TASK_SHA,'donor_5_4_268_unmodified':True}

def report(reports, build_dir=None):
    reports=Path(reports)
    stages={}
    for kind,obj in ALL_OBJECTS.items():
        prefix='R13' if kind in PRIOR_OBJECTS else 'R14'
        rcfile=reports/f'{prefix}_{kind}_RC.txt'
        logfile=reports/f'{prefix}_{kind}_BUILD.log'
        rc=int(rcfile.read_text().strip()) if rcfile.is_file() else None
        body=logfile.read_text(errors='replace') if logfile.is_file() else ''
        errors=[l[:500] for l in body.splitlines() if re.search(r'\berror:|\bfatal error:|make(?:\[\d+\])?: \*\*\*',l)]
        exists=None if build_dir is None else (Path(build_dir)/obj).is_file() and (Path(build_dir)/obj).stat().st_size>0
        stages[kind]={'object':obj,'rc':rc,'compiled_object_file_verified':exists,
                      'compiler_error_count':len(errors),'first_errors':errors[:25],
                      'llvm_broken_pipe_count':body.count('LLVM ERROR: IO failure on output stream: Broken pipe')}
    prepare=reports/'R13_PREPARE_RC.txt'
    prepare_rc=int(prepare.read_text().strip()) if prepare.is_file() else None
    good=prepare_rc==0 and all(x['rc']==0 and x['compiler_error_count']==0 and x['compiled_object_file_verified'] is True for x in stages.values())
    output={
       'schema':SCHEMA,
       'status':'R14_NINE_OBJECTS_COMPILED_NOT_FULL_LINK' if good else 'R14_WALT_COMPONENT_BUILD_BLOCKERS',
       'r13_prepare_rc':prepare_rc,'individual_compiled_objects_ok':good,
       'original_walt_makefile_required_objects':list(ALL_OBJECTS.values()),
       'nine_objects':stages,
       'kernel_built':False,'vmlinux_linked':False,'kernel_modversions_abi_verified':False,
       'scheduler_integration_verified':False,'stock_rtmm_implemented':False,
       'stock_5_4_274_source_reproduced':False,'boot_tested':False,
       'flash_allowed':False,'production_patch_approved':False,
       'note':'Individual objects only. No link tests, no complete scheduler, and no OEM module ABI approval.'
    }
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R14_NINE_WALT_OBJECTS_SUMMARY.json').write_text(json.dumps(output,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R14_REQUIRED_NINE_OBJECT_COMPILATION_PASS':good,'R13_PREPARE_RC':prepare_rc,
                      'R14_FAILING_OBJECTS':[k for k,v in stages.items() if v['rc']!=0 or v['compiler_error_count'] or v['compiled_object_file_verified'] is not True],
                      'OEM_ABI_GREEN':False,'FLASH':False}))
    return output

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['verify','summary'])
    p.add_argument('--root');p.add_argument('--r11');p.add_argument('--reports');p.add_argument('--build-dir')
    a=p.parse_args()
    if a.mode=='verify':
        verify_main(a.root)
        print(json.dumps(audit_original_walt_sources(a.r11),sort_keys=True))
    else:report(a.reports,a.build_dir)
if __name__=='__main__':main()
