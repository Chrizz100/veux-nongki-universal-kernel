#!/usr/bin/env python3
"""Tests for R14 provenance, real source makefile, and honest compiler gates."""
import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import r14_walt_family as p
ROOT=Path(__file__).resolve().parents[1]
R11=Path(os.environ.get('R14_R11_DIR',str(Path(__file__).resolve().parents[2]/'verification/r11')))

class R14Tests(unittest.TestCase):
    def test_01_actual_r13_parent(self):self.assertEqual(p.sha256((ROOT/'reference/R13_MAIN_ORIGINAL.zip').read_bytes()),p.R13_SHA)
    def test_02_verification_actual_main(self):self.assertEqual(p.verify_main(ROOT)['schema'],p.SCHEMA)
    def test_03_nonflash_manifest(self):
        m=p.verify_main(ROOT)
        for f in ['flash_allowed','full_walt_linked','oem_abi_verified','production_patch_approved','run_full_kernel_build']:
            self.assertIs(m[f],False)
    def test_04_pinned_commits(self):
        m=p.verify_main(ROOT)
        self.assertEqual((m['pair_commit'],m['donor_commit']),(p.PAIR_COMMIT,p.DONOR_COMMIT))
    def test_05_original_stocks_verified(self):
        if R11.is_dir():self.assertEqual(p.audit_original_walt_sources(R11)['stock_task_sha256'],p.STOCK_TASK_SHA)
    def test_06_full_pinned_makefile(self):
        if R11.is_dir():self.assertEqual(p.audit_original_walt_sources(R11)['pinned_walt_source_files'],7)
    def test_07_walt_rule_exact(self):
        mk='obj-$(CONFIG_SCHED_WALT) += walt.o boost.o sched_avg.o qc_vas.o core_ctl.o trace.o\nobj-$(CONFIG_CPU_BOOST) += cpu-boost.o\n'
        cf='ifeq ($(CONFIG_CPU_FREQ), y)\nCONFIG_CPU_BOOST=y\nendif\n'
        self.assertEqual(p.validate_walt_rules(mk,cf,True)['WALT'],p.WALT_RULE)
    def test_08_missing_makefile_unit_rejected(self):
        mk='obj-$(CONFIG_SCHED_WALT) += walt.o\nobj-$(CONFIG_CPU_BOOST) += cpu-boost.o\n'
        with self.assertRaises(ValueError):p.validate_walt_rules(mk,'CONFIG_CPU_BOOST=y\n',True)
    def test_09_makefile_injection_rejected(self):
        mk='obj-$(CONFIG_SCHED_WALT) += walt.o boost.o sched_avg.o qc_vas.o core_ctl.o trace.o ; echo wrong\nobj-$(CONFIG_CPU_BOOST) += cpu-boost.o\n'
        with self.assertRaises(ValueError):p.validate_walt_rules(mk,'CONFIG_CPU_BOOST=y\n',True)
    def test_10_cpu_frequency_boost_requirement(self):
        mk='obj-$(CONFIG_SCHED_WALT) += '+' '.join(p.WALT_RULE)+'\nobj-$(CONFIG_CPU_BOOST) += cpu-boost.o\n'
        with self.assertRaises(ValueError):p.validate_walt_rules(mk,'# unrelated\n',True)
    def test_11_exact_nine_compiler_objects(self):
        self.assertEqual(len(p.ALL_OBJECTS),9)
        self.assertEqual(len(set(p.ALL_OBJECTS.values())),9)
    def test_12_no_techpack_dummy(self):self.assertTrue(all(x.endswith('.o') for x in p.ALL_OBJECTS.values()))
    def test_13_manifest_wrong_flags_rejected(self):
        with mock.patch.object(p,'SCHEMA','OTHER_BAD_SCHEMA'):
            with self.assertRaises(ValueError):p.verify_main(ROOT)
    def test_14_wrong_parent_sha_rejected(self):
        with mock.patch.object(p,'R13_SHA','0'*64):
            with self.assertRaises(ValueError):p.verify_main(ROOT)
    def test_15_report_unavailable_is_not_success(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(p.report(d,d)['individual_compiled_objects_ok'])
    def test_16_real_green_all_nine(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); rp=d/'reports';rp.mkdir();build=d/'out';build.mkdir()
            (rp/'R13_PREPARE_RC.txt').write_text('0\n')
            for name,path in p.ALL_OBJECTS.items():
                prefix='R13' if name in p.PRIOR_OBJECTS else 'R14'
                (rp/f'{prefix}_{name}_RC.txt').write_text('0\n')
                (rp/f'{prefix}_{name}_BUILD.log').write_text('  CC      '+path+'\n')
                target=build/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'elf-data')
            self.assertTrue(p.report(rp,build)['individual_compiled_objects_ok'])
    def test_17_error_status_fails_even_if_rc_zero(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); rp=d/'reports';rp.mkdir();build=d/'out';build.mkdir()
            (rp/'R13_PREPARE_RC.txt').write_text('0\n')
            for name,path in p.ALL_OBJECTS.items():
                prefix='R13' if name in p.PRIOR_OBJECTS else 'R14'
                (rp/f'{prefix}_{name}_RC.txt').write_text('0\n')
                (rp/f'{prefix}_{name}_BUILD.log').write_text('foo.c:1: error: unexpectedly failed\n' if name=='QC_VAS' else 'ok\n')
                target=build/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'x')
            self.assertFalse(p.report(rp,build)['individual_compiled_objects_ok'])
    def test_18_nonzero_rc_never_green(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);rp=d/'reports';rp.mkdir();build=d/'out';build.mkdir()
            (rp/'R13_PREPARE_RC.txt').write_text('0\n')
            for name,path in p.ALL_OBJECTS.items():
                prefix='R13' if name in p.PRIOR_OBJECTS else 'R14'
                (rp/f'{prefix}_{name}_RC.txt').write_text('2\n' if name=='CORE_CTL' else '0\n')
                (rp/f'{prefix}_{name}_BUILD.log').write_text('log\n')
                target=build/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'x')
            self.assertFalse(p.report(rp,build)['individual_compiled_objects_ok'])
    def test_19_compiled_files_required(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);rp=d/'reports';rp.mkdir();build=d/'out';build.mkdir()
            (rp/'R13_PREPARE_RC.txt').write_text('0\n')
            for name,path in p.ALL_OBJECTS.items():
                prefix='R13' if name in p.PRIOR_OBJECTS else 'R14'
                (rp/f'{prefix}_{name}_RC.txt').write_text('0\n')
                (rp/f'{prefix}_{name}_BUILD.log').write_text('ok\n')
            self.assertFalse(p.report(rp,build)['individual_compiled_objects_ok'])
    def test_20_all_results_noflash(self):
        with tempfile.TemporaryDirectory() as d:
            rep=p.report(d,d)
            for f in ['kernel_built','vmlinux_linked','kernel_modversions_abi_verified','scheduler_integration_verified','stock_rtmm_implemented','boot_tested','flash_allowed','production_patch_approved']:
                self.assertIs(rep[f],False)
    def test_21_config_disabled_cpuboost_only_if_cpu_freq(self):
        mk='obj-$(CONFIG_SCHED_WALT) += '+' '.join(p.WALT_RULE)+'\nobj-$(CONFIG_CPU_BOOST) += cpu-boost.o\n'
        self.assertFalse(p.validate_walt_rules(mk,'',False)['cpu_freq_enabled'])
    def test_22_reject_malformed_makefile(self):
        with self.assertRaises(ValueError):p.validate_walt_rules('obj-$(CONFIG_SCHED_WALT) += fake\n','',True)
    def test_23_parent_source_archive_integrity(self):
        if R11.is_dir():
            report=p.audit_original_walt_sources(R11)
            self.assertEqual(len(report['rule_set']['WALT']),6)
    def test_24_fixed_stock_task_not_modified(self):
        self.assertIn('Original', (ROOT/'README_ERST_LESEN.md').read_text())

if __name__=='__main__':unittest.main()
