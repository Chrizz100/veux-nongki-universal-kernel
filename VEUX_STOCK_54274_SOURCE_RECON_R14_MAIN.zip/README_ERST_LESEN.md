# VEUX Stock 5.4.274 – R14: vollständige WALT-Komponentenprüfung (NOFLASH)

Dieser Prüfstand baut auf dem **erfolgreichen R13-GitHub-Lauf #42091161461** auf: Stock-Taskstruktur und drei erfolgreich kompilierte Objekte bleiben identisch. R14 prüft zusätzlich die vom originalen gepinnten Qualcomm-WALT-Makefile vorgeschriebenen Objekte `boost.o`, `sched_avg.o`, `qc_vas.o`, `core_ctl.o`, `trace.o` sowie `cpu-boost.o` (die Stock-Konfiguration hat `CONFIG_CPU_FREQ=y`). Zusammen mit den R13-Objekten werden **neun** Objekte geprüft.

**Wichtige Grenzen:** Eine erfolgreiche Einzelobjektkompilierung beweist **weder** die vollständige Integration der Scheduler-Hooks **noch** die Linkbarkeit von vmlinux, Stock-RTMM, Kernel 5.4.274, QGKI/GKI-CRC-ABI oder Bootfähigkeit. Es gibt keine Image/AK3-Erzeugung, keinen Flash und keine Änderung der originalen R6-Basis oder des gepinnten Spenderquellbaums. Abweichungen und Fehler werden als Diagnoseberichte ausgegeben; echte Compilerfehler setzen den GitHub-Job rot.

## Herkunft
- Spender `dereference23/kernel_xiaomi_sm6375`, Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`, Linux 5.4.268.
- Qualcomm/Xiaomi-WALT `shandongtlb/kernel_xiaomi_sm8350_M11`, Commit `01cb3a8824b7b4caf3e3540274e71abba5ade538`, ursprünglich Linux 5.4.61.
- Originaler Stock-`include/linux/sched.h` SHA-256 `a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111`; Stock-Konfiguration `CONFIG_SCHED_WALT=y`, `CONFIG_CPU_FREQ=y`, `CONFIG_RTMM=y`.
- Das vollständige geprüfte R13-MAIN ist verschachtelt enthalten; dessen R12-/R11- und WALT-Originalquellen werden durchgehend per Hash validiert.

## GitHub
Die Dateien `VEUX_STOCK_54274_SOURCE_RECON_R14_MAIN.zip` ins Hauptverzeichnis und `.github/workflows/VEUX_STOCK_54274_SOURCE_RECON_R14_NOFLASH.yml` in den Workflow-Ordner hochladen. Nur den neuen Workflow starten. Kein Boot-/Flash-Paket ist enthalten.
