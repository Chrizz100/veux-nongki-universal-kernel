#!/usr/bin/env python3
"""VEUX R5S2 version lineage: an actual reviewed commit on official sync-susfs.

No spoofed KSU_VERSION, no direct Image edits. BakaSU version comes from the
complete official Git history plus one real VEUX source-integration commit.
All writes are limited to the disposable GitHub Actions kernel build tree.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import zipfile

SYNC='f308ed0936bdd31163cb53da3f42bc7a698f5512'
BASE='5b76b884c75f729a220bb317aa4a4fc78f0e0e9c'
UPSTREAM_COUNT=4533
TARGET_COUNT=4534
TARGET_VERSION=35234
TAG='v4.2.0-rc3'
R5S1_SELINUX_SHA='78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78'
CORE_PATHS=['feature/selinux_hide.c','feature/sucompat.c','tools/code_generation/syscall_no/syscall_no.c','Kbuild']

class VersionBlocked(RuntimeError): pass

def need(ok,why):
    if not ok: raise VersionBlocked(why)

def sha(b:bytes):return hashlib.sha256(b).hexdigest()

def git(root:Path,*args,timeout=120):
    p=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True,timeout=timeout)
    need(p.returncode==0,'GIT_'+str(args[:2])+':'+p.stderr[-250:])
    return p.stdout.strip()

def is_git_dir(p:Path):return p.is_dir() and not p.is_symlink()

def verify_donor(donor:Path,*,head=SYNC,count=UPSTREAM_COUNT,tag=TAG):
    donor=donor.resolve(strict=True)
    need(donor.is_dir() and is_git_dir(donor/'.git'),'SYNC_DONOR_NOT_FULL_GIT')
    need(git(donor,'rev-parse','--show-toplevel')==str(donor),'SYNC_DONOR_GIT_ROOT_MISMATCH')
    need(git(donor,'rev-parse','HEAD')==head,'SYNC_DONOR_UPSTREAM_SHA_CHANGED')
    need(not (donor/'.git/shallow').exists(),'SYNC_DONOR_SHALLOW')
    need(int(git(donor,'rev-list','--count','HEAD'))==count,'UPSTREAM_GIT_COUNT_NOT_VERIFIED')
    need(git(donor,'describe','--abbrev=0','--tags')==tag,'SYNC_DONOR_TAG_MISMATCH')
    need(git(donor,'status','--porcelain','--untracked-files=all')=='','SYNC_DONOR_DIRTY')
    remote=git(donor,'remote','get-url','origin')
    need(remote.rstrip('/') in ('https://github.com/Baka-SU/BakaSU.git','https://github.com/Baka-SU/BakaSU'),
         'SYNC_DONOR_NONOFFICIAL_REMOTE')
    return {'sha':head,'count':count,'tag':tag,'origin':remote}

def source_tree_hashes(folder:Path):
    need(folder.is_dir() and not folder.is_symlink(),'SOURCE_COMPONENT_NOT_DIRECTORY')
    return {p.relative_to(folder).as_posix():sha(p.read_bytes()) for p in folder.rglob('*')
            if p.is_file() and not p.is_symlink() and '.git' not in p.relative_to(folder).parts}

def version_block(text:str):
    old=('KSU_LOCAL_VERSION := 4522\nKSU_VERSION := 35222\n'
         'KSU_TAG_NAME := v4.2.0-rc3\nKSU_COMMIT_SHA := 5b76b884\nKSU_BRANCH_NAME := main\n')
    new=('KSU_LOCAL_VERSION := $(shell cd $(KSU_SRC); $(GIT_BIN) rev-list --count HEAD)\n'
         'KSU_VERSION := $(shell expr 30000 + $(KSU_LOCAL_VERSION) + 700)\n'
         'KSU_TAG_NAME := $(shell cd $(KSU_SRC); $(GIT_BIN) describe --abbrev=0 --tags 2>/dev/null || echo "v4.1.0")\n'
         'KSU_COMMIT_SHA := $(shell cd $(KSU_SRC); $(GIT_BIN) rev-parse --short=8 HEAD 2>/dev/null || echo "unknown")\n'
         'KSU_BRANCH_NAME := $(shell cd $(KSU_SRC); $(GIT_BIN) branch --show-current 2>/dev/null || echo "unknown")\n')
    need(text.count(old)==1,'PINNED_KBUILD_IDENTITY_BLOCK_NOT_UNIQUE')
    return text.replace(old,new,1)

def install_lineage(src:Path, work:Path, donor:Path,*, donor_sha=SYNC,upstream_count=UPSTREAM_COUNT, expected_original=BASE,
                   selected_tag=TAG):
    src=src.resolve(strict=True);work=work.resolve(strict=True);donor=donor.resolve(strict=True)
    need(src.name=='kernel' and work.name=='5.4.274' and work.parent.name=='builds'
         and src.is_relative_to(work) and not donor.is_relative_to(work), 'DISPOSABLE_VERSION_BUILD_ROOT_REQUIRED')
    root=work.parent.parent
    provenance=verify_donor(donor,head=donor_sha,count=upstream_count,tag=selected_tag)
    vendor=src/'KernelSU'; kroot=vendor/'kernel'
    need(vendor.is_dir() and is_git_dir(vendor/'.git') and kroot.is_dir() and not kroot.is_symlink(),
         'VEUX_ORIGINAL_BAKASU_NOT_GIT_DIRECTORY')
    old_git_head=git(vendor,'rev-parse','HEAD')
    need(len(old_git_head)==40,'VEUX_ORIGINAL_SOURCE_GIT_HEAD_INVALID')
    need((src/'drivers/kernelsu').is_symlink() and (src/'drivers/kernelsu').resolve()==kroot.resolve(),
         'EXPECTED_KERNELSU_SYMLINK_TO_BUILD_ROOT_MISSING')
    need(sha((kroot/'feature/selinux_hide.c').read_bytes())==R5S1_SELINUX_SHA,
         'R5S1_EFFECTIVE_SELINUX_SOURCE_MOVED')
    need((kroot/'tools/code_generation/syscall_no/syscall_no.c').is_file(),
         '522_COMPAT32_SOURCE_NOT_STAGED')
    old_hashes=source_tree_hashes(kroot)
    old_uapi=source_tree_hashes(vendor/'uapi')
    need(len(old_hashes)>25 and len(old_uapi)>0,'KERNELSU_TREE_INCOMPLETE')
    new_root=root/'versioned-bakasu-candidate'
    need(not new_root.exists() and not (root/'report/BAKASU_TRUE_VERSION_STAGE.json').exists(),
         'VERSIONED_REPO_ALREADY_STAGED')
    shutil.copytree(donor,new_root,symlinks=True,ignore=shutil.ignore_patterns('out'))
    for name in ('kernel','uapi'):
        destination=new_root/name
        need(destination.is_dir() and not destination.is_symlink(), 'UPSTREAM_MISSING_SUBTREE_'+name)
        shutil.rmtree(destination)
        shutil.copytree(vendor/name,destination,symlinks=True)
    kbuild=new_root/'kernel/Kbuild'
    body=kbuild.read_text()
    kbuild.write_text(version_block(body))
    updated=source_tree_hashes(new_root/'kernel')
    need(set(updated)==set(old_hashes) and all(updated[x]==v for x,v in old_hashes.items() if x!='Kbuild'),
         'SOURCE_CHANGED_OTHER_THAN_VERSIONED_KBUILD')
    need(source_tree_hashes(new_root/'uapi')==old_uapi,'UAPI_CHANGED_DURING_REBASE')
    git(new_root,'switch','--create','veux/r5s2-compat32-5.4')
    git(new_root,'add','-A','--','kernel','uapi')
    changes=git(new_root,'diff','--cached','--name-only').splitlines()
    need('kernel/Kbuild' in changes and 'kernel/feature/selinux_hide.c' in changes and
         'kernel/feature/sucompat.c' in changes and
         all(v.startswith(('kernel/','uapi/')) for v in changes),
         'UNREVIEWED_BAKASU_GIT_PATHS')
    git(new_root,'-c','user.name=VEUX Kernel CI','-c',
        'user.email=veux-kernel-ci@users.noreply.github.com',
        'commit','--quiet','-m','veux(5.4): port f308 SUSFS integration, d726 SELinux and 522 compat32')
    commit=git(new_root,'rev-parse','HEAD')
    need(git(new_root,'rev-parse','HEAD^')==donor_sha,'REAL_VERSION_PARENT_MISMATCH')
    need(int(git(new_root,'rev-list','--count','HEAD'))==upstream_count+1,'REAL_VERSION_COUNT_MISMATCH')
    need(git(new_root,'status','--porcelain','--untracked-files=all')=='','REAL_VERSION_SOURCE_NOT_CLEAN')
    need(git(new_root,'describe','--abbrev=0','--tags')==selected_tag,'GIT_TAG_CHANGED')
    computed=30700+int(git(new_root,'rev-list','--count','HEAD'))
    if upstream_count==UPSTREAM_COUNT: need(computed==TARGET_VERSION,'UNEXPECTED_VERSION_COUNT')
    # The actual kernel source remains byte-identical except restoring the official version formula.
    old_backup=root/'private-pre-version-kernelsu'
    need(not old_backup.exists() and vendor.parent.resolve().is_relative_to(work),
         'UNSAFE_VERSIONED_KSU_REPLACEMENT')
    vendor.rename(old_backup)
    try:
        new_root.rename(vendor)
    except Exception:
        old_backup.rename(vendor)
        raise
    need(git(vendor,'rev-parse','HEAD')==commit and
         (src/'drivers/kernelsu').resolve()==vendor/'kernel',
         'REBASED_KSU_SOURCE_SYMLINK_LOST')
    report={'status':'OFFICIAL_SYNC_SUSFS_REAL_GIT_COMMIT_IN_DISPOSABLE_BUILD',
            'original_pinned_version':35222,'prior_git_head_recorded':old_git_head,
            'original_source_pin_in_R5S2_manifest':expected_original,'real_upstream_sync_commit':donor_sha,
            'upstream_git_count':upstream_count,'upstream_version':30700+upstream_count,
            'veux_commit':commit,'veux_commit_short':git(vendor,'rev-parse','--short=8','HEAD'),
            'real_git_commit_parent':git(vendor,'rev-parse','HEAD^'),
            'commit_count':upstream_count+1,'version':computed,'tag':selected_tag,
            'built_from_real_git_ancestry':True,'modified_tracked_paths':changes,
            'compiled_kernel_sources_same_except_kbuild_identity':True,
            'old_kernel_source_hashes':old_hashes, 'old_kbuild_sha256':old_hashes['Kbuild'],
            'new_kbuild_sha256':updated['Kbuild'],
            'r5s1_selinux_sha256':R5S1_SELINUX_SHA,
            'SUSFS_core_unchanged':True,'NoMount_unchanged':True,
            'manager_apk_not_rebuilt':True,'not_a_flash_permission':True}
    dst=root/'report/BAKASU_TRUE_VERSION_STAGE.json';dst.parent.mkdir(exist_ok=True)
    dst.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(f'VEUX_REAL_BAKASU_VERSION_STAGED=PASS; VERSION={computed}; COMMIT={commit}; UPSTREAM={donor_sha}',flush=True)
    return report

def verify_version_compilation(src:Path,work:Path,version:dict,result:dict):
    src=src.resolve(strict=True);work=work.resolve(strict=True)
    img=work/'build/arch/arm64/boot/Image'
    need(img.is_file() and img.stat().st_size>1000000,'NEW_GIT_VERSION_IMAGE_NOT_COMPILED')
    expected=(version['tag']+'-'+version['veux_commit_short']+'@BakaSU').encode()
    data=img.read_bytes()
    need(data.count(expected)==1,'BUILT_IMAGE_HAS_WRONG_GIT_VERSION_MARKER')
    need(b'v4.2.0-rc3-5b76b884@BakaSU' not in data,'OLD_35222_KERNEL_IDENTITY_REMAINS')
    cmd=work/'build/drivers/kernelsu/core/.init.o.cmd'
    need(cmd.is_file() and '-DKSU_VERSION='+str(version['version']) in cmd.read_text(errors='replace'),
         'COMPILER_DID_NOT_USE_REAL_VERSION_CODE')
    need('KSU_VERSION := $(shell expr 30000 + $(KSU_LOCAL_VERSION) + 700)' in
         (src/'KernelSU/kernel/Kbuild').read_text(),'OFFICIAL_DYNAMIC_VERSION_FORMULA_MISSING')
    need(git(src/'KernelSU','rev-parse','HEAD')==version['veux_commit'], 'BUILT_SOURCE_COMMIT_MOVED')
    need(result.get('compile') is True and result.get('image_sha256')==sha(data),'COMPILED_IMAGE_RESULT_MISMATCH')
    proof={'status':'REAL_GIT_35234_COMPILED','version':version['version'],
            'commit':version['veux_commit'],'upstream':version['real_upstream_sync_commit'],
            'compiled_marker':expected.decode(),'image_sha256':sha(data),
            'compiler_cmd_sha256':sha(cmd.read_bytes()),'device_test':False}
    path=work.parent.parent/'report/BAKASU_TRUE_VERSION_COMPILED.json'
    need(not path.exists(),'VERSION_COMPILE_REPORT_COLLISION')
    path.write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
    print('VEUX_REAL_BAKASU_VERSION_COMPILED=PASS; NO_FLASH',flush=True)
    return proof

def rebind_reviewed_Kbuild_hash(compat522:dict, version:dict):
    """R5S2 verifies all 20 sources; record the one legitimate version formula delta.

    All 19 other hashes remain exactly as emitted by the official 522 Git port.
    This never disables or weakens the compiled-source hash checks.
    """
    need(compat522.get('status')=='PINNED_522_5_4_PORT_STAGED_IN_MEMORY',
         '522_OFFICIAL_PRE_VERSION_PROOF_MISSING')
    files=compat522.get('changed_files') or []
    need(len(files)==20,'522_PINNED_PATH_COUNT_DRIFT')
    hits=[x for x in files if x.get('path')=='kernel/Kbuild']
    need(len(hits)==1,'522_PINNED_KBUILD_PATH_MISSING_OR_DUPLICATE')
    item=hits[0]
    before=item.get('after_sha256')
    need(before==version.get('old_kbuild_sha256'),'REVIEWED_KBUILD_PRE_VERSION_HASH_MISMATCH')
    after=version.get('new_kbuild_sha256')
    need(isinstance(after,str) and len(after)==64 and after!=before,
         'REVIEWED_KBUILD_VERSION_DELTA_UNVERIFIED')
    item['post_522_upstream_sha256']=before
    item['after_sha256']=after
    item['version_formula_only_sha256_transition']=True
    need(len([x for x in files if x.get('version_formula_only_sha256_transition')])==1,
         'BROAD_522_HASH_OVERRIDE_FORBIDDEN')
    print('R5S2_ALL_20_COMPILED_SHA_GATES_RETAINED_VERSION_KBUILD_REVIEWED=PASS',flush=True)
    return compat522

# Injection may modify only the generated R6->R5S1->R5S2 worker in runner.temp.
COMPILE_ANCHOR='        image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n'
def inject_version_worker(original,parent,worker:Path,reference:Path,bakasu522:Path,sync_donor:Path):
    meta=original(parent,worker,reference,bakasu522)
    body=worker.read_text()
    need('real_version = install_lineage(' not in body,'WORKER_ALREADY_VERSIONED')
    needle=r'(?m)^        compat_522_staged = stage_522\(src, bundle, work, Path\([^\n]+\)\)\n'
    matches=list(re.finditer(needle,body))
    need(len(matches)==1 and body.count(COMPILE_ANCHOR)==1,'VERSION_WORKER_ANCHORS_CHANGED')
    line=matches[0].group(0)
    add=("        from veux_r5s2_true_version import install_lineage\n"
         +f"        real_version = install_lineage(src, work, Path({str(sync_donor.resolve(strict=True))!r}))\n"
         +"        from veux_r5s2_true_version import rebind_reviewed_Kbuild_hash\n"
         +"        compat_522_staged = rebind_reviewed_Kbuild_hash(compat_522_staged,real_version)\n")
    body=body.replace(line,line+add,1)
    code=('        original_pinned_bakasu_target = dict(targets["components"]["resukisu"])\n'
          '        targets["components"]["resukisu"].update({"commit":real_version["veux_commit"],\n'
          '          "local_version":real_version["commit_count"],"version":str(real_version["version"]),\n'
          '          "ref":"refs/heads/veux/r5s2-compat32-5.4"})\n'
          '        try:\n'
          '            image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n'
          '        finally:\n'
          '            targets["components"]["resukisu"].clear()\n'
          '            targets["components"]["resukisu"].update(original_pinned_bakasu_target)\n'
          '        from veux_r5s2_true_version import verify_version_compilation\n'
          '        result["bakasu_true_version"] = verify_version_compilation(src,work,real_version,result)\n')
    body=body.replace(COMPILE_ANCHOR,code,1)
    ast.parse(body)
    need(body.count('real_version = install_lineage(')==1 and
         body.count('result["bakasu_true_version"] = verify_version_compilation(')==1,
         'VERSION_WORKER_DUPLICATE_PATCH')
    worker.write_text(body)
    meta['real_version_worker_staged']=True
    return meta

def build(repo:Path, work:Path, reference:Path, bakasu522:Path, sync_donor:Path, jobs:int):
    import veux_bakasu_522_r5s2 as r5s2
    verify_donor(sync_donor)
    old=r5s2.inject_worker_inner
    proof=[]
    def inject(parent,worker,ref,donor):
        row=inject_version_worker(old,parent,worker,ref,donor,sync_donor)
        proof.append(row)
        return row
    r5s2.inject_worker_inner=inject
    try:
        r5s2.build(repo,work,reference,bakasu522,jobs)
    finally:
        r5s2.inject_worker_inner=old
    need(len(proof)==1 and proof[0].get('real_version_worker_staged'),
         'R5S2_REAL_VERSION_WORKER_NOT_RUN')
    old_result=json.loads((work/'public/5.4.274/RESULT.json').read_text())
    comp=old_result.get('bakasu_true_version') or {}
    need(comp.get('status')=='REAL_GIT_35234_COMPILED' and comp.get('version')==TARGET_VERSION,
         'REAL_VERSION_BUILD_INTEGRITY_NOT_CONFIRMED')
    return old_result

def package_versioned(work:Path):
    """Publish a version-labeled AK3 after all prior and new gates; preserve payload bytes."""
    work=work.resolve(strict=True)
    root=work/'public/5.4.274'
    old=next((p for p in root.glob('*_35222_*AnyKernel_RMNET.zip')),None)
    boot=next((p for p in root.glob('*_35222_*boot.img')),None)
    need(old is not None and boot is not None,'ORIGINAL_R5S2_AK3_AND_BOOT_NOT_FOUND')
    result=json.loads((root/'RESULT.json').read_text())
    identity=result.get('bakasu_true_version') or {}
    need(identity.get('status')=='REAL_GIT_35234_COMPILED' and identity.get('version')==TARGET_VERSION,
         'BUILD_SOURCE_NOT_ACTUALLY_VERSIONED')
    dest=work/'versioned-public/5.4.274'
    need(not dest.exists(),'VERSION_ARTIFACT_DESTINATION_EXISTS')
    dest.mkdir(parents=True)
    versioned_name=old.name.replace('_35222_','_35234_')
    versioned=dest/versioned_name
    with zipfile.ZipFile(old) as zi,zipfile.ZipFile(versioned,'w') as zo:
        need(zi.testzip() is None and len(zi.namelist())==20,'BASE_AK3_INVALID')
        for meta in zi.infolist():
            payload=zi.read(meta.filename)
            if meta.filename=='anykernel.sh':
                need(payload.count(b'ReSukiSU_35222_')==1,'KERNELSTRING_OLD_IDENTITY_NOT_UNIQUE')
                payload=payload.replace(b'ReSukiSU_35222_',b'ReSukiSU_35234_',1)
            zo.writestr(meta,payload)
    with zipfile.ZipFile(old) as zi,zipfile.ZipFile(versioned) as zo:
        need(zo.testzip() is None and zi.namelist()==zo.namelist(),'REPACKED_AK3_INVALID')
        for name in zi.namelist():
            if name=='anykernel.sh':
                need(b'ReSukiSU_35234_' in zo.read(name),'AK3_LABEL_FAILED')
            else:need(zi.read(name)==zo.read(name),'AK3_PAYLOAD_CHANGED_'+name)
        image=zo.read('Image')
        need(sha(image)==result['image_sha256'],'REPACKED_IMAGE_SHA_MISMATCH')
    newboot=dest/boot.name.replace('_35222_','_35234_')
    shutil.copy2(boot,newboot)
    doc=root/'RMNET-INSTALLATION.txt'
    shutil.copy2(doc,dest/doc.name)
    result['artifact_name']=result['artifact_name'].replace('_35222_','_35234_')
    result['version_integrity']='OFFICIAL_SYNC_SUSFS_REAL_GIT_PLUS_VEUX_COMMIT'
    out_result=dest/'RESULT.json'
    out_result.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    sums=''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in (versioned,newboot,out_result,dest/doc.name))
    (dest/'SHA256SUMS.txt').write_text(sums)
    need(len(list(dest.iterdir()))==5,'UNEXPECTED_VERSIONED_ARTIFACT_COUNT')
    print('VEUX_R5S2_GENUINE_BAKASU_35234_AK3=PASS; FLASH_TEST_PENDING',flush=True)
    return {'versioned_ak3':str(versioned),'sha256':sha(versioned.read_bytes()),
            'versioned_boot':str(newboot),'version':TARGET_VERSION,
            'compiled_image_sha256':result['image_sha256']}

def main():
    p=argparse.ArgumentParser()
    p.add_argument('command',choices=['donor','build','package'])
    p.add_argument('--repo',type=Path)
    p.add_argument('--work',type=Path)
    p.add_argument('--reference',type=Path)
    p.add_argument('--donor522',type=Path)
    p.add_argument('--sync',type=Path)
    p.add_argument('--jobs',type=int,default=4)
    a=p.parse_args()
    try:
        if a.command=='donor':
            need(a.sync is not None,'MISSING_SYNC_DONOR')
            print(json.dumps(verify_donor(a.sync),sort_keys=True))
        elif a.command=='build':
            need(all(v is not None for v in (a.repo,a.work,a.reference,a.donor522,a.sync)),
                 'MISSING_BUILD_ARGUMENT')
            build(a.repo,a.work,a.reference,a.donor522,a.sync,a.jobs)
        else:
            need(a.work is not None,'MISSING_WORK_ARGUMENT')
            print(json.dumps(package_versioned(a.work),sort_keys=True))
    except (VersionBlocked,KeyError,OSError,subprocess.SubprocessError) as e:
        print('VEUX_GENUINE_BAKASU_VERSION_BLOCKED:'+str(e),flush=True)
        raise SystemExit(1)
if __name__=='__main__':main()
