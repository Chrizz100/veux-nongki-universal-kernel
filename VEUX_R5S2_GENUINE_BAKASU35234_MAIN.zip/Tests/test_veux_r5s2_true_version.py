#!/usr/bin/env python3
"""Offline host tests for the genuine BakaSU driver version migration."""
import tempfile
from pathlib import Path
import shutil
import subprocess
import unittest
import zipfile
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import veux_r5s2_true_version as v


def run(*cmd,cwd=None):
    p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
    if p.returncode:
        raise AssertionError((cmd,p.stderr))
    return p.stdout.strip()

def commit(repo,msg):
    run('git','add','-A',cwd=repo)
    run('git','-c','user.name=Test','-c','user.email=test@example.com',
        'commit','--quiet','-m',msg,cwd=repo)
    return run('git','rev-parse','HEAD',cwd=repo)

def make_repo(root,kind):
    root.mkdir()
    run('git','init','--quiet','-b','main',str(root))
    run('git','remote','add','origin','https://github.com/Baka-SU/BakaSU.git',cwd=root)
    (root/'kernel/feature').mkdir(parents=True)
    (root/'kernel/tools/code_generation/syscall_no').mkdir(parents=True)
    (root/'uapi').mkdir()
    (root/'uapi/base').write_text('uapi_'+kind+'\n')
    (root/'kernel/Kbuild').write_text('base\n')
    (root/'kernel/feature/selinux_hide.c').write_text('else source\n')
    (root/'kernel/feature/sucompat.c').write_text('sucompat baseline\n')
    (root/'kernel/tools/code_generation/syscall_no/syscall_no.c').write_text('host tool baseline\n')
    for i in range(31):
        (root/'kernel'/f'file{i:02d}.c').write_text(f'file {i}\n')
    old=commit(root,'begin')
    (root/'kernel/feature/sucompat.c').write_text('upstream sucompat\n')
    middle=commit(root,'next')
    (root/'kernel/feature/selinux_hide.c').write_text('upstream SELinux\n')
    final=commit(root,'official sync-susfs')
    run('git','tag','v4.2.0-rc3',cwd=root)
    return old,middle,final


class Host(unittest.TestCase):
    def test_version_rewrite_is_original_formula(self):
        old=('KSU_LOCAL_VERSION := 4522\nKSU_VERSION := 35222\n'
             'KSU_TAG_NAME := v4.2.0-rc3\nKSU_COMMIT_SHA := 5b76b884\nKSU_BRANCH_NAME := main\n')
        new=v.version_block('before\n'+old+'after\n')
        self.assertIn('KSU_VERSION := $(shell expr 30000 + $(KSU_LOCAL_VERSION) + 700)',new)
        self.assertNotIn('KSU_VERSION := 35234',new)
        self.assertEqual(new.count('KSU_LOCAL_VERSION := '),1)
        with self.assertRaises(v.VersionBlocked):v.version_block('bad source')

    def test_true_git_lineage_only_version_block_touched(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)
            donor=path/'donor';_,_,head=make_repo(donor,'upstream')
            work=path/'out/builds/5.4.274';src=work/'source/kernel'
            src.mkdir(parents=True)
            vendor=src/'KernelSU';_,_,old=make_repo(vendor,'legacy')
            (vendor/'kernel/Kbuild').write_text(
                'KSU_LOCAL_VERSION := 4522\nKSU_VERSION := 35222\n'
                'KSU_TAG_NAME := v4.2.0-rc3\nKSU_COMMIT_SHA := 5b76b884\nKSU_BRANCH_NAME := main\n')
            # Test the *actual* compiled-R5S1 SELinux reference exactly.
            current=Path(__file__).resolve().parents[1]/'evidence/actual_r5s1_selinux.c'
            if not current.exists():
                self.skipTest('Nested source not prepared')
            (vendor/'kernel/feature/selinux_hide.c').write_bytes(current.read_bytes())
            (vendor/'kernel/feature/sucompat.c').write_text('522 compat32 port actual source\n')
            (vendor/'kernel/tools/code_generation/syscall_no/syscall_no.c').write_text('522 host tool\n')
            (src/'drivers').mkdir()
            (src/'drivers/kernelsu').symlink_to('../KernelSU/kernel')
            (path/'out/report').mkdir(parents=True)
            h=v.source_tree_hashes(vendor/'kernel')
            result=v.install_lineage(src,work,donor,donor_sha=head,upstream_count=3,
                                      expected_original=old)
            self.assertEqual(result['version'],30704)
            self.assertEqual(result['real_git_commit_parent'],head)
            self.assertEqual(result['commit_count'],4)
            self.assertNotEqual(result['veux_commit'],head)
            self.assertEqual(v.source_tree_hashes(src/'KernelSU/kernel')['feature/selinux_hide.c'],h['feature/selinux_hide.c'])
            self.assertEqual(v.source_tree_hashes(src/'KernelSU/kernel')['feature/sucompat.c'],h['feature/sucompat.c'])
            self.assertTrue((src/'drivers/kernelsu').resolve()==src/'KernelSU/kernel')
            self.assertIn('KSU_LOCAL_VERSION := $(shell', (src/'KernelSU/kernel/Kbuild').read_text())
            self.assertNotIn('KSU_LOCAL_VERSION := 4522', (src/'KernelSU/kernel/Kbuild').read_text())
            self.assertEqual(run('git','status','--porcelain','--untracked-files=all',cwd=src/'KernelSU'),'')

    def test_upstream_wrong_revision_is_blocked(self):
        with tempfile.TemporaryDirectory() as td:
            donor=Path(td)/'donor';a,b,c=make_repo(donor,'upstream')
            with self.assertRaises(v.VersionBlocked):
                v.verify_donor(donor,head=b,count=3)
            with self.assertRaises(v.VersionBlocked):
                v.verify_donor(donor,head=c,count=4533)

    def test_duplicate_worker_fails_and_normal_worker_parses(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'worker.py'
            p.write_text('def f():\n'
                         '        compat_522_staged = stage_522(src, bundle, work, Path("/abc"))\n'
                         +v.COMPILE_ANCHOR)
            donor=Path(td)/'donor';donor.mkdir()
            def orig(parent,worker,reference,bakasu): return {'status':'mock'}
            res=v.inject_version_worker(orig,object(),p,Path('/ref'),Path('/b'),donor)
            self.assertTrue(res['real_version_worker_staged'])
            self.assertIn('install_lineage(',p.read_text())
            with self.assertRaises(v.VersionBlocked):
                v.inject_version_worker(orig,object(),p,Path('/ref'),Path('/b'),donor)

    def test_repacked_AK3_bytes_unchanged_except_label(self):
        with tempfile.TemporaryDirectory() as td:
            work=Path(td)/'work';public=work/'public/5.4.274';public.mkdir(parents=True)
            old=public/'Kernel_5.4.274_ReSukiSU_35222_SUSFS_2.3.0_NoMount_21_AnyKernel_RMNET.zip'
            with zipfile.ZipFile(old,'w') as z:
                z.writestr('anykernel.sh','kernel.string=Kernel_5.4.274_ReSukiSU_35222_SUSFS_2.3.0_NoMount_21')
                z.writestr('Image',b'only for host tests')
                for i in range(18):z.writestr(f'path{i:02d}',f'data {i}')
            boot=public/'Kernel_5.4.274_ReSukiSU_35222_SUSFS_2.3.0_NoMount_21_boot.img'
            boot.write_bytes(b'original boot')
            (public/'RMNET-INSTALLATION.txt').write_text('RMNET preserved')
            (public/'RESULT.json').write_text(json.dumps({'image_sha256':v.sha(b'only for host tests'),
               'artifact_name':'Kernel_5.4.274_ReSukiSU_35222_SUSFS_2.3.0_NoMount_21_RMNET',
               'bakasu_true_version':{'status':'REAL_GIT_35234_COMPILED','version':35234}}))
            out=v.package_versioned(work)
            self.assertTrue(Path(out['versioned_ak3']).exists())
            with zipfile.ZipFile(out['versioned_ak3']) as z:
                self.assertIn(b'35234',z.read('anykernel.sh'))
                self.assertEqual(z.read('Image'),b'only for host tests')
            self.assertEqual(len(list((work/'versioned-public/5.4.274').iterdir())),5)


    def test_version_Kbuild_hash_gate_only_one_file(self):
        import copy
        from hashlib import sha256
        old=sha256(b'old Kbuild').hexdigest()
        new=sha256(b'new Kbuild').hexdigest()
        items=[{'path':'kernel/Kbuild','after_sha256':old}]+[
            {'path':f'kernel/other_{i}','after_sha256':'a'*64} for i in range(19)]
        original=copy.deepcopy(items)
        row={'status':'PINNED_522_5_4_PORT_STAGED_IN_MEMORY','changed_files':items}
        version={'old_kbuild_sha256':old,'new_kbuild_sha256':new}
        changed=v.rebind_reviewed_Kbuild_hash(row,version)
        self.assertEqual(changed['changed_files'][0]['after_sha256'],new)
        self.assertEqual(changed['changed_files'][0]['post_522_upstream_sha256'],old)
        self.assertEqual(changed['changed_files'][1:],original[1:])
        with self.assertRaises(v.VersionBlocked):
            v.rebind_reviewed_Kbuild_hash(copy.deepcopy(row),version)
        with self.assertRaises(v.VersionBlocked):
            v.rebind_reviewed_Kbuild_hash({'status':row['status'],'changed_files':copy.deepcopy(original)},
                                           {'old_kbuild_sha256':'0'*64,'new_kbuild_sha256':new})

if __name__=='__main__':unittest.main()
