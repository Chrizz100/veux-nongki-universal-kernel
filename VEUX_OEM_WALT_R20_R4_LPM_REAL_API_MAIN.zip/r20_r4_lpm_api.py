#!/usr/bin/env python3
"""Port genuine 2-argument Qualcomm WALT LPM API into disposable VEUX cpuidle.

No stubbed WALT behaviour. Prerequisites: R19 15 objects proven, genuine
kernel/sched/walt/sched_avg.o compiled, actual OEM WALT (cpu,u64*) API present.
If the actual source API differs, STOP rather than adapting heuristically.
"""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import re
import sys

DRIVER = 'drivers/cpuidle/lpm-levels.c'
WALT_H = 'include/linux/sched/walt.h'
WALT_IMPL = 'kernel/sched/walt/sched_avg.c'
WALT_MAKE = 'kernel/sched/walt/Makefile'
STAT_H = 'include/linux/sched/stat.h'
DRIVER_PIN_BLOB = 'ef589378adf49fc78cf4adc2ac90ba7b9091d059' # pinned Positron b2b7a3... source
INCLUDE_OLD = '#include <linux/sched/stat.h>\n'
INCLUDE_NEW = INCLUDE_OLD + '#include <linux/sched/walt.h>\n'
OLD_STUB = ('static inline uint64_t sched_lpm_disallowed_time(int cpu)\n'
            '{\n\treturn 0;\n}\n')
OLD_CALL = ('\tbias_time = sched_lpm_disallowed_time(cpu);\n'
            '\tif (bias_time) {\n')
NEW_CALL = ('\tif (!sched_lpm_disallowed_time(cpu, &bias_time)) {\n')
ABI = re.compile(r'\bsched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*,\s*u64\s*\*\s*timeout\s*\)')
PROVIDER = re.compile(r'(?m)^\s*int\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*,\s*u64\s*\*\s*timeout\s*\)\s*\{')
HEADER = re.compile(r'(?m)^\s*extern\s+int\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*,\s*u64\s*\*\s*timeout\s*\)\s*;')

class ContractError(Exception):
    pass

def require(value,code):
    if not value:
        raise ContractError(code)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def gitblob(b):
    return hashlib.sha1(('blob '+str(len(b))+'\0').encode()+b).hexdigest()

def check_backend(header,implementation,makefile,stat,config,compiler_result):
    h=header.decode('utf-8');c=implementation.decode('utf-8');m=makefile.decode('utf-8')
    st=stat.decode('utf-8');cfg=config.decode('utf-8')
    require(cfg.count('CONFIG_SCHED_WALT=y\n')==1,'WALT_NOT_Y')
    require(len(HEADER.findall(h))==1,'OEM_WALT_HEADER_NOT_INT_CPU_TIMEOUT')
    require(len(PROVIDER.findall(c))==1,'OEM_WALT_REAL_PROVIDER_NOT_INT_CPU_TIMEOUT')
    require(len(ABI.findall(c))==1,'OEM_WALT_PROVIDER_AMBIGUOUS')
    require(re.search(r'EXPORT_SYMBOL(?:_GPL)?\s*\(\s*sched_lpm_disallowed_time\s*\)',c) is not None,
            'OEM_PROVIDER_NOT_EXPORTED')
    require(re.search(r'\bbusy_hyst_end_time\b',c) and re.search(r'\*timeout\s*=',c),
            'OEM_PROVIDER_NOT_BUSY_HYST_SEMANTICS')
    require(re.search(r'\bsched_avg\.o\b',m) is not None,'SCHED_AVG_NOT_IN_MAKEFILE')
    require(re.search(r'\bsched_lpm_disallowed_time\b',st) is None,
            'LEGACY_STAT_H_CONFLICT_NEEDS_UPSTREAM_REVIEW')
    # The same include is used for CONFIG_SCHED_WALT=n, so the upstream
    # stub must return INT_MAX (no LPM restriction), not a fabricated bias.
    require('CONFIG_SCHED_WALT' in h and 'INT_MAX' in h and
            re.search(r'(?m)^\s*static\s+inline\s+int\s+sched_lpm_disallowed_time',h),
            'WALT_HEADER_MISSING_REAL_NO_WALT_FALLBACK')
    data=json.loads(compiler_result.decode('utf-8'))
    r=data.get('objects',{}).get('kernel/sched/walt/sched_avg.o',{})
    require(data.get('object_success_count')==15 and r.get('compiled') is True,
            'REAL_WALT_SCHED_AVG_OBJECT_NOT_PROVEN')
    require(re.fullmatch('[0-9a-f]{64}',r.get('object_sha256','')) is not None,
            'REAL_WALT_SCHED_AVG_SHA_MISSING')
    return r['object_sha256']

def patch_driver(src):
    s=src.decode('utf-8')
    require(gitblob(src)==DRIVER_PIN_BLOB,'DRIVER_PINNED_PREIMAGE_SHA_DRIFT')
    require(s.count(OLD_STUB)==1,'LEGACY_WALT_OFF_STUB_DRIFT')
    require(s.count(INCLUDE_OLD)==1 and s.count('sched_lpm_disallowed_time(')==2,
            'DRIVER_CALL_COUNT_OR_HEADER_DRIFT')
    require(s.count(OLD_CALL)==1,'LEGACY_ONE_ARG_CALL_DRIFT')
    require('include <linux/sched/walt.h>' not in s,'WALT_HEADER_ALREADY_PRESENT')
    require('static bool check_cpu_isolated(int cpu)' in s,'CPU_ISOLATION_PATH_DRIFT')
    s=s.replace(INCLUDE_OLD,INCLUDE_NEW,1)
    s=s.replace(OLD_STUB,'',1)  # replaced by the real WALT header's upstream !WALT stub
    s=s.replace(OLD_CALL,NEW_CALL,1)
    require(s.count('sched_lpm_disallowed_time(')==1 and s.count(NEW_CALL)==1,
            'NEW_CALL_SCOPE_INVALID')
    require('pm_cpu->bias = bias_time;' in s,'LPM_BIAS_ASSIGNMENT_LOST')
    return s.encode('utf-8')

def run(snapshot,canonical,project,config,result,output):
    snapshot,canonical,project,config,result,output = map(Path,
        (snapshot,canonical,project,config,result,output))
    for label,p in (('SNAPSHOT',snapshot),('CANONICAL',canonical),('PROJECT',project)):
        require(p.is_dir() and not p.is_symlink(),'UNSAFE_'+label)
    s,c,p,o=snapshot.resolve(),canonical.resolve(),project.resolve(),output.resolve()
    require(s!=c and not s.is_relative_to(c) and not c.is_relative_to(s),
            'CANONICAL_CANNOT_BE_MUTABLE_SNAPSHOT')
    require(not s.is_relative_to(p) and not o.is_relative_to(p),'PROJECT_MUTATION_FORBIDDEN')
    require(not o.is_relative_to(s) and not o.is_relative_to(c) and
            not output.exists() and not output.is_symlink(),'REPORT_OUTPUT_UNSAFE')
    tracked={}
    for name in (DRIVER,WALT_H,WALT_IMPL,WALT_MAKE,STAT_H):
        f=snapshot/name
        require(f.is_file() and not f.is_symlink() and f.resolve().is_relative_to(s),
                'UNSAFE_STAGE_INPUT:'+name)
        tracked[name]=f.read_bytes()
        require(b'\r\n' not in tracked[name],'CRLF_INPUT:'+name)
    original=canonical/DRIVER
    require(original.is_file() and not original.is_symlink() and
            original.resolve().is_relative_to(c),'UNSAFE_CANONICAL_DRIVER')
    require(original.read_bytes()==tracked[DRIVER],'CANONICAL_DRIVER_DRIFT')
    require(config.is_file() and result.is_file() and not config.is_symlink() and
            not result.is_symlink(),'MISSING_CONFIG_OR_R18_PROOF')
    proof_sha=check_backend(tracked[WALT_H],tracked[WALT_IMPL],tracked[WALT_MAKE],
                            tracked[STAT_H],config.read_bytes(),result.read_bytes())
    after=patch_driver(tracked[DRIVER])
    before=tracked[DRIVER]
    oldlines=before.decode().splitlines(keepends=True)
    newlines=after.decode().splitlines(keepends=True)
    patch=''.join(difflib.unified_diff(oldlines,newlines,fromfile='a/'+DRIVER,
                                       tofile='b/'+DRIVER))
    require(patch.count('@@')==6,'PATCH_HUNK_SCOPE_DRIFT')  # 3 @@ pairs
    changes=[x for x in patch.splitlines() if x.startswith('+') and not x.startswith('+++')]
    deletions=[x for x in patch.splitlines() if x.startswith('-') and not x.startswith('---')]
    require(len(changes)==2 and len(deletions)==6,'NON_MINIMAL_LPM_API_BACKPORT')
    changed=False
    try:
        require((snapshot/DRIVER).read_bytes()==before,'PREWRITE_RACE')
        (snapshot/DRIVER).write_bytes(after);changed=True
        require((snapshot/DRIVER).read_bytes()==after,'POSTWRITE_DRIFT')
        require(original.read_bytes()==before,'ORIGINAL_CHANGED')
        for k,v in tracked.items():
            if k!=DRIVER:
                require((snapshot/k).read_bytes()==v,'WALT_PROVIDER_OR_HEADER_CHANGED:'+k)
        output.mkdir(parents=True,exist_ok=False)
        report={
            'stage':'R20_R4_REAL_WALT_LPM_TWO_ARGUMENT_API_BRIDGE',
            'source_reference_commit':'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632',
            'kernel':'5.4.274','changed_files':[DRIVER],
            'provider_object':'kernel/sched/walt/sched_avg.o',
            'provider_object_sha256':proof_sha,
            'provider_abi':'int sched_lpm_disallowed_time(int cpu, u64 *timeout)',
            'old_call':'u64 sched_lpm_disallowed_time(int cpu)',
            'modified_sha256_before':sha(before),'modified_sha256_after':sha(after),
            'reference_sha256':sha(original.read_bytes()),
            'canonical_unmodified':True,'brene_changed':False,
            'bakasusu_nomount_changed':False,'flash_allowed':False,
            'vmlinux_linked':False,'vendor_abi_proven':False,
            'note':'Adapt OEM cpuidle client to already compiled actual two-argument WALT provider, without stubbed WALT runtime or modifying any WALT sources.'}
        (output/'R20_R4_SOURCE_RESULT.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
        (output/'R20_R4_SOURCE_DIFF.patch').write_text(patch)
        print('R20_R4_OEM_LPM_ABI_SOURCE=PASS; REAL_PROVIDER=YES; FILES=1; WALT_RUNTIME_STUB=NO; FLASH=NO')
        return report
    except Exception:
        if changed and (snapshot/DRIVER).read_bytes()==after:
            (snapshot/DRIVER).write_bytes(before)
        raise

def main():
    p=argparse.ArgumentParser()
    for opt in ('snapshot','canonical','project','config','result','output'):
        p.add_argument('--'+opt,required=True)
    a=p.parse_args()
    try:
        run(a.snapshot,a.canonical,a.project,a.config,a.result,a.output)
        return 0
    except (ContractError,ValueError,OSError,UnicodeError,json.JSONDecodeError) as e:
        print('R20_R4_FAIL_CLOSED:'+str(e),file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())
