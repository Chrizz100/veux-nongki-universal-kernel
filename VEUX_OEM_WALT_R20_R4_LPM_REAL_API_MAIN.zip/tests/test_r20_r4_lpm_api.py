import importlib.util
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

P=pathlib.Path(__file__).resolve().parents[1]/'r20_r4_lpm_api.py'
spec=importlib.util.spec_from_file_location('r20_r4_lpm_api',P)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)

DRIVER=(
'#include <linux/kernel.h>\n'
'#include <linux/sched/stat.h>\n'
+''.join('// before control section %02d\n'%i for i in range(14))+
'#ifdef CONFIG_SCHED_WALT\n'
'static bool check_cpu_isolated(int cpu)\n{\n\treturn cpu_isolated(cpu);\n}\n'
'#else\n'
'static bool check_cpu_isolated(int cpu)\n{\n\treturn false;\n}\n\n'
+ m.OLD_STUB+
'#endif\n'
+''.join('// between controls and call %02d\n'%i for i in range(30))+
'static inline bool lpm_disallowed(int cpu, struct lpm_cpu *pm_cpu)\n'
'{\n\tuint64_t bias_time = 0;\n'
+ m.OLD_CALL+
'\t\tpm_cpu->bias = bias_time;\n\t\treturn true;\n\t}\n\treturn false;\n}\n'
)
HEADER=('''#ifndef _LINUX_SCHED_WALT_H
#define _LINUX_SCHED_WALT_H
#include <linux/types.h>
#if IS_ENABLED(CONFIG_SCHED_WALT)
extern int sched_lpm_disallowed_time(int cpu, u64 *timeout);
#else
static inline int sched_lpm_disallowed_time(int cpu, u64 *timeout)
{
	return INT_MAX;
}
#endif
#endif
''')
PROVIDER=('''static DEFINE_PER_CPU(atomic64_t, busy_hyst_end_time) = ATOMIC64_INIT(0);
int sched_lpm_disallowed_time(int cpu, u64 *timeout)
{
	u64 now = sched_clock();
	u64 bias_end_time = atomic64_read(&per_cpu(busy_hyst_end_time, cpu));
	if (now < bias_end_time) {
		*timeout = bias_end_time - now;
		return 0;
	}
	return INT_MAX;
}
EXPORT_SYMBOL(sched_lpm_disallowed_time);
''')
R18={'object_success_count':15,'objects':{'kernel/sched/walt/sched_avg.o':{'compiled':True,'object_sha256':'a'*64}}}

def b(t):return t.encode()

class Tests(unittest.TestCase):
    def setUp(self):
        self.pin=mock.patch.object(m,'DRIVER_PIN_BLOB',m.gitblob(b(DRIVER)))
        self.pin.start();self.addCleanup(self.pin.stop)
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.base=pathlib.Path(self.tmp.name);self.s=self.base/'snapshot';self.c=self.base/'canonical';self.p=self.base/'project';self.o=self.base/'report'
        for v in (self.s,self.c,self.p):v.mkdir()
        self.config=self.base/'config';self.config.write_text('CONFIG_SCHED_WALT=y\n')
        self.r18=self.base/'r18.json';self.r18.write_text(json.dumps(R18))
        self.put(m.DRIVER,DRIVER)
        self.put(m.WALT_H,HEADER)
        self.put(m.WALT_IMPL,PROVIDER)
        self.put(m.WALT_MAKE,'obj-$(CONFIG_SCHED_WALT) += walt.o sched_avg.o\n')
        self.put(m.STAT_H,'#ifndef _LINUX_SCHED_STAT_H\n#define _LINUX_SCHED_STAT_H\n#endif\n')
    def put(self,name,contents):
        p=self.s/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(contents)
        if name==m.DRIVER:
            q=self.c/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(contents)
    def check(self):return m.run(self.s,self.c,self.p,self.config,self.r18,self.o)
    def blocked(self,match):
        with self.assertRaisesRegex(m.ContractError,match):self.check()
        self.assertFalse(self.o.exists())
    def test_01_real_abi_patch_pass(self):
        v=self.check();self.assertEqual(v['changed_files'],[m.DRIVER]);self.assertTrue(self.o.is_dir())
        src=(self.s/m.DRIVER).read_text()
        self.assertIn('#include <linux/sched/walt.h>',src)
        self.assertIn('if (!sched_lpm_disallowed_time(cpu, &bias_time))',src)
        self.assertNotIn(m.OLD_STUB,src)
        self.assertIn('pm_cpu->bias = bias_time;',src)
        self.assertEqual((self.c/m.DRIVER).read_text(),DRIVER)
    def test_02_exact_patch_three_hunks(self):
        self.check();diff=(self.o/'R20_R4_SOURCE_DIFF.patch').read_text()
        self.assertEqual(diff.count('@@'),6);self.assertEqual(len([x for x in diff.splitlines() if x.startswith('+') and not x.startswith('+++')]),2)
    def test_03_real_15_object_hash_proof(self):
        j=self.check();self.assertEqual(j['provider_object_sha256'],'a'*64)
    def test_04_genuine_provider_required(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('int sched_lpm_disallowed_time(', 'u64 sched_lpm_disallowed_time('));self.blocked('REAL_PROVIDER')
    def test_05_2_args_no_1_arg(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('int cpu, u64 *timeout','int cpu'));self.blocked('REAL_PROVIDER')
    def test_06_requires_real_header(self):
        self.put(m.WALT_H,HEADER.replace('extern int','extern u64'));self.blocked('HEADER_NOT')
    def test_07_requires_nonwalt_fallback(self):
        self.put(m.WALT_H,HEADER.replace('INT_MAX','0'));self.blocked('MISSING_REAL_NO_WALT')
    def test_08_does_not_fake_runtime(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('busy_hyst_end_time','static_never_busy'));self.blocked('BUSY_HYST')
    def test_09_requires_timeout_writing(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('*timeout = bias_end_time - now;','/* drop write */'));self.blocked('BUSY_HYST')
    def test_10_requires_export(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('EXPORT_SYMBOL(sched_lpm_disallowed_time);',''));self.blocked('NOT_EXPORTED')
    def test_11_real_sched_avg_in_makefile(self):
        self.put(m.WALT_MAKE,'obj-y += walt.o\n');self.blocked('SCHED_AVG_NOT_IN_MAKEFILE')
    def test_12_no_legacy_conflicting_proto(self):
        self.put(m.STAT_H,'extern u64 sched_lpm_disallowed_time(int cpu);\n');self.blocked('LEGACY_STAT_H_CONFLICT')
    def test_13_never_compile_walt_off(self):
        self.config.write_text('# CONFIG_SCHED_WALT is not set\n');self.blocked('WALT_NOT_Y')
    def test_14_not_assume_unproved_object(self):
        z=json.loads(self.r18.read_text());z['objects']['kernel/sched/walt/sched_avg.o']['compiled']=False;self.r18.write_text(json.dumps(z));self.blocked('OBJECT_NOT_PROVEN')
    def test_15_sha_proof_required(self):
        z=json.loads(self.r18.read_text());z['objects']['kernel/sched/walt/sched_avg.o']['object_sha256']='x';self.r18.write_text(json.dumps(z));self.blocked('SHA_MISSING')
    def test_16_no_other_source_drift(self):
        self.put(m.DRIVER,DRIVER+'// extra\n');self.blocked('PINNED_PREIMAGE_SHA_DRIFT')
    def test_17_legacy_stub_unique(self):
        txt=DRIVER.replace(m.OLD_STUB,'');self.put(m.DRIVER,txt)
        with mock.patch.object(m,'DRIVER_PIN_BLOB',m.gitblob(b(txt))):self.blocked('LEGACY_WALT_OFF_STUB_DRIFT')
    def test_18_call_scope_unique(self):
        txt=DRIVER.replace(m.OLD_CALL,'\tif (1) {\n');self.put(m.DRIVER,txt)
        with mock.patch.object(m,'DRIVER_PIN_BLOB',m.gitblob(b(txt))):self.blocked('DRIVER_CALL_COUNT_OR_HEADER_DRIFT')
    def test_19_prevent_edit_canonical(self):
        self.s=self.c;self.blocked('CANONICAL_CANNOT_BE')
    def test_20_prevent_edit_under_project(self):
        self.s=self.p;self.blocked('PROJECT_MUTATION_FORBIDDEN')
    def test_21_prevent_report_in_source(self):
        self.o=self.s/'reports';self.blocked('REPORT_OUTPUT_UNSAFE')
    def test_22_symlink_driver_blocked(self):
        f=self.s/m.DRIVER;f.unlink();f.symlink_to(self.c/m.DRIVER);self.blocked('UNSAFE_STAGE_INPUT')
    def test_23_symlink_provider_blocked(self):
        f=self.s/m.WALT_IMPL;f.unlink();f.symlink_to(self.c/m.DRIVER);self.blocked('UNSAFE_STAGE_INPUT')
    def test_24_canonical_modified_aborts(self):
        (self.c/m.DRIVER).write_text(DRIVER+'t');self.blocked('CANONICAL_DRIVER_DRIFT')
    def test_25_cannot_overwrite_report(self):
        self.o.mkdir()
        with self.assertRaisesRegex(m.ContractError,'REPORT_OUTPUT_UNSAFE'):self.check()
        self.assertEqual(list(self.o.iterdir()),[])
    def test_26_archive_report_is_no_flash(self):
        j=self.check();self.assertFalse(j['flash_allowed']);self.assertFalse(j['brene_changed']);self.assertFalse(j['bakasusu_nomount_changed'])
    def test_27_verify_git_blob(self):
        self.assertEqual(m.gitblob(b(DRIVER)),m.DRIVER_PIN_BLOB)
    def test_28_nonwalt_header_still_compiles(self):
        self.assertIn('return INT_MAX;',HEADER)
    def test_29_multiple_backend_abi_blocks(self):
        self.put(m.WALT_IMPL,PROVIDER+'\n'+PROVIDER);self.blocked('REAL_PROVIDER')
    def test_30_no_export_dummy(self):
        self.put(m.WALT_IMPL,PROVIDER.replace('EXPORT_SYMBOL(sched_lpm_disallowed_time);','EXPORT_SYMBOL(fake);'));self.blocked('NOT_EXPORTED')

if __name__=='__main__':unittest.main()
