import datetime,hashlib,io,json,pathlib,sys,tempfile,unittest,zipfile
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from trigger_build import choose_run, inspect_compiled
from contracts import require,BASEFILES,PIN,H6_BLOB,REPO,H6

class BuildControlTests(unittest.TestCase):
 def setUp(self):
  self.now=datetime.datetime(2026,11,2,17,30,0,tzinfo=datetime.timezone.utc)
  self.run={'id':700,'created_at':'2026-11-02T17:30:04Z','head_sha':'a'*40,
      'event':'workflow_dispatch','path':H6,'status':'queued','html_url':'https://github.com/test'}
 def test_select_only_new_matching_run(self):
  self.assertEqual(choose_run([self.run],{699},'a'*40,self.now)['id'],700)
 def test_reject_old_run(self):
  self.assertIsNone(choose_run([self.run],{700},'a'*40,self.now))
 def test_reject_wrong_commit(self):
  self.assertIsNone(choose_run([self.run],set(),'b'*40,self.now))
 def test_reject_other_workflow(self):
  self.assertIsNone(choose_run([{**self.run,'path':'.github/workflows/foo.yml'}],set(),'a'*40,self.now))
 def test_reject_ambiguous_runs(self):
  with self.assertRaisesRegex(ValueError,'AMBIGUOUS'):
   choose_run([self.run,{**self.run,'id':701}],set(),'a'*40,self.now)
 def _zip(self,p,pass_build):
  report={'status':'ACTIVE_BAKASU_SUSFS_NOMOUNT_V22_TRUE_KERNEL_BUILD_PASS_NOFLASH' if pass_build else 'BLOCKED_COMPILER',
    'true_active_bakasu_susfs_nomount_compiled':pass_build,'nomount_protocol':22,
    'vendor_abi_proven':False,'device_test':False,'flash_allowed':False,
    'compiler_status':'COMPILED' if pass_build else 'FAILED','project_repo_unchanged':True,
    'no_brene_changes':True,'no_vendor_changes':True,'walt_enabled':False,
    'compiler_file_hashes':{'NOMOUNT_OBJECT':'x'*64} if pass_build else {}}
  with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('R55H6_FINAL_STATUS.json',json.dumps(report))
 def test_true_build_never_equals_flash_ready(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip';self._zip(p,True)
   d=inspect_compiled(p,'success')
   self.assertTrue(d['compiler_integrated_three_components'])
   self.assertFalse(d['flash_allowed']);self.assertFalse(d['CASS_in_same_vmlinux_proven'])
   self.assertFalse(d['all_updates_integrated']);self.assertFalse(d['vendor_abi_proven'])
 def test_failed_build_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip';self._zip(p,False)
   self.assertFalse(inspect_compiled(p,'failure')['compiler_integrated_three_components'])
 def test_brene_or_walt_change_fails_compiler_claim(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip';self._zip(p,True)
   with zipfile.ZipFile(p) as z:r=json.loads(z.read('R55H6_FINAL_STATUS.json'))
   for key,value in [('no_brene_changes',False),('walt_enabled',True),('no_vendor_changes',False)]:
    altered=dict(r);altered[key]=value
    with zipfile.ZipFile(p,'w') as z:z.writestr('R55H6_FINAL_STATUS.json',json.dumps(altered))
    self.assertFalse(inspect_compiled(p,'success')['compiler_integrated_three_components'])
 def test_failed_run_cannot_claim_compile(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip';self._zip(p,True)
   self.assertFalse(inspect_compiled(p,'failure')['compiler_integrated_three_components'])
 def test_missing_result_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip'
   with zipfile.ZipFile(p,'w') as z:z.writestr('README','hello')
   with self.assertRaisesRegex(ValueError,'H6_FINAL_STATUS_MISSING'):
    inspect_compiled(p,'success')
 def test_bad_claim_is_rejected(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'a.zip';self._zip(p,True)
   with zipfile.ZipFile(p) as z:r=json.loads(z.read('R55H6_FINAL_STATUS.json'))
   r['flash_allowed']=True
   with zipfile.ZipFile(p,'w') as z:z.writestr('R55H6_FINAL_STATUS.json',json.dumps(r))
   with self.assertRaisesRegex(ValueError,'H6_INVALID_RELEASE_CLAIM'):inspect_compiled(p,'success')
 def test_nonempty_sha_and_pins(self):
  self.assertEqual(len(BASEFILES),3)
  self.assertTrue(all(len(v)==64 for v in BASEFILES.values()))
  self.assertTrue(all(len(v)==40 for v in PIN.values()))
  self.assertEqual(len(H6_BLOB),40)
 def test_strict_assert(self):
  with self.assertRaises(ValueError):require(False,'SHOULD_FAIL')

if __name__=='__main__':unittest.main()
