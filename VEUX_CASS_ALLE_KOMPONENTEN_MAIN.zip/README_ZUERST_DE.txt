VEUX CASS / BakaSU / SUSFS 2.3 / NoMount v2.2 — echter Build-Kontrolllauf (NO FLASH)
Datum 02.11.2026

WAS DIESER LAUF TUT
  1. Prueft unveraendert SHA256 der vorhandenen R13-, R41- und Jack54-Main.
  2. Prueft den existierenden R55H6-Workflow gegen seinen Git-Blob und die
     Pin-Commits. Dieser Workflow fuehrt tatsaechlich eine vollstaendige
     ARM64-Kompilierung (Image, dtbs, modules) auf 5.4.274 aus.
  3. Erfasst BakaSU-/ReSukiSU-, SUSFS- und NoMount-Kandidaten samt Herkunft
     und Review-Sperren. Neuere UAPI-/DEV-Staende werden NICHT ungeprueft
     als Bestandteil eines fertigen Kernels deklariert.
  4. Loest mit dem automatisch bereitgestellten GITHUB_TOKEN (KEIN PAT,
     keine eigenen Secrets) den bestehenden R55H6-Kompilierlauf aus,
     wartet auf seinen Abschluss und prueft das echte CI-Pruefartefakt.
  5. Legt den Build-Bericht als GitHub-Artefakt ab. Keine Flashbefehle,
     kein automatischer Kernel-Upload als flashbares Paket.

STAND IM VORHANDENEN R55H6-BUILD
  BakaSU 35252 Commit d5e9e025b8b49155f8014684d64c91742b465f65
  SUSFS 2.3.0 (native 5.4 Patchkette, 21 Dateien)
  NoMount 2.2.0 built-in, Commit bf1847f98fed382369c43bfd652cd93774b9b8e3
  Linux 5.4.274 P11/WALT aus/CASS-R13-Referenz
  Aktuelle neuere Kandidaten (BakaSU 35257 mit UAPI-6, SUSFS a120,
  NoMount DEV) sind NUR OFFENE REVIEWPUNKTE, NICHT bereits eingebaut.

OFFENES UND BEWUSST NICHT UMGANGENES
  - CASS wirklich in demselben neuen vmlinux und CONFIG_SCHED_WALT=n
  - Neuer BakaSU-35257-Port und UAPI-6-Kompatibilitaet
  - NoMount-DEV-Commit von 02.11.2026 und VINTF-Kompatibilitaet
  - SUSFS-2.3.0-Kandidatenintegration, SELinux + AVD, OPEN_REDIRECT/SRCU
  - Vendor-ABI: 132 RMNET-CRC-Importe, BReNE unveraendert
  - DTB/DTBO, Boot-Roundtrip, AnyKernel3, SELinux, Gerätelauf
  - Alle Checks muessen vor einer Flashfreigabe konkret bestanden sein.

GITHUB-UPLOAD: Gesamt-ZIP ZUERST ENTPACKEN.
  VEUX_CASS_ALLE_KOMPONENTEN_MAIN.zip -> Repo-Hauptverzeichnis.
  VEUX_CASS_ALLE_KOMPONENTEN_BUILD_NOFLASH.yml -> .github/workflows/
  In GitHub Actions den neuen VEUX-Workflow auf main starten.
  Der Controller braucht GITHUB_TOKEN mit actions: write (in der YAML
  konfiguriert). Kein nutzereigener Secret/Token notwendig.
  Workflow muss ohne automatisch wechselnde Upstream-Snapshots ausfuehren.
  R55H6 darf auf dem Gerät NICHT geflasht werden, auch nicht bei Compiler-PASS.

Wenn das GitHub-TOKEN zum Starten der bestehenden R55H6-Workflow nicht
berechtigt ist, wird FAIL-CLOSED abgebrochen; dieses Ergebnis ist kein
Quellfehler und darf nicht mit einem Bypass 'repariert' werden.
