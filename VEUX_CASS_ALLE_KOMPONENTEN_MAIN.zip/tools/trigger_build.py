#!/usr/bin/env python3
"""Dispatch and verify the actual pre-existing combined 5.4.274 kernel build.
Only native GitHub Actions GITHUB_TOKEN is used; no PAT, installer, or root modifications.
Never marks an experimental kernel as flashable.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,os,pathlib,sys,time,urllib.error,urllib.parse,urllib.request,zipfile
from contracts import REPO, H6, require
HOST='https://api.github.com'
ARTIFACT_PREFIX='VEUX-R55H6-R1-BAKASU-SUSFS-NOMOUNT-V22-NOFLASH-'

class Api:
 def __init__(self,token):
  require(bool(token),'GITHUB_TOKEN_MISSING')
  self.token=token
 def fetch(self,method,path,body=None,redirects=True):
  assert path.startswith('/repos/'+REPO+'/')
  payload=None if body is None else json.dumps(body,separators=(',',':')).encode()
  req=urllib.request.Request(HOST+path,data=payload,method=method,headers={
   'Accept':'application/vnd.github+json','Authorization':'Bearer '+self.token,
   'X-GitHub-Api-Version':'2022-11-28','User-Agent':'VEUX-CASS-compiler-auditor',
   **({'Content-Type':'application/json'} if payload is not None else {})})
  class NoRedirect(urllib.request.HTTPRedirectHandler):
   def redirect_request(self,req,fp,code,msg,headers,newurl):return None
  opener=urllib.request.build_opener() if redirects else urllib.request.build_opener(NoRedirect())
  try:
   with opener.open(req,timeout=35) as response:
    if response.status==204:return None
    return json.load(response)
  except urllib.error.HTTPError as e:
   reason=e.read(320).decode('utf8','replace')
   raise RuntimeError(f'GITHUB_HTTP_{e.code}:{reason}') from None

def parse_run(j):
 return {k:j.get(k) for k in ('id','created_at','head_sha','name','path','status','conclusion','html_url','event','run_attempt')}

def choose_run(items,known,head,start):
 matches=[]
 for j in items:
  if j.get('id') in known or j.get('head_sha')!=head or j.get('event')!='workflow_dispatch':continue
  created=j.get('created_at','')
  try:d=datetime.datetime.fromisoformat(created.replace('Z','+00:00'))
  except ValueError:continue
  if d<start-datetime.timedelta(seconds=5):continue
  if j.get('path')!=H6:continue
  matches.append(j)
 if len(matches)>1:raise ValueError('AMBIGUOUS_DISPATCH_RUNS')
 return matches[0] if matches else None

def download_artifact(api,api_path,out,max_size=250_000_000):
 # Never forward the bearer token to the temporary artifact storage service.
 request=urllib.request.Request(HOST+api_path,headers={
  'Accept':'application/vnd.github+json','Authorization':'Bearer '+api.token,
  'X-GitHub-Api-Version':'2022-11-28','User-Agent':'VEUX-CASS-compiler-auditor'})
 class NoRedirect(urllib.request.HTTPRedirectHandler):
  def redirect_request(self,req,fp,code,msg,headers,newurl):return None
 opener=urllib.request.build_opener(NoRedirect())
 try:opener.open(request,timeout=35);raise ValueError('EXPECTED_REDIRECT_MISSING')
 except urllib.error.HTTPError as e:
  if e.code not in (302,303,307,308):raise RuntimeError('ARTIFACT_API_HTTP_'+str(e.code)) from None
  url=e.headers.get('Location','')
 parsed=urllib.parse.urlparse(url)
 host=parsed.hostname or ''
 allowed=(host.endswith('.blob.core.windows.net') or
          host.endswith('.actions.githubusercontent.com') or
          host.endswith('.githubusercontent.com'))
 require(parsed.scheme=='https' and allowed and not parsed.username and not parsed.password,'UNSAFE_ARTIFACT_DOWNLOAD_REDIRECT')
 out=pathlib.Path(out);out.parent.mkdir(parents=True,exist_ok=True)
 h=hashlib.sha256();size=0
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'VEUX-CASS-compiler-auditor'}),timeout=120) as src,out.open('xb') as dst:
  while True:
   block=src.read(2**20)
   if not block:break
   size+=len(block);require(size<=max_size,'ARTIFACT_ZIP_TOO_LARGE')
   dst.write(block);h.update(block)
 return h.hexdigest(),size

def inspect_compiled(zip_path, build_conclusion, reported_digest=None):
 with zipfile.ZipFile(zip_path) as z:
  names=z.namelist()
  require(len(names)==len(set(names)) and z.testzip() is None,'H6_ARTIFACT_UNSAFE_OR_BAD_CRC')
  candidates=[x for x in names if x.endswith('R55H6_FINAL_STATUS.json')]
  require(len(candidates)==1,'H6_FINAL_STATUS_MISSING_OR_AMBIGUOUS')
  status=json.loads(z.read(candidates[0]))
  mandatory={'true_active_bakasu_susfs_nomount_compiled','nomount_protocol','vendor_abi_proven','device_test','flash_allowed','status'}
  require(mandatory<=status.keys(),'H6_RESULT_SCHEMA_MISSING')
  require(status['nomount_protocol']==22,'H6_PROTOCOL_NOT_V22')
  require(status['flash_allowed'] is False and status['device_test'] is False,'H6_INVALID_RELEASE_CLAIM')
  raw_compiled=(build_conclusion=='success' and
      status['status']=='ACTIVE_BAKASU_SUSFS_NOMOUNT_V22_TRUE_KERNEL_BUILD_PASS_NOFLASH' and
      status['true_active_bakasu_susfs_nomount_compiled'] is True and
      status.get('compiler_status') not in (None,'NOT_STARTED') and
      status.get('project_repo_unchanged') is True and
      status.get('no_brene_changes') is True and
      status.get('no_vendor_changes') is True and
      status.get('walt_enabled') is False and
      isinstance(status.get('compiler_file_hashes'),dict) and
      'NOMOUNT_OBJECT' in status['compiler_file_hashes'])
  # The H6 output explicitly leaves vendor ABI unresolved. No release/flash success.
  return {'schema':'VEUX_H6_REAL_BUILD_AUDIT_V1','h6_status':status,
    'github_conclusion':build_conclusion,'compiler_integrated_three_components':bool(raw_compiled),
    'CASS_in_same_vmlinux_proven':False,'RMNET_132_CRC_proven':False,
    'updated_BakaSU_35257_integrated':False,'updated_NoMount_dev_integrated':False,
    'SUSFS_candidate_8a12_integrated':False,'AK3_static_boot_pass':False,
    'all_updates_integrated':False,'vendor_abi_proven':False,
    'flash_allowed':False,'device_tested':False}

def main():
 a=argparse.ArgumentParser();a.add_argument('--sha',required=True);a.add_argument('--out',required=True);
 a.add_argument('--timeout',type=int,default=14000);x=a.parse_args()
 require(bool(os.environ.get('GITHUB_REPOSITORY')==REPO),'REPOSITORY_CHANGED')
 token=os.environ.get('GITHUB_TOKEN','');api=Api(token)
 out=pathlib.Path(x.out);out.mkdir(parents=True,exist_ok=True)
 path='/repos/'+REPO+'/actions/workflows/'+urllib.parse.quote(H6.rsplit('/',1)[1],safe='')+'/runs?event=workflow_dispatch&branch=main&per_page=50'
 known={r['id'] for r in api.fetch('GET',path).get('workflow_runs',[])}
 start=datetime.datetime.now(datetime.timezone.utc)
 dispatch='/repos/'+REPO+'/actions/workflows/'+urllib.parse.quote(H6.rsplit('/',1)[1],safe='')+'/dispatches'
 api.fetch('POST',dispatch,{'ref':'main'})
 print('EXISTING_REAL_R55H6_FULL_BUILD_DISPATCHED__NO_FLASH',flush=True)
 match=None
 for i in range(40):
  time.sleep(8)
  match=choose_run(api.fetch('GET',path).get('workflow_runs',[]),known,x.sha,start)
  if match:break
 require(match is not None,'DISPATCH_RUN_NOT_LOCATED')
 run_id=match['id'];report={'schema':'VEUX_H6_ORCHESTRATOR_V1','run_id':run_id,'url':match['html_url'],
   'target_workflow':H6,'source_sha':x.sha,'flash_allowed':False,
   'real_build_triggered':True,'real_build_completed':False}
 (out/'TRIGGERED_BUILD.json').write_text(json.dumps(report,indent=2)+'\n')
 print('REAL_BUILD_RUN_URL='+str(match['html_url']),flush=True)
 deadline=time.monotonic()+x.timeout
 while time.monotonic()<deadline:
  data=api.fetch('GET','/repos/'+REPO+'/actions/runs/'+str(run_id))
  if data.get('status')=='completed':break
  time.sleep(35)
 else:raise RuntimeError('H6_BUILD_TIMEOUT__SEE_'+str(match['html_url']))
 report['github_status']=data.get('status');report['github_conclusion']=data.get('conclusion');report['real_build_completed']=True
 artifacts=api.fetch('GET','/repos/'+REPO+'/actions/runs/'+str(run_id)+'/artifacts').get('artifacts',[])
 matches=[a for a in artifacts if a['name']==ARTIFACT_PREFIX+str(run_id) and not a.get('expired')]
 require(len(matches)==1,'R55H6_BUILD_EVIDENCE_ARTIFACT_MISSING')
 a=matches[0];output=out/'R55H6_EVIDENCE.zip'
 digest,size=download_artifact(api,'/repos/'+REPO+'/actions/artifacts/'+str(a['id'])+'/zip',output)
 reported=a.get('digest','')
 require(not reported or reported=='sha256:'+digest,'H6_ARTIFACT_DIGEST_MISMATCH')
 parsed=inspect_compiled(output,data.get('conclusion'))
 report.update({'artifact_id':a['id'],'artifact_sha256':digest,'artifact_bytes':size,
                'compiled_components_verified':parsed['compiler_integrated_three_components'],
                'release_ready':False,'flash_allowed':False})
 (out/'TRIGGERED_BUILD.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 (out/'BUILD_STATUS.json').write_text(json.dumps(parsed,indent=2,sort_keys=True)+'\n')
 print('R55H6_REAL_COMPILE='+('PASS' if parsed['compiler_integrated_three_components'] else 'BLOCKED'),flush=True)
 print('NEWER_CANDIDATE_UPDATES=REVIEW_PENDING; VENDOR_ABI=BLOCKED; CASS=UNPROVEN; FLASH=NO',flush=True)
 if not parsed['compiler_integrated_three_components']:raise RuntimeError('ACTUAL_COMBINED_KERNEL_BUILD_NOT_PROVEN')

if __name__=='__main__':
 try:main()
 except Exception as exc:
  print('R55H6_BUILD_DRIVER_FAIL_CLOSED='+str(exc),file=sys.stderr)
  raise SystemExit(3)
