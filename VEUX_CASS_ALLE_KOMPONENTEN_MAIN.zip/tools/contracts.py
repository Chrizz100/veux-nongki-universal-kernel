#!/usr/bin/env python3
"""VEUX full-build readiness: immutable stock/CASS source & component locks.
This is a *build-driver contract*, not a source-only green result or flash approval.
"""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, re, subprocess, sys

REPO='Chrizz100/veux-nongki-universal-kernel'
H6='.github/workflows/VEUX_R55H6_R1_274_BAKASU_SUSFS_NOMOUNT_V22_NOFLASH.yml'
H6_BLOB='8f71cae9c040134f37c2c683f272279eb84ddbad'
BASEFILES={
 'VEUX_R13_CASS_MAIN.zip':'15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1',
 'VEUX_R41_NOMOUNT_SOURCE_MAIN.zip':'e9ea57fc1feb8d4d0e840a61b21174ad1d83d496216794bd9285b40f17026bff',
 'VEUX_JACK54_CASS_MAIN_20261102.zip':'d621629e9bc78bf33433bd5357a9649b8d86f32fc864c753b6947126c37a63b1'
}
PIN={
 'bakas_uapi5_current':'8770c7e324a22895703c4916b8a16520e0b81c79',
 'bakas_uapi6_candidate':'516d3e87fbc986ccefdde2c2765f1700612441a9',
 'nomount_current':'c5fad9d8f97c5a207f7342fd91789449915ea047',
 'nomount_v22':'bf1847f98fed382369c43bfd652cd93774b9b8e3',
 'susfs_current':'5326e21a7eb232f9e21debdd5164e99bee3d1e2f',
 'susfs_candidate':'8a120081f2739bc0e4b1f6a389d8236f22944acc',
 'jack54_patch':'bd505f994e255156e8233c399d6835641423bbf6',
 'bakas_h6_stable':'d5e9e025b8b49155f8014684d64c91742b465f65',
 'nomount_dev_20261102':'04af0552bb29c7cee1b78c3eea69d7ed98b80bf2',
 'stock_micode_ref':'61397e524093d1ccb94769b5460825e2eaf8871e'
}

def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()

def git(root,*args):
 return subprocess.check_output(['git','-C',str(root),*args], text=True).strip()

def require(test, message):
 if not test: raise ValueError(message)

# The pinned H6 script uses this actual step and emits these exact evidence
# markers. The old arbitrary English words "Full Kbuild" / "Image dtbs modules"
# were never present in the real workflow, despite a genuine compile step.
# H6_BLOB continues to require byte-identical, immutable workflow content.
H6_BUILD_STEP = 'Build BakaSU 35252 plus SUSFS 2.3.0 plus NoMount v22 built-in ARM64 Image DTBs'
H6_EVIDENCE_MARKERS = (
    'R55H5_ACTIVE_BUILD_RESULT.json',
    'R55H6_FINAL_STATUS.json',
    'R55H6_TRUE_COMPILER_RESULT=',
    'true_active_bakasu_susfs_nomount_compiled',
    'NOMOUNT_OBJECT',
    'Upload BakaSU source and compiler evidence only; never boot images',
)

def verify_h6_compiler_contract(workflow_text: str) -> bool:
    if not isinstance(workflow_text, str):
        return False
    if workflow_text.count(H6_BUILD_STEP) != 1:
        return False
    if any(workflow_text.count(marker) != 1 for marker in H6_EVIDENCE_MARKERS):
        return False
    return True

def audit(root: pathlib.Path, refs: pathlib.Path, checked_sha: str|None=None)->dict:
 root=root.resolve(strict=True)
 require((root/'.git').is_dir(), 'NOT_A_GIT_CHECKOUT')
 require(checked_sha is None or git(root,'rev-parse','HEAD')==checked_sha,'CHECKOUT_COMMIT_MISMATCH')
 require(not git(root,'status','--porcelain','--untracked-files=all'),'CHECKOUT_DIRTY')
 files={}
 for name,digest in BASEFILES.items():
  file=root/name
  require(file.is_file() and not file.is_symlink(),'MISSING_INPUT:'+name)
  found=sha(file)
  require(found==digest,'BAD_INPUT_SHA256:'+name)
  files[name]=found
 h6=root/H6
 require(h6.is_file() and not h6.is_symlink(),'H6_WORKFLOW_MISSING')
 require(git(root,'hash-object',H6)==H6_BLOB,'H6_WORKFLOW_SHA_DRIFT')
 h6txt=h6.read_text(encoding='utf8')
 require('workflow_dispatch' in h6txt,'H6_NOT_MANUALLY_DISPATCHABLE')
 require("ref: bf1847f98fed382369c43bfd652cd93774b9b8e3" in h6txt,'H6_NOMOUNT_PIN_CHANGED')
 require("ref: d5e9e025b8b49155f8014684d64c91742b465f65" in h6txt,'H6_BAKASU_PIN_CHANGED')
 require(verify_h6_compiler_contract(h6txt),'H6_NOT_FULL_BUILD')
 def upstream(component,file):
  p=root/'common/upstream'/component/(file+'.json')
  require(p.is_file(), 'MISSING_UPSTREAM_METADATA:'+str(p))
  return json.loads(p.read_text())
 baka, bakac=upstream('resukisu','current'),upstream('resukisu','candidate')
 nm,nmc=upstream('nomount','current'),upstream('nomount','candidate')
 sf,sfc=upstream('susfs','current'),upstream('susfs','candidate')
 # These are independently refreshed *candidates*, not build sources.
 # Never let an unreviewed new candidate silently alter a pinned H6 compile.
 # Nor should a harmless metadata refresh prevent the old pinned build.
 for item in (baka,bakac,nm,nmc,sf,sfc):
  require(isinstance(item,dict) and re.fullmatch(r'[0-9a-f]{40}',item.get('commit','')),
          'INVALID_UPSTREAM_METADATA')
 candidates_observed={'BakaSU_current':baka,'BakaSU_candidate':bakac,
                      'NoMount_current':nm,'NoMount_candidate':nmc,
                      'SUSFS_current':sf,'SUSFS_candidate':sfc}
 snapshot_drift=(baka['commit']!=PIN['bakas_uapi5_current'] or
                 bakac['commit']!=PIN['bakas_uapi6_candidate'] or
                 nm['commit']!=PIN['nomount_current'] or
                 nmc['commit']!=PIN['nomount_v22'] or
                 sf['commit']!=PIN['susfs_current'] or
                 sfc['commit']!=PIN['susfs_candidate'])
 ref=json.loads((refs/'VEUX_JACK54_REFERENCE_GATE.json').read_text())
 jack_patch=(refs/'JACK_5.4_REFERENCE.patch').read_text()
 require('+#define SUSFS_VERSION "v2.3.0"' in jack_patch and
         'susfs_spoof_avd_allowed_rcu' in jack_patch and
         'srcu_read_lock(&susfs_srcu_open_redirect)' in jack_patch, 'JACK_5_4_REFERENCE_INCOMPLETE')
 require('diff --git a/security/selinux/ss/services.c' not in jack_patch,'JACK_SELINUX_SERVICES_FALSE_PROOF')
 r55=(refs/'R55_CASS_AVD_BRIDGE_REFERENCE.patch').read_text()
 require('susfs_spoof_avd_allowed_rcu' in r55 and 'rcu_read_lock();' in r55,
         'R55_AVD_BRIDGE_MISSING')
 require(ref['schema']=='VEUX_JACK54_STOCK_BRIDGE_V1','JACK_REFERENCE_SCHEMA_CHANGED')
 require(ref['all_updates_integrated'] is False and ref['new_kernel_compiled'] is False and ref['flash_allowed'] is False,'JACK_REFERENCE_MISREPORTED')
 require(ref['provenance']['jack_commit']==PIN['jack54_patch'],'JACK_REFERENCE_PIN_DRIFT')
 report={
  'schema':'VEUX_CASS_FULL_BUILD_CONTROL_V1','repository':REPO,'checkout_sha':git(root,'rev-parse','HEAD'),
  'baseline_input_sha256':files,'h6_workflow_sha1_gitblob':H6_BLOB,
  'build_requested':'R55H6 real 5.4.274 ARM64 compilation, BakaSU 35252 + SUSFS 2.3.0 + NoMount built-in v22',
  'build_path':H6,'source_bridge_current':ref['status'],
  'tested_build_pins':{'BakaSU':PIN['bakas_h6_stable'],'NoMount':PIN['nomount_v22'],'SUSFS':'2.3.0'},
  'candidate_snapshot_changed_since_lock':snapshot_drift,
  'candidate_snapshots_observed_from_checkout':candidates_observed,
  'newer_candidates_not_auto_integrated':{
      'BakaSU_35257_uapi6':PIN['bakas_uapi6_candidate'],
      'SUSFS_2_3_0':PIN['susfs_candidate'],
      'NoMount_dev':PIN['nomount_dev_20261102']},
  'pending_compatibility': ['BakaSU UAPI 5 -> 6 review and native 5.4 hooks',
     'NoMount dev vs stable v22 kernel API and VINTF check',
     'SUSFS snapshot new commits against original Jack/native54 fork',
     'CASS symbol/config linked proof on combined Image',
     '132 RMNET CRC imports and vendor loader ABI',
     'Image/vmlinux/Module.symvers DTB/DTBO and OEM bootimage compatibility',
     'AK3 static installer / boot unpack-repack device-specific check'],
  'kernel_compiled':False,'all_updates_integrated':False,'vendor_abi_proven':False,
  'flash_allowed':False,'device_tested':False,'BReNE_changed':False
 }
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--refs',required=True);p.add_argument('--out',required=True);p.add_argument('--sha',default=None)
 a=p.parse_args()
 out=pathlib.Path(a.out)
 try:
  result=audit(pathlib.Path(a.repo),pathlib.Path(a.refs),a.sha)
 except Exception as exc:
  out.parent.mkdir(parents=True,exist_ok=True)
  (out.parent/'COMPONENT_PINS_FAILURE.json').write_text(json.dumps({
   'stage':'R55H6_PINNED_COMPONENTS_PREFLIGHT',
   'error_type':type(exc).__name__, 'error':str(exc),
   'kernel_compiled':False, 'flash_allowed':False},indent=2,sort_keys=True)+'\n')
  print('R55H6_SOURCE_AND_COMPONENT_PINS=BLOCKED:'+str(exc),file=sys.stderr)
  raise SystemExit(3)
 out.parent.mkdir(parents=True,exist_ok=True)
 out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 print('R55H6_SOURCE_AND_COMPONENT_PINS=PASS; COMPILE_PENDING; UPDATE_CANDIDATES_PENDING; NO_FLASH')
