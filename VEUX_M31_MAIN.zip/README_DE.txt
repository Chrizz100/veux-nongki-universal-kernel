VEUX M31 – BQ-Schreibfehler und GPIO-/OTG-Teilzustaende – NOFLASH
Basis: gruener M30-Lauf 43710552679, Commit ffbf9396e6e3a369b513c4b299a6f1566feb4e6c.

UPLOAD AM SMARTPHONE
1. VEUX_M31_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   Die MAIN nicht entpacken. Ein angehaengtes (1) im Namen entfernen.
2. VEUX_M31_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach den Workflow manuell starten.
   Historische Pakete werden aus festen Commit-Referenzen geladen und authentifiziert.

BESTAETIGTER M30-STAND
Alle 32 Artefakte heruntergeladen und geprueft: 752 Dateien, 692 Textdateien,
162 JSON-Dateien, 34.664.784 dekodierte Textbytes. Archiv-SHA-256 und ZIP-CRC passen.
Neun Archive enthalten historische Fehler aus Zwischenpruefungen; alle sechs
betroffenen Ziele wurden spaeter erfolgreich in R18 kompiliert. Keine neuen
M30-Baufehler. Zuordnung: Reports/RUN43710552679_32_ARTEFAKTE.zip.
Finaler M30 unabhaengig geprueft: BQ-Probe-/Lesefehler, WT, SC8551, RPM,
eingebettete Konfiguration/Image/vmlinux, 1.423 passende QGKI-Import-CRCs,
37 passende Module und unveraenderte komplette Exporttabelle. Alle 40 make-
Aufrufe erfolgreich. Boot.img und AK3 aus gepinnten Referenzen byteidentisch
rekonstruiert. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen den finalen M30.

M31-REPARATUR
Die BQ-IIO-Schreibfunktion ignoriert bisher Bus-, GPIO- und Batterieabfragefehler.
Sie meldet Erfolg und aktualisiert teils interne Werte vor dem Hardwareerfolg.
M31 gibt Fehler zurueck und beendet abhaengige Aktionen am ersten Fehler.
Strom-/HIZ-/Terminierungswerte werden erst nach erfolgreichem zugehoerigem
Schreiben uebernommen. GPIO-Umschaltung meldet Fehler ebenfalls weiter.
OTG verwendet das tatsaechliche IIO-Geraet statt des globalen g_bq-Zeigers.
Nach erfolgreich aktiviertem OTG bleiben Status und Wakeup bei einem spaeteren
Fehler gesetzt. Nach erfolgreich deaktiviertem OTG werden sie auch dann
freigegeben, wenn anschliessendes Lade-Einschalten fehlschlaegt.
Es gibt keine behauptete atomare Hardwaretransaktion und kein blindes Rollback:
Bereits erfolgreiche Teiloperationen bleiben wirksam; der Aufrufer erhaelt den
Fehler. Ein physischer Busfehler beweist nicht den tatsaechlichen Chipzustand.

Nur bq_iio_write_raw und bq2589x_usb_switch sind gegenueber M30 geaendert.
Alle zwoelf M30-Lesefunktionen und die erprobte Probe-Funktion bleiben byteidentisch.
Strom-/Spannungsvorgaben und die erfolgreichen Hardware-Ablaufspuren bleiben
unveraendert. Keine zusaetzliche 5-V-VINDPM-Regel, keine Defconfig-Aenderung.
Die beiden Header bleiben byteidentisch, insbesondere 1.763 Bytes ohne EOF-LF.

PRUEFUNGEN UND CI
25 neue/fortgefuehrte M31-Regressionen bestehen mit GCC 11.4 und GCC 14 sowie UBSan.
Der native Schreibtest fuehrt echte Treiberfunktionen aus: 416 erfolgreiche
Grenzwert-/Chip-/Batterie-/Wakeup-Faelle und 6.960 gezielte Fehlerfaelle;
37.571 C-Assertions. Dazu unveraenderte 2.327 Lese- und 156 Probe-Assertions.
Der ganze geaenderte BQ-Treiber ist fuer ARM64 mit Clang 12.0.5 und CFI/ThinLTO
kompiliert. Das ersetzt keinen vollstaendigen lokalen M31-Kernelbau.
Die YAML fuehrt saemtliche authentifizierten Elternregressionen plus M31 aus.
Der volle M31-CI-Bau muss neue Quellen, LLVM-Objekt, CFI-Kommando, Interfaces
und Lese-/Schreibfehlerzweige in Image UND vmlinux nachweisen. Anschliessend
alle unveraenderten Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates.
M30 wird unveraendert fuer seine Regressionen geladen. Die neue BQ-Schicht
baut auf dem authentischen M28-R2-Kern auf, damit alte ganze Dateihashes nicht
neue, streng begrenzte Reparaturen blockieren. Alle semantischen Gates bleiben.
Kernelkennung: 5.4.274-qgki-g82179e362f33.

OFFEN
Vollstaendiger M31-GitHub-Bau und dessen Artefaktpruefung. Danach spaetere
BQ-Probe-Ressourcenaufraeumung und Shutdown-Synchronisation sowie weitere
offene Quellpunkte. Die historischen ueber 7.100 Quellabweichungen sind nicht
allein durch diese Build-/ABI-Pruefungen als repariert nachgewiesen.
Geraeteboot, Laden, OTG, Suspend und Wiederherstellung sind noch ungetestet.
Kein universeller GKI-/Vollvergleich aller OEM-Module. Device Pass NEIN.
Flashfreigabe NEIN. Alle Produkte bleiben NOFLASH.
