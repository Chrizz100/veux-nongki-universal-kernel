#!/usr/bin/env python3
"""Offline guardrail tests, no network or kernel flash/build."""
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch
import replay_p2_source as r
import walt_source_audit as w
import stage_stock274 as s


def git(root,*a):
    x=subprocess.run(['git','-C',str(root),*a],capture_output=True,text=True,check=False)
    if x.returncode:raise AssertionError(x.stderr)
    return x.stdout.strip()


class SourceGateTests(unittest.TestCase):
    def test_gitblob_matches_git(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);git(root,'init','-q');p=root/'file';p.write_bytes(b'hi\n')
            self.assertEqual(r.gitblob(p.read_bytes()),git(root,'hash-object','file'))
            self.assertEqual(w.gitblob(p.read_bytes()),r.gitblob(p.read_bytes()))

    def test_github_env_parse(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'env';p.write_text('HELLO=world\n')
            env={};pos=r.read_env_update(p,0,env)
            self.assertEqual(env['HELLO'],'world')
            with p.open('a') as out:out.write('PIN=abcd\n')
            self.assertEqual(r.read_env_update(p,pos,env),p.stat().st_size)
            self.assertEqual(env['PIN'],'abcd')

    def test_invalid_env_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'env';p.write_text('INVALID_HEREDOC<<EOF\n')
            with self.assertRaisesRegex(ValueError,'UNSUPPORTED_GITHUB_ENV'):
                r.read_env_update(p,0,{})

    def test_donor_sha_fail_closed(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'donor.yml';f.write_text('on: workflow_dispatch\n')
            with self.assertRaisesRegex(ValueError,'PINNED_HISTORICAL_WORKFLOW_CHANGED'):
                r.load_plan(f,Path(d))

    def test_static_pins_were_not_removed(self):
        self.assertEqual(r.P2_TREE,s.checked(['echo',r.P2_TREE]))
        self.assertEqual(s.P2_TOOL_BLOB,'10cc6d1a5cd8020d4783073070f2a57f2b9b769d')
        self.assertEqual(len(s.EXPECTED_PATHS),6)
        self.assertEqual(len(w.FILES),11)
        self.assertTrue(all(len(x)==40 for x in w.FILES.values()))

    def test_walt_merge_source_only(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root=base/'src';root.mkdir();git(root,'init','-q');git(root,'config','user.email','t@example.invalid');git(root,'config','user.name','tester')
            a=root/'kernel/sched';a.mkdir(parents=True)
            (a/'cass.c').write_text('int cass_old;\n')
            (a/'cass_rt.h').write_text('#pragma once\n')
            (a/'core.c').write_text('int cpu_scheduler;\n')
            git(root,'add','-A');git(root,'commit','-qm','p2')
            p2_tree=git(root,'rev-parse','HEAD^{tree}')
            branch=git(root,'branch','--show-current')
            git(root,'checkout','-qb','stock')
            (a/'walt').mkdir();content=b'obj-y += walt.o\n'
            (a/'walt/Makefile').write_bytes(content)
            (a/'core.c').write_text('int cpu_scheduler;\nint WALT_feature;\n')
            git(root,'add','-A');git(root,'commit','-qm','xiaomi stock')
            stock_sha=git(root,'rev-parse','HEAD')
            git(root,'update-ref',w.XIAOMI_REF,stock_sha)
            git(root,'checkout','-q',branch)
            git(root,'rm','-q','kernel/sched/cass.c','kernel/sched/cass_rt.h');git(root,'commit','-qm','p3 cass removed')
            before=git(root,'rev-parse','HEAD^{tree}')
            with patch.object(w,'XIAOMI_SHA',stock_sha),patch.object(w,'P2_TREE',p2_tree),patch.object(w,'FILES',{'Makefile':w.gitblob(content)}),patch.object(w,'HOSTS',('kernel/sched/core.c',)):
                outcome=w.audit(root,base/'out')
            self.assertEqual(outcome['p2_parent_tree'],p2_tree)
            self.assertFalse(outcome['walt_semantic_rebase_done'])
            self.assertFalse(outcome['flashable'])
            self.assertEqual(outcome['walt_donor_source_count'],1)
            self.assertEqual(outcome['scheduler_host_merge_probes'][0]['status'],'MANUAL_CODE_REVIEW_REQUIRED')
            self.assertEqual(git(root,'rev-parse','HEAD^{tree}'),before)
            self.assertEqual(git(root,'status','--porcelain'), '')
            self.assertEqual((base/'out/xiaomi-original-walt/Makefile').read_bytes(),content)

    def test_walt_multiple_real_git_conflicts_are_diagnostic(self):
        """Regression: 2+ conflict regions must not mean merge program failed."""
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);root=base/'source';root.mkdir()
            git(root,'init','-q')
            git(root,'config','user.name','tester')
            git(root,'config','user.email','t@example.invalid')
            sched=root/'kernel/sched';sched.mkdir(parents=True)
            (sched/'cass.c').write_text('int cass_old;\n')
            (sched/'cass_rt.h').write_text('#pragma once\n')
            common=''.join('void block_%d(void) {\n  old_%d();\n}\n' % (i,i) +
                           ''.join('/* untouched_%d_%d */\n' % (i,j) for j in range(13))
                           for i in range(3))
            (sched/'core.c').write_text(common)
            git(root,'add','-A');git(root,'commit','-qm','common base')
            common_branch=git(root,'branch','--show-current')
            git(root,'checkout','-qb','xiaomi-ref')
            (sched/'walt').mkdir();donor=b'obj-y += walt.o\n'
            (sched/'walt/Makefile').write_bytes(donor)
            stock=common
            for i in range(3):stock=stock.replace('old_%d();'%i,'stock_%d();'%i)
            (sched/'core.c').write_text(stock)
            git(root,'add','-A');git(root,'commit','-qm','xiaomi stock donor')
            stock_sha=git(root,'rev-parse','HEAD')
            git(root,'update-ref',w.XIAOMI_REF,stock_sha)
            git(root,'checkout','-q',common_branch)
            ours=common
            for i in range(3):ours=ours.replace('old_%d();'%i,'positron_%d();'%i)
            (sched/'core.c').write_text(ours)
            git(root,'add','-A');git(root,'commit','-qm','p2 with Positron changes')
            p2_tree=git(root,'rev-parse','HEAD^{tree}')
            git(root,'rm','-q','kernel/sched/cass.c','kernel/sched/cass_rt.h')
            git(root,'commit','-qm','p3 CASS removed')
            with patch.object(w,'XIAOMI_SHA',stock_sha), \
                 patch.object(w,'P2_TREE',p2_tree), \
                 patch.object(w,'FILES',{'Makefile':w.gitblob(donor)}), \
                 patch.object(w,'HOSTS',('kernel/sched/core.c',)):
                result=w.audit(root,base/'report')
            p=result['scheduler_host_merge_probes'][0]
            self.assertEqual(p['diagnostic_merge'],'CONFLICTS')
            self.assertEqual(p['merge_file_exit_status'],3)
            self.assertEqual(p['conflict_marker_count'],3)
            self.assertEqual(p['status'],'MANUAL_CODE_REVIEW_REQUIRED')
            self.assertFalse(p['semantic_merge_approved'])
            self.assertFalse(result['walt_semantic_rebase_done'])
            self.assertTrue((base/'report/host_merge_00.txt').is_file())
            self.assertEqual(git(root,'status','--porcelain'),'')

    def test_walt_tool_error_still_stops(self):
        import subprocess as sp
        from unittest.mock import Mock
        for rc,output in ((255,b''),(2,b''),(0,b'<<<<<<< bad\n')):
            proc=sp.CompletedProcess(args=['git','merge-file'],returncode=rc,
                                     stdout=output,stderr=b'fake error')
            with self.assertRaisesRegex(RuntimeError,'MERGE_TOOL_ERROR'):
                w.classify_merge_file_result(proc,'kernel/sched/core.c')
        proc=sp.CompletedProcess(args=['git','merge-file'],returncode=3,
                                 stdout=b'<<<<<<< x\n',stderr=b'')
        with self.assertRaisesRegex(RuntimeError,'MERGE_COUNT_MISMATCH'):
            w.classify_merge_file_result(proc,'kernel/sched/core.c')

    def test_walt_pin_drift_blocks(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertNotEqual(w.gitblob(b'changed'),w.FILES['Makefile'])

    def test_stage_output_guard(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d);(base/'kernel').mkdir();(base/'project').mkdir()
            with self.assertRaisesRegex(RuntimeError,'UNSAFE_OUTPUT'):
                s.stage(base,base/'kernel/out')

if __name__=='__main__': unittest.main(verbosity=2)
