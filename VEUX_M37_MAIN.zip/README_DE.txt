VEUX M37 - VINDPM-/HIZ-Fehler und unabhaengige Wiederherstellung - NOFLASH
Basis: gruener M36-Lauf 43805889804, Commit ce347a1bf4cda96832ee205d21ac788034779349.

UPLOAD AM SMARTPHONE
1. VEUX_M37_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M37_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M36 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256 und komplette ZIP-CRC geprueft:
1.178 Dateien, 1.085 Textdateien, 309 JSON-Dateien, 38.202.086 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; alle sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M36 unabhaengig geprueft:
echte Quellen, LLVM-Objekt/CFI-Kommando, neun verlinkte Schnittstellen und fuenf
Monitor-Fehlerzweige, 40 erfolgreiche make-Aufrufe, eingebettete Konfiguration
in Image/vmlinux und unveraenderte komplette Exporttabelle.
Import-CRCs unabhaengig neu berechnet: 1.423 passend, keine CRC-Abweichung,
kein fehlender Export und 37 passende Module der bekannten Stock-Vendor-Kohorte.
Boot.img und AK3 byteidentisch aus gepinnten Referenzen rekonstruiert;
AVB und Stock-Ramdisk/Paar geprueft. Tiefe Binaer-/ABI-/Boot-Pruefungen betreffen
den finalen M36. Reports/RUN43805889804_32_ARTEFAKTE.zip und
Reports/M36_INDEPENDENT_VERIFICATION.json enthalten die aktuelle Auswertung.
Fruehere Berichte bleiben in den unveraenderten, gepinnten Vorgaengerpaketen;
dieses Paket wiederholt diese historischen Berichtskopien nicht.
Static Boot Pass ist kein Device Pass.

M37 REPARATUR
Geaendert sind nur bq2589x_adjust_absolute_vindpm und der VINDPM-/HIZ-Block
in bq2589x_monitor_workfunc. Alle anderen Bytes des M36-Monitors bleiben gleich.
Ein gescheitertes Abschalten fuer die VINDPM-Messung etabliert keine gueltigen
Messbedingungen. Danach werden die davon abhaengige Wartezeit, ADC-Messung und
VINDPM-Konfiguration nicht fortgesetzt. Die bisherige unabhaengige Wiederaktivierung
des Ladezweigs wird trotzdem versucht: Ein gemeldeter Busfehler beweist nicht,
dass ein Schreibzugriff die Hardware unveraendert gelassen hat.
Auch nach gescheiterter ADC-Messung wird diese Wiederherstellung versucht.
Der erste Fehler wird im Fehlerprotokoll erhalten; ein zusaetzlicher Fehler bei
der Wiederherstellung wird separat gemeldet. Nach irgendeinem dieser Fehler
folgt keine abhaengige VINDPM-Konfiguration. Deren eigener Fehler wird ebenfalls
protokolliert. Die private Helper-Signatur bleibt void; kein neuer API-Rueckgabewert.
Erfolgreiche Werte und Reihenfolgen bleiben gleich: 1.000 ms Messwartezeit,
SDP 4.400 mV und fuer die uebrigen Typen 4.500 mV; keine neuen Stromgrenzen.
Der Monitor protokolliert Fehler des VINDPM-Lesens sowie HIZ-Eintritt und -Austritt.
Der Austritt wird weiterhin auch nach einem gemeldeten Eintrittsfehler versucht.
Die bisherige 1-ms-Wartezeit und die anschliessende unabhaengige Temperatur- und
Spannungspruefung sowie das 10-Sekunden-Monitorintervall bleiben erhalten.
Die M36-Gueltigkeitspruefung fuer Messwerte, Konfigurationswiederholung und
Temperaturabschaltung sind ausserhalb des HIZ-Blocks byteidentisch geschuetzt.
Keine Defconfig-/ABI-/Header-Aenderung. bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-LF.

BEWUSSTE GRENZEN
Wiederherstellungsversuch bedeutet keine nachgewiesene Hardware-Wiederherstellung.
Eine gescheiterte HIZ-Ruecksetzung wird gemeldet; kein neuer persistenter
Recovery-Zustand und keine neue Abschalt- oder Wiederholungsstrategie werden
erfunden. Die bisherige Lade-Wiederaktivierung im VINDPM-Helfer bleibt erhalten,
auch wenn der Ladezweig beim Aufruf bereits ausgeschaltet war.
Parallele Adapter-/Monitorarbeiten werden nicht neu serialisiert. ICO-, DPDM-
und Provider-/Versorgungspfade sowie echte Geraeteablaeufe sind weiter zu pruefen.

LOKALE PRUEFUNGEN
40 M37-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Neuer nativer Test mit echten VINDPM-/Monitorfunktionen und Registerhelfern:
24.930 C-Assertions, 224 gleiche Erfolgsablaeufe und 4.832 gezielte Fehlerfaelle.
Beide Chips, acht Adaptertypen, mehrere Messwerte, alle vier Lese- und drei
Schreibphasen des VINDPM-Helfers sowie die HIZ-Aufrufstellen sind geprueft.
Dauerhafte Busfehler und Schreibzugriffe, die den simulierten Chip trotz Fehler
veraendern, sind ebenfalls geprueft. Doppelfehler beweisen den erhaltenen ersten Fehler und den separaten Restore-Fehler.
Auch nach HIZ-Fehlern wird die bestehende Temperaturabschaltung erreicht.
Zwei alte M36-Fehler wurden reproduziert; die neue Fehlererwartung weist M36 ab.
Ein manipulierter Temperaturschwellwert scheitert selbst mit neu berechneten
Datei-/Manifest-Hashes am separaten Schutz aller Nicht-HIZ-Monitorbytes.
Alle aktuellen nativen Tests zusammen: 110.640 C-Assertions; dazu 156 Assertions
des unveraenderten Probetests auf der M31-Referenz.
Der komplette Treiber kompiliert fuer ARM64 mit gepinntem AOSP Clang 12.0.5,
CFI/ThinLTO und den Headern des aktuellen M36-Laufs. Kein voller lokaler M37-Kernelbau.

CI UND OFFENE ARBEIT
Alle bisherigen Reparaturschichten werden unveraendert geladen und getestet.
Die neue Schicht nutzt den authentischen M28-R2-Baukern mit allen Konfigurations-,
WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates. M37 muss neue Quellen, LLVM-Objekt,
CFI-Kommando, neun verlinkte Schnittstellen und fuenf neue VINDPM-/HIZ-Fehlerzweige
in Image UND vmlinux nachweisen. Konfiguration und komplette Exporttabelle muessen
unveraendert bleiben. Boot.img/AK3 erst nach diesen Gates.
Originalkennung: 5.4.274-qgki-g82179e362f33.
Offen: vollstaendiger M37-GitHub-Bau und alle Artefakte, danach ICO-/DPDM- und
Provider-/Versorgungspfade. Kein Vollvergleich aller historischen ueber 7.100
Quellabweichungen und kein universeller GKI-Nachweis.
Geraeteboot, Laden, OTG, Suspend, Shutdown und Wiederherstellung bleiben ungetestet.
Device Pass NEIN. Flashfreigabe NEIN.
