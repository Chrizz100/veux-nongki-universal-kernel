VEUX 5.4.274 – SUSFS-/BakaSU-SELinux-Compat R5 – EXPERIMENTELL

1) Originale MAIN-ZIP unverändert ins Repo-HAUPTVERZEICHNIS:
   VEUX_R6_SUSFS_SELINUX54_R5_MAIN.zip
2) Gesonderte YAML nach .github/workflows/ hochladen:
   VEUX_R6_SUSFS_SELINUX54_R5_EXPERIMENTAL_BUILD.yml
3) GitHub Actions: VEUX R6 SUSFS SELinux 5.4 R5 – Partial Compat Build – NO FLASH
   -> Run workflow -> enable_build=true.
4) Den neuen Run-Link zur unabhängigen Audit- und Build-Artefaktprüfung senden.

KERNEL-KERN und R4 bleiben unverändert bis zum Workflow. Builds ausschließlich im Runner-Temp.
R5 portiert 3 vorhandene BakaSU-5.4-SELinux-Rückfallbedingungen aus dem aktuellen
SUSFS-Verhaltensvergleich. Die upstreamseitige BakaSU 32bit-Kompatibilität von
Commit 522081c5 und das volle SUSFS-/BakaSU-Upgrade sind NICHT enthalten.
Nicht als Flashpaket freigegeben. Kein Claim auf Gerätetest.
