# VEUX R5 – BakaSU/SUSFS 5.4.274: exakter Update-Umfang

Stand: 18.10.2026. Referenz: GitHub R4-Build 39008125408 (grün, Kernel+AK3+statische Bootprüfung; kein Gerätetest).

## Was R5 tatsächlich integriert

Das originale BakaSU-SELinux `selinux_hide.c` von d7260ca1 wird durch dieselbe bytegenau verifizierte, bereits in R4 kompilierte Statusänderung ergänzt. Zusätzlich werden genau DREI frühe Rückfallbedingungen an die neuere SUSFS-5.10-Hooklogik angepasst, **in BakaSUs bereits vorhandenen 5.4-Wrappers**:

1. `my_write_context`: originaler SELinux-Handler, wenn UID < 10000 **oder** `ksu_selinux_hide_running` falsch.
2. `my_write_access`: gleiche Bedingung.
3. `ksu_handle_selinux_setprocattr`: zum originalen Handler, wenn UID < 10000 **oder** `ksu_selinux_hide_running` falsch.

Dies ist eine begrenzte semantische Anpassung an den belegten Upstream-Diff `5326e21a..fec037cb`, nicht der vollständige 5.10-Patch. Der einzig berührte Kernelquellpfad ist `KernelSU/kernel/feature/selinux_hide.c`. Das bereits in R4 vorhandene `my_sel_open_handle_status`-Update bleibt erhalten. Das Update wird NUR in einer temporären GitHub-Actions-Quellkopie nach der offiziellen d726-Sicherheitsreparatur und vor dem echten Kernel-Build angewendet. Die drei nativen SUSFS-Kerndateien und `security/selinux/{hooks,selinuxfs}.c` bleiben unverändert.

**R4-Quell-SHA-256:** `3cb110f10df3f552620dbd7592d15270b8c45a0179c2bc0e34210ad6120bf0d6`.

**R5-Kandidat-SHA-256:** `8f17c3588e10a1d5d607a098ae51075d36ed5792e1e62e3886ede14f3e7d73df`.

## Was R5 ausdrücklich NICHT enthält

- **BakaSU-32-Bit-Userspace-Upstreamcommit `522081c5` vom 18.10.**: Mehrere Kernel-/Hook-/Syscall-Dateien, Codegenerierung und neue Makros sind für Linux 5.4 als zusammengehörige Portierung separat erforderlich. Ein beliebiges Teilstück in `sucompat.c` genügt nicht. R5 verändert diese Dateien nicht und belässt den ursprünglichen BakaSU-Versionscode 35222.
- **Neuere volle BakaSU-Quelle `b2c595dd`**: nicht direkt austauschbar, weil im aktuellen `kernel/tools/susfs_compat.mk` weiterhin ein aktives `$(error Please wait susfs update.)` den Build ausdrücklich stoppt. Der Stop wird NICHT auskommentiert oder umgangen.
- **Vollständiger SUSFS-5.10-Integrationspatch**: neue `security/selinux/hooks.c` und `security/selinux/selinuxfs.c`-Hunks gehören zu GKI 5.10 und sind keine direkt anwendbaren VEUX-5.4-Hunks; 24 Hostpfade und 11 von 28 KernelSU-Patchzielpfaden brauchen eine vollständige Bewertung. Die drei SUSFS-Kerndateien waren im letzten bestätigten Vergleich identisch; sie werden nicht künstlich ersetzt.
- Keine künstliche KernelSU-Versionsanhebung, keine CRC-/vermagic-Fälschung, keine Abschaltung von CFI, ThinLTO, Kernel-Stackschutz oder `CONFIG_MODVERSIONS`.
- Kein Geräte-PASS, keine Flashfreigabe, kein Release und keine automatische Source-Promotion.

## Nachweise und Reihenfolge

- R2 `38965488864`: NoMount 2.1.1 Full Compile, Stack-/LTO-Gates und AK3 grün.
- R3 `39004860053`: 1 SELinux-Statusfix quellseitig grün.
- R4 `39008125408`: Linux 5.4.274 Full Compile/Static Boot und Pakete grün; feste R4-SELinux-Referenz.
- R5: lokaler Static-Green-Pass erforderlich, **danach** experimenteller Build über separate GitHub Actions. Erst der neue GitHub-Lauf darf behaupten, die drei R5-Anpassungen seien kompiliert. Eine Ausführung auf dem Gerät ist daraus nicht abzuleiten.

Offizielle Quellen: https://gitlab.com/simonpunk/susfs4ksu/-/tree/gki-android13-5.10 und https://github.com/Baka-SU/BakaSU/commit/522081c5b1c58587c4c743242eecf445ccebed5d
