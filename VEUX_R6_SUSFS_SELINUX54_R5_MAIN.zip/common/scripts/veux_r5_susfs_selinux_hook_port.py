#!/usr/bin/env python3
"""VEUX R5: three strictly scoped SUSFS SELinux runtime parity guards.

The official SUSFS GKI 5.10 patch gates setprocattr, sel_write_context,
sel_write_access on both app UID and ksu_selinux_hide_running.  On the proven
VEUX 5.4 kernel, the corresponding routines are already implemented as BakaSU
legacy wrappers instead of native 5.10 SELinux code.  Reuse them, do not
install the 5.10 patch into native host SELinux or remove the BakaSU blocker.

Only works with byte-authenticated R4 selinux_hide.c, in disposable source;
never changes repository or donor and is NOT a full upstream sync.
"""
from __future__ import annotations
import difflib
import hashlib
import json
from pathlib import Path
import re

REL = 'KernelSU/kernel/feature/selinux_hide.c'
KERNEL = '5.4.274'
OFFICIAL_D726_SHA = 'e4299d4db52b3e761413928d733076dc497104cee0cd5ab27e165364cd773c5c'
R4_SHA = '3cb110f10df3f552620dbd7592d15270b8c45a0179c2bc0e34210ad6120bf0d6'
R4_BLOB = 'd4b19f7989167f85f2f2c0373fef366bee762e01'
STATUS_START = 'static int my_sel_open_handle_status(struct inode *inode, struct file *filp)'
STATUS_OLD = 'if (likely(ksu_get_uid_t(current_uid()) >= 10000 && ksu_selinux_hide_enabled)) {'
STATUS_NEW = 'if (likely(ksu_get_uid_t(current_uid()) >= 10000 && ksu_selinux_hide_running)) {'
OLD = 'if (likely(ksu_get_uid_t(current_uid()) < 10000)) {'
NEW = 'if (likely(ksu_get_uid_t(current_uid()) < 10000 || !ksu_selinux_hide_running)) {'
SCOPE = (
    ('my_write_context', 'static ssize_t my_write_context(', 'static ssize_t my_write_access(', 'orig_context_write'),
    ('my_write_access', 'static ssize_t my_write_access(', '/*\n * get the security ID', 'orig_access_write'),
    ('ksu_handle_selinux_setprocattr', 'int __nocfi ksu_handle_selinux_setprocattr(const char *name,', 'typedef int (*sel_open_handle_status_fn)', 'goto call_orig'),
)
TARGET_SHA = '8f17c3588e10a1d5d607a098ae51075d36ed5792e1e62e3886ede14f3e7d73df'
TARGET_BLOB = '24e166346d409d9eae6a06451518eb7e42f7b985'

class PortError(RuntimeError):
    pass

def require(x: bool, err: str) -> None:
    if not x:
        raise PortError(err)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git_blob(data: bytes) -> str:
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def guard_r4_text(original: bytes, expected_sha: str = R4_SHA, expected_blob: str = R4_BLOB) -> tuple[bytes, dict]:
    require(sha(original) == expected_sha, 'R4_SELINUX_SOURCE_PREIMAGE_MISMATCH')
    require(git_blob(original) == expected_blob, 'R4_GIT_BLOB_MISMATCH')
    text = original.decode('utf-8', errors='strict')
    require(text.count(STATUS_NEW) == 1 and text.count(STATUS_OLD) == 0,
            'R4_STATUS_GATE_MISSING_OR_AMBIGUOUS')
    require(text.count(OLD) == 3 and text.count(NEW) == 0,
            'R4_THREE_WRAPPERS_ORIGINAL_GUARDS_CHANGED')
    require(text.count('ksu_selinux_hide_running __read_mostly = false;') == 1,
            'R4_BAKASU_RUNTIME_FLAG_MISSING')
    updated = text
    edits = []
    for name, begin, end, evidence in SCOPE:
        require(updated.count(begin) == 1 and updated.count(end) == 1,
                'R5_FUNCTION_BOUNDARY_MISSING_OR_AMBIGUOUS_'+name)
        a = updated.index(begin)
        b = updated.index(end, a+len(begin))
        fragment = updated[a:b]
        require(fragment.count(OLD) == 1 and fragment.count(NEW) == 0,
                'R5_WRAPPER_GUARD_NOT_UNIQUE_'+name)
        require(evidence in fragment,
                'R5_ORIGINAL_SELINUX_CONTROL_PATH_MISSING_'+name)
        result = fragment.replace(OLD, NEW, 1)
        updated = updated[:a] + result + updated[b:]
        edits.append({'function':name,'guard_before':OLD,'guard_after':NEW})
    output = updated.encode('utf-8')
    require(len(edits) == 3 and updated.count(NEW) == 3 and updated.count(OLD) == 0,
            'R5_CHANGE_COUNT_NOT_THREE')
    # Reversing EXACTLY these three substitutions must reconstruct the R4 blob.
    require(output.replace(NEW.encode(),OLD.encode()) == original,
            'R5_UNRELATED_SOURCE_MUTATION')
    for token in ('PROCESS__SETCURRENT','PROCESS__DYNTRANSITION','PROCESS__PTRACE',
                  'ksu_security_context_to_sid','backup_policydb','fake_status',
                  'ksu_selinux_hide_unhook','ksu_selinux_hide_enabled','commit_creds(new)'):
        require(updated.count(token) == text.count(token),
                'R5_SECURITY_FLOW_OR_RESOURCE_LIFETIME_CHANGED_'+token)
    return output, {
        'status':'EXACT_THREE_5_4_BAKASU_SUSFS_RUNTIME_PARITY_EDITS',
        'kernel':KERNEL,'path':REL,'sha256_before':sha(original),
        'sha256_after':sha(output),'git_blob_before':git_blob(original),
        'git_blob_after':git_blob(output),'changes':edits,
        'native_selinux_files_changed':False,
        'official_upstream_32bit_commit_integrated':False,
        'full_susfs_510_integration':False,
        'bakasu_upstream_susfs_blocker_removed':False,
        'source_and_runtime_different':True,
        'device_pass':False,'flash_release':False,
    }

def verify_target(output: bytes) -> None:
    require(sha(output)==TARGET_SHA and git_blob(output)==TARGET_BLOB,
            'R5_IMMUTABLE_TARGET_SOURCE_HASH_CHANGED')

def verify_reference_r4(path: Path) -> dict:
    require(path.is_file() and not path.is_symlink(), 'R5_R4_REFERENCE_SOURCE_UNSAFE')
    original=path.read_bytes()
    updated, audit=guard_r4_text(original)
    verify_target(updated)
    audit['R4_reference_source_verified']=True
    return audit

def write_diff(old: bytes, updated: bytes) -> str:
    diff=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),
        updated.decode().splitlines(keepends=True),fromfile='a/'+REL,tofile='b/'+REL,n=4))
    require(diff.count('@@')==6 and diff.count('-    '+OLD)==3 and diff.count('+    '+NEW)==3,
            'R5_DIFF_NOT_EXACTLY_THREE_HUNKS')
    return diff
