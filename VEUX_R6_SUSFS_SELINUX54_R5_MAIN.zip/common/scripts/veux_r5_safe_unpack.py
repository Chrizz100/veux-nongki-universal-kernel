#!/usr/bin/env python3
"""Fail-closed R5/R4/R2 archive identity and extraction to runner.temp only."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import os
import stat
import sys
import zipfile

R4_SHA = '05a5fe60a643b64a9a9f427b40215ae5634984660c57391d411c25a1d8e4432f'
R2_SHA = 'ac70b8203ddc9978847b819413cc239cd2b3aab22ef60277fa8f0b2adb8ebda3'
R4_AUDIT_SHA = '9d0a58fc8deafebade097b6cf8ddc4de333b08d2ae7c82edc470895236d7a0c8'
SUSFS_DIFF_SHA = '2930df057b10764fbb85313b21e5b0baa794db7091b31e7e76f75721fe26928f'
R5_NAMES = {
 'MANIFEST_SHA256.json','README_START_HIER_DE.txt',
 'baseline/VEUX_R6_SUSFS_SELINUX54_R4_MAIN.zip',
 'evidence/VEUX_R4_RUN39008125408_AUDIT_ORIGINAL.zip',
 'evidence/SUSFS_5326_ZU_FEC037_SOURCE_DIFF_AUDIT.zip',
 'common/scripts/veux_r5_susfs_selinux_hook_port.py',
 'common/scripts/veux_r5_susfs_selinux_build.py',
 'common/scripts/veux_r5_safe_unpack.py',
 'Tests/test_veux_r5_susfs_selinux.py',
 'docs/R5_OFFENE_BAKASU_SUSFS_UPDATES.json',
 'docs/R5_SUSFS_BAKASU_ABGRENZUNG_DE.md',
 'reviews/SELINUX_SUSFS_R5_REVIEW.patch',
}
R4_NAMES={
 'MANIFEST_SHA256.json','README_START_HIER_DE.txt',
 'Tests/test_susfs_selinux54_r3.py','Tests/test_veux_r6_susfs_selinux54_build_r4.py',
 'baseline/VEUX_R6_NM211_R2_MAIN.zip',
 'common/scripts/veux_r6_susfs_selinux54_build_r4.py',
 'common/scripts/veux_r6_susfs_selinux54_port_r3.py',
 'evidence/R3_GITHUB_AUDIT_39004860053.zip',
}
R2_NAMES={
 'README_START_HIER_DE.txt', 'MANIFEST_SHA256.json',
 'Tests/test_veux_r6_nomount211_build_r2.py',
 'Tests/test_veux_r6_nomount211_preflight_r1.py',
 'common/r6_nm211/SUSFS_R2_NACHPRUEFUNG.json',
 'common/r6_nm211/pinned_nomount_7046c7ad_source.tar.gz',
 'common/scripts/veux_r6_nomount211_build_r2.py',
 'common/scripts/veux_r6_nomount211_preflight_r1.py',
}

class UnsafeArchive(RuntimeError):
    pass

def ensure(valid: bool, error: str):
    if not valid:
        raise UnsafeArchive(error)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def unpack(path: Path,dest: Path, expected: set[str], schema: int, *, require_unpacked: bool = True) -> dict:
    ensure(not dest.exists() and not dest.is_symlink(), 'DEST_ALREADY_PRESENT')
    with zipfile.ZipFile(path) as z:
        li=z.infolist()
        ensure(len(li)==len(expected) and set(x.filename for x in li)==expected,
            'ZIP_MEMBER_COUNT_OR_SCOPE_DRIFT')
        ensure(z.testzip() is None, 'ZIP_MEMBER_CORRUPTION')
        manifest=json.loads(z.read('MANIFEST_SHA256.json'))
        ensure(manifest.get('schema')==schema and manifest.get('approved_for_flash') is False,
            'MANIFEST_SCHEMA_OR_FLASH_STATUS_INVALID')
        ensure(set(manifest.get('files',{}))==expected-{'MANIFEST_SHA256.json'},
            'MANIFEST_FILE_LIST_DRIFT')
        data={}
        for member in li:
            rel=PurePosixPath(member.filename)
            mode=member.external_attr>>16
            ensure(not rel.is_absolute() and '..' not in rel.parts and
                   '\\' not in member.filename and stat.S_ISREG(mode),
                   'ZIP_TRAVERSAL_LINK_OR_UNSUPPORTED_MEMBER')
            raw=z.read(member.filename)
            if member.filename!='MANIFEST_SHA256.json':
                ensure(sha(raw)==manifest['files'][member.filename],
                    'MEMBER_HASH_DRIFT_'+member.filename)
            data[member.filename]=raw
    if require_unpacked:
        dest.mkdir(parents=True)
        for name,raw in data.items():
            target=dest.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True,exist_ok=True)
            ensure(not target.exists() and not target.is_symlink(), 'ZIP_MEMBER_COLLISION')
            target.write_bytes(raw)
    return manifest

def perform(main: Path, work: Path) -> dict:
    main=main.resolve(strict=True)
    ensure(main.is_file() and not main.is_symlink(),'MAIN_ZIP_UNSAFE')
    work=work.resolve()
    ensure(not work.exists() and not work.is_symlink(),'WORKSPACE_ALREADY_EXISTS')
    base=work.parent
    ensure(base.is_dir() and not base.is_symlink(),'WORKSPACE_PARENT_INVALID')
    r5=work/'r5';r4=work/'r4';r2=work/'r2'
    work.mkdir(parents=True)
    manifest=unpack(main,r5,R5_NAMES,5)
    ensure(manifest.get('r4_green_run')==39008125408 and
           manifest.get('r3_source_green_run')==39004860053 and
           manifest.get('r2_green_run')==38965488864 and
           manifest.get('bakasu_522_upstream_integrated') is False and
           manifest.get('full_upstream_susfs_integrated') is False,
           'R5_MANIFEST_FALSE_UPSTREAM_OR_PROVENANCE_CLAIM')
    r4zip=r5/'baseline/VEUX_R6_SUSFS_SELINUX54_R4_MAIN.zip'
    ensure(sha(r4zip.read_bytes())==R4_SHA,'R4_BASELINE_ZIP_SHA_DRIFT')
    r4manifest=unpack(r4zip,r4,R4_NAMES,4)
    ensure(r4manifest.get('r2_green_kernel_run')==38965488864 and
           r4manifest.get('susfs_component_pin')=='5326e21a7eb232f9e21debdd5164e99bee3d1e2f',
           'R4_PIN_OR_REFERENCE_CHANGED')
    r2zip=r4/'baseline/VEUX_R6_NM211_R2_MAIN.zip'
    ensure(sha(r2zip.read_bytes())==R2_SHA,'R2_BASELINE_ZIP_SHA_DRIFT')
    r2manifest=unpack(r2zip,r2,R2_NAMES,2)
    ensure(r2manifest.get('last_source_pass_run')==38960694902 and
           r2manifest.get('nomount_candidate')=='7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3',
           'R2_LAST_GREEN_OR_NOMOUNT_PIN_DRIFT')
    audit=r5/'evidence/VEUX_R4_RUN39008125408_AUDIT_ORIGINAL.zip'
    ensure(sha(audit.read_bytes())==R4_AUDIT_SHA,'R4_GITHUB_CI_AUDIT_SHA_DRIFT')
    # Main ZIP was independently pinned and every contained member hashed above.
    # Only now is it safe to import its pure, source-only verification helper.
    scripts=str(r5/'common/scripts')
    if scripts not in sys.path:sys.path.insert(0,scripts)
    from veux_r5_susfs_selinux_hook_port import R4_SHA as R4_SOURCE_SHA,verify_reference_r4
    with zipfile.ZipFile(audit) as z:
        ensure(z.testzip() is None,'GITHUB_R4_AUDIT_ZIP_CORRUPT')
        source=z.read('report/SUSFS_SELINUX54_R3/SELINUX_5_4_PORT_R3_STAGED.c')
        prior=json.loads(z.read('report/SELINUX54_R4_FINAL.json'))
        ensure(sha(source)==R4_SOURCE_SHA and
               prior.get('status')=='EXPERIMENTAL_R4_COMPILE_GATES_PASS_DEVICE_UNTESTED' and
               prior.get('actual_kernel_build') is True and
               prior.get('flash_release') is False,
               'R4_GITHUB_BUILD_PROVENANCE_FALSE')
    src_file=work/'R4_COMPILED_REFERENCE_SELINUX.c'
    src_file.write_bytes(source)
    with zipfile.ZipFile(audit) as z:
        original=z.read('report/SUSFS_SELINUX54_R3/SELINUX_D726_ORIGINAL.c')
    ensure(sha(original)=='e4299d4db52b3e761413928d733076dc497104cee0cd5ab27e165364cd773c5c',
           'D726_OFFICIAL_ORIGINAL_SOURCE_HASH_CHANGED')
    (work/'D726_ORIGINAL_REFERENCE_SELINUX.c').write_bytes(original)
    audit_proof=verify_reference_r4(src_file)
    susfs=r5/'evidence/SUSFS_5326_ZU_FEC037_SOURCE_DIFF_AUDIT.zip'
    ensure(sha(susfs.read_bytes())==SUSFS_DIFF_SHA,'SUSFS_COMPAT_DIFF_SHA_DRIFT')
    with zipfile.ZipFile(susfs) as z:
        ensure(z.testzip() is None,'SUSFS_COMPAT_DIFF_CORRUPT')
        patch=z.read('reviews/50_add_susfs_in_gki-android13-5.10.patch.diff').decode()
        for mark in ('ksu_selinux_hide_running','sel_write_context','sel_write_access','selinux_setprocattr'):
            ensure(mark in patch,'SUSFS_ORIGINAL_5_10_PARITY_EVIDENCE_LOST_'+mark)
    result={
        'status':'R5_IMMUTABLE_NESTED_SOURCE_AND_GITHUB_EVIDENCE_PASS',
        'r5_main_sha256':sha(main.read_bytes()),
        'r4_main_sha256':R4_SHA,'r2_main_sha256':R2_SHA,
        'r4_github_audit_sha256':R4_AUDIT_SHA,
        'susfs_patch_diff_sha256':SUSFS_DIFF_SHA,
        'r4_compiled_source_sha256':R4_SOURCE_SHA,
        'r5_candidate_source_sha256':audit_proof['sha256_after'],
        'no_repo_writes':True,'no_upstream_guard_removal':True,
        'no_compilation_in_archive_validation':True,'device_pass':False,
    }
    (work/'ZIP_VALIDATION.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    return result

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--main',required=True,type=Path)
    p.add_argument('--work',required=True,type=Path)
    args=p.parse_args()
    try:
        result=perform(args.main,args.work)
        print(result['status'])
        return 0
    except Exception as exc:
        print('R5_SOURCE_ARCHIVE_FAIL_CLOSED:'+str(exc),file=sys.stderr)
        return 1
if __name__=='__main__':
    raise SystemExit(main())
