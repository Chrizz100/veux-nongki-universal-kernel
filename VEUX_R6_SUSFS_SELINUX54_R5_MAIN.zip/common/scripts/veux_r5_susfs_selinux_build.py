#!/usr/bin/env python3
"""VEUX 5.4.274 R5: compile strictly reviewed three-hook SUSFS/BakaSU
SELinux legacy parity candidate on the green R6/NoMount211 R2 build chain.

Does NOT replace BakaSU with new upstream, does NOT bypass the upstream SUSFS
build-stop, does NOT port the native 5.10 SELinux host patch, and never grants
flash/device permission. Changes only disposable runner workspaces.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import tempfile

import veux_r6_nomount211_build_r2 as r2
import veux_r6_susfs_selinux54_port_r3 as r3
import veux_r5_susfs_selinux_hook_port as port

KERNEL = '5.4.274'
R4_RUN = 39008125408
R4_IMAGE = 'e11853f4f98eb8a4231b9a02c52a5ca099dbead0e577d7934e7dc49c5e8ccb57'
R2_RUN = 38965488864
R5_SOURCE_SHA = port.TARGET_SHA
BAKASU_PREBLOCKER = '5b76b884c75f729a220bb317aa4a4fc78f0e0e9c'
SUSFS_BASE = '5326e21a7eb232f9e21debdd5164e99bee3d1e2f'
NOMOUNT_BASE = '7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3'

class BuildError(RuntimeError):
    pass

def need(value: bool, reason: str):
    if not value:
        raise BuildError(reason)

def sh(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def write_report(root: Path, rel: str, report: dict) -> Path:
    p=root/'report'/rel
    need(not p.exists() and not p.is_symlink(), 'REPORT_ALREADY_EXISTS_'+rel)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    return p

def stage(src: Path, bundle: Path, work: Path) -> dict:
    src=src.resolve(strict=True);bundle=bundle.resolve(strict=True);work=work.resolve(strict=True)
    root=work.parent.parent
    need(work.name==KERNEL and work.parent.name=='builds' and src.is_relative_to(work),
         'R5_UNEXPECTED_DISPOSABLE_SOURCE')
    need(bundle==root/'bundle' and not bundle.is_relative_to(src),
         'R5_BUNDLE_SCOPE_CHANGED')
    targets=json.loads((bundle/'targets.json').read_text())['components']
    need(targets['resukisu']['commit']==BAKASU_PREBLOCKER and
         targets['susfs']['commit']==SUSFS_BASE and
         targets['nomount']['commit']==NOMOUNT_BASE,
         'R5_BAKA_SUSFS_NOMOUNT_TARGETS_DRIFT')
    official=json.loads((work/'BAKASU-OFFICIAL-D726-R6.json').read_text())
    need(official.get('source_matches_official_bakasu_d726_byte_for_byte') is True
         and official.get('after_sha256')==port.OFFICIAL_D726_SHA
         and official.get('source_provenance',{}).get('upstream_commit')==r3.BAKASU_EFFECTIVE_SOURCE,
         'R5_OFFICIAL_D726_PREIMAGE_NOT_PROVEN')
    host=r3.verify_host(src)
    path=r3.safe_path(src,port.REL)
    official_bytes=path.read_bytes()
    need(sh(official_bytes)==port.OFFICIAL_D726_SHA,
         'R5_OFFICIAL_D726_BLOB_NOT_IN_BUILD_SOURCE')
    staged_r4,proof_r3=r3.transform_status_guard(official_bytes)
    need(sh(staged_r4)==port.R4_SHA and port.git_blob(staged_r4)==port.R4_BLOB,
         'R5_R4_STAGED_SOURCE_NOT_EXACT')
    r5,change=port.guard_r4_text(staged_r4)
    port.verify_target(r5)
    need(path.read_bytes()==official_bytes,'R5_DISPOSABLE_SOURCE_CHANGED_DURING_STAGE')
    path.write_bytes(r5)
    need(path.read_bytes()==r5,'R5_SOURCE_WRITE_VERIFICATION_FAILED')
    r3.verify_host(src)
    audit={'status':'EXACT_R4_PLUS_THREE_NEW_R5_SELINUX_GUARDS_STAGED',
           'official_source_before_sha256':sh(official_bytes),
           'reviewed_r4_sha256':sh(staged_r4),'reviewed_r5_sha256':sh(r5),
           'r3_status_change_applied_first':True,'R5_new_guard_count':3,
           'changed_path_only':port.REL,'native_5_4_selinux_host_unmodified':True,
           'host_checks':host,'r3_proof':proof_r3,'r5_proof':change,
           'susfs_core_pin':SUSFS_BASE,'bakasu_source_pin':BAKASU_PREBLOCKER,
           'bakasu_32bit_syscall_upstream_integrated':False,
           'full_susfs_integration_applied':False,
           'device_pass':False,'flash_release':False}
    write_report(root,'SUSFS_SELINUX54_R5_STAGE.json',audit)
    patch=port.write_diff(staged_r4,r5)
    (root/'report/SELINUX_R4_TO_R5_3_GUARDS.patch').write_text(patch)
    print('R5_SELINUX_SUSFS_THREE_RUNTIME_GUARDS_STAGED=PASS; R4+3; BAKASU32_NOT_INTEGRATED',flush=True)
    return audit

def verify_compiled(src: Path, work: Path, staged: dict, result: dict) -> dict:
    src=src.resolve(strict=True);work=work.resolve(strict=True)
    need(src.is_relative_to(work) and work.name==KERNEL,'R5_COMPILED_KERNEL_SOURCE_UNSAFE')
    need(staged.get('status')=='EXACT_R4_PLUS_THREE_NEW_R5_SELINUX_GUARDS_STAGED' and
         staged.get('reviewed_r5_sha256')==R5_SOURCE_SHA and
         staged.get('R5_new_guard_count')==3,'R5_BUILD_STAGE_NOT_VERIFIED')
    source=r3.safe_path(src,port.REL).read_bytes()
    port.verify_target(source)
    r3.verify_host(src)
    ref=work/'build/drivers/kernelsu/feature'
    obj=ref/'selinux_hide.o';cmd=ref/'.selinux_hide.o.cmd'
    log=work/'compile.log';config=work/'config-reports/actual-build.config'
    for f in (obj,cmd,log,config):
        need(f.is_file() and not f.is_symlink() and f.stat().st_size>0,
             'R5_COMPILED_OBJECT_EVIDENCE_MISSING_'+f.name)
    args=cmd.read_text(errors='replace')
    cfg=config.read_text(errors='replace')
    lg=log.read_text(errors='replace')
    need('drivers/kernelsu/feature/selinux_hide.o' in args and
         '-fstack-protector-strong' in args and '-flto=thin' in args and
         '-fno-stack-protector' not in args,
         'R5_SELINUX_OBJECT_NOT_PROTECTED')
    need(bool(re.search(r'(?m)^\s*CC\s+drivers/kernelsu/feature/selinux_hide\.o\b',lg)),
         'R5_SELINUX_OBJECT_NOT_COMPILED_IN_THIS_RUN')
    for token in ('CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
                  'CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y','CONFIG_STACKPROTECTOR_STRONG=y'):
        need(bool(re.search(r'(?m)^'+re.escape(token)+r'$',cfg)),
             'R5_KERNEL_CONFIG_CHANGED_'+token)
    need(result.get('kernel')==KERNEL,'R5_RESULT_KERNEL_MISMATCH')
    report={'status':'COMPILED_THREE_NEW_SUSFS_SELINUX_54_GUARDS',
            'source_sha256':R5_SOURCE_SHA,'source_git_blob':port.TARGET_BLOB,
            'source_changed_functions':[x[0] for x in port.SCOPE],
            'r3_status_guard_still_present':True,'source_changes_beyond_R4':3,
            'object_sha256':sh(obj.read_bytes()),'command_sha256':sh(cmd.read_bytes()),
            'config_sha256':sh(config.read_bytes()),'compile_log_sha256':sh(log.read_bytes()),
            'strong_stack_protector':True,'thinlto':True,
            'native_selinux_hooks_unchanged':True,'susfs_kernel_core_unchanged':True,
            'bakasu_32bit_522_not_integrated':True,
            'device_pass':False,'flash_release':False}
    write_report(work.parent.parent,'SUSFS_SELINUX54_R5_COMPILED.json',report)
    return report

def inject_r5_worker(disposable_worker: Path) -> dict:
    need(disposable_worker.is_file() and not disposable_worker.is_symlink(),
         'R5_DISPOSABLE_WORKER_REQUIRED')
    original=disposable_worker.read_text()
    source_anchor=r2.OVERLAY_ANCHOR
    post_anchor=r2.COMPILE_ANCHOR
    need(original.count(source_anchor)==1 and original.count(post_anchor)==1,
         'R5_PROVEN_R6_WORKER_ANCHORS_CHANGED')
    need('bakasu_official_r6 = apply_official_source(' in original and
         "result['bakasu_official_r6'] = bakasu_official_r6" in original,
         'R5_OFFICIAL_SELINUX_REPAIR_NOT_APPLIED')
    need('r5_staged = stage(' not in original and 'r5_compiled = verify_compiled(' not in original,
         'R5_WORKER_ALREADY_INJECTED')
    source=original.replace(source_anchor,
        '        from veux_r5_susfs_selinux_build import stage\n'
        '        r5_staged = stage(src, bundle, work)\n'
        +source_anchor,1)
    source=source.replace(post_anchor,
        post_anchor
        +'        from veux_r5_susfs_selinux_build import verify_compiled\n'
        +'        r5_compiled = verify_compiled(src, work, r5_staged, result)\n'
        +"        result['susfs_selinux54_r5'] = r5_compiled\n",1)
    ast.parse(source,filename=str(disposable_worker))
    need(source.count('r5_staged = stage(src, bundle, work)')==1 and
         source.count('r5_compiled = verify_compiled(src, work, r5_staged, result)')==1,
         'R5_WORKER_INJECTION_SCOPE_CHANGED')
    disposable_worker.write_text(source)
    need(disposable_worker.read_text()==source,'R5_WORKER_WRITEBACK_FAILED')
    return {'status':'R5_DISPOSABLE_R6_WORKER_INJECTED',
            'before_sha256':sh(original.encode()),'after_sha256':sh(source.encode()),
            'repository_worker_unmodified':True,'stage_before_overlay':True}

def build(repo: Path, root: Path, jobs: int) -> dict:
    repo=repo.resolve(strict=True);root=root.resolve(strict=True)
    need(not root.is_relative_to(repo) and 1<=jobs<=16,'R5_UNSAFE_BUILD_ROOT_OR_JOBS')
    r1=root/'report/NOMOUNT211_R6_SOURCE_ONLY.json'
    need(r1.is_file() and not r1.is_symlink(),'R5_REQUIRES_R2_PREPARATION_AND_PREFLIGHT')
    doc=json.loads(r1.read_text())
    need(doc.get('status')=='SOURCE_PREFLIGHT_ONLY_PASS' and
         doc.get('bakasu_or_susfs_upgraded') is False,
         'R5_OLD_BAKA_SUSFS_BASE_SOURCE_CHECK_FAILED')
    # Wrap ONLY the in-memory R1 loader to inject R5 checks into the R6 worker.
    # The actual R2 build remains the proven compiler/package/static-boot pipeline.
    original_load=r2.r1.load_r6
    record=[]
    def load_with_r5(path):
        r6=original_load(path)
        prior=r6.selinux_r3.inject_worker
        def inject(original: Path, destination: Path):
            info=prior(original,destination)
            record.append(inject_r5_worker(destination))
            return info
        r6.selinux_r3.inject_worker=inject
        return r6
    original_pythonpath=os.environ.get('PYTHONPATH','')
    scripts=str(Path(__file__).resolve().parent)
    os.environ['PYTHONPATH']=os.pathsep.join([scripts,original_pythonpath])
    r2.r1.load_r6=load_with_r5
    try:
        base=r2.build(repo,root,jobs)
    finally:
        r2.r1.load_r6=original_load
        os.environ['PYTHONPATH']=original_pythonpath
    need(len(record)==1 and record[0]['repository_worker_unmodified'],
         'R5_WORKER_NOT_INJECTED_EXACTLY_ONCE')
    pub=root/'public'/KERNEL
    row=json.loads((pub/'RESULT.json').read_text())
    proof=row.get('susfs_selinux54_r5') or {}
    need(proof.get('status')=='COMPILED_THREE_NEW_SUSFS_SELINUX_54_GUARDS' and
         proof.get('source_sha256')==R5_SOURCE_SHA and
         proof.get('source_changes_beyond_R4')==3,
         'R5_EFFECTIVE_KERNEL_SOURCE_NOT_COMPILED')
    need(row.get('targets',{}).get('susfs',{}).get('commit')==SUSFS_BASE and
         row.get('targets',{}).get('resukisu',{}).get('commit')==BAKASU_PREBLOCKER and
         row.get('targets',{}).get('nomount',{}).get('commit')==NOMOUNT_BASE,
         'R5_EFFECTIVE_COMPONENT_PINS_CHANGED')
    need(all(row.get(k) is True for k in ('compile','package','static_boot')) and
         row.get('device') is False and row.get('image_sha256') != R4_IMAGE,
         'R5_COMPILE_PACKAGE_BOOT_OR_IMAGE_NOT_PROVEN')
    need(base.get('status')=='EXPERIMENTAL_BUILD_GATES_PASS_DEVICE_NOT_TESTED',
         'R5_R2_PIPELINE_GATES_FAILED')
    summary={'status':'EXPERIMENTAL_R5_THREE_HOOK_KERNEL_BUILD_PASS_DEVICE_UNTESTED',
             'source_base':'R4 source from GitHub run '+str(R4_RUN),
             'kernel_sha256':row['image_sha256'],'reference_R4_image_sha256':R4_IMAGE,
             'bakasu_32bit_522_not_integrated':True,
             'full_susfs_510_kernel_patch_not_applied':True,
             'three_runtime_guard_edits_compiled':True,
             'susfs_component_pin':SUSFS_BASE,'bakasu_pin':BAKASU_PREBLOCKER,
             'nomount_commit':NOMOUNT_BASE,'worker_injection':record[0],
             'compiled_proof':proof,'compile':True,'package':True,'static_boot':True,
             'device_pass':False,'flash_release':False,'no_main_promotion':True}
    write_report(root,'SUSFS_SELINUX54_R5_FINAL.json',summary)
    print('VEUX_R5_SUSFS_SELINUX_54_GUARDS_BUILD_PACKAGE_STATIC=PASS; DEVICE_PASS=NO; NO_FLASH',flush=True)
    return summary

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['build'])
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--work',type=Path,required=True)
    p.add_argument('--jobs',type=int,default=4)
    args=p.parse_args()
    try:
        build(args.repo,args.work,args.jobs)
        return 0
    except Exception as exc:
        print(f'VEUX_R5_BUILD_BLOCKED:{type(exc).__name__}:{exc}',file=sys.stderr,flush=True)
        return 1

if __name__=='__main__':
    raise SystemExit(main())
