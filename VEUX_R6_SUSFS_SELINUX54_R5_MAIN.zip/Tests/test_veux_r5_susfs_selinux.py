#!/usr/bin/env python3
"""R5 negative regression gates; offline, 100% disposable fixtures."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import veux_r5_susfs_selinux_hook_port as port
import veux_r5_susfs_selinux_build as b

class TestR5(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        source=os.environ.get('R5_R4_SOURCE')
        official=os.environ.get('R5_D726_SOURCE')
        if not source or not official:
            raise AssertionError('R5_R4_SOURCE and R5_D726_SOURCE required; must come from immutable original GitHub R4 audit')
        cls.r4=Path(source).read_bytes()
        cls.d726=Path(official).read_bytes()
        assert port.sha(cls.r4)==port.R4_SHA
        assert port.sha(cls.d726)==port.OFFICIAL_D726_SHA

    def test_01_r4_source_pinned(self):
        self.assertEqual(port.sha(self.r4),port.R4_SHA)
        self.assertEqual(port.git_blob(self.r4),port.R4_BLOB)

    def test_02_only_three_exact_modifications(self):
        output,report=port.guard_r4_text(self.r4)
        self.assertEqual(len(report['changes']),3)
        self.assertEqual(output.replace(port.NEW.encode(),port.OLD.encode()),self.r4)
        self.assertEqual(report['sha256_after'],port.TARGET_SHA)

    def test_03_git_blob_and_sha_strong_identity(self):
        changed,_=port.guard_r4_text(self.r4)
        port.verify_target(changed)
        self.assertEqual(port.git_blob(changed),port.TARGET_BLOB)

    def test_04_keep_existing_r3_status_fix(self):
        out,_=port.guard_r4_text(self.r4)
        self.assertEqual(out.count(port.STATUS_NEW.encode()),1)
        self.assertNotIn(port.STATUS_OLD.encode(),out)

    def test_05_each_legacy_wrapper_one_guard(self):
        out,_=port.guard_r4_text(self.r4)
        txt=out.decode()
        self.assertEqual(txt.count(port.NEW),3)
        for fn,first,last,_ in port.SCOPE:
            self.assertEqual(txt[txt.index(first):txt.index(last,txt.index(first))].count(port.NEW),1,fn)

    def test_06_source_changed_rejected(self):
        with self.assertRaisesRegex(port.PortError,'PREIMAGE'):
            port.guard_r4_text(self.r4+b'\n')

    def test_07_duplicate_guard_rejected(self):
        changed=self.r4.replace(port.OLD.encode(),port.NEW.encode(),1)
        with self.assertRaisesRegex(port.PortError,'PREIMAGE'):
            port.guard_r4_text(changed)

    def test_08_status_guard_drift_rejected(self):
        original=self.r4.replace(port.STATUS_NEW.encode(),port.STATUS_OLD.encode(),1)
        with self.assertRaisesRegex(port.PortError,'PREIMAGE'):
            port.guard_r4_text(original)

    def test_09_missing_runtime_flag_rejected(self):
        changed=self.r4.replace(b'ksu_selinux_hide_running __read_mostly = false;',b'ksu_selinux_hide_enabled __read_mostly = false;',1)
        with self.assertRaisesRegex(port.PortError,'PREIMAGE'):
            port.guard_r4_text(changed)

    def test_10_source_official_derivation(self):
        x,_=b.r3.transform_status_guard(self.d726)
        self.assertEqual(x,self.r4)

    def test_11_patch_has_exact_three_hunks(self):
        changed,_=port.guard_r4_text(self.r4)
        patchtext=port.write_diff(self.r4,changed)
        self.assertEqual(patchtext.count('@@'),6)
        self.assertEqual(patchtext.count('+    '+port.NEW),3)

    def test_12_d726_unmodified_under_transform(self):
        changed,_=port.guard_r4_text(self.r4)
        self.assertEqual(port.sha(self.d726),port.OFFICIAL_D726_SHA)
        self.assertNotEqual(self.d726,changed)

    def test_13_false_full_susfs_claim_rejected(self):
        out,report=port.guard_r4_text(self.r4)
        self.assertIs(report['full_susfs_510_integration'],False)
        self.assertIs(report['official_upstream_32bit_commit_integrated'],False)

    def test_14_false_device_claim_absent(self):
        out,report=port.guard_r4_text(self.r4)
        self.assertIs(report['device_pass'],False)
        self.assertIs(report['flash_release'],False)

    def test_15_ref_source_file_auth(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'reference.c';p.write_bytes(self.r4)
            self.assertEqual(port.verify_reference_r4(p)['status'],'EXACT_THREE_5_4_BAKASU_SUSFS_RUNTIME_PARITY_EDITS')

    def test_16_ref_source_symlink_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'ref.c';p.write_bytes(self.r4)
            sym=Path(t)/'link.c';sym.symlink_to(p)
            with self.assertRaisesRegex(port.PortError,'UNSAFE'):
                port.verify_reference_r4(sym)

    def fixture(self):
        temp=tempfile.TemporaryDirectory()
        root=Path(temp.name);work=root/'builds/5.4.274';work.mkdir(parents=True)
        src=work/'source/kernel';src.mkdir(parents=True)
        bundle=root/'bundle';bundle.mkdir()
        path=src/port.REL;path.parent.mkdir(parents=True)
        path.write_bytes(self.d726)
        components={'resukisu':{'commit':b.BAKASU_PREBLOCKER},
                    'nomount':{'commit':b.NOMOUNT_BASE},'susfs':{'commit':b.SUSFS_BASE}}
        (bundle/'targets.json').write_text(json.dumps({'components':components}))
        (work/'BAKASU-OFFICIAL-D726-R6.json').write_text(json.dumps({
            'source_matches_official_bakasu_d726_byte_for_byte':True,
            'after_sha256':port.OFFICIAL_D726_SHA,
            'source_provenance':{'upstream_commit':b.r3.BAKASU_EFFECTIVE_SOURCE}}))
        return temp,root,work,src,bundle,path

    def test_17_stage_real_d726_source_three_guards(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            with patch.object(b.r3,'verify_host',return_value={'pinned':True}):
                proof=b.stage(src,bundle,work)
            self.assertEqual(proof['R5_new_guard_count'],3)
            self.assertEqual(port.sha(path.read_bytes()),port.TARGET_SHA)
            self.assertEqual((root/'report/SUSFS_SELINUX54_R5_STAGE.json').is_file(),True)
        finally:temp.cleanup()

    def test_18_stage_wrong_susfs_pin_rejected(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            cfg=json.loads((bundle/'targets.json').read_text())
            cfg['components']['susfs']['commit']='0'*40
            (bundle/'targets.json').write_text(json.dumps(cfg))
            with self.assertRaisesRegex(b.BuildError,'TARGETS_DRIFT'):
                b.stage(src,bundle,work)
            self.assertEqual(path.read_bytes(),self.d726)
        finally:temp.cleanup()

    def test_19_stage_false_official_baka_proof_rejected(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            p=work/'BAKASU-OFFICIAL-D726-R6.json'
            cfg=json.loads(p.read_text());cfg['source_matches_official_bakasu_d726_byte_for_byte']=False
            p.write_text(json.dumps(cfg))
            with self.assertRaisesRegex(b.BuildError,'OFFICIAL_D726_PREIMAGE'):
                b.stage(src,bundle,work)
            self.assertEqual(path.read_bytes(),self.d726)
        finally:temp.cleanup()

    def test_20_stage_duplicate_rejected(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            with patch.object(b.r3,'verify_host',return_value={}):
                b.stage(src,bundle,work)
                with self.assertRaises(b.BuildError):b.stage(src,bundle,work)
        finally:temp.cleanup()

    def test_21_build_missing_object_rejected(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            path.write_bytes(port.guard_r4_text(self.r4)[0])
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(b.BuildError,'COMPILED_OBJECT_EVIDENCE_MISSING'):
                    b.verify_compiled(src,work,{'status':'EXACT_R4_PLUS_THREE_NEW_R5_SELINUX_GUARDS_STAGED',
                        'reviewed_r5_sha256':port.TARGET_SHA,'R5_new_guard_count':3},{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_22_build_reject_wrong_source(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(port.PortError,'TARGET_SOURCE_HASH'):
                    b.verify_compiled(src,work,{'status':'EXACT_R4_PLUS_THREE_NEW_R5_SELINUX_GUARDS_STAGED',
                        'reviewed_r5_sha256':port.TARGET_SHA,'R5_new_guard_count':3},{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_23_reject_r5_missing_compile_proof(self):
        temp,root,work,src,bundle,path=self.fixture()
        try:
            with self.assertRaisesRegex(b.BuildError,'BUILD_STAGE_NOT_VERIFIED'):
                b.verify_compiled(src,work,{'status':'WRONG'},{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_24_worker_injection_exact(self):
        text=('def worker():\n    if True:\n'
              '        bakasu_official_r6 = apply_official_source(src, donor, work)\n'
              '        overlay_hash = r.save_overlay(src, before, args.overlays / label, label, targets)\n'
              '        image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n'
              "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'worker.py';p.write_text(text)
            result=b.inject_r5_worker(p)
            self.assertEqual(result['status'],'R5_DISPOSABLE_R6_WORKER_INJECTED')
            self.assertIn('r5_staged = stage(',p.read_text())
            with self.assertRaisesRegex(b.BuildError,'ALREADY_INJECTED'):
                b.inject_r5_worker(p)

    def test_25_worker_double_anchor_reject(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'worker.py'
            p.write_text("result['bakasu_official_r6'] = bakasu_official_r6\n"
                "bakasu_official_r6 = apply_official_source(\n" + b.r2.OVERLAY_ANCHOR*2 +b.r2.COMPILE_ANCHOR)
            with self.assertRaisesRegex(b.BuildError,'ANCHORS_CHANGED'):
                b.inject_r5_worker(p)

    def test_26_target_wrong_digest_reject(self):
        with self.assertRaisesRegex(port.PortError,'TARGET_SOURCE_HASH'):
            port.verify_target(self.r4)

    def test_27_file_path_list_only_one(self):
        self.assertEqual(port.REL,'KernelSU/kernel/feature/selinux_hide.c')
        self.assertEqual(len({x[0] for x in port.SCOPE}),3)

    def test_28_r5_reports_no_full_bakasu_upgrade(self):
        self.assertEqual(b.BAKASU_PREBLOCKER,'5b76b884c75f729a220bb317aa4a4fc78f0e0e9c')
        self.assertNotEqual(b.BAKASU_PREBLOCKER,'b2c595ddfa64b685e5a144ad37b7c95f912fb92a')

    def compiled_fixture(self):
        temp,root,work,src,bundle,path=self.fixture()
        path.write_bytes(port.guard_r4_text(self.r4)[0])
        target=work/'build/drivers/kernelsu/feature';target.mkdir(parents=True)
        (target/'selinux_hide.o').write_bytes(b'ELF TEST OBJECT')
        (target/'.selinux_hide.o.cmd').write_text('cmd_cc_o_c := clang -flto=thin -fstack-protector-strong -c drivers/kernelsu/feature/selinux_hide.o\n')
        (work/'compile.log').write_text('  CC    drivers/kernelsu/feature/selinux_hide.o\n')
        cfg=work/'config-reports/actual-build.config';cfg.parent.mkdir(parents=True)
        cfg.write_text('\n'.join(('CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
                    'CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y','CONFIG_STACKPROTECTOR_STRONG=y'))+'\n')
        staged={'status':'EXACT_R4_PLUS_THREE_NEW_R5_SELINUX_GUARDS_STAGED',
                'reviewed_r5_sha256':port.TARGET_SHA,'R5_new_guard_count':3}
        return temp,root,work,src,staged,target,cfg

    def test_29_positive_compiler_object_fixture(self):
        temp,root,work,src,staged,target,cfg=self.compiled_fixture()
        try:
            with patch.object(b.r3,'verify_host',return_value={}):
                result=b.verify_compiled(src,work,staged,{'kernel':b.KERNEL})
            self.assertEqual(result['status'],'COMPILED_THREE_NEW_SUSFS_SELINUX_54_GUARDS')
            self.assertTrue(result['strong_stack_protector'])
        finally:temp.cleanup()

    def test_30_reject_compiler_without_thinlto(self):
        temp,root,work,src,staged,target,cfg=self.compiled_fixture()
        try:
            cmd=target/'.selinux_hide.o.cmd';cmd.write_text(cmd.read_text().replace('-flto=thin',''))
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(b.BuildError,'OBJECT_NOT_PROTECTED'):
                    b.verify_compiled(src,work,staged,{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_31_reject_compiler_without_stack_protector(self):
        temp,root,work,src,staged,target,cfg=self.compiled_fixture()
        try:
            cmd=target/'.selinux_hide.o.cmd';cmd.write_text(cmd.read_text().replace('-fstack-protector-strong','-fno-stack-protector'))
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(b.BuildError,'OBJECT_NOT_PROTECTED'):
                    b.verify_compiled(src,work,staged,{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_32_reject_unconfigured_cfi(self):
        temp,root,work,src,staged,target,cfg=self.compiled_fixture()
        try:
            cfg.write_text(cfg.read_text().replace('CONFIG_CFI_CLANG=y',''))
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(b.BuildError,'KERNEL_CONFIG_CHANGED'):
                    b.verify_compiled(src,work,staged,{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_33_reject_missing_actual_compile_trace(self):
        temp,root,work,src,staged,target,cfg=self.compiled_fixture()
        try:
            (work/'compile.log').write_text('SKIP THE OBJECT\n')
            with patch.object(b.r3,'verify_host',return_value={}):
                with self.assertRaisesRegex(b.BuildError,'NOT_COMPILED_IN_THIS_RUN'):
                    b.verify_compiled(src,work,staged,{'kernel':b.KERNEL})
        finally:temp.cleanup()

    def test_34_r2_and_r5_worker_injections_coexist(self):
        text=('def worker():\n    if True:\n'
              '        bakasu_official_r6 = apply_official_source(src, donor, work)\n'
              '        overlay_hash = r.save_overlay(src, before, args.overlays / label, label, targets)\n'
              '        image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n'
              "        result['bakasu_official_r6'] = bakasu_official_r6\n")
        with tempfile.TemporaryDirectory() as t:
            worker=Path(t)/'worker.py';worker.write_text(text)
            b.inject_r5_worker(worker)
            b.r2.inject_stack_gates(worker)
            final=worker.read_text()
            self.assertIn('r5_staged = stage(',final)
            self.assertIn('nomount_r2_source = stage_stack_protection(',final)
            self.assertEqual(final.count('image, result = compat.compile_kernel('),1)
            self.assertLess(final.index('r5_staged = stage('),final.index('nomount_r2_source = stage_stack_protection('))
            self.assertLess(final.index('nomount_r2_source = stage_stack_protection('),final.index('overlay_hash = r.save_overlay('))
            self.assertLess(final.index('r5_compiled = verify_compiled('),final.index("result['bakasu_official_r6'] ="))

if __name__=='__main__':unittest.main()
