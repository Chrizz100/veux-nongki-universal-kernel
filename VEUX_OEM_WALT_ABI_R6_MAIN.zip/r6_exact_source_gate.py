#!/usr/bin/env python3
"""VEUX 5.4.274 R6: integrate *only* proven WALT structures on disposable source snapshots.

Authenticates P11 R4 -> P3/P10 lineage, never builds a kernel or writes live repository.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

P3_TREE='7f97dbbff432d61bbf11cae03de257a21f1d3c74'
P10_TREE='04e3831b70ed3ba19a7bd59e3054b7df5418941d'
P10_PATCH_SHA='5c9603350966ec06ebb6dcdb8f9b154a3715388b759b6afc12bf41a2c41a403e'
P3_SCHED_PUBLIC_SHA='2eb0a7713b897f6eb745b1635b34aa219528796447b7953d25a9e8766aaefb39'
P10_WALT_C_SHA='03ebaf13151525db262f6d20809d69bbbcd5c4fcf378c061b04d661495c72646'
PATCH_HASH={
  'WALT_STRUCT_BRIDGE_R2.patch':'7c3c7f78ab7b25df7576c30fe51415b49a517082fda89414ef10a80e9fb9079f',
  'WALT_R3_FIX_AFTER_R2_P10.patch':'964a682721f2f0ae2ce0f5770858e6120271c8c562f730971c3459c491192f2c'
}
HEADERS=['include/linux/sched.h','include/linux/sched/sysctl.h','kernel/sched/sched.h']
CALLERS=['kernel/sched/core.c','kernel/sched/fair.c','kernel/sched/rt.c','kernel/sched/deadline.c','kernel/sched/stop_task.c','kernel/sched/idle.c']

class GateBlocked(RuntimeError):pass

def require(ok:bool,reason:str):
    if not ok: raise GateBlocked(reason)

def sha(content:bytes):return hashlib.sha256(content).hexdigest()

def regular_file(p:Path):
    require(p.is_file() and not p.is_symlink(),f'REGULAR_FILE_REQUIRED:{p}')
    return p.read_bytes()

def unq_replace(s:str,needle:str,replace:str,name:str):
    require(s.count(needle)==1,f'ANCHOR_NOT_UNIQUE:{name}:{s.count(needle)}')
    return s.replace(needle,replace,1)

def split_patch(patch:bytes):
    """Read only added lines in each actual unified-diff hunk, no reinterpretation."""
    data=patch.decode('utf-8')
    out={};file=None;hunk=None
    for line in data.splitlines(keepends=True):
        if line.startswith('--- a/'):
            file=line[6:].strip();out[file]=[];hunk=None
        elif line.startswith('@@ '):
            require(file is not None,'PATCH_HUNK_WITHOUT_PATH')
            hunk=[];out[file].append(hunk)
        elif hunk is not None and line.startswith('+') and not line.startswith('+++'):
            hunk.append(line[1:])
    return {k:[''.join(h) for h in hunks] for k,hunks in out.items()}

def anchored_patch_r2_r3(files:dict[str,bytes],r2:bytes,r3:bytes):
    """Conservative, source-hash-gated context fallback when git apply rejects offsets.

    Uses exact added hunks from pinned patches; never generates guessed kernel code.
    """
    r2h=split_patch(r2);r3h=split_patch(r3)
    require(len(r2h['include/linux/sched.h'])==2,'R2_PUBLIC_HUNK_COUNT_DRIFT')
    require(len(r2h['kernel/sched/sched.h'])==2,'R2_INTERNAL_HUNK_COUNT_DRIFT')
    require(len(r3h['kernel/sched/sched.h'])==1 and len(r3h['include/linux/sched/sysctl.h'])==1,'R3_HUNK_COUNT_DRIFT')
    result={k:v.decode('utf-8') for k,v in files.items()}
    public=result['include/linux/sched.h']
    require('struct walt_task_struct {' not in public and '\twts;' not in public,'R2_PUBLIC_ALREADY_HAS_WALT')
    require('ANDROID_KABI_RESERVE(4)' in public,'R2_PUBLIC_OEM_CONTEXT_MISSING')
    public=unq_replace(public,'\nstruct sched_rt_entity {',r2h['include/linux/sched.h'][0]+'\nstruct sched_rt_entity {','R2_PUBLIC_INSERT')
    public=unq_replace(public,'\tstruct sched_rt_entity\t\trt;\n#ifdef CONFIG_CGROUP_SCHED',
                  '\tstruct sched_rt_entity\t\trt;\n'+r2h['include/linux/sched.h'][1]+'#ifdef CONFIG_CGROUP_SCHED','R2_TASK_WTS')
    result['include/linux/sched.h']=public
    internal=result['kernel/sched/sched.h']
    require('struct walt_rq {' not in internal and '\t\twrq;' not in internal,'R2_INTERNAL_ALREADY_HAS_WALT')
    internal=unq_replace(internal,'struct rq;\nstruct cpuidle_state;\n\n',
           'struct rq;\nstruct cpuidle_state;\n\n'+r2h['kernel/sched/sched.h'][0], 'R2_INTERNAL_INSERT')
    # Place the runqueue WALT field in the OEM position, before IRQ accounting.
    internal=unq_replace(internal,'\tu64\t\t\tmax_idle_balance_cost;\n#endif\n\n#ifdef CONFIG_IRQ_TIME_ACCOUNTING',
     '\tu64\t\t\tmax_idle_balance_cost;\n#endif\n'+r2h['kernel/sched/sched.h'][1]+'\n#ifdef CONFIG_IRQ_TIME_ACCOUNTING','R2_RQ_WRQ')
    internal=unq_replace(internal,'struct rq;\nstruct cpuidle_state;\n\nstruct walt_cpu_load {',
            'struct rq;\nstruct cpuidle_state;\n'+r3h['kernel/sched/sched.h'][0]+'\nstruct walt_cpu_load {', 'R3_HELPER')
    result['kernel/sched/sched.h']=internal
    sysctl=result['include/linux/sched/sysctl.h']
    sysctl=unq_replace(sysctl,'#ifdef CONFIG_SCHED_WALT\nextern unsigned int sysctl_sched_capacity_margin_up',
                         r3h['include/linux/sched/sysctl.h'][0]+'#ifdef CONFIG_SCHED_WALT\nextern unsigned int sysctl_sched_capacity_margin_up', 'R3_SYSCTL')
    result['include/linux/sched/sysctl.h']=sysctl
    return {k:v.encode('utf-8') for k,v in result.items()}

def source_proofs(src:Path,p3_report:dict,p11_report:dict,strict:bool):
    require(p3_report.get('p3_cass_free_tree')==P3_TREE,'P3_TREE_IDENTITY_MISMATCH')
    require(p11_report.get('source_p3_tree')==P3_TREE and p11_report.get('source_p11_composed_tree')==P10_TREE,'P11_COMPOSED_TREE_MISMATCH')
    require(p11_report.get('combined_patch_sha256')==P10_PATCH_SHA and p11_report.get('source_gate')=='PASS','P10_SOURCE_GATE_MISMATCH')
    files={}
    for name in HEADERS+CALLERS+['kernel/sched/walt/walt.c']:
        files[name]=regular_file(src/name)
    if strict:
        require(sha(files['include/linux/sched.h'])==P3_SCHED_PUBLIC_SHA,'P3_PUBLIC_SCHED_HASH_MISMATCH')
        require(sha(files['kernel/sched/walt/walt.c'])==P10_WALT_C_SHA,'P10_OFFICIAL_WALT_DONOR_HASH_MISMATCH')
    check={name:files[name].decode('utf-8',errors='replace') for name in CALLERS}
    require('select_task_rq_idle(' in check['kernel/sched/idle.c'] and 'int sibling_count_hint' in check['kernel/sched/idle.c'], 'P10_IDLE_5_ARGUMENT_NOT_PRESENT')
    require('select_task_rq_fair(' in check['kernel/sched/fair.c'] and 'int sibling_count_hint' in check['kernel/sched/fair.c'], 'P10_FAIR_5_ARGUMENT_NOT_PRESENT')
    for tag in ('rt','dl','stop'):
        target={'rt':'rt','dl':'deadline','stop':'stop_task'}[tag]
        require(f'select_task_rq_{tag}(' in check[f'kernel/sched/{target}.c'] and 'int sibling_count_hint' in check[f'kernel/sched/{target}.c'],f'P10_{tag.upper()}_5_ARGUMENT_NOT_PRESENT')
    core=check['kernel/sched/core.c']
    require('try_to_wake_up(task, TASK_NORMAL, 0, head->count)' in core and 'walt_update_task_ravg(curr, rq, TASK_UPDATE' in core,'P10_WAKEUP_OR_TICK_SOURCE_MISSING')
    internal=files['kernel/sched/sched.h'].decode('utf-8')
    require('int sibling_count_hint' in internal and '(*select_task_rq)' in internal,'P10_SCHED_CLASS_CALLBACK_MISSING')
    require('struct walt_rq {' not in internal and 'struct walt_task_struct {' not in files['include/linux/sched.h'].decode(),'P10_STRUCTS_ALREADY_APPLIED')
    return files

def apply(src:Path,p3_path:Path,p11_path:Path,patchdir:Path,out:Path,strict:bool=True):
    require(not out.exists() and not out.is_symlink(),'OUTPUT_ALREADY_EXISTS')
    require(src.is_dir() and not src.is_symlink() and src.resolve()!=out.resolve(),'SOURCE_ROOT_UNSAFE')
    p3=json.loads(regular_file(p3_path));p11=json.loads(regular_file(p11_path))
    original=source_proofs(src,p3,p11,strict=strict)
    for name,pin in PATCH_HASH.items():require(sha(regular_file(patchdir/name))==pin,'PATCH_SHA_MISMATCH:'+name)
    out.mkdir(parents=True)
    stage=out/'source'
    for name in HEADERS:
        target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(original[name])
    patch_r2=patchdir/'WALT_STRUCT_BRIDGE_R2.patch';patch_r3=patchdir/'WALT_R3_FIX_AFTER_R2_P10.patch'
    def git(action:list[str]):
        return subprocess.run(['git','apply','--whitespace=nowarn',*action],cwd=stage,capture_output=True,text=True,timeout=18)
    log=[];method='GIT_APPLY'
    r2=git(['--check',str(patch_r2)]);log.append('R2_CHECK:\n'+r2.stdout+r2.stderr)
    if r2.returncode==0:
        x=git([str(patch_r2)]);require(x.returncode==0,'R2_REAL_APPLY_FAILURE:'+x.stderr)
        r3=git(['--check',str(patch_r3)]);log.append('R3_CHECK:\n'+r3.stdout+r3.stderr)
        if r3.returncode==0:
            x=git([str(patch_r3)]);require(x.returncode==0,'R3_REAL_APPLY_FAILURE:'+x.stderr)
        else:
            method='EXACT_ANCHOR_FALLBACK_AFTER_R3_DIFF'
    else:method='EXACT_ANCHOR_FALLBACK_AFTER_R2_DIFF'
    if method!='GIT_APPLY':
        # Stage is disposable. Reconstitute original byte-for-byte prior to anchored port.
        for k in HEADERS:(stage/k).write_bytes(original[k])
        require(strict, 'ANCHOR_FALLBACK_REQUIRES_EXACT_P3_PROVENANCE')
        updated=anchored_patch_r2_r3({k:original[k] for k in HEADERS},patch_r2.read_bytes(),patch_r3.read_bytes())
        for k in HEADERS:(stage/k).write_bytes(updated[k])
        log.append('FALLBACK=EXACT_PINNED_P3_WITH_UNIQUE_ANCHORS_ONLY')
    after={k:regular_file(stage/k) for k in HEADERS}
    pub=after['include/linux/sched.h'].decode()
    sh=after['kernel/sched/sched.h'].decode()
    sys=after['include/linux/sched/sysctl.h'].decode()
    for tok,t in [('struct walt_task_struct {',pub),('struct walt_rq {',sh),('struct walt_task_struct\t\twts;',pub),('struct walt_rq\t\twrq;',sh),('is_min_capacity_cpu(int cpu)',sh),('MAX_MARGIN_LEVELS (MAX_CLUSTERS - 1)',sys)]:
        require(tok in t,'R6_MISSING_EXPECTED_WALT_TOKEN:'+tok)
    require(pub.count('struct walt_task_struct {')==1 and sh.count('struct walt_rq {')==1 and sys.count('#define MAX_MARGIN_LEVELS')==1,'R6_DUPLICATE_WALT_DEFINITION')
    report={
      'status':'WALT_R6_REAL_P3_COMPATIBILITY_PRECOMPILE_STAGED' if strict else 'WALT_R6_DIAGNOSTIC_FIXTURE_ONLY',
      'strict_real_source':strict,'method':method,
      'p3_tree':p3['p3_cass_free_tree'],'p10_composed_tree':p11['source_p11_composed_tree'],
      'source_after_sha256':{k:sha(v) for k,v in after.items()},
      'source_before_sha256':{k:sha(original[k]) for k in HEADERS},
      'p10_callers_verified':CALLERS,
      'r6_modified_files':HEADERS,
      'final_kernel_built':False,'walt_on_compile_proven':False,'vendor_crc_fixed':False,
      'flash_allowed':False,'brene_changed':False,
      'pending':['full compiler checks for WALT tick/cpufreq','OEM stock WALT ABI parity','Module.symvers vendor CRC comparison']
    }
    (out/'R6_SOURCE_GATE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    (out/'R6_PATCH_APPLY.log').write_text('\n'.join(log)+'\n')
    print('WALT_R6_P3_P10_PINNED_SOURCE_GATE=PASS; FILES=3; BUILD=NO; FLASH=NO; method='+method)
    return report

def main():
    pa=argparse.ArgumentParser()
    pa.add_argument('--kernel',type=Path,required=True)
    pa.add_argument('--p3',type=Path,required=True)
    pa.add_argument('--p11',type=Path,required=True)
    pa.add_argument('--patches',type=Path,required=True)
    pa.add_argument('--output',type=Path,required=True)
    args=pa.parse_args()
    try:apply(args.kernel,args.p3,args.p11,args.patches,args.output,strict=True)
    except (GateBlocked,ValueError,OSError,subprocess.TimeoutExpired) as e:
        print('R6_SOURCE_NOT_APPROVED:'+str(e),file=__import__('sys').stderr)
        raise SystemExit(2)

if __name__=='__main__':main()
