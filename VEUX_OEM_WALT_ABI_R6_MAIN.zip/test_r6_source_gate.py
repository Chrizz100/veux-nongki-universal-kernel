"""Offline fixture/negative tests; they are NOT a real P3 GitHub checkout."""
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT=Path(__file__).resolve().parent.parent
BASE=Path('/mnt/data')
spec=importlib.util.spec_from_file_location('r6gate',ROOT/'src/r6_exact_source_gate.py')
r6=importlib.util.module_from_spec(spec);spec.loader.exec_module(r6)
P11=BASE/'VEUX_P11_R4_38630203122_ORIGINAL_EVIDENCE.zip'
R5=BASE/'VEUX_OEM_WALT_ABI_R5_SOURCE_CALLERS_NO_FLASH.zip'


def gitapply(stage,patch):
    p=subprocess.run(['git','apply','--whitespace=nowarn',str(patch)],cwd=stage,capture_output=True,text=True)
    if p.returncode:raise AssertionError(p.stderr)


def fixtures(root:Path):
    """R2 diagnostic headers + original P10 selector evidence; clearly *not* exact P3."""
    kernel=root/'kernel';p3=root/'P3_RESULT.json';p11=root/'P11_PREP_REPORT.json'
    for s in r6.HEADERS+r6.CALLERS+['kernel/sched/walt/walt.c']:
        dst=kernel/s;dst.parent.mkdir(parents=True,exist_ok=True)
        if s=='include/linux/sched.h':data=(BASE/'VEUX_OEM_WALT_ABI_R2_SOURCE_BRIDGE/references/base/include/linux/sched.h').read_bytes()
        elif s=='kernel/sched/sched.h':data=(BASE/'VEUX_OEM_WALT_ABI_R2_SOURCE_BRIDGE/references/base/kernel/sched/sched.h').read_bytes()
        elif s=='include/linux/sched/sysctl.h':data=(BASE/'VEUX_OEM_WALT_ABI_R3_SOURCE_BRIDGE/references/p3/include/linux/sched/sysctl.h').read_bytes()
        else:data=b'// R6 OFFLINE NEGATIVE FIXTURE\n'
        dst.write_bytes(data)
    # Simulate P10's 5-arg type and prepared sysctl file using authentic pinned patch hunks.
    gitapply(kernel,BASE/'VEUX_OEM_WALT_ABI_R4_SCHED_CLASS_FIVE_ARGS.patch')
    with zipfile.ZipFile(R5) as z:
        original=z.read('references/P10_COMBINED_ORIGINAL.patch').decode()
        st=original.index('diff --git a/include/linux/sched/sysctl.h b/')
        ed=original.find('\ndiff --git ',st+1)
        (root/'p10_sysctl.patch').write_text(original[st:ed].rstrip()+'\n')
    gitapply(kernel,root/'p10_sysctl.patch')
    # Fixture caller text intentionally reduced; no kernel compile claimed.
    for t in ['rt','dl','stop','idle']:
        path={'rt':'rt.c','dl':'deadline.c','stop':'stop_task.c','idle':'idle.c'}[t]
        (kernel/'kernel/sched'/path).write_text(f'select_task_rq_{t}(struct task_struct *p, int cpu, int sd, int flags, int sibling_count_hint) {{return cpu;}}\n')
    with zipfile.ZipFile(R5) as z:
        (kernel/'kernel/sched/core.c').write_bytes(z.read('stage/source/kernel/sched/core.c')+b'\n/* fixture: walt_update_task_ravg(curr, rq, TASK_UPDATE */\n')
        (kernel/'kernel/sched/fair.c').write_bytes(z.read('stage/source/kernel/sched/fair.c'))
    (kernel/'kernel/sched/walt/walt.c').parent.mkdir(parents=True,exist_ok=True)
    (kernel/'kernel/sched/walt/walt.c').write_bytes((BASE/'VEUX_OEM_WALT_ABI_R2_SOURCE_BRIDGE/references/xiaomi-walt/walt.c').read_bytes())
    with zipfile.ZipFile(P11) as z:
        p3.write_bytes(z.read('VEUX_274_P3_OUTPUT/P3_RESULT.json'))
        p11.write_bytes(z.read('VEUX_274_P11_PREP/P11_PREP_REPORT.json'))
    return kernel,p3,p11

class R6Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='veux-walt-r6-fixture-');self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name);self.kernel,self.p3,self.p11=fixtures(self.root)
        self.patchdir=ROOT/'src'

    def stage(self):return r6.apply(self.kernel,self.p3,self.p11,self.patchdir,self.root/'out',strict=False)

    def test_01_repo_source_pin_values(self):
        self.assertEqual(r6.P3_TREE,'7f97dbbff432d61bbf11cae03de257a21f1d3c74')
        self.assertEqual(r6.P10_TREE,'04e3831b70ed3ba19a7bd59e3054b7df5418941d')
    def test_02_source_pins_valid_sha(self):
        for name,pin in r6.PATCH_HASH.items():self.assertEqual(r6.sha((self.patchdir/name).read_bytes()),pin)
    def test_03_script_stages_headers(self):
        r=self.stage();self.assertEqual(len(r['r6_modified_files']),3)
        self.assertFalse(r['final_kernel_built'])
    def test_04_script_does_not_change_kernel(self):
        before={p:(self.kernel/p).read_bytes() for p in r6.HEADERS}
        self.stage()
        self.assertEqual(before,{p:(self.kernel/p).read_bytes() for p in r6.HEADERS})
    def test_05_repeated_run_rejects_existing_output(self):
        self.stage()
        with self.assertRaisesRegex(r6.GateBlocked,'OUTPUT_ALREADY_EXISTS'):self.stage()
    def test_06_invalid_p3_tree_rejects(self):
        q=json.loads(self.p3.read_text());q['p3_cass_free_tree']='0'*40;self.p3.write_text(json.dumps(q))
        with self.assertRaisesRegex(r6.GateBlocked,'P3_TREE_IDENTITY_MISMATCH'):self.stage()
    def test_07_invalid_p10_proof_rejects(self):
        q=json.loads(self.p11.read_text());q['combined_patch_sha256']='f'*64;self.p11.write_text(json.dumps(q))
        with self.assertRaisesRegex(r6.GateBlocked,'P10_SOURCE_GATE_MISMATCH'):self.stage()
    def test_08_missing_idle_callback_rejects(self):
        (self.kernel/'kernel/sched/idle.c').write_text('int foo(void){return 0;}')
        with self.assertRaisesRegex(r6.GateBlocked,'P10_IDLE_5_ARGUMENT_NOT_PRESENT'):self.stage()
    def test_09_missing_tick_rejects(self):
        p=self.kernel/'kernel/sched/core.c';p.write_bytes(p.read_bytes().replace(b'walt_update_task_ravg(curr, rq, TASK_UPDATE',b'noop_walt_ravg(curr, rq, TASK_UPDATE'))
        with self.assertRaisesRegex(r6.GateBlocked,'P10_WAKEUP_OR_TICK_SOURCE_MISSING'):self.stage()
    def test_10_double_definitions_reject(self):
        p=self.kernel/'include/linux/sched.h';p.write_bytes(p.read_bytes()+b'\nstruct walt_task_struct {int dummy;};\n')
        with self.assertRaisesRegex(r6.GateBlocked,'P10_STRUCTS_ALREADY_APPLIED'):self.stage()
    def test_11_bad_patch_hash_reject(self):
        dst=self.root/'badpatch';shutil.copytree(self.patchdir,dst)
        (dst/'WALT_STRUCT_BRIDGE_R2.patch').write_text('fake')
        with self.assertRaisesRegex(r6.GateBlocked,'PATCH_SHA_MISMATCH'):r6.apply(self.kernel,self.p3,self.p11,dst,self.root/'out',strict=False)
    def test_12_strict_rejects_not_exact_p3(self):
        with self.assertRaisesRegex(r6.GateBlocked,'P3_PUBLIC_SCHED_HASH_MISMATCH'):
            r6.apply(self.kernel,self.p3,self.p11,self.patchdir,self.root/'out',strict=True)
    def test_13_symlink_input_rejected(self):
        orig=self.kernel/'kernel/sched/core.c';q=orig.with_suffix('.bak');orig.rename(q);orig.symlink_to(q)
        with self.assertRaisesRegex(r6.GateBlocked,'REGULAR_FILE_REQUIRED'):self.stage()
    def test_14_report_no_flash(self):
        rep=self.stage();self.assertFalse(rep['vendor_crc_fixed']);self.assertFalse(rep['flash_allowed']);self.assertFalse(rep['brene_changed'])
    def test_15_sysctl_has_macro(self):
        self.stage();s=(self.root/'out/source/include/linux/sched/sysctl.h').read_text();self.assertIn('MAX_MARGIN_LEVELS',s)
    def test_16_task_and_rq(self):
        self.stage();f=self.root/'out/source';self.assertIn('struct walt_task_struct', (f/'include/linux/sched.h').read_text());self.assertIn('struct walt_rq', (f/'kernel/sched/sched.h').read_text())
    def test_17_patch_hunks_extracted(self):
        a=r6.split_patch((self.patchdir/'WALT_STRUCT_BRIDGE_R2.patch').read_bytes());self.assertEqual(len(a['include/linux/sched.h']),2)
    def test_18_real_p11_artifact_sha(self):
        self.assertEqual(r6.sha(P11.read_bytes()),'97e590a4ea1981b94726a7fb37e58dc734da606542b38764a2e8f555096bdc79')
    def test_19_anchored_method_bytes_on_trusted_offline_fixture(self):
        before={k:(self.kernel/k).read_bytes() for k in r6.HEADERS}
        patched=r6.anchored_patch_r2_r3(before,
            (self.patchdir/'WALT_STRUCT_BRIDGE_R2.patch').read_bytes(),
            (self.patchdir/'WALT_R3_FIX_AFTER_R2_P10.patch').read_bytes())
        self.stage()
        for k in r6.HEADERS:self.assertEqual(patched[k],(self.root/'out/source'/k).read_bytes(),k)
    def test_20_anchored_duplicate_and_anchor_drift_block(self):
        before={k:(self.kernel/k).read_bytes() for k in r6.HEADERS}
        before['kernel/sched/sched.h']=before['kernel/sched/sched.h'].replace(b'struct cpuidle_state;',b'struct alt_state;')
        with self.assertRaisesRegex(r6.GateBlocked,'ANCHOR_NOT_UNIQUE'):
            r6.anchored_patch_r2_r3(before,(self.patchdir/'WALT_STRUCT_BRIDGE_R2.patch').read_bytes(),(self.patchdir/'WALT_R3_FIX_AFTER_R2_P10.patch').read_bytes())

if __name__=='__main__':unittest.main()
