VEUX R5S2 – BakaSU 522 Linux-5.4-Quellport / Experimenteller Build – NO FLASH
==========================================================================
1. Diese VEUX_R5S2_BAKASU522_MAIN.zip unverändert ins Repository-Hauptverzeichnis hochladen.
2. Separate Workflow-YAML nach .github/workflows/ übertragen.
3. Workflow "VEUX R5S2 BakaSU 522 non-GKI 5.4 Port - NO FLASH" manuell starten.
4. R5S1 und R6 unverändert lassen. Auf den vollständigen GitHub-Lauf mit Audit warten.

Der Runner beschafft den exakten offiziellen BakaSU-Commit und führt eine
fail-closed-Drei-Wege-Portierung nur in einer temporären Quellkopie durch.
Die KSU-Version wird nicht gefälscht. SUSFS 5.10-Hostpatches werden NICHT
ungeprüft auf VEUX 5.4 übertragen. Keine Flashfreigabe; Gerätetest fehlt.

enable_build=false prüft die originalen Donor-/R5S1-Quellen und Archive,
portiert aber die 20 Dateien noch nicht in eine reale Kernelquelle.
Der vollständige Portierungsversuch mit Compile erfordert enable_build=true.
