"""Fail-closed BakaSU 522 Linux 5.4 port unit/negative tests."""
from __future__ import annotations
import tempfile,subprocess,hashlib,importlib,sys,json
from pathlib import Path
from unittest import TestCase,main
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'common/scripts'))
import veux_bakasu_522_r5s2 as x

def run(*args):
    z=subprocess.run(args,check=True,capture_output=True,text=True)
    return z.stdout.strip()
class GuardTests(TestCase):
    def test_01_actual_commit_hard_pin(self):self.assertEqual(len(x.TARGET),40)
    def test_02_actual_parent_hard_pin(self):self.assertEqual(len(x.BASE),40)
    def test_03_exact_20_files(self):self.assertEqual(len(x.PINS),20)
    def test_04_three_new_code_generator_files(self):self.assertEqual(sum(p is None for p,n in x.PINS.values()),3)
    def test_05_old_hashes_are_sha1(self):self.assertTrue(all(a is None or len(a)==40 for a,_ in x.PINS.values()))
    def test_06_new_hashes_are_sha1(self):self.assertTrue(all(len(b)==40 for a,b in x.PINS.values()))
    def test_07_paths_inside_kernel(self):self.assertTrue(all(not Path(k).is_absolute() and '..' not in Path(k).parts for k in x.PINS))
    def test_08_necessary_core_paths(self):
        for p in ('Kbuild','feature/sucompat.c','hook/arm64/syscall_hook.c','include/arch.h','tools/code_generation/syscall_no/syscall_no.c'):
            self.assertIn(p,x.PINS)
    def test_09_no_selinux_override(self):self.assertNotIn('feature/selinux_hide.c',x.PINS)
    def test_10_no_susfs_override(self):self.assertFalse(any('susfs' in p for p in x.PINS))
    def test_11_git_blob_known(self):self.assertEqual(x.blob(b'hello'),'b6fc4c620b67d95f953a5c1c1230aaab5db5a1b0')
    def test_12_empty_blob(self):self.assertEqual(x.blob(b''),'e69de29bb2d1d6434b8b29ae775ad8c2e48c5391')
    def test_13_normal_sha256(self):self.assertEqual(x.sha(b'abc'),hashlib.sha256(b'abc').hexdigest())
    def test_14_equal_preimage(self):
        with tempfile.TemporaryDirectory() as t:
            a=b'left\nright\n';b=b'left\nNEW\n';n,mode=x.three_way(a,a,b,Path(t))
            self.assertEqual((n,mode),(b,'EXACT_PREIMAGE'))
    def test_15_already_integrated_is_blocked(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaisesRegex(x.PortBlocked,'ALREADY_PRESENT'):
                x.three_way(b'new',b'old',b'new',Path(t))
    def test_16_binary_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            with self.assertRaisesRegex(x.PortBlocked,'BINARY_SOURCE'):
                x.three_way(b'a\x00',b'a',b'b',Path(t))
    def test_17_nonoverlap_threeway(self):
        with tempfile.TemporaryDirectory() as t:
            a=''.join(f'line{i}\n' for i in range(25))
            b=a.replace('line3\n','CHANGED_BY_UPSTREAM\n')
            c=a.replace('line20\n','CHANGED_LOCALLY\n')
            merged,kind=x.three_way(c.encode(),a.encode(),b.encode(),Path(t))
            self.assertEqual(kind,'CLEAN_THREE_WAY')
            self.assertIn(b'CHANGED_BY_UPSTREAM',merged)
            self.assertIn(b'CHANGED_LOCALLY',merged)
    def test_18_conflicting_threeway_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            a=''.join(f'line{i}\n' for i in range(25))
            b=a.replace('line3\n','UPSTREAM\n')
            c=a.replace('line3\n','LOCAL\n')
            with self.assertRaisesRegex(x.PortBlocked,'MERGE_CONFLICT'):
                x.three_way(c.encode(),a.encode(),b.encode(),Path(t))

class RepoCases(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.donor=self.root/'donor';self.donor.mkdir()
        run('git','-C',str(self.donor),'init','-q')
        run('git','-C',str(self.donor),'config','user.email','test@example.invalid')
        run('git','-C',str(self.donor),'config','user.name','Isolated Test')
        k=self.donor/'kernel';k.mkdir()
        self.before=(''.join(f'line{i}\n' for i in range(25))).encode()
        self.after=self.before.replace(b'line3\n',b'OFFICIAL\n')
        (k/'Kbuild').write_bytes(self.before)
        run('git','-C',str(self.donor),'add','.')
        run('git','-C',str(self.donor),'commit','-q','-m','base')
        self.parent=run('git','-C',str(self.donor),'rev-parse','HEAD')
        (k/'Kbuild').write_bytes(self.after)
        run('git','-C',str(self.donor),'add','.')
        run('git','-C',str(self.donor),'commit','-q','-m','target')
        self.target=run('git','-C',str(self.donor),'rev-parse','HEAD')
        self.pins={'Kbuild':(x.blob(self.before),x.blob(self.after))}
        self.pa=patch.multiple(x,BASE=self.parent,TARGET=self.target,PINS=self.pins,EXPECTED_KERNEL_DELTA=1)
        self.pa.start();self.addCleanup(self.pa.stop)
        self.src=self.root/'src';self.src.mkdir()
        k=self.src/'KernelSU/kernel';k.mkdir(parents=True)
        (k/'Kbuild').write_bytes(self.before)
        (k/'feature').mkdir();(k/'feature/selinux_hide.c').write_text('R5S1_TEST_PLACEHOLDER\n')
        (self.src/'drivers').mkdir()
        (self.src/'drivers/kernelsu').symlink_to('../KernelSU/kernel')
        for s in ('security/selinux/hooks.c','security/selinux/selinuxfs.c','fs/susfs.c','include/linux/susfs.h','include/linux/susfs_def.h'):
            p=self.src/s;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('ALREADY_REVIEWED\n')
    def test_19_exact_donor_provenance(self):self.assertTrue(x.verify_donor(self.donor)['before_and_after_git_blobs_authenticated'])
    def test_20_wrong_commit_rejected(self):
        with patch.object(x,'TARGET','0'*40):
            with self.assertRaisesRegex(x.PortBlocked,'WRONG_COMMIT'):x.verify_donor(self.donor)
    def test_21_wrong_parent_rejected(self):
        with patch.object(x,'BASE','0'*40):
            with self.assertRaisesRegex(x.PortBlocked,'WRONG_PARENT'):x.verify_donor(self.donor)
    def test_22_unexpected_kernel_file_rejected(self):
        (self.donor/'kernel/extra').write_text('unexpected')
        run('git','-C',str(self.donor),'add','.')
        run('git','-C',str(self.donor),'commit','-q','-m','more')
        with patch.object(x,'TARGET',run('git','-C',str(self.donor),'rev-parse','HEAD')):
            with self.assertRaisesRegex(x.PortBlocked,'WRONG_PARENT|UNREVIEWED'):x.verify_donor(self.donor)
    def test_23_corrupted_expected_blob(self):
        with patch.object(x,'PINS',{'Kbuild':('0'*40,self.pins['Kbuild'][1])}):
            with self.assertRaisesRegex(x.PortBlocked,'BEFORE_BLOB_DRIFT'):x.verify_donor(self.donor)
    def test_24_complete_port_in_memory(self):
        (self.src/'KernelSU/kernel/Kbuild').write_bytes(self.before+b'')
        rep,files=x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
        self.assertEqual(rep['kernel_paths'],1)
        self.assertEqual(rep['changed_files'][0]['mode'],'EXACT_PREIMAGE')
        self.assertEqual(files['Kbuild'],self.after)
        self.assertEqual((self.src/'KernelSU/kernel/Kbuild').read_bytes(),self.before)
    def test_25_nonoverlapping_local_change_preserved(self):
        local=self.before.replace(b'line20\n',b'LOCAL\n')
        (self.src/'KernelSU/kernel/Kbuild').write_bytes(local)
        report,files=x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
        self.assertIn(b'LOCAL\n',files['Kbuild']);self.assertIn(b'OFFICIAL\n',files['Kbuild'])
        self.assertEqual(report['changed_files'][0]['mode'],'CLEAN_THREE_WAY')
    def test_26_conflict_does_not_write(self):
        local=self.before.replace(b'line3\n',b'LOCAL\n')
        (self.src/'KernelSU/kernel/Kbuild').write_bytes(local)
        with self.assertRaisesRegex(x.PortBlocked,'MERGE_CONFLICT'):
            x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
        self.assertEqual((self.src/'KernelSU/kernel/Kbuild').read_bytes(),local)
    def test_27_dirty_upstream_refused(self):
        (self.donor/'kernel/Kbuild').write_text('dirty')
        with self.assertRaisesRegex(x.PortBlocked,'DONOR_DIRTY'):x.verify_donor(self.donor)
    def test_28_broken_mirror_refused(self):
        (self.src/'drivers/kernelsu').unlink();(self.src/'drivers/kernelsu').mkdir()
        with self.assertRaisesRegex(x.PortBlocked,'BUILDPATH'):x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
    def test_29_symlink_file_refused(self):
        k=self.src/'KernelSU/kernel/Kbuild';k.unlink();k.symlink_to(self.donor/'kernel/Kbuild')
        with self.assertRaisesRegex(x.PortBlocked,'UNSAFE_KERNELSU_TARGET'):x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
    def test_30_core_source_unchanged(self):
        rep,files=x.port_in_memory(self.src,self.donor,self.root,pin_source=False)
        self.assertTrue(rep['native_selinux_susfs_untouched'])
    def test_31_authentic_selinux_mandatory(self):
        with self.assertRaisesRegex(x.PortBlocked,'FROZEN_R5S1_SELINUX_REPAIRS_LOST'):
            x.port_in_memory(self.src,self.donor,self.root,pin_source=True)
    def test_32_new_commit_522_only_update_already_present(self):
        (self.src/'KernelSU/kernel/Kbuild').write_bytes(self.after)
        with self.assertRaisesRegex(x.PortBlocked,'ALREADY_PRESENT'):
            x.port_in_memory(self.src,self.donor,self.root,pin_source=False)

# Imported by unittest discovery; these checks also verify the actual proven
# R5S1 worker injector remains composable with the new R5S2 wrapper.
class WorkerContract(TestCase):
    def setUp(self):
        self.t=tempfile.TemporaryDirectory();self.addCleanup(self.t.cleanup)
        self.root=Path(self.t.name)
        self.worker=self.root/'worker.py'
        self.ref=self.root/'R5S1.c';self.ref.write_text('synthetic-good-referenced-file\n')
        self.donor=self.root/'donor';self.donor.mkdir()
        import veux_sync_susfs_r1_build as base
        self.base=base
        self.worker.write_text('from pathlib import Path\ndef worker(args):\n        result[\'bakasu_official_r6\'] = bakasu_official_r6\n'
            +base.r2.OVERLAY_ANCHOR+base.r2.COMPILE_ANCHOR)
    def test_33_r5s1_injection_preserved(self):
        row=x.inject_worker_inner(self.base.inject_worker,self.worker,self.ref,self.donor)
        code=self.worker.read_text()
        self.assertIn('compat_522_staged = stage_522(',code)
        self.assertIn('sync_staged = stage(',code)
        self.assertEqual(code.count('stage_522('),1)
        self.assertEqual(code.count('verify_522_compiled('),1)
        self.assertEqual(row['status'],'R5S2_DISPOSABLE_WORKER_INJECTED')
    def test_34_ast_parses_after_injection(self):
        import ast
        x.inject_worker_inner(self.base.inject_worker,self.worker,self.ref,self.donor)
        ast.parse(self.worker.read_text())
    def test_35_duplicate_injection_rejected(self):
        x.inject_worker_inner(self.base.inject_worker,self.worker,self.ref,self.donor)
        with self.assertRaises(Exception):
            x.inject_worker_inner(self.base.inject_worker,self.worker,self.ref,self.donor)
    def test_36_source_only_cannot_alter_repo_worker(self):
        before=self.worker.read_bytes()
        x.inject_worker_inner(self.base.inject_worker,self.worker,self.ref,self.donor)
        self.assertNotEqual(before,self.worker.read_bytes())
        self.assertTrue(self.worker.is_relative_to(self.root))


class R5S2WorkerTests(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.worker=self.root/'runner.py'
        self.donor=self.root/'donor';self.donor.mkdir()
        # This independently tests the exact wrapper around the already green
        # R5S1 disposable-source injection, not only individual substrings.
        import veux_sync_susfs_r1_build as previous
        self.previous=previous
        self.worker.write_text('from pathlib import Path\n'+
            "def worker(args):\n        result['bakasu_official_r6'] = bakasu_official_r6\n"+
            previous.r2.OVERLAY_ANCHOR+previous.r2.COMPILE_ANCHOR)
        import zipfile
        with zipfile.ZipFile(Path(__file__).resolve().parents[1]/
                'baseline/VEUX_SYNC_SUSFS_R5S1_MAIN.zip') as z:
            raw=z.read('common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c')
        self.reference=self.root/'reference.c';self.reference.write_bytes(raw)
        self.assertEqual(x.sha(raw),x.R5S1_SHA)

    def test_33_real_r5s1_worker_wrap_keeps_all_anchors(self):
        out=x.inject_worker_inner(self.previous.inject_worker,self.worker,self.reference,self.donor)
        body=self.worker.read_text()
        self.assertEqual(out['status'],'R5S2_DISPOSABLE_WORKER_INJECTED')
        self.assertEqual(body.count('compat_522_staged = stage_522('),1)
        self.assertEqual(body.count('result["bakasu_522_r5s2"]'),1)
        self.assertLess(body.index('sync_staged = stage('),body.index('compat_522_staged = stage_522('))
        self.assertLess(body.index('compat_522_staged = stage_522('),body.index('sync_compiled = verify_compiled('))
        self.assertLess(body.index("result['bakasu_sync_f308_d726_r5']"),body.index('result["bakasu_522_r5s2"]'))
        __import__('ast').parse(body)

    def test_34_double_worker_injection_is_blocked(self):
        x.inject_worker_inner(self.previous.inject_worker,self.worker,self.reference,self.donor)
        before=self.worker.read_bytes()
        with self.assertRaises(x.PortBlocked):
            x.inject_worker_inner(self.previous.inject_worker,self.worker,self.reference,self.donor)
        self.assertEqual(self.worker.read_bytes(),before)

    def test_35_tampered_original_worker_anchor_is_blocked(self):
        self.worker.write_text(self.worker.read_text().replace('bakasu_official_r6','bakasu_fake'))
        with self.assertRaises(x.PortBlocked):
            x.inject_worker_inner(self.previous.inject_worker,self.worker,self.reference,self.donor)

class CompiledProofTests(TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name)
        self.work=self.root/'builds/5.4.274';self.work.mkdir(parents=True)
        self.src=self.work/'source/kernel';self.src.mkdir(parents=True)
        self.kroot=self.src/'KernelSU/kernel';self.kroot.mkdir(parents=True)
        (self.kroot/'feature').mkdir()
        import zipfile
        with zipfile.ZipFile(Path(__file__).resolve().parents[1]/
                'baseline/VEUX_SYNC_SUSFS_R5S1_MAIN.zip') as z:
            raw=z.read('common/sync/VEUX_SYNC_F308_D726_R5_HOOK.c')
        (self.kroot/'feature/selinux_hide.c').write_bytes(raw)
        (self.kroot/'Kbuild').write_text('compiled kernel Kbuild fixture\n')
        (self.root/'report').mkdir()
        cp=self.work/'config-reports/actual-build.config';cp.parent.mkdir(parents=True)
        cp.write_text('CONFIG_COMPAT=y\n# CONFIG_KSU_TRACEPOINT_HOOK is not set\nCONFIG_CFI_CLANG=y\nCONFIG_THINLTO=y\nCONFIG_STACKPROTECTOR_STRONG=y\n')
        obj=self.work/'build/drivers/kernelsu/feature/sucompat.o';obj.parent.mkdir(parents=True)
        obj.write_bytes(b'ELF_ABI_TEST_FIXTURE_NONEMPTY')
        cmd=obj.parent/'.sucompat.o.cmd'
        cmd.write_text('cmd_drivers/kernelsu/feature/sucompat.o := clang -fstack-protector-strong -flto=thin\n')
        hdr=self.work/'build/drivers/kernelsu/compat/syscall_no.h';hdr.parent.mkdir(parents=True)
        hdr.write_text('#ifndef KSU_NR_COMPAT_H\n#define ksu_get_syscall_no(name) __NR_##name\n#define ksu_get_compat_syscall_no(name) __NR_compat32_##name\n#define __NR_compat32_execveat 387\n')
        self.report={'status':'PINNED_522_5_4_PORT_STAGED_IN_MEMORY',
            'changed_files':[{'path':'kernel/Kbuild',
                              'after_sha256':x.sha((self.kroot/'Kbuild').read_bytes())}]}
        self.result={'kernel':'5.4.274'}

    def test_36_compile_proof_positive_fixture(self):
        row=x.verify_compiled(self.src,self.work,self.report,self.result)
        self.assertEqual(row['status'],'EXPERIMENTAL_522_5_4_COMPILED_IN_R5S1_LINEAGE')
        self.assertFalse(row['flash_release'])
    def test_37_missing_compiled_sucompat_object_refused(self):
        (self.work/'build/drivers/kernelsu/feature/sucompat.o').unlink()
        with self.assertRaisesRegex(x.PortBlocked,'SUCOMPAT_NOT_COMPILED'):
            x.verify_compiled(self.src,self.work,self.report,self.result)
    def test_38_disabled_compat_refused(self):
        c=self.work/'config-reports/actual-build.config';c.write_text(c.read_text().replace('CONFIG_COMPAT=y','CONFIG_COMPAT=n'))
        with self.assertRaisesRegex(x.PortBlocked,'COMPAT_DISABLED'):
            x.verify_compiled(self.src,self.work,self.report,self.result)
    def test_39_weak_stack_protector_refused(self):
        c=self.work/'build/drivers/kernelsu/feature/.sucompat.o.cmd'
        c.write_text(c.read_text().replace('-fstack-protector-strong','-fno-stack-protector'))
        with self.assertRaisesRegex(x.PortBlocked,'COMPILER_FLAGS_INSECURE'):
            x.verify_compiled(self.src,self.work,self.report,self.result)
    def test_40_bad_generated_syscall_header_refused(self):
        h=self.work/'build/drivers/kernelsu/compat/syscall_no.h';h.write_text('#define INVALID\n')
        with self.assertRaisesRegex(x.PortBlocked,'GENERATED_COMPAT_HEADER_INCOMPLETE'):
            x.verify_compiled(self.src,self.work,self.report,self.result)

if __name__=='__main__':main()
