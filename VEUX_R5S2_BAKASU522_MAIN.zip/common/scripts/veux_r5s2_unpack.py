#!/usr/bin/env python3
"""VEUX R5S2 cryptographically bound bootstrap; never writes source checkout."""
from __future__ import annotations
import argparse,hashlib,json,stat,subprocess,sys,zipfile
from pathlib import Path,PurePosixPath
R5S1_SHA='038285dfa9a1ebc7f3c6b175f114e01f1542e976ada8139274857ae3c462288a'
R5S1_MEMBER='baseline/VEUX_SYNC_SUSFS_R5S1_MAIN.zip'
FILES={
 'README_START_HIER_DE.txt',R5S1_MEMBER,
 'common/scripts/veux_bakasu_522_r5s2.py','common/scripts/veux_r5s2_unpack.py',
 'Tests/test_veux_r5s2_522.py','docs/R5S2_SCOPE_UPDATE_2026-10-18_DE.md',
 'MANIFEST_SHA256.json',
}
class Blocked(RuntimeError):pass
def must(x,s):
 if not x:raise Blocked(s)
def sha(b):return hashlib.sha256(b).hexdigest()
def safe_unpack(main:Path,out:Path):
 main=main.resolve(strict=True)
 must(main.is_file() and not main.is_symlink(),'MAIN_UNSAFE')
 out=out.resolve()
 must(not out.exists() and out.parent.is_dir(),'DEST_ALREADY_PRESENT')
 with zipfile.ZipFile(main) as z:
  infos=z.infolist();must(len(infos)==len(FILES) and {x.filename for x in infos}==FILES,'OUTER_ZIP_SCOPE_DRIFT')
  must(z.testzip() is None,'ZIP_CRC_FAIL')
  m=json.loads(z.read('MANIFEST_SHA256.json'))
  must(m.get('schema')==1 and m.get('flash_approved') is False and m.get('522_kernel_integration_stage')=='CANDIDATE_NOT_BUILT',
      'FALSE_RELEASE_CLAIM_OR_WRONG_MANIFEST')
  must(set(m['files'])==FILES-{'MANIFEST_SHA256.json'},'MANIFEST_FILE_SET_MISMATCH')
  data={}
  for f in infos:
   path=PurePosixPath(f.filename);mode=f.external_attr>>16
   must(not path.is_absolute() and '..' not in path.parts and '\\' not in f.filename and stat.S_ISREG(mode),
        'UNSAFE_ZIP_FILE_'+f.filename)
   b=z.read(f.filename)
   if f.filename!='MANIFEST_SHA256.json':must(sha(b)==m['files'][f.filename],'ZIP_MEMBER_HASH_FAIL_'+f.filename)
   data[f.filename]=b
 must(sha(data[R5S1_MEMBER])==R5S1_SHA,'R5S1_GREEN_REFERENCE_DRIFT')
 with zipfile.ZipFile(__import__('io').BytesIO(data[R5S1_MEMBER])) as z:
  must(z.testzip() is None,'NESTED_R5S1_CORRUPT')
  m=json.loads(z.read('MANIFEST_SHA256.json'))
  bootstrap='common/scripts/veux_sync_susfs_r1_unpack.py'
  code=z.read(bootstrap)
  must(m.get('schema')==6 and sha(code)==m['files'][bootstrap], 'UNAUTHENTICATED_R5S1_UNPACKER')
 out.mkdir()
 for name,b in data.items():
  dest=out.joinpath(*PurePosixPath(name).parts)
  dest.parent.mkdir(parents=True,exist_ok=True)
  must(not dest.exists(),'ZIP_DEST_COLLISION')
  dest.write_bytes(b)
 boot=out/'r5s1-unpack-verified.py'
 boot.write_bytes(code)
 nested=out/'verified-r5s1'
 p=subprocess.run([sys.executable,str(boot),'--main',str(out/R5S1_MEMBER),'--work',str(nested)],
                  capture_output=True,text=True,timeout=100)
 must(p.returncode==0,'NESTED_R5S1_NOT_VERIFIED:'+p.stderr[-750:])
 res=json.loads((nested/'ZIP_VALIDATION.json').read_text())
 must(res.get('status')=='R5S1_EXACT_F308_AND_D726_PLUS_R5_NESTED_ARCHIVES_PASS',
      'R5S1_BUILD_CHAIN_NOT_GREEN')
 report={'schema':1,'status':'R5S2_PINNED_R5S1_NESTED_GITHUB_SOURCE_PASS',
         'r5s1_sha256':R5S1_SHA,'outer_main_sha256':sha(main.read_bytes()),
         'nested_green_sources':True,'upstream_522_to_be_fetched_as_exact_commit':True,
         'kernel_build':False,'device_pass':False,'flash_approved':False}
 (out/'ZIP_VALIDATION.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print('R5S2_IMMUTABLE_NESTED_R5S1_BASE=PASS; NO_KERNEL_BUILD',flush=True)
 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--main',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
 try:safe_unpack(args.main,args.out)
 except Exception as exc:
  print('R5S2_UNPACK_BLOCKED:'+type(exc).__name__+':'+str(exc),file=sys.stderr);sys.exit(1)
