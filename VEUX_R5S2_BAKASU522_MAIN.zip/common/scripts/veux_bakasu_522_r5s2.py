#!/usr/bin/env python3
"""VEUX R5S2: fail-closed, pinned BakaSU compat32 commit 522 on green R5S1.

Git objects are independently pinned, tested in a disposable build tree.
Only the 20 changed kernel files of BakaSU commit 522081c5 are staged; we do
NOT claim to integrate the userspace/manager changes. No kernel flash action.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile

BASE='2489b38582a08fee7b586d05185da5e5d12c6a5c'
TARGET='522081c5b1c58587c4c743242eecf445ccebed5d'
R5S1_SHA='78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78'
R5S1_BLOB='0698d24d3cb3b98945886bc3aff66e02b6735fe9'
REPO='Chrizz100/veux-nongki-universal-kernel'
KERNEL='5.4.274'
EXPECTED_KERNEL_DELTA=20
PINS={  # (official parent Git blob, official target Git blob); None=added
 'Kbuild':('b7655cb3a49077678ef7055ee5fd6cb6a0b44b5d','518b1aece067747f6f341da44cb5f738ba749b3b'),
 'build-all.sh':('3fcf4e072790d19ae3686fa86e97a25ee7a05963','e9a190f1496de5f24cf7b6a896d9146e6d87327d'),
 'compat/kernel_compat.h':('931179d158c05300045b5775180dcf56f045e5b2','9c9af95e123f06bba505f2ab99baeb080c33c705'),
 'feature/adb_root.c':('b16dfa37b736d4bee9ad9bc8c4a1b98e0017aa05','b5e8338ef9f150558dc8e38d62a812b7e2239ba6'),
 'feature/sucompat.c':('42e01ebfffe1ff3f40579b8053767ecb5777c0fb','94803fcfa4e282f448f609fcc59a25c85255faa1'),
 'feature/sucompat.h':('efdc23d148c9226cfcb2fdfb34f7c9fd2de34729','93573422b85ee22993d3e634803a621e4a81bc5f'),
 'hook/arm64/syscall_hook.c':('5f5b32c641cccd17668fd3ef7df47c2b8345d138','c7ef5b3f392e70cdbb9e80f41215a9b0e213f855'),
 'hook/riscv64/syscall_hook.c':('1eaf2cd4a7e3023f62b2a74541207b8a5f77e09d','6663fbb7fec29931a0e601f4e4877cc880df3628'),
 'hook/setuid_hook.c':('7eb2de3f5a347ed0cf91be1f074882b947da0791','8277a4bf3db7c5db14edc3cef1dc4b787f8b39c0'),
 'hook/syscall_event_bridge.c':('605e0626c77abdddf70558d6decf75894efd1e03','a0c559a2760a5f1b1f3bc5e3a4df339dede496f1'),
 'hook/syscall_hook.h':('d4921bf9b988aa9e8dbc1cc5423a21603824ed96','47df6b9136f668607310cdf8afe005466a43d398'),
 'hook/syscall_hook_manager.c':('30c23726d5932bc502ed65a2a3f15e0e36aa4800','5dd1f2be2299c99fcf6425133353bc0d764b0708'),
 'hook/x86_64/syscall_hook.c':('ff9ba18d7fa2806f4e6f5676414fb7ff8056a0b6','21e78580dab08b8972bdb62dcbfae60d11843c54'),
 'include/arch.h':('99bd2d18aadc639982943bb5eb16261c69636ba9','b5a361a91dcec5631a872c36e962947605207488'),
 'runtime/ksud_integration.c':('39334735468768a2ffcec7317530058bba46e317','e2d2910ef433a7c9b576a0cd3f85eb3f03e74732'),
 'supercall/supercall.c':('ca43b5a3d55a7bf751ba238dd7cfc93615813a2a','7008779430866103fffc9bf9ed27ecc2223bdf9a'),
 'tools/code_generation/code_generation.mk':(None,'3862c7f0dd52054d8fc39b7d180d973dc4d50ac8'),
 'tools/code_generation/syscall_no/syscall_no.c':(None,'86e3ec478e56252848e11726588f230761c3c62c'),
 'tools/code_generation/syscall_no/syscall_no.mk':(None,'6ff7d8a4f0354c4e1cabc0c4cdf0b68d83d84ba5'),
 'tools/kernel_compat.mk':('2023956a3faa701198e6e9efcd84300db84d488c','2f642583c783753273c64166a92a7de2e509f41e'),
}
class PortBlocked(RuntimeError): pass

def need(x,msg):
    if not x: raise PortBlocked(msg)

def sha(x:bytes): return hashlib.sha256(x).hexdigest()

def blob(x:bytes): return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()

def git(repo:Path,*args,timeout=120)->str:
    p=subprocess.run(['git','-C',str(repo),*args],capture_output=True,timeout=timeout,text=True)
    need(p.returncode==0,'GIT_FAIL_'+':'.join(args[:2])+':'+p.stderr[-180:])
    return p.stdout.strip()

def git_bytes(repo:Path,oid:str)->bytes:
    p=subprocess.run(['git','-C',str(repo),'cat-file','blob',oid],capture_output=True,timeout=120)
    need(p.returncode==0,'CANNOT_READ_PINNED_GIT_BLOB_'+oid)
    need(blob(p.stdout)==oid,'GIT_BLOB_CONTENT_MISMATCH_'+oid)
    return p.stdout

def verify_donor(donor:Path)->dict:
    donor=donor.resolve(strict=True)
    need(donor.is_dir() and not donor.is_symlink(),'DONOR_UNSAFE')
    need(git(donor,'rev-parse','--show-toplevel')==str(donor),'DONOR_NOT_GIT_ROOT')
    need(git(donor,'rev-parse','HEAD')==TARGET,'DONOR_WRONG_COMMIT')
    need(git(donor,'rev-parse','HEAD^')==BASE,'DONOR_WRONG_PARENT')
    need(git(donor,'status','--porcelain','--untracked-files=all')=='','DONOR_DIRTY')
    changed=git(donor,'diff','--name-only',BASE,TARGET,'--','kernel/').splitlines()
    need(changed==sorted('kernel/'+p for p in PINS),'DONOR_UNREVIEWED_KERNEL_PATH_SET')
    for name,(prior,after) in PINS.items():
        full='kernel/'+name
        if prior is not None:
            need(git(donor,'rev-parse',BASE+':'+full)==prior,'DONOR_BEFORE_BLOB_DRIFT_'+name)
        need(git(donor,'rev-parse',TARGET+':'+full)==after,'DONOR_AFTER_BLOB_DRIFT_'+name)
    return {'git_commit':TARGET,'parent':BASE,'kernel_paths_count':len(PINS),
            'added_kernel_paths':sum(b is None for b,_ in PINS.values()),
            'before_and_after_git_blobs_authenticated':True}

def three_way(ours:bytes,before:bytes,after:bytes,td:Path)->tuple[bytes,str]:
    need(b'\0' not in ours+before+after,'BINARY_SOURCE_REFUSED')
    if ours==after: raise PortBlocked('522_UPDATE_ALREADY_PRESENT')
    if ours==before:return after,'EXACT_PREIMAGE'
    with tempfile.TemporaryDirectory(dir=td,prefix='merge-522-') as d:
        a,b,c=(Path(d)/n for n in ('local','base','target'))
        a.write_bytes(ours);b.write_bytes(before);c.write_bytes(after)
        r=subprocess.run(['git','merge-file','-p',str(a),str(b),str(c)],capture_output=True,timeout=50)
        need(r.returncode==0,'MERGE_CONFLICT_OR_ERROR_'+str(r.returncode)+':'+r.stderr.decode(errors='replace')[:250])
        need(b'<<<<<<<' not in r.stdout and b'>>>>>>>' not in r.stdout,'MERGE_CONFLICT_MARKERS')
        need(r.stdout!=ours,'MERGE_NO_CHANGE_NOT_VALID')
        return r.stdout,'CLEAN_THREE_WAY'

def port_in_memory(src:Path,donor:Path,tmp:Path,*,pin_source=True)->tuple[dict,dict[str,bytes]]:
    src=src.resolve(strict=True);donor=donor.resolve(strict=True)
    need(tmp.is_dir(),'TEMP_WORK_NOT_FOUND')
    checked=verify_donor(donor)
    kroot=(src/'KernelSU/kernel').resolve(strict=True)
    need(kroot.is_dir() and kroot.is_relative_to(src),'KERNELSU_PATH_UNSAFE')
    link=(src/'drivers/kernelsu').resolve(strict=True)
    need(link==kroot,'KERNELSU_BUILDPATH_DOES_NOT_MATCH_EFFECTIVE_SOURCE')
    sel=kroot/'feature/selinux_hide.c'
    need(sel.is_file() and not sel.is_symlink(),'BAKASU_R5S1_SOURCE_MISSING')
    if pin_source:
        need(sha(sel.read_bytes())==R5S1_SHA and blob(sel.read_bytes())==R5S1_BLOB,
             'FROZEN_R5S1_SELINUX_REPAIRS_LOST')
    retained={k:(src/k).read_bytes() for k in ('security/selinux/hooks.c','security/selinux/selinuxfs.c','fs/susfs.c','include/linux/susfs.h','include/linux/susfs_def.h')}
    outputs={};summary=[]
    for name,(before_oid,after_oid) in PINS.items():
        target=kroot/name
        need(target.resolve().is_relative_to(kroot) and not target.is_symlink(),'UNSAFE_KERNELSU_TARGET_'+name)
        after=git_bytes(donor,after_oid)
        if before_oid is None:
            need(not target.exists(),'ADDED_UPSTREAM_FILE_ALREADY_EXISTS_'+name)
            updated,how=after,'NEW_OFFICIAL_FILE'
            old=b''
        else:
            need(target.is_file(),'MISSING_VEUX_5_4_TARGET_'+name)
            old=target.read_bytes()
            before=git_bytes(donor,before_oid)
            updated,how=three_way(old,before,after,tmp)
        outputs[name]=updated
        summary.append({'path':'kernel/'+name,'mode':how,'before_sha256':sha(old),
                        'after_sha256':sha(updated),'upstream_git_blob':after_oid})
    need(all((src/k).read_bytes()==v for k,v in retained.items()),'SUSFS_OR_NATIVE_SELINUX_CHANGED_DURING_DRYRUN')
    need(sha(sel.read_bytes())==R5S1_SHA if pin_source else True,'SELINUX_CHANGED_DURING_DRYRUN')
    need(len(summary)==EXPECTED_KERNEL_DELTA and len(outputs)==EXPECTED_KERNEL_DELTA,'EXPECTED_COMPLETE_522_KERNEL_DELTA')
    return {'status':'PINNED_522_5_4_PORT_STAGED_IN_MEMORY','donor':checked,
            'effective_r5s1_selinux_sha256':sha(sel.read_bytes()),
            'native_selinux_susfs_untouched':True,'changed_files':summary,
            'kernel_paths':len(summary),'security_features_not_disabled':True,
            'new_manager_ksud_userland_not_integrated':True,
            'not_a_device_pass':True,'no_flash':True},outputs

def stage(src:Path,bundle:Path,work:Path,donor:Path)->dict:
    src=src.resolve(strict=True);work=work.resolve(strict=True);bundle=bundle.resolve(strict=True)
    need(src.is_relative_to(work) and work.name==KERNEL and work.parent.name=='builds','UNSAFE_BUILD_WORKSPACE')
    root=work.parent.parent
    need(bundle==root/'bundle','EXPECTED_IMMUTABLE_BUNDLE')
    targets=json.loads((bundle/'targets.json').read_text())['components']
    need(targets['resukisu']['commit']=='5b76b884c75f729a220bb317aa4a4fc78f0e0e9c'
         and targets['susfs']['commit']=='5326e21a7eb232f9e21debdd5164e99bee3d1e2f'
         and targets['nomount']['commit']=='7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3',
         'R5S2_UPSTREAM_BASE_COMPONENT_DRIFT')
    report,staged=port_in_memory(src,donor,root)
    kroot=(src/'KernelSU/kernel').resolve(strict=True)
    for relative,data in staged.items():
        path=kroot/relative
        need(not path.is_symlink() and (not path.exists() or path.is_file()),'R5S2_SOURCE_WRITE_UNSAFE')
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
    need(sha((kroot/'feature/selinux_hide.c').read_bytes())==R5S1_SHA,'D726_SELINUX_SECURITY_CHANGED')
    rep=root/'report/BAKASU_522_R5S2_STAGE.json'
    need(rep.parent.is_dir() and not rep.exists(),'R5S2_REPORT_COLLISION')
    rep.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print('BAKASU_522_R5S2_SOURCE_STAGE=PASS; FILES=20; R5S1_SELINUX_UNCHANGED; NO_FLASH',flush=True)
    return report

def verify_compiled(src:Path,work:Path,staged:dict,result:dict)->dict:
    kroot=(src/'KernelSU/kernel').resolve(strict=True)
    need(staged.get('status')=='PINNED_522_5_4_PORT_STAGED_IN_MEMORY','522_STAGE_PROOF_MISSING')
    for f in staged['changed_files']:
        rel=f['path'].removeprefix('kernel/')
        need(sha((kroot/rel).read_bytes())==f['after_sha256'],'522_SOURCE_NOT_IN_COMPILED_BUILD_'+rel)
    need(sha((kroot/'feature/selinux_hide.c').read_bytes())==R5S1_SHA,'522_ERASED_R5S1_SELINUX')
    work=work.resolve(strict=True)
    cfg=(work/'config-reports/actual-build.config').read_text()
    need(re.search(r'(?m)^CONFIG_COMPAT=y$',cfg) is not None,'VEUX_32BIT_COMPAT_DISABLED')
    need('# CONFIG_KSU_TRACEPOINT_HOOK is not set' in cfg,'NON_GKI_54_HOOK_BASE_CHANGED')
    for x in ('CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y','CONFIG_STACKPROTECTOR_STRONG=y'):
        need(re.search('(?m)^'+x+'$',cfg) is not None,'CONFIG_GUARD_REMOVED_'+x)
    obj=work/'build/drivers/kernelsu/feature/sucompat.o'
    cmd=work/'build/drivers/kernelsu/feature/.sucompat.o.cmd'
    need(obj.is_file() and not obj.is_symlink() and obj.stat().st_size>0 and
         cmd.is_file() and not cmd.is_symlink() and cmd.stat().st_size>0,
         'BAKASU_522_SUCOMPAT_NOT_COMPILED')
    t=cmd.read_text(errors='replace')
    need('-fstack-protector-strong' in t and '-flto=thin' in t and
         '-fno-stack-protector' not in t,'BAKASU_522_SUCOMPAT_COMPILER_FLAGS_INSECURE')
    header=[p for p in (work/'build/drivers/kernelsu').rglob('syscall_no.h')
            if p.is_file() and not p.is_symlink()]
    need(len(header)==1,'BAKASU_522_GENERATED_HEADER_NOT_UNIQUE_OR_MISSING')
    hdr=header[0].read_text(errors='replace')
    for needle in ('#ifndef KSU_NR_COMPAT_H', '#define ksu_get_syscall_no(name)',
                   '#define ksu_get_compat_syscall_no(name)', '__NR_compat32_'):
        need(needle in hdr,'BAKASU_522_GENERATED_COMPAT_HEADER_INCOMPLETE_'+needle)
    row={'status':'EXPERIMENTAL_522_5_4_COMPILED_IN_R5S1_LINEAGE',
         'change_count':20,'donor_commit':TARGET,'compat_config_y':True,
         'tracepoint_disabled':True,'r5s1_selinux_unchanged':True,
         'generated_syscall_header_sha256':sha(header[0].read_bytes()),
         'sucompat_cmd_sha256':sha(cmd.read_bytes()),'device_pass':False,'flash_release':False}
    path=work.parent.parent/'report/BAKASU_522_R5S2_COMPILED.json'
    need(not path.exists(),'COMPAT_522_COMPILED_REPORT_COLLISION')
    path.write_text(json.dumps(row,indent=2,sort_keys=True)+'\n')
    print('BAKASU_522_R5S2_COMPILED=PASS; DEVICE_PASS=NO',flush=True)
    return row

def build(repo:Path,work:Path,reference:Path,donor:Path,jobs:int)->dict:
    import veux_sync_susfs_r1_build as r5s1
    import veux_r6_nomount211_build_r2 as r2
    repo=repo.resolve(strict=True);work=work.resolve(strict=True)
    need(not work.is_relative_to(repo) and 1<=jobs<=12,'UNSAFE_R5S2_BUILD_WORKSPACE')
    need(sha(reference.read_bytes())==R5S1_SHA,'R5S1_REFERENCE_CHANGED')
    verify_donor(donor)
    orig=r5s1.inject_worker
    count=[]
    def wrap(worker,ref):
        row=inject_worker_inner(orig,worker,ref,donor)
        count.append(row)
        return row
    r5s1.inject_worker=wrap
    try:
        r5s1.build(repo,work,jobs,reference)
    finally:
        r5s1.inject_worker=orig
    need(len(count)==1,'R5S2_WORKER_NOT_INJECTED_EXACTLY_ONCE')
    row=json.loads((work/'public'/KERNEL/'RESULT.json').read_text())
    compiled=row.get('bakasu_522_r5s2') or {}
    need(compiled.get('status')=='EXPERIMENTAL_522_5_4_COMPILED_IN_R5S1_LINEAGE'
         and row.get('compile') is True and row.get('package') is True
         and row.get('device') is False,'R5S2_BUILD_ARTIFACT_NOT_VERIFIED')
    report={'status':'EXPERIMENTAL_R5S2_BAKASU522_KERNEL_COMPILED_DEVICE_UNTESTED',
        'official_bakasu_kernel_diff_commit':TARGET,
        'official_kernel_paths_ported':20,
        'r5s1_f308_d726_selinux_retained':True,
        'source_kernel_compilation':True,
        'module_abi_independent_R5S1_verifier_still_required':True,
        'legacy_r5s1_reports_522_not_integrated_flag_refers_only_to_inherited_r5s1_baseline':True,
        'bakasu_manager_and_ksud_userspace_updates_not_integrated':True,
        'susfs_new_5_10_host_patch_not_integrated':True,
        'device_pass':False,'flash_approved':False}
    p=work/'report/R5S2_BAKASU522_FINAL.json'
    need(not p.exists(),'R5S2_FINAL_REPORT_EXISTS')
    p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print('R5S2_BAKASU_522_KERNEL_BUILD=PASS; INDEPENDENT_ABI_GATE_NEXT; NO_FLASH',flush=True)
    return report

def inject_worker_inner(orig,worker,reference,donor):
    try:
        res=orig(worker,reference)
    except Exception as exc:
        raise PortBlocked('R5S1_SOURCE_INJECTION_REFUSED:'+str(exc)) from exc
    source=worker.read_text()
    pattern=re.compile(r'(?m)^(        sync_staged = stage\(src, bundle, work, Path\(.+\)\)\n)')
    need(len(pattern.findall(source))==1,'R5S1_STAGE_ANCHOR_DRIFT')
    end="        result['bakasu_sync_f308_d726_r5'] = sync_compiled\n"
    need(source.count(end)==1 and 'compat_522_staged' not in source,'R5S2_COMPILATION_ANCHOR_DRIFT')
    d=str(donor.resolve(strict=True))
    source=pattern.sub(lambda m:m.group(1)+
        '        from veux_bakasu_522_r5s2 import stage as stage_522\n'
        +f'        compat_522_staged = stage_522(src, bundle, work, Path({d!r}))\n',source,count=1)
    source=source.replace(end,end+
        '        from veux_bakasu_522_r5s2 import verify_compiled as verify_522_compiled\n'
        +'        result["bakasu_522_r5s2"] = verify_522_compiled(src,work,compat_522_staged,result)\n',1)
    need(source.count('compat_522_staged = stage_522(')==1,'R5S2_INJECTION_DOUBLE')
    ast.parse(source)
    worker.write_text(source)
    need(res.get('status')=='SYNC_ONLY_DISPOSABLE_WORKER_INJECTED',
         'R5S1_INJECTION_STATUS_NOT_GREEN')
    return {'status':'R5S2_DISPOSABLE_WORKER_INJECTED',
            'r5s1_stage':res,'repository_worker_unchanged':True}

def main():
    a=argparse.ArgumentParser()
    a.add_argument('cmd',choices=['donor','build'])
    a.add_argument('--donor',type=Path,required=True)
    a.add_argument('--repo',type=Path)
    a.add_argument('--work',type=Path)
    a.add_argument('--reference',type=Path)
    a.add_argument('--jobs',type=int,default=4)
    p=a.parse_args()
    try:
        if p.cmd=='donor':
            print(json.dumps(verify_donor(p.donor),sort_keys=True))
        else:
            need(p.repo is not None and p.work is not None and p.reference is not None,'MISSING_BUILD_ARGUMENTS')
            build(p.repo,p.work,p.reference,p.donor,p.jobs)
    except (PortBlocked,ValueError,KeyError,OSError,subprocess.SubprocessError) as e:
        print('BAKASU_522_R5S2_BLOCKED:'+type(e).__name__+':'+str(e),flush=True)
        raise SystemExit(1)
if __name__=='__main__':main()
