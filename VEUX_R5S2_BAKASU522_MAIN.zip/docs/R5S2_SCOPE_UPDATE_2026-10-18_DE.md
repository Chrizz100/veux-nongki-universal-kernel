# VEUX R5S2 – BakaSU-522 Kernelport auf grünem R5S1

Der vollständig grüne Referenzbuild ist R5S1, GitHub-Run 39110233263.

## Kandidat
- Basis: R5S1 mit BakaSU sync-susfs `f308ed0936bdd31163cb53da3f42bc7a698f5512`, gezielt erhaltenem `d7260ca1`, R3/R5 SELinux-Anpassungen, NoMount 2.1.1 und SUSFS-Kern 2.3.0.
- Neu untersucht/zu übernehmen: ausschließlich die **20 Kerneldateien** des offiziellen BakaSU-Commits `522081c5b1c58587c4c743242eecf445ccebed5d`, Parent `2489b38582a08fee7b586d05185da5e5d12c6a5c`.
- Nicht eingeschlossen: zusätzliche Manager-/ksud-/Rust-/Workflow-Dateien desselben Commits. Ein vollständiges Nutzerraum-Update wird deshalb **nicht** behauptet.
- BakaSU-Versionskennung wird nicht künstlich geändert.
- SUSFS-Kerndateien bleiben auf authentifiziertem `5326e21a` (2.3.0). Der vom R5S1-Audit beobachtete GitLab-Head `c1a8ccbb` liegt fünf Commits weiter. Deren 5.10-Integrationspatches sind weiterhin **nicht** für 5.4 freigegeben. Diese R5S2-Stufe ändert SUSFS nicht.

## Harte Voraussetzungen
1. Original-Git-Commit/Parent, alle 20 Git-Dateipaar-Hashes und vollständige Pfadmenge nachweisen.
2. GitHub-Quellencheckout unverändert lassen; sämtliche Bearbeitung nur in der temporären Runner-Quellkopie.
3. Drei-Wege-Portierung aller 20 Dateien, bei Konflikt oder ungeklärtem Dateipfad ohne Teilergebnis abbrechen.
4. Die R5S1-SELinux-Quelldatei bleibt bytegenau identisch (SHA-256 `78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78`). Native SELinux-Hostdateien und SUSFS-Kerndateien bleiben unverändert.
5. Für den vollständigen Build `CONFIG_COMPAT=y`, bestehender Non-GKI Hook (`CONFIG_KSU_TRACEPOINT_HOOK=n`), Stackprotector strong, ThinLTO, CFI. Zusätzlich Nachweis der erzeugten `compat/syscall_no.h` und `sucompat.o`-Kompilierung.
6. Erneute R5S1-Prüfung: gleiche `.config`, `Module.symvers`, AK3/Boot-Identität; keine Geräte- oder Flashfreigabe.

**Vor dem nächsten echten GitHub-Lauf:** Lokal sind nur Quellstruktur, Test-Fakes, YAML/Archive prüfbar. Ob BakaSU-522 alle fehlenden 5.4-APIs mitbringt, entscheidet die reale GitHub-Quellenprüfung und Kompilierung. Ein Kompilierungsfehler ist möglich und kein Anlass, die gesicherten R5S1-/R6-Basisstände zu verändern.
