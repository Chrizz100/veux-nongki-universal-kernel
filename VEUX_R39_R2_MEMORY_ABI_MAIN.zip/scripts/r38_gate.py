#!/usr/bin/env python3
"""VEUX R38: pinned R37 overlay vs. stock driver map and historical vendor ABI.

Read-only, diagnostic and NEVER a vendor ABI, kernel boot or flashing approval.
Stock currently bound drivers != evidence of R20 driver binding. An historical
modules.load line != proof that its module is loaded at runtime.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import io
import json
from pathlib import Path
import tempfile
import zipfile

import r34_gate
import r37_gate

SCHEMA='VEUX_R38_OVERLAY_STRUCTURAL_VENDOR_ABI_TRIAGE_V1'
DEVICE='VEUX_R37_DEVICE_EVIDENCE.zip'
ORIGINAL_HASHES={
    'evidence/R20_Module.symvers':'5131e75259d76acd00e08143d76d22d04d1ec86b18b0d70b84fa05b7e1e4049d',
    'evidence/R20_VEUX.dtb':'42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
    'evidence/R21_VENDOR_IMPORTS.csv':'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394',
    'evidence/R33_DEVICE_EVIDENCE.zip':'493d0aed78e428d1d31047c3a30c3f235b1e84ccd657da8f224769a891e7b43d',
    'evidence/R34_DEVICE_EVIDENCE_R2.zip':'b779f0352670aa1d2a3b41204b9a46fa5e597f3005f40c079e9d3a9fce657f0b',
    'evidence/R35_RESULT.zip':'00f44e3d1308d5f36703e2fb751b0592394074aa957150ea0e96f7e3c2a06e16',
    'evidence/R36_R2_RESULT.zip':'d880f0f9d731c5b8a5ccc0243d32d7b7ccc57384bf84220e7c3da691f3c1430a',
    'evidence/R37_RESULT.zip':'843d4db003492a476f23d9725924cc4ff915ee0d49c4fbd12412b38b41f42a4f',
}
R35_FILES={'R35_65_KNOTEN_PRIORITAET.csv','R35_BERICHT_DE.txt','R35_GRUPPEN.csv',
    'R35_RESULT.json','R35_TESTS.log','R35_VENDOR_NAMENSKANDIDATEN.csv','SHA256SUMS.txt'}
R37_FILES={'R37_DTBO_16_INDEX.csv','R37_BERICHT_DE.txt','R37_R20_27_NODES.csv',
    'R37_RESULT.json','R37_STOCK_27_NODES.csv','R37_TESTS.log','SHA256SUMS.txt'}


def sha(b:bytes)->str:return hashlib.sha256(b).hexdigest()


def verify_file_set_and_sha(base:Path)->dict:
    meta=json.loads((base/'MANIFEST_SHA256.json').read_text(encoding='utf8'))
    if meta.get('schema')!='VEUX_R38_PINNED_PACKAGE_V1':raise ValueError('R38_MANIFEST_SCHEMA')
    files=meta.get('files')
    if not isinstance(files,dict) or len(files)<13:raise ValueError('R38_MANIFEST_TOO_SHORT')
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if actual!=set(files)|{'MANIFEST_SHA256.json'}:raise ValueError('R38_UNEXPECTED_PACKAGE_MEMBERS')
    if not set(ORIGINAL_HASHES).issubset(actual):raise ValueError('R38_EVIDENCE_FILES_MISSING')
    for rel,record in files.items():
        path=Path(rel)
        if path.is_absolute() or '..' in path.parts or '\\' in rel or rel.startswith('.'):
            raise ValueError('R38_UNSAFE_MANIFEST_PATH')
        f=base/path
        if f.is_symlink() or not f.is_file() or f.stat().st_size!=record.get('bytes') or sha(f.read_bytes())!=record.get('sha256'):
            raise ValueError('R38_PACKAGE_HASH_FAILED:'+rel)
    for path,h in ORIGINAL_HASHES.items():
        if sha((base/path).read_bytes())!=h:raise ValueError('R38_ORIGINAL_EVIDENCE_HASH_CHANGED:'+path)
    return meta


def historical_report_zip(path,expected_names,expected_schema,expected_status):
    data=r37_gate.safe_zip(path,expected_names)
    record={}
    for line in data['SHA256SUMS.txt'].decode('ascii').splitlines():
        parts=line.split('  ',1)
        if len(parts)!=2 or parts[1] in record or len(parts[0])!=64:
            raise ValueError('R38_ORIGINAL_SUM_FORMAT')
        record[parts[1]]=parts[0]
    hash_required=expected_names-{'SHA256SUMS.txt'}
    if expected_schema.startswith('VEUX_R35'):
        # R35 original GitHub report did not list R35_TESTS.log in SHA256SUMS;
        # its bytes are still pinned by the entire original ZIP SHA256.
        hash_required-={'R35_TESTS.log'}
    if set(record)!=hash_required:raise ValueError('R38_ORIGINAL_SUM_FILE_SET')
    if any(sha(data[name])!=h for name,h in record.items()):
        raise ValueError('R38_ORIGINAL_SUM_MISMATCH')
    res=json.loads(data['R35_RESULT.json'] if expected_schema.startswith('VEUX_R35') else data['R37_RESULT.json'])
    if res.get('schema')!=expected_schema or res.get('status')!=expected_status or res.get('flash_allowed') is not False:
        raise ValueError('R38_PRIOR_RESULT_INCORRECT')
    return data,res


def verify_originals(base:Path):
    verify_file_set_and_sha(base)
    r33,table=r37_gate.verify_r33(base)
    r34,targets=r37_gate.verify_r34_r36(base)
    r35files,r35=historical_report_zip(base/'evidence/R35_RESULT.zip',R35_FILES,
        'VEUX_R35_DT_VENDOR_BOOT_TRIAGE_V1','R35_EVIDENCE_PROVEN_PRIORITY_ONLY_BOOT_BLOCKED')
    r37files,r37=historical_report_zip(base/'evidence/R37_RESULT.zip',R37_FILES,
        'VEUX_R37_DTBO_CANDIDATE_OFFLINE_MERGE_GATE_V1','R37_RAW_STOCK_DTBO_AND_OFFLINE_MERGE_ANALYZED_BOOT_BLOCKED')
    if (r35.get('stock_bound_without_r20_compatible_overlap')!=65 or
        r37.get('unique_root_metadata_candidate_index')!=0 or
        r37.get('stock_27_exact_target_matches')!=27 or
        r37.get('r20_27_exact_target_matches')!=27 or
        r37.get('stock_base_plus_index0_merge',{}).get('nodes')!=2652 or
        r37.get('r20_standalone_plus_index0_merge',{}).get('nodes')!=2200):
        raise ValueError('R38_PRIOR_RESULTS_DIVERGE')
    if r37.get('dtbo_bootloader_choice_proven') is not False:
        raise ValueError('R38_MUST_NOT_ASSERT_BOOTLOADER_CHOICE')
    original65=list(csv.DictReader(io.StringIO(r35files['R35_65_KNOTEN_PRIORITAET.csv'].decode('utf8'))))
    if len(original65)!=65 or len({r['stock_node'] for r in original65})!=65:
        raise ValueError('R38_R35_65_REJECTED')
    sym=r34_gate.parse_symvers((base/'evidence/R20_Module.symvers').read_bytes())
    vendor,counts=r34_gate.vendor_rows((base/'evidence/R21_VENDOR_IMPORTS.csv').read_bytes(),sym)
    if len(vendor)!=218 or sum(counts.values())!=14648:
        raise ValueError('R38_VENDOR_MATRIX_INVALID')
    return r33,r34,targets,original65,r37,vendor,counts


def is_enabled(s:str)->bool:
    return r37_gate.normstatus(s)=='enabled'


def classify_runtime(runtime,merged):
    if merged is None:return 'PATH_MISSING'
    if is_enabled(runtime['status']) and not is_enabled(merged['status']):return 'ENABLED_STOCK_DISABLED_R20'
    compatible_a=runtime['compatible'];compatible_b=merged['compatible']
    if set(compatible_a).intersection(compatible_b):
        if r37_gate.normstatus(runtime['status'])==r37_gate.normstatus(merged['status']):
            return 'COMPAT_OVERLAP_AND_STATUS_MATCH'
        return 'COMPAT_OVERLAP_STATUS_DIFF'
    if compatible_a==compatible_b and r37_gate.normstatus(runtime['status'])==r37_gate.normstatus(merged['status']):
        return 'EXACT_EMPTY_COMPAT_AND_STATUS_MATCH'
    return 'COMPAT_DISJOINT_OR_ABSENT'


def compare_bound_nodes(r34,merged):
    lookup={n['path']:n for n in merged}
    result=[]
    for n in r34['device_nodes']:
        if not n['stock_bound_drivers']:continue
        other=lookup.get(n['path'])
        result.append({'path':n['path'],'stock_drivers':';'.join(n['stock_bound_drivers']),
            'stock_compatible':';'.join(n['compatible']),
            'r20_compatible':';'.join(other['compatible']) if other else '',
            'stock_status':n['status'],'r20_status':other['status'] if other else 'MISSING',
            'classification':classify_runtime(n,other),
            'limitation':'STOCK_DRIVER_ONLY_NOT_R20_PROBE'})
    if len(result)!=503 or len({r['path'] for r in result})!=503:
        raise ValueError('R38_STOCK_DRIVER_BINDING_COUNT_INVALID')
    return result


def compare_r35_65(original65,merged,r34):
    old={n['path']:n for n in r34['device_nodes']}
    new={n['path']:n for n in merged}
    result=[]
    for r in original65:
        path=r['stock_node'];runt=old.get(path)
        if not runt or not runt['stock_bound_drivers']:
            raise ValueError('R38_R35_OLD_NODE_NO_LONGER_BOUND')
        cls=classify_runtime(runt,new.get(path))
        result.append({'path':path,'original_R35_group':r['investigation_group'],
             'original_R35_priority':r['review_order'],'R35_original_difference':r['difference_kind'],
             'after_R37_overlay':cls,
             'stock_compatible':';'.join(runt['compatible']),
             'r20_compatible':';'.join(new[path]['compatible']) if path in new else '',
             'limitation':'STRUCTURAL_ONLY_NOT_PROBE'})
    if len(result)!=65:raise ValueError('R38_65_ROWS_INVALID')
    return result


def structural_diff(stock,r20):
    a={n['path']:n for n in stock};b={n['path']:n for n in r20}
    if len(a)!=len(stock) or len(b)!=len(r20):raise ValueError('R38_DUPLICATE_FDT_PATH')
    rows=[];tally=collections.Counter()
    for p in sorted(set(a)|set(b)):
        n=a.get(p);m=b.get(p)
        if n is None:typ='R20_ONLY'
        elif m is None:typ='STOCK_ONLY'
        elif n['compatible']!=m['compatible'] and r37_gate.normstatus(n['status'])!=r37_gate.normstatus(m['status']):
            typ='COMPAT_AND_STATUS_DIFFER'
        elif n['compatible']!=m['compatible']:typ='COMPAT_DIFFER'
        elif r37_gate.normstatus(n['status'])!=r37_gate.normstatus(m['status']):typ='STATUS_DIFFER'
        else:typ='STRUCTURAL_METADATA_MATCH'
        tally[typ]+=1
        if typ!='STRUCTURAL_METADATA_MATCH':
            rows.append({'path':p,'difference':typ,
            'stock_compatible':';'.join(n['compatible']) if n else '',
            'r20_compatible':';'.join(m['compatible']) if m else '',
            'stock_status':n['status'] if n else 'MISSING',
            'r20_status':m['status'] if m else 'MISSING'})
    if sum(tally.values())!=len(set(a)|set(b)):
        raise ValueError('R38_STRUCTURAL_TOTAL_WRONG')
    return rows,tally


def report_vendor(vendor,counts,reference_r33):
    """Report *historical* CRCs by exact path and stock list; no implied load/probe."""
    groups=reference_r33['module_load_lists'];list_status={}
    for g in groups:
        if g['path'] not in ('/vendor/lib/modules/modules.load','/vendor/lib/modules/5.4-gki/modules.load'):
            continue
        if g.get('truncated') is not False:raise ValueError('R38_TRUNCATED_VENDOR_MODULE_LOAD')
        prefix=g['path'].rsplit('/',1)[0]
        for name in g['module_names']:
            p=prefix+'/'+name
            if p not in vendor:raise ValueError('R38_VENDOR_LIST_MODULE_WITHOUT_IMPORT:'+p)
            list_status.setdefault(p,g['path'])
    if len(list_status)!=218:raise ValueError('R38_NOT_ALL_HISTORICAL_FILES_LISTED')
    active=set(reference_r33['loaded_module_names'])
    if active!={'rmnet_offload','rmnet_shs'}:raise ValueError('R38_STOCK_RUNTIME_MODULE_NAMES_CHANGED')
    out=[]
    for path in sorted(vendor):
        c=vendor[path]; module=Path(path).stem
        out.append({'vendor_file_path':path,'load_list':list_status[path],
            'runtime_module_name_seen':str(module in active),
            'module_origin_at_runtime':'NOT_PROVEN_BY_MODULES_LOAD',
            'historical_matched':c['MATCH'],
            'historical_crc_mismatched':c['CRC_MISMATCH'],
            'historical_exports_absent':c['ABSENT_IN_R20_SYMVERS'],
            'historical_total_imports':sum(c.values()),
            'review_order':'1_STOCK_RUNTIME_NAME_ONLY' if module in active else
                '2_LIST_IN_VENDOR' if list_status[path]=='/vendor/lib/modules/modules.load' else
                '3_LIST_IN_GKI',
            'limitation':'HISTORICAL_IMPORTS_NOT_CURRENT_LOAD_PROOF'})
    if len(out)!=218 or sum(int(r['historical_total_imports']) for r in out)!=14648:
        raise ValueError('R38_VENDOR_IMPORT_TOTAL_INVALID')
    return out


def write_csv(dest,cols,rows):
    stream=io.StringIO();writer=csv.DictWriter(stream,fieldnames=cols,lineterminator='\n')
    writer.writeheader();writer.writerows(rows);dest.write_text(stream.getvalue(),encoding='utf8')


def audit(base:Path,device_zip:Path,out:Path):
    r33,r34,targets,original65,r37,vendor,counts=verify_originals(base)
    device_files=r37_gate.safe_zip(device_zip,r37_gate.DEVICE_NAMES)
    live=r37_gate.parse_device(device_files,r33,targets)
    with tempfile.TemporaryDirectory(prefix='r38-readonly-') as td:
        work=Path(td);stock_base=work/'stock-base.dtb';candidate=work/'index0.dtbo';r20base=work/'r20.dtb'
        stock_base.write_bytes(device_files['R37_VENDOR_BOOT_BASE.dtb'])
        candidate.write_bytes(device_files['R37_DTBO_CANDIDATE0.dtbo'])
        r20base.write_bytes((base/'evidence/R20_VEUX.dtb').read_bytes())
        stock_meta,stock=r37_gate.run_merger(stock_base,candidate,work,'stock-merged.dtb')
        r20_meta,r20=r37_gate.run_merger(r20base,candidate,work,'r20-merged.dtb')
    if stock_meta.get('outcome')!='OFFLINE_APPLY_AND_PARSE_SUCCESS' or r20_meta.get('outcome')!='OFFLINE_APPLY_AND_PARSE_SUCCESS':
        raise ValueError('R38_PREVIOUS_SUCCESSFUL_OVERLAY_NOW_FAILED')
    if len(stock)!=2652 or len(r20)!=2200:
        raise ValueError('R38_R37_FDT_NODE_COUNTS_CHANGED')
    for nodes,label in [(stock,'stock'),(r20,'r20')]:
        comparison=r37_gate.compare_nodes(nodes,live['runtime_target_nodes'])
        if len(comparison)!=27 or sum(c['compatible_match'] and c['status_match'] for c in comparison)!=27:
            raise ValueError('R38_27_PROVEN_OVERLAY_TARGETS_CHANGED:'+label)
    bound=compare_bound_nodes(r34,r20)
    tracked=compare_r35_65(original65,r20,r34)
    diff,tally=structural_diff(stock,r20)
    vendors=report_vendor(vendor,counts,r33)
    cls=collections.Counter(r['classification'] for r in bound)
    r35cls=collections.Counter(r['after_R37_overlay'] for r in tracked)
    x={
        'schema':SCHEMA,'status':'R38_REAL_STOCK_R20_MERGED_STRUCTURAL_AND_HISTORICAL_VENDOR_ABI_COMPARED_BOOT_BLOCKED',
        'source_commit':'0b7ba72729d893bda20e7e52eed2c170d4202f65',
        'r37_original_artifact_sha256':ORIGINAL_HASHES['evidence/R37_RESULT.zip'],
        'device_raw_evidence_verified':True,'candidate_index':0,
        'stock_merged_nodes':len(stock),'r20_merged_nodes':len(r20),
        'fdt_structure_counts':dict(sorted(tally.items())),
        'stock_runtime_bound_node_total':len(bound),
        'r20_overlay_bound_node_classification':dict(sorted(cls.items())),
        'r35_65_after_overlay':dict(sorted(r35cls.items())),
        'r35_65_total':len(tracked),
        'ufs_pmic_27_exact_runtime_matches_stock_and_r20':True,
        'vendor_historical_module_files':len(vendors),
        'vendor_historical_imports':14648,
        'vendor_crc_matches':counts['MATCH'],
        'vendor_crc_mismatches':counts['CRC_MISMATCH'],
        'vendor_missing_exports':counts['ABSENT_IN_R20_SYMVERS'],
        'runtime_stock_module_names':sorted(set(r33['loaded_module_names'])),
        'runtime_module_file_provenance_from_load_list':False,
        'vendor_modules_load_list_not_loaded_proof':True,
        'dtbo_bootloader_selection_proven':False,
        'r20_live_driver_probe_proven':False,
        'vendor_abi_proven':False,
        'boot_ready':False,'flash_allowed':False,
        'kernel_built':False,'device_modified':False,'source_patch_created':False,
        'brene_changed':False,'bakasusu_nomount_changed':False,
        'limitations':[
            'Structural DTBO application offline does not show actual bootloader selection or R20 driver probe.',
            'Stock runtime bound drivers are observations under the stock kernel, never R20 probe proof.',
            'Historical vendor CRCs from R21 do not prove that a particular vendor module is loaded, required or current.',
            'Some runtime RMNET module paths come from a separate 2EF0 loader; basename matching is NOT source provenance.',
            'Different FDT node counts and missing compatible/status strings are not alone actionable kernel defects.',
            'No complete vendor ABI, WALT runtime, Android ROM boot, SELinux or BakaSU/SUSFS/NoMount validation.'
        ]
    }
    out.mkdir(parents=True,exist_ok=True)
    write_csv(out/'R38_STOCK_BOUND_503.csv',list(bound[0]),bound)
    write_csv(out/'R38_R35_65_AFTER_OVERLAY.csv',list(tracked[0]),tracked)
    write_csv(out/'R38_STOCK_R20_FDT_DIFFERENCES.csv',
        ['path','difference','stock_compatible','r20_compatible','stock_status','r20_status'],diff)
    write_csv(out/'R38_VENDOR_218_ABI_PRIORITY.csv',list(vendors[0]),vendors)
    (out/'R38_RESULT.json').write_text(json.dumps(x,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf8')
    lines=[
      'VEUX R38 – Offline-Strukturvergleich und historische Vendor-ABI; KEINE Boot-/Flashfreigabe',
      f'R37-Reproduktion: Stock+DTBO0 {len(stock)} Knoten; R20+DTBO0 {len(r20)} Knoten.',
      'UFS-/PMIC-Pruefung: Stock und R20 weiterhin 27/27 passende Zielknoten (compatible+status).',
      'Stock-laufende gebundene Treiberknoten: 503; nur STRUKTURELLER Vergleich mit R20+DTBO0.',
      'R20 Klassifikation: '+', '.join(f'{k}={v}' for k,v in sorted(cls.items())),
      'R35 65-Knoten-Nachpruefung: '+', '.join(f'{k}={v}' for k,v in sorted(r35cls.items())),
      'FDT-Strukturunterschiede: '+', '.join(f'{k}={v}' for k,v in sorted(tally.items())),
      'Historische Vendor-Module: 218/218 in zwei erfassten modules.load-Listen, NICHT alle geladen.',
      f'Vendor-Importe R21: {sum(counts.values())}=MATCH {counts["MATCH"]} + CRC_MISMATCH {counts["CRC_MISMATCH"]} + ABSENT {counts["ABSENT_IN_R20_SYMVERS"]}.',
      'Aktuell unter STOCK geladene ModulNAMEN: rmnet_offload und rmnet_shs (Dateiherkunft separat pruefen).',
      'Weder Bootloader-DTBO-Auswahl noch R20-live-Probe oder komplette Vendor-ABI sind damit bewiesen.',
      'KEIN R20-Quellpatch, KEIN Kernel-Build, KEIN Flash, KEINE BReNE-Aenderung.',
      'NAECHSTER SCHRITT: konkret fehlende/abweichende AKTIV gebundene Stock-Knoten und erforderliche Vendor-Module anhand der CSVs eingrenzen.'
    ]
    (out/'R38_BERICHT_DE.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
    files=sorted(p for p in out.iterdir() if p.is_file())
    (out/'SHA256SUMS.txt').write_text(''.join(sha(p.read_bytes())+'  '+p.name+'\n' for p in files),encoding='ascii')
    print('R38_PROVENANCE=PASS; R35_TRACKED=65; STOCK_BOUND=503; HISTORICAL_VENDOR=218; R20_R37_27_MATCH=YES; BOOT=NO; FLASH=NO')
    return x


if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Read-only R38 structural ABI diagnostics')
    ap.add_argument('--bundle',type=Path,required=True)
    ap.add_argument('--device-zip',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    try:audit(args.bundle,args.device_zip,args.out)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,json.JSONDecodeError) as e:
        raise SystemExit('R38_FAIL_CLOSED: '+str(e))
