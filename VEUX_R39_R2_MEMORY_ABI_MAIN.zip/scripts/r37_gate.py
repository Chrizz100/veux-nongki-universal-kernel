#!/usr/bin/env python3
"""R37 pinned metadata selection and *offline* overlay application diagnostics.

Passing this gate is NOT a bootloader selection, vendor ABI, boot, or flash approval.
Raw runtime FDT is never accepted or exported. All raw inputs are static stock
partition FDTs captured read-only on the user's device and hash-pinned to R33.
"""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import shutil
import stat
import subprocess
import tempfile
import zipfile

from r34_gate import fdt_nodes

SCHEMA='VEUX_R37_DTBO_CANDIDATE_OFFLINE_MERGE_GATE_V1'
DEVICE_SCHEMA='VEUX_R37_TARGETED_RAW_DTBO_EVIDENCE_V1'
ANCHORS={
 'evidence/R33_DEVICE_EVIDENCE.zip':'493d0aed78e428d1d31047c3a30c3f235b1e84ccd657da8f224769a891e7b43d',
 'evidence/R34_DEVICE_EVIDENCE_R2.zip':'b779f0352670aa1d2a3b41204b9a46fa5e597f3005f40c079e9d3a9fce657f0b',
 'evidence/R36_R2_RESULT.zip':'d880f0f9d731c5b8a5ccc0243d32d7b7ccc57384bf84220e7c3da691f3c1430a',
 'evidence/R20_VEUX.dtb':'42728a6f3d48ae35ac6be4b14ea51bc8a323e77baec2ee544827487378f99d37',
}
DTBO_TABLE_SHA='8bb06d7d100109fb79aa08349de003d72f14157e04afd2784a13cc28da1b3a3e'
ENTRY0_SHA='cc4841c596e0d4264f57f42f344ed0d121b8cd92b3a848457e1e575aae97a731'
BASE_SHA='4aa52366c6e969394ae3b8e969de14971f90b0886d9011705798a86b464953a7'
R33_NAMES={'R33_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'}
R34_NAMES={'R34_DEVICE_EVIDENCE.json','README_DE.txt','SHA256SUMS.txt'}
R36_NAMES={'R36_RESULT.json','R36_PMIC_25_SOURCE_MATRIX.csv','R36_UFS_2_BOOT_MATRIX.csv','R36_BERICHT_DE.txt','R36_TESTS.log','SHA256SUMS.txt'}
DEVICE_NAMES={'R37_DEVICE_EVIDENCE.json','R37_VENDOR_BOOT_BASE.dtb','R37_DTBO_CANDIDATE0.dtbo','README_DE.txt','SHA256SUMS.txt'}
UFS_PATHS=('/soc/ufsphy_mem@4807000','/soc/ufshc@4804000')


def sha(data):return hashlib.sha256(data).hexdigest()


def safe_zip(source,expected,compressed_limit=7_000_000,uncompressed_limit=15_000_000):
    b=source.read_bytes() if isinstance(source,Path) else source
    if not isinstance(b,bytes) or len(b)>compressed_limit:
        raise ValueError('R37_ARCHIVE_COMPRESSED_LIMIT')
    files={};size=0
    with zipfile.ZipFile(io.BytesIO(b)) as z:
        items=z.infolist(); names=[f.filename for f in items]
        if len(items)!=len(expected) or set(names)!=set(expected) or len(set(names))!=len(names):
            raise ValueError('R37_UNEXPECTED_OR_DUPLICATE_ARCHIVE_MEMBERS')
        for f in items:
            name=f.filename
            if f.is_dir() or name.startswith('/') or '\\' in name or '..' in Path(name).parts or stat.S_ISLNK(f.external_attr>>16):
                raise ValueError('R37_ZIP_MEMBER_UNSAFE')
            if f.file_size>6_000_000 or f.compress_size>6_000_000:
                raise ValueError('R37_ZIP_FILE_TOO_LARGE')
            size+=f.file_size
            if size>uncompressed_limit:raise ValueError('R37_ZIP_TOTAL_LIMIT')
            files[name]=z.read(f)
        if z.testzip() is not None:raise ValueError('R37_ZIP_CRC_FAILURE')
    return files


def verify_sums(files):
    summ=files['SHA256SUMS.txt'].decode('ascii')
    records={}
    for line in summ.splitlines():
        bits=line.split('  ',1)
        if len(bits)!=2 or len(bits[0])!=64 or bits[1] in records:
            raise ValueError('R37_SHA256SUMS_SYNTAX')
        records[bits[1]]=bits[0]
    if not records or not set(records).issubset(set(files)-{'SHA256SUMS.txt'}):
        raise ValueError('R37_SHA256SUMS_FILE_SET')
    expected_critical=({'R37_DEVICE_EVIDENCE.json','R37_VENDOR_BOOT_BASE.dtb','R37_DTBO_CANDIDATE0.dtbo'} if 'R37_DEVICE_EVIDENCE.json' in files else
        {'R34_DEVICE_EVIDENCE.json'} if 'R34_DEVICE_EVIDENCE.json' in files else
        {'R36_RESULT.json'} if 'R36_RESULT.json' in files else {'R33_DEVICE_EVIDENCE.json'})
    if not expected_critical.issubset(records):raise ValueError('R37_CRITICAL_SUMS_MISSING')
    if any(sha(files[name])!=expected for name,expected in records.items()):
        raise ValueError('R37_SHA256SUMS_CONTENT_MISMATCH')
    return True


def verify_bundle(base):
    manifest=json.loads((base/'MANIFEST_SHA256.json').read_text())
    if manifest.get('schema')!='VEUX_R37_PINNED_MAIN_PACKAGE_V1':
        raise ValueError('R37_BAD_MAIN_MANIFEST_SCHEMA')
    files=manifest.get('files',{})
    actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
    if actual!=set(files)|{'MANIFEST_SHA256.json'} or len(files)<10:
        raise ValueError('R37_MAIN_FILE_LIST_INCORRECT')
    for n,meta in files.items():
        p=base/n
        if p.is_symlink() or p.stat().st_size!=meta.get('bytes') or sha(p.read_bytes())!=meta.get('sha256'):
            raise ValueError('R37_MAIN_SHA256_MISMATCH:'+n)
    for n,h in ANCHORS.items():
        if sha((base/n).read_bytes())!=h:raise ValueError('R37_PINNED_ORIGINAL_CHANGED:'+n)
    return True


def verify_r33(base):
    files=safe_zip(base/'evidence/R33_DEVICE_EVIDENCE.zip',R33_NAMES)
    verify_sums(files)
    data=json.loads(files['R33_DEVICE_EVIDENCE.json'])
    if (data.get('schema')!='VEUX_R33_DEVICE_DTB_PROVENANCE_V1' or
        data.get('read_only') is not True or data.get('reported_active_slot')!='_a'):
        raise ValueError('R37_R33_SCHEMA_OR_SLOT_CHANGED')
    run=data['runtime_device_tree']
    if run.get('status')!='PARSED':raise ValueError('R37_R33_RUNTIME_NOT_PARSED')
    root=run['fdt']['root']
    entries=data.get('dtbo',[])
    if len(entries)!=2:raise ValueError('R37_EXPECTED_TWO_DTBO_SLOTS')
    for d in entries:
        if (d.get('status')!='PARSED' or d.get('entry_count')!=16 or
            d.get('table_sha256')!=DTBO_TABLE_SHA or len(d.get('entries',[]))!=16):
            raise ValueError('R37_DTBO_TABLE_OR_ENTRY_COUNT_CHANGED')
    if entries[0]['partition']!='dtbo_a' or entries[1]['partition']!='dtbo_b':
        raise ValueError('R37_DTBO_PARTITION_ORDER')
    for i in range(16):
        if entries[0]['entries'][i]['sha256']!=entries[1]['entries'][i]['sha256']:
            raise ValueError('R37_DTBO_SLOTS_DIVERGE')
    scores=[]
    for ent in entries[0]['entries']:
        e=ent['fdt']['root']; match=(
            e.get('model')==root.get('model') and
            e.get('qcom,board-id')==root.get('qcom,board-id') and
            e.get('qcom,msm-id')==root.get('qcom,msm-id') and
            e.get('compatible')==root.get('compatible'))
        scores.append({'index':ent['index'],'model':e.get('model',[''])[0],
             'board_id':','.join(e.get('qcom,board-id',[])),
             'soc_id':','.join(e.get('qcom,msm-id',[])),
             'full_runtime_root_metadata_match':bool(match),
             'sha256':ent['sha256']})
    indices=[x['index'] for x in scores if x['full_runtime_root_metadata_match']]
    if indices!=[0] or scores[0]['sha256']!=ENTRY0_SHA:
        raise ValueError('R37_EXPECTED_EXACTLY_INDEX0')
    if scores[3]['board_id']==scores[0]['board_id']:
        raise ValueError('R37_PEUX_BOARD_VARIANT_NOT_DISTINCT')
    vendor=[v for v in data.get('vendor_boot',[]) if v.get('partition')=='vendor_boot_a']
    if not vendor or vendor[0]['dtbs'][0]['sha256']!=BASE_SHA:
        raise ValueError('R37_STOCK_BASE_DTB_ANCHOR_WRONG')
    return data,scores


def verify_r34_r36(base):
    r34=safe_zip(base/'evidence/R34_DEVICE_EVIDENCE_R2.zip',R34_NAMES)
    verify_sums(r34)
    d=json.loads(r34['R34_DEVICE_EVIDENCE.json'])
    if d.get('schema')!='VEUX_R34_DEVICE_DRIVER_BINDINGS_V1' or d.get('status')!='CURRENT_NODES_ENUMERATED':
        raise ValueError('R37_R34_INVALID')
    nodes=d.get('device_nodes',[])
    if len(nodes)!=754 or sum(bool(n['stock_bound_drivers']) for n in nodes)!=503:
        raise ValueError('R37_R34_NODE_OR_BINDING_COUNTS')
    node_by_path={n['path']:n for n in nodes}
    for p in UFS_PATHS:
        n=node_by_path.get(p)
        if n is None or n['status']!='ok' or not n['stock_bound_drivers']:
            raise ValueError('R37_STOCK_UFS_PATH_NOT_ENABLED_OR_BOUND:'+p)
    r36=safe_zip(base/'evidence/R36_R2_RESULT.zip',R36_NAMES)
    verify_sums(r36)
    x=json.loads(r36['R36_RESULT.json'])
    if (x.get('status')!='R36_ANCESTOR_SOURCE_OBJECTS_AND_STOCK_DT_CONFIRMED_BOOT_BLOCKED' or
        x.get('source_blob_count')!=22 or x.get('r20_ufs_built_objects_proven')!=2 or
        x.get('pmic_nodes_source_and_build_checked')!=25 or x.get('boot_ready') is not False):
        raise ValueError('R37_R36_RESULT_INVALID')
    pmic=list(csv.DictReader(io.StringIO(r36['R36_PMIC_25_SOURCE_MATRIX.csv'].decode())))
    ufs=list(csv.DictReader(io.StringIO(r36['R36_UFS_2_BOOT_MATRIX.csv'].decode())))
    if len(pmic)!=25 or len(ufs)!=2:raise ValueError('R37_R36_MATRIX_LENGTH')
    paths=sorted({r['node'] for r in pmic+ufs})
    if len(paths)!=27:raise ValueError('R37_R36_DISTINCT_TARGET_PATHS')
    return d,paths


def parse_device(files,reference_r33,expected_paths):
    verify_sums(files)
    if set(line.split('  ',1)[1] for line in files['SHA256SUMS.txt'].decode().splitlines())!=DEVICE_NAMES-{'SHA256SUMS.txt'}:
        raise ValueError('R37_DEVICE_EVIDENCE_NOT_ALL_HASHED')
    d=json.loads(files['R37_DEVICE_EVIDENCE.json'])
    expected_keys={'schema','read_only','reported_active_slot','dtbo_partition',
       'vendor_boot_partition','dtbo_table_sha256','dtbo_entry_count',
       'candidate_entry_index','candidate_entry_sha256','vendor_boot_base_dtb_sha256',
       'candidate_entry_root','runtime_fdt_metadata','runtime_target_nodes',
       'limitation','no_flash','no_source_patch'}
    if set(d)!=expected_keys or d['schema']!=DEVICE_SCHEMA or d['read_only'] is not True or d['no_flash'] is not True or d['no_source_patch'] is not True:
        raise ValueError('R37_DEVICE_SCHEMA_FIELDS_INCORRECT')
    slot=d['reported_active_slot']
    if slot not in ('_a','_b') or d['dtbo_partition']!='dtbo'+slot or d['vendor_boot_partition']!='vendor_boot'+slot:
        raise ValueError('R37_DEVICE_SLOT_NOT_CONSISTENT')
    if (d['dtbo_table_sha256']!=DTBO_TABLE_SHA or d['dtbo_entry_count']!=16 or
        d['candidate_entry_index']!=0 or d['candidate_entry_sha256']!=ENTRY0_SHA or
        d['vendor_boot_base_dtb_sha256']!=BASE_SHA):
        raise ValueError('R37_DEVICE_SOURCE_HASHES_DO_NOT_MATCH_R33')
    if d['candidate_entry_root']!=reference_r33['dtbo'][0]['entries'][0]['fdt']['root']:
        raise ValueError('R37_DEVICE_OVERLAY_MODEL_DIFFERENT')
    if d['runtime_fdt_metadata']['root']!=reference_r33['runtime_device_tree']['fdt']['root']:
        raise ValueError('R37_CURRENT_DEVICE_ROOT_CHANGED')
    rawbase=files['R37_VENDOR_BOOT_BASE.dtb'];rawov=files['R37_DTBO_CANDIDATE0.dtbo']
    if sha(rawbase)!=BASE_SHA or sha(rawov)!=ENTRY0_SHA:
        raise ValueError('R37_DEVICE_RAW_FDT_HASH_MISMATCH')
    if len(rawbase)!=324539 or len(rawov)!=151349:
        raise ValueError('R37_RAW_FDT_SIZE_ANCHOR_FAILED')
    parsed= {n['path']:n for n in fdt_nodes(rawov)}
    if '/' not in parsed:raise ValueError('R37_ENTRY0_PARSE_INVALID')
    fdt_nodes(rawbase)
    got=d['runtime_target_nodes']
    if (not isinstance(got,list) or len(got)!=27 or
        sorted(n.get('path','') for n in got)!=expected_paths or
        any(set(n)!={'path','compatible','status'} for n in got)):
        raise ValueError('R37_ONLY_27_SAFE_RUNTIME_TARGETS_ALLOWED')
    for n in got:
        if len(n['compatible'])>18 or any(len(s)>180 for s in n['compatible']) or len(n['status'])>80:
            raise ValueError('R37_RUNTIME_NODE_DATA_INVALID')
    return d


def normstatus(s):
    return 'enabled' if s in ('okay','ok','okay (default)') else s


def compare_nodes(merged_nodes,device_nodes):
    m={n['path']:n for n in merged_nodes}
    rows=[]
    for n in device_nodes:
        v=m.get(n['path'])
        compatible_match=(v is not None and v['compatible']==n['compatible'])
        status_match=(v is not None and normstatus(v['status'])==normstatus(n['status']))
        rows.append({'path':n['path'],'in_merged':v is not None,
           'compatible_match':compatible_match,'status_match':status_match,
           'runtime_status':n['status'],'merged_status':v['status'] if v else 'MISSING',
           'runtime_compatible':';'.join(n['compatible']),
           'merged_compatible':';'.join(v['compatible']) if v else ''})
    return rows


def run_merger(base,overlay,work,outname):
    tool=shutil.which('fdtoverlay')
    if not tool:raise ValueError('R37_MISSING_REAL_FDTOVERLAY_TOOL')
    out=work/outname
    try:
        p=subprocess.run([tool,'-i',str(base),'-o',str(out),str(overlay)],
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False)
    except (OSError,subprocess.TimeoutExpired) as e:
        return {'outcome':'TOOL_EXECUTION_FAILED','reason':type(e).__name__},[]
    if p.returncode!=0 or not out.exists():
        return {'outcome':'FDTOVERLAY_APPLY_FAILED','exit_code':p.returncode,
                'reason':p.stderr.decode('utf-8','replace')[:550]},[]
    try:
        nodes=fdt_nodes(out.read_bytes())
    except Exception as e:
        return {'outcome':'MERGED_FDT_INVALID','reason':str(e)},[]
    finally:
        out.unlink(missing_ok=True)
    return {'outcome':'OFFLINE_APPLY_AND_PARSE_SUCCESS','nodes':len(nodes)},nodes


def write_reports(out,rows,metadata,run=None):
    out.mkdir(parents=True,exist_ok=True)
    def write_csv(name,fields,items):
        s=io.StringIO();w=csv.DictWriter(s,fieldnames=fields,lineterminator='\n');w.writeheader();w.writerows(items)
        (out/name).write_text(s.getvalue(),encoding='utf8')
    write_csv('R37_DTBO_16_INDEX.csv',list(rows[0]),rows)
    if run:
        for key,items in [('STOCK',run.get('stock_compare',[])),('R20',run.get('r20_compare',[]))]:
            if items:write_csv('R37_'+key+'_27_NODES.csv',list(items[0]),items)
    (out/'R37_RESULT.json').write_text(json.dumps(metadata,indent=2,sort_keys=True)+'\n')
    lines=['VEUX R37 - DTBO-Index und Offline-FDT-Zusammenfuehrung - Nur Diagnose',
        'R33 a/b: 16 Eintraege, Tabellen-Hashes identisch; VEUX Kandidat Index 0 einziges volles Root-Metadaten-Match.',
        'PEUX Index 3: SoC gleich, ABER Board-ID unterscheidet sich (0x20 statt 0x00).',
        'Bootloader-Auswahl NICHT bewiesen; UFS- und PMIC-Treiberprobe unter R20 NICHT bewiesen.',
        'R37_DEVICE_EVIDENCE_PRESENT='+str(metadata['r37_new_device_evidence_present']),
        'STOCK_MERGE='+metadata['stock_base_plus_index0_merge']['outcome'],
        'R20_MERGE='+metadata['r20_standalone_plus_index0_merge']['outcome'],
        'R20_VENDOR_ABI=UNPROVEN; BOOT=NO; FLASH=NO; BReNE_UNCHANGED=YES',
        'Hinweis: fdtoverlay offline simuliert nur die Anwendung der FDT-Daten; keine Bootloader-Entscheidung.',
    ]
    if run:
        lines.append('STOCK_TARGET_EXACT_MATCHES='+str(sum(x['status_match'] and x['compatible_match'] for x in run['stock_compare']))+'/27' if run.get('stock_compare') else 'STOCK_TARGET_EXACT_MATCHES=NOT_AVAILABLE')
        lines.append('R20_TARGET_EXACT_MATCHES='+str(sum(x['status_match'] and x['compatible_match'] for x in run['r20_compare']))+'/27' if run.get('r20_compare') else 'R20_TARGET_EXACT_MATCHES=NOT_AVAILABLE')
    (out/'R37_BERICHT_DE.txt').write_text('\n'.join(lines)+'\n',encoding='utf8')
    targets=[p for p in out.iterdir() if p.is_file()]
    (out/'SHA256SUMS.txt').write_text(''.join(f'{sha(p.read_bytes())}  {p.name}\n' for p in sorted(targets)),encoding='ascii')


def audit(bundle,out,device_path=None):
    verify_bundle(bundle)
    r33,table=verify_r33(bundle)
    r34,paths=verify_r34_r36(bundle)
    result={
        'schema':SCHEMA,'status':'R37_METADATA_UNIQUE_AWAIT_RAW_EVIDENCE',
        'r33_dtbo_entries_per_slot':16,'r33_slots_same_table_sha':True,
        'unique_root_metadata_candidate_index':0,'candidate_model':'Qualcomm Technologies, Inc. VEUX QRD NOPMI',
        'candidate0_sha256':ENTRY0_SHA,'r34_stock_node_count':754,'r34_stock_bound_node_count':503,
        'r36_ufs_nodes_with_build_evidence':2,'r36_pmic_nodes_with_source_evidence':25,
        'r37_new_device_evidence_present':False,
        'stock_base_plus_index0_merge':{'outcome':'NOT_ATTEMPTED_NO_RAW_INPUT'},
        'r20_standalone_plus_index0_merge':{'outcome':'NOT_ATTEMPTED_NO_RAW_INPUT'},
        'dtbo_bootloader_choice_proven':False,'r20_live_probe_proven':False,'vendor_abi_proven':False,
        'boot_ready':False,'flash_allowed':False,'kernel_built':False,
        'source_patch_created':False,'device_modified':False,'brene_changed':False,
        'limitations':['Unique DTBO root metadata is a candidate, NOT bootloader selection evidence.',
          'fdtoverlay offline is only a structural check, not a real R20 boot or probe.',
          'Generic matching UFS/PMIC nodes cannot prove final vendor ABI or ROM boot.'],
    }
    comparisons=None
    if device_path is not None:
        devicefiles=safe_zip(device_path,DEVICE_NAMES)
        live=parse_device(devicefiles,r33,paths)
        result['r37_new_device_evidence_present']=True
        comparisons={}
        with tempfile.TemporaryDirectory(prefix='r37-merge-') as t:
            wd=Path(t);stock=wd/'stock-base.dtb';overlay=wd/'index0.dtbo';r20=wd/'r20.dtb'
            stock.write_bytes(devicefiles['R37_VENDOR_BOOT_BASE.dtb'])
            overlay.write_bytes(devicefiles['R37_DTBO_CANDIDATE0.dtbo'])
            r20.write_bytes((bundle/'evidence/R20_VEUX.dtb').read_bytes())
            for name,base in [('stock',stock),('r20',r20)]:
                merge,nodes=run_merger(base,overlay,wd,name+'-merged.dtb')
                result[name+'_base_plus_index0_merge' if name=='stock' else 'r20_standalone_plus_index0_merge']=merge
                comparisons[name+'_compare']=compare_nodes(nodes,live['runtime_target_nodes']) if nodes else []
        result['status']='R37_RAW_STOCK_DTBO_AND_OFFLINE_MERGE_ANALYZED_BOOT_BLOCKED'
        if comparisons['stock_compare']:
            result['stock_27_exact_target_matches']=sum(x['compatible_match'] and x['status_match'] for x in comparisons['stock_compare'])
        if comparisons['r20_compare']:
            result['r20_27_exact_target_matches']=sum(x['compatible_match'] and x['status_match'] for x in comparisons['r20_compare'])
    write_reports(out,table,result,comparisons)
    print('R37_PROVENANCE=PASS; DTBO_TABLE=16; UNIQUE_VEUX_CANDIDATE=0; RAW_CAPTURE='+('YES' if device_path else 'NO')+'; BOOT=NO; FLASH=NO')
    return result


if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--bundle',type=Path,required=True)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--device-zip',type=Path)
    args=ap.parse_args()
    try:audit(args.bundle,args.out,args.device_zip)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile,json.JSONDecodeError) as e:
        raise SystemExit('R37_FAIL_CLOSED: '+str(e))
