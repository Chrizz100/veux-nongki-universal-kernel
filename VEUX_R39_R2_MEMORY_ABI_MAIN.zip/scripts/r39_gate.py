#!/usr/bin/env python3
"""VEUX R39: read-only source-pinned FDT reserved-memory and historical ABI provenance.

The stock/vendor-boot base plus the metadata-matched DTBO is a *simulation*.
Not a capture of the live stock FDT, not bootloader selection, not a R20 probe,
not a complete vendor ABI, and NEVER authorization to build or flash.
"""
from __future__ import annotations
import argparse
import collections
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import struct
import subprocess
import tempfile
import zipfile

import r34_gate
import r37_gate
import r38_gate

SCHEMA = 'VEUX_R39_PINNED_MEMORY_RESERVATION_ABI_PROVENANCE_V1'
PINS = {
    'evidence/VEUX_R30_ABI_ORIGINALMODULE_NACHWEIS_20261023.zip': '220492de584dc4a182c586561d2fb8a50e1e3e4305845434dfbdd8cfc3eb2625',
    'evidence/VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip': '05302cda83c6ef67e583ea5d881768e11665af0a39efaef62ae0ec5a47999479',
    'evidence/VEUX_R38_RUN_40080527188_ERGEBNIS.zip': '51fb5117cf6b86337470af8e8f291bfef82b52467d355e947f4ae74eb84011c0',
}
R38_REPORT_FILES = {'R38_BERICHT_DE.txt','R38_R35_65_AFTER_OVERLAY.csv','R38_RESULT.json',
    'R38_STOCK_BOUND_503.csv','R38_STOCK_R20_FDT_DIFFERENCES.csv','R38_TESTS.log',
    'R38_VENDOR_218_ABI_PRIORITY.csv','SHA256SUMS.txt'}
R30_FILES = {'LESEN_ZUERST_R30_DE.txt','R30_ORIGINAL_GERAETEBEFUND.json',
    'R30_2EF0_MODULQUELLE_NACHWEIS.json','R30_ABI_BUILD_ZUSAMMENFASSUNG.json',
    'R30_ORIGINALMODUL_ABI_ALLE_BUILDVARIANTEN.csv',
    'R30_ABI_109_EINDEUTIGE_ZIELSYMBOLE.csv','SHA256SUMS.txt'}
COLUMNS = {
    'R39_RESERVED_MEMORY.csv':['reservation_name','stock_node','r20_node','stock_address','stock_size',
        'r20_address','r20_size','stock_end_exclusive','r20_end_exclusive','stock_flags','r20_flags',
        'stock_reference_count','r20_reference_count','comparison','assessment'],
    'R39_INTERNAL_RESERVATION_OVERLAPS.csv':['tree','first','second','overlap_start',
        'overlap_end_exclusive','overlap_bytes','assessment'],
    'R39_MEMRESERVE_HEADER.csv':['tree','index','address','size','end_exclusive'],
    'R39_GPU_COOLING.csv':['path','stock_node_present','r20_node_present','stock_compatible',
        'r20_compatible','stock_status','r20_status','stock_phandle','r20_phandle',
        'stock_thermal_reference_count','r20_thermal_reference_count','interpretation'],
    'R39_R38_9_DRIVER_EXCEPTIONS.csv':['path','stock_drivers','stock_compatible',
        'r20_compatible','stock_status','r20_status','classification','interpretation'],
    'R39_THERMAL_STATUS_DIFF.csv':['path','stock_status','r20_status','limitation'],
    'R39_VENDOR_218_REVIEW.csv':['vendor_file_path','load_list','historical_matched',
        'historical_crc_mismatched','historical_exports_absent','historical_total_imports',
        'runtime_module_name_seen','runtime_file_provenance','review_priority','assessment'],
}


def digest(b:bytes)->str:return hashlib.sha256(b).hexdigest()


def safe_zip(path:Path, expected:set[str], maxzip:int=4_000_000, maxout:int=5_000_000)->dict[str,bytes]:
    if not path.is_file() or path.stat().st_size>maxzip:raise ValueError('R39_ZIP_SIZE')
    result={};total=0
    with zipfile.ZipFile(path) as z:
        members=z.infolist();names=[m.filename for m in members]
        if len(names)!=len(expected) or set(names)!=expected or len(set(names))!=len(names):
            raise ValueError('R39_ZIP_MEMBER_MISMATCH_OR_DUPLICATE')
        for member in members:
            p=PurePosixPath(member.filename)
            if (member.is_dir() or p.is_absolute() or '..' in p.parts or
                '\\' in member.filename or stat.S_ISLNK(member.external_attr>>16)):
                raise ValueError('R39_ZIP_UNSAFE_PATH')
            total+=member.file_size
            if total>maxout or member.file_size>maxout:raise ValueError('R39_ZIP_DECOMPRESSION_LIMIT')
            result[member.filename]=z.read(member)
        if z.testzip():raise ValueError('R39_ZIP_CRC')
    return result


def verify_sums(files:dict[str,bytes], skip:set[str]=set())->None:
    lines=files['SHA256SUMS.txt'].decode('ascii').splitlines()
    parsed={}
    for line in lines:
        parts=line.split('  ',1)
        if len(parts)!=2 or not re.fullmatch('[0-9a-f]{64}',parts[0]) or parts[1] in parsed:
            raise ValueError('R39_SUMS_FORMAT')
        parsed[parts[1]]=parts[0]
    if set(parsed)!=(set(files)-{'SHA256SUMS.txt'}-skip):raise ValueError('R39_SUMS_SET')
    if any(digest(files[f])!=sha for f,sha in parsed.items()):raise ValueError('R39_SUMS_CONTENT')


def verify_package(root:Path)->dict:
    man=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf8'))
    if man.get('schema')!='VEUX_R39_IMMUTABLE_READONLY_PACKAGE_V1':raise ValueError('R39_MANIFEST_SCHEMA')
    files=man.get('files',{})
    actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}
    if actual!=set(files)|{'MANIFEST_SHA256.json'}:raise ValueError('R39_MANIFEST_FILE_SET')
    if not set(PINS).issubset(files):raise ValueError('R39_MISSING_ORIGINAL_EVIDENCE')
    for p,meta in files.items():
        path=PurePosixPath(p)
        if (path.is_absolute() or '..' in path.parts or '\\' in p or
            not re.fullmatch('[0-9a-f]{64}',str(meta.get('sha256','')))):
            raise ValueError('R39_BAD_MANIFEST_ENTRY')
        full=root/p
        if (full.is_symlink() or not full.is_file() or full.stat().st_size!=meta.get('bytes') or
            digest(full.read_bytes())!=meta['sha256']):raise ValueError('R39_MANIFEST_HASH:'+p)
    for rel,pin in PINS.items():
        if digest((root/rel).read_bytes())!=pin:raise ValueError('R39_PIN_CHANGED:'+rel)
    return man


def verify_original_reports(root:Path):
    verify_package(root)
    r38=safe_zip(root/'evidence/VEUX_R38_RUN_40080527188_ERGEBNIS.zip',R38_REPORT_FILES)
    verify_sums(r38)
    result=json.loads(r38['R38_RESULT.json'])
    expected={
        'schema':'VEUX_R38_OVERLAY_STRUCTURAL_VENDOR_ABI_TRIAGE_V1',
        'status':'R38_REAL_STOCK_R20_MERGED_STRUCTURAL_AND_HISTORICAL_VENDOR_ABI_COMPARED_BOOT_BLOCKED',
        'stock_merged_nodes':2652,'r20_merged_nodes':2200,
        'stock_runtime_bound_node_total':503,'r35_65_total':65,
        'vendor_historical_module_files':218,'vendor_historical_imports':14648,
        'vendor_crc_matches':6960,'vendor_crc_mismatches':7653,'vendor_missing_exports':35,
        'boot_ready':False,'flash_allowed':False}
    if any(result.get(k)!=v for k,v in expected.items()):raise ValueError('R39_ORIGINAL_R38_REPORT_CHANGED')
    r30=safe_zip(root/'evidence/VEUX_R30_ABI_ORIGINALMODULE_NACHWEIS_20261023.zip',R30_FILES)
    verify_sums(r30)
    capture=json.loads(r30['R30_ORIGINAL_GERAETEBEFUND.json'])
    deployed=json.loads(r30['R30_2EF0_MODULQUELLE_NACHWEIS.json'])
    variants=json.loads(r30['R30_ABI_BUILD_ZUSAMMENFASSUNG.json'])
    if (capture['schema']!='VEUX_R30_VENDOR_BOOT_MODULE_PROVENANCE_V1' or
        capture['conclusion']['actual_loading_path_proven'] is not False or
        capture['conclusion']['vendor_abi_proven'] is not False or
        capture['loaded_build_ids']!={'rmnet_shs':'52967b0490abea75','rmnet_offload':'3e7d408d3146fb8c'} or
        {k:v['build_id'] for k,v in deployed['modules'].items()}!=capture['loaded_build_ids'] or
        variants['variants']['R20_R11']['module_symvers_sha256']!=r38_gate.ORIGINAL_HASHES['evidence/R20_Module.symvers']):
        raise ValueError('R39_R30_PROVENANCE_DIVERGED')
    bound=list(csv.DictReader(io.StringIO(r38['R38_STOCK_BOUND_503.csv'].decode('utf8'))))
    vendor=list(csv.DictReader(io.StringIO(r38['R38_VENDOR_218_ABI_PRIORITY.csv'].decode('utf8'))))
    fdt=list(csv.DictReader(io.StringIO(r38['R38_STOCK_R20_FDT_DIFFERENCES.csv'].decode('utf8'))))
    if (len(bound)!=503 or len(vendor)!=218 or len(fdt)!=499 or
        sum(b['classification']!='COMPAT_OVERLAP_AND_STATUS_MATCH' for b in bound)!=9):
        raise ValueError('R39_R38_ORIGINAL_MATRIX_COUNT_DIVERGED')
    return result,bound,vendor,fdt,capture,deployed,variants


def safe_extract_r38(root:Path,dest:Path)->None:
    inp=root/'evidence/VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip'
    if inp.stat().st_size>4_000_000:raise ValueError('R39_R38_NESTED_TOO_BIG')
    total=0
    with zipfile.ZipFile(inp) as z:
        members=z.infolist();paths=[f.filename for f in members]
        if len(members)!=15 or len(set(paths))!=15:raise ValueError('R39_R38_NESTED_FILES')
        for f in members:
            p=PurePosixPath(f.filename)
            if (f.is_dir() or p.is_absolute() or '..' in p.parts or '\\' in f.filename or
                stat.S_ISLNK(f.external_attr>>16)):
                raise ValueError('R39_R38_NESTED_UNSAFE')
            total+=f.file_size
            if f.file_size>7_000_000 or total>15_000_000:raise ValueError('R39_R38_NESTED_LIMIT')
        if z.testzip():raise ValueError('R39_R38_NESTED_CRC')
        z.extractall(dest)
    r38_gate.verify_file_set_and_sha(dest)


def parse_fdt_selected(blob:bytes):
    """Parse FDT without copying unbounded property contents. Return a safe property subset."""
    if len(blob)<40 or len(blob)>8_000_000:raise ValueError('R39_FDT_SIZE')
    magic,total,structoff,stringoff,reserveoff,version,last,boot,stringbytes,structbytes=struct.unpack_from('>10I',blob)
    if (magic!=0xd00dfeed or not 40<=total<=len(blob) or version<16 or version>20 or
        not 40<=structoff<total or not 40<=stringoff<total or
        not 40<=reserveoff<total or structoff+structbytes>total or
        stringoff+stringbytes>total or structbytes<8):
        raise ValueError('R39_FDT_BAD_HEADER')
    strings=blob[stringoff:stringoff+stringbytes]
    stack=[];nodes={};pos=structoff;end=structoff+structbytes
    selected={'#address-cells','#size-cells','reg','no-map','reusable','size','alloc-ranges',
        'alignment','phandle','linux,phandle','compatible','status','memory-region',
        'memory-region-names','cooling-device','cooling-min-state','cooling-max-state',
        'qcom,reserved-memory','qcom,mem-acc'}
    ended=False
    while pos+4<=end:
        tok=struct.unpack_from('>I',blob,pos)[0];pos+=4
        if tok==1:
            stop=blob.find(b'\0',pos,end)
            if stop<pos or stop-pos>250:raise ValueError('R39_FDT_BAD_NODE_NAME')
            name=blob[pos:stop].decode('utf8','replace');pos=(stop+4)&~3
            if not stack: path='/'
            else: path=(stack[-1].rstrip('/')+'/'+name)
            if path in nodes or len(nodes)>10000 or len(stack)>70:raise ValueError('R39_FDT_DUPLICATE_OR_DEPTH')
            stack.append(path);nodes[path]={}
        elif tok==2:
            if not stack:raise ValueError('R39_FDT_STACK_NEGATIVE')
            stack.pop()
        elif tok==3:
            if pos+8>end or not stack:raise ValueError('R39_FDT_BAD_PROP_HEADER')
            size,nameoff=struct.unpack_from('>II',blob,pos);pos+=8
            if size>4_000_000 or pos+size>end or nameoff>=len(strings):raise ValueError('R39_FDT_BAD_PROP_BOUNDS')
            nend=strings.find(b'\0',nameoff)
            if nend<0:raise ValueError('R39_FDT_BAD_PROP_NAME')
            name=strings[nameoff:nend].decode('ascii','replace')
            if (name in selected or name.startswith('memory-region')) and size<=4096:
                # Duplicate relevant DT properties are malformed and must fail closed.
                if name in nodes[stack[-1]]:raise ValueError('R39_FDT_DUPLICATE_PROPERTY')
                nodes[stack[-1]][name]=blob[pos:pos+size]
            pos=(pos+size+3)&~3
        elif tok==4:pass
        elif tok==9:
            if stack:raise ValueError('R39_FDT_UNBALANCED_TREE')
            ended=True;break
        else:raise ValueError('R39_FDT_UNKNOWN_TOKEN')
    if not ended:raise ValueError('R39_FDT_END_MISSING')
    reserved=[];idx=reserveoff
    for i in range(512):
        if idx+16>total:raise ValueError('R39_FDT_MEMRSV_BOUNDS')
        addr,size=struct.unpack_from('>QQ',blob,idx);idx+=16
        if addr==size==0:break
        if size==0 or addr+size>2**64:raise ValueError('R39_FDT_MEMRSV_OVERFLOW')
        reserved.append((addr,size))
    else:raise ValueError('R39_FDT_MEMRSV_MISSING_TERMINATOR')
    return nodes,reserved


def u32(raw:bytes|None,default:int)->int:
    return (struct.unpack('>I',raw)[0] if raw is not None and len(raw)==4 else default)


def hex64(n:int|None)->str:return f'0x{n:016x}' if isinstance(n,int) else ''


def prop_str(b:bytes|None)->str:
    if b is None:return ''
    return ';'.join(x.decode('utf8','replace')[:140] for x in b.split(b'\0') if x)[:500]


def extract_reserved(nodes:dict)->dict:
    root=nodes.get('/',{});parent=nodes.get('/reserved-memory',{})
    ac=u32(parent.get('#address-cells'),u32(root.get('#address-cells'),2))
    sc=u32(parent.get('#size-cells'),u32(root.get('#size-cells'),1))
    if ac not in (1,2) or sc not in (1,2):raise ValueError('R39_UNSUPPORTED_ADDRESS_CELLS')
    cell_bytes=(ac+sc)*4
    data={}
    for path,props in nodes.items():
        if not path.startswith('/reserved-memory/') or path.count('/')!=2:continue
        key=path.rsplit('/',1)[-1].split('@',1)[0]
        reg=props.get('reg')
        start=None;size=None;state='NO_REG_DYNAMIC_OR_UNKNOWN';reg_count=0
        if reg is not None:
            if len(reg)%cell_bytes or not len(reg) or len(reg)>cell_bytes*32:
                state='REG_PARSE_ERROR'
            else:
                values=[]
                for off in range(0,len(reg),cell_bytes):
                    cells=struct.unpack('>'+('I'*(ac+sc)),reg[off:off+cell_bytes])
                    addr=0;length=0
                    for x in cells[:ac]:addr=(addr<<32)|x
                    for x in cells[ac:]:length=(length<<32)|x
                    values.append((addr,length))
                reg_count=len(values)
                if len(values)==1:
                    start,size=values[0]
                    state='STATIC_REG' if size>0 and start+size<=2**64 else 'REG_ZERO_OR_OVERFLOW'
                else:state='MULTIPLE_REG_RANGES'
        refs=[]
        ph=u32(props.get('phandle'),u32(props.get('linux,phandle'),0))
        for nodepath,otherprops in nodes.items():
            if ph==0 or nodepath==path:continue
            for pn,raw in otherprops.items():
                if pn=='memory-region' or pn.startswith('memory-region-'):
                    if len(raw)%4==0 and ph in struct.unpack('>'+'I'*(len(raw)//4),raw):
                        refs.append(f'{nodepath}:{pn}')
        entry={'path':path,'label':key,'address':start,'size':size,'flags':
            ';'.join(f for f in ('no-map','reusable') if f in props) or 'not-declared',
            'state':state,'reference_count':len(set(refs)),'references':sorted(set(refs)),
            'reg_ranges':reg_count,'declared_size':props.get('size') is not None}
        data[path]=entry
    return data


def reservations_report(stock:dict,r20:dict):
    def group(rows):
        d=collections.defaultdict(list)
        for x in rows.values():d[x['label']].append(x)
        return d
    a=group(stock);b=group(r20);out=[]
    for label in sorted(set(a)|set(b)):
        left=a.get(label,[]);right=b.get(label,[])
        maxlen=max(len(left),len(right))
        for i in range(maxlen):
            s=left[i] if i<len(left) else None
            r=right[i] if i<len(right) else None
            if not s:cmp='R20_ONLY'
            elif not r:cmp='STOCK_ONLY'
            elif s['state']!='STATIC_REG' or r['state']!='STATIC_REG':cmp='INDETERMINATE_NONSTATIC_REG'
            elif (s['address'],s['size'],s['flags'])==(r['address'],r['size'],r['flags']):cmp='PHYSICAL_RANGE_AND_FLAGS_MATCH'
            elif s['address']!=r['address'] and s['size']==r['size']:cmp='RELOCATED_SAME_SIZE'
            elif s['size']!=r['size'] or s['flags']!=r['flags']:cmp='SIZE_OR_FLAGS_DIFFER'
            else:cmp='PHYSICAL_RANGE_DIFFERENT'
            out.append(dict(reservation_name=label+(f'#{i+1}' if maxlen>1 else ''),
                stock_node=s['path'] if s else '',r20_node=r['path'] if r else '',
                stock_address=hex64(s['address']) if s else '',
                r20_address=hex64(r['address']) if r else '',
                stock_size=hex64(s['size']) if s else '',
                r20_size=hex64(r['size']) if r else '',
                stock_end_exclusive=hex64(s['address']+s['size']) if s and s['address'] is not None and s['size'] is not None else '',
                r20_end_exclusive=hex64(r['address']+r['size']) if r and r['address'] is not None and r['size'] is not None else '',
                stock_flags=s['flags'] if s else '',r20_flags=r['flags'] if r else '',
                stock_reference_count=s['reference_count'] if s else '',
                r20_reference_count=r['reference_count'] if r else '',
                comparison=cmp,assessment='OFFLINE_STRUCTURAL_ONLY_NOT_RUNTIME_FDT'))
    return out


def detect_overlaps(label:str,regions:dict):
    ranges=[(v['address'],v['address']+v['size'],v['path']) for v in regions.values()
        if v['state']=='STATIC_REG']
    ranges.sort();out=[]
    for i,(start,end,path) in enumerate(ranges):
        for prev_start,prev_end,prev_path in ranges[:i]:
            if prev_end<=start:continue
            overlap_start=max(start,prev_start);overlap_end=min(end,prev_end)
            if overlap_start>=overlap_end:continue
            out.append({'tree':label,'first':prev_path,'second':path,
                'overlap_start':hex64(overlap_start),'overlap_end_exclusive':hex64(overlap_end),
                'overlap_bytes':overlap_end-overlap_start,
                'assessment':'INTERVAL_OVERLAP_DETECTED_CHECK_IF_INTENDED_NOT_AUTO_BOOT_FAILURE'})
    return out


def inspect_gpu_cooling(stock:dict,r20:dict):
    paths={p for p in set(stock)|set(r20) if p.endswith('/gfx-cdev')}
    out=[]
    for path in sorted(paths):
        x=stock.get(path);y=r20.get(path)
        def count_refs(nodes,entry):
            if entry is None:return 0
            ph=u32(entry.get('phandle'),u32(entry.get('linux,phandle'),0))
            if ph==0:return 0
            n=0
            for nodepath,props in nodes.items():
                if '/thermal-zones/' not in nodepath or 'cooling-device' not in props:continue
                raw=props['cooling-device']
                if len(raw)%4==0 and ph in struct.unpack('>'+'I'*(len(raw)//4),raw):n+=1
            return n
        # A gfx-cdev node can exist in only one of the two offline FDTs.
        # Missing nodes are not the same as present nodes without a status
        # property: guard *before* calling .get(), never in the `or` fallback.
        stock_status = ((prop_str(x.get('status')) or 'enabled-default')
                        if x is not None else 'MISSING')
        r20_status = ((prop_str(y.get('status')) or 'enabled-default')
                      if y is not None else 'MISSING')
        out.append({'path':path,'stock_node_present':str(x is not None),
            'r20_node_present':str(y is not None),
            'stock_compatible':prop_str(x.get('compatible')) if x is not None else '',
            'r20_compatible':prop_str(y.get('compatible')) if y is not None else '',
            'stock_status':stock_status,
            'r20_status':r20_status,
            'stock_phandle':u32(x.get('phandle'),0) if x is not None else '',
            'r20_phandle':u32(y.get('phandle'),0) if y is not None else '',
            'stock_thermal_reference_count':count_refs(stock,x),
            'r20_thermal_reference_count':count_refs(r20,y),
            'interpretation':'DIFFERENCE_UNDER_TEST_NO_DRIVER_FAULT_CONFIRMED'})
    return out


def r38_exceptions(bound:list):
    out=[]
    for x in bound:
        if x['classification']=='COMPAT_OVERLAP_AND_STATUS_MATCH':continue
        if (x['classification']=='ENABLED_STOCK_DISABLED_R20' and
                x['stock_compatible']=='qcom,jtagv8-mm'):
            label='DEBUG_JTAG_NOT_A_CORE_BOOT_TREEDRIVER_GAP'
        elif x['path'].endswith('/gfx-cdev'):
            label='GPU_REGULATOR_COOLING_MAP_FURTHER_REVIEW'
        else:label='UNCLASSIFIED_REQUIRE_MANUAL_REVIEW'
        out.append({**{k:x[k] for k in COLUMNS['R39_R38_9_DRIVER_EXCEPTIONS.csv'] if k in x},
                    'interpretation':label})
    if len(out)!=9:raise ValueError('R39_NINE_EXCEPTIONS_CHANGED')
    return out


def historic_modules(vendor:list, deployed:dict):
    modules=deployed['modules'];out=[]
    for x in vendor:
        name=Path(x['vendor_file_path']).stem
        if name in modules:priority='1_BUILD_ID_ALIGNED_WITH_2EF0_NOT_FILE_ORIGIN_PROVEN'
        elif any(n in name for n in ('msm_drm','msm_kgsl','msm_ion','ipam','platform_dlkm')):
            priority='2_HISTORIC_IMPACT_CHECK_BEFORE_BOOT_APPROVAL'
        else:priority='3_LISTED_HISTORICAL_NOT_LOADED_PROVEN'
        out.append({'vendor_file_path':x['vendor_file_path'],'load_list':x['load_list'],
            'historical_matched':x['historical_matched'],
            'historical_crc_mismatched':x['historical_crc_mismatched'],
            'historical_exports_absent':x['historical_exports_absent'],
            'historical_total_imports':x['historical_total_imports'],
            'runtime_module_name_seen':x['runtime_module_name_seen'],
            'runtime_file_provenance':'NO_PROOF_FROM_VENDOR_PATH',
            'review_priority':priority,
            'assessment':'HISTORIC_CRC_ONLY_NO_CURRENT_LOAD_OR_R20_BOOT_PROOF'})
    return sorted(out,key=lambda x:(x['review_priority'],
        -int(x['historical_exports_absent']),-int(x['historical_crc_mismatched']),x['vendor_file_path']))


def write_csv(path:Path,rows:list,fields:list):
    s=io.StringIO();writer=csv.DictWriter(s,fieldnames=fields,lineterminator='\n',extrasaction='ignore')
    writer.writeheader();writer.writerows(rows);path.write_text(s.getvalue(),encoding='utf8')


def run_merge(source:Path,overlay:Path,out:Path)->bytes:
    command=shutil.which('fdtoverlay')
    if not command:raise ValueError('R39_FDTOVERLAY_NOT_INSTALLED')
    result=subprocess.run([command,'-i',str(source),'-o',str(out),str(overlay)],
        stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=45,check=False)
    if result.returncode!=0 or not out.is_file():
        raise ValueError('R39_OFFLINE_OVERLAY_FAILED:'+result.stderr.decode('utf8','replace')[:180])
    content=out.read_bytes()
    if len(content)>8_000_000:raise ValueError('R39_MERGED_FDT_TOO_LARGE')
    return content


def audit(root:Path,device:Path,out:Path):
    prior,bound, vendor, differences,capture,deployed,variants=verify_original_reports(root)
    with tempfile.TemporaryDirectory(prefix='r39-fdt-noflash-') as td:
        tmp=Path(td);nested=tmp/'r38-main';nested.mkdir()
        safe_extract_r38(root,nested)
        r33,r34,targets,old65,r37,r21counts,r21total=r38_gate.verify_originals(nested)
        if len(r21counts)!=218 or sum(r21total.values())!=14648:
            raise ValueError('R39_VENDOR_HISTORIC_ANCHOR')
        device_files=r37_gate.safe_zip(device,r37_gate.DEVICE_NAMES)
        r37_gate.parse_device(device_files,r33,targets)
        stockbase=tmp/'stock_vendor_boot.dtb';over=tmp/'candidate0.dtbo';r20base=tmp/'r20.dtb'
        stockbase.write_bytes(device_files['R37_VENDOR_BOOT_BASE.dtb'])
        over.write_bytes(device_files['R37_DTBO_CANDIDATE0.dtbo'])
        r20base.write_bytes((nested/'evidence/R20_VEUX.dtb').read_bytes())
        stock_merged=run_merge(stockbase,over,tmp/'stock_merged.dtb')
        r20_merged=run_merge(r20base,over,tmp/'r20_merged.dtb')
        snodes,sheader=parse_fdt_selected(stock_merged)
        rnodes,rheader=parse_fdt_selected(r20_merged)
        if len(snodes)!=2652 or len(rnodes)!=2200:
            raise ValueError('R39_ORIGINAL_MERGED_COUNT_CHANGED')
        # Crucial distinction: node shape parity is NOT byte equality or runtime binding.
        stock_meta=r37_gate.fdt_nodes(stock_merged)
        r20_meta=r37_gate.fdt_nodes(r20_merged)
        original_bound=r38_gate.compare_bound_nodes(r34,r20_meta)
        origcls=collections.Counter(row['classification'] for row in original_bound)
        if origcls!={'COMPAT_OVERLAP_AND_STATUS_MATCH':494,
                'ENABLED_STOCK_DISABLED_R20':8,'PATH_MISSING':1}:
            raise ValueError('R39_503_BOUND_MATRIX_NOT_REPRODUCED')
        old65now=r38_gate.compare_r35_65(old65,r20_meta,r34)
        if sum(x['after_R37_overlay']=='COMPAT_OVERLAP_AND_STATUS_MATCH' for x in old65now)!=65:
            raise ValueError('R39_R35_REGRESSION')
        sreserv=extract_reserved(snodes);rreserv=extract_reserved(rnodes)
        if not sreserv or not rreserv:raise ValueError('R39_RESERVED_MEMORY_UNAVAILABLE')
        mem=reservations_report(sreserv,rreserv)
        overlaps=detect_overlaps('STOCK_MERGED',sreserv)+detect_overlaps('R20_MERGED',rreserv)
        headerrows=[]
        for tree,header in [('STOCK_MERGED',sheader),('R20_MERGED',rheader)]:
            for i,(addr,size) in enumerate(header):
                headerrows.append({'tree':tree,'index':i,'address':hex64(addr),
                    'size':hex64(size),'end_exclusive':hex64(addr+size)})
        gfx=inspect_gpu_cooling(snodes,rnodes)
        if not gfx:raise ValueError('R39_GFX_COOLING_NODE_NOT_FOUND')
        exceptions=r38_exceptions(original_bound)
        therm=[{'path':x['path'],'stock_status':x['stock_status'],
                'r20_status':x['r20_status'],
                'limitation':'STATUS_ONLY_NOT_THERMAL_DRIVER_OR_SENSOR_FAILURE'}
                for x in differences if x['difference']=='STATUS_DIFFER' and '/thermal-zones/' in x['path']]
        if len(therm)!=9:raise ValueError('R39_THERMAL_STATUS_COUNT')
        modules=historic_modules(vendor,deployed)
    summary=collections.Counter(m['comparison'] for m in mem)
    results={
        'schema':SCHEMA,
        'status':'R39_READONLY_RESERVED_MEMORY_GPU_COOLING_AND_HISTORICAL_MODULE_PROVENANCE_REVIEW_BOOT_BLOCKED',
        'r38_sha256':PINS['evidence/VEUX_R38_RUN_40080527188_ERGEBNIS.zip'],
        'r30_sha256':PINS['evidence/VEUX_R30_ABI_ORIGINALMODULE_NACHWEIS_20261023.zip'],
        'r37_device_verified_again':True,'index0_offline_merged_stock_nodes':2652,
        'index0_offline_merged_r20_nodes':2200,'r35_65_after_overlay_matching':65,
        'stock_bound_matching_compatible_and_status':494,
        'remaining_stock_bound_structural_exceptions':9,'jtag_debug_exceptions':8,
        'gfx_cooling_bound_node_missing_r20':1,
        'stock_reserved_nodes_examined':len(sreserv),'r20_reserved_nodes_examined':len(rreserv),
        'reservation_comparison_counts':dict(summary),'same_tree_reservation_overlap_events':len(overlaps),
        'fdt_header_memory_reservations_stock':len(sheader),
        'fdt_header_memory_reservations_r20':len(rheader),
        'thermals_status_difference_nodes':len(therm),
        'r30_loaded_build_id_matched_archive_modules':2,
        'r30_module_full_file_identity_or_load_path_proven':False,
        'historical_vendor_files_reviewed':len(modules),'historical_crc_mismatch_count':7653,
        'historical_absent_exports':35,'vendor_modules_load_is_runtime_load_proof':False,
        'stock_vendor_boot_dtbo_composition_is_live_fdt_proof':False,
        'r20_source_changed':False,'device_modified':False,'brene_changed':False,
        'vendor_abi_proven':False,'boot_ready':False,'flash_allowed':False,'kernel_built':False,
        'limitations':[
            'The FDTs were produced offline from the partition base and DTBO index 0; neither one proves the live Android bootloader FDT or actual R20 probes.',
            'A detected address change or overlap is descriptive; only validation against actual boot use, firmware allocation, and memblock reservations can prove harm.',
            'A 2EF0 module Build-ID association does not prove the exact byte-identical loaded pathname or loading sequence.',
            'Historical vendor modules.load and CRC differences cannot establish which module was used at boot.',
            'The vendor ABI, scheduler integration, actual boot, SELinux, BakaSU, SUSFS and NoMount remain unproven.'
        ]}
    out.mkdir(parents=True,exist_ok=True)
    output={
        'R39_RESERVED_MEMORY.csv':mem,
        'R39_INTERNAL_RESERVATION_OVERLAPS.csv':overlaps,
        'R39_MEMRESERVE_HEADER.csv':headerrows,
        'R39_GPU_COOLING.csv':gfx,
        'R39_R38_9_DRIVER_EXCEPTIONS.csv':exceptions,
        'R39_THERMAL_STATUS_DIFF.csv':therm,
        'R39_VENDOR_218_REVIEW.csv':modules,
    }
    for name,rows in output.items():write_csv(out/name,rows,COLUMNS[name])
    (out/'R39_RESULT.json').write_text(json.dumps(results,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf8')
    report=[
        'VEUX R39 – PINNED MEMORY / GPU-COOLING / HISTORICAL ABI REVIEW – KEINE FLASHFREIGABE',
        'R37+R38 echte DTBO-0-Reproduktion: Stock 2652 Knoten, R20 2200 Knoten (OFFLINE).',
        'R35: 65/65 alte Verdachtsfaelle strukturell geloest. Unter 503 Stock-Bindungen: 494 gleich, 8 JTAG-Debug deaktiviert, 1 gfx-cdev-Pfad fehlt.',
        'Reservierte Speicherbereiche geprueft: STOCK='+str(len(sreserv))+'; R20='+str(len(rreserv))+'.',
        'Physische DT-Reservierungen im Header: STOCK='+str(len(sheader))+'; R20='+str(len(rheader))+'.',
        'Verglichene Reservierungen: '+', '.join(f'{k}={v}' for k,v in sorted(summary.items())),
        'Innerhalb der jeweiligen FDT erkannte Intervall-Ueberlappungen: '+str(len(overlaps))+' (NICHT automatisch ein Bootfehler).',
        'GPU-Regler-Cooling: '+str(len(gfx))+' Knotenpaare dokumentiert; Gleichwertigkeit NICHT aus dem Pfadnamen ableitbar.',
        'Thermal-Zones: '+str(len(therm))+' Aktivierungsstatus-Unterschiede; keine pauschale Aktivierung.',
        'Vendor: 218 historische Moduldateien, 7653 CRC-Abweichungen, 35 fehlende Exporte.',
        'R30: rmnet_shs und rmnet_offload Build-ID bezieht sich auf 2EF0-Originalarchiv; aktiver Ladepfad NICHT bewiesen.',
        'Weder Stock- noch R20-OFFLINE-FDT ist ein exakter Live-Bootnachweis. Keine Quellpatches, kein Build, kein Flash.',
        'BReNE, BakaSU, SUSFS, NoMount nicht veraendert. Flash bleibt gesperrt.',
    ]
    (out/'R39_BERICHT_DE.txt').write_text('\n'.join(report)+'\n',encoding='utf8')
    names=sorted(f.name for f in out.iterdir() if f.is_file())
    (out/'SHA256SUMS.txt').write_text(''.join(f'{digest((out/n).read_bytes())}  {n}\n' for n in names),encoding='ascii')
    return results


def main():
    p=argparse.ArgumentParser(description='Read only. Never build or flash.')
    p.add_argument('--bundle',type=Path,required=True)
    p.add_argument('--device-zip',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    try:
        r=audit(args.bundle,args.device_zip,args.out)
    except Exception as exc:
        raise SystemExit('R39_FAIL_CLOSED:'+str(exc)[:350]) from None
    print('R39_SOURCE_PROVENANCE=PASS; RESERVED_STOCK='+str(r['stock_reserved_nodes_examined'])+
          '; RESERVED_R20='+str(r['r20_reserved_nodes_examined'])+
          '; R35_65=RESOLVED; VENDOR=HISTORICAL_218; BOOT=NO; FLASH=NO')


if __name__=='__main__':main()
