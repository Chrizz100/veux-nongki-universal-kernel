VEUX R39 – READ-ONLY MEMORY/COOLING/ABI-REVIEW, 24.10.2026
======================================================

GitHub-Repository: Chrizz100/veux-nongki-universal-kernel

Dateien für den GitHub-Upload:
  In das Repository-Hauptverzeichnis (Root/main), ZIP UNVERÄNDERT:
    VEUX_R39_MEMORY_ABI_MAIN.zip
  Nach .github/workflows/:
    VEUX_R39_MEMORY_ABI_GATE.yml

KEINE neue Termux-Datei notwendig. Der Workflow benötigt die BEREITS im
Repository-Root vorhandene Datei VEUX_R37_DEVICE_EVIDENCE.zip.
Diese Datei wurde beim erfolgreichen R37- und R38-Lauf verwendet.

Anschließend GitHub Actions > VEUX R39 ... > Run workflow.
Nicht die alten GitHub-Runs 'Re-run' verwenden.

PRÜFUMFANG
- R30 2EF0-Modulprovenienz + R38 GitHub-Originalergebnisse gesichert
- R37-Stock-VendorBoot-Basis und VEUX-DTBO-Index 0 offline anwenden
- R20-DTB mit demselben DTBO-Index 0 offline anwenden
- FDT reserved-memory: reg-Start, Groesse, no-map, reusable, Referenzzahl
- FDT-Header-Memoryreservierungen sowie Adress-Ueberlappungen
- 9 R38-Stock-Treiberbindungen: 8 JTAG und 1 gfx-cdev
- 9 thermische Statusdifferenzen
- 218 HISTORISCHE Vendor-Module und 2EF0 RMNET-Build-ID-Hinweise

SICHERHEIT
- KEIN R20-Kernelbuild, KEIN Flash, KEIN aktiver FDT-Export aus Android
- KEIN Root auf GitHub, KEIN Umschreiben der Partitionen
- KEINE Aenderungen an BReNE, BakaSU, SUSFS oder NoMount
- KEINE Bootloader-DTBO-Auswahl, Live-R20-Treiberprobe oder Vendor-ABI-Freigabe
- Roh-DTB/DTBO bleiben nur temporaer, Ausgaben sind CSV/TXT/JSON

Die im GitHub-Run ermittelten Memory-/ABI-Matrizen sind Befunde, KEINE
Boot- oder Flashfreigabe. Die relevante Firmware-FDT-Zusammenfuehrung
wird OFFLINE emuliert; daraus folgt keine reale Bootloaderentscheidung.

R39 R2: Behebt ausschliesslich den NoneType-Fehler in inspect_gpu_cooling bei einem in Stock oder R20 fehlenden /gfx-cdev Knoten.
Neuer Workflow: VEUX_R39_R2_MEMORY_ABI_GATE.yml. Neue Main-ZIP: VEUX_R39_R2_MEMORY_ABI_MAIN.zip.
Die unveraenderten R30-/R38-Rohbelege und R37-Geräte-ZIP bleiben unveraendert. Keine Quellpatches, kein Flash.
Der fruehere rote Run 40082723502 wurde im R39-R2-Paket als Regression dokumentiert.
