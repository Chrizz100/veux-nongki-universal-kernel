set -euo pipefail
python3 -B "$M26_DIR/Tools/m26_rpm_sleep.py" package \
  --m25-tool "$M25_DIR/Tools/m25_config.py" \
  --r25-tool "$R25_DIR/Tools/r25_tzlog.py" \
  --r24-tool "$R24_DIR/Tools/r24_memory.py" \
  --r23-tool "$R23_DIR/Tools/r23_fingerprint.py" \
  --r21-package-tool "$R21_SCHED_DIR/Tools/r21_package.py" \
  --build "$R16_REPAIR_OUTPUT" \
  --packager-tool "$R21_PACK_DIR/Tools/boot_ak3_plan.py" \
  --work "$GITHUB_WORKSPACE/r46-m26-pack-work" --output "$R21_PACKAGE_OUTPUT"
