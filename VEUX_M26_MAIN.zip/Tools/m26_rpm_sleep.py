#!/usr/bin/env python3
"""Preserve unsent RPM sleep requests while retaining every M25-R2 build and ABI gate."""
import argparse
import hashlib
import importlib.util
import json
import mmap
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATUS = 'M26_FULL_RPM_SLEEP_M25_CONFIG_1423_CRCS_37_MODULES_PASS_NOFLASH'
UNITS = ['drivers/rpmsg/rpm-smd', 'drivers/soc/qcom/system_pm_rpm']
ERROR_MESSAGE = b'Failed to send sleep request: %d\n'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for data in iter(lambda: f.read(1048576), b''):
            h.update(data)
    return h.hexdigest()


def profile():
    return json.loads((ROOT / 'References/PROFILE.json').read_text())


def pins():
    return json.loads((ROOT / 'References/SOURCE_PINS.json').read_text())


def verify_package():
    names = set()
    for line in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = line.split('  ', 1)
        path = Path(name)
        require(not path.is_absolute() and '..' not in path.parts and name not in names,
                'UNSAFE_MANIFEST')
        require(not (ROOT / path).is_symlink() and sha(ROOT / path) == digest,
                'PACKAGE_CHANGED:' + name)
        names.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == names and len(pins()) == 2, 'PACKAGE_SCOPE_CHANGED')
    for name, pin in pins().items():
        for side in ['Before', 'After']:
            require(sha(ROOT / side / name) == pin[side.lower() + '_sha256'],
                    'SOURCE_FIXTURE_CHANGED:' + name)
    historical = json.loads((ROOT / 'References/HISTORICAL/manifest.json').read_text())
    require(pins()['drivers/rpmsg/rpm-smd.c']['before_sha256'] == historical['before_sha256']
            and pins()['drivers/rpmsg/rpm-smd.c']['after_sha256'] == historical['after_sha256'],
            'EXACT_HISTORICAL_RPM_FIX_REQUIRED')


def source_check(source, after=False):
    source = Path(source).resolve(strict=True)
    result = {}
    for name, pin in pins().items():
        path = source / name
        require(path.is_file() and all(not p.is_symlink() for p in [path, *path.parents]
                if p.is_relative_to(source)), 'SOURCE_NOT_REGULAR:' + name)
        result[name] = sha(path)
        expected = pin['after_sha256' if after else 'before_sha256']
        require(result[name] == expected,
                'RPM_SOURCE_CONTEXT_CHANGED:' + name + ':expected=' + expected + ':actual=' + result[name])
    return result


def apply_source(source):
    source = Path(source).resolve(strict=True)
    source_check(source)
    for name, pin in pins().items():
        if pin['before_sha256'] != pin['after_sha256']:
            (source / name).write_bytes((ROOT / 'After' / name).read_bytes())
    return source_check(source, after=True)


def linked_proof(text):
    patterns = {'rpm_enter': r'msm_rpm_enter_sleep', 'rpm_exit': r'msm_rpm_exit_sleep',
                'system_pm_initcall': r'__initcall_\S*sys_pm_rpm_driver_init6(?:\.llvm\.\S+)?'}
    result = {}
    for key, pattern in patterns.items():
        found = re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(' + pattern + r')$', text)
        require(found, 'RPM_SLEEP_INTERFACE_NOT_LINKED:' + key)
        result[key] = sorted(set(found))
    return result


def rpm_proof(build):
    build = Path(build).resolve(strict=True)
    out = build / 'candidate-out'
    source = source_check(build / 'candidate-source', after=True)
    require(sha(out / '.config') == profile()['baseline_config_sha256'], 'ACTUAL_M25_CONFIG_CHANGED')
    require(sha(out / 'Module.symvers') == profile()['full_symvers_sha256'], 'FULL_M25_EXPORT_TABLE_CHANGED')
    config = (out / '.config').read_text()
    for key in ['CONFIG_MSM_RPM_SMD', 'CONFIG_QTI_SYSTEM_PM_RPM']:
        require(re.search(r'(?m)^' + key + '=y$', config), 'BUILTIN_RPM_PATH_REQUIRED:' + key)
    objects = {}
    for unit in UNITS:
        obj = out / (unit + '.o')
        cmd = obj.parent / ('.' + obj.name + '.cmd')
        with obj.open('rb') as f:
            require(f.read(4) in [b'BC\xc0\xde', b'\xde\xc0\x17\x0b'], 'RPM_OBJECT_NOT_LLVM_BITCODE:' + unit)
        text = cmd.read_text()
        require(unit + '.c' in text and '-flto=thin' in text and '-fsanitize=cfi' in text,
                'ACTUAL_RPM_CFI_COMMAND_REQUIRED:' + unit)
        objects[unit] = {'object_sha256': sha(obj), 'command_sha256': sha(cmd)}
    offsets = {}
    for name in ['arch/arm64/boot/Image', 'vmlinux']:
        path = out / name
        with path.open('rb') as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as data:
            offsets[name] = data.find(ERROR_MESSAGE)
        require(offsets[name] >= 0, 'REPAIRED_RPM_FAILURE_PATH_NOT_LINKED:' + name)
    return {'rpm_source_hashes': source, 'rpm_objects': objects,
            'linked_rpm_interfaces': linked_proof((out / 'System.map').read_text()),
            'rpm_error_message_offsets': offsets, 'new_config_values_requested': [],
            'actual_config_sha256': sha(out / '.config'), 'full_symvers_sha256': sha(out / 'Module.symvers')}


def load_parent(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['m25_tool_sha256'], 'AUTHENTIC_M25_R2_TOOL_CHANGED')
    spec = importlib.util.spec_from_file_location('m26_original_m25_r2', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def write_result(out, name, result):
    if out.is_dir():
        (out / name).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def build(args):
    verify_package()
    parent = load_parent(args.m25_tool)
    original = parent.patch_makefile
    out = Path(args.output).resolve()
    result = {'status': 'M26_BUILD_PENDING', 'kernel_compiled': False,
              'device_pass': False, 'flash_allowed': False, 'runtime_suspend_tested': False,
              'baseline_run': profile()['baseline_run'], 'new_config_values_requested': []}

    def patch_source(source):
        # Check every RPM preimage before modifying the isolated candidate.
        result['rpm_preflight'] = source_check(source)
        prior = original(source)
        result['applied_rpm_source_hashes'] = apply_source(source)
        return prior

    parent.patch_makefile = patch_source
    try:
        parent.build(args)
        prior = parent.verify_fresh(out)
        require(prior['kernel_compiled'] is True, 'FULL_M25_R2_BUILD_REQUIRED')
        result.update(rpm_proof(out))
        require(result['rpm_source_hashes'] == result['applied_rpm_source_hashes'],
                'RPM_SOURCE_CHANGED_DURING_BUILD')
        r25 = json.loads((out / 'R25_RESULT.json').read_text())
        require(r25['fully_matching_modules'] == 37 and r25['qgki_counts'] ==
                {'MATCH': 1423, 'CRC_MISMATCH': 0, 'NOT_EXPORTED': 0}, 'COMPLETE_QGKI_COHORT_REQUIRED')
        result.update(status=STATUS, kernel_compiled=True, rpm_sleep_failure_path_compiled_and_linked=True,
                      fully_matching_modules=37, qgki_counts=r25['qgki_counts'],
                      kernel_product_hashes=r25['kernel_product_hashes'], release=r25['release'])
    except Exception as error:
        result.update(status='M26_BUILD_OR_RPM_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        parent.patch_makefile = original
        write_result(out, 'M26_RESULT.json', result)
    print(result['status'], 'DEVICE_PASS=NO FLASH=NO')


def verify_fresh(build, parent):
    build = Path(build).resolve(strict=True)
    result = json.loads((build / 'M26_RESULT.json').read_text())
    require(result.get('status') == STATUS and result.get('kernel_compiled') is True
            and result.get('rpm_sleep_failure_path_compiled_and_linked') is True
            and result.get('runtime_suspend_tested') is False
            and result.get('device_pass') is False and result.get('flash_allowed') is False,
            'FRESH_M26_FULL_RPM_BUILD_REQUIRED')
    parent.verify_fresh(build)
    proof = rpm_proof(build)
    require(all(result.get(k) == v for k, v in proof.items()), 'FRESH_RPM_PROOF_CHANGED')
    for name, digest in result['kernel_product_hashes'].items():
        require(sha(build / 'candidate-out' / name) == digest, 'FRESH_KERNEL_PRODUCT_CHANGED:' + name)
    return result


def package(args):
    verify_package()
    parent = load_parent(args.m25_tool)
    result = verify_fresh(args.build, parent)
    out = Path(args.output).resolve()
    package_result = {'status': 'M26_PACKAGE_PENDING', 'static_boot_path_pass': False,
                      'device_pass': False, 'flash_allowed': False}
    try:
        parent.package(args)
        prior = json.loads((out / 'M25_PACKAGE_RESULT.json').read_text())
        require(prior['static_boot_path_pass'] is True and prior['packaged_kernel_config_matches_build'] is True,
                'M25_R2_STATIC_CONFIG_AND_PACKAGE_GATES_REQUIRED')
        for path in sorted((out / 'review').iterdir()):
            require(path.is_file() and path.name.startswith('VEUX_R25_'), 'UNEXPECTED_REVIEW_FILE')
            target = path.with_name(path.name.replace('VEUX_R25_', 'VEUX_M26_', 1))
            require(not target.exists(), 'REVIEW_TARGET_EXISTS')
            path.rename(target)
        pair = parent.audit_pair(args.build, out)
        verify_fresh(args.build, parent)
        package_result.update(status='M26_RPM_SLEEP_CONFIG_BOOT_AK3_PAIR_PASS_NOFLASH',
                              static_boot_path_pass=True, review_pair_sha256=pair,
                              kernel_release=result['release']['verified_release'])
    except Exception as error:
        package_result.update(status='M26_PACKAGE_GATE_FAILED_NOFLASH', error=str(error))
        review = out / 'review'
        if review.exists():
            review.rename(out / 'unverified-review')
        raise
    finally:
        write_result(out, 'M26_PACKAGE_RESULT.json', package_result)
    print('M26_RPM_SLEEP_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='op', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    b = sub.add_parser('build')
    for name in ('m25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-tool', 'r19-tool', 'r18-tool',
                 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + name, required=True)
    a = sub.add_parser('package')
    for name in ('m25-tool', 'r25-tool', 'r24-tool', 'r23-tool', 'r21-package-tool', 'build',
                 'packager-tool', 'work', 'output'):
        a.add_argument('--' + name, required=True)
    args = p.parse_args()
    verify_package()
    if args.op == 'build':
        build(args)
    elif args.op == 'package':
        package(args)
    elif args.op == 'check-source':
        print(json.dumps(source_check(args.source), sort_keys=True))
    else:
        print('M26_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')


if __name__ == '__main__':
    main()
