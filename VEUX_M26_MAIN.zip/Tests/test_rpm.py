import argparse
import contextlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('m26_tested', ROOT / 'Tools/m26_rpm_sleep.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class RpmSourceTests(unittest.TestCase):
    def test_exact_historical_source_and_only_one_file_changes(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            shutil.copytree(ROOT / 'Before', source, dirs_exist_ok=True)
            before = m.source_check(source)
            after = m.apply_source(source)
            self.assertEqual({n for n in before if before[n] != after[n]}, {'drivers/rpmsg/rpm-smd.c'})
            self.assertEqual(after['drivers/rpmsg/rpm-smd.c'],
                             '8c7416abec4c2c28ccc9829ad9f6abaee2c42bdcfda8fd8420236c6b1cb5c655')
            self.assertEqual(after, m.source_check(source, after=True))

    def test_last_caller_preimage_drift_prevents_any_write(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp)
            shutil.copytree(ROOT / 'Before', source, dirs_exist_ok=True)
            victim = source / 'drivers/soc/qcom/system_pm_rpm.c'
            victim.write_bytes(victim.read_bytes() + b'/* changed caller */')
            before = (source / 'drivers/rpmsg/rpm-smd.c').read_bytes()
            with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_CHANGED'):
                m.apply_source(source)
            self.assertEqual((source / 'drivers/rpmsg/rpm-smd.c').read_bytes(), before)

    def test_already_fixed_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            shutil.copytree(ROOT / 'After', temp, dirs_exist_ok=True)
            with self.assertRaisesRegex(ValueError, 'SOURCE_CONTEXT_CHANGED'):
                m.apply_source(temp)

    def test_symlink_cannot_redirect_source_patch(self):
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / 'source'
            shutil.copytree(ROOT / 'Before', source)
            path = source / 'drivers/rpmsg/rpm-smd.c'
            target = Path(temp) / 'elsewhere.c'
            path.rename(target)
            path.symlink_to(target)
            with self.assertRaisesRegex(ValueError, 'NOT_REGULAR'):
                m.apply_source(source)

    def test_exact_native_original_fixed_and_xiaomi_functions_22_cases(self):
        script = ROOT / 'References/HISTORICAL/test_rpm_sleep.py'
        spec = importlib.util.spec_from_file_location('authentic_rpm_native_tests', script)
        native = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(native)
        with tempfile.TemporaryDirectory() as temp:
            native.OUT = Path(temp)
            with patch.object(sys, 'argv', [str(script), str(ROOT / 'After/drivers/rpmsg/rpm-smd.c')]), contextlib.redirect_stdout(io.StringIO()):
                native.main()
            result = json.loads((Path(temp) / 'RESULTS.json').read_text())
            self.assertEqual(result['host_cases_passed'], 22)
            self.assertEqual(result['transport_failure_cases'], 11)
            self.assertFalse(result['kernel_build'])
            self.assertFalse(result['device_test'])

    def test_authentic_m25_hook_preserves_makefile_fix_and_configuration(self):
        parent_root = Path(os.environ.get('M25_DIR', str(ROOT.parent / 'm25-r2-main')))
        parent = m.load_parent(parent_root / 'Tools/m25_config.py')
        original = parent.patch_makefile
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / 'candidate-source'
            shutil.copytree(ROOT / 'Before', source)
            makefile = source / 'kernel/Makefile'
            makefile.parent.mkdir()
            makefile.write_bytes((parent_root / 'References/kernel.Makefile.before').read_bytes())
            cfg = root / '.config'
            cfg.write_bytes(b'CONFIG_TEST_SENTINEL=y\n')

            def stop(args):
                report = parent.patch_makefile(source)
                self.assertEqual(report['after_sha256'], parent.POSTIMAGE_SHA)
                m.source_check(source, after=True)
                self.assertEqual(cfg.read_bytes(), b'CONFIG_TEST_SENTINEL=y\n')
                raise RuntimeError('AUTHENTIC_M25_AND_RPM_CALLBACK_PASS_STOPS_BEFORE_COMPILATION')

            with patch.object(m, 'load_parent', return_value=parent), patch.object(parent, 'build', side_effect=stop):
                with self.assertRaisesRegex(RuntimeError, 'CALLBACK_PASS'):
                    m.build(argparse.Namespace(m25_tool=str(parent_root / 'Tools/m25_config.py'), output=str(root)))
            self.assertIs(parent.patch_makefile, original)
            result = json.loads((root / 'M26_RESULT.json').read_text())
            self.assertFalse(result['kernel_compiled'])
            self.assertFalse(result['flash_allowed'])
            self.assertIn('applied_rpm_source_hashes', result)

    def test_linked_rpm_and_actual_system_pm_initcall_required(self):
        lines = ['ffffffc010ee3e64 T msm_rpm_enter_sleep',
                 'ffffffc010ee4304 T msm_rpm_exit_sleep',
                 'ffffffc0127edf90 d __initcall_136_81_sys_pm_rpm_driver_init6']
        self.assertEqual(len(m.linked_proof('\n'.join(lines))), 3)
        for i in range(3):
            with self.subTest(i=i), self.assertRaisesRegex(ValueError, 'NOT_LINKED'):
                m.linked_proof('\n'.join(lines[:i] + lines[i + 1:]))

    def test_old_green_result_cannot_satisfy_new_build_gate(self):
        with tempfile.TemporaryDirectory() as temp:
            (Path(temp) / 'M26_RESULT.json').write_text(json.dumps({'status': 'M25_GREEN', 'kernel_compiled': True}))
            parent = argparse.Namespace(verify_fresh=lambda b: None)
            with self.assertRaisesRegex(ValueError, 'FRESH_M26_FULL_RPM_BUILD_REQUIRED'):
                m.verify_fresh(temp, parent)

    def test_parent_packaging_failure_is_reported_and_unverified_pair_quarantined(self):
        with tempfile.TemporaryDirectory() as temp:
            out = Path(temp)
            (out / 'review').mkdir()
            (out / 'review/unverified_boot.img').write_bytes(b'unit fixture')

            def fail(args):
                raise RuntimeError('PARENT_PACKAGE_FAILED')

            parent = argparse.Namespace(package=fail)
            with patch.object(m, 'verify_package'), patch.object(m, 'load_parent', return_value=parent), patch.object(m, 'verify_fresh', return_value={}):
                with self.assertRaisesRegex(RuntimeError, 'PARENT_PACKAGE_FAILED'):
                    m.package(argparse.Namespace(m25_tool='fixture', build='fixture', output=temp))
            result = json.loads((out / 'M26_PACKAGE_RESULT.json').read_text())
            self.assertFalse(result['static_boot_path_pass'])
            self.assertFalse(result['device_pass'])
            self.assertFalse(result['flash_allowed'])
            self.assertFalse((out / 'review').exists())
            self.assertTrue((out / 'unverified-review/unverified_boot.img').is_file())


class ProductTests(unittest.TestCase):
    def fixture(self, build):
        shutil.copytree(ROOT / 'After', build / 'candidate-source')
        out = build / 'candidate-out'
        (out / 'arch/arm64/boot').mkdir(parents=True)
        cfg = out / '.config'
        cfg.write_text('CONFIG_MSM_RPM_SMD=y\nCONFIG_QTI_SYSTEM_PM_RPM=y\n')
        (out / 'Module.symvers').write_text('SYNTHETIC UNIT FIXTURE\n')
        for unit in m.UNITS:
            obj = out / (unit + '.o')
            obj.parent.mkdir(parents=True, exist_ok=True)
            obj.write_bytes(b'BC\xc0\xdeSYNTHETIC UNIT FIXTURE')
            (obj.parent / ('.' + obj.name + '.cmd')).write_text(unit + '.c -flto=thin -fsanitize=cfi')
        for name in ['arch/arm64/boot/Image', 'vmlinux']:
            (out / name).write_bytes(b'SYNTHETIC UNIT FIXTURE\0' + m.ERROR_MESSAGE)
        (out / 'System.map').write_text('ffffffc010ee3e64 T msm_rpm_enter_sleep\n'
                                      'ffffffc010ee4304 T msm_rpm_exit_sleep\n'
                                      'ffffffc0127edf90 d __initcall_136_81_sys_pm_rpm_driver_init6\n')
        profile = dict(m.profile(), baseline_config_sha256=m.sha(cfg), full_symvers_sha256=m.sha(out / 'Module.symvers'))
        return out, profile

    def test_complete_product_proof_checks_both_real_compile_commands_and_linked_error_path(self):
        with tempfile.TemporaryDirectory() as temp:
            out, profile = self.fixture(Path(temp))
            with patch.object(m, 'profile', return_value=profile):
                proof = m.rpm_proof(temp)
            self.assertEqual(len(proof['rpm_objects']), 2)
            self.assertEqual(set(proof['rpm_error_message_offsets']), {'arch/arm64/boot/Image', 'vmlinux'})
            self.assertEqual(proof['new_config_values_requested'], [])

    def test_old_failure_path_cfi_or_export_table_drift_is_rejected(self):
        for name in ['arch/arm64/boot/Image', 'vmlinux', 'Module.symvers',
                     'drivers/rpmsg/.rpm-smd.o.cmd', 'drivers/rpmsg/rpm-smd.o',
                     'drivers/soc/qcom/.system_pm_rpm.o.cmd', 'System.map']:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp:
                out, profile = self.fixture(Path(temp))
                (out / name).write_bytes(b'old or invalid product')
                with patch.object(m, 'profile', return_value=profile), self.assertRaises(ValueError):
                    m.rpm_proof(temp)

    def test_product_hashes_are_rechecked_after_recorded_green_result(self):
        with tempfile.TemporaryDirectory() as temp:
            build = Path(temp)
            out, profile = self.fixture(build)
            with patch.object(m, 'profile', return_value=profile):
                result = dict(m.rpm_proof(build), status=m.STATUS, kernel_compiled=True,
                              rpm_sleep_failure_path_compiled_and_linked=True, runtime_suspend_tested=False,
                              device_pass=False, flash_allowed=False,
                              kernel_product_hashes={'vmlinux': m.sha(out / 'vmlinux')})
                (build / 'M26_RESULT.json').write_text(json.dumps(result))
                parent = argparse.Namespace(verify_fresh=lambda b: None)
                self.assertEqual(m.verify_fresh(build, parent)['status'], m.STATUS)
                p = out / 'vmlinux'
                p.write_bytes(p.read_bytes() + b'changed after build')
                with self.assertRaisesRegex(ValueError, 'FRESH_KERNEL_PRODUCT_CHANGED'):
                    m.verify_fresh(build, parent)


class WorkflowTests(unittest.TestCase):
    def command(self, op):
        expected = (ROOT / ('References/M26_' + op.upper() + '_COMMAND.sh')).read_text()
        if 'M26_WORKFLOW' not in os.environ:
            return expected
        rows = Path(os.environ['M26_WORKFLOW']).read_text().splitlines()
        found = []
        for i, row in enumerate(rows):
            if row.strip() != 'run: |':
                continue
            indent = len(row) - len(row.lstrip())
            body = []
            for line in rows[i + 1:]:
                if line.strip() and len(line) - len(line.lstrip()) <= indent:
                    break
                body.append(line)
            script = textwrap.dedent('\n'.join(body)) + '\n'
            if 'python3 -B "$M26_DIR/Tools/m26_rpm_sleep.py" ' + op in script:
                found.append(script)
        self.assertEqual(found, [expected])
        return found[0]

    def capture(self, op, broken=False):
        with tempfile.TemporaryDirectory(prefix='m26 argv spaces ') as temp:
            root = Path(temp)
            bindir = root / 'bin'
            bindir.mkdir()
            shim = bindir / 'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M26_CAPTURE"\n')
            shim.chmod(0o755)
            keys = ['M25_DIR', 'R25_DIR', 'R24_DIR', 'R23_DIR', 'R21_SCHED_DIR', 'R19_RMNET_DIR',
                    'R18_IRQ_DIR', 'R17_CACHE_DIR', 'R16_REPAIR_DIR', 'R9_SNAPSHOT', 'R13_OBJOUT',
                    'R47_REPORT_DIR', 'R47_TOOLS_DIR', 'GITHUB_WORKSPACE', 'R16_REPAIR_OUTPUT',
                    'R21_PACK_DIR', 'R21_PACKAGE_OUTPUT']
            env = {k: str(root / (k + ' spaces')) for k in keys}
            env['M26_DIR'] = str(ROOT)
            command = self.command(op)
            if broken:
                command = command.replace(' ' + op + ' \\\n', ' ' + op + ' \\\n  + \\\n', 1)
            result = subprocess.run(['bash', '-c', command], env=dict(os.environ, **env,
                                    PATH=str(bindir) + os.pathsep + os.environ['PATH'], M26_CAPTURE=str(root / 'argv')),
                                    text=True, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            argv = (root / 'argv').read_bytes().decode().split('\0')
            self.assertEqual(argv.pop(), '')
            self.assertEqual(argv[:2], ['-B', str(ROOT / 'Tools/m26_rpm_sleep.py')])
            return argv[1:], env

    def invoke(self, op, count):
        argv, env = self.capture(op)
        with patch.object(sys, 'argv', argv), patch.object(m, 'verify_package'), patch.object(m, op) as called:
            m.main()
        parsed = vars(called.call_args.args[0])
        self.assertEqual(len(parsed), count + 1)
        self.assertEqual(parsed['op'], op)
        self.assertEqual(parsed['m25_tool'], env['M25_DIR'] + '/Tools/m25_config.py')
        self.assertEqual(parsed['r25_tool'], env['R25_DIR'] + '/Tools/r25_tzlog.py')
        self.assertEqual(parsed['output'], env['R16_REPAIR_OUTPUT'] if op == 'build' else env['R21_PACKAGE_OUTPUT'])
        return parsed, env

    def test_delivered_build_command_passes_real_parser_with_all_fifteen_paths(self):
        parsed, env = self.invoke('build', 15)
        self.assertEqual(parsed['source'], env['R9_SNAPSHOT'])
        self.assertEqual(parsed['project'], env['GITHUB_WORKSPACE'] + '/project')

    def test_delivered_package_command_passes_real_parser_with_all_nine_paths(self):
        parsed, env = self.invoke('package', 9)
        self.assertEqual(parsed['build'], env['R16_REPAIR_OUTPUT'])
        self.assertEqual(parsed['work'], env['GITHUB_WORKSPACE'] + '/r46-m26-pack-work')

    def test_original_plus_typo_is_rejected_before_either_operation(self):
        for op in ['build', 'package']:
            argv, _ = self.capture(op, broken=True)
            with self.subTest(op=op), patch.object(sys, 'argv', argv), patch.object(m, op) as called, contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as error:
                    m.main()
            self.assertEqual(error.exception.code, 2)
            called.assert_not_called()


if __name__ == '__main__':
    unittest.main()
