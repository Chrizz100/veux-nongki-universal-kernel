#!/usr/bin/env python3
"""R58: assemble a *new isolated* native-5.4 CASS source candidate.

No boot.img, no installer, no flash. Real 35259 replay and R52 partial SUSFS
are mandatory inputs from the successful R56-R4 GitHub source workflow.
This script deliberately does not equate a source merge to a kernel build.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

R13_MAIN_SHA = '15770d93410c01ed9ad149ffc82b93d54a3ea73e6c53a274bd767b249cc975c1'
R56_MAIN_SHA = 'b745ba93ebf92482fa3fcfa10a27b08c62fc72e07479e029dbae685949ae6117'
R13_CONFIG_SHA = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'
R13_NATIVE_SUSFS_SHA = '4d6f73641fba90b422a0f3d787a5c220829ad6b99807bec843ba24e7f1d73172'
R52_SUSFS_SHA = 'c5613da17ec246247edb5e76f2454ebf6ab190b145cd16b3c3f121a92ace3770'
NATIVE54_HASHTABLE_BLOB = '417d2c4bc60db4b80b29d1a7f78d1273b600b258'
# A Git *commit* ID includes author/committer timestamps. The original R54
# replay creates two VEUX-local commits with current timestamps, so identical
# source trees can have different commit IDs between successful CI runs.
# Pin the *tree*, upstream ancestry, exact protected blobs and changed paths.
# Do not replace this with a permissive regex-only SHA acceptance.
R56_BAKASU_TREE = 'f3c5aabc128c70b1bda34d1cc5f2ede01a48af79'
R56_BAKASU_OFFICIAL_HEAD = '516d3e87fbc986ccefdde2c2765f1700612441a9'
R56_R13_RECONSTRUCTED_TREE = 'a0fb073cc22c7cba0fce0fff5dfb33e99669cb36'
R56_R13_ORIGINAL_COMMIT = 'd2537b13ab15fce72e8c0d99e7788805f071aeb4'
R56_R13_ORIGINAL_PARENT = '2cbbcc2363aa8d4b6286fc2266a338063b2b77a7'
R56_OFFICIAL_SEQUENCE = (
    '5785bdb8091304322f597f67d50e0b79f9815cb2',
    'f98b7a5b909910e1830cae8a2f9c78a61f1f6c2a',
    'e5473cdf25ce0285fcb4977396a9c0585a0e2d91',
    '01c11c70b4a49a756f7fa4b2ec13f2dbbe6f6abb',
    '516d3e87fbc986ccefdde2c2765f1700612441a9',
)
R56_PROTECTED_BLOBS = {
    'kernel/feature/selinux_hide.c':'6647ab49ac546fb122f0e44c69d506e1496cc788',
    'kernel/feature/sucompat.c':'069a5c130aa9b510c094463964a10a11dff70673',
    'kernel/feature/sucompat.h':'756502a75bb5bef80894eccd97506d2ee1753bb0',
    'kernel/manager/throne_tracker.c':'a9591199f789abd578731513298e87c8b04e3ac2',
    'kernel/supercall/dispatch.c':'212bfb456207ac6d78160dae9cce5eaee114e7b0',
}
R56_ALL_CHANGED_PATHS = (
    '.github/workflows/build-manager.yml', 'kernel/Kbuild', 'kernel/core/init.c',
    'kernel/infra/btf_parser.c','kernel/infra/btf_parser.h','kernel/infra/file_wrapper.c',
    'kernel/selinux/inode.c','kernel/selinux/selinux.h','scripts/ksubot.py',
    'userspace/ksud/src/boot_patch.rs','userspace/ksuinit/src/init.rs',
)

SUSFS_SNAPSHOT = '937232ce8c4bdcbe4216e99a1b3d7b5cf633f7c6'
SUSFS_LATEST_OBSERVED = '8a120081f2739bc0e4b1f6a389d8236f22944acc'
VENDOR_SERVICES_BLOBS = {'08b8700be4bd0699987cd38f48070997e1d47dac',
                          '6559767d34444c54c03be4d821f64b9745c4ef54'}
R56_SOURCE_CONTRACT = 'REAL_BAKASU_35259_REPLAYED__NATIVE54_AVD_PATCHES_STAGED__FULL_SUSFS_HOOKS_BLOCKED'
ROOT = Path(__file__).resolve().parents[1]

class Blocked(RuntimeError): pass

def need(cond, why):
    if not cond: raise Blocked(why)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git','--no-optional-locks','-C',str(repo),*args],text=True).strip()

def git_blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def required_file(p):
    p=Path(p)
    need(p.is_file() and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode),'MISSING_OR_SYMLINK:'+str(p))
    return p

def preflight(r13_main, r56_main, r13_config):
    need(sha(required_file(r13_main))==R13_MAIN_SHA,'R13_SOURCE_CHANGED')
    need(sha(required_file(r56_main))==R56_MAIN_SHA,'R56_INPUT_CHANGED')
    need(sha(required_file(r13_config))==R13_CONFIG_SHA,'R13_CONFIG_SHA_CHANGED')
    text=required_file(r13_config).read_text()
    for token in ('CONFIG_SCHED_CASS=y','CONFIG_MODULES=y','CONFIG_KSU=y',
                  'CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y','CONFIG_MODVERSIONS=y',
                  'CONFIG_SECURITY_SELINUX=y'):
        need(token+'\n' in text, 'R13_REQUIRED_CONFIG_MISSING:'+token)
    need('CONFIG_SCHED_WALT=y\n' not in text,'WALT_NOT_ALLOWED')
    return {'r13_sha':R13_MAIN_SHA,'r56_sha':R56_MAIN_SHA,
            'cass':True,'modules':True,'modversions':True,'nomount':True,
            'walt':False,'device_test':False,'flash_allowed':False}

def type_bridge(text):
    """Narrow native-5.4 type lookup: retains original rwlock and core parser.

    5.10's `struct selinux_policy` RCU parser is NOT copied into Linux 5.4.
    No extra policy_rwlock changes or weakening of access checks.
    """
    need('susfs_is_sus_type_rcu' not in text,'SUS_TYPE_LOOKUP_ALREADY_PRESENT')
    before_lock_count=text.count('rcu_read_lock();')
    before_unlock_count=text.count('rcu_read_unlock();')
    anchor='#include "audit.h"\n\n'
    need(text.count(anchor)==1,'SELINUX_HEADER_ANCHOR_CHANGED')
    declarations=('#ifdef CONFIG_KSU_SUSFS\n'
                  '#include <linux/rcupdate.h>\n'
                  'extern bool susfs_is_sus_type_rcu(u32 type_value);\n'
                  '#endif\n\n')
    text=text.replace(anchor,anchor+declarations,1)
    marker=('\ttypdatum = hashtab_search(pol->p_types.table, scontextp);\n'
            '\tif (!typdatum || typdatum->attribute)\n'
            '\t\tgoto out;\n\n'
            '\tctx->type = typdatum->value;')
    need(text.count(marker)==1,'NATIVE54_POLICYDB_TYPE_PARSER_CHANGED')
    insertion=('\ttypdatum = hashtab_search(pol->p_types.table, scontextp);\n'
               '\tif (!typdatum || typdatum->attribute)\n'
               '\t\tgoto out;\n\n'
               '#ifdef CONFIG_KSU_SUSFS\n'
               '\t/* Exact native-5.4 type check, without replacing the policy parser. */\n'
               '\trcu_read_lock();\n'
               '\tif (susfs_is_sus_type_rcu(typdatum->value)) {\n'
               '\t\trcu_read_unlock();\n'
               '\t\tgoto out;\n'
               '\t}\n'
               '\trcu_read_unlock();\n'
               '#endif\n'
               '\tctx->type = typdatum->value;')
    text=text.replace(marker,insertion,1)
    need(text.count('susfs_is_sus_type_rcu(')==2,'SUS_TYPE_CALL_AND_PROTO_COUNT')
    need(text.count('rcu_read_lock();')==before_lock_count+1 and
         text.count('rcu_read_unlock();')==before_unlock_count+2,
         'EXTRA_RCU_TYPE_LOCKS')
    return text

def native_hashtable_header(text):
    """Add Linux-5.4 hashtable include and exact-key hash-collision protection.

    Retain the pinned R52 source unchanged; repair only its isolated candidate.
    """
    anchor='#include <linux/hash.h>\n'
    need(text.count(anchor)==1, 'NATIVE54_HASH_INCLUDE_MISSING_OR_DUPLICATE')
    need('#include <linux/hashtable.h>' not in text,'NATIVE54_HASHTABLE_ALREADY_PRESENT_REVIEW')
    need('static DEFINE_HASHTABLE(SUS_TYPE_HLIST' in text and
         'static DEFINE_HASHTABLE(SUS_AVD_ALLOWED_HLIST' in text,
         'NEW_SUSFS_HASH_TABLES_NOT_PRESENT')
    text=text.replace(anchor,anchor+'#include <linux/hashtable.h>\n',1)
    # Upstream 5.10 type entries use hash buckets but don't retain the key.
    # In Linux 5.4, hash_for_each_possible_rcu() traverses *a bucket* (many
    # keys), not an exact match: without a value check, collisions are false
    # SELinux type matches. Repair only this isolated candidate's lookup.
    import re
    pattern=r'(?m)^struct st_susfs_sus_type_hlist \{\n(\s*struct hlist_node\s+node;\n)\};'
    matches=list(re.finditer(pattern,text))
    need(len(matches)==1,'NATIVE54_TYPE_HASH_STRUCT_CHANGED')
    match=matches[0]
    original=match.group(0)
    updated=original[:-2]+'\tu32 type_value;\n};'
    text=text[:match.start()]+updated+text[match.end():]
    duplicate='''hash_for_each_possible_safe(SUS_TYPE_HLIST, tmp_entry, tmp_hlist_node, node, type_value) {
'''
    need(text.count(duplicate)==1,'NATIVE54_TYPE_DUPLICATE_LOOKUP_CHANGED')
    text=text.replace(duplicate,duplicate+
        '\t\tif (tmp_entry->type_value != type_value)\n\t\t\tcontinue;\n',1)
    new_entry='\thash_add_rcu(SUS_TYPE_HLIST, &new_entry->node, type_value);'
    need(text.count(new_entry)==1,'NATIVE54_TYPE_INSERT_ANCHOR_CHANGED')
    text=text.replace(new_entry,'\tnew_entry->type_value = type_value;\n'+new_entry,1)
    lookup='''hash_for_each_possible_rcu(SUS_TYPE_HLIST, entry, node, type_value) {
		return true;
	}'''
    need(text.count(lookup)==1,'NATIVE54_TYPE_LOOKUP_ANCHOR_CHANGED')
    text=text.replace(lookup,
        lookup.replace('\t\treturn true;',
            '\t\tif (entry->type_value == type_value)\n\t\t\treturn true;'),1)
    need(text.count('type_value')>0 and text.count('entry->type_value == type_value')==1,
         'NATIVE54_TYPE_HASH_KEY_CHECK_MISSING')
    return text

def apply_patch(repo, patch):
    patch=required_file(patch)
    for flag in ('--check',None):
        argv=['git','-C',str(repo),'apply','--whitespace=error']
        if flag:argv.append(flag)
        argv.append(str(patch))
        subprocess.run(argv,check=True,capture_output=True,text=True)

def ensure_git_replay(replay, receipt):
    """Prove an identical 35259 replay by immutable content and ancestry.

    R54 reconstructs *new* local Git commits without fixed timestamps; their
    SHA-1 IDs can change between runners even if the tree is byte-identical.
    Do not hard-pin those unstable commit IDs, nor trust the receipt alone.
    """
    data=json.loads(required_file(receipt).read_text())
    need(data.get('schema')=='VEUX_R56_R3_BAKASU_TREE_RECOVERY_V1' and
         data.get('status')=='HISTORICAL_R13_TREE_VERIFIED__CURRENT_BAKASU_CONTENT_REPLAYED__NO_BUILD_NO_FLASH',
         'R56_BAKASU_REPLAY_RECEIPT_CHANGED')
    need(data.get('official_head')==R56_BAKASU_OFFICIAL_HEAD and
         data.get('five_official_upstream_commits')==list(R56_OFFICIAL_SEQUENCE),
         'R56_UPSTREAM_LINEAGE_CHANGED')
    need(data.get('historical_original_commit')==R56_R13_ORIGINAL_COMMIT and
         data.get('historical_original_parent')==R56_R13_ORIGINAL_PARENT and
         data.get('historical_reconstructed_tree')==R56_R13_RECONSTRUCTED_TREE and
         data.get('historical_tree_byte_identical') is True and
         data.get('original_commit_SHA_recreated') is False,
         'R56_R13_RECONSTRUCTION_CHANGED')
    need(data.get('genuine_git_commit_count')==4559 and
         data.get('calculated_source_version')==35259 and
         data.get('kernel_compiled') is False and
         data.get('flash_allowed') is False,
         'R56_BAKASU_REPLAY_RECEIPT_CHANGED')
    need(data.get('changed_paths')==list(R56_ALL_CHANGED_PATHS) and
         data.get('protected_port_blobs')==R56_PROTECTED_BLOBS,
         'R56_BAKASU_PROTECTED_SOURCE_RECEIPT_CHANGED')
    need(data.get('result_tree')==R56_BAKASU_TREE,
         'R56_BAKASU_SOURCE_TREE_CHANGED')
    actual_commit=git(replay,'rev-parse','HEAD')
    need(isinstance(data.get('result_commit'),str) and
         len(data['result_commit'])==40 and
         all(c in '0123456789abcdef' for c in data['result_commit']) and
         data['result_commit']==actual_commit,
         'R56_BAKASU_RECEIPT_COMMIT_MISMATCH')
    need(git(replay,'rev-parse','HEAD^{tree}')==R56_BAKASU_TREE,
         'R56_BAKASU_ACTUAL_GIT_TREE_CHANGED')
    need(git(replay,'rev-parse','HEAD~2')==R56_BAKASU_OFFICIAL_HEAD,
         'R56_BAKASU_REPLAY_PARENT_CHANGED')
    need(git(replay,'rev-list','--count','HEAD')=='4559',
         'R56_BAKASU_REAL_GIT_COUNT_CHANGED')
    need(not git(replay,'status','--porcelain','--untracked-files=all'),
         'R56_BAKASU_SOURCE_DIRTY')
    # The two VEUX commits may only change five explicitly approved files;
    # none of the new upstream files or build metadata may be overwritten.
    changed=set(git(replay,'diff','--name-only',R56_BAKASU_OFFICIAL_HEAD+'..HEAD').splitlines())
    need(changed==set(R56_PROTECTED_BLOBS),
         'R56_BAKASU_LOCAL_PORT_SCOPE_CHANGED')
    for name, blob in R56_PROTECTED_BLOBS.items():
        need(git(replay,'rev-parse','HEAD:'+name)==blob,
             'PROTECTED_PORT_BLOB_CHANGED:'+name)
    return data

def stage(a):
    source=Path(a.kernel).resolve(strict=True)
    replay=Path(a.replay).resolve(strict=True)
    stage_root=Path(a.r54_stage).resolve(strict=True)
    r56=Path(a.r56_stage).resolve(strict=True)
    out=Path(a.out)
    need(out.parent.is_dir() and not out.exists() and not out.is_symlink(),'MUST_STAGE_IN_NEW_DIRECTORY')
    need(not out.resolve().is_relative_to(source) and not out.resolve().is_relative_to(replay),
         'DO_NOT_MUTATE_REFERENCE_TREE')
    r13_config=Path(a.r13_config)
    historical=preflight(a.r13_main,a.r56_main,r13_config)
    old=source/'KernelSU'
    need(old.is_dir() and git(old,'rev-parse','HEAD')=='d2537b13ab15fce72e8c0d99e7788805f071aeb4',
         'R13_BAKASU_SOURCE_NOT_EXPECTED')
    need(sha(required_file(source/'fs/susfs.c'))==R13_NATIVE_SUSFS_SHA,'R13_NATIVE_SUSFS_PREIMAGE_CHANGED')
    need(git_blob(required_file(source/'include/linux/hashtable.h').read_bytes())==NATIVE54_HASHTABLE_BLOB,
         'NATIVE54_KERNEL_HASHTABLE_SOURCE_CHANGED')
    r52=stage_root/'R54_PARTIAL_SUSFS_PORT'
    susfs=required_file(r52/'NOT_BUILD_READY_susfs.c')
    receipt=json.loads(required_file(r52/'R52_SOURCE_RECEIPT.json').read_text())
    need(sha(susfs)==R52_SUSFS_SHA and receipt['native54_partial_candidate_sha256']==R52_SUSFS_SHA and
         receipt['official_head']==SUSFS_SNAPSHOT,'R52_AUTHENTIC_SUSFS_5_4_CANDIDATE_CHANGED')
    need(all(k in susfs.read_text() for k in ['susfs_add_sus_type(', 'susfs_is_sus_type_rcu(',
         'susfs_add_sus_avd_allowed_by_type(', 'susfs_spoof_avd_allowed_rcu(']),'SUSFS_FUNCTIONS_MISSING')
    build=json.loads(required_file(r56/'R56_REAL_SOURCE_GATE.json').read_text())
    need(build['status']==R56_SOURCE_CONTRACT and build['source_stage_accepted'] is True,
         'R56_SOURCE_NOT_CERTIFIED')
    provenance=ensure_git_replay(replay,stage_root/'R54_REAL_BAKASU_REPLAY.json')
    need(build.get('genuine_BakaSU_replay_commit')==provenance['result_commit'] and
         build.get('genuine_BakaSU_replay_version')==35259,
         'R56_SOURCE_GATE_REPLAY_IDENTITY_DISAGREES')
    orig_services=required_file(source/'security/selinux/ss/services.c')
    before=orig_services.read_bytes()
    need(git_blob(before) in VENDOR_SERVICES_BLOBS,'R13_STOCK54_SERVICES_REVIEW_REQUIRED')
    patch1=required_file(r56/'R56_BAKASU_AVD_PATCH/0001-bakasu-native54-avd-bridge.patch')
    patch2=required_file(r56/'R56_STOCK_SERVICES_AVD_PATCH/R56_SERVICES_5_4_AVD_SOURCE_ONLY.patch')
    need(sha(patch1)==sha(ROOT/'refs/0001-bakasu-native54-avd-bridge.patch'),'BAKASU_AVD_PATCH_CHANGED')
    need(sha(patch2)==sha(ROOT/'refs/0002-xiaomi-services-native54-avd.patch'),'STOCK_AVD_PATCH_CHANGED')

    # Create the independent candidate only after all immutable source pins pass.
    # No changes to source, R13, R41, the GitHub checkout or any device.
    out.mkdir(mode=0o700)
    target=out/'kernel'
    shutil.copytree(source,target,symlinks=True)
    shutil.rmtree(target/'KernelSU')
    shutil.copytree(replay,target/'KernelSU',symlinks=True)
    (target/'fs/susfs.c').write_text(native_hashtable_header(susfs.read_text()))
    apply_patch(target/'KernelSU',patch1)
    apply_patch(target,patch2)
    serv=target/'security/selinux/ss/services.c'
    after=type_bridge(serv.read_text())
    serv.write_text(after)
    need('CONFIG_KSU_SUSFS' in after and 'susfs_spoof_avd_allowed_rcu' in after,
         'SELINUX_SERVICES_PATCH_MISSING')
    # One new *local* BakaSU commit, never falsely labelled an upstream release.
    b=target/'KernelSU'
    changed=set(git(b,'status','--porcelain').splitlines())
    need(len(changed)==2 and all(('kernel/feature/selinux_hide.c' in q or
                                  'kernel/selinux/sepolicy.c' in q) for q in changed),
         'R58_BAKASU_DELTA_NOT_TWO_FILES')
    subprocess.run(['git','-C',str(b),'add','--','kernel/feature/selinux_hide.c',
                    'kernel/selinux/sepolicy.c'],check=True,capture_output=True)
    # Reproducible *local* source commit: real git history, fixed metadata,
    # never a fabricated upstream version or unsigned binary release.
    commit_env={**os.environ,'GIT_AUTHOR_NAME':'VEUX R58 CI',
                'GIT_COMMITTER_NAME':'VEUX R58 CI',
                'GIT_AUTHOR_EMAIL':'veux-r58@invalid.example',
                'GIT_COMMITTER_EMAIL':'veux-r58@invalid.example',
                'GIT_AUTHOR_DATE':'2026-11-03T00:00:00+00:00',
                'GIT_COMMITTER_DATE':'2026-11-03T00:00:00+00:00'}
    subprocess.run(['git','-C',str(b),'commit','--no-gpg-sign',
                    '-m','VEUX: native 5.4 SUSFS type and AVD bridge (R58 diagnostic)'],
                   env=commit_env,check=True,capture_output=True)
    need(git(b,'rev-list','--count','HEAD')=='4560','R58_GIT_VERSION_NOT_NATIVE')
    need(not git(b,'status','--porcelain'),'R58_BAKASU_WORKTREE_DIRTY')
    result={'schema':'VEUX_R58_INTEGRATED_SOURCE_DIAGNOSTIC_V1',
            'status':'NATIVE54_R13_CASS_BAKASU35259_REBASE_SUSFS_PORT_STAGED_COMPILE_PENDING',
            'base_r13_git':'d2537b13ab15fce72e8c0d99e7788805f071aeb4',
            'bakasu_35259_replay_git':provenance['result_commit'],
            'bakasu_local_bridge_git':git(b,'rev-parse','HEAD'),
            'bakasu_real_git_count':4560,
            'version_from_history':35260,
            'native54_susfs_sha256':sha(target/'fs/susfs.c'),
            'native54_explicit_hashtable_header':True,
            'native54_sus_type_hash_collision_guard':True,
            'native54_services_sha256':sha(serv),
            'protected_r13_config_sha256':sha(r13_config),
            'new_susfs_functions':list(['susfs_add_sus_type','susfs_is_sus_type_rcu',
                 'susfs_add_sus_avd_allowed_by_type','susfs_spoof_avd_allowed_rcu']),
            'susfs_snapshot_basis':SUSFS_SNAPSHOT,
            'susfs_8a120081_update_ported':False,
            'native54_avc_audit_rework_ported':False,
            'native54_setprocattr_rework_ported':False,
            'r56_github_source_receipt':build['status'],
            'kernel_compiled':False,'OEM_ABI_proven':False,'device_boot_test':False,
            'boot_img_generated':False,'flash_allowed':False}
    (out/'R58_SOURCE_STAGE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(result['status'])
    return result

def cli():
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=['preflight','stage'],required=True)
    p.add_argument('--r13-main',type=Path,required=True)
    p.add_argument('--r56-main',type=Path,required=True)
    p.add_argument('--r13-config',type=Path,required=True)
    p.add_argument('--kernel',type=Path)
    p.add_argument('--replay',type=Path)
    p.add_argument('--r54-stage',type=Path)
    p.add_argument('--r56-stage',type=Path)
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    try:
        if a.mode=='preflight':print(json.dumps(preflight(a.r13_main,a.r56_main,a.r13_config),sort_keys=True))
        else:
            need(all((a.kernel,a.replay,a.r54_stage,a.r56_stage,a.out)),'STAGE_ARGUMENTS_MISSING')
            stage(a)
        return 0
    except (Blocked,ValueError,KeyError,OSError,subprocess.CalledProcessError) as e:
        print('R58_FAIL_CLOSED='+str(e),file=sys.stderr)
        return 3

if __name__=='__main__':sys.exit(cli())
