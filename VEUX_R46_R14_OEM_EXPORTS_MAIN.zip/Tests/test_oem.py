from pathlib import Path
import importlib.util
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('oem_restore', ROOT / 'Tools/restore_oem.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def function(text, signature):
    start = text.index(signature)
    opening = text.index('{', start)
    depth = 1
    for position in range(opening + 1, len(text)):
        depth += (text[position] == '{') - (text[position] == '}')
        if depth == 0:
            return text[start:position + 1]
    raise AssertionError('Unclosed C function')


class OEMTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original_R13', self.source)

    def test_complete_six_file_port_matches_all_postimage_pins(self):
        proof = m.apply_source(self.source)
        self.assertEqual(proof['changed_files'], 6)
        for name, pin in m.pins().items():
            self.assertEqual(m.sha(self.source / name), pin['after_sha256'])
        soc = (self.source / 'sound/soc/soc-core.c').read_text()
        self.assertIn('int smartpa_type = PA_INVALID;', soc)
        self.assertIn('EXPORT_SYMBOL(smartpa_type);', soc)
        self.assertIn('return smartpa_type;', soc)
        self.assertIn('hardwareinfo_set_prop(HARDWARE_SMARTPA, "FS1962")', soc)
        # Existing enum users and all unrelated public types remain available.
        before = (ROOT / 'Original_R13/include/sound/soc.h').read_text()
        after = (self.source / 'include/sound/soc.h').read_text()
        self.assertEqual(after, before.replace(
            'void snd_soc_set_smartpa_type(const char *name, enum smartpa_type pa_type);',
            'int snd_soc_set_smartpa_type(const char *name, int pa_type);', 1))

    def test_port_reproduces_from_complete_pinned_sources(self):
        root = Path(self.temp.name) / 'reproduce'
        for name in ('Original_R13', 'StockReference'):
            shutil.copytree(ROOT / name, root / name)
        (root / 'Tools').mkdir()
        shutil.copyfile(ROOT / 'Tools/build_scoped_port.py', root / 'Tools/build_scoped_port.py')
        result = subprocess.run([sys.executable, '-B', str(root / 'Tools/build_scoped_port.py')],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        for name in ('RESTORE_OEM_HARDWARE_SMARTPA.patch', 'FILE_PINS.json'):
            self.assertEqual((root / 'References' / name).read_bytes(),
                             (ROOT / 'References' / name).read_bytes())

    def test_preflight_checks_do_not_change_source(self):
        before = {str(p.relative_to(self.source)): p.read_bytes()
                  for p in self.source.rglob('*') if p.is_file()}
        proof = m.check_source(self.source)
        self.assertFalse(proof['source_changed'])
        self.assertEqual(before, {str(p.relative_to(self.source)): p.read_bytes()
                                  for p in self.source.rglob('*') if p.is_file()})

    def test_late_drift_rejected_before_creating_driver(self):
        path = self.source / 'include/sound/soc.h'
        path.write_text(path.read_text() + '\n/* drift */\n')
        before = {str(p.relative_to(self.source)): p.read_bytes()
                  for p in self.source.rglob('*') if p.is_file()}
        with self.assertRaisesRegex(ValueError, 'OEM_PREIMAGE_CHANGED'):
            m.apply_source(self.source)
        self.assertEqual(before, {str(p.relative_to(self.source)): p.read_bytes()
                                  for p in self.source.rglob('*') if p.is_file()})

    def test_broken_new_file_symlink_rejected(self):
        path = self.source / 'drivers/misc/hardware_info.c'
        path.symlink_to(Path(self.temp.name) / 'outside')
        with self.assertRaisesRegex(ValueError, 'UNSAFE_SOURCE'):
            m.apply_source(self.source)

    def test_existing_unrelated_driver_not_overwritten(self):
        path = self.source / 'drivers/misc/hardware_info.c'
        path.write_text('existing implementation\n')
        with self.assertRaisesRegex(ValueError, 'NEW_OEM_FILE_ALREADY_PRESENT'):
            m.apply_source(self.source)
        self.assertEqual(path.read_text(), 'existing implementation\n')

    def test_reapplication_rejected(self):
        m.apply_source(self.source)
        with self.assertRaisesRegex(ValueError, 'OEM_PREIMAGE_CHANGED'):
            m.apply_source(self.source)

    def test_only_hardware_info_config_addition_permitted(self):
        before = {'CONFIG_WT_QGKI': 'y', 'CONFIG_NR_CPUS': '32'}
        after = {**before, 'CONFIG_HARDWARE_INFO': 'y'}
        self.assertEqual(m.verify_config(before, after), {'CONFIG_HARDWARE_INFO': [None, 'y']})
        with self.assertRaisesRegex(ValueError, 'UNEXPECTED_R13_R14_CONFIG_DELTA'):
            m.verify_config(before, {**after, 'CONFIG_NR_CPUS': '64'})
        with self.assertRaisesRegex(ValueError, 'STOCK_SMARTPA_CONFIGURATION_DISABLED'):
            m.verify_config({'CONFIG_WT_QGKI': 'n'}, {'CONFIG_WT_QGKI': 'n', 'CONFIG_HARDWARE_INFO': 'y'})

    def test_all_three_stock_interfaces_and_zero_missing_required(self):
        expected = {**m.EXPECTED, 'old_good': '0x12345678'}
        reference = {'old_good': '0x12345678', 'snd_soc_set_smartpa_type': '0xde9e3baf'}
        self.assertEqual(len(m.verify_abi(expected, reference, expected)['gained_matching_symbols']), 3)
        for name in m.EXPECTED:
            with self.assertRaisesRegex(ValueError, 'OEM_EXPORT_NOT_STOCK_COMPATIBLE'):
                m.verify_abi({**expected, name: '0x00000000'}, reference, expected)
        with self.assertRaisesRegex(ValueError, 'ORIGINAL_IMPORTS_STILL_NOT_EXPORTED'):
            m.verify_abi(m.EXPECTED, {}, expected)

    def test_old_stock_match_must_not_regress(self):
        expected = {**m.EXPECTED, 'old_good': '0x12345678'}
        with self.assertRaisesRegex(ValueError, 'PREVIOUS_STOCK_MATCH_REGRESSED'):
            m.verify_abi({**expected, 'old_good': '0x87654321'}, {'old_good': '0x12345678'}, expected)

    def test_export_names_without_real_code_and_data_rejected(self):
        path = Path(self.temp.name) / 'System.map'
        path.write_text(''.join('0000000000001000 r __ksymtab_' + n + '\n' for n in m.EXPECTED))
        with self.assertRaisesRegex(ValueError, 'REAL_OEM_CODE_MISSING'):
            m.prove_linked(path)

    def test_driver_must_have_a_real_device_initcall(self):
        path = Path(self.temp.name) / 'System.map'
        lines = ['0000000000001000 T hardwareinfo_set_prop',
                 '0000000000002000 T snd_soc_set_smartpa_type',
                 '0000000000003000 t hardwareinfo_init_module',
                 '0000000000004000 D smartpa_type']
        lines += ['0000000000005000 r __ksymtab_' + name for name in m.EXPECTED]
        path.write_text('\n'.join(lines) + '\n')
        with self.assertRaisesRegex(ValueError, 'HARDWARE_INFO_INITCALL_MISSING_OR_DUPLICATE'):
            m.prove_linked(path)
        path.write_text(path.read_text() +
                        '0000000000006000 d __initcall_141_318_hardwareinfo_init_module6\n')
        self.assertIn('hardwareinfo_init_module6', m.prove_linked(path)['device_initcall'])

    def test_real_oem_c_logic_bounds_ioctl_and_smartpa_flow(self):
        # Exercise the actual C bodies on the host with narrow user-copy and
        # string adapters. Separate Clang tests compile the two complete ARM64
        # units against genuine kernel headers; this host test proves pure logic.
        driver = (ROOT / 'Candidate_R14/drivers/misc/hardware_info.c').read_text()
        soc = (ROOT / 'Candidate_R14/sound/soc/soc-core.c').read_text()
        header = (ROOT / 'Candidate_R14/include/sound/soc.h').read_text()
        prefix = driver[:driver.index('int __weak tid_hardware_info_get')]
        prefix = re.sub(r'^\s*#include[^\n]*\n', '', prefix, flags=re.M)
        enum = re.search(r'enum smartpa_type\s*\{.*?\};', header, flags=re.S).group(0)
        harness = r'''
#include <assert.h>
#include <errno.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include "hardware_info.h"
#define __user
#define PAGE_SIZE 4096
#define pr_info(...) ((void)0)
#define pr_err(...) ((void)0)
#define IS_REACHABLE(option) 1
#define mutex_lock(lock) ((void)(lock))
#define mutex_unlock(lock) ((void)(lock))
struct device;
struct device_attribute;
static int smartpa_mutex;
static long strscpy(char *d, const char *s, size_t n) {
    size_t length = strlen(s), copied = length < n - 1 ? length : n - 1;
    memcpy(d, s, copied); d[copied] = 0;
    return length < n ? (long)copied : -E2BIG;
}
static size_t copy_from_user(void *d, const void *s, size_t n) {
    if (!s) return n;
    memcpy(d, s, n); return 0;
}
static size_t copy_to_user(void *d, const void *s, size_t n) {
    if (!d) return n;
    memcpy(d, s, n); return 0;
}
static int scnprintf(char *d, size_t n, const char *fmt, ...) {
    va_list args; va_start(args, fmt); int r = vsnprintf(d, n, fmt, args); va_end(args);
    return r < 0 ? r : (r < (int)n ? r : (int)n - 1);
}
'''
        harness += prefix + enum + '\nint smartpa_type = PA_INVALID;\n'
        harness += function(driver, 'static long hardwareinfo_ioctl(') + '\n'
        harness += function(driver, 'static ssize_t show_boardinfo(') + '\n'
        harness += function(soc, 'int snd_soc_set_smartpa_type(') + '\n'
        harness += r'''
int main(void) {
    for (int i = 0; i < HARDWARE_MAX_ITEM; i++) {
        assert(hardwareinfo_items[i] != NULL);
        assert(hardwareinfo_set_prop(i, "initial") == 0);
    }
    char before[sizeof(hardwareinfo_name)];
    memcpy(before, hardwareinfo_name, sizeof(before));
    assert(hardwareinfo_set_prop(-1, "bad") < 0);
    assert(hardwareinfo_set_prop(HARDWARE_MAX_ITEM, "bad") < 0);
    assert(hardwareinfo_set_prop(HARDWARE_SMARTPA, NULL) < 0);
    assert(!memcmp(before, hardwareinfo_name, sizeof(before)));
    char overlong[512]; memset(overlong, 'x', sizeof(overlong)); overlong[511] = 0;
    assert(hardwareinfo_set_prop(HARDWARE_SMARTPA, overlong) == 0);
    assert(strlen(hardwareinfo_name[HARDWARE_SMARTPA]) == 63);
    char input[64]; memset(input, 'A', sizeof(input)); input[63] = 0;
    assert(hardwareinfo_ioctl(NULL, HARDWARE_BACK_CAM_MOUDULE_ID_SET, (unsigned long)input) == 0);
    assert(!strcmp(hardwareinfo_name[HARDWARE_BACK_CAM_MOUDULE_ID], input));
    assert(hardwareinfo_ioctl(NULL, HARDWARE_FRONT_CAM_MODULE_ID_SET, 0) == -EFAULT);
    assert(snd_soc_set_smartpa_type("test", FS1962) == FS1962);
    assert(smartpa_type == FS1962);
    char output[64]; memset(output, '!', sizeof(output));
    assert(hardwareinfo_ioctl(NULL, HARDWARE_SMARTPA_IC_GET, (unsigned long)output) == 0);
    assert(!strcmp(output, "FS1962"));
    assert(snd_soc_set_smartpa_type("test", AW88261) == AW88261);
    assert(!strcmp(hardwareinfo_name[HARDWARE_SMARTPA], "AW88261"));
    assert(snd_soc_set_smartpa_type("test", PA_MAX_NUM + 1) == AW88261);
    assert(!strcmp(hardwareinfo_name[HARDWARE_SMARTPA], "unknown"));
    assert(hardwareinfo_ioctl(NULL, 0xffffffffU, (unsigned long)output) == -EINVAL);
    struct { uint64_t pre; char text[4096]; uint64_t post; } page;
    page.pre = 0x1234567812345678ULL; page.post = 0x8765432187654321ULL;
    memset(page.text, 0xa5, sizeof(page.text));
    long used = show_boardinfo(NULL, NULL, page.text);
    assert(used > 0 && used < 4096);
    assert(page.pre == 0x1234567812345678ULL && page.post == 0x8765432187654321ULL);
    assert(strstr(page.text, "USB_PD") && strstr(page.text, "SMARTPA"));
    int lines = 0; for (long i = 0; i < used; i++) lines += page.text[i] == '\n';
    assert(lines == HARDWARE_MAX_ITEM);
    puts("REAL_OEM_C_LOGIC_BOUNDS_IOCTL_AND_SMARTPA_FLOW_PASS");
    return 0;
}
'''
        path = Path(self.temp.name) / 'logic.c'
        path.write_text(harness)
        binary = Path(self.temp.name) / 'logic'
        build = subprocess.run(['cc', '-std=gnu11', '-O1', '-fsanitize=address,undefined',
                                '-fno-omit-frame-pointer', '-I' + str(ROOT / 'Candidate_R14/include/linux'),
                                str(path), '-o', str(binary)], capture_output=True, text=True)
        self.assertEqual(build.returncode, 0, build.stderr)
        run = subprocess.run([str(binary)], capture_output=True, text=True, timeout=15,
                             env={**os.environ, 'ASAN_OPTIONS': 'detect_leaks=0'})
        self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
        self.assertIn('REAL_OEM_C_LOGIC_BOUNDS_IOCTL_AND_SMARTPA_FLOW_PASS', run.stdout)


if __name__ == '__main__':
    unittest.main()
