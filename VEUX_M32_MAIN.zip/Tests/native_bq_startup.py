#!/usr/bin/env python3
"""Execute real BQ probe/DT functions with per-resource failure injection."""
import argparse
from pathlib import Path
import re,subprocess,tempfile
ROOT=Path(__file__).resolve().parents[1]
DRIVER='drivers/power/supply/qcom/bq2589x_charger.c'
def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('source',type=Path);a=p.parse_args()
 source=a.source.read_text();before=(ROOT/'References/M31_PROVEN_BQ.c').read_text()
 enum=before[before.index('enum bq2589x_part_no {'):before.index('enum bq2589x_part_no {')+before[before.index('enum bq2589x_part_no {'):].index('};')+2]
 ref=function(before,'bq2589x_parse_dt').replace('bq2589x_parse_dt(', 'bq2589x_parse_dt_reference(',1)
 ref+='\n'+function(before,'bq2589x_charger_probe').replace('bq2589x_charger_probe(', 'bq2589x_charger_probe_reference(',1).replace('bq2589x_parse_dt(', 'bq2589x_parse_dt_reference(')
 body=function(source,'bq2589x_parse_dt')+'\n'+function(source,'bq2589x_charger_probe')
 tests=r'''
static int resources(void){return awake_refs+battery_refs+usb_refs+gpio_refs+sysfs_refs+iio_refs+irq_refs;}
int main(void){
 reset(BQ25890,true);fail_event=REQUEST_IRQ;fail_code=-EIO;
 CHECK(bq2589x_charger_probe_reference(&client,NULL)==-EIO);
 CHECK(awake_refs==1&&battery_refs==1&&usb_refs==1&&gpio_refs==1&&sysfs_refs==1&&iio_refs==1);
 puts("BQ_M31_FAILED_PROBE_LEAVES_SIX_RESOURCE_OWNERS=REPRODUCED");
 reset(BQ25890,true);fail_event=GET_GPIO;fail_ordinal=1;fail_code=-EPROBE_DEFER;
 CHECK(bq2589x_parse_dt_reference(&client.dev,&state)==0);CHECK(state.otg_gpio==-EPROBE_DEFER);
 puts("BQ_M31_NEGATIVE_GPIO_IGNORED=REPRODUCED");
 reset(BQ25890,true);fail_event=PROP_U32;fail_ordinal=1;fail_code=-EINVAL;
 CHECK(bq2589x_charger_probe_reference(&client,NULL)==0);CHECK(count(INIT_DEVICE)==1&&count(REQUEST_IRQ)==1);
 puts("BQ_M31_DT_FAILURE_CONTINUES=REPRODUCED");
 int parts[]={BQ25890,SYV690};int errors[]={-EIO,-ENOMEM,-EPROBE_DEFER,-EINVAL,-EREMOTEIO};
 int failures[]={DETECT,IIO_INIT,WAKEUP,INIT_DEVICE,GPIO_REQUEST,GPIO_TO_IRQ,SYSFS_CREATE,REQUEST_IRQ};
 int success_cases=0,fault_cases=0;
 for(int chip=0;chip<2;chip++)for(int dt=0;dt<2;dt++){
  reset(parts[chip],dt);CHECK(bq2589x_charger_probe_reference(&client,NULL)==0);
  int saved_count=used;memcpy(saved,trace,sizeof(trace));
  reset(parts[chip],dt);CHECK(bq2589x_charger_probe(&client,NULL)==0);
  CHECK(used==saved_count&&!memcmp(trace,saved,(size_t)used*sizeof(trace[0])));
  CHECK(state.startup_ready&&early_ready==0);CHECK(resources()==7);CHECK(g_bq==&state&&client.data==&state);
  CHECK(state.is_bq25890h==(chip==0));CHECK(count(INIT_WORK_ITEM)==6&&count(FORCE_DPDM)==1);success_cases++;
  for(int f=0;f<8;f++)for(int e=0;e<5;e++)for(int nullable=0;nullable<4;nullable++){
   reset(parts[chip],dt);fail_event=failures[f];fail_code=errors[e];nullable_battery=nullable&1;nullable_usb=nullable&2;
   int expected=fail_event==DETECT?-ENODEV:(fail_event==WAKEUP?-ENOMEM:errors[e]);
   CHECK(bq2589x_charger_probe(&client,NULL)==expected);
   CHECK(resources()==0);CHECK(!state.startup_ready&&early_ready==0);CHECK(g_bq==NULL&&client.data==NULL);
   CHECK(count(FORCE_DPDM)==0&&count(ENABLE_WAKE)==0);CHECK(count(CANCEL_WORK)==0&&count(CANCEL_DELAYED)==0);
   CHECK(count(IIO_UNREGISTER)==(f>=2));CHECK(count(WAKE_UNREGISTER)==(f>=3));
   CHECK(count(GPIO_FREE)==(f>=5));CHECK(count(SYSFS_REMOVE)==(f==7));
   fault_cases++;
  }
 }
 for(int chip=0;chip<2;chip++)for(int kind=PROP_U32;kind<=GET_GPIO;kind++)for(int k=1;k<=(kind==PROP_U32?5:4);k++)for(int e=0;e<5;e++){
  reset(parts[chip],true);fail_event=kind;fail_ordinal=k;fail_code=errors[e];
  CHECK(bq2589x_charger_probe(&client,NULL)==errors[e]);CHECK(resources()==0);
  CHECK(g_bq==NULL&&client.data==NULL&&!state.startup_ready);
  CHECK(count(INIT_DEVICE)==0&&count(GPIO_REQUEST)==0&&count(REQUEST_IRQ)==0);
  CHECK(count(kind)==k);fault_cases++;
 }
 reset(BQ25890,true);gpio_zero=1;CHECK(bq2589x_parse_dt(&client.dev,&state)==0);CHECK(state.otg_gpio==0);
 reset(BQ25890,true);alloc_fail=1;CHECK(bq2589x_charger_probe(&client,NULL)==-ENOMEM);CHECK(count(PRIV)==0&&resources()==0&&client.data==NULL);
 reset(99,true);CHECK(bq2589x_charger_probe(&client,NULL)==-ENODEV);CHECK(resources()==0&&client.data==NULL);
 printf("BQ_STARTUP_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; ownership, GPIO defer, null dependencies and publication order\n",assertions,success_cases,fault_cases);
 return 0;
}
'''
 with tempfile.TemporaryDirectory(prefix='m32-bq-startup-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text((ROOT/'References/native_bq_startup_stubs.h').read_text()+'\n'+enum+'\n'+ref+'\n'+body+'\n'+tests)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True,timeout=20)
if __name__=='__main__':main()
