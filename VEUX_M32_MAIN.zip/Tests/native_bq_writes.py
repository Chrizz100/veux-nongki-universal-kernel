#!/usr/bin/env python3
"""Run the real BQ setters and IIO writer with bus, GPIO and property faults."""
import argparse
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DRIVER = 'drivers/power/supply/qcom/bq2589x_charger.c'


def function(source, name):
    m = re.search(r'^(?:static\s+)?[^\n;]+\b' + name + r'\([^;]+?\n\{', source, re.M)
    if not m:
        raise ValueError(name)
    return source[m.start():source.index('\n}', m.end()) + 2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', type=Path)
    args = p.parse_args()
    source = args.source.read_text()
    baseline = (ROOT / 'References/M30_PROVEN_BQ.c').read_text()
    definitions = '\n'.join(line for line in (ROOT / 'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()
                            if line.startswith('#define BQ2589X_'))
    channels = list(dict.fromkeys(re.findall(r'\bPSY_IIO_[A-Z_]+', source)))
    constants = '\n'.join('#define ' + n + ' ' + str(i) for i, n in enumerate(channels))
    prefix = r'''
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
typedef uint8_t u8;
struct mutex { pthread_mutex_t value; };
#define DEFINE_MUTEX(n) struct mutex n = { PTHREAD_MUTEX_INITIALIZER }
#define mutex_lock(m) pthread_mutex_lock(&(m)->value)
#define mutex_unlock(m) pthread_mutex_unlock(&(m)->value)
#define dev_err(...) ((void)0)
#define pr_err(...) ((void)0)
#define pr_debug(...) ((void)0)
#define pr_err_ratelimited(...) ((void)0)
#define udelay(x) ((void)0)
#define POWER_SUPPLY_PROP_CAPACITY 1
#define POWER_SUPPLY_PROP_TEMP 2
#define BQ2589X_STATUS_CHARGE_ENABLE 4
#define EPROBE_DEFER 517
#define smp_load_acquire(p) __atomic_load_n((p), __ATOMIC_ACQUIRE)
struct bq2589x_config { bool enable_term, otg_status; int input_current; };
struct bq2589x {
 void *client, *dev, *batt_psy, *wt_ws;
 struct bq2589x_config cfg;
 bool is_bq25890h, startup_ready;
 int status, hz_flag, usb_switch_flag, usb_swtich_status;
 int otg_gpio, usb_switch1, usb_switch2, wakeup_flag;
};
struct iio_dev { struct bq2589x *data; };
struct iio_chan_spec { int channel; };
union power_supply_propval { int intval; };
static struct bq2589x state, other, saved_state, *g_bq;
static struct iio_dev iio = { &state };
static DEFINE_MUTEX(bq2589x_i2c_lock);
enum { READ=1, WRITE, GPIO, PROPERTY, AWAKE, RELAX };
struct event { int kind, a, b; };
static struct event events[256], saved_events[256];
static unsigned char registers[256], saved_registers[256];
static int used, counts[7], fail_kind, fail_at, fail_code, last_failure, assertions;
static int capacity, temperature;
static int event(int kind, int a, int b) {
 if (used >= 256) abort();
 events[used++] = (struct event){kind,a,b};
 counts[kind]++;
 if (kind == fail_kind && counts[kind] >= fail_at &&
     (kind != READ || counts[kind] < fail_at + 3)) {
  last_failure = used - 1;
  return fail_code;
 }
 return 0;
}
static void *iio_priv(struct iio_dev *d) { return d->data; }
static int i2c_smbus_read_byte_data(void *client, u8 reg) {
 int rc = event(READ,reg,0); return rc < 0 ? rc : registers[reg];
}
static int i2c_smbus_write_byte_data(void *client, u8 reg, u8 val) {
 int rc = event(WRITE,reg,val); if (rc < 0) return rc; registers[reg]=val; return 0;
}
static int gpio_direction_output(int gpio, int val) { return event(GPIO,gpio,val); }
static int power_supply_get_property(void *psy, int prop, union power_supply_propval *v) {
 int rc = event(PROPERTY,prop,0); if (rc < 0) return rc;
 v->intval = prop == POWER_SUPPLY_PROP_CAPACITY ? capacity : temperature; return 0;
}
static void __pm_stay_awake(void *ws) { event(AWAKE,0,0); }
static void __pm_relax(void *ws) { event(RELAX,0,0); }
'''
    names = ['bq2589x_read_byte', 'bq2589x_write_byte', 'bq2589x_update_bits',
             'bq2589x_enable_otg', 'bq2589x_disable_otg', 'bq2589x_set_otg_volt', 'bq2589x_set_otg_current',
             'bq2589x_enable_charger', 'bq2589x_disable_charger', 'bq2589x_set_charge_current',
             'bq2589x_set_term_current', 'bq2589x_set_chargevoltage', 'bq2589x_set_input_volt_limit',
             'bq2589x_set_input_current_limit', 'bq2589x_enter_hiz_mode', 'bq2589x_exit_hiz_mode',
             'bq2589x_enable_term', 'bq2589x_usb_switch', 'bq_iio_write_raw']
    body = '\n\n'.join(function(source, name) for name in names)
    reference = function(baseline, 'bq2589x_usb_switch').replace('bq2589x_usb_switch(', 'bq2589x_usb_switch_reference(', 1)
    reference += '\n\n' + function(baseline, 'bq_iio_write_raw').replace('bq_iio_write_raw(', 'bq_iio_write_raw_reference(', 1).replace('bq2589x_usb_switch(', 'bq2589x_usb_switch_reference(')
    tests = r'''
#define CHECK(x) do { assertions++; if (!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while(0)
static void reset(int chip, int psy, int wake, int off, int boundary) {
 memset(&state,0,sizeof(state)); memset(&other,0,sizeof(other));
 memset(registers,0xa5,sizeof(registers)); memset(events,0,sizeof(events)); memset(counts,0,sizeof(counts));
 used=fail_kind=fail_at=fail_code=0;last_failure=-1;
 state.startup_ready=true;state.is_bq25890h=chip; state.batt_psy=psy?&state:NULL;
 state.otg_gpio=11;state.usb_switch1=12;state.usb_switch2=13;
 state.cfg.input_current=777;state.cfg.enable_term=true;state.cfg.otg_status=off;
 state.hz_flag=1;state.usb_switch_flag=1;state.usb_swtich_status=1;state.wakeup_flag=wake;
 registers[BQ2589X_REG_03]&=~BQ2589X_OTG_CONFIG_MASK;
 if(off)registers[BQ2589X_REG_03]|=BQ2589X_OTG_ENABLE<<BQ2589X_OTG_CONFIG_SHIFT;
 state.status=(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK)?BQ2589X_STATUS_CHARGE_ENABLE:0;
 capacity=boundary?6:5;temperature=boundary?100:99;
 other.otg_gpio=91;other.usb_switch1=92;other.usb_switch2=93;g_bq=&state;
}
static int call(int channel, int value, bool reference) {
 struct iio_chan_spec ch={channel};
 return reference ? bq_iio_write_raw_reference(&iio,&ch,value,0,0) : bq_iio_write_raw(&iio,&ch,value,0,0);
}
int main(void) {
 reset(0,1,0,0,0);state.startup_ready=false;CHECK(call(PSY_IIO_OTG_ENABLE,1,false)==-EPROBE_DEFER);CHECK(used==0);CHECK(!state.cfg.otg_status);
 reset(0,1,0,0,0);fail_kind=WRITE;fail_at=1;fail_code=-EREMOTEIO;
 CHECK(call(PSY_IIO_MAIN_CHAGER_CURRENT,1500,true)==0);CHECK(state.cfg.input_current==1500);
 puts("BQ_M30_WRITE_FALSE_SUCCESS_AND_PREMATURE_CACHE=REPRODUCED");
 reset(0,1,0,0,0);fail_kind=GPIO;fail_at=1;fail_code=-EIO;
 CHECK(bq2589x_usb_switch_reference(&state,false)==0);CHECK(state.usb_swtich_status==0);CHECK(counts[GPIO]==2);
 puts("BQ_M30_USB_GPIO_FALSE_SUCCESS=REPRODUCED");
 const int scenarios[][2]={
  {PSY_IIO_MAIN_CHAGER_HZ,-1},{PSY_IIO_MAIN_CHAGER_HZ,0},{PSY_IIO_MAIN_CHAGER_HZ,1},
  {PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,100},{PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,3100},{PSY_IIO_MAIN_INPUT_CURRENT_SETTLED,4000},
  {PSY_IIO_MAIN_INPUT_VOLTAGE_SETTLED,4000},{PSY_IIO_MAIN_INPUT_VOLTAGE_SETTLED,4500},{PSY_IIO_MAIN_INPUT_VOLTAGE_SETTLED,9000},
  {PSY_IIO_MAIN_CHAGER_CURRENT,100},{PSY_IIO_MAIN_CHAGER_CURRENT,1500},{PSY_IIO_MAIN_CHAGER_CURRENT,3100},{PSY_IIO_MAIN_CHAGER_CURRENT,4000},
  {PSY_IIO_CHARGING_ENABLED,0},{PSY_IIO_CHARGING_ENABLED,1},
  {PSY_IIO_OTG_ENABLE,0},{PSY_IIO_OTG_ENABLE,1},{PSY_IIO_OTG_ENABLE,2},
  {PSY_IIO_MAIN_CHAGER_TERM,200},{PSY_IIO_MAIN_CHAGER_TERM,300},
  {PSY_IIO_BATTERY_VOLTAGE_TERM,4200},{PSY_IIO_BATTERY_VOLTAGE_TERM,4352},{PSY_IIO_BATTERY_VOLTAGE_TERM,4608},
  {PSY_IIO_ENABLE_CHAGER_TERM,0},{PSY_IIO_ENABLE_CHAGER_TERM,1},{PSY_IIO_ENABLE_CHAGER_TERM,2}
 };
 const int errors[]={-EIO,-EREMOTEIO,-ETIMEDOUT,-ENODEV,-ENXIO};
 int scenario_count=sizeof(scenarios)/sizeof(scenarios[0]);
 int success_cases=0,fault_cases=0;
 for(int chip=0;chip<2;chip++)for(int psy=0;psy<2;psy++)for(int wake=0;wake<2;wake++)for(int boundary=0;boundary<2;boundary++)
 for(int s=0;s<scenario_count;s++) {
  int ch=scenarios[s][0],v=scenarios[s][1],off=ch==PSY_IIO_OTG_ENABLE&&!v;
  reset(chip,psy,wake,off,boundary);
  CHECK(call(ch,v,true)==0);
  int saved_used=used;int saved_counts[7];memcpy(saved_counts,counts,sizeof(counts));
  memcpy(saved_events,events,sizeof(events));memcpy(saved_registers,registers,sizeof(registers));saved_state=state;
  reset(chip,psy,wake,off,boundary);
  CHECK(call(ch,v,false)==0);
  CHECK(used==saved_used);CHECK(!memcmp(events,saved_events,(size_t)used*sizeof(events[0])));
  CHECK(!memcmp(registers,saved_registers,sizeof(registers)));CHECK(!memcmp(&state,&saved_state,sizeof(state)));
  success_cases++;
  for(int kind=READ;kind<=PROPERTY;kind++)for(int k=1;k<=saved_counts[kind];k++)for(int e=0;e<5;e++) {
   reset(chip,psy,wake,off,boundary);fail_kind=kind;fail_at=k;fail_code=errors[e];
   CHECK(call(ch,v,false)==errors[e]);CHECK(last_failure>=0);
   CHECK(counts[kind]==k+(kind==READ?2:0));
   for(int i=last_failure+1;i<used;i++)CHECK(events[i].kind==AWAKE||events[i].kind==RELAX);
   if(kind==READ)CHECK(counts[WRITE]==k-1);
   if(kind==WRITE)CHECK(counts[READ]==k);
   if(ch==PSY_IIO_MAIN_CHAGER_HZ)CHECK(state.hz_flag==1&&state.usb_switch_flag==1);
   if(ch==PSY_IIO_MAIN_CHAGER_CURRENT)CHECK(state.cfg.input_current==((k==2)?100:777));
   if(ch==PSY_IIO_ENABLE_CHAGER_TERM)CHECK(state.cfg.enable_term==true);
   if(ch==PSY_IIO_OTG_ENABLE) {
    bool hardware_on=!!(registers[BQ2589X_REG_03]&BQ2589X_OTG_CONFIG_MASK);
    CHECK(state.cfg.otg_status==hardware_on);
    CHECK(state.wakeup_flag==(hardware_on?(off?wake:1):(!off?wake:0)));
    if(kind==GPIO)CHECK(state.usb_swtich_status==1);
   }
   fault_cases++;
  }
 }
 /* The callback must select its own device, independent of the global pointer. */
 reset(0,1,0,0,1);g_bq=&other;CHECK(call(PSY_IIO_OTG_ENABLE,1,false)==0);
 CHECK(events[0].kind==GPIO&&events[0].a==11);CHECK(events[1].a==12&&events[2].a==13);
 CHECK(other.cfg.otg_status==false);CHECK(other.usb_swtich_status==0);CHECK(state.cfg.otg_status==true);
 reset(0,1,0,0,1);g_bq=NULL;CHECK(call(PSY_IIO_OTG_ENABLE,1,false)==0);
 CHECK(state.cfg.otg_status&&state.wakeup_flag);
 for(int en=0;en<2;en++)for(int k=1;k<=2;k++)for(int e=0;e<5;e++) {
  reset(0,1,0,0,0);state.usb_swtich_status=!en;fail_kind=GPIO;fail_at=k;fail_code=errors[e];
  CHECK(bq2589x_usb_switch(&state,en)==errors[e]);CHECK(counts[GPIO]==k);CHECK(state.usb_swtich_status==!en);
 }
 reset(0,1,0,0,0);CHECK(call(9999,0,false)==-EINVAL);CHECK(used==0);
 printf("BQ_WRITE_ERROR_HOST_TESTS=PASS; assertions=%d; success_cases=%d; fault_cases=%d; exact success traces and partial OTG state\n",assertions,success_cases,fault_cases);
 return 0;
}
'''
    with tempfile.TemporaryDirectory(prefix='m31-bq-writes-') as tmp:
        root = Path(tmp)
        c, exe = root / 'test.c', root / 'test'
        c.write_text(prefix + '\n' + definitions + '\n' + constants + '\n' + body + '\n' + reference + '\n' + tests)
        subprocess.run(['cc', '-std=gnu11', '-O2', '-Wall', '-Wextra', '-Werror', '-Wno-unused-parameter',
                        '-Wno-unused-function', '-pthread', '-fsanitize=undefined', '-fno-sanitize-recover=all',
                        str(c), '-o', str(exe)], check=True)
        subprocess.run([str(exe)], check=True, timeout=20)


if __name__ == '__main__':
    main()
