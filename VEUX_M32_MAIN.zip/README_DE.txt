VEUX M32 – BQ-Startfehler: Ressourcenfreigabe, GPIO und fruehe IIO-Zugriffe – NOFLASH
Basis: gruener M31-Lauf 43719946706 / Commit d70fedcfdca36e95c388e2210994513895b18fd4.

UPLOAD AM SMARTPHONE
1. VEUX_M32_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M32_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Anschliessend Workflow manuell starten.
   Historische Pakete werden aus festen Commits geladen und authentifiziert.

M31 AUSGEWERTET
Alle 32 Artefakte heruntergeladen und SHA-256/ZIP-CRC geprueft: 798 Dateien,
735 Textdateien, 179 JSON-Dateien, 35.045.452 dekodierte Textbytes.
Neun Archive enthalten historische Zwischenfehler; die sechs betroffenen Ziele
sind spaeter in R18 erfolgreich kompiliert. Finaler M31 unabhaengig geprueft:
40 erfolgreiche make-Aufrufe, BQ-Lese-/Schreibfehlerzweige in Image und vmlinux,
eingebettete Konfiguration, 1.423 passende Import-CRCs, 37 passende Module,
unveraenderte komplette Exporttabelle und Originalkennung. Boot.img und AK3
byteidentisch aus den gepinnten Referenzen rekonstruiert. Alle Archivberichte
sind ausgewertet; tiefe Kernel-/ABI-/Boot-Pruefungen betreffen den finalen M31.
Berichte: Reports/RUN43719946706_32_ARTEFAKTE.zip und M31_INDEPENDENT_VERIFICATION.json.

M32 REPARATURGRUPPE
Bei fehlgeschlagenem request_irq bleiben im M31 sechs Ressourcenbesitzer zurueck:
IIO-Registrierung, Wakeup-Quelle, zwei Power-Supply-Referenzen, GPIO und Sysfs.
Zudem ignoriert Probe Fehler von parse_dt; dessen vier GPIO-Abfragen pruefen
den alten ret-Wert statt des tatsaechlichen GPIO-Ergebnisses.
M32 fuehrt die Abbruchpfade nach Besitzstand zusammen: nur erfolgreich
angeforderte GPIOs/Sysfs werden freigegeben, vorhandene Referenzen zurueckgegeben,
die IIO-Registrierung explizit aufgehoben und clientdata/globaler Zeiger bereinigt.
Wegen der fruehen IIO-Registrierung werden Lese-/Schreibcallbacks bis zum Ende
eines erfolgreichen Starts mit -EPROBE_DEFER abgewiesen. Ein privates Ready-Feld
wird mit Release/Acquire publiziert; so greifen diese Callbacks bei Startfehlern
nicht auf unvollstaendige oder gerade freigegebene Ressourcen zu.
Fehler einer Wakeup-Allokation beenden Probe mit -ENOMEM. GPIO-/DT-Fehler und
insbesondere -EPROBE_DEFER werden bis zum Aufrufer weitergegeben.
Die Fehleraufraeumung wird ausschliesslich vor erfolgreicher IRQ-Installation
erreicht. Es werden dort keine nie gestarteten Workqueues abgebrochen.

Nur parse_dt, Probe und die beiden Callback-Eingangspruefungen sowie das private
Ready-Feld sind geaendert. Die eigentlichen M30/M31-Lese-/Schreibfunktionskoerper
bleiben nach Entfernen der neuen Eingangspruefung byteidentisch. Alle anderen
Treiberbytes sind identisch zum gepinnten M31. Keine Strom-/Spannungsregel geaendert,
keine zusaetzliche 5-V-VINDPM-Regel, keine Defconfig-Aenderung. Beide Header bleiben
byteidentisch; bq2589x_iio.h bleibt 1.763 Bytes ohne abschliessenden Zeilenumbruch.

PRUEFUNGEN
27 M32-Regressionen mit GCC 11.4 und GCC 14 sowie UBSan bestanden.
Der neue native Test fuehrt die echten Probe-/DT-Funktionen aus: 4 erfolgreiche
Chip-/DT-Kombinationen mit identischer Erfolgsablaufspur und 730 Fehlerfaelle;
6.894 C-Assertions pruefen Besitzstaende, Freigaben, NULL-Referenzen, GPIO-0,
deferred probe und Publikationsreihenfolge. Die alten Fehler sind reproduziert.
Die echten Lese-/Schreibcallbacks bestehen weitere 2.330 bzw. 37.574 Assertions,
einschliesslich frueher IIO-Zugriffe ohne Hardwareaktionen. Der unveraenderte
156-Assertion-Probetest laeuft zusaetzlich auf der authentischen M31-Referenz;
er ersetzt nicht den neuen Test der geaenderten M32-Probe-Funktion.
Der ganze neue Treiber kompiliert fuer ARM64 mit Clang 12.0.5 und CFI/ThinLTO.
Die verwendeten Freigabe-APIs sind bereits im aktuellen Kernel exportiert.
Das ist kein vollstaendiger lokaler M32-Kernelbau und kein Hardware-Rennbedingungstest.

CI-KETTE
Die M31-Schicht und ihre Tests werden unveraendert authentifiziert geladen.
Die neue BQ-Schicht verwendet weiterhin den authentischen M28-R2-Baukern mit
allen geerbten Konfigurations-, WT-, ADC-, RPM-, Release-, CRC- und Boot-Gates.
M32 muss zusaetzlich tatsaechliche Quellen, LLVM-Objekt/CFI-Kommando, verlinkte
Interfaces sowie Lese-, Schreib- und neue Startfehlerzweige in Image UND vmlinux
nachweisen. Konfiguration und komplette Exporttabelle bleiben auf dem bestaetigten
Stand. Boot.img/AK3 werden erst nach diesen Pruefungen erstellt und statisch geprueft.
Kernelkennung bleibt 5.4.274-qgki-g82179e362f33.

OFFEN
Vollstaendiger M32-GitHub-Bau und alle Artefakte danach. Shutdown muss IRQ und
Hintergrundarbeiten noch synchronisieren und erfolgreiche Laufzeitressourcen
freigeben. Weitere ignorierte Schreibfehler in init_device und Adapterpfaden
sowie optionale/erforderliche Power-Supply-Abhaengigkeiten sind gesondert offen.
Die vier DT-GPIOs und reale Verbraucherabhaengigkeiten sind am konkreten Geraet
noch nicht validiert. Keine vollstaendige Aufarbeitung aller historischen ueber
7.100 Quellabweichungen und kein universeller GKI-Nachweis. Geraeteboot, Laden,
OTG, Suspend und Wiederherstellung sind ungetestet. Device Pass NEIN. Flash NEIN.
