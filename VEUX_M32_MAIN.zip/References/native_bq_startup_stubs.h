
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <setjmp.h>
#include <assert.h>
#define WRITE_ONCE(x,v) __atomic_store_n(&(x),(v),__ATOMIC_RELAXED)
#define smp_store_release(p,v) __atomic_store_n((p),(v),__ATOMIC_RELEASE)
#define EPROBE_DEFER 517
struct device { void *of_node; struct { int unused; } kobj; };
struct bq2589x;
struct i2c_client { struct device dev; int irq; struct bq2589x *data; };
struct i2c_device_id { int unused; };
struct iio_dev { struct bq2589x *data; };
struct work_struct { int id; };
struct delayed_work { struct work_struct work; };
struct device_node { int unused; };
struct bq2589x_config { bool enable_auto_dpdm,enable_term,enable_ico,use_absolute_vindpm; int otg_vol,otg_current,charge_voltage,charge_current,term_current; };
struct bq2589x {
 bool startup_ready;
 struct bq2589x_config cfg;
 int otg_gpio,usb_switch1,usb_switch2;
 struct iio_dev *indio_dev;
 struct device *dev;
 struct i2c_client *client;
 bool usb_switch_flag, force_exit_flag, hz_flag, is_bq25890h;
 int status, revision, part_no, charge_type, irq_gpio;
 void *wt_ws, *batt_psy, *usb_psy;
 struct work_struct irq_work, adapter_in_work, adapter_out_work;
 struct delayed_work monitor_work, ico_work, force_work;
};
struct attribute_group { int unused; };
static const struct attribute_group bq2589x_attr_group = {0};
#define BQ2589X_STATUS_EXIST 1
#define IRQF_TRIGGER_FALLING 1
#define IRQF_ONESHOT 2
#define dev_err(...) ((void)0)
#define dev_info(...) ((void)0)
#define pr_err(...) ((void)0)
enum {ALLOC=1,PRIV,CLIENTDATA,DETECT,IIO_INIT,WAKEUP,PSY_BATTERY,PSY_USB,
 PARSE_DT,INIT_DEVICE,GPIO_REQUEST,GPIO_TO_IRQ,INIT_WORK_ITEM,SYSFS_CREATE,
 REQUEST_IRQ,ENABLE_WAKE,USB_SWITCH,FORCE_DPDM,CANCEL_WORK,CANCEL_DELAYED,IIO_UNREGISTER,WAKE_UNREGISTER,PSY_PUT,GPIO_FREE,SYSFS_REMOVE,PROP_BOOL,PROP_U32,GET_GPIO};
struct event { int id, arg; };
static struct event trace[128], saved[128];
static int used, fail_event, fail_code, chip, alloc_fail, null_priv, assertions;
static int fail_ordinal,awake_refs,battery_refs,usb_refs,gpio_refs,sysfs_refs,iio_refs,irq_refs,early_ready,nullable_battery,nullable_usb,gpio_zero;
static int battery_token,usb_token;
static struct bq2589x state, *g_bq;
static struct iio_dev iio;
static struct i2c_client client;
static jmp_buf null_trap;
static bool trap_enabled;
static int event(int id, int arg) {
 if (used >= 128) abort();
 trace[used++] = (struct event){id,arg};
 if(state.startup_ready)early_ready++;
 int n=0;for(int i=0;i<used;i++)if(trace[i].id==id)n++;
 return id == fail_event && (!fail_ordinal||n==fail_ordinal) ? fail_code : 0;
}
static struct iio_dev *devm_iio_device_alloc(struct device *dev, size_t bytes) {
 event(ALLOC,(int)bytes); return alloc_fail ? NULL : &iio;
}
static void *iio_priv(struct iio_dev *dev) {
 event(PRIV,0);
 if (!dev) { null_priv++; if (trap_enabled) longjmp(null_trap,1); abort(); }
 return dev->data;
}
static void i2c_set_clientdata(struct i2c_client *c, struct bq2589x *s) {
 event(CLIENTDATA,0); c->data=s;
}
static int bq2589x_detect_device(struct bq2589x *bq) {
 int rc=event(DETECT,0); if (!rc) { bq->part_no=chip; bq->revision=2; } return rc;
}
static int bq_init_iio_psy(struct bq2589x *bq) { int rc=event(IIO_INIT,0);if(!rc)iio_refs++;return rc; }
static void devm_iio_device_unregister(struct device *d,struct iio_dev *i) { assert(iio_refs==1);iio_refs--;event(IIO_UNREGISTER,0); }
static void *wakeup_source_register(struct device *dev,const char *name) { if(event(WAKEUP,0))return NULL;awake_refs++;return &state; }
static void wakeup_source_unregister(void *p) { if(p){assert(awake_refs==1);awake_refs--;}event(WAKE_UNREGISTER,!!p); }
static void *power_supply_get_by_name(const char *name) {
 bool battery=!strcmp(name,"battery");event(battery?PSY_BATTERY:PSY_USB,0);
 if(battery){if(nullable_battery)return NULL;battery_refs++;return &battery_token;}
 if(nullable_usb)return NULL;
 usb_refs++;return &usb_token;
}
static void power_supply_put(void *p) {
 if(p==&battery_token){assert(battery_refs==1);battery_refs--;}
 else {assert(p==&usb_token&&usb_refs==1);usb_refs--;}
 event(PSY_PUT,p==&battery_token?1:2);
}
static bool of_property_read_bool(struct device_node *np,const char *name){event(PROP_BOOL,0);return true;}
static int of_property_read_u32(struct device_node *np,const char *name,int *value){int rc=event(PROP_U32,0);if(rc)return rc;*value=1500;return 0;}
static int of_get_named_gpio(struct device_node *np,const char *name,int index){
 int rc=event(GET_GPIO,0);if(rc)return rc;
 if(!strcmp(name,"otg-gpio"))return gpio_zero?0:31;
 if(!strcmp(name,"intr-gpio"))return 32;
 return !strcmp(name,"usb-switch1")?33:34;
}
static int bq2589x_init_device(struct bq2589x *bq) { return event(INIT_DEVICE,0); }
static int gpio_request(int gpio,const char *name) { int rc=event(GPIO_REQUEST,gpio);if(!rc)gpio_refs++;return rc; }
static void gpio_free(int gpio){assert(gpio_refs==1);gpio_refs--;event(GPIO_FREE,gpio);}
static int gpio_to_irq(int gpio) { int rc=event(GPIO_TO_IRQ,gpio); return rc ? rc : 17; }
static void bq2589x_charger_irq_workfunc(struct work_struct *w) {}
static void bq2589x_adapter_in_workfunc(struct work_struct *w) {}
static void bq2589x_adapter_out_workfunc(struct work_struct *w) {}
static void bq2589x_monitor_workfunc(struct work_struct *w) {}
static void bq2589x_ico_workfunc(struct work_struct *w) {}
static void bq2589x_force_workfunc(struct work_struct *w) {}
static void init_work_item(struct work_struct *w,void (*fn)(struct work_struct *)) { event(INIT_WORK_ITEM,w->id); }
#define INIT_WORK(w,fn) init_work_item(w,fn)
#define INIT_DELAYED_WORK(w,fn) init_work_item(&(w)->work,fn)
static int sysfs_create_group(void *kobj,const struct attribute_group *group) { int rc=event(SYSFS_CREATE,0);if(!rc)sysfs_refs++;return rc; }
static void sysfs_remove_group(void *kobj,const struct attribute_group *group){assert(sysfs_refs==1);sysfs_refs--;event(SYSFS_REMOVE,0);}
static int bq2589x_charger_interrupt(int irq,void *data) { return 0; }
static int request_irq(int irq,int (*fn)(int,void *),int flags,const char *name,void *data) { int rc=event(REQUEST_IRQ,irq);if(!rc)irq_refs++;return rc; }
static int enable_irq_wake(int irq) { return event(ENABLE_WAKE,irq); }
static int bq2589x_usb_switch(struct bq2589x *bq,bool on) { return event(USB_SWITCH,on); }
static void bq2589x_force_dpdm_done(struct bq2589x *bq) { event(FORCE_DPDM,0); }
static void cancel_work_sync(struct work_struct *w) { event(CANCEL_WORK,w->id); }
static void cancel_delayed_work_sync(struct delayed_work *w) { event(CANCEL_DELAYED,w->work.id); }
static void reset(int part, bool dt) {
 memset(&state,0,sizeof(state)); memset(&iio,0,sizeof(iio)); memset(&client,0,sizeof(client));
 memset(trace,0,sizeof(trace)); used=fail_event=alloc_fail=null_priv=0; fail_code=-EIO; chip=part;
 fail_ordinal=awake_refs=battery_refs=usb_refs=gpio_refs=sysfs_refs=iio_refs=irq_refs=early_ready=nullable_battery=nullable_usb=gpio_zero=0;
 trap_enabled=false; g_bq=NULL; iio.data=&state; client.dev.of_node=dt?&state:NULL;
 state.irq_gpio=7; state.irq_work.id=1; state.adapter_in_work.id=2; state.adapter_out_work.id=3;
 state.monitor_work.work.id=4; state.ico_work.work.id=5; state.force_work.work.id=6;
}
static int count(int id) { int n=0; for(int i=0;i<used;i++) if(trace[i].id==id)n++; return n; }
#define CHECK(x) do { assertions++; if(!(x)) { fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x); return 1; } } while(0)
