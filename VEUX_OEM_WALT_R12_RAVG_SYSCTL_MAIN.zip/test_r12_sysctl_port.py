import importlib.util,hashlib,json,pathlib,subprocess,tempfile,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('port',ROOT/'r12_oem_ravg_sysctl_port.py')
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)

HDR='''#include <linux/types.h>
extern int proc_douintvec_minmax(struct ctl_table *table, int write,
\t\t\t\t void __user *buffer, size_t *lenp,
\t\t\t\t loff_t *ppos);
extern int proc_dointvec(struct ctl_table *, int, void __user *,size_t *,loff_t *);
'''
SRC='''#include <linux/sysctl.h>
#ifdef CONFIG_PROC_SYSCTL
static int do_proc_dointvec(struct ctl_table *table, int write,
                             void __user *buffer, size_t *lenp, loff_t *ppos,
                             int (*fn)(bool *, unsigned long *,int *,int,void *),void *data)
{
 return 0;
}
#else /* CONFIG_PROC_SYSCTL */
int proc_dointvec(struct ctl_table *table, int write, void __user *buf,size_t *len, loff_t *pos)
{
 return -ENOSYS;
}
#endif /* CONFIG_PROC_SYSCTL */
'''
class SourceTests(unittest.TestCase):
 def test_01_header_declaration(self):self.assertIn('proc_douintvec_ravg_window(struct',p.header(HDR))
 def test_02_kernel_functions(self):self.assertIn('do_proc_douintvec_rwin(',p.implementation(SRC))
 def test_03_two_definitions(self):self.assertEqual(p.implementation(SRC).count('int proc_douintvec_ravg_window('),2)
 def test_04_valid_2(self):self.assertIn('*lvalp == 2',p.IMPLEMENTATION)
 def test_05_valid_3(self):self.assertIn('*lvalp == 3',p.IMPLEMENTATION)
 def test_06_valid_4(self):self.assertIn('*lvalp == 4',p.IMPLEMENTATION)
 def test_07_valid_5(self):self.assertIn('*lvalp == 5',p.IMPLEMENTATION)
 def test_08_valid_8(self):self.assertIn('*lvalp == 8',p.IMPLEMENTATION)
 def test_09_invalid_einval(self):self.assertIn('return -EINVAL;',p.IMPLEMENTATION)
 def test_10_disabled_enosys(self):self.assertIn('return -ENOSYS;',p.FALLBACK)
 def test_11_converter_dointvec(self):self.assertIn('return do_proc_dointvec(table, write',p.IMPLEMENTATION)
 def test_12_no_unrelated_stub(self):self.assertNotIn('return 0;\n}',p.FALLBACK)
 def test_13_no_walt_disable(self):self.assertNotIn('#undef CONFIG_SCHED_WALT',p.IMPLEMENTATION)
 def test_14_no_module_crc(self):self.assertNotIn('module_layout',p.IMPLEMENTATION)
 def test_15_original_condition_preserved(self):self.assertIn('#else /* CONFIG_PROC_SYSCTL */',p.implementation(SRC))
 def test_16_header_double_guard(self):
  with self.assertRaises(p.GateError):p.header(p.header(HDR))
 def test_17_impl_double_guard(self):
  with self.assertRaises(p.GateError):p.implementation(p.implementation(SRC))
 def test_18_no_converter_guard(self):
  with self.assertRaises(p.GateError):p.implementation(SRC.replace('do_proc_dointvec','notreal'))
 def test_19_missing_else_guard(self):
  with self.assertRaises(p.GateError):p.implementation(SRC.replace('#else /* CONFIG_PROC_SYSCTL */','#else'))
 def test_20_missing_endif_guard(self):
  with self.assertRaises(p.GateError):p.implementation(SRC.replace('#endif /* CONFIG_PROC_SYSCTL */','#endif'))
 def test_21_bad_header_guard(self):
  with self.assertRaises(p.GateError):p.header(HDR.replace('proc_douintvec_minmax','another_handler'))
 def test_22_source_set(self):
  with self.assertRaises(p.GateError):p.transform({p.PATHS[0]:HDR})
 def test_23_passes_whitespace_variants(self):
  self.assertIn('proc_douintvec_ravg_window(',p.header(HDR.replace('\t\t\t\t ','\t\t')))
 def test_24_git_blob_v1(self):
  self.assertEqual(p.blob(b'abc'),'f2ba8f84ab5c1bce84a7b441cb1959cfc7093b7f')
 def test_25_genuine_pins_40hex(self):
  self.assertTrue(all(len(h)==40 for h in p.BASE_BLOBS.values()))
 def test_26_transform_source_scope(self):
  r=p.transform({p.PATHS[0]:HDR,p.PATHS[1]:SRC});self.assertEqual(set(r),set(p.PATHS))
 def test_27_correct_count(self):
  r=p.transform({p.PATHS[0]:HDR,p.PATHS[1]:SRC});self.assertEqual(r[p.PATHS[1]].count('do_proc_douintvec_rwin'),2)
 def test_28_git_patch_apply_and_reverse(self):
  r=p.transform({p.PATHS[0]:HDR,p.PATHS[1]:SRC})
  import difflib
  patch=''.join(x for n in p.PATHS for x in difflib.unified_diff({p.PATHS[0]:HDR,p.PATHS[1]:SRC}[n].splitlines(keepends=True),r[n].splitlines(keepends=True),fromfile='a/'+n,tofile='b/'+n))
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d)
   for n,t in [(p.PATHS[0],HDR),(p.PATHS[1],SRC)]:
    z=d/n;z.parent.mkdir(parents=True,exist_ok=True);z.write_text(t)
   q=d/'diff.patch';q.write_text(patch)
   for args in [('apply','--check'),('apply',),('apply','--reverse','--check'),('apply','--reverse')]:
    result=subprocess.run(['git',*args,str(q)],cwd=d,capture_output=True,text=True)
    self.assertEqual(result.returncode,0,result.stderr)
   self.assertEqual((d/p.PATHS[0]).read_text(),HDR)
   self.assertEqual((d/p.PATHS[1]).read_text(),SRC)
 def test_29_immutable_r11_pins(self):self.assertEqual(len(p.R11_POST),4)
 def test_30_walt_sha_pin(self):self.assertEqual(len(p.WALT_C_SHA),64)
 def test_31_missing_stage(self):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d)
   with self.assertRaises(p.GateError):p.stage(d,d/'not.json',d/'missing',d,d/'out')
 def test_32_refuse_wrong_input_blob(self):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d);g=d/'gate';r=d/'result';rr=d/'old';rr.mkdir();snapshot=d/'snap';snapshot.mkdir()
   for n,v in p.R11_POST.items():
    t=snapshot/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_text('fake')
   # Exact original pin must reject these fake sources before any edit.
   self.assertNotEqual(p.blob(SRC.encode()),p.BASE_BLOBS['kernel/sysctl.c'])
 def test_33_no_eager_write(self):
  with tempfile.TemporaryDirectory() as d:
   d=pathlib.Path(d)
   self.assertFalse((d/'R12_SOURCE_GATE.json').exists())
 def test_34_compile_driver_imported(self):
  s=(ROOT/'r12_real_object_compile.py').read_text();self.assertIn('kernel/sysctl.o',s)
 def test_35_no_flash_components(self):
  t=(ROOT/'r12_oem_ravg_sysctl_port.py').read_text();self.assertNotIn('AnyKernel3',t)
 def _clang(self, body):
  src=("#include <stdbool.h>\n#include <stddef.h>\n"
       "#define __user\n#define EINVAL 22\n#define ENOSYS 38\n"
       "typedef long long loff_t; struct ctl_table { int dummy; };\n"
       "static int do_proc_dointvec(struct ctl_table *t, int w,void __user *b, size_t *l,loff_t *p,"
       "int (*conv)(bool *,unsigned long *,int *,int,void *),void *d) {return 0;}\n"+body)
  res=subprocess.run(['clang','-x','c','-std=gnu11','-Werror','-fsyntax-only','-'],input=src,text=True,capture_output=True)
  self.assertEqual(res.returncode,0,res.stderr)
 def test_36_real_clang_oem_enabled(self):self._clang(p.IMPLEMENTATION)
 def test_37_real_clang_oem_disabled(self):self._clang(p.FALLBACK)

if __name__=='__main__':unittest.main()
