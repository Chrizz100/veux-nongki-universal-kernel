#!/usr/bin/env python3
"""VEUX R12: exact original Xiaomi WALT ravg-window sysctl helper.

NO flash, NO image, source-only patch on authenticated R11 disposable kernel copy.
Xiaomi 5.4.134 donor: MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e
Original P3 source ancestor: dereference23/kernel_xiaomi_sm6375@b2b7a3bbc36d120ee523ebc8d68e0f13a97df632.
"""
import argparse, difflib, hashlib, json, re, subprocess, sys
from pathlib import Path

class GateError(Exception): pass

def require(cond, why):
    if not cond: raise GateError(why)

def sha(x): return hashlib.sha256(x).hexdigest()

def blob(x): return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()

PATHS=('include/linux/sysctl.h','kernel/sysctl.c')
BASE_BLOBS={
    'include/linux/sysctl.h':'aa615a0863f5cab4467d88ec0558a0c914db4163',
    'kernel/sysctl.c':'648dfa089f589e4755980ad82b8dd1d136f93d49'
}
WALT_C_SHA='03ebaf13151525db262f6d20809d69bbbcd5c4fcf378c061b04d661495c72646'
R11_POST={'include/linux/sched.h':'b9c7b4a39d4d5ed5a28cbe0513540f62c903f2db840dfdd2c792b4593f1c23da',
          'kernel/sched/core.c':'fe11a5c1f8db62d1d50449d35b0e1a1b4af3e6b23c24dfeeef226870061aed0a',
          'kernel/sched/fair.c':'f594f7286e068a7009a06e2cb8ae7ac6b10b95a8901580e79a67481a477a8ad3',
          'kernel/sched/sched.h':'2a61b4d52c2630a0851ee379650634dfa96b004db592820ba1e9bc6ad4d0bbfd'}

PROTO=(
    'extern int proc_douintvec_ravg_window(struct ctl_table *table, int write,\n'
    '\t\t\t\t     void __user *buffer, size_t *lenp,\n'
    '\t\t\t\t     loff_t *ppos);\n'
)
# MiCode kernel/sysctl.c 3714--3736 -- original write semantics (only 2,3,4,5,8).
IMPLEMENTATION='''static int do_proc_douintvec_rwin(bool *negp, unsigned long *lvalp,
\t\t\t\t\tint *valp, int write, void *data)
{
\tif (write) {
\t\tif (*lvalp == 2 || *lvalp == 3 || *lvalp == 4 || *lvalp == 5 ||
\t\t\t*lvalp == 8)
\t\t\t*valp = *lvalp;
\t\telse
\t\t\treturn -EINVAL;
\t} else {
\t\t*negp = false;
\t\t*lvalp = *valp;
\t}

\treturn 0;
}

int proc_douintvec_ravg_window(struct ctl_table *table, int write,
\t\t\t\tvoid __user *buffer, size_t *lenp, loff_t *ppos)
{
\treturn do_proc_dointvec(table, write, buffer, lenp, ppos,
\t\t\t\tdo_proc_douintvec_rwin, NULL);
}

'''
FALLBACK='''int proc_douintvec_ravg_window(struct ctl_table *table, int write,
\t\t\t    void __user *buffer, size_t *lenp, loff_t *ppos)
{
\treturn -ENOSYS;
}

'''

def replace_once(src, old, new, reason):
    n=src.count(old)
    require(n==1,reason+':COUNT_'+str(n))
    return src.replace(old,new,1)

def header(src):
    require('proc_douintvec_ravg_window' not in src,'RAVG_HEADER_ALREADY_DEFINED')
    # Whitespace-tolerant parsing only AFTER exact original Git blob verification.
    pattern=(r'(?m)^extern int proc_douintvec_minmax\(struct ctl_table \*table, int write,\n'
             r'\s+void __user \*buffer, size_t \*lenp,\n'
             r'\s+loff_t \*ppos\);\n')
    matches=list(re.finditer(pattern,src))
    require(len(matches)==1,'RAVG_PROTO_ANCHOR_COUNT_'+str(len(matches)))
    m=matches[0]
    return src[:m.end()]+PROTO+src[m.end():]

def implementation(src):
    require('proc_douintvec_ravg_window' not in src,'RAVG_BODY_ALREADY_DEFINED')
    require('do_proc_dointvec(' in src,'MISSING_REAL_INTEGER_SYSCTL_CONVERTER')
    require('static int do_proc_dointvec(' in src,'REAL_SYSCTL_FUNCTION_NOT_FOUND')
    src=replace_once(src,'#else /* CONFIG_PROC_SYSCTL */\n',IMPLEMENTATION+'#else /* CONFIG_PROC_SYSCTL */\n','RAVG_PROC_SYSCTL_BRANCH')
    return replace_once(src,'#endif /* CONFIG_PROC_SYSCTL */\n',FALLBACK+'#endif /* CONFIG_PROC_SYSCTL */\n','RAVG_DISABLED_SYSCTL_STUB')

def transform(src):
    require(set(src)==set(PATHS),'SOURCE_PATHS_DRIFT')
    return {PATHS[0]:header(src[PATHS[0]]),PATHS[1]:implementation(src[PATHS[1]])}

def verify_r11(gate,result,snapshot,report):
    require(gate.is_file() and not gate.is_symlink(),'R11_GATE_MISSING')
    require(result.is_file() and not result.is_symlink(),'R11_RESULT_MISSING')
    g=json.loads(gate.read_text());r=json.loads(result.read_text())
    require(g['status']=='R11_OEM_WALT_REAL_API_FOLLOWUP_STAGED_NOT_COMPILED','R11_GATE_WRONG_STATUS')
    require(g['after_sha256']==R11_POST,'R11_POSTIMAGE_SHA_CHAIN_CHANGED')
    require(r['status']=='R11_COMPILER_ERRORS_RECORDED' and r['object_make_attempted'] is True and r['object_success_count']==2,'R11_RESULT_UNEXPECTED')
    objs=r['objects'];expect={'kernel/sched/core.o':True,'kernel/sched/fair.o':True,'kernel/sched/walt/walt.o':False}
    require(set(objs)==set(expect) and all(objs[n]['compiled'] is v for n,v in expect.items()),'R11_OBJECT_SET_MISMATCH')
    require(not any(g.get(k) or r.get(k) for k in ('flash_allowed','vendor_abi_proven','image_built','kernel_image_built','brene_changed','bakasusu_nomount_changed')),'INCONSISTENT_FLASH_OR_ABI')
    for name,h in R11_POST.items():
        p=snapshot/name
        require(p.is_file() and not p.is_symlink() and sha(p.read_bytes())==h,'R11_SOURCE_DRIFT:'+name)
    p=snapshot/'kernel/sched/walt/walt.c'
    require(p.is_file() and not p.is_symlink() and sha(p.read_bytes())==WALT_C_SHA,'PINNED_XIAOMI_WALT_CODE_CHANGED')
    c=p.read_text()
    require(c.count('proc_douintvec_ravg_window(')==1,'EXPECTED_EXACT_ONE_OEM_CALLSITE')
    # Read the ORIGINAL failing compiler log; not just an advertised status.
    walt=report/'compiler_logs/03_kernel_sched_walt_walt.o.log'
    require(walt.is_file() and not walt.is_symlink(),'R11_ACTUAL_CLANG_LOG_MISSING')
    require(sha(walt.read_bytes())==objs['kernel/sched/walt/walt.o']['log_sha256'],'R11_REAL_LOG_SHA_MISMATCH')
    data=walt.read_text(errors='replace')
    require("implicit declaration of function 'proc_douintvec_ravg_window'" in data,'R11_WRONG_COMPILER_FAILURE')
    return g,r

def stage(snapshot,gate,result,r11_report,out):
    require(snapshot.is_dir() and not snapshot.is_symlink(),'SOURCE_SNAPSHOT_MISSING')
    require(not out.exists() and not out.is_symlink(),'OUTPUT_EXISTS')
    verify_r11(gate,result,snapshot,r11_report)
    src={}
    for name in PATHS:
        p=snapshot/name
        require(p.is_file() and not p.is_symlink(),'SOURCE_FILE_MISSING_OR_SYMLINK:'+name)
        b=p.read_bytes()
        require(blob(b)==BASE_BLOBS[name],'P3_P10_SYSCTL_PREIMAGE_BLOB_MISMATCH:'+name)
        src[name]=b.decode('utf-8')
    target=transform(src)
    patch=''.join(x for name in PATHS for x in difflib.unified_diff(src[name].splitlines(keepends=True),target[name].splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name))
    require(patch.count('--- a/')==2 and patch.count('+++ b/')==2,'PATCH_SCOPE_BAD')
    report={'status':'R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED','source_original_unchanged':True,
       'modified_files':list(PATHS),'preimage_git_blobs':BASE_BLOBS,
       'before_sha256':{name:sha(src[name].encode()) for name in PATHS},
       'after_sha256':{name:sha(target[name].encode()) for name in PATHS},
       'patch_sha256':sha(patch.encode()),
       'donor_ref':'MiCode/Xiaomi_Kernel_OpenSource@61397e524093d1ccb94769b5460825e2eaf8871e',
       'real_r11_compiler_failure_verified':True,
       'allowed_windows':[2,3,4,5,8], 'proc_sysctl_disabled_returns_enosys':True,
       'kernel_image_built':False,'all_objects_compiled':False,'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,'bakasusu_nomount_changed':False}
    out.mkdir(parents=True)
    (out/'R12_SYSCTL.patch').write_text(patch)
    (out/'R12_SOURCE_GATE.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    for name in PATHS:
        (snapshot/name).write_text(target[name])
    for name in PATHS:
        require(sha((snapshot/name).read_bytes())==report['after_sha256'][name],'PATCH_POSTIMAGE_BAD')
    print('R12_XIAOMI_SYSCTL_SOURCE_GATE=PASS; PATHS=2; COMPILER=NOT_YET_RUN; FLASH=NO')
    return report

def main():
    a=argparse.ArgumentParser()
    for key in ['snapshot','r11-gate','r11-result','r11-report','output']:
        a.add_argument('--'+key,required=True,type=Path)
    q=a.parse_args()
    try:stage(q.snapshot,q.r11_gate,q.r11_result,q.r11_report,q.output)
    except (GateError,OSError,ValueError,KeyError) as e:
        print('R12_SOURCE_GATE_ERROR:'+str(e),file=sys.stderr);return 2
    return 0
if __name__=='__main__':raise SystemExit(main())
