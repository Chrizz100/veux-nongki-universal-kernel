#!/usr/bin/env bash
# VEUX R56 – real upstream source preflight. Deliberately no flash/build actions.
# The R13 compile chain is a protected reference, not an updated kernel.
set -Eeuo pipefail
umask 077
fail() { printf 'R56_FAIL_CLOSED=%s\n' "$1" >&2; exit 3; }
: "${GITHUB_WORKSPACE:?}" "${RUNNER_TEMP:?}" "${R56_PAYLOAD:?}"
[[ "${GITHUB_ACTIONS:-}" == true && "${RUNNER_OS:-}" == Linux ]] || fail NOT_GITHUB
[[ "${GITHUB_REPOSITORY:-}" == 'Chrizz100/veux-nongki-universal-kernel' ]] || fail WRONG_REPO
[[ "${GITHUB_REF:-}" == refs/heads/main ]] || fail WRONG_BRANCH
[[ "$(git -C "$GITHUB_WORKSPACE" rev-parse HEAD)" == "${GITHUB_SHA:-}" ]] || fail GITHUB_SHA_DRIFT
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || fail DIRTY_ORIGINAL_REPO
R13="$GITHUB_WORKSPACE/VEUX_R13_CASS_MAIN.zip"
R41="$GITHUB_WORKSPACE/VEUX_R41_NOMOUNT_SOURCE_MAIN.zip"
R54="$R56_PAYLOAD/references/VEUX_R54_CASS_SOURCE_MAIN.zip"
R55="$R56_PAYLOAD/references/VEUX_R55_AVD_QUELLSTUFE_NOFLASH.zip"
R13_YAML="$GITHUB_WORKSPACE/.github/workflows/VEUX_R13_CASS_BUILD.yml"
DIR="$RUNNER_TEMP/veux-r56-real-source-proof"
[[ ! -e "$DIR" && ! -L "$DIR" ]] || fail REUSED_REPORT_DIR
mkdir -m 0700 "$DIR"
printf 'R56_REPORT_DIR=%s\n' "$DIR" >> "$GITHUB_ENV"
python3 -B "$R56_PAYLOAD/tools/r56_source_gate.py" \
 --r13 "$R13" --r41 "$R41" --r54 "$R54" --r55 "$R55" \
 --r13-workflow "$R13_YAML" --out "$DIR/R56_ORIGINALS_AUTHENTICATED.json" || fail ORIGINALS_NOT_AUTHENTIC
R56_TEST_R13="$R13" R56_TEST_R41="$R41" R56_TEST_R13_YAML="$R13_YAML" \
  python3 -B -m unittest discover -s "$R56_PAYLOAD/tests" -p 'test_*.py' -v \
  > "$DIR/R56_20_NEW_TESTS.log" 2>&1 || fail R56_REGRESSION_FAILED
# SHA-attested nested R54/R55 payloads; never execute before authentication.
python3 -I - "$R54" "$R55" "$DIR" <<'PY'
from pathlib import Path,PurePosixPath
from zipfile import ZipFile
import hashlib,json,stat,sys
root=Path(sys.argv[3]);
for archive,target,manifest_name in [(Path(sys.argv[1]),root/'r54','MANIFEST_SHA256.json'),
                                      (Path(sys.argv[2]),root/'r55','SHA256SUMS.txt')]:
 with ZipFile(archive) as z:
  infos=z.infolist();names=[x.filename for x in infos]
  assert names and len(names)==len(set(names)) and len(names)<80 and z.testzip() is None
  assert sum(x.file_size for x in infos)<2_000_000
  if manifest_name.endswith('json'):
   m=json.loads(z.read(manifest_name));assert m['schema']=='VEUX_R54_PAYLOAD_V1'
   expected=m['files']
  else:
   expected=dict((a[1],a[0]) for s in z.read(manifest_name).decode().splitlines() if len(a:=s.strip().split('  ',1))==2)
  assert set(expected)|{manifest_name}==set(names)
  for x in infos:
   p=PurePosixPath(x.filename)
   assert p.parts and not p.is_absolute() and '..' not in p.parts and '\\' not in x.filename and not x.is_dir()
   assert stat.S_IFMT(x.external_attr>>16) in (0,stat.S_IFREG)
   raw=z.read(x)
   if x.filename!=manifest_name: assert hashlib.sha256(raw).hexdigest()==expected[x.filename]
  target.mkdir(mode=0o700)
  for x in infos:
   path=target/x.filename;path.parent.mkdir(parents=True,exist_ok=True)
   path.write_bytes(z.read(x))
print('R56_NESTED_MAIN_INTEGRITY=PASS')
PY
# Re-run R55 real R13 native AVD tests. These test source manipulation, NOT compilation.
python3 -B -m unittest discover -s "$DIR/r55/tests" -p 'test_r55_avd.py' -v \
 > "$DIR/R55_20_TESTS.log" 2>&1 || fail R55_REGRESSION_FAILED
# The already-authenticated R54 source script runs all historic source gates
# and performs the genuine five-commit BakaSU + two VEUX-port Git replay.
export R54_PAYLOAD_PATH="$DIR/r54"
if ! bash "$DIR/r54/tools/r54/R54_GITHUB_REAL_SOURCE_PREBUILD_NOFLASH.sh" \
  > "$DIR/R54_FULL_SOURCE_STAGE.log" 2>&1; then
  echo 'R56_R2: exact underlying R54 error (last 65 log lines):' >&2
  tail -n 65 "$DIR/R54_FULL_SOURCE_STAGE.log" >&2
  fail R54_REAL_UPSTREAM_REPLAY_BLOCKED
fi
# R54 creates a unique scratch directory. Never guess a missing one.
shopt -s nullglob
matches=("$RUNNER_TEMP"/veux-r54-no-flash-*)
[[ "${#matches[@]}" == 1 ]] || fail R54_REPORT_DIR_MISSING_OR_AMBIGUOUS
R54_STAGE="${matches[0]}"
[[ -s "$R54_STAGE/R54_REAL_BAKASU_REPLAY.json" ]] || fail REAL_BAKASU_REPLAY_RECEIPT_MISSING
[[ -s "$R54_STAGE/R54_PARTIAL_SUSFS_PORT/R52_SOURCE_RECEIPT.json" ]] || fail PARTIAL_SUSFS_STATUS_MISSING
# Next: generate the original native5.4 (R13) + latest genuine BakaSU AVD
# bridge against the real replayed source. This makes a patch, not a new kernel.
python3 -B "$DIR/r55/r55_native54_avd_overlay.py" \
 --selinux-hide "$R54_STAGE/NEW_BAKASU_GIT_SOURCE_NOT_BUILT/kernel/feature/selinux_hide.c" \
 --sepolicy "$R54_STAGE/NEW_BAKASU_GIT_SOURCE_NOT_BUILT/kernel/selinux/sepolicy.c" \
 --output "$DIR/R56_BAKASU_AVD_PATCH" > "$DIR/R56_BAKASU_AVD_STAGE.log" 2>&1 || fail AVD_REAL_BAKASU_PATCH_REJECTED
# Probe the real Xiaomi stock services.c by immutable commit, and require its
# exact Git blob; a different patched working tree later REQUIRES a new review.
# Input is in a separate child directory: source-tree write guard MUST stay on.
mkdir -m 0700 "$DIR/XIAOMI_STOCK_SOURCE"
curl --fail --location --silent --show-error --retry 2 --max-time 90 \
 'https://raw.githubusercontent.com/MiCode/Xiaomi_Kernel_OpenSource/61397e524093d1ccb94769b5460825e2eaf8871e/security/selinux/ss/services.c' \
 --output "$DIR/XIAOMI_STOCK_SOURCE/xiaomi_stock_services.c" || fail XIAOMI_STOCK_SERVICES_FETCH
python3 -B "$R56_PAYLOAD/tools/r56_services_avd.py" \
 --services "$DIR/XIAOMI_STOCK_SOURCE/xiaomi_stock_services.c" --out "$DIR/R56_STOCK_SERVICES_AVD_PATCH" \
 > "$DIR/R56_STOCK_SERVICES_AVD_STAGE.log" 2>&1 || fail STOCK_AVD_5_4_SOURCE_REVIEW_REQUIRED
# Source-only evidence (with the new true Git replay) is a useful result.
python3 -I - "$DIR" "$R54_STAGE" <<'PY'
from pathlib import Path
import json,sys
p,q=map(Path,sys.argv[1:3]);b=json.loads((q/'R54_REAL_BAKASU_REPLAY.json').read_text())
s=json.loads((q/'R54_PARTIAL_SUSFS_PORT/R52_SOURCE_RECEIPT.json').read_text())
a=json.loads((p/'R56_BAKASU_AVD_PATCH/R55_AVD_SOURCE_RECEIPT.json').read_text())
h=json.loads((p/'R56_STOCK_SERVICES_AVD_PATCH/R56_SERVICES_AVD_GATE.json').read_text())
assert b['genuine_git_commit_count']==4559 and b['calculated_source_version']==35259
assert s['gates']['build_allowed'] is False
assert a['gates']['whole_kernel_compiled'] is False and h['compiled'] is False
result={'schema':'VEUX_R56_REAL_SOURCE_GATE_V1',
 'status':'REAL_BAKASU_35259_REPLAYED__NATIVE54_AVD_PATCHES_STAGED__FULL_SUSFS_HOOKS_BLOCKED',
 'genuine_BakaSU_replay_commit':b['result_commit'],
 'genuine_BakaSU_replay_version':b['calculated_source_version'],
 'native54_partial_SUSFS':s['status'],'AVD_BakaSU':a['status'] if 'status' in a else a.get('bakasu',{}),
 'host_services_reference_sha256':h['pre_sha256'],
 'missing_components':['remaining native54 SELinux hooks.c / AVC and services.c integration into actual CASS kernel tree',
 'actual new KernelSU + SUSFS source tree and compiler link',
 'fresh Image/vmlinux/DTB/Module.symvers and all 132 RMNET and nine OEM module ABI checks',
 'safe AK3 and device-specific boot.img / rollback proof'],
 'source_stage_accepted':True,'all_updates_integrated':False,'kernel_compiled':False,
 'OEM_ABI_CLEARED':False,'boot_img_validated':False,'flash_allowed':False}
(p/'R56_REAL_SOURCE_GATE.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(result['status'])
PY
[[ -z "$(git -C "$GITHUB_WORKSPACE" status --porcelain --untracked-files=all)" ]] || fail REPOSITORY_MODIFIED
printf 'R56_SOURCE_GATE=PARTIAL\nR56_KERNEL_BUILD_ALLOWED=NO\nR56_BOOT_FLASH_ALLOWED=NO\n'
# Deliberately do not call compiler or packager until full CASS 5.4 host hooks
# are present and compiled, and R13 tests are re-executed on that exact tree.
