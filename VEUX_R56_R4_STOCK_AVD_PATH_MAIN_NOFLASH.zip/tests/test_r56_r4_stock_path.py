#!/usr/bin/env python3
"""Regression against GitHub 41565600433's CANNOT_WRITE_TO_SOURCE_TREE.

No protected kernel source or SUSFS call path is changed by this test.
"""
import contextlib
import hashlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import importlib.util
ROOT=Path(__file__).resolve().parents[1]
def read_services():
 spec=importlib.util.spec_from_file_location('r56_r4_services',ROOT/'tools/r56_services_avd.py')
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
 return m
SERV=read_services()
FIXTURE=('#include <linux/errno.h>\n#include "audit.h"\n\nvoid security_compute_av_user(struct selinux_state *state,\n                              u32 ssid, u32 tsid, u16 tclass,\n                              struct av_decision *avd)\n{\n    struct context *scontext = NULL, *tcontext = NULL;\n    read_lock(&state->ss->policy_rwlock);\n\tcontext_struct_compute_av(policydb, scontext, tcontext, tclass, avd,\n\t\t\t\t  NULL);\n out:\n    read_unlock(&state->ss->policy_rwlock);\n}\n/* End function */\n').encode()

class R56StockPathRegression(unittest.TestCase):
 def test_01_real_runner_uses_separate_stock_source_directory(self):
  s=(ROOT/'tools/R56_GITHUB_SOURCE_AND_BOOT_GATES_NOFLASH.sh').read_text()
  self.assertIn('mkdir -m 0700 "$DIR/XIAOMI_STOCK_SOURCE"',s)
  self.assertIn('--output "$DIR/XIAOMI_STOCK_SOURCE/xiaomi_stock_services.c"',s)
  self.assertIn('--services "$DIR/XIAOMI_STOCK_SOURCE/xiaomi_stock_services.c" --out "$DIR/R56_STOCK_SERVICES_AVD_PATCH"',s)
  self.assertNotIn('--output "$DIR/xiaomi_stock_services.c"',s)
  self.assertNotIn('--services "$DIR/xiaomi_stock_services.c"',s)
 def test_02_cli_succeeds_with_sibling_not_inside_source(self):
  with tempfile.TemporaryDirectory() as d, patch.object(SERV,'XIAOMI_BLOB',SERV.blob(FIXTURE)):
   root=Path(d);src=root/'XIAOMI_STOCK_SOURCE';src.mkdir(mode=0o700)
   (src/'xiaomi_stock_services.c').write_bytes(FIXTURE)
   out=root/'R56_STOCK_SERVICES_AVD_PATCH'
   with contextlib.redirect_stdout(io.StringIO()) as v:
    rc=SERV.main(['--services',str(src/'xiaomi_stock_services.c'),'--out',str(out)])
   self.assertEqual(rc,0);self.assertIn('STATIC_SOURCE_PASS',v.getvalue())
   self.assertTrue((out/'R56_SERVICES_5_4_AVD_SOURCE_ONLY.patch').is_file())
   self.assertTrue((out/'R56_SERVICES_AVD_GATE.json').is_file())
   import json
   gate=json.loads((out/'R56_SERVICES_AVD_GATE.json').read_text())
   self.assertFalse(gate['compiled']);self.assertFalse(gate['flash_allowed'])
   self.assertEqual(gate['reference_git_blob'],SERV.blob(FIXTURE))
 def test_03_previous_layout_is_rejected_without_writing(self):
  with tempfile.TemporaryDirectory() as d, patch.object(SERV,'XIAOMI_BLOB',SERV.blob(FIXTURE)):
   src=Path(d)/'xiaomi_stock_services.c';src.write_bytes(FIXTURE)
   out=Path(d)/'R56_STOCK_SERVICES_AVD_PATCH'
   with contextlib.redirect_stderr(io.StringIO()) as e:
    rc=SERV.main(['--services',str(src),'--out',str(out)])
   self.assertEqual(rc,3);self.assertIn('CANNOT_WRITE_TO_SOURCE_TREE',e.getvalue());self.assertFalse(out.exists())
 def test_04_corrupt_stock_blob_remains_blocked(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'source').mkdir();src=root/'source'/'s.c';src.write_bytes(FIXTURE)
   with contextlib.redirect_stderr(io.StringIO()) as e:
    rc=SERV.main(['--services',str(src),'--out',str(root/'output')])
   self.assertEqual(rc,3);self.assertIn('STOCK_SERVICES_BLOB_DRIFT_REVIEW_REQUIRED',e.getvalue())
 def test_05_symlink_input_is_rejected(self):
  with tempfile.TemporaryDirectory() as d:
   root=Path(d);(root/'source').mkdir();src=root/'source'/'s.c';src.symlink_to(root/'real.c')
   (root/'real.c').write_bytes(FIXTURE)
   with contextlib.redirect_stderr(io.StringIO()):
    rc=SERV.main(['--services',str(src),'--out',str(root/'output')])
   self.assertEqual(rc,3)
 def test_06_existing_output_is_rejected(self):
  with tempfile.TemporaryDirectory() as d, patch.object(SERV,'XIAOMI_BLOB',SERV.blob(FIXTURE)):
   root=Path(d);(root/'source').mkdir();src=root/'source'/'s.c';src.write_bytes(FIXTURE)
   out=root/'output';out.mkdir();(out/'sentinel').write_text('unchanged')
   with contextlib.redirect_stderr(io.StringIO()):
    rc=SERV.main(['--services',str(src),'--out',str(out)])
   self.assertEqual(rc,3);self.assertEqual((out/'sentinel').read_text(),'unchanged')
 def test_07_no_flash_reenabled(self):
  s=(ROOT/'tools/R56_GITHUB_SOURCE_AND_BOOT_GATES_NOFLASH.sh').read_text()
  self.assertIn('R56_KERNEL_BUILD_ALLOWED=NO',s)
  self.assertIn('R56_BOOT_FLASH_ALLOWED=NO',s)
  self.assertIn('fail STOCK_AVD_5_4_SOURCE_REVIEW_REQUIRED',s)
if __name__=='__main__':unittest.main()
