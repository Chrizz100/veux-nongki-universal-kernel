# VEUX R20-R8 original Qualcomm debug output / full kernel experiment — NOFLASH

**Evidence:** [GitHub Action R20-R7](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42187535839) at SHA 0a5d9d7502ca59a721a29c60c9c3af41e989d1b1 compiled 9/9 genuine target objects plus 12/12 R17 regression objects. Full Image/dtbs failed at `kernel/sched/debug.c:960` because the SM6375 donor contains `PM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED);` and the macro `#define PM(F,M) __PS(...)` depends on nonexistent `__PS` and `UTIL_AVG_UNCHANGED` in this translation unit.

Pinned Qualcomm SM8350/Android11 `kernel/sched/debug.c` uses **P(se.avg.util_est.enqueued);** at exactly the same function call; its entire debug printer uses an already present `P(F)` macro. We adopt only this original Qualcomm output expression and remove the orphan `PM` definition (not present upstream Qualcomm) in the disposable SM6375 debug.c. No made-up definitions, warning suppressions, `-Wno-error`, no fake ABI CRC, and no operation on production kernel.

NEW gate: `kernel/sched/debug.o` compiles in addition to the previous 9/9 target objects, then all 12 R17 regressions, then the real full `Image dtbs` build. Source trees remain original/clean and pinned to their Git blobs. GitHub will reveal the next true build blocker if present.

**Status: OFFLINE preflight only, no complete kernel, no OEM ABI green, NOFLASH.**
