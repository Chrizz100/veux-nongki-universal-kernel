import unittest
from r20_compat import (PAIR_SOURCE, DONOR_SOURCE, TARGETS, R17_REGRESSION,
                        blob_sha, modify_vendor_hook, extract_pair_trace_event,
                        reconcile_vmscan, reconcile_interrupt_headers, reconcile_softirq, reconcile_full_trace, reconcile_scheduler_topology, reconcile_sched_class_selector, reconcile_sched_dl_flags, reconcile_qualcomm_topology, reconcile_sched_debug)

CORE = '''void set_user_nice(struct task_struct *p, long nice)
{
    bool queued, running;
    int old_prio, delta;
    struct rq_flags rf;
    struct rq *rq;

    if (task_nice(p) == nice || nice < MIN_NICE || nice > MAX_NICE)
        return;
    rq = task_rq_lock(p, &rf);
    update_rq_clock(rq);
    trace_android_rvh_set_user_nice(p, &nice);
    something_else();
}
'''
PAIR_TRACE = '''/*
 * Tracepoint for task enqueue/dequeue:
 */
TRACE_EVENT(sched_enq_deq_task,
TP_PROTO(struct task_struct *p, bool enqueue,
  unsigned int cpus_allowed),
TP_ARGS(p, enqueue, cpus_allowed),
TP_fast_assign(__entry->demand = task_load(p);
 __entry->pred_demand = task_pl(p);),
);

/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_TRACE = '''/*
 * Tracepoint for waking up a task:
 */
DECLARE_EVENT_CLASS(sched_wakeup_template);
'''
DONOR_VM = '''static LIST_HEAD(shrinker_list);
static DEFINE_SPINLOCK(shrinker_lock);
static DEFINE_RWLOCK(shrinker_rwlock);
static void foo(void) {
down_write(&shrinker_rwsem);
up_write(&shrinker_rwsem);
if (!down_read_trylock(&shrinker_rwsem)) return;
up_read(&shrinker_rwsem);
}
'''

class R20SourceTests(unittest.TestCase):
    def test_01_pinned_source_count(self):
        self.assertEqual(len(PAIR_SOURCE),18)
        self.assertEqual(len(DONOR_SOURCE),17)
    def test_02_blob_sha(self):
        self.assertEqual(blob_sha(b"test\n"),"9daeafb9864cf43055ae93beb0afd6c7d144bfa4")
    def test_03_four_real_object_targets(self):
        self.assertEqual(set(TARGETS), {"CORE","RT","FAIR","VMSCAN","SOFTIRQ","IDLE","DEADLINE","STOP_TASK","TOPOLOGY","DEBUG"})
    def test_04_twelve_r17_distinct(self):
        self.assertEqual(len(R17_REGRESSION),12)
        self.assertEqual(len(set(R17_REGRESSION)),12)
    def test_05_vendor_hook_3args(self):
        x=modify_vendor_hook(CORE)
        self.assertIn("trace_android_rvh_set_user_nice(p, &nice, &allowed);",x)
        self.assertNotIn("trace_android_rvh_set_user_nice(p, &nice);",x)
    def test_06_vendor_hook_original_default_false(self):
        self.assertIn("allowed = false;",modify_vendor_hook(CORE))
    def test_07_vendor_hook_used_before_rejection(self):
        x=modify_vendor_hook(CORE)
        self.assertLess(x.index("trace_android_rvh_set_user_nice"),x.index("if ((task_nice"))
    def test_08_vendor_hook_preserves_override(self):
        self.assertIn("&& !allowed",modify_vendor_hook(CORE))
    def test_09_vendor_hook_rejects_bad_source(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("bool queued, running;", "bool queued;"))
    def test_10_vendor_hook_rejects_double_hook(self):
        with self.assertRaises(ValueError): modify_vendor_hook(CORE.replace("something_else();", "trace_android_rvh_set_user_nice(p, &nice);"))
    def test_11_trace_integration_once(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertEqual(x.count("TRACE_EVENT(sched_enq_deq_task,"),1)
    def test_12_trace_retains_donor_wakeup(self):
        x=extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE)
        self.assertIn("DECLARE_EVENT_CLASS(sched_wakeup_template);",x)
    def test_13_trace_rejects_duplicate_event(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE,DONOR_TRACE+"\nTRACE_EVENT(sched_enq_deq_task,\n")
    def test_14_trace_requires_real_task_api(self):
        with self.assertRaises(ValueError): extract_pair_trace_event(PAIR_TRACE.replace("task_load(p)","zero(p)"),DONOR_TRACE)
    def test_15_donor_shrinker_lock(self):
        self.assertIn("static DECLARE_RWSEM(shrinker_rwsem);", reconcile_vmscan(DONOR_VM))
    def test_16_donor_shrinker_no_reset(self):
        x=reconcile_vmscan(DONOR_VM)
        self.assertIn("static DEFINE_SPINLOCK(shrinker_lock);",x)
        self.assertIn("static DEFINE_RWLOCK(shrinker_rwlock);",x)
    def test_17_donor_shrinker_reject_duplicate(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM+"\nstatic DECLARE_RWSEM(shrinker_rwsem);\n")
    def test_18_donor_shrinker_reject_removed_usage(self):
        with self.assertRaises(ValueError): reconcile_vmscan(DONOR_VM.replace("up_read(&shrinker_rwsem)","up_read(&some_lock)"))
    def test_19_no_warning_bypass_flags_in_source(self):
        import inspect,r20_compat
        src=inspect.getsource(r20_compat)
        self.assertIn('"-j2"',src)
        self.assertIn('"LLVM=1"',src)
        self.assertIn('"flash_allowed": False',src)
    def test_20_unmodified_pin_bijection(self):
        self.assertIn("kernel/sched/core.c", PAIR_SOURCE)
        self.assertIn("mm/vmscan.c", DONOR_SOURCE)
        self.assertIn("mm/vmscan.c", PAIR_SOURCE)
        self.assertEqual(PAIR_SOURCE["mm/vmscan.c"], "d81fc723be0c1a127d4acb7079cad23a2ee0a543")

    def test_21_stage_all_constant_sources_are_pinned(self):
        """Catch the exact R20 KeyError before another GitHub run."""
        import ast, inspect, textwrap
        from r20_compat import stage
        tree=ast.parse(textwrap.dedent(inspect.getsource(stage)))
        keys=[]
        for node in ast.walk(tree):
            if not isinstance(node, ast.Subscript):
                continue
            if not (isinstance(node.value, ast.Name) and node.value.id == 'sources'):
                continue
            try:
                key=ast.literal_eval(node.slice)
            except (ValueError, TypeError, SyntaxError):
                continue  # Dynamic loop variables are handled by their own source list.
            if isinstance(key, tuple) and len(key)==2 and key[0] in {'pair','donor'}:
                keys.append(key)
        self.assertGreaterEqual(len(keys), 9)
        for origin, path in keys:
            self.assertIn(path, PAIR_SOURCE if origin=='pair' else DONOR_SOURCE,
                          f'Missing hard-coded source pin for {origin}:{path}')

    def test_22_vmscan_trial_matches_r19_original_provenance(self):
        self.assertEqual(PAIR_SOURCE['mm/vmscan.c'],
                         'd81fc723be0c1a127d4acb7079cad23a2ee0a543')
        self.assertEqual(DONOR_SOURCE['mm/vmscan.c'],
                         'fa1625a90cd9f2a7eb0f62b0700819fb6c77d3aa')


    def test_23_pinned_softirq_sources(self):
        self.assertEqual(PAIR_SOURCE['kernel/softirq.c'],'0ee55ec4f7a0fc065441295351970d4b3f047cf9')
        self.assertEqual(DONOR_SOURCE['kernel/softirq.c'],'7ff73dfad7c5f81b4a955569ce0725aa6c16317f')
    def test_24_pinned_interrupt_headers(self):
        self.assertEqual(PAIR_SOURCE['include/linux/interrupt.h'],'2ccad949658b86265730c12d4df28f933983c800')
        self.assertEqual(DONOR_SOURCE['include/linux/interrupt.h'],'01517747214a4d53b8df9d2db5e325064d6acce7')
    def test_25_softirq_original_mask(self):
        pair='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
/* Softirq's where the handling might be long: */
#define LONG_SOFTIRQ_MASK ((1 << NET_TX_SOFTIRQ) | (1 << NET_RX_SOFTIRQ) | \
    (1 << BLOCK_SOFTIRQ) | (1 << IRQ_POLL_SOFTIRQ) | (1 << TASKLET_SOFTIRQ))
/* map softirq index to softirq name. update 'softirq_to_name' by source */
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
DECLARE_PER_CPU(__u32, active_softirqs);
'''
        donor='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
'''
        x=reconcile_interrupt_headers(pair,donor)
        self.assertIn('LONG_SOFTIRQ_MASK',x)
        self.assertEqual(x.count('DECLARE_PER_CPU(__u32, active_softirqs);'),1)
    def test_26_softirq_mask_rejects_fake(self):
        pair='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
/* Softirq's where the handling might be long: */
#define LONG_SOFTIRQ_MASK (0)
/* map softirq index to softirq name. update 'softirq_to_name' */
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
DECLARE_PER_CPU(__u32, active_softirqs);
'''
        donor='''#define SOFTIRQ_STOP_IDLE_MASK (~(1 << RCU_SOFTIRQ))
DECLARE_PER_CPU(struct task_struct *, ksoftirqd);
'''
        with self.assertRaises(ValueError):reconcile_interrupt_headers(pair,donor)
    def test_27_softirq_instrumentation(self):
        pair='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
/* active_softirqs genuine Qualcomm */
DEFINE_PER_CPU(__u32, active_softirqs);
const char * const softirq_to_name[NR_SOFTIRQS] = {
__this_cpu_write(active_softirqs, pending);
__this_cpu_write(active_softirqs, 0);
'''
        donor='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
const char * const softirq_to_name[NR_SOFTIRQS] = {
set_softirq_pending(0);

    local_irq_enable();
if (__this_cpu_read(ksoftirqd) == current)
'''.replace('    local_irq_enable();','\tlocal_irq_enable();')
        x=reconcile_softirq(pair,donor)
        self.assertEqual(x.count('DEFINE_PER_CPU(__u32, active_softirqs);'),1)
        self.assertEqual(x.count('__this_cpu_write(active_softirqs, pending);'),1)
        self.assertEqual(x.count('__this_cpu_write(active_softirqs, 0);'),1)
        self.assertIn('set_softirq_pending(0);',x)
    def test_28_softirq_fails_closed_on_changed_dispatch(self):
        pair='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
DEFINE_PER_CPU(__u32, active_softirqs);
const char * const softirq_to_name[NR_SOFTIRQS] = {
__this_cpu_write(active_softirqs, pending);
__this_cpu_write(active_softirqs, 0);
'''
        donor='''DEFINE_PER_CPU(struct task_struct *, ksoftirqd);
set_softirq_pending(1);
if (__this_cpu_read(ksoftirqd) == current)
'''
        with self.assertRaises(ValueError): reconcile_softirq(pair,donor)
    def test_29_trace_block_missing_rejected(self):
        with self.assertRaises(ValueError):reconcile_full_trace(PAIR_TRACE,DONOR_TRACE)
    def test_30_pinned_true_trace_not_mocked(self):
        import inspect, r20_compat
        s=inspect.getsource(r20_compat)
        for term in ('TRACE_EVENT(sched_cpu_util,','TRACE_EVENT(sched_load_balance_sg_stats,',
                     'TRACE_EVENT(sched_load_balance_stats,',
                     'TRACE_EVENT(sched_load_balance_nohz_kick,',
                     'trace_sched_cpu_util'):
            if term=='trace_sched_cpu_util': continue
            self.assertIn(term,s)
    def test_31_softirq_selected_as_required_fifth_target(self):
        self.assertEqual(TARGETS['SOFTIRQ'],'kernel/softirq.o')
    def test_32_source_constants_pinned_at_stage(self):
        import ast,inspect,textwrap
        import r20_compat
        tree=ast.parse(textwrap.dedent(inspect.getsource(r20_compat.stage)))
        keys=[]
        for node in ast.walk(tree):
            if not isinstance(node,ast.Subscript) or not isinstance(node.value,ast.Name) or node.value.id!='sources':continue
            try:k=ast.literal_eval(node.slice)
            except (ValueError,TypeError,SyntaxError):continue
            if isinstance(k,tuple) and len(k)==2 and k[0] in {'pair','donor'}:keys.append(k)
        self.assertGreaterEqual(len(keys),15)
        for label,path in keys:self.assertIn(path,PAIR_SOURCE if label=='pair' else DONOR_SOURCE)
    def test_33_sched_domain_shared_field_from_qualcomm(self):
        pair='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\n#ifdef CONFIG_SCHED_WALT\n\tbool            overutilized;\n#endif\n};'
        donor='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n};'
        x=reconcile_scheduler_topology(pair,donor)
        self.assertEqual(x.count('bool            overutilized;'),1)
    def test_34_sched_domain_shared_rejects_wrong_source(self):
        pair='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\n#ifdef CONFIG_SCHED_WALT\n\tbool            overutilized;\n#endif\n};'
        donor='struct sched_domain_shared {\n\tint\t\thas_idle_cores;\n\nint unrelated;\n};'
        with self.assertRaises(ValueError):reconcile_scheduler_topology(pair,donor)
    def test_35_original_topology_git_blobs_pinned(self):
        self.assertEqual(PAIR_SOURCE['include/linux/sched/topology.h'],'ce91928f2df7fbfa46a64f1cb02e91100db73e03')
        self.assertEqual(DONOR_SOURCE['include/linux/sched/topology.h'],'509c0d1b9c0cbea9955064463c5a664b0d5c8c00')
    def test_36_full_qualcomm_walt_trace_family_import(self):
        # Fixture matching the original GitHub source event names and block guards.
        load='''/*
 * Tracepoint for load balancing:
 */
#ifdef CONFIG_SMP
TRACE_EVENT(sched_load_balance,
);
TRACE_EVENT(sched_load_balance_sg_stats,
);
TRACE_EVENT(sched_load_balance_stats,
);
TRACE_EVENT(sched_load_balance_nohz_kick,
);
#endif /* CONFIG_SMP */
'''
        walt='''#ifdef CONFIG_SCHED_WALT
TRACE_EVENT(sched_load_balance_skip_tasks,
);
TRACE_EVENT(sched_cpu_util,
);
TRACE_EVENT(sched_compute_energy,
);
TRACE_EVENT(sched_task_util,
);
TRACE_EVENT(sched_find_best_target,
);
TRACE_EVENT_CONDITION(sched_overutilized,
);
#endif /* CONFIG_SCHED_WALT */
'''
        pair='#include <linux/binfmts.h>\n#include <linux/sched/idle.h>\n' + PAIR_TRACE + load + 'DECLARE_EVENT_CLASS(sched_process_template,\n' + walt + '#endif /* _TRACE_SCHED_H */'
        donor='#include <linux/binfmts.h>\n' + DONOR_TRACE + 'DECLARE_EVENT_CLASS(sched_process_template,\n' + '#endif /* _TRACE_SCHED_H */'
        result=reconcile_full_trace(pair,donor)
        self.assertEqual(result.count('TRACE_EVENT(sched_cpu_util,'),1)
        self.assertEqual(result.count('TRACE_EVENT(sched_find_best_target,'),1)
        self.assertEqual(result.count('TRACE_EVENT_CONDITION(sched_overutilized,'),1)
        self.assertEqual(result.count('TRACE_EVENT(sched_load_balance_nohz_kick,'),1)
        self.assertIn('DECLARE_EVENT_CLASS(sched_wakeup_template);',result)
        self.assertEqual(result.count('#include <linux/sched/idle.h>'),1)
    def test_37_upstream_duplicate_walt_trace_rejected(self):
        pair=PAIR_TRACE + 'TRACE_EVENT(sched_cpu_util,\n' + 'TRACE_EVENT(sched_cpu_util,\n'
        with self.assertRaises(ValueError):reconcile_full_trace(pair,DONOR_TRACE)


    def test_38_idle_enum_same_original_github_blob(self):
        self.assertEqual(PAIR_SOURCE['include/linux/sched/idle.h'], '22873d276be60e5d4200e7acfd5b7015191005a3')
        self.assertEqual(DONOR_SOURCE['include/linux/sched/idle.h'], '22873d276be60e5d4200e7acfd5b7015191005a3')

    def test_39_trace_requires_genuine_pair_include(self):
        import inspect, r20_compat
        src=inspect.getsource(r20_compat.reconcile_full_trace)
        self.assertIn("pair_trace.count(upstream_include) != 1",src)
        self.assertIn("anchor + upstream_include",src)
        self.assertNotIn('define cpu_idle_type',src)

    def test_40_trace_requires_unique_donor_anchor(self):
        import inspect, r20_compat
        src=inspect.getsource(r20_compat.reconcile_full_trace)
        self.assertIn('donor_trace.count(anchor) != 1',src)
        self.assertIn('upstream_include in donor_trace',src)

    def test_41_stage_enforces_unmodified_idle_header(self):
        import inspect,r20_compat
        src=inspect.getsource(r20_compat.stage)
        self.assertIn('R20_R4_IDLE_ENUM_GENUINE_MATCH_REQUIRED',src)
        self.assertIn('trial/"include/linux/sched/idle.h"',src)

    def test_42_no_stub_or_compile_error_suppression_for_idle_fix(self):
        import inspect,r20_compat
        src=inspect.getsource(r20_compat.reconcile_full_trace)
        self.assertNotIn('-Wno-error',src)
        self.assertNotIn('define trace_',src)
        self.assertNotIn('cpu_idle_type {',src)


    def _selection_sources(self, kind):
        names={"idle":"select_task_rq_idle", "deadline":"select_task_rq_dl", "stop_task":"select_task_rq_stop"}
        fn=names[kind]
        old=f"static int\n{fn}(struct task_struct *p, int cpu, int sd_flag, int flags)\n"
        new=(f"static int\n#ifdef CONFIG_SCHED_WALT\n{fn}(struct task_struct *p, int cpu, int sd_flag, int flags,\n"
             f"\t\t    int sibling_count_hint)\n#else\n{fn}(struct task_struct *p, int cpu, int sd_flag, int flags)\n#endif\n")
        body="{\n\treturn task_cpu(p); /* original donor behavior */\n}\n" if kind!='deadline' else "{\n  struct task_struct *curr;\n  (void)curr;\n}\n"
        return new+body+"\n// pinned source tail\n",old+body+"\n// pinned source tail\n",new,old

    def test_43_all_five_sched_classes_have_pinned_source_blobs(self):
        for kind, p, d in (
            ('IDLE','251a7df055d6ba8644d3df566ba91c2fe5f0ed5f','b8e66abbc618f6037d6e306159f123f80e90d546'),
            ('DEADLINE','58e0eeef00904e84e6a05869f12fc06be55c315e','50fdd78145677d10fe6a90fa13168abc0282533e'),
            ('STOP_TASK','6a0937d4884ff0e07741e060cf45ac17fef8b9d3','02dc0a8e392571bb000dc549b57af0a7f48fb1e5')):
            path={'IDLE':'kernel/sched/idle.c','DEADLINE':'kernel/sched/deadline.c','STOP_TASK':'kernel/sched/stop_task.c'}[kind]
            self.assertEqual(PAIR_SOURCE[path],p)
            self.assertEqual(DONOR_SOURCE[path],d)
            self.assertEqual(TARGETS[kind],path.removesuffix('.c')+'.o')

    def test_44_all_original_scheduler_classes_work_with_upstream_select_signature(self):
        for kind in ('idle','deadline','stop_task'):
            src,donor,upstream,original=self._selection_sources(kind)
            actual=reconcile_sched_class_selector(src,donor,kind)
            self.assertIn(upstream,actual)
            self.assertEqual(actual.replace(upstream,original,1),donor)
            self.assertIn('#else\n',actual)

    def test_45_missing_or_mutated_qualcomm_signature_is_rejected(self):
        for kind in ('idle','deadline','stop_task'):
            src,donor,_,_=self._selection_sources(kind)
            with self.assertRaises(ValueError):
                reconcile_sched_class_selector(src.replace('sibling_count_hint','wrong_hint'),donor,kind)
            with self.assertRaises(ValueError):
                reconcile_sched_class_selector(src.replace('#ifdef CONFIG_SCHED_WALT','#ifdef CONFIG_NOT_WALT'),donor,kind)

    def test_46_donor_body_or_duplicate_signature_is_rejected(self):
        for kind in ('idle','deadline','stop_task'):
            src,donor,_,original=self._selection_sources(kind)
            with self.assertRaises(ValueError):
                reconcile_sched_class_selector(src,donor.replace(original,original+original),kind)
            with self.assertRaises(ValueError):
                reconcile_sched_class_selector(src,donor.replace(original,original.replace('static int','static bool')),kind)

    def test_47_nonexistent_scheduler_class_rejected(self):
        src,donor,_,_=self._selection_sources('idle')
        with self.assertRaises(ValueError):
            reconcile_sched_class_selector(src,donor,'fair')

    def test_48_no_fake_callbacks_or_warnings_masked(self):
        import inspect, r20_compat
        s=inspect.getsource(r20_compat.reconcile_sched_class_selector)
        for forbidden in ('#define select_task_rq','-Wno-error','return 0;','(void) sibling_count_hint;'):
            self.assertNotIn(forbidden,s)
        self.assertIn('NON_SIGNATURE_MODIFICATION',s)

    def test_49_all_new_pinned_sources_used_and_unmodified_donor_precondition(self):
        import inspect, r20_compat
        s=inspect.getsource(r20_compat.stage)
        self.assertIn('"kernel/sched/idle.c", "kernel/sched/deadline.c", "kernel/sched/stop_task.c"',s)
        for kind in ('"idle"','"deadline"','"stop_task"'):
            self.assertIn(kind, s)
        self.assertIn('R20_ORIGINAL_R17_TRIAL_SOURCE_IS_NOT_THE_DONOR',s)

    def test_50_replay_preserved_and_no_flash_or_abi_claim(self):
        import r20_compat, inspect
        src=inspect.getsource(r20_compat)
        self.assertIn('"flash_allowed": False',src)
        self.assertIn('"oem_abi_verified": False',src)
        self.assertNotIn('strip -s',src)
        self.assertIn('"kernel/sched/idle.o"',src)
        self.assertIn('"kernel/sched/deadline.o"',src)
        self.assertIn('"kernel/sched/stop_task.o"',src)


    def _r6_headers(self):
        flag = "#define SCHED_FLAG_SUGOV\t0x10000000\n"
        macro = "#define SCHED_DL_FLAGS (SCHED_FLAG_RECLAIM | SCHED_FLAG_DL_OVERRUN | SCHED_FLAG_SUGOV)\n"
        tail = "static inline bool dl_entity_is_special(struct sched_dl_entity *dl_se)\n{\n  return false;\n}\n"
        return flag + "\n" + tail, flag + "\n" + macro + "\n" + tail, flag + "\n" + tail, macro

    def test_51_r6_exact_original_sched_h_blobs(self):
        self.assertEqual(PAIR_SOURCE['kernel/sched/sched.h'], '79b175a65e0ebda59a5ccc13691b454b347e7701')
        self.assertEqual(DONOR_SOURCE['kernel/sched/sched.h'], '15e50442697e1e0e655cb970130d9c14af56b049')

    def test_52_r6_only_original_macro_grafted(self):
        pair, donor, trial, macro = self._r6_headers()
        fixed = reconcile_sched_dl_flags(pair, donor, trial)
        self.assertEqual(fixed.count(macro), 1)
        self.assertEqual(fixed.replace('\n' + macro, '', 1), trial)

    def test_53_r6_duplicate_or_missing_macro_is_rejected(self):
        pair, donor, trial, macro = self._r6_headers()
        for bad_pair,bad_donor,bad_trial in (
            (pair + macro, donor, trial), (pair, donor.replace(macro, ''), trial),
            (pair, donor, trial + macro), (pair.replace('#define SCHED_FLAG_SUGOV', '#define INVALID_FLAG'), donor, trial),
        ):
            with self.assertRaises(ValueError):
                reconcile_sched_dl_flags(bad_pair, bad_donor, bad_trial)

    def test_54_r6_rejects_wrong_location_of_donor_definition(self):
        pair, donor, trial, macro = self._r6_headers()
        bad_donor = donor.replace(macro, '') + macro
        with self.assertRaises(ValueError): reconcile_sched_dl_flags(pair,bad_donor,trial)

    def test_55_r6_previous_walt_callbacks_untouched(self):
        import inspect,r20_compat
        s=inspect.getsource(r20_compat.stage)
        self.assertIn('reconcile_sched_class_selector(', s)
        self.assertIn('"kernel/sched/sched.h": experimental_sched_repaired',s)
        self.assertIn('R20_STOCK_HEADER_MUTATION',s)
        self.assertIn('R20_R6_TRIAL_SCHED_INTERNAL_HEADER_MISSING',s)

    def test_56_r6_dependency_macro_is_original_not_stubbed(self):
        import inspect, r20_compat
        s=inspect.getsource(r20_compat.reconcile_sched_dl_flags)
        self.assertIn('SCHED_FLAG_RECLAIM | SCHED_FLAG_DL_OVERRUN | SCHED_FLAG_SUGOV',s)
        self.assertNotIn('-Wno-error',s)
        self.assertNotIn('SCHED_FLAG_RECLAIM = 0',s)


    def _r7_topology_samples(self):
        pre='/* original private scheduler topology */\n'
        perf='static bool build_perf_domains(const struct cpumask *cpu_map)\n{\n'
        tail='    if (!sysctl_sched_energy_aware) goto free;\n    for_each_cpu(i, cpu_map) {\n        if (find_pd(pd, i)) continue;\n    }\n    if (nr_pd * (nr_cs + nr_cpus) > EM_MAX_COMPLEXITY) goto free;\n    rcu_assign_pointer(rd->pd, pd);\n    return !!pd;\nfree:\n    free_pd(pd);\n    return false;\n}\n#else\nstatic void free_pd(struct perf_domain *pd) { }\n'
        donor_perf=perf+'    cpumask_copy(&min_cap_cpu_mask, &min_cpu_mask);\n'+tail
        pair_perf=perf+'#ifndef CONFIG_SCHED_WALT\n    if (condition) goto free;\n#endif\n'+tail
        donor_init='static void init_sched_groups_capacity(int cpu, struct sched_domain *sd)\n{\n    sg->group_weight = cpumask_weight(sched_group_span(sg));\n    update_group_capacity(sd, cpu);\n}\n\n'
        pair_init='void init_sched_groups_capacity(int cpu, struct sched_domain *sd)\n{\n#ifdef CONFIG_SCHED_WALT\n    cpumask_t avail_mask;\n#endif\n#ifdef CONFIG_SCHED_WALT\n    cpumask_andnot(&avail_mask, mask, cpu_isolated_mask);\n#else\n    sg->group_weight = cpumask_weight(sched_group_span(sg));\n#endif\n    sg->group_weight = cpumask_weight(sched_group_span(sg));\n    update_group_capacity(sd, cpu);\n}\n\n'
        # The pair contains one standard group_weight assignment, in else branch.
        pair_init=pair_init.replace('    sg->group_weight = cpumask_weight(sched_group_span(sg));\n    update_group_capacity','    update_group_capacity')
        marker='/*\n * Initializers for schedule domains\n */\n'
        return pre+donor_perf+donor_init+marker,pre+pair_perf+pair_init+marker

    def test_57_r7_exact_original_pins(self):
        self.assertEqual(PAIR_SOURCE['kernel/sched/topology.c'],'d2b122897c7e473fb837cc9629dba6ca4197f463')
        self.assertEqual(DONOR_SOURCE['kernel/sched/topology.c'],'571adb2ded0abd2013569d01be797df45b59db76')

    def test_58_r7_genuine_pair_replaces_only_two_functions(self):
        donor,pair=self._r7_topology_samples()
        result=reconcile_qualcomm_topology(pair,donor)
        self.assertNotIn('min_cap_cpu_mask',result)
        self.assertIn('cpu_isolated_mask',result)
        self.assertIn('void init_sched_groups_capacity(',result)
        self.assertNotIn('static void init_sched_groups_capacity(',result)
        self.assertIn('/* original private scheduler topology */',result)

    def test_59_r7_missing_original_upstream_rejected(self):
        donor,pair=self._r7_topology_samples()
        for changed_pair in (pair.replace('#ifndef CONFIG_SCHED_WALT','#ifndef CONFIG_NOT_WALT'),pair.replace('cpu_isolated_mask','not_cpu_isolated_mask'),pair.replace('static bool build_perf_domains','static int build_perf_domains')):
            with self.assertRaises(ValueError):reconcile_qualcomm_topology(changed_pair,donor)

    def test_60_r7_missing_original_donor_rejected(self):
        donor,pair=self._r7_topology_samples()
        for bad in (donor.replace('min_cap_cpu_mask','not_min_cap_cpu_mask'),donor.replace('static void init_sched_groups_capacity','void init_sched_groups_capacity')):
            with self.assertRaises(ValueError):reconcile_qualcomm_topology(pair,bad)

    def test_61_r7_nine_objects_plus_twelve(self):
        self.assertEqual(len(TARGETS),10)
        self.assertEqual(TARGETS['TOPOLOGY'],'kernel/sched/topology.o')
        self.assertEqual(len(R17_REGRESSION),12)

    def test_62_r7_fails_if_sprd_rotation_enabled(self):
        import inspect,r20_compat
        self.assertIn('CONFIG_SPRD_ROTATION_TASK=y',inspect.getsource(r20_compat.compile_objects))

    def test_63_r7_tamper_unchanged_tail_rejected(self):
        donor,pair=self._r7_topology_samples()
        pair=pair.replace('rcu_assign_pointer(rd->pd, pd)','do_nothing(pd)')
        with self.assertRaises(ValueError):reconcile_qualcomm_topology(pair,donor)


    def _r8_debug_samples(self):
        head='#include "sched.h"\n#define   PM(F, M) __PS(#F, p->F & (M))\n'
        # Function body samples only: enough to test exact upstream output rewrite.
        stem='void proc_sched_show_task(struct task_struct *p, struct pid_namespace *ns, struct seq_file *m)\n{\n#define P(F) \\\n\tSEQ_printf(m, "%s", #F)\n\tP(se.avg.util_est.ewma);\n'
        tail='#undef P\n}\nvoid proc_sched_set_task(struct task_struct *p)\n{\n}\n'
        donor=head+stem+'\tPM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED);\n'+tail
        pair=head.replace('#define   PM(F, M) __PS(#F, p->F & (M))\n','')+stem+'\tP(se.avg.util_est.enqueued);\n'+tail
        return pair,donor

    def test_64_r8_genuine_upstream_debug_source_pins(self):
        self.assertEqual(PAIR_SOURCE['kernel/sched/debug.c'],'5bf8939658bf46022e0dcaae3f600c7526ff77ba')
        self.assertEqual(DONOR_SOURCE['kernel/sched/debug.c'],'76f74c238a5a2dada979f0e779ba31dcf1c49b0f')

    def test_65_r8_exact_upstream_debug_statement_not_dummy(self):
        pair,donor=self._r8_debug_samples()
        out=reconcile_sched_debug(pair,donor)
        self.assertEqual(out,pair)
        self.assertNotIn('__PS',out)
        self.assertIn('P(se.avg.util_est.enqueued);',out)

    def test_66_r8_invalid_original_donor_macro_rejected(self):
        pair,donor=self._r8_debug_samples()
        with self.assertRaises(ValueError):reconcile_sched_debug(pair,donor.replace('__PS','__P'))

    def test_67_r8_missing_qualcomm_print_rejected(self):
        pair,donor=self._r8_debug_samples()
        with self.assertRaises(ValueError):reconcile_sched_debug(pair.replace('P(se.avg.util_est.enqueued);','P(se.avg.util_est.ewma);'),donor)

    def test_68_r8_duplicate_debug_print_rejected(self):
        pair,donor=self._r8_debug_samples()
        with self.assertRaises(ValueError):reconcile_sched_debug(pair,donor+"\tPM(se.avg.util_est.enqueued, ~UTIL_AVG_UNCHANGED);\n")

    def test_69_r8_true_debug_object_gate(self):
        self.assertEqual(TARGETS['DEBUG'],'kernel/sched/debug.o')
        self.assertEqual(len(TARGETS),10)
        self.assertEqual(len(R17_REGRESSION),12)

if __name__=="__main__":unittest.main()
