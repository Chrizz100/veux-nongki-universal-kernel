"""Authenticate the M53 source and extract the matching Xiaomi reference image."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile
from check import BASE_CONFIG, BASE_IMAGE, sha, stock, write, require

root=Path(__file__).resolve().parent
work=Path(sys.argv[1]).resolve()
work.mkdir(parents=True,exist_ok=True)
source=work/'src'
source.mkdir()
base=work/'baseline.config'
with zipfile.ZipFile(work/'m53.zip') as archive:
    require(sha(work/'m53.zip')=='4fe80a41e2e65587a6ffd61c26369c33cd94ff7e36f13505fa74d873e6b99eda', 'M53 artifact digest')
    manifest=json.loads(archive.read('M53_KERNEL.json'))
    require(manifest['image_sha256']==BASE_IMAGE,'M53 image identity')
    base.write_bytes(archive.read('kernel.config'))
    require(sha(base)==BASE_CONFIG,'M53 config identity')
    archive.extract('M53-kernel-source.tar.gz',work)
tar=work/'M53-kernel-source.tar.gz'
require(sha(tar)=='96755966c0ebd2b83c5f1ee043ef730b081c1245c25fe8c88958149c34eab5d3','M53 source digest')
subprocess.run(['tar','-xzf',tar,'-C',source],check=True)
with zipfile.ZipFile(work/'m46.zip') as archive:
    require(sha(work/'m46.zip')=='e980811eb4a91478ccd74faa31f4709348d12a4a3d027a9048ed71e149a10164','M46 artifact digest')
    with zipfile.ZipFile(io.BytesIO(archive.read('VEUX_M46_Stock_und_Geraetecheck.zip'))) as inner:
        inner.extract('boot.img',work)
stock(work/'boot.img')
patch=root/'oom-priority.patch'
subprocess.run(['git','apply','--check',patch],cwd=source,check=True)
subprocess.run(['git','apply',patch],cwd=source,check=True)
for rel,digest in json.loads((root/'postimages.json').read_text()).items():
    require(sha(source/rel)==digest,'Unexpected patched source: '+rel)
out=work/'out'
out.mkdir()
shutil.copyfile(base,out/'.config')
subprocess.run(['bash',source/'scripts/config','--file',out/'.config','-e','PRIORITIZE_OOM_TASKS','--set-val','OOM_TASK_PRIORITY_ADJ_LIMIT','0'],check=True)
