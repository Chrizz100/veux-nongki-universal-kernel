# VEUX M54 · Prozessauswahl bei Speichermangel

Grundlage ist der erfolgreiche M53-Bau für Xiaomi VEUX mit der Kennung 5.4.274-qgki-g82179e362f33. Referenz ist Xiaomis originale boot.img des Builds V816.0.12.0.TKCMIXM. Die SHA-256 dieser Stock-Datei lautet ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5. Das separat vom laufenden Gerät gesicherte boot_a bleibt der persönliche Wiederherstellungsstand.

## GitHub

1. VEUX_M54_MAIN.zip als ZIP ins Hauptverzeichnis hochladen.
2. VEUX_M54_OOM_NOFLASH.yml im selben Branch unter .github/workflows/ speichern.
3. In Actions „VEUX M54 – Stock-Speicherverwaltung, QGKI 5.4.274“ manuell starten.

Der Workflow lädt den Quellstand aus Artefakt 14750997936 sowie die Stock-Referenz aus Artefakt 14706022228. Beide müssen zu diesem Zeitpunkt bei GitHub verfügbar sein. Die ZIPs, das Quellarchiv, die Stockdatei und die drei geänderten Quelldateien werden mit festen SHA-256 verglichen. Das Paket ist für GitHub vorgesehen.

## Bestätigter Stand aus M53

Beide Artefakte aus [Lauf 45013249769](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/45013249769/job/137179963678) wurden heruntergeladen und geprüft. Das Image, vmlinux und die eingebetteten Konfigurationen passen zum archivierten Bau. Die drei Atomikfunktionen wurden am fertigen Image erneut mit Xiaomi verglichen. 3.148 Importe aus 37 Vendor-Modulen (1.423 unterschiedliche Symbole) stimmen mit Symbol-CRC und Anbieter überein. Die Prüfungen für F2FS, Radixbaum, Bootinfo und das statische Bootlayout waren erfolgreich. In den Kbuild-Protokollen für Image, Module und Vorbau fand sich keine Compilerwarnung. GitHub meldete veraltete Action-Runtimes. M54 verwendet auf Node 24 ausgelegte, auf Commit-SHA festgelegte Actions.

## Reparatur und Befund am Xiaomi-Kernel

Xiaomis fertiger 5.4.274-Kernel berücksichtigt bei der ersten Prozessauswahl nur Kandidaten mit oom_score_adj ab 0. Findet dieser Durchlauf keinen geeigneten Kandidaten, kann der reguläre Bewertungsdurchlauf auch niedrigere Werte einbeziehen. Das gilt systemweit und innerhalb einer Speichergruppe. Im per Prüfsumme identifizierten Xiaomi-Image wurden die Symbole aus den eingebetteten kallsyms-Daten rekonstruiert. Im M53-Image weist der Code je einen Aufruf zur Auswahl je Bereich auf, im Stock-Image je zwei.

M54 übernimmt die Optionen PRIORITIZE_OOM_TASKS=y und OOM_TASK_PRIORITY_ADJ_LIMIT=0 sowie die betroffenen Stellen aus [Xiaomis öffentlicher VEUX-Quelle](https://github.com/MiCode/Xiaomi_Kernel_OpenSource/tree/61397e524093d1ccb94769b5460825e2eaf8871e/mm). Die vorzeichenbehafteten Bewertungen aus 5.4.274, der LONG_MIN-Startwert pro Durchlauf und die Behandlung eines bereits ausgewählten OOM-Opfers bleiben Bestandteil der Auswahl. Der Kernel berücksichtigt die Xiaomi-Wartefrist, falls ein Administrator panic_on_oom aktiviert hat. Der Zeitpunkt wird nach einem vom Kernel ausgelösten Abschuss zurückgesetzt.

Die ARM64-Prüfung bestätigt zwei Auswahlstellen im aktivierten OOM-Objekt und eine bei ausgeschaltetem Schalter. Das neue Prioritätsfeld liegt bei Byte 56, die nachfolgende Einschränkung bei Byte 60, passend zu den Zugriffen im Stock-Image. Die Hosttests führen die tatsächlichen C-Funktionen des Kernelbaums mit simulierten Prozessen, Speichergruppen, Signalen und Zeitgebern aus. Vier Konfigurationen mit jeweils 3.872 paarweisen Entscheidungen ergeben 15.488 Fälle. Zusätzliche Tests betreffen unter anderem Prozess-Schutz, Speichergruppen, laufende Opfer, Referenzfreigabe, Zeitüberlauf und den Rückfall bei Speichermangel. Ein echter Speichermangel auf einem VEUX wurde damit nicht ausgelöst.

## Bilanz

| Gegenstand | Ergebnis |
|---|---|
| Textliche Konfigurationsabweichungen gegenüber Xiaomi | M53 hat 52. Der lokale M54-Kbuild hat 50. Die einzigen Änderungen zur M53-Konfiguration sind die beiden OOM-Optionen. |
| Zwei ARM64-LSE-Einträge | Das abweichende Kconfig-Format beschreibt die abgeschaltete Erweiterung. Die drei geprüften M53-Codepfade entsprechen dem Verhalten von Stock. |
| Fünf ZRAM_DEF_COMP-Einträge | Die Initialisierung in zram_add übergibt in Stock und M53 nachweislich „lzo-rle“ als Standard an strlcpy. M54 prüft den Aufruf im fertigen Image erneut. Das MIUI-spezifische zRAM-Tracking ist eine eigene offene Funktion. |
| Übrige 43 Konfigurationszeilen | Enthalten weitere Funktions-, Werkzeug- und Darstellungsunterschiede. Die vollständige Liste mit allen 50 Zeilen steht in Restkonfiguration.csv. Eine Fehlerquote lässt sich daraus nicht berechnen. |
| Bestätigte weitere Abweichung im Speicherpfad | Im Stock-Maschinencode ruft group_send_sig_info nach der Signalzustellung add_to_oom_reaper auf. Dieser prüft task_will_free_mem und erreicht wake_oom_reaper. Die Xiaomi-Verknüpfung fehlt im M53-Quellstand und ist vom M54-Patch nicht abgedeckt. |
| Weitere Geräteprüfungen | Thermische CPU-Isolation, F2FS-Wiederanlauf nach unterbrochenem Schreiben, Boot/Verity/UFS am laufenden Kandidaten und praktisch erprobte Wiederherstellung bleiben offen. |

## Ergebnis des nächsten Laufs

SPEICHER-Vorprüfung, ARM64-Objekte, Portierungstests, Kernel-Konfiguration und Modulimporte stehen im Artefakt KERNEL-NACHWEISE. Nach dem vollständigen Bau vergleicht M54 die OOM-Auswahlstellen, die zRAM-Initialisierung sowie die drei ARM64-Atomikpfade im fertigen Kernel-Image mit der Xiaomi-Referenz. QUELLSTAND enthält die Quellen und die Konfiguration des erfolgreichen Laufs. Bis zum getesteten Gerätestart und zur Klärung des Rückwegs bleibt die Flash-Freigabe offen.
