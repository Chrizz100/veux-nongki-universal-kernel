"""Compare the candidate to the actual stock image, M53 and original vendor imports."""
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import json
import mmap
import struct
import tempfile

from config_proof import autoconf_check, config_values, embedded, extract_config, require
from layout.boot import make_image, unpack_m45

ROOT = Path(__file__).resolve().parent
REL = '5.4.274-qgki-g82179e362f33'
BOOT = 'ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5'
STOCK_IMAGE = '6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
BASE_CONFIG = '6bcc1686f88b94c8484016d583d2885249b73c5e9e8efbeb5164c07b25fb307a'
BASE_IMAGE = 'bfde94963367beb578e27eac0f5c2259a7c5d6f65523ecc3da0f9a34ebaa45fc'
DTB = '4b7fa9ac17c325234bc4ba75f65aefa42fdd32647b40e9bd3f616c9d9a6c2a96'
BOOTINFO = ['pureason', 'powerup_reason_details', 'unknown reboot', 'long_power_key', 'dm_verity_logging',
            'Powerup reason=', 'qpnp_pon_is_lpk', 'qpnp_pon_is_ps_hold_reset']
LEGACY = ['Write Booster Configured', 'ufstw\0', 'enable_tw\0', 'enable_flush_en\0', 'enable_autoflush_in_h8\0',
          'xiaomi,simtray-status\0', 'cpumaxfreq\0', 'dp_flag\0', 'androidboot.vbmeta.invalidate_on_error\0',
          'androidboot.vbmeta.device\0', 'AVB error handler called for', 'qcom,ufshc\0',
          'qcom,ufs-phy-qmp-v4-yupik\0', 'bq2589x: fault settings restore failed', 'Linux version ' + REL + ' (']

def sha(path):
    with path.open('rb') as src:
        h = hashlib.sha256()
        for chunk in iter(lambda: src.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def stock(path):
    require(sha(path) == BOOT, 'Xiaomi boot hash')
    raw = path.read_bytes()
    require(raw[:8] == b'ANDROID!' and struct.unpack_from('<I',raw,40)[0] in (3,4), 'Xiaomi boot header')
    kernel = raw[4096:4096+struct.unpack_from('<I',raw,8)[0]]
    require(hashlib.sha256(kernel).hexdigest() == STOCK_IMAGE and all(s.encode() in kernel for s in BOOTINFO+['parent xattr is set','parent dir xattr set']), 'Xiaomi bootinfo evidence')
    return config_values(extract_config(kernel))

def abi(symvers, result):
    actual = {}
    for line in symvers.read_text().splitlines():
        crc, symbol, owner, *_ = line.split()
        require(symbol not in actual, 'Duplicate export '+symbol)
        actual[symbol] = (crc.lower(), owner)
    with (ROOT/'ref/vendor-imports.csv').open() as src:
        imports = list(csv.DictReader(src))
    with (result/'QGKI-Importe.csv').open('w',newline='') as dst:
        w = csv.writer(dst); w.writerow(['Modul','Symbol','Stock-CRC','Kernel-CRC','Anbieter','Status'])
        misses = 0
        for r in imports:
            crc, owner = actual.get(r['symbol'], ('', ''))
            expected_owner = ('drivers/bluetooth/btpower' if r['symbol'] in
                              ('btpower_register_slimdev','btpower_get_chipset_version') else 'vmlinux')
            ok = crc == r['expected_crc'].lower() and owner == expected_owner
            misses += not ok
            w.writerow([r['module'],r['symbol'],r['expected_crc'],crc,owner,'PASS' if ok else 'FAIL'])
    counts = [len({r['symbol'] for r in imports}),len(imports),len({r['module'] for r in imports})]
    require(counts == [1423,3148,37] and not misses, f'Vendor-ABI {counts}, {misses} mismatches')
    return counts

def configs(baseline, candidate, rom, result):
    require(sha(baseline) == BASE_CONFIG, 'Wrong M53 config')
    b,c = [config_values(p.read_bytes()) for p in (baseline,candidate)]
    diff = lambda left,right: {k:(left.get(k),right.get(k)) for k in sorted(left.keys() | right.keys()) if left.get(k)!=right.get(k)}
    original = diff(rom,b)
    repair = {'CONFIG_PRIORITIZE_OOM_TASKS':'y','CONFIG_OOM_TASK_PRIORITY_ADJ_LIMIT':'0'}
    require(len(original)==52 and all(original[k]==(value,None) for k,value in repair.items()), 'M53 vs Stock')
    changes = diff(b,c)
    require(changes=={k:(None,v) for k,v in repair.items()}, f'M54 config delta {changes}')
    rest = diff(rom,c)
    require(len(rest)==50 and rest=={k:v for k,v in original.items() if k not in repair}, 'Unexpected config changes')
    require(c['CONFIG_F2FS_CP_OPT']=='y' and c['CONFIG_BPF_JIT']=='y', 'F2FS/BPF config')
    with (result/'Restkonfiguration.csv').open('w',newline='') as f:
        w=csv.writer(f,delimiter=';'); w.writerow(['Option','Xiaomi 5.4.274','M54'])
        w.writerows((k,*v) for k,v in rest.items())

def final(a):
    out=a.out
    image=out/'arch/arm64/boot/Image'
    config=(out/'.config').read_bytes()
    require(sha(image)!=BASE_IMAGE and image.read_bytes()[56:60]==b'ARM\x64','Expected new ARM64 Image')
    require((out/'include/config/kernel.release').read_text().strip()==REL and
            (out/'include/generated/utsrelease.h').read_text().split('"')[1]==REL,'Kernel release')
    require(gzip.decompress((out/'kernel/config_data.gz').read_bytes())==config, 'Kbuild config_data')
    count=autoconf_check(config,(out/'include/generated/autoconf.h').read_text())
    for path in [image,out/'vmlinux']:
        require(embedded(path)==config,'IKCONFIG: '+path.name)
        with path.open('rb') as f, mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as data:
            for s in LEGACY+BOOTINFO+['parent xattr is set']:
                require(data.find(s.encode())>=0, 'Missing marker in '+path.name+': '+repr(s))
            require(data.find(b'LSE atomic instructions\0')<0,'LSE capability active in '+path.name)
    exports=(out/'Module.symvers').read_text().splitlines()
    for name in BOOTINFO[-2:]:
        require(any(row.split()[1:3]==[name,'vmlinux'] for row in exports),'Missing PMIC export: '+name)
    dt=out/'arch/arm64/boot/dts'
    require({p.relative_to(dt).as_posix():sha(p) for p in dt.rglob('*') if p.suffix in ('.dtb','.dtbo')}==
            {'vendor/xiaomi/veux.dtb':DTB},'VEUX DTB differs')
    module_names={p.relative_to(out).as_posix() for p in out.rglob('*.ko')}
    require(module_names=={'drivers/bluetooth/btpower.ko','drivers/bluetooth/bt_fm_slim.ko',
            'drivers/char/rdbg.ko','drivers/media/rc/ir-spi.ko'},'Built module set: '+str(module_names))
    for name in module_names:
        require(('vermagic='+REL+' ').encode() in (out/name).read_bytes(),'Module vermagic: '+name)
    table=abi(out/'Module.symvers',a.result)
    with tempfile.TemporaryDirectory() as tmp:
        base=unpack_m45(Path(tmp))
        rebuilt,page,index=make_image(base,a.stock.read_bytes(),image.read_bytes())
        boot=base.image_info(rebuilt)
        require(boot['kernel_sha256']==sha(image) and boot['ramdisk_sha256']==base.RAMDISK and
                len(rebuilt)==134217728,'Stock layout')
    write(a.result/'M54_KERNEL.json',dict(release=REL,config_sha256=sha(out/'.config'),image_sha256=sha(image),
          vmlinux_sha256=sha(out/'vmlinux'),dtb_sha256=DTB,remaining_stock_options=50,autoconf_entries=count,
          atomics_stock_equivalent_config_entries=['CONFIG_ARM64_LSE_ATOMICS','CONFIG_ARM64_USE_LSE_ATOMICS'],
          vendor_abi=dict(zip(('symbols','imports','modules'),table)),built_modules=sorted(module_names),
          stock_layout=dict(bytes=len(rebuilt),ramdisk_sha256=boot['ramdisk_sha256'],avb_page=index),
          device_pass=False,flash_allowed=False))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stage',choices=['config','final'])
    for name in ['out','stock','baseline','result']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args()
    a.result.mkdir(parents=True,exist_ok=True)
    configs(a.baseline,a.out/'.config',stock(a.stock),a.result)
    if a.stage=='final':final(a)
