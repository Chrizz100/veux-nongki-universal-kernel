#!/usr/bin/env bash
# Run from the work directory containing the authenticated source and stock boot.img.
set -euo pipefail
tools=$(cd "$(dirname "$0")" && pwd)
python3 -B "$tools/memory_image.py" stock clang/bin boot.img evidence/Xiaomi-Speicher.json
python3 -B "$tools/test_oom.py" src
bash "$tools/kbuild.sh" src out clang mm/oom_kill.o mm/page_alloc.o mm/memcontrol.o kernel/sysctl.o drivers/block/zram/zram_drv.o
clang/bin/ld.lld -r out/mm/oom_kill.o -o evidence/OOM-arm64.o
python3 -B "$tools/oom_object.py" clang/bin on evidence/OOM-arm64.o evidence/OOM-ein.json
mkdir -p oom-off
cp out/.config oom-off/.config
bash src/scripts/config --file oom-off/.config -d PRIORITIZE_OOM_TASKS
bash "$tools/kbuild.sh" src oom-off clang olddefconfig
bash "$tools/kbuild.sh" src oom-off clang mm/oom_kill.o
clang/bin/ld.lld -r oom-off/mm/oom_kill.o -o evidence/OOM-arm64-aus.o
python3 -B "$tools/oom_object.py" clang/bin off evidence/OOM-arm64-aus.o evidence/OOM-aus.json
