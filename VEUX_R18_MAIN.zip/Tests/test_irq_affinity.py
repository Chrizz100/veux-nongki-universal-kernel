import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r18_tests', ROOT / 'Tools/r18_irq_affinity.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class IrqAffinityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original', self.source)

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self):
        return {n: (self.source / n).read_bytes() for n in r.FILES}

    def test_both_full_commits_produce_the_exact_three_candidate_files(self):
        result = r.apply_source(self.source)
        self.assertFalse(result['GPIO_fix_already_present'])
        for n in r.FILES:
            self.assertEqual((self.source / n).read_bytes(), (ROOT / 'Candidate' / n).read_bytes())

    def test_preflight_does_not_write_and_comments_survive(self):
        path = self.source / r.FILES[0]
        path.write_text('# earlier unrelated integration\n' + path.read_text())
        before = self.snapshot()
        self.assertFalse(r.check_source(self.source)['source_changed'])
        self.assertEqual(before, self.snapshot())
        r.apply_source(self.source)
        self.assertTrue(path.read_text().startswith('# earlier unrelated integration'))

    def test_late_gpio_drift_prevents_all_three_writes(self):
        path = self.source / r.FILES[2]
        text = path.read_text()
        old = r.function(text, r.FUNCTIONS[0])
        path.write_text(text.replace(old, old.replace('return 0;', 'return 7;'), 1))
        before = self.snapshot()
        with self.assertRaises(ValueError):
            r.apply_source(self.source)
        self.assertEqual(before, self.snapshot())

    def test_symlink_cannot_redirect_a_source_write(self):
        path = self.source / r.FILES[1]
        outside = Path(self.temp.name) / 'outside'
        outside.write_bytes(path.read_bytes())
        original = outside.read_bytes()
        path.unlink()
        path.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'SOURCE_NOT_REGULAR'):
            r.apply_source(self.source)
        self.assertEqual(original, outside.read_bytes())

    def test_preexisting_complete_upstream_fix_is_preserved(self):
        shutil.copyfile(ROOT / 'Candidate' / r.FILES[2], self.source / r.FILES[2])
        result = r.apply_source(self.source)
        self.assertTrue(result['GPIO_fix_already_present'])
        for n in r.FILES:
            self.assertEqual((self.source / n).read_bytes(), (ROOT / 'Candidate' / n).read_bytes())

    def test_partial_upstream_fix_and_reapplication_are_rejected(self):
        path = self.source / r.FILES[2]
        text = path.read_text()
        old = r.function(text, r.FUNCTIONS[0])
        path.write_text(text.replace(old, old.replace('return 0;', 'return -EINVAL;'), 1))
        with self.assertRaisesRegex(ValueError, 'PARTIAL_UPSTREAM_GPIO_FIX'):
            r.apply_source(self.source)
        shutil.copyfile(ROOT / 'Original' / r.FILES[2], path)
        r.apply_source(self.source)
        with self.assertRaises(ValueError):
            r.apply_source(self.source)

    def r17(self):
        return r.load_r17(os.environ['R18_R17_TOOL'])

    def abi(self):
        r17 = self.r17()
        base = r17.load_base(os.environ['R18_BASE_TOOL'])
        h = base.dependency().dependency().dependency()[2]
        expected, _ = h.references()
        previous = set(r.profile()['previous_matches'])
        actual = {n: (crc if n in previous else '0x00000000') for n, crc in expected.items()}
        for name in r.profile()['required_gains']:
            actual[name] = expected[name]
        return actual, expected

    def test_only_the_single_stock_irq_config_flag_may_change(self):
        r17 = self.r17()
        base = r17.load_base(os.environ['R18_BASE_TOOL'])
        r12 = base.dependency().dependency().dependency()[1]
        before = r12.config_values((base.ROOT / 'References/R15.config').read_text())
        before.update(CONFIG_EMERGENCY_MEMORY='y', CONFIG_MULTIPLE_KSWAPD='y',
                      CONFIG_VM_EVENT_COUNT_CLEAN_PAGE_RECLAIM='y')
        after = dict(before, **{r.FLAG: 'y'})
        self.assertEqual(r.verify_config(before, after, r17), before)
        after['CONFIG_CFI_CLANG'] = 'n'
        with self.assertRaises(ValueError):
            r.verify_config(before, after, r17)

    def test_1304_previous_and_all_104_new_matches_are_mandatory(self):
        actual, expected = self.abi()
        result = r.verify_abi(actual, expected)
        self.assertEqual(result['counts'], {'MATCH': 1408, 'CRC_MISMATCH': 15, 'NOT_EXPORTED': 0})
        actual[r.profile()['required_gains'][0]] = '0x00000000'
        with self.assertRaisesRegex(ValueError, 'LOCAL_104_GAINS_NOT_CONFIRMED'):
            r.verify_abi(actual, expected)

    def test_old_match_loss_or_missing_original_import_cannot_pass(self):
        actual, expected = self.abi()
        name = r.profile()['previous_matches'][0]
        old = actual[name]
        actual[name] = '0x00000000'
        with self.assertRaisesRegex(ValueError, '1304_STOCK_MATCH_LOST'):
            r.verify_abi(actual, expected)
        actual[name] = old
        name = next(n for n in expected if n not in r.profile()['previous_matches'])
        del actual[name]
        with self.assertRaisesRegex(ValueError, 'ORIGINAL_IMPORT_MISSING'):
            r.verify_abi(actual, expected)


if __name__ == '__main__':
    unittest.main()
