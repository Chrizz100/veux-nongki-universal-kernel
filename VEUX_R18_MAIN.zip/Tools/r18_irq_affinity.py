#!/usr/bin/env python3
"""Restore stock IRQ affinity plus the complete upstream Qualcomm error-path fix."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
FLAG = 'CONFIG_GENERIC_IRQ_EFFECTIVE_AFF_MASK'
FILES = ('drivers/irqchip/Kconfig', 'kernel/irq/Kconfig', 'drivers/pinctrl/qcom/pinctrl-msm.c')
FUNCTIONS = ('msm_gpio_irq_set_affinity', 'msm_gpio_irq_set_vcpu_affinity')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def profile():
    value = json.loads((ROOT / 'References/PROFILE.json').read_text())
    require(len(set(value['previous_matches'])) == 1304
            and len(set(value['required_gains'])) == 104, 'R18_PROFILE_CHANGED')
    return value


def verify_package():
    listed = set()
    for row in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = row.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in listed,
                'UNSAFE_R18_MANIFEST')
        require(not (ROOT / p).is_symlink() and sha(ROOT / p) == digest, 'R18_FILE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == listed, 'R18_MANIFEST_SCOPE_CHANGED')
    profile()


def function(text, name):
    start = re.search(r'(?m)^static int ' + re.escape(name) + r'\(', text)
    require(start is not None, 'GPIO_HANDLER_MISSING:' + name)
    end = re.search(r'(?m)^}', text[start.start():])
    require(end is not None, 'GPIO_HANDLER_UNCLOSED:' + name)
    return text[start.start():start.start() + end.end()]


def gpio_fixed(source):
    text = (source / FILES[2]).read_text()
    state = []
    for name in FUNCTIONS:
        body = function(text, name)
        require('d->parent_data && test_bit(d->hwirq, pctrl->skip_wake_irqs)' in body,
                'VENDOR_WAKE_PARENT_GUARD_CHANGED:' + name)
        target = 'irq_chip_set_affinity_parent' if name == FUNCTIONS[0] else 'irq_chip_set_vcpu_affinity_parent'
        require(target + '(' in body, 'GPIO_PARENT_DELEGATION_LOST:' + name)
        require(body.count('return -EINVAL;') + body.count('return 0;') == 1,
                'GPIO_UNSUPPORTED_PATH_CHANGED:' + name)
        state.append('return -EINVAL;' in body)
    require(state[0] == state[1], 'PARTIAL_UPSTREAM_GPIO_FIX')
    return all(state)


def validate_postimage(source):
    kernel = (source / FILES[1]).read_text()
    block = re.search(r'(?ms)^config GENERIC_IRQ_EFFECTIVE_AFF_MASK\n(.*?)(?=^config |\Z)', kernel)
    require(block is not None and 'depends on !ARM64' not in block[1], 'ARM64_EFFECTIVE_AFFINITY_STILL_BLOCKED')
    chips = (source / FILES[0]).read_text()
    for name in ('ARM_GIC', 'ARM_GIC_V3'):
        block = re.search(r'(?ms)^config ' + name + r'\n(.*?)(?=^config |\Z)', chips)
        require(block is not None and block[1].count('select GENERIC_IRQ_EFFECTIVE_AFF_MASK') == 1,
                'GIC_EFFECTIVE_AFFINITY_SELECTION_MISSING:' + name)
    require(gpio_fixed(source), 'UPSTREAM_GPIO_FIX_MISSING')


def prepared(source):
    source = Path(source).resolve(strict=True)
    for name in FILES:
        p = source / name
        require(p.is_file() and not p.is_symlink()
                and all(not parent.is_symlink() for parent in p.parents if parent.is_relative_to(source)),
                'R18_SOURCE_NOT_REGULAR:' + name)
    with tempfile.TemporaryDirectory(prefix='r18-source-prepare-') as tmp:
        stage = Path(tmp)
        for name in FILES:
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, stage / name)
        already_fixed = gpio_fixed(stage)
        operations = [(['-R'], ROOT / 'References/REVERSE_DISABLE_COMMIT.patch')]
        if not already_fixed:
            operations.append(([], ROOT / 'References/UPSTREAM_GPIO_FIX.patch'))
        for direction, patch in operations:
            for flags in (['--check'], []):
                r = subprocess.run(['git', 'apply', '--whitespace=error', *direction, *flags, str(patch)],
                                   cwd=stage, text=True, capture_output=True)
                require(r.returncode == 0, 'R18_EXACT_CONTEXT_PATCH_FAILED:' + r.stderr)
        validate_postimage(stage)
        return {n: (stage / n).read_bytes() for n in FILES}, already_fixed


def check_source(source):
    _, present = prepared(source)
    return {'files_checked': 3, 'source_changed': False, 'upstream_GPIO_fix_already_present': present}


def apply_source(source):
    source = Path(source).resolve(strict=True)
    data, present = prepared(source)
    for name, content in data.items():
        (source / name).write_bytes(content)
    validate_postimage(source)
    return {'source_hashes': {name: sha(source / name) for name in FILES},
            'complete_disable_commit_reversed': profile()['reverse_disable_commit'],
            'complete_upstream_GPIO_fix': profile()['upstream_gpio_fix'],
            'GPIO_fix_already_present': present, 'vendor_parent_guards_preserved': True}


def audit_handlers(source):
    source = Path(source)
    validate_postimage(source)
    checks = {
        'parent_and_child_share_irq_common_data': ('kernel/irq/irqdomain.c', 'irq_data->common = child->common;'),
        'GICv2_updates_effective_mask': ('drivers/irqchip/irq-gic.c', 'irq_data_update_effective_affinity('),
        'GICv3_updates_effective_mask': ('drivers/irqchip/irq-gic-v3.c', 'irq_data_update_effective_affinity('),
        'ITS_updates_effective_mask': ('drivers/irqchip/irq-gic-v3-its.c', 'irq_data_update_effective_affinity('),
        'MPM_delegates_to_parent_data': ('drivers/irqchip/qcom-mpm.c', 'data = data->parent_data;'),
        'generic_core_initializes_effective_mask': ('kernel/irq/manage.c', 'irq_init_effective_affinity('),
    }
    for label, (name, text) in checks.items():
        require(text in (source / name).read_text(), 'IRQ_HANDLER_SOURCE_CONTRACT_CHANGED:' + label)
    return {'source_contracts_checked': list(checks), 'GPIO_unsupported_paths_return_EINVAL': True,
            'device_interrupt_routing_tested': False}


def verify_config(before, after, r17):
    require(after.get(FLAG) == 'y', 'STOCK_EFFECTIVE_AFFINITY_NOT_ENABLED')
    filtered = dict(after)
    del filtered[FLAG]
    r17.verify_config_values(filtered)
    return filtered


def verify_abi(actual, expected):
    p = profile()
    matches = {n for n, crc in expected.items() if actual.get(n) == crc}
    previous = set(p['previous_matches'])
    require(not previous - matches, 'PREVIOUS_1304_STOCK_MATCH_LOST:' + repr(sorted(previous - matches)))
    require(not expected.keys() - actual.keys(), 'ORIGINAL_IMPORT_MISSING')
    require(set(p['required_gains']) <= matches - previous, 'LOCAL_104_GAINS_NOT_CONFIRMED')
    require(actual.get('module_layout') == '0x945d02f2', 'STOCK_MODULE_LAYOUT_LOST')
    return {'baseline_matches': 1304, 'gained_matching_symbols': sorted(matches - previous),
            'lost_matching_symbols': [], 'all_104_local_gains_confirmed': True,
            'counts': {'MATCH': len(matches), 'CRC_MISMATCH': len(expected) - len(matches), 'NOT_EXPORTED': 0}}


def load_r17(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['r17_tool_sha256'], 'AUTHENTIC_R17_EXTENSION_CHANGED')
    spec = importlib.util.spec_from_file_location('r18_authenticated_r17', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def build(args):
    verify_package()
    r17 = load_r17(args.r17_tool)
    base = r17.load_base(args.base_tool)
    check_source(args.source)
    original_apply, original_config, original_abi = base.apply_source, base.verify_config, base.verify_abi
    result = {'status': 'R18_BUILD_PENDING', 'baseline_run': 43432555852,
              'kernel_compiled': False, 'flash_allowed': False, 'device_boot_tested': False}

    def source_extended(source):
        old = original_apply(source)
        result['R17_stock_DMA_alignment'] = r17.apply_cache(source)
        result['irq_source'] = apply_source(source)
        result['irq_handler_audit'] = audit_handlers(source)
        return {'unchanged_R16_port': old, 'R17_DMA': result['R17_stock_DMA_alignment'], 'R18_IRQ': result['irq_source']}

    def config_extended(before, after):
        filtered = verify_config(before, after, r17)
        delta = original_config(before, filtered)
        result['config_delta_against_green_R17'] = {FLAG: [None, 'y']}
        return dict(delta, **{FLAG: [None, 'y']})

    def abi_extended(actual, reference, expected):
        old = original_abi(actual, reference, expected)
        result['R17_crypto_progress_preserved'] = r17.verify_current_abi(actual, expected)
        result['abi_progress'] = verify_abi(actual, expected)
        return dict(old, R18_progress=result['abi_progress'])

    base.apply_source, base.verify_config, base.verify_abi = source_extended, config_extended, abi_extended
    output = Path(args.output).resolve()
    try:
        base.build(args)
        report = json.loads((output / 'R16_RESULT.json').read_text())
        require(report['kernel_compiled'] and report['r6_baseline_unchanged'], 'FULL_BUILD_NOT_PROVEN')
        require(result['abi_progress']['counts'] == report['qgki_counts'], 'ABI_REPORT_DISAGREEMENT')
        for name, digest in result['irq_source']['source_hashes'].items():
            require(sha(output / 'candidate-source' / name) == digest, 'IRQ_SOURCE_CHANGED_DURING_BUILD:' + name)
        require(sha(output / 'candidate-source/arch/arm64/include/asm/cache.h')
                == result['R17_stock_DMA_alignment']['header_sha256'], 'R17_STOCK_DMA_REPAIR_CHANGED')
        result.update(status='R18_FULL_ARM64_BUILD_AND_STOCK_IRQ_AFFINITY_PROGRESS_PROVEN_NOFLASH',
                      kernel_compiled=True, qgki_counts=report['qgki_counts'],
                      fully_matching_modules=report['fully_matching_modules'],
                      kernel_product_hashes=report['kernel_product_hashes'], r6_baseline_unchanged=True)
    except Exception as error:
        result.update(status='R18_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        if output.is_dir():
            (output / 'R18_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    bp = sub.add_parser('build')
    for name in ('r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        bp.add_argument('--' + name, required=True)
    args = parser.parse_args()
    verify_package()
    if args.operation == 'build':
        build(args)
    elif args.operation == 'check-source':
        print(json.dumps(check_source(args.source), sort_keys=True))
    else:
        print('R18_FULL_IRQ_COMMIT_AND_UPSTREAM_GPIO_FIX_AUTHENTICATED; KERNEL_NOT_BUILT; FLASH=NO')


if __name__ == '__main__':
    main()
