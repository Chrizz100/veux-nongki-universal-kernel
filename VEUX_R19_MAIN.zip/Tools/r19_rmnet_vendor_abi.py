#!/usr/bin/env python3
"""Restore the four-argument vendor API while retaining Qualcomm's corrected API."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
CORE = 'techpack/datarmnet/core/rmnet_descriptor.c'
HEADER = 'techpack/datarmnet/core/rmnet_descriptor.h'
OFFLOAD = 'techpack/datarmnet-ext/offload/rmnet_offload_main.c'
FILES = (CORE, HEADER, OFFLOAD)
LEGACY = 'rmnet_frag_ipv6_skip_exthdr'
MODERN = LEGACY + '_v2'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def profile():
    p = json.loads((ROOT / 'References/PROFILE.json').read_text())
    require(len(set(p['previous_matches'])) == 1419 and set(p['source_pins']) == set(FILES),
            'R19_PROFILE_CHANGED')
    return p


def verify_package():
    listed = set()
    for row in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = row.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in listed,
                'UNSAFE_R19_MANIFEST')
        require(not (ROOT / p).is_symlink() and sha(ROOT / p) == digest,
                'R19_PACKAGE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == listed, 'R19_MANIFEST_SCOPE_CHANGED')
    profile()


def function(text, name):
    m = re.search(r'(?m)^int ' + re.escape(name) + r'\(', text)
    require(m is not None, 'RMNET_FUNCTION_MISSING:' + name)
    end = re.search(r'(?m)^}', text[m.start():])
    require(end is not None, 'RMNET_FUNCTION_UNCLOSED:' + name)
    return text[m.start():m.start() + end.end()]


def functional_checks(source):
    source = Path(source)
    c = (source / CORE).read_text()
    before = (ROOT / 'Original' / CORE).read_text()
    require(function(c, MODERN).replace(MODERN, LEGACY) == function(before, LEGACY),
            'QUALCOMM_IPV6_IMPLEMENTATION_CHANGED')
    for name in (CORE, OFFLOAD):
        old = (ROOT / 'Original' / name).read_text()
        if name == CORE:
            # Remove only the new legacy wrapper and reverse the symbol rename.
            start = c.index('\n\n/* Preserve the four-argument vendor ABI.')
            end = c.index('EXPORT_SYMBOL(' + LEGACY + ');', start) + len('EXPORT_SYMBOL(' + LEGACY + ');')
            require((c[:start] + c[end:]).replace(MODERN, LEGACY) == old,
                    'RMNET_CHECKSUM_OR_ATOMIC_FRAGMENT_FIX_CHANGED')
        else:
            require((source / name).read_text().replace(MODERN, LEGACY) == old,
                    'OFFLOAD_FRAGMENT_FALLBACK_CHANGED')
    body = function(c, LEGACY)
    require(body.count('bool frag_hdr;') == 1 and body.count('frag_offp, &frag_hdr);') == 1,
            'LEGACY_API_REQUIRES_CALLER_FIFTH_ARGUMENT')
    require('bool *' not in body.split('{', 1)[0], 'LEGACY_API_NOT_FOUR_ARGUMENTS')
    require(c.count('EXPORT_SYMBOL(' + LEGACY + ');') == 1
            and c.count('EXPORT_SYMBOL(' + MODERN + ');') == 1, 'RMNET_REAL_EXPORT_MISSING')
    return {'original_four_argument_API': True, 'modern_five_argument_API': MODERN,
            'upstream_implementation_unchanged': True, 'atomic_fragment_callers_preserved': True,
            'checksum_logic_unchanged': True, 'crcs_overridden': False}


def audit_callers(source, patched):
    source = Path(source)
    found = {}
    pattern = re.compile(r'\b(?:' + LEGACY + '|' + MODERN + r')\s*\(')
    for root in ('techpack/datarmnet', 'techpack/datarmnet-ext'):
        for p in (source / root).rglob('*'):
            if not p.is_file() or p.suffix not in ('.c', '.h'):
                continue
            text = p.read_text(errors='replace')
            if pattern.search(text):
                found[str(p.relative_to(source))] = [len(re.findall(r'\b' + n + r'\s*\(', text))
                                                    for n in (LEGACY, MODERN)]
    expected = {CORE: [1, 4], HEADER: [1, 1], OFFLOAD: [0, 2]} if patched else {
        CORE: [3, 0], HEADER: [1, 0], OFFLOAD: [2, 0]}
    require(found == expected, 'UNEXPECTED_RMNET_API_CONSUMER:' + repr(found))
    return {'audited_API_files': found, 'unconverted_five_argument_callers': []}


def prepared(source):
    source = Path(source).resolve(strict=True)
    pins = profile()['source_pins']
    for name in FILES:
        p = source / name
        require(p.is_file() and not p.is_symlink()
                and all(not x.is_symlink() for x in p.parents if x.is_relative_to(source)),
                'R19_SOURCE_NOT_REGULAR:' + name)
        require(sha(p) == pins[name]['before_sha256'], 'R19_PREIMAGE_DRIFT:' + name)
    audit_callers(source, False)
    with tempfile.TemporaryDirectory(prefix='r19-rmnet-prepare-') as tmp:
        stage = Path(tmp)
        for name in FILES:
            (stage / name).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source / name, stage / name)
        for flags in (['--check'], []):
            r = subprocess.run(['git', 'apply', '--whitespace=error', *flags,
                                str(ROOT / 'References/RMNET_VENDOR_ABI.patch')],
                               cwd=stage, text=True, capture_output=True)
            require(r.returncode == 0, 'R19_EXACT_CONTEXT_PATCH_FAILED:' + r.stderr)
        for name in FILES:
            require(sha(stage / name) == pins[name]['after_sha256'], 'R19_POSTIMAGE_DRIFT:' + name)
        functional_checks(stage)
        audit_callers(stage, True)
        return {name: (stage / name).read_bytes() for name in FILES}


def check_source(source):
    prepared(source)
    return {'files_checked': 3, 'source_changed': False, 'all_five_argument_callers_accounted_for': True}


def apply_source(source):
    source = Path(source).resolve(strict=True)
    data = prepared(source)
    for name, content in data.items():
        (source / name).write_bytes(content)
    return dict(functional_checks(source), **audit_callers(source, True),
                source_hashes={n: sha(source / n) for n in FILES})


def verify_abi(actual, expected):
    matches = {n for n, crc in expected.items() if actual.get(n) == crc}
    previous = set(profile()['previous_matches'])
    require(previous <= matches, 'PREVIOUS_1419_STOCK_MATCH_LOST:' + repr(sorted(previous - matches)))
    require(expected.keys() <= actual.keys(), 'ORIGINAL_VENDOR_IMPORT_MISSING')
    require(actual.get(LEGACY) == expected[LEGACY] == '0x92d7c00c', 'RMNET_STOCK_API_CRC_NOT_RESTORED')
    require(MODERN in actual, 'MODERN_FRAGMENT_AWARE_EXPORT_NOT_BUILT')
    require(actual.get('module_layout') == '0x945d02f2', 'STOCK_MODULE_LAYOUT_LOST')
    return {'baseline_matches': 1419, 'gained_matching_symbols': sorted(matches - previous),
            'lost_matching_symbols': [], 'counts': {'MATCH': len(matches),
            'CRC_MISMATCH': len(expected) - len(matches), 'NOT_EXPORTED': 0}}


def load_r18(path):
    path = Path(path).resolve(strict=True)
    require(sha(path) == profile()['r18_tool_sha256'], 'AUTHENTIC_R18_ENGINE_CHANGED')
    spec = importlib.util.spec_from_file_location('r19_authentic_r18', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.verify_package()
    return module


def build(args):
    verify_package()
    r18 = load_r18(args.r18_tool)
    check_source(args.source)
    original_source, original_abi = r18.apply_source, r18.verify_abi
    result = {'status': 'R19_BUILD_PENDING', 'baseline_run': 43454069717,
              'kernel_compiled': False, 'device_boot_tested': False, 'flash_allowed': False}

    def source_extended(source):
        old = original_source(source)
        result['rmnet_source'] = apply_source(source)
        return old

    def abi_extended(actual, expected):
        old = original_abi(actual, expected)
        result['abi_progress'] = verify_abi(actual, expected)
        return old

    r18.apply_source, r18.verify_abi = source_extended, abi_extended
    out = Path(args.output).resolve()
    try:
        r18.build(args)
        report = json.loads((out / 'R18_RESULT.json').read_text())
        require(report['kernel_compiled'] and report['r6_baseline_unchanged'], 'FULL_BUILD_NOT_PROVEN')
        require(result['abi_progress']['counts'] == report['qgki_counts'], 'ABI_REPORT_DISAGREEMENT')
        require(report['fully_matching_modules'] >= 36, 'RMNET_MODULE_CRC_NOT_FULLY_MATCHING')
        require(sha(out / 'candidate-out/.config') == profile()['config_sha256'], 'GREEN_R18_CONFIG_CHANGED')
        for name, digest in result['rmnet_source']['source_hashes'].items():
            require(sha(out / 'candidate-source' / name) == digest, 'R19_SOURCE_CHANGED_DURING_BUILD:' + name)
        system = (out / 'candidate-out/System.map').read_text()
        for name in (LEGACY, MODERN):
            require(re.search(r'(?m)^[0-9a-f]+\s+[Tt]\s+' + name + r'(?:\.cfi_jt)?$', system),
                    'RMNET_IMPLEMENTATION_NOT_LINKED:' + name)
        result.update(status='R19_FULL_ARM64_BUILD_AND_RMNET_VENDOR_API_PROGRESS_PROVEN_NOFLASH',
                      kernel_compiled=True, qgki_counts=report['qgki_counts'],
                      fully_matching_modules=report['fully_matching_modules'],
                      kernel_product_hashes=report['kernel_product_hashes'],
                      config_unchanged_against_green_R18=True, r6_baseline_unchanged=True)
    except Exception as error:
        result.update(status='R19_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        r18.apply_source, r18.verify_abi = original_source, original_abi
        if out.is_dir():
            (out / 'R19_RESULT.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(result['status'], result['qgki_counts'], 'FLASH=NO')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    sub.add_parser('check-source').add_argument('--source', required=True)
    b = sub.add_parser('build')
    for n in ('r18-tool', 'r17-tool', 'base-tool', 'source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        b.add_argument('--' + n, required=True)
    args = p.parse_args()
    verify_package()
    if args.operation == 'build':
        build(args)
    elif args.operation == 'check-source':
        print(json.dumps(check_source(args.source), sort_keys=True))
    else:
        print('R19_RMNET_VENDOR_API_PACKAGE_VERIFIED; FULL_KERNEL_NOT_BUILT; FLASH=NO')


if __name__ == '__main__':
    main()
