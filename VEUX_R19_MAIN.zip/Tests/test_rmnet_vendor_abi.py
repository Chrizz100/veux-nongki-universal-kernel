import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('r19_tests', ROOT / 'Tools/r19_rmnet_vendor_abi.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)


class RmnetVendorApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original', self.source)

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self):
        return {n: (self.source / n).read_bytes() for n in r.FILES}

    def test_complete_source_conversion_and_ipv6_fix_preservation(self):
        result = r.apply_source(self.source)
        self.assertTrue(result['upstream_implementation_unchanged'])
        self.assertTrue(result['atomic_fragment_callers_preserved'])
        for n in r.FILES:
            self.assertEqual((self.source / n).read_bytes(), (ROOT / 'Candidate' / n).read_bytes())

    def test_preflight_does_not_mutate_the_green_source(self):
        before = self.snapshot()
        self.assertFalse(r.check_source(self.source)['source_changed'])
        self.assertEqual(before, self.snapshot())

    def test_last_file_drift_prevents_every_write(self):
        p = self.source / r.OFFLOAD
        p.write_text(p.read_text() + '\n/* unexpected edit */\n')
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
            r.apply_source(self.source)
        self.assertEqual(before, self.snapshot())

    def test_unlisted_consumer_is_caught_before_any_write(self):
        (self.source / 'techpack/datarmnet/core/extra.c').write_text(r.LEGACY + '(a,b,c,d,e);\n')
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'UNEXPECTED_RMNET_API_CONSUMER'):
            r.apply_source(self.source)
        self.assertEqual(before, self.snapshot())

    def test_symlink_and_reapplication_cannot_replace_source(self):
        p = self.source / r.HEADER
        outside = Path(self.temp.name) / 'outside'
        outside.write_bytes(p.read_bytes())
        p.unlink()
        p.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'SOURCE_NOT_REGULAR'):
            r.apply_source(self.source)
        p.unlink()
        shutil.copyfile(ROOT / 'Original' / r.HEADER, p)
        r.apply_source(self.source)
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
            r.apply_source(self.source)
        self.assertEqual(before, self.snapshot())

    def expected(self):
        r18 = r.load_r18(os.environ['R19_R18_TOOL'])
        r17 = r18.load_r17(os.environ['R18_R17_TOOL'])
        base = r17.load_base(os.environ['R18_BASE_TOOL'])
        h = base.dependency().dependency().dependency()[2]
        expected, _ = h.references()
        previous = set(r.profile()['previous_matches'])
        actual = {n: crc if n in previous else '0x00000000' for n, crc in expected.items()}
        actual[r.LEGACY] = expected[r.LEGACY]
        actual[r.MODERN] = '0x0e7aae8c'
        return actual, expected

    def test_real_rmnet_gain_is_mandatory_and_1419_matches_are_preserved(self):
        actual, expected = self.expected()
        self.assertEqual(r.verify_abi(actual, expected)['counts'],
                         {'MATCH': 1420, 'CRC_MISMATCH': 3, 'NOT_EXPORTED': 0})
        actual[r.LEGACY] = '0x05bbf7c9'
        with self.assertRaisesRegex(ValueError, 'RMNET_STOCK_API_CRC_NOT_RESTORED'):
            r.verify_abi(actual, expected)

    def test_old_match_loss_missing_import_or_missing_modern_api_is_fatal(self):
        actual, expected = self.expected()
        n = r.profile()['previous_matches'][0]
        crc = actual[n]
        actual[n] = '0x00000000'
        with self.assertRaisesRegex(ValueError, '1419_STOCK_MATCH_LOST'):
            r.verify_abi(actual, expected)
        actual[n] = crc
        n = 'wake_up_process'
        del actual[n]
        with self.assertRaisesRegex(ValueError, 'ORIGINAL_VENDOR_IMPORT_MISSING'):
            r.verify_abi(actual, expected)
        actual[n] = '0x00000000'
        del actual[r.MODERN]
        with self.assertRaisesRegex(ValueError, 'MODERN_FRAGMENT_AWARE_EXPORT_NOT_BUILT'):
            r.verify_abi(actual, expected)

    def test_actual_c_apis_handle_fragment_headers_errors_and_four_argument_callers(self):
        prefix = r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <errno.h>
#include <arpa/inet.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef uint16_t __be16;
#define NEXTHDR_NONE 59
#define NEXTHDR_FRAGMENT 44
#define NEXTHDR_AUTH 51
struct ipv6_opt_hdr { u8 nexthdr; u8 hdrlen; };
struct frag_hdr { u8 nexthdr; u8 reserved; __be16 frag_off; uint32_t identification; };
struct rmnet_frag_descriptor { u8 bytes[160]; u32 length; u32 split; };
static bool ipv6_ext_hdr(u8 n) { return n==0 || n==43 || n==44 || n==51 || n==59 || n==60; }
#define ipv6_optlen(hp) (((hp)->hdrlen+1)<<3)
static void *rmnet_frag_header_ptr(struct rmnet_frag_descriptor *d, u32 off, u32 len, void *buf)
{
 if(off>d->length || len>d->length-off) return NULL;
 if(off<d->split && off+len>d->split) { memcpy(buf,d->bytes+off,len); return buf; }
 return d->bytes+off;
}
'''
        old = r.function((ROOT / 'Original' / r.CORE).read_text(), r.LEGACY).replace(r.LEGACY, 'upstream')
        text = (ROOT / 'Candidate' / r.CORE).read_text()
        modern = r.function(text, r.MODERN)
        legacy = r.function(text, r.LEGACY)
        suffix = r'''
static void compare(struct rmnet_frag_descriptor *d,int start,u8 nexthdr)
{
 u8 n1=nexthdr,n2=nexthdr,n3=nexthdr;
 __be16 f1=htons(0xa55a),f2=f1;
 struct { uint64_t before; __be16 frag; uint64_t after; } guarded;
 bool h1=true,h2=false;
 guarded.before=0x1122334455667788ULL;guarded.after=0xaabbccddeeff0011ULL;guarded.frag=f1;
 int a=upstream(d,start,&n1,&f1,&h1);
 int b=rmnet_frag_ipv6_skip_exthdr_v2(d,start,&n2,&f2,&h2);
 int c=rmnet_frag_ipv6_skip_exthdr(d,start,&n3,&guarded.frag);
 assert(a==b && a==c && n1==n2 && n1==n3 && f1==f2 && f1==guarded.frag && h1==h2);
 assert(guarded.before==0x1122334455667788ULL && guarded.after==0xaabbccddeeff0011ULL);
}
int main(void)
{
 struct rmnet_frag_descriptor d={.length=160,.split=43};
 u8 n;__be16 f;bool h;
 n=17;assert(rmnet_frag_ipv6_skip_exthdr(&d,40,&n,&f)==40 && f==0 && n==17);
 d.bytes[40]=17;d.bytes[41]=0;
 n=0;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==48 && !h && n==17);
 n=44;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==48 && h && f==0);
 d.bytes[43]=1;n=44;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==48 && h && ntohs(f)==1);
 d.bytes[43]=8;n=44;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==40 && h && n==44 && ntohs(f)==8);
 n=59;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==-EINVAL && !h);
 d.length=41;n=44;assert(rmnet_frag_ipv6_skip_exthdr_v2(&d,40,&n,&f,&h)==-EINVAL);
 d.length=160;
 for(int split=0;split<160;split++) {
  d.split=split;
  for(int i=0;i<160;i++) d.bytes[i]=(u8)(i*37+split);
  for(int n=0;n<256;n++) { compare(&d,40,(u8)n);compare(&d,159,(u8)n); }
  compare(&d,-1,44);
 }
 return 0;
}
'''
        path = Path(self.temp.name) / 'actual_api.c'
        path.write_text(prefix + old + '\n' + modern + '\n' + legacy + suffix)
        exe = path.with_suffix('')
        compile = subprocess.run(['cc', '-std=c11', '-O1', '-Wall', '-Wextra', '-Werror',
                                  '-fsanitize=address,undefined', '-fno-omit-frame-pointer',
                                  str(path), '-o', str(exe)], text=True, capture_output=True)
        self.assertEqual(compile.returncode, 0, compile.stderr)
        # This stack-only harness needs bounds/UB checks; LeakSanitizer cannot
        # inspect threads in the sandbox's traced process environment.
        env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0:halt_on_error=1',
                   UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        run = subprocess.run([str(exe)], text=True, capture_output=True, env=env)
        self.assertEqual(run.returncode, 0, run.stderr)


if __name__ == '__main__':
    unittest.main()
