set -euo pipefail
python3 -B "$R25_DIR/Tools/r25_tzlog.py" build \
  --r24-tool "$R24_DIR/Tools/r24_memory.py" \
  --r23-tool "$R23_DIR/Tools/r23_fingerprint.py" \
  --r21-tool "$R21_SCHED_DIR/Tools/r21_scheduler_release.py" \
  --r19-tool "$R19_RMNET_DIR/Tools/r19_rmnet_vendor_abi.py" \
  --r18-tool "$R18_IRQ_DIR/Tools/r18_irq_affinity.py" \
  --r17-tool "$R17_CACHE_DIR/Tools/r17_cache_alignment.py" \
  --base-tool "$R16_REPAIR_DIR/Tools/restore_memory_network.py" \
  --source "$R9_SNAPSHOT" --objout "$R13_OBJOUT" \
  --r6-report "$R47_REPORT_DIR/R47_RESULT.json" \
  --r6-tool "$R47_TOOLS_DIR/Tools/veux_r47_r13_on_r46.py" \
  --project "$GITHUB_WORKSPACE/project" --output "$R16_REPAIR_OUTPUT"
