import argparse,contextlib,hashlib,importlib.util,io,json,lzma,os
from pathlib import Path
import shutil,subprocess,sys,tempfile,textwrap,unittest
from unittest.mock import patch
from native_tzlog import compile_harness,CASES
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r25_tested',ROOT/'Tools/r25_tzlog.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def baseline():return m.config_values(lzma.decompress((ROOT/'References/R24.config.xz').read_bytes()).decode())
def enabled():return dict(baseline(),CONFIG_QTI_TZ_LOG='y')
def fixture(path):
    shutil.copytree(ROOT/'Before',path,dirs_exist_ok=True)
    d=path/m.profile()['device_tree_path'];d.parent.mkdir(parents=True,exist_ok=True)
    d.write_bytes((ROOT/'References/HOLI_TZLOG_NODE.dts').read_bytes())
    (path/'scripts').mkdir(exist_ok=True);shutil.copyfile(ROOT/'References/scripts_config',path/'scripts/config')

class TrustZoneTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        cls.binaries=[compile_harness(ROOT,Path(cls.temp.name),debug)for debug in [False,True]]
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def native(self,names):
        for b in self.binaries:
            for case in names:
                with self.subTest(binary=b.name,case=case):
                    p=subprocess.run([str(b),case],capture_output=True,text=True,timeout=5)
                    self.assertEqual(p.returncode,0,p.stdout+p.stderr)
    def test_native_qsee_allocation_registration_and_error_cleanup(self):self.native(CASES[:6])
    def test_native_encrypted_allocation_partial_failures_and_double_cleanup(self):self.native(CASES[6:12])
    def test_native_procfs_both_children_and_partial_failure_cleanup(self):self.native(CASES[12:16])
    def test_native_optional_debugfs_error_pointers(self):self.native(CASES[16:18])
    def test_native_probe_remove_full_success_and_failure_lifetimes(self):self.native(CASES[18:26])
    def test_native_proc_read_forwards_the_correct_private_log_id(self):self.native(['proc-read'])

    def test_real_r24_fixture_and_only_one_new_option(self):
        data=lzma.decompress((ROOT/'References/R24.config.xz').read_bytes())
        self.assertEqual(hashlib.sha256(data).hexdigest(),m.profile()['baseline_config_sha256'])
        self.assertEqual(m.normalize_logger(enabled()),baseline())
        self.assertNotIn(m.FLAG,baseline());self.assertEqual(baseline()['CONFIG_DEBUG_FS'],'n')
        for value in [None,'n','m']:
            d=enabled()
            if value is None:del d[m.FLAG]
            else:d[m.FLAG]=value
            with self.subTest(value=value),self.assertRaises(ValueError):m.normalize_logger(d)

    def test_stock_disabled_debugfs_and_procfs_contract_cannot_change(self):
        for key,value in [('CONFIG_DEBUG_FS','y'),('CONFIG_PROC_FS','n')]:
            d=enabled();d[key]=value
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'PROCFS_AND_DISABLED'):m.normalize_logger(d)

    def test_memory_fingerprint_cfi_release_and_other_flags_cannot_regress(self):
        for key,value in [('CONFIG_RTMM','n'),('CONFIG_PROCESS_RECLAIM','n'),('CONFIG_FINGERPRINT_FPC','n'),
                          ('CONFIG_CFI_CLANG','n'),('CONFIG_SCHED_WALT','n'),('CONFIG_LOCALVERSION','"-Positron"')]:
            d=enabled();d[key]=value
            with self.subTest(key=key),self.assertRaisesRegex(ValueError,'OUTSIDE_ONE'):m.normalize_logger(d)

    def test_complete_preflight_and_only_two_changed_files(self):
        with tempfile.TemporaryDirectory()as temp:
            source=Path(temp);fixture(source)
            old=m.source_check(source);new=m.apply_source(source)
            changed={n for n in old['source_hashes']if old['source_hashes'][n]!=new['source_hashes'][n]}
            self.assertEqual(changed,{'drivers/firmware/qcom/tz_log.c','drivers/firmware/qcom/Kconfig'})
            self.assertEqual(new,m.source_check(source,after=True))
            self.assertIn('depends on PROC_FS',(source/'drivers/firmware/qcom/Kconfig').read_text())
            self.assertNotIn('depends on DEBUG_FS',(source/'drivers/firmware/qcom/Kconfig').read_text())
            with self.assertRaises(ValueError):m.apply_source(source)

    def test_last_source_or_device_tree_drift_prevents_any_write(self):
        for victim in ['drivers/firmware/qcom/tz_log.c',m.profile()['device_tree_path']]:
            with self.subTest(victim=victim),tempfile.TemporaryDirectory()as temp:
                source=Path(temp);fixture(source);p=source/victim
                if victim.endswith('.dtsi'):p.write_text(p.read_text().replace('0xc125720','0x12345678'))
                else:p.write_text(p.read_text()+'\n/* drift */\n')
                before={str(p.relative_to(source)):m.sha(p)for p in source.rglob('*')if p.is_file()}
                with self.assertRaises(ValueError):m.apply_source(source)
                self.assertEqual(before,{str(p.relative_to(source)):m.sha(p)for p in source.rglob('*')if p.is_file()})

    def test_source_symlink_rejected(self):
        with tempfile.TemporaryDirectory()as temp:
            source=Path(temp)/'source';source.mkdir();fixture(source);p=source/'drivers/firmware/qcom/tz_log.c'
            other=Path(temp)/'other.c';p.rename(other);p.symlink_to(other)
            with self.assertRaisesRegex(ValueError,'NOT_REGULAR'):m.apply_source(source)

    def test_real_config_tool_requests_one_key_and_preserves_debugfs(self):
        with tempfile.TemporaryDirectory()as temp:
            source=Path(temp);fixture(source);cfg=source/'.config';cfg.write_bytes(lzma.decompress((ROOT/'References/R24.config.xz').read_bytes()))
            m.request_logger(source,cfg);self.assertEqual(m.config_values(cfg.read_text()),enabled())

    def test_genuine_r24_normalizer_contract_and_failure_cannot_claim_green(self):
        parent_root=Path(os.environ.get('R24_DIR',str(ROOT.parent/'r24-main')))
        parent=m.load_parent(parent_root/'Tools/r24_memory.py')
        original_request,original_normalize=parent.request_memory,parent.normalize_memory
        with tempfile.TemporaryDirectory()as temp:
            source=Path(temp)/'source';source.mkdir();fixture(source)
            out=Path(temp)/'result';out.mkdir();cfg=out/'.config';cfg.write_bytes(lzma.decompress((ROOT/'References/R24.config.xz').read_bytes()))
            def stop(args):
                parent.request_memory(source,cfg)
                values=parent.normalize_memory(m.config_values(cfg.read_text()))
                self.assertNotIn(m.FLAG,values);self.assertNotIn('CONFIG_RTMM',values)
                m.source_check(source,after=True);raise RuntimeError('TEST_STOPS_BEFORE_KERNEL_COMPILATION')
            with patch.object(m,'load_parent',return_value=parent),patch.object(parent,'build',side_effect=stop):
                with self.assertRaisesRegex(RuntimeError,'TEST_STOPS_BEFORE_KERNEL_COMPILATION'):
                    m.build(argparse.Namespace(source=str(source),output=str(out),r24_tool=str(parent_root/'Tools/r24_memory.py')))
            self.assertIs(parent.request_memory,original_request);self.assertIs(parent.normalize_memory,original_normalize)
            r=json.loads((out/'R25_RESULT.json').read_text());self.assertFalse(r['kernel_compiled']);self.assertFalse(r['flash_allowed'])

    def test_all_linked_interfaces_required_with_cfi_symbol_suffixes(self):
        lines=['ffffffc012000000 d __initcall_178_1708_tz_log_driver_init6',
               'ffffffc012000100 r qsee_log_dump_proc_fops',
               'ffffffc012000200 t tz_log_probe$123ab.cfi_jt']
        self.assertEqual(len(m.linked_proof('\n'.join(lines))),3)
        for i in range(3):
            with self.subTest(i=i),self.assertRaises(ValueError):m.linked_proof('\n'.join(lines[:i]+lines[i+1:]))

    def test_old_green_kernel_cannot_be_packaged_as_r25(self):
        with tempfile.TemporaryDirectory()as temp:
            (Path(temp)/'R25_RESULT.json').write_text(json.dumps({'status':'R24_FULL_MEMORY_PASS'}))
            with self.assertRaisesRegex(ValueError,'FRESH_R25_FULL_BUILD_REQUIRED'):m.verify_fresh(temp)

class WorkflowTests(unittest.TestCase):
    def command(self):
        expected=(ROOT/'References/R25_BUILD_COMMAND.sh').read_text()
        if 'R25_WORKFLOW'not in os.environ:return expected
        rows=Path(os.environ['R25_WORKFLOW']).read_text().splitlines();matches=[]
        for i,row in enumerate(rows):
            if not row.strip().startswith('run: |'):continue
            indent=len(row)-len(row.lstrip());body=[]
            for line in rows[i+1:]:
                if line.strip()and len(line)-len(line.lstrip())<=indent:break
                body.append(line)
            script=textwrap.dedent('\n'.join(body))+'\n'
            if 'python3 -B "$R25_DIR/Tools/r25_tzlog.py" build'in script:matches.append(script)
        self.assertEqual(matches,[expected]);return matches[0]
    def capture(self,body):
        with tempfile.TemporaryDirectory(prefix='r25 argv spaces ')as temp:
            root=Path(temp);b=root/'bin';b.mkdir();shim=b/'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$R25_CAPTURE"\n');shim.chmod(0o755)
            keys=['R24_DIR','R23_DIR','R21_SCHED_DIR','R19_RMNET_DIR','R18_IRQ_DIR','R17_CACHE_DIR','R16_REPAIR_DIR',
                  'R9_SNAPSHOT','R13_OBJOUT','R47_REPORT_DIR','R47_TOOLS_DIR','GITHUB_WORKSPACE','R16_REPAIR_OUTPUT']
            values={n:str(root/(n+' spaces'))for n in keys};values['R25_DIR']=str(ROOT)
            p=subprocess.run(['bash','-c',body],env=dict(os.environ,**values,PATH=str(b)+os.pathsep+os.environ['PATH'],R25_CAPTURE=str(root/'argv')),
                             capture_output=True,text=True,timeout=10)
            self.assertEqual(p.returncode,0,p.stderr);data=(root/'argv').read_bytes().split(b'\0');self.assertEqual(data.pop(),b'')
            return[x.decode()for x in data],values
    def test_delivered_bash_argv_reaches_real_parser_with_all_thirteen_paths(self):
        argv,env=self.capture(self.command());self.assertEqual(argv[:2],['-B',str(ROOT/'Tools/r25_tzlog.py')])
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'verify_package'),patch.object(m,'build')as build:m.main()
        expected={'op':'build'}
        for key,var,suffix in [('r24_tool','R24_DIR','/Tools/r24_memory.py'),('r23_tool','R23_DIR','/Tools/r23_fingerprint.py'),
            ('r21_tool','R21_SCHED_DIR','/Tools/r21_scheduler_release.py'),('r19_tool','R19_RMNET_DIR','/Tools/r19_rmnet_vendor_abi.py'),
            ('r18_tool','R18_IRQ_DIR','/Tools/r18_irq_affinity.py'),('r17_tool','R17_CACHE_DIR','/Tools/r17_cache_alignment.py'),
            ('base_tool','R16_REPAIR_DIR','/Tools/restore_memory_network.py'),('source','R9_SNAPSHOT',''),('objout','R13_OBJOUT',''),
            ('r6_report','R47_REPORT_DIR','/R47_RESULT.json'),('r6_tool','R47_TOOLS_DIR','/Tools/veux_r47_r13_on_r46.py'),
            ('project','GITHUB_WORKSPACE','/project'),('output','R16_REPAIR_OUTPUT','')]:expected[key]=env[var]+suffix
        self.assertEqual(vars(build.call_args.args[0]),expected)
    def test_stray_plus_is_rejected_before_build(self):
        argv,_=self.capture(self.command().replace(' build \\\n',' build \\\n  + \\\n',1))
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'build')as build,contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit)as error:m.main()
        self.assertEqual(error.exception.code,2);build.assert_not_called()

if __name__=='__main__':unittest.main()
