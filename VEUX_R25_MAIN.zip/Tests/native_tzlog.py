"""Run the actual patched allocation/probe/procfs functions with native host mocks."""
from pathlib import Path
import re,subprocess

def function(text,name):
    m=re.search(r'(?m)^.*\b'+name+r'\([^;]*?\)\n\{',text)
    if not m:raise ValueError(name)
    depth=1
    for i in range(m.end(),len(text)):
        depth+=(text[i]=='{')-(text[i]=='}')
        if not depth:return text[m.start():i+1]
    raise ValueError(name)

CASES=['qsee-success','qsee-bridge-fail','qsee-scm-fail','qsee-dma-fail','qsee-size-overflow','qsee-size-zero',
 'encrypted-success','encrypted-first-dma','encrypted-second-dma','encrypted-first-bridge','encrypted-second-bridge',
 'unencrypted-cleanup','proc-root-fail','proc-qsee-fail','proc-tz-fail','proc-success','debug-dir-fail','debug-file-fail',
 'probe-plain','probe-encrypted','probe-proc-fail','probe-encrypted-proc-fail','probe-feature-fail','probe-resource-fail',
 'probe-hyp-fail','probe-display-fail','proc-read']

def compile_harness(root,out,debugfs=False):
    text=(root/'After/drivers/firmware/qcom/tz_log.c').read_text()
    names=['tzdbg_register_qsee_log_buf','tzdbg_free_qsee_log_buf','tzdbg_allocate_encrypted_log_buf',
           'tzdbg_free_encrypted_log_buf','tzdbgfs_init','tzdbgfs_exit','tz_log_probe','tz_log_remove',
           'qsee_log_dump_procfs_read']
    code=PREFIX+'\n'+'\n\n'.join(function(text,n)for n in names)+'\n'+MAIN
    source=out/('actual_tzlog_'+str(int(debugfs))+'.c');source.write_text(code)
    binary=source.with_suffix('');args=['cc','-std=gnu11','-O1','-Wall','-Werror','-Wno-unused-function',
      '-Wno-unused-variable','-Wno-sign-compare','-fsanitize=undefined','-fno-sanitize-recover=all']
    if debugfs:args+=['-DCONFIG_DEBUG_FS=1']
    p=subprocess.run(args+[str(source),'-o',str(binary)],capture_output=True,text=True,timeout=30)
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
    return binary

PREFIX=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <errno.h>
#include <sys/types.h>
#define __iomem
#define __user
#define GFP_KERNEL 0
#define PAGE_SIZE 4096UL
#define VMID_HLOS 1
#define PERM_READ 1
#define PERM_WRITE 2
#define QSEOS_RESULT_SUCCESS 0
#define QSEE_LOG_BUF_SIZE 0x8000
#define QSEE_LOG_BUF_SIZE_V2 0x20000
#define TZDBG_STATS_MAX 9
#define TZDBG_QSEE_LOG 6
#define TZDBG_LOG 5
#define IORESOURCE_MEM 0
#define EPROBE_DEFER 517
#define pr_err(...) ((void)0)
#define pr_info(...) ((void)0)
#define pr_debug(...) ((void)0)
#define dev_err(...) ((void)0)
#define dev_info(...) ((void)0)
#define dev_dbg(...) ((void)0)
#define ERR_PTR(n) ((void*)(intptr_t)(n))
#define IS_ERR(p) ((uintptr_t)(p)>=(uintptr_t)-4095)
#define IS_ERR_OR_NULL(p) (!(p)||IS_ERR(p))
#define PTR_ERR(p) ((int)(intptr_t)(p))
typedef uintptr_t phys_addr_t;
struct device {void *of_node;};struct platform_device {struct device dev;void *data;};
struct resource {uintptr_t start;size_t size;};
struct tzdbg_t {int unused;};
struct tzdbg_log_t {struct {unsigned wrap,offset;} log_pos;};
struct tzdbg_log_v2_t {struct {unsigned wrap,offset;} log_pos;};
struct encrypted_log_info {void*vaddr;size_t size;uintptr_t paddr;uint64_t shmb_handle;};
static struct {bool is_enlarged_buf,is_encrypted_log_enabled,is_hyplog_enabled;void*virt_iobase;
 struct tzdbg_t*diag_buf;void*disp_buf;int debug_tz[TZDBG_STATS_MAX];struct{const char*name;}stat[TZDBG_STATS_MAX];}tzdbg;
static struct encrypted_log_info enc_qseelog_info,enc_tzlog_info;
static struct tzdbg_log_t*g_qsee_log;static struct tzdbg_log_v2_t*g_qsee_log_v2;
static unsigned qseelog_buf_size,debug_rw_buf_size=0x3000,display_buf_size;
static uintptr_t coh_pmem,disp_buf_paddr;static uint64_t qseelog_shmbridge_handle;
struct proc_dir_entry {int unused;};static struct proc_dir_entry proc_root,proc_child,*g_proc_dir;
struct dentry {int unused;};static struct dentry debug_root,debug_child;
static const int tzdbg_fops=0,qsee_log_dump_proc_fops=0;
static void*ptrs[16];static size_t sizes[16];static int live[16];static int dma_calls,dma_fail,bridge_calls,bridge_fail,bridge_live[16];
static int feature_error,scm_error,want_encrypted,missing_resource,hyp_error,hyp_requested,proc_calls,proc_fail,proc_live,proc_children;
static int debug_calls,debug_fail,debug_live,kmem_live;static unsigned forced_size=QSEE_LOG_BUF_SIZE_V2;
static void *dma_alloc_coherent(struct device*d,size_t size,uintptr_t*pa,int flags){(void)d;(void)flags;int n=++dma_calls;
 assert(n<16);if(n==dma_fail)return NULL;assert(size<1024*1024);ptrs[n]=calloc(1,size);assert(ptrs[n]);sizes[n]=size;live[n]=1;*pa=n;return ptrs[n];}
static void dma_free_coherent(struct device*d,size_t size,void*p,uintptr_t pa){(void)d;assert(p);assert(pa>0&&pa<16);
 assert(live[pa]&&ptrs[pa]==p&&sizes[pa]==size);live[pa]=0;free(p);}
static int qtee_shmbridge_register(uintptr_t pa,size_t size,uint32_t*v,uint32_t*perm,uint32_t n,uint32_t other,uint64_t*h){
 (void)pa;(void)size;(void)v;(void)perm;(void)n;(void)other;int id=++bridge_calls;if(id==bridge_fail)return -EACCES;*h=id;bridge_live[id]=1;return 0;}
static void qtee_shmbridge_deregister(uint64_t h){assert(h>0&&h<16&&bridge_live[h]);bridge_live[h]=0;}
static int of_property_read_u32(void*np,const char*name,unsigned*out){(void)np;(void)name;*out=forced_size;return 0;}
static bool of_property_read_bool(void*np,const char*name){(void)np;(void)name;return hyp_requested;}
static int qcom_scm_register_qsee_log_buf(uintptr_t p,unsigned s){(void)p;(void)s;return scm_error;}
static void*kzalloc(size_t n,int f){(void)f;kmem_live++;return calloc(1,n);}
static void kfree(void*p){assert(p&&kmem_live>0);kmem_live--;free(p);}
static int tzdbg_get_tz_version(void){return feature_error;}
static void tzdbg_query_encrypted_log(void){tzdbg.is_encrypted_log_enabled=want_encrypted;}
static struct resource resource={0xc125720,0x3000};
static struct resource *platform_get_resource(struct platform_device*p,int type,int index){(void)p;(void)type;(void)index;return missing_resource?NULL:&resource;}
static size_t resource_size(struct resource*r){return r->size;}
static void*devm_ioremap_nocache(struct device*d,uintptr_t addr,size_t size){(void)d;(void)addr;(void)size;return(void*)0x10000;}
static uint32_t readl_relaxed(void*p){(void)p;return 0x20000;}
static int __update_hypdbg_base(struct platform_device*p,void*b){(void)p;(void)b;return hyp_error;}
static void platform_set_drvdata(struct platform_device*p,void*d){p->data=d;}
static void*platform_get_drvdata(struct platform_device*p){return p->data;}
static struct dentry*debugfs_create_dir(const char*n,void*p){(void)n;(void)p;if(++debug_calls==debug_fail)return ERR_PTR(-ENODEV);debug_live=1;return &debug_root;}
static struct dentry*debugfs_create_file_unsafe(const char*n,int mode,struct dentry*d,int*data,const void*f){(void)n;(void)mode;(void)d;(void)data;(void)f;
 if(++debug_calls==debug_fail){return ERR_PTR(-ENOSPC);}
 return &debug_child;}
static void debugfs_remove_recursive(void*d){assert(d==&debug_root&&debug_live);debug_live=0;}
static struct proc_dir_entry*proc_mkdir(const char*n,void*p){(void)p;assert(!strcmp(n,"tzdbg"));if(++proc_calls==proc_fail)return NULL;proc_live=1;return &proc_root;}
static struct proc_dir_entry*proc_create_data(const char*n,int mode,struct proc_dir_entry*p,const void*ops,int*data){
 assert(p==&proc_root&&proc_live&&ops==&qsee_log_dump_proc_fops&&mode==0444);
 assert((!strcmp(n,"qsee_log")&&*data==TZDBG_QSEE_LOG)||(!strcmp(n,"tz_log")&&*data==TZDBG_LOG));
 if(++proc_calls==proc_fail){return NULL;}
 proc_children++;return &proc_child;}
static void proc_remove(struct proc_dir_entry*p){if(!p)return;assert(p==&proc_root&&proc_live);proc_live=0;proc_children=0;}
struct inode{void*data;};struct file{void*private_data;struct inode*inode;};
#define PDE_DATA(i) ((i)->data)
static struct inode*file_inode(struct file*f){return f->inode;}
static ssize_t tzdbgfs_read(struct file*f,char*b,size_t c,loff_t*o){(void)b;(void)o;assert(f->private_data==&tzdbg.debug_tz[3]);return c;}
'''

MAIN=r'''
static void empty(void){for(int i=0;i<16;i++)assert(!live[i]&&!bridge_live[i]);assert(!kmem_live&&!proc_live&&!proc_children&&!debug_live);}
int main(int argc,char**argv){assert(argc==2);const char*c=argv[1];struct platform_device p={.dev={.of_node=(void*)1}};
 int ret;qseelog_buf_size=QSEE_LOG_BUF_SIZE;
 if(!strncmp(c,"qsee-",5)){
  if(!strcmp(c,"qsee-bridge-fail"))bridge_fail=1;
  if(!strcmp(c,"qsee-scm-fail"))scm_error=-EPERM;
  if(!strcmp(c,"qsee-dma-fail"))dma_fail=1;
  if(!strcmp(c,"qsee-size-overflow")){tzdbg.is_enlarged_buf=1;forced_size=UINT_MAX;}
  if(!strcmp(c,"qsee-size-zero")){tzdbg.is_enlarged_buf=1;forced_size=0;}
  ret=tzdbg_register_qsee_log_buf(&p);
  if(!strcmp(c,"qsee-success")){assert(ret==0);tzdbg_free_qsee_log_buf(&p);tzdbg_free_qsee_log_buf(&p);}
  else if(bridge_fail)assert(ret==-EACCES);else if(scm_error)assert(ret==-EPERM);else if(dma_fail)assert(ret==-ENOMEM);else assert(ret==-EOVERFLOW);
  assert(!g_qsee_log&&!g_qsee_log_v2);empty();
 }else if(!strncmp(c,"encrypted-",10)){
  tzdbg.is_encrypted_log_enabled=1;
  if(!strcmp(c,"encrypted-first-dma"))dma_fail=1;
  if(!strcmp(c,"encrypted-second-dma"))dma_fail=2;
  if(!strcmp(c,"encrypted-first-bridge"))bridge_fail=1;
  if(!strcmp(c,"encrypted-second-bridge"))bridge_fail=2;
  ret=tzdbg_allocate_encrypted_log_buf(&p);
  if(!strcmp(c,"encrypted-success")){assert(ret==0);tzdbg_free_encrypted_log_buf(&p);tzdbg_free_encrypted_log_buf(&p);}
  else if(dma_fail)assert(ret==-ENOMEM);else assert(ret==-EACCES);
  assert(!enc_qseelog_info.vaddr&&!enc_tzlog_info.vaddr);empty();
 }else if(!strcmp(c,"unencrypted-cleanup")){assert(!tzdbg_allocate_encrypted_log_buf(&p));tzdbg_free_encrypted_log_buf(&p);empty();}
 else if(!strncmp(c,"proc-",5)&&strcmp(c,"proc-read")){
  if(!strcmp(c,"proc-root-fail"))proc_fail=1;
  if(!strcmp(c,"proc-qsee-fail"))proc_fail=2;
  if(!strcmp(c,"proc-tz-fail"))proc_fail=3;
  ret=tzdbgfs_init(&p);if(proc_fail)assert(ret==-ENOMEM);else{assert(!ret&&proc_children==2);tzdbgfs_exit(&p);}empty();
 }else if(!strncmp(c,"debug-",6)){
  debug_fail=!strcmp(c,"debug-dir-fail")?1:2;ret=tzdbgfs_init(&p);
#ifdef CONFIG_DEBUG_FS
  assert(ret==(debug_fail==1?-ENODEV:-ENOSPC));
#else
  assert(ret==0);tzdbgfs_exit(&p);
#endif
  empty();
 }else if(!strncmp(c,"probe-",6)){
  if(!strcmp(c,"probe-encrypted")||!strcmp(c,"probe-encrypted-proc-fail"))want_encrypted=1;
  if(!strcmp(c,"probe-proc-fail")||!strcmp(c,"probe-encrypted-proc-fail"))proc_fail=3;
  if(!strcmp(c,"probe-feature-fail"))feature_error=-EPROBE_DEFER;
  if(!strcmp(c,"probe-resource-fail"))missing_resource=1;
  if(!strcmp(c,"probe-hyp-fail")){hyp_requested=1;hyp_error=-EPROBE_DEFER;}
  if(!strcmp(c,"probe-display-fail"))dma_fail=2;
  ret=tz_log_probe(&p);
  if(feature_error||hyp_error)assert(ret==-EPROBE_DEFER);else if(missing_resource)assert(ret==-ENXIO);
  else if(proc_fail||dma_fail)assert(ret==-ENOMEM);else{assert(!ret&&proc_children==2);assert(tz_log_remove(&p)==0);}
  empty();
 }else if(!strcmp(c,"proc-read")){struct inode inode={.data=&tzdbg.debug_tz[3]};struct file file={.inode=&inode};loff_t off=0;char b[3];
  assert(qsee_log_dump_procfs_read(&file,b,3,&off)==3);assert(file.private_data==inode.data);empty();}
 else assert(!"UNKNOWN_CASE");
 return 0;}
'''
