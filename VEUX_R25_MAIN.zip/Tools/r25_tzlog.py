#!/usr/bin/env python3
"""Restore stock procfs TrustZone logging on the authenticated R24 build path."""
import argparse,hashlib,importlib.util,json,re,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
FLAG='CONFIG_QTI_TZ_LOG'
DRIVER='drivers/firmware/qcom/tz_log.c'
STATUS='R25_FULL_TZ_PROCFS_RTMM_FINGERPRINT_1423_CRCS_37_MODULES_PASS_NOFLASH'

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def profile():return json.loads((ROOT/'References/PROFILE.json').read_text())
def pins():return json.loads((ROOT/'References/SOURCE_PINS.json').read_text())
def config_values(text):
    result={}
    for line in text.splitlines():
        if line.startswith('CONFIG_'):n,v=line.split('=',1)
        elif line.startswith('# CONFIG_')and line.endswith(' is not set'):n,v=line[2:-11],'n'
        else:continue
        require(n not in result,'DUPLICATE_CONFIG:'+n);result[n]=v
    return result
def normalize_logger(values):
    require(values.get(FLAG)=='y','STOCK_TZ_LOG_MUST_BE_BUILTIN')
    require(values.get('CONFIG_DEBUG_FS')=='n'and values.get('CONFIG_PROC_FS')=='y',
            'STOCK_PROCFS_AND_DISABLED_DEBUGFS_REQUIRED')
    old=dict(values);del old[FLAG]
    digest=hashlib.sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    require(digest==profile()['baseline_config_values_sha256'],'CONFIG_CHANGED_OUTSIDE_ONE_TZ_LOG_KEY')
    return old
def verify_package():
    names=set()
    for line in(ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest,name=line.split('  ',1);p=Path(name)
        require(not p.is_absolute()and'..'not in p.parts and name not in names,'UNSAFE_PACKAGE_MANIFEST')
        require(not(ROOT/p).is_symlink()and sha(ROOT/p)==digest,'PACKAGE_FILE_CHANGED:'+name);names.add(name)
    actual={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()
            and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt'}
    require(actual==names and len(pins())==5,'PACKAGE_SCOPE_CHANGED')
    for n,pin in pins().items():
        for side in ['Before','After']:
            require(sha(ROOT/side/n)==pin[side.lower()+'_sha256'],'SOURCE_FIXTURE_CHANGED:'+n)
def tree_node(source):
    path=Path(source)/profile()['device_tree_path'];require(path.is_file()and not path.is_symlink(),'HOLI_DTS_MISSING')
    text=path.read_text();require(text.count('qcom_tzlog:')==1,'TZLOG_NODE_NOT_UNIQUE')
    start=text.index('qcom_tzlog:');end=text.index('};',start)+2
    digest=hashlib.sha256(re.sub(r'\s+','',text[start:end]).encode()).hexdigest()
    require(digest==profile()['tzlog_node_tokens_sha256'],'HOLI_TZ_LOG_CONTRACT_CHANGED')
    return {'holi_dtsi_sha256':sha(path),'tzlog_node_tokens_sha256':digest,'runtime_binding_proven':False}
def source_check(source,after=False):
    source=Path(source).resolve(strict=True);result={}
    for n,pin in pins().items():
        path=source/n
        require(path.is_file()and all(not p.is_symlink()for p in[path,*path.parents]if p.is_relative_to(source)),
                'SOURCE_NOT_REGULAR:'+n)
        result[n]=sha(path);require(result[n]==pin['after_sha256'if after else'before_sha256'],
                                   'SOURCE_CONTEXT_CHANGED:'+n)
    return {'source_hashes':result,'device_tree_contract':tree_node(source)}
def apply_source(source):
    source=Path(source).resolve(strict=True);source_check(source)
    for n,pin in pins().items():
        if pin['before_sha256']!=pin['after_sha256']:(source/n).write_bytes((ROOT/'After'/n).read_bytes())
    return source_check(source,after=True)
def request_logger(source,config):
    source=Path(source);require(sha(source/'scripts/config')==profile()['scripts_config_sha256'],'SCRIPTS_CONFIG_CHANGED')
    p=subprocess.run(['bash',str(source/'scripts/config'),'--file',str(config),'--enable','QTI_TZ_LOG'],
                     capture_output=True,text=True)
    require(p.returncode==0,'LOGGER_CONFIG_REQUEST_FAILED:'+p.stderr)
    return {'only_new_requested_keys':[FLAG],'defconfig_modified':False,'debugfs_enabled':False}
def load_parent(path):
    path=Path(path).resolve(strict=True);require(sha(path)==profile()['r24_tool_sha256'],'AUTHENTIC_R24_TOOL_CHANGED')
    spec=importlib.util.spec_from_file_location('r25_authentic_r24',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.verify_package();return module
def linked_proof(text):
    patterns={'initcall':r'__initcall_\S*tz_log_driver_init6(?:\.llvm\.\S+)?',
              'proc_log_operations':r'qsee_log_dump_proc_fops(?:[.$]\S+)?',
              'platform_probe':r'tz_log_probe(?:[.$]\S+)?'}
    result={}
    for key,pattern in patterns.items():
        found=re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+('+pattern+r')$',text)
        require(found,'TZ_LOG_INTERFACE_NOT_LINKED:'+key);result[key]=sorted(set(found))
    return result
def logger_proof(build):
    build=Path(build).resolve(strict=True);out=build/'candidate-out';values=config_values((out/'.config').read_text())
    normalize_logger(values);source=source_check(build/'candidate-source',after=True)
    obj=out/'drivers/firmware/qcom/tz_log.o';cmd=obj.parent/('.'+obj.name+'.cmd')
    with obj.open('rb')as f:magic=f.read(4)
    require(magic in(b'BC\xc0\xde',b'\xde\xc0\x17\x0b'),'TZ_LOG_OBJECT_NOT_LLVM_BITCODE')
    text=cmd.read_text();require(DRIVER in text and'-flto=thin'in text and'-fsanitize=cfi'in text,
                               'REAL_TZ_LOG_CFI_COMMAND_MISSING')
    return {'only_new_config_changes_against_actual_R24':{FLAG:[None,'y']},
        'stock_debugfs_disabled':True,'logger_source':source,
        'logger_object_sha256':sha(obj),'logger_command_sha256':sha(cmd),
        'linked_tz_log_interfaces':linked_proof((out/'System.map').read_text()),'System_map_sha256':sha(out/'System.map')}
def write_result(out,name,data):
    if out.is_dir():(out/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
def build(args):
    verify_package();parent=load_parent(args.r24_tool)
    original_request,original_normalize=parent.request_memory,parent.normalize_memory
    out=Path(args.output).resolve()
    result={'status':'R25_BUILD_PENDING','kernel_compiled':False,'device_pass':False,'flash_allowed':False,
        'runtime_trustzone_probe_tested':False,'baseline_run':profile()['baseline_run'],
        'legacy_report_config_scope':'R24 normalizes the explicit R25 logger key; R25_RESULT gives the complete new delta.'}
    def request(source,config):
        old=original_request(source,config);result['applied_logger_source']=apply_source(source)
        result['logger_config_request']=request_logger(source,config)
        return dict(old,logger_request=result['logger_config_request'])
    def normalize(values):return original_normalize(normalize_logger(values))
    parent.request_memory,parent.normalize_memory=request,normalize
    try:
        parent.build(args);legacy=json.loads((out/'R24_RESULT.json').read_text())
        require(legacy['status']==parent.STATUS and legacy['kernel_compiled']is True
                and legacy['rtmm_provider_chain_compiled_and_linked']is True
                and legacy['fully_matching_modules']==37,'FULL_R24_MEMORY_FINGERPRINT_AND_OEM_GATES_REQUIRED')
        result.update(logger_proof(out));require(result['logger_source']==result['applied_logger_source'],
                                                'LOGGER_SOURCE_CHANGED_DURING_BUILD')
        for n,h in legacy['kernel_product_hashes'].items():require(sha(out/'candidate-out'/n)==h,'KERNEL_PRODUCT_CHANGED:'+n)
        result.update(status=STATUS,kernel_compiled=True,trustzone_procfs_compiled_and_linked=True,
            fully_matching_modules=37,qgki_counts=legacy['qgki_counts'],all_1423_import_crcs_match=True,
            kernel_product_hashes=legacy['kernel_product_hashes'],release=legacy['release'])
    except Exception as error:
        result.update(status='R25_BUILD_OR_TZ_LOG_GATE_FAILED_NOFLASH',error=str(error));raise
    finally:
        parent.request_memory,parent.normalize_memory=original_request,original_normalize
        write_result(out,'R25_RESULT.json',result)
    print(result['status'],'DEVICE_PASS=NO FLASH=NO')
def verify_fresh(build):
    build=Path(build).resolve(strict=True);r=json.loads((build/'R25_RESULT.json').read_text())
    require(r.get('status')==STATUS and r.get('kernel_compiled')is True
            and r.get('trustzone_procfs_compiled_and_linked')is True
            and r.get('runtime_trustzone_probe_tested')is False
            and r.get('device_pass')is False and r.get('flash_allowed')is False,'FRESH_R25_FULL_BUILD_REQUIRED')
    actual=logger_proof(build);require(all(r.get(k)==v for k,v in actual.items()),'TZ_LOG_PROOF_CHANGED')
    require(r['fully_matching_modules']==37 and r['qgki_counts']=={'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0},
            'OEM_COHORT_CHANGED')
    for n,h in r['kernel_product_hashes'].items():require(sha(build/'candidate-out'/n)==h,'FRESH_KERNEL_CHANGED:'+n)
    return r
def package(args):
    verify_package();r=verify_fresh(args.build);parent=load_parent(args.r24_tool);original=parent.normalize_memory
    parent.normalize_memory=lambda values:original(normalize_logger(values))
    try:parent.package(args)
    finally:parent.normalize_memory=original
    out=Path(args.output).resolve(strict=True);prior=json.loads((out/'R24_PACKAGE_RESULT.json').read_text())
    require(prior['static_boot_path_pass']is True and prior['device_pass']is False,'STATIC_PAIR_NOT_PROVEN')
    pair={}
    for p in sorted((out/'review').iterdir()):
        require(p.is_file()and p.name.startswith('VEUX_R24_'),'UNEXPECTED_REVIEW_FILE')
        q=p.with_name(p.name.replace('VEUX_R24_','VEUX_R25_',1));require(not q.exists(),'REVIEW_TARGET_EXISTS')
        p.rename(q);pair[q.name]=sha(q)
    require(len(pair)==2 and any(n.endswith('_boot.img')for n in pair)and any(n.endswith('_AK3.zip')for n in pair),
            'COMPLETE_PAIR_REQUIRED');verify_fresh(args.build)
    write_result(out,'R25_PACKAGE_RESULT.json',{'status':'R25_STATIC_BOOT_AK3_PAIR_PASS_DEVICE_UNTESTED_NOFLASH',
        'static_boot_path_pass':True,'device_pass':False,'flash_allowed':False,'review_pair_sha256':pair,
        'kernel_release':r['release']['verified_release'],'image_sha256':prior['image_sha256']})
    print('R25_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')
def main():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='op',required=True)
    s.add_parser('verify-package');s.add_parser('check-source').add_argument('--source',required=True)
    b=s.add_parser('build')
    for n in('r24-tool','r23-tool','r21-tool','r19-tool','r18-tool','r17-tool','base-tool','source','objout',
             'r6-report','r6-tool','project','output'):b.add_argument('--'+n,required=True)
    a=s.add_parser('package')
    for n in('r24-tool','r23-tool','r21-package-tool','build','packager-tool','work','output'):a.add_argument('--'+n,required=True)
    args=p.parse_args();verify_package()
    if args.op=='build':build(args)
    elif args.op=='package':package(args)
    elif args.op=='check-source':print(json.dumps(source_check(args.source)))
    else:print('R25_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')
if __name__=='__main__':main()
