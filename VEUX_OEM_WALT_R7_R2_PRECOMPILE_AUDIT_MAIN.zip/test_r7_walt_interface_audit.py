#!/usr/bin/env python3
"""Self-contained failure-case tests; exact-source assertions are run by CLI in CI."""
from __future__ import annotations
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest import mock

spec=importlib.util.spec_from_file_location('audit',Path(__file__).with_name('r7_walt_interface_audit.py'))
audit=importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)

H='''#ifdef CONFIG_SPRD_ROTATION_TASK
static inline void clear_reserved(int cpu){ (void)cpu; }
u64 sched_ktime_clock(void);
#else
static inline bool is_reserved(int cpu){return false;}
static inline u64 sched_ktime_clock(void){return sched_clock();}
#endif
'''
W='''u64 sched_ktime_clock(void)
{
 return 1;
}
void clear_walt_request(int cpu)
{
 clear_reserved(cpu);
 clear_reserved(rq->push_cpu);
}
'''
C='''CONFIG_SCHED_WALT=y\nCONFIG_QGKI=y\nCONFIG_MODULES=y\n'''
CORE='''#ifdef CONFIG_SCHED_WALT
walt_update_task_ravg(curr, rq, TASK_UPDATE, 1, 0);
try_to_wake_up(task, TASK_NORMAL, 0, head->count);
#endif
'''

class Tests(unittest.TestCase):
    def test_01_genuine_contract_model(self):
        r=audit.assess(H,W,C,CORE)
        self.assertEqual(2,len(r['findings']))
        self.assertFalse(r['source_conditions']['oem_sprd_rotation_enabled'])
    def test_02_requires_walt_on(self):
        with self.assertRaisesRegex(audit.EvidenceError,'OEM_WALT_NOT_ENABLED'):
            audit.assess(H,W,C.replace('CONFIG_SCHED_WALT=y','CONFIG_SCHED_WALT=n'),CORE)
    def test_03_requires_qgki(self):
        with self.assertRaisesRegex(audit.EvidenceError,'OEM_QGKI_NOT_ENABLED'):
            audit.assess(H,W,C.replace('CONFIG_QGKI=y','CONFIG_QGKI=n'),CORE)
    def test_04_blocks_enabled_rotation_assumption(self):
        with self.assertRaisesRegex(audit.EvidenceError,'ROTATION_IS_ENABLED'):
            audit.assess(H,W,C+'CONFIG_SPRD_ROTATION_TASK=y\n',CORE)
    def test_05_requires_rotation_branch(self):
        with self.assertRaisesRegex(audit.EvidenceError,'ROTATION_CLOCK_CONTRACT'):
            audit.assess(H.replace('CONFIG_SPRD_ROTATION_TASK','CONFIG_OTHER'),W,C,CORE)
    def test_06_requires_unique_rotation_branch(self):
        with self.assertRaisesRegex(audit.EvidenceError,'ROTATION_CLOCK_CONTRACT'):
            audit.assess(H+H,W,C,CORE)
    def test_07_requires_on_clock_prototype(self):
        with self.assertRaisesRegex(audit.EvidenceError,'ROTATION_ON_CLOCK'):
            audit.assess(H.replace('u64 sched_ktime_clock(void);','int sched_ktime_clock(void);'),W,C,CORE)
    def test_08_requires_off_clock_inline(self):
        with self.assertRaisesRegex(audit.EvidenceError,'ROTATION_CLOCK_CONTRACT|ROTATION_OFF_CLOCK'):
            audit.assess(H.replace('static inline u64 sched_ktime_clock','inline u64 sched_ktime_clock'),W,C,CORE)
    def test_09_detects_changed_clear_reserved(self):
        with self.assertRaisesRegex(audit.EvidenceError,'RESERVED_FUNCTION'):
            audit.assess(H.replace('static inline bool is_reserved','static inline void clear_reserved(int cpu){}\nstatic inline bool is_reserved'),W,C,CORE)
    def test_10_detects_missing_on_clear(self):
        with self.assertRaisesRegex(audit.EvidenceError,'RESERVED_FUNCTION'):
            audit.assess(H.replace('clear_reserved(int cpu)','reset_reserved(int cpu)'),W,C,CORE)
    def test_11_detects_missing_walt_clock(self):
        with self.assertRaisesRegex(audit.EvidenceError,'WALT_GLOBAL_CLOCK'):
            audit.assess(H,W.replace('u64 sched_ktime_clock','int sched_ktime_clock'),C,CORE)
    def test_12_detects_missing_clear_walt_request(self):
        with self.assertRaisesRegex(audit.EvidenceError,'WALT_CLEAR_WALT_REQUEST'):
            audit.assess(H,W.replace('clear_walt_request','walt_request_changed'),C,CORE)
    def test_13_requires_both_clear_reserved_calls(self):
        with self.assertRaisesRegex(audit.EvidenceError,'WALT_CLEAR_RESERVED_CALLS'):
            audit.assess(H,W.replace('clear_reserved(cpu);','(void)cpu;'),C,CORE)
    def test_14_requires_real_p10_tick(self):
        with self.assertRaisesRegex(audit.EvidenceError,'P10_CORE_TICK'):
            audit.assess(H,W,C,CORE.replace('walt_update_task_ravg','foo'))
    def test_15_requires_real_p10_wakeup(self):
        with self.assertRaisesRegex(audit.EvidenceError,'P10_CORE_WAKEUP'):
            audit.assess(H,W,C,CORE.replace('head->count','1'))
    def test_16_requires_real_p10_guard(self):
        with self.assertRaisesRegex(audit.EvidenceError,'P10_CORE_WALT_GUARD'):
            audit.assess(H,W,C,CORE.replace('CONFIG_SCHED_WALT','CONFIG_OTHER'))
    def test_17_compiler_probes_expect_rejection(self):
        res=audit.run_clang_diagnostics('clang')
        self.assertEqual({'clock_redefinition','clear_reserved_undeclared'},set(res))
        self.assertTrue(all(p['result']=='EXPECTED_COMPILER_ERROR' for p in res.values()))
    def test_26_ubuntu_runner_clang_14_implicit_declaration(self):
        message="<stdin>:1:36: error: implicit declaration of function 'clear_reserved' is invalid in C99 [-Werror,-Wimplicit-function-declaration]"
        self.assertTrue(audit.expected_clang_failure('clear_reserved_undeclared',1,message))
    def test_27_local_clang_17_undeclared_call(self):
        message="<stdin>:1:36: error: call to undeclared function 'clear_reserved'; ISO C99 and later do not support implicit function declarations [-Wimplicit-function-declaration]"
        self.assertTrue(audit.expected_clang_failure('clear_reserved_undeclared',1,message))
    def test_28_reject_unrelated_compiler_error_or_zero_exit(self):
        self.assertFalse(audit.expected_clang_failure('clear_reserved_undeclared',1,"error: unknown argument -something"))
        self.assertFalse(audit.expected_clang_failure('clear_reserved_undeclared',0,"error: implicit declaration of function 'clear_reserved'"))
        self.assertFalse(audit.expected_clang_failure('clock_redefinition',1,"error: call to undeclared function 'clear_reserved'"))
        self.assertFalse(audit.expected_clang_failure('clear_reserved_undeclared',1,"warning: implicit declaration of function 'clear_reserved'"))
    def test_29_simulated_ubuntu_runner_clang_14_full_probes(self):
        from types import SimpleNamespace
        outputs=[SimpleNamespace(returncode=1,stderr="<stdin>:4:5: error: redefinition of 'sched_ktime_clock'"),
                 SimpleNamespace(returncode=1,stderr="<stdin>:1:36: error: implicit declaration of function 'clear_reserved' is invalid in C99 [-Werror,-Wimplicit-function-declaration]")]
        with mock.patch.object(audit.subprocess,'run',side_effect=outputs) as p:
            result=audit.run_clang_diagnostics('clang')
        self.assertEqual(2,p.call_count)
        self.assertEqual('EXPECTED_COMPILER_ERROR',result['clear_reserved_undeclared']['result'])
    def test_30_unrelated_compiler_failures_stop_diagnostic(self):
        from types import SimpleNamespace
        with mock.patch.object(audit.subprocess,'run',return_value=SimpleNamespace(returncode=1,stderr='error: wrong target architecture')):
            with self.assertRaisesRegex(audit.EvidenceError,'CLANG_UNEXPECTED_RESULT'):
                audit.run_clang_diagnostics('clang')
    def test_18_clang_absence_fails_closed(self):
        with self.assertRaises(FileNotFoundError):
            audit.run_clang_diagnostics('/definitely/missing/clang')
    def test_19_disallow_missing_inputs(self):
        with self.assertRaisesRegex(audit.EvidenceError,'UNSAFE_OR_MISSING_INPUT'):
            audit.read_regular(Path('/invalid/nonexistent'))
    def test_20_disallow_symlink_inputs(self):
        with tempfile.TemporaryDirectory() as d:
            a,b=Path(d)/'a',Path(d)/'b'
            a.write_text('sample');b.symlink_to(a)
            with self.assertRaisesRegex(audit.EvidenceError,'UNSAFE_OR_MISSING_INPUT'):
                audit.read_regular(b)
    def test_21_reject_donor_sha_mismatch(self):
        self.assertNotEqual(audit.digest(b'mutated'),audit.WALT_C_SHA)
    def test_22_unapproved_gate_flags_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d);(t/'R6_SOURCE_GATE.json').write_text('{"strict_real_source":false}')
            with self.assertRaisesRegex(audit.EvidenceError,'R6_STRICT'):
                audit.inspect(t,t,Path('/missing'),'clang')
    def test_23_reject_wrong_tree_pins(self):
        with tempfile.TemporaryDirectory() as d:
            t=Path(d);(t/'R6_SOURCE_GATE.json').write_text(
                '{"strict_real_source":true,"method":"GIT_APPLY","p3_tree":"wrong","p10_composed_tree":"wrong"}')
            with self.assertRaisesRegex(audit.EvidenceError,'R6_TREE_MISMATCH'):
                audit.inspect(t,t,Path('/missing'),'clang')
    def test_24_r6_header_hash_scope_and_lengths(self):
        self.assertEqual({'include/linux/sched.h','include/linux/sched/sysctl.h',
                          'kernel/sched/sched.h'},set(audit.R6_SOURCE_HASHES))
        self.assertEqual(3,len(set(audit.R6_SOURCE_HASHES.values())))
        self.assertTrue(all(len(v)==64 and all(c in '0123456789abcdef' for c in v)
                            for v in audit.R6_SOURCE_HASHES.values()))
    def test_25_oem_config_pinned(self):
        p=Path(__file__).with_name('OEM_VEUX_5_4_274.config')
        self.assertTrue(p.is_file(), 'OEM config must accompany the R7 audit')
        self.assertEqual(audit.OEM_SHA,audit.digest(p.read_bytes()))

if __name__=='__main__':unittest.main(verbosity=2)
