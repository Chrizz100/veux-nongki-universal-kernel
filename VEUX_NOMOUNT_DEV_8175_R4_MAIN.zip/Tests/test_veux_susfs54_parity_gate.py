#!/usr/bin/env python3
"""Strict host-only tests of source-parity gate. NO actual VEUX compile/device test."""
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from veux_susfs54_parity_gate import check_source, sha, read_regular_inside

KSU = r'''
#ifdef KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 10, 0)
#error BakaSU does NOT support susfs selinux_hide feature in nongki
#endif
#endif
static ssize_t my_write_context(struct file *f, char *buf, size_t size) {
 if (likely(current_uid().val < 10000 || !ksu_selinux_hide_running)) { return orig_context_write(f, buf, size); }
 return 0;
}
static ssize_t my_write_access(struct file *f, char *buf, size_t size) {
 if (likely(current_uid().val < 10000 || !ksu_selinux_hide_running)) { return orig_access_write(f, buf, size); }
 return 0;
}
static int my_sel_open_handle_status(struct inode *inode, struct file *f) {
 if (current_uid().val >= 10000 && ksu_selinux_hide_running) return 0;
 return orig_sel_open_handle_status(inode, f);
}
int ksu_handle_selinux_setprocattr(const char *name, void *v, size_t size) {
 if (likely(current_uid().val < 10000 || !ksu_selinux_hide_running)) goto call_orig;
 if (error2 || error) return error2 ?: error;
 call_orig: return ksu_orig_setprocattr(name, v, size);
}
'''
MAKE = 'VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n'
HOOK = 'static int selinux_setprocattr(const char *name, void *value, size_t size) { return 0; }\n'
FS = 'static int sel_open_handle_status(struct inode *i, struct file *f) { return 0; }\n'
BASE = 'KernelSU/kernel/feature/selinux_hide.c'
CANDS = ['security/selinux/hooks.c', 'security/selinux/selinuxfs.c']


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.write('Makefile', MAKE)
        self.write(BASE, KSU)
        self.write(CANDS[0], HOOK)
        self.write(CANDS[1], FS)

    def write(self, path, text):
        dest = self.root / path
        dest.parent.mkdir(exist_ok=True, parents=True)
        dest.write_text(text)

    def actual_hashes(self):
        return {p: sha((self.root / p).read_bytes()) for p in (BASE, *CANDS) if (self.root / p).is_file()}

    def report(self, hashes=None):
        return check_source(self.root, hashes if hashes is not None else self.actual_hashes())

    def check_is_blocked(self, name):
        r = self.report()
        self.assertEqual(r['result'], 'BLOCKED_NO_BUILD_NO_FLASH')
        self.assertIn(name, [c['check'] for c in r['checks'] if c['result'] == 'BLOCKED'])

    def test_clean_source_passes(self):
        self.assertEqual(self.report()['result'], 'SOURCE_PARITY_PASS_DEVICE_UNTESTED')

    def test_all_pass_checks_present(self):
        r = self.report()
        self.assertGreaterEqual(len(r['checks']), 10)
        self.assertTrue(all(c['result'] == 'PASS' for c in r['checks']))

    def test_version_wrong_blocked(self):
        self.write('Makefile', MAKE.replace('274', '268'))
        self.check_is_blocked('COMPOSED_KERNEL_5_4_274')

    def test_kernel_major_wrong(self):
        self.write('Makefile', MAKE.replace('VERSION = 5', 'VERSION = 6'))
        self.check_is_blocked('COMPOSED_KERNEL_5_4_274')

    def test_native_gki_fake_state_blocked(self):
        self.write(CANDS[0], HOOK + '\nextern struct selinux_state fake_state;\n')
        self.check_is_blocked('NO_DOUBLE_GKI_510_NATIVE_HOOK_'+CANDS[0])

    def test_native_gki_running_hook_blocked(self):
        self.write(CANDS[1], FS + '\nextern bool ksu_selinux_hide_running;\n')
        self.check_is_blocked('NO_DOUBLE_GKI_510_NATIVE_HOOK_'+CANDS[1])

    def test_r5_runtime_guard_missing_context(self):
        self.write(BASE, KSU.replace('current_uid().val < 10000 || !ksu_selinux_hide_running', 'current_uid().val < 10000', 1))
        self.check_is_blocked('BAKASU_RUNTIME_GUARD_my_write_context')

    def test_r5_runtime_guard_missing_access(self):
        self.write(BASE, KSU.replace('if (likely(current_uid().val < 10000 || !ksu_selinux_hide_running)) { return orig_access_write', 'if (likely(current_uid().val < 10000)) { return orig_access_write'))
        self.check_is_blocked('BAKASU_RUNTIME_GUARD_my_write_access')

    def test_setprocattr_no_orig(self):
        self.write(BASE, KSU.replace('ksu_orig_setprocattr', 'unsafe_custom_handler'))
        self.check_is_blocked('BAKASU_STOCK_SETPROCATTR_FALLBACK')

    def test_setprocattr_no_sid_error_check(self):
        self.write(BASE, KSU.replace('if (error2 || error)', 'if (error2)'))
        self.check_is_blocked('BAKASU_DOUBLE_SID_ERROR_GUARD')

    def test_status_not_running(self):
        self.write(BASE, KSU.replace('&& ksu_selinux_hide_running) return 0;', '&& ksu_selinux_hide_enabled) return 0;'))
        self.check_is_blocked('BAKASU_STATUS_RUNNING_GUARD')

    def test_guard_removed(self):
        self.write(BASE, KSU.replace('#error BakaSU', '//error BakaSU'))
        self.check_is_blocked('BAKASU_NON_GKI_54_GUARD')

    def test_missing_source(self):
        (self.root / CANDS[0]).unlink()
        self.check_is_blocked('NATIVE_SOURCE_PRESENT_'+CANDS[0])

    def test_fake_symlink_rejected(self):
        p = self.root / CANDS[0]
        p.unlink()
        p.symlink_to(self.root / CANDS[1])
        self.check_is_blocked('SOURCE_READ_'+CANDS[0])

    def test_sha_integrity_tamper(self):
        old = self.actual_hashes()
        self.write(CANDS[0], HOOK + '// unauthorized build difference\n')
        r = self.report(old)
        self.assertIn('BASELINE_SHA256_'+CANDS[0], [c['check'] for c in r['checks'] if c['result']=='BLOCKED'])

    def test_duplicate_ksu_differs_blocked(self):
        self.write('drivers/kernelsu/feature/selinux_hide.c', KSU + '\n// changed\n')
        self.check_is_blocked('BAKASU_STAGING_AGREES_WITH_COMPILED')

    def test_duplicate_ksu_same_passes(self):
        self.write('drivers/kernelsu/feature/selinux_hide.c', KSU)
        self.assertEqual(self.report()['result'], 'SOURCE_PARITY_PASS_DEVICE_UNTESTED')

    # R4: exact legitimate KSU alias, with strict fail-closed tampering tests.
    def make_alias(self, target='../KernelSU/kernel'):
        parent = self.root / 'drivers'
        parent.mkdir(exist_ok=True)
        (parent / 'kernelsu').symlink_to(target, target_is_directory=True)

    def test_exact_real_build_alias_is_accepted(self):
        self.make_alias()
        r = self.report()
        self.assertEqual(r['result'], 'SOURCE_PARITY_PASS_DEVICE_UNTESTED')
        self.assertEqual(r['writes_to_kernel_source'], False)
        self.assertEqual(read_regular_inside(self.root, 'drivers/kernelsu/feature/selinux_hide.c'), KSU.encode())
        self.assertIn('BAKASU_STAGING_AGREES_WITH_COMPILED', [c['check'] for c in r['checks'] if c['result']=='PASS'])
        self.assertIn('BASELINE_SHA256_drivers/kernelsu/feature/selinux_hide.c', [c['check'] for c in r['checks'] if c['result']=='PASS'])

    def test_exact_alias_with_pinned_real_bakasu_source_passes(self):
        # Real compiled BakaSU snapshot retained in the source-only R3/R4 overlay.
        evidence = Path(__file__).resolve().parents[1] / 'evidence/BAKASU_R5S1_COMPILED_SELINUX_REFERENCE.c'
        real = evidence.read_bytes()
        self.assertEqual(sha(real), '78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78')
        self.write(BASE, real.decode('utf-8'))
        pinned = self.actual_hashes()
        self.make_alias()
        r = self.report(pinned)
        self.assertEqual(r['result'], 'SOURCE_PARITY_PASS_DEVICE_UNTESTED', r['checks'])
        self.assertEqual(read_regular_inside(self.root, 'drivers/kernelsu/feature/selinux_hide.c'), real)

    def test_absolute_alias_to_same_directory_is_rejected(self):
        self.make_alias(str(self.root/'KernelSU/kernel'))
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_equivalent_but_different_link_text_is_rejected(self):
        self.make_alias('../KernelSU/./kernel')
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_dangling_alias_is_rejected_even_if_canonical_source_exists(self):
        self.make_alias('../KernelSU/missing')
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_alias_escape_outside_kernel_root_is_rejected(self):
        with tempfile.TemporaryDirectory() as external:
            self.make_alias(external)
            self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_nested_alias_target_is_rejected(self):
        (self.root/'redirect').symlink_to('KernelSU/kernel', target_is_directory=True)
        self.make_alias('../redirect')
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_drivers_symlink_without_resolved_alias_is_rejected(self):
        (self.root/'drivers').symlink_to('missing-directory', target_is_directory=True)
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_drivers_parent_symlink_with_alias_source_is_rejected(self):
        (self.root/'mirror').mkdir()
        (self.root/'mirror/kernelsu').symlink_to('../../KernelSU/kernel', target_is_directory=True)
        (self.root/'drivers').symlink_to('mirror', target_is_directory=True)
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_canonical_kernelsu_kernel_directory_symlink_rejected(self):
        (self.root/'KernelSU/kernel').rename(self.root/'KernelSU/actual_kernel')
        (self.root/'KernelSU/kernel').symlink_to('actual_kernel', target_is_directory=True)
        self.make_alias()
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_canonical_kernelsu_feature_directory_symlink_rejected(self):
        (self.root/'KernelSU/kernel/feature').rename(self.root/'KernelSU/kernel/actual_feature')
        (self.root/'KernelSU/kernel/feature').symlink_to('actual_feature', target_is_directory=True)
        self.make_alias()
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_canonical_kernelsu_leaf_symlink_rejected(self):
        orig=self.root/BASE
        orig.rename(orig.with_name('orig.c'))
        orig.symlink_to('orig.c')
        self.make_alias()
        self.check_is_blocked('SOURCE_READ_drivers/kernelsu/feature/selinux_hide.c')

    def test_alias_independent_canonical_sha_tamper_rejected(self):
        pinned=self.actual_hashes()
        self.make_alias()
        self.write(BASE, KSU + '\n// modified after stage\n')
        r=self.report(pinned)
        self.assertEqual(r['result'], 'BLOCKED_NO_BUILD_NO_FLASH')
        self.assertIn('BASELINE_SHA256_drivers/kernelsu/feature/selinux_hide.c', [c['check'] for c in r['checks'] if c['result']=='BLOCKED'])
        self.assertIn('BASELINE_SHA256_'+BASE, [c['check'] for c in r['checks'] if c['result']=='BLOCKED'])

    def test_exact_alias_not_whitelisted_for_another_source(self):
        self.make_alias()
        with self.assertRaisesRegex(ValueError, 'symlink in source path'):
            read_regular_inside(self.root, 'drivers/kernelsu/feature/other.c')

    def test_unrelated_native_selinux_symlink_still_rejected(self):
        self.make_alias()
        (self.root/CANDS[0]).unlink()
        (self.root/CANDS[0]).symlink_to('selinuxfs.c')
        self.check_is_blocked('SOURCE_READ_'+CANDS[0])

    def test_no_write_to_source(self):
        before = {str(x.relative_to(self.root)): hashlib.sha256(x.read_bytes()).hexdigest()
                  for x in self.root.rglob('*') if x.is_file()}
        self.report()
        after = {str(x.relative_to(self.root)): hashlib.sha256(x.read_bytes()).hexdigest()
                 for x in self.root.rglob('*') if x.is_file()}
        self.assertEqual(before, after)


if __name__ == '__main__':
    unittest.main(verbosity=2)
