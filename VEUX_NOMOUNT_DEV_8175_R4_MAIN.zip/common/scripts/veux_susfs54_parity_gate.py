#!/usr/bin/env python3
"""Fail-closed, read-only SUSFS/BakaSU SELinux source parity gate for VEUX 5.4.274.

Checks the actual composed kernel source; never applies/changes patches.
Hashes are from the verified 2026-10-18 VEUX NoMount-DEV CI source audit.
Syntax, markers and SHA prove source identity, not Android runtime behavior.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import sys

EXPECTED = {
    'KernelSU/kernel/feature/selinux_hide.c': '78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78',
    'security/selinux/hooks.c': '57a84c1b0f41d108e9557314c0039e5bfd6fc4b15aa60532711d32e551cc2992',
    'security/selinux/selinuxfs.c': '16533ae84611ddc908759231a06ac09722cbeda3cba7ebc361baa1ee462729a1',
}
EXACT_KSU_ALIAS = "drivers/kernelsu/feature/selinux_hide.c"
EXACT_KSU_SYMLINK = "drivers/kernelsu"
EXACT_KSU_SYMLINK_TARGET = "../KernelSU/kernel"

KSU_ALTERNATIVES = (
    'drivers/kernelsu/feature/selinux_hide.c',
    'KernelSU/kernel/feature/selinux_hide.c',
)
NATIVE = ('security/selinux/hooks.c', 'security/selinux/selinuxfs.c')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_regular_inside(root: Path, relative: str) -> bytes:
    """Read only regular files; permit precisely one verified BakaSU build alias.

    drivers/kernelsu -> ../KernelSU/kernel is created by the authenticated
    35234 build pipeline. Only the *specific* selinux_hide.c probe may use it.
    Other symlinks (including canonical source parents and the file itself)
    are forbidden. Read through the validated canonical path, not the alias.
    """
    path = Path(relative)
    if (path.is_absolute() or '..' in path.parts or not relative or
            '\\' in relative or any(s in ('.', '') for s in relative.split('/'))):
        raise ValueError('unsafe relative path: ' + relative)
    curr = root
    for segment in path.parts:
        curr = curr / segment
        if not curr.is_symlink():
            continue
        if relative != EXACT_KSU_ALIAS or curr != root / EXACT_KSU_SYMLINK:
            raise ValueError('symlink in source path: ' + relative)
        # Do not normalize the readlink text: e.g. an absolute or equivalent
        # but unapproved indirection is *not* the original build layout.
        link_text = os.readlink(curr)
        if link_text != EXACT_KSU_SYMLINK_TARGET:
            raise ValueError('unexpected BakaSU alias target: ' + link_text)
        target = root / 'KernelSU/kernel'
        try:
            resolved = curr.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise ValueError('BakaSU alias cannot resolve safely') from exc
        if resolved != target or not target.is_dir():
            raise ValueError('BakaSU alias does not point at canonical in-root kernel directory')
        # Re-read via the physical path. The recursive call enforces that
        # KernelSU, kernel, feature and selinux_hide.c are all non-symlinks.
        return read_regular_inside(root, 'KernelSU/kernel/feature/selinux_hide.c')
    if not curr.is_file():
        raise FileNotFoundError(relative)
    return curr.read_bytes()


def function_body(source: str, name: str) -> str:
    # Function definition only, not a prototype. This is structural smoke testing,
    # not a C parser; hashes ensure the tested source is exactly the known image source.
    pat = r'\b' + re.escape(name) + r'\s*\([^;{}]*\)\s*\{'
    m = re.search(pat, source, re.S)
    if not m:
        # A real BakaSU 5.4 definition uses #if prototype / #else prototype / #endif / {
        m = re.search(r'\b' + re.escape(name) + r'\s*\([^;{}]*\)\s*#else[\s\S]{0,400}?#endif\s*\{', source)
    if not m:
        return ''
    depth = 1
    start = m.end()
    for j in range(start, len(source)):
        if source[j] == '{':
            depth += 1
        elif source[j] == '}':
            depth -= 1
            if depth == 0:
                return source[start:j]
    return ''


def check_source(src_dir: Path, expected: dict[str, str] | None = None) -> dict:
    """Read only, returns structured checks; BLOCKED is not a runnable image."""
    expected = expected if expected is not None else EXPECTED
    root = src_dir.resolve(strict=True)
    results: list[dict] = []

    def check(name: str, success: bool, detail: str):
        results.append({'check': name, 'result': 'PASS' if success else 'BLOCKED', 'detail': detail})

    try:
        mk = read_regular_inside(root, 'Makefile').decode('utf-8', 'replace')
        actual = {k: re.search(r'^\s*' + k + r'\s*=\s*(\d+)\s*$', mk, re.M) for k in
                  ('VERSION', 'PATCHLEVEL', 'SUBLEVEL')}
        ver = '.'.join(actual[k].group(1) if actual[k] else '?' for k in actual)
        check('COMPOSED_KERNEL_5_4_274', ver == '5.4.274', 'Makefile version ' + ver)
    except (ValueError, OSError) as e:
        check('COMPOSED_KERNEL_5_4_274', False, str(e))

    ksu_present = []
    for name in KSU_ALTERNATIVES:
        if (root / name).exists() or (root / name).is_symlink():
            ksu_present.append(name)
    # Even dangling or poisoned parent links must be evaluated and BLOCKED;
    # absence of an alias file is NOT evidence that a symlink layout is safe.
    if ((root / 'drivers').is_symlink() or
            (root / EXACT_KSU_SYMLINK).is_symlink()):
        if EXACT_KSU_ALIAS not in ksu_present:
            ksu_present.insert(0, EXACT_KSU_ALIAS)
    data: dict[str, bytes] = {}
    for rel in (*ksu_present, *NATIVE):
        try:
            data[rel] = read_regular_inside(root, rel)
        except (OSError, ValueError) as e:
            check('SOURCE_READ_' + rel, False, str(e))

    if not ksu_present:
        check('BAKASU_SOURCE_PRESENT', False, 'Neither canonical nor compiled BakaSU hook file found')
    else:
        check('BAKASU_SOURCE_PRESENT', True, ', '.join(ksu_present))

    if len(ksu_present) > 1:
        consistent = len({sha(data[p]) for p in ksu_present if p in data}) == 1 and all(p in data for p in ksu_present)
        check('BAKASU_STAGING_AGREES_WITH_COMPILED', consistent,
              'Both source variants must be byte-for-byte identical')

    # The exact C source hash is our one-to-one compiled build baseline.
    for rel in (*ksu_present, *NATIVE):
        if rel not in data:
            continue
        canonical = 'KernelSU/kernel/feature/selinux_hide.c' if rel in KSU_ALTERNATIVES else rel
        found = sha(data[rel]); want = expected.get(canonical, '')
        check('BASELINE_SHA256_' + rel, found == want,
              f'actual={found} expected={want or "NOT SET"}')

    if ksu_present and ksu_present[0] in data:
        hook = data[ksu_present[0]].decode('utf-8', 'replace')
        check('BAKASU_NON_GKI_54_GUARD',
              bool(re.search(r'#if\s+LINUX_VERSION_CODE\s*<\s*KERNEL_VERSION\(5,\s*10,\s*0\)[\s\S]{0,280}?#error', hook))
              and 'KSU_COMPAT_HAS_SUSFS_FEATURE_SELINUX_HIDE' in hook,
              'Unsupported native SUSFS SELinux-hide path must remain rejected on <5.10')
        functions = ('my_write_context', 'my_write_access', 'ksu_handle_selinux_setprocattr')
        for name in functions:
            body = function_body(hook, name)
            check('BAKASU_RUNTIME_GUARD_' + name,
                  bool(body) and '!ksu_selinux_hide_running' in body and '10000' in body,
                  'App-UID threshold and hide-running fallback both required')
        status = function_body(hook, 'my_sel_open_handle_status')
        check('BAKASU_STATUS_RUNNING_GUARD',
              bool(status) and 'ksu_selinux_hide_running' in status,
              'Status hook must use running (not enabled) after R3 fix')
        proc = function_body(hook, 'ksu_handle_selinux_setprocattr')
        check('BAKASU_STOCK_SETPROCATTR_FALLBACK',
              bool(proc) and 'goto call_orig' in proc and 'ksu_orig_setprocattr' in proc,
              'Legacy source must keep the stock handler fallback')
        check('BAKASU_DOUBLE_SID_ERROR_GUARD',
              bool(proc) and bool(re.search(r'if\s*\(\s*error2\s*\|\|\s*error\s*\)', proc)),
              'Both the backup-policy and real-policy error paths must be handled')

    for rel in NATIVE:
        if rel not in data:
            check('NATIVE_SOURCE_PRESENT_' + rel, False, 'Missing native source')
            continue
        native = data[rel].decode('utf-8', 'replace')
        tokens = ['fake_state', 'ksu_selinux_hide_running', 'my_setprocattr(', 'my_sel_open_handle_status(']
        found = [token for token in tokens if token in native]
        check('NO_DOUBLE_GKI_510_NATIVE_HOOK_' + rel, not found,
              'Forbidden native 5.10 SELinux-hide symbols: ' + (', '.join(found) if found else 'none'))

    return {
        'schema': 1,
        'scope': 'VEUX_5.4.274_BAKASU35234_SUSFS2.3_NOMOUNT_DEV8175_READ_ONLY',
        'result': 'SOURCE_PARITY_PASS_DEVICE_UNTESTED' if all(x['result'] == 'PASS' for x in results) else 'BLOCKED_NO_BUILD_NO_FLASH',
        'checks': results,
        'writes_to_kernel_source': False,
        'source_identity_only_not_runtime_or_vendor_abi': True,
    }


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', type=Path, required=True,
                   help='Fully composed, temporary VEUX 5.4.274 kernel source root; not your Android phone')
    args = p.parse_args(argv)
    try:
        report = check_source(args.source)
    except (ValueError, OSError) as e:
        report = {'result': 'BLOCKED_NO_BUILD_NO_FLASH', 'error': str(e)}
    print(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
    return 0 if report['result'] == 'SOURCE_PARITY_PASS_DEVICE_UNTESTED' else 2


if __name__ == '__main__':
    sys.exit(main())
