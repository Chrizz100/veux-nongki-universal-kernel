#!/usr/bin/env python3
"""R15 genuine OEM+Qualcomm WALT runtime-provider trial; never a flash patch.

Reuses ONLY verified source bytes from original stock ikheaders and pinned
upstream Linux 5.4.61. All mutations occur inside a disposable donor worktree.
"""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path

SCHEMA='VEUX_R15_AUTHENTIC_WALT_RUNTIME_PROVIDERS_NOFLASH'
R14_SHA='42de59e084ab7ef539dd78bfe489ee5a27b99afd00196ad63db7160623bfd3d0'
PAIR_COMMIT='01cb3a8824b7b4caf3e3540274e71abba5ade538'
DONOR_COMMIT='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
STOCK_TASK_SHA='a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
STOCK_SYSC_SHA='a40790ea7884c5fad110f17d56445bef069fb7eed1251c8d0ea1a00611cafe60'
STOCK_HEADERS={
 'cpuhotplug.h':'cf61cc430731855d3e7e6a9d6c712c404ffcfc13907cd17f79b7cb4c2492643b',
 'nmi.h':'7491b62e4c53a6f0f7ed0f1104f60be05e2c8c4f48473ed6d1aadcf9fa65727f',
 'hrtimer.h':'7e475d274a02aa790ab2375a138cb78f92c3e8fc64686d05e841871322a3e427',
 'timer.h':'40b20e0ac57751ed5e002897b73164a5a67410d74e66dd4e264576d78f0d631c',
}
# Git blob SHA1 from fixed pair commit. Used in addition to the full git HEAD pin.
PAIR_BLOBS={
 'kernel/sysctl.c':'ce8cff2a5d8f2657e5bf8e00db0337b86cb78ff0',
 'kernel/watchdog.c':'e377bd4d14f71ef02fc33f6a06b17ae1e396e9b1',
 'kernel/time/hrtimer.c':'02f1ad059f58afceb8e0484001da28e0a5393b5e',
 'kernel/time/timer.c':'968ab19e51c84cc7b1a45f6dd96f633e439c4ed1',
}
DONOR_BLOBS={
 'kernel/watchdog.c':'a3d0e928305c31004ebc0d84361edb3353dbf48c',
 'kernel/time/hrtimer.c':'8e3c9228aec97289fb7b937e034d7f7d2a56189f',
 'kernel/time/timer.c':'16a2b62f5f74cfd0ecfad89943a4997b218e8676',
 'include/linux/nmi.h':'6cb593d9ed08a2b5b928f98dac892d309ebfc93c',
 'include/linux/cpuhotplug.h':'618d763c06a0ccedd6b8fe0a8f3bced78be72993',
 'include/linux/hrtimer.h':'1bb58485b2e246484b7599a74fe79b015fed2906',
 'include/linux/timer.h':'4184069aabf36d1e94a8c993e74ea817d6411c95',
}
R15_PROVIDERS={
 'SYSCTL':'kernel/sysctl.o',
 'WATCHDOG':'kernel/watchdog.o',
 'HRTIMER':'kernel/time/hrtimer.o',
 'TIMER':'kernel/time/timer.o',
}

def sha(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args],stderr=subprocess.PIPE,text=True).strip()
def require_count(s,needle,n=1):
    if s.count(needle)!=n:raise ValueError('R15_SOURCE_ANCHOR_DRIFT: '+repr(needle))

def load_main(root):
    root=Path(root)
    if not root.is_dir() or root.is_symlink():raise ValueError('R15_BAD_ROOT')
    m=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (m.get('schema')!=SCHEMA or m.get('r14_sha256')!=R14_SHA or
        m.get('pair_commit')!=PAIR_COMMIT or m.get('donor_commit')!=DONOR_COMMIT or
        m.get('stock_task_sha256')!=STOCK_TASK_SHA or
        any(m.get(x) is not False for x in ['flash_allowed','kernel_built','vmlinux_linked','production_patch_approved','oem_abi_verified'])):
        raise ValueError('R15_UNSAFE_MANIFEST_OR_PIN')
    fs={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if fs != set(m['files'])|{'MANIFEST_SHA256.json'}:raise ValueError('R15_FILESET_DRIFT')
    if any(p.is_symlink() for p in root.rglob('*')):raise ValueError('R15_SYMLINK')
    for rel,digest in m['files'].items():
        p=root/rel
        if not p.is_file() or sha(p.read_bytes())!=digest:raise ValueError('R15_CONTENT_HASH_DRIFT:'+rel)
    if sha((root/'reference/R14_MAIN_ORIGINAL.zip').read_bytes())!=R14_SHA:raise ValueError('R15_R14_PARENT_CHANGED')
    for name,digest in STOCK_HEADERS.items():
        if sha((root/'reference'/name).read_bytes())!=digest:raise ValueError('R15_STOCK_HEADER_DRIFT:'+name)
    import zipfile
    with zipfile.ZipFile(root/'reference/R14_MAIN_ORIGINAL.zip') as z:
        if z.testzip():raise ValueError('R15_NESTED_CORRUPT')
        m2=json.loads(z.read('MANIFEST_SHA256.json'))
        if m2['schema']!='VEUX_R14_FULL_QUALCOMM_WALT_COMPONENT_COMPILER_NOFLASH' or m2['flash_allowed'] is not False:
            raise ValueError('R15_R14_NOT_GENUINE')
    return m

def single_replace(s,old,new):
    require_count(s,old)
    return s.replace(old,new,1)

def upstream_migration(pair,marker):
    start='\n#ifdef CONFIG_HOTPLUG_CPU\n'+marker
    if start not in pair: # files with extra newlines between guard and function
        start='\n#ifdef CONFIG_HOTPLUG_CPU\n\n'+marker
    require_count(pair,start)
    i=pair.index(start)
    ending='\n#endif /* CONFIG_HOTPLUG_CPU */'
    j=pair.index(ending,i)+len(ending)
    region=pair[i:j]
    if region.count('#ifdef CONFIG_HOTPLUG_CPU')!=1 or region.count('#endif /* CONFIG_HOTPLUG_CPU */')!=1 or len(region)>14000:
        raise ValueError('R15_UPSTREAM_MIGRATION_SCOPE')
    return region

def donor_migration(donor,marker):
    return upstream_migration(donor,marker)

def patch_sysctl(header,code,stock,upstream):
    decl=re.findall(r'^extern int proc_douintvec_capacity\([\s\S]*?\);',stock,re.M)
    if len(decl)!=1 or len(decl[0])>275:raise ValueError('R15_MISSING_STOCK_CAPACITY_DECL')
    require_count(header,'extern int proc_douintvec_ravg_window(')
    if 'proc_douintvec_capacity' in header or 'proc_douintvec_capacity' in code:
        raise ValueError('R15_CAPACITY_ALREADY_PRESENT')
    hd=single_replace(header,'extern int proc_douintvec_ravg_window(',decl[0]+'\nextern int proc_douintvec_ravg_window(')
    start='static int do_proc_douintvec_capacity_conv('
    end='static int do_proc_douintvec_rwin('
    require_count(upstream,start);require_count(upstream,end)
    a=upstream.index(start);b=upstream.index(end,a)
    real=upstream[a:b].strip()
    if (real.count('proc_douintvec_capacity(')!=1 or 'SCHED_FIXEDPOINT_SCALE' not in real or
        'do_proc_dointvec(table, write, buffer, lenp, ppos,' not in real or len(real)>2300):
        raise ValueError('R15_CAPACITY_UPSTREAM_SEMANTICS')
    # Authentic disabled-configuration branch from pinned upstream source.
    x=upstream.index('\n#else /* CONFIG_PROC_SYSCTL */',b)
    j=upstream.index('\nint proc_douintvec_capacity(',x)+1
    k=upstream.index('\n#endif /* CONFIG_PROC_SYSCTL */',j)
    stub=upstream[j:k].strip()
    if stub.count('int proc_douintvec_capacity(')!=1 or 'return -ENOSYS;' not in stub or len(stub)>350:
        raise ValueError('R15_CAPACITY_STUB_SCOPE')
    require_count(code,'static int do_proc_douintvec_rwin(')
    patched=single_replace(code,'static int do_proc_douintvec_rwin(',real+'\n\nstatic int do_proc_douintvec_rwin(')
    require_count(patched,'\n#endif /* CONFIG_PROC_SYSCTL */')
    patched=single_replace(patched,'\n#endif /* CONFIG_PROC_SYSCTL */','\n\n'+stub+'\n#endif /* CONFIG_PROC_SYSCTL */')
    return hd,patched

def patch_stock_headers(headers,stock):
    out=dict(headers)
    # The exact stock enum is conditional; no number is hardcoded or spoofed.
    cpuhot=stock['cpuhotplug.h']
    m=re.findall(r'(?s)#ifdef CONFIG_SCHED_WALT\n\s*CPUHP_CORE_CTL_ISOLATION_DEAD,\n#endif',cpuhot)
    if len(m)!=1 or 'CPUHP_CORE_CTL_ISOLATION_DEAD' in headers['cpuhotplug.h']:
        raise ValueError('R15_STOCK_CPUHP_ENUM_DRIFT')
    out['cpuhotplug.h']=single_replace(headers['cpuhotplug.h'],'\tCPUHP_RCUTREE_PREP,','\tCPUHP_RCUTREE_PREP,\n'+m[0])
    # Real declarations and optional no-lockup fallback are both from stock.
    nh=stock['nmi.h']
    real=re.findall(r'(?s)#ifdef CONFIG_SCHED_WALT\nextern void watchdog_enable\(.*?\n#endif',nh)
    fallback=re.findall(r'(?s)#ifdef CONFIG_SCHED_WALT\nstatic inline void watchdog_enable\(.*?\n#endif',nh)
    if len(real)!=1 or len(fallback)!=1 or 'watchdog_configured' in headers['nmi.h']:
        raise ValueError('R15_STOCK_WATCHDOG_DECL_DRIFT')
    out['nmi.h']=single_replace(headers['nmi.h'],'void lockup_detector_init(void);','void lockup_detector_init(void);\n'+real[0])
    out['nmi.h']=single_replace(out['nmi.h'],'static inline void lockup_detector_cleanup(void) { }','static inline void lockup_detector_cleanup(void) { }\n'+fallback[0])
    for name,symbol,anchor in [
        ('hrtimer.h','hrtimer_quiesce_cpu','extern void hrtimer_init('),
        ('timer.h','timer_quiesce_cpu','extern void add_timer('),
    ]:
        pat=r'(?m)^extern void '+symbol+r'\(void \*cpup\);'
        m=re.findall(pat,stock[name]);
        if len(m)!=1 or symbol in headers[name]:raise ValueError('R15_STOCK_TIMER_DECL_DRIFT:'+name)
        out[name]=single_replace(headers[name],anchor,m[0]+'\n\n'+anchor)
    return out

def patch_watchdog(donor,pair):
    var='static DEFINE_PER_CPU(unsigned int, watchdog_en);'
    require_count(pair,var)
    if var in donor or 'watchdog_configured' in donor:raise ValueError('R15_WATCHDOG_ALREADY_PORTED')
    a='void watchdog_enable(unsigned int cpu)\n{'
    da='static void watchdog_enable(unsigned int cpu)\n{'
    end='\nstatic int softlockup_stop_fn('
    require_count(pair,a);require_count(donor,da)
    i=pair.index(a);j=pair.index(end,i)
    block=pair[i:j].strip()
    if (block.count('void watchdog_enable(')!=1 or block.count('void watchdog_disable(')!=1 or
        block.count('bool watchdog_configured(')!=1 or block.count('watchdog_en')<4 or len(block)>4200):
        raise ValueError('R15_WATCHDOG_GENUINE_IMPLEMENTATION_DRIFT')
    x=donor.index(da);y=donor.index(end,x)
    patched=donor[:x]+block+'\n'+donor[y:]
    patched=single_replace(patched,'static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);',
                           'static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);\n'+var)
    return patched

def apply(ours,stocks,upstreams):
    changes={}
    patched_headers=patch_stock_headers({k:ours['include/linux/'+k] for k in STOCK_HEADERS},stocks)
    for k,v in patched_headers.items():changes['include/linux/'+k]=v
    a,b=patch_sysctl(ours['include/linux/sysctl.h'],ours['kernel/sysctl.c'],stocks['sysctl.h'],upstreams['kernel/sysctl.c'])
    changes['include/linux/sysctl.h']=a;changes['kernel/sysctl.c']=b
    changes['kernel/watchdog.c']=patch_watchdog(ours['kernel/watchdog.c'],upstreams['kernel/watchdog.c'])
    for p,marker in [('kernel/time/hrtimer.c','static void migrate_hrtimer_list('),('kernel/time/timer.c','static void migrate_timer_list(')]:
        donor=ours[p];pair=upstreams[p]
        old=donor_migration(donor,marker)
        new=upstream_migration(pair,marker)
        if not all(x in new for x in ['quiesce_cpu','bool remove_pinned']) or len(new)<=len(old):
            raise ValueError('R15_MISSING_AUTHENTIC_TIMER_QUIESCE:'+p)
        changes[p]=single_replace(donor,old,new)
    if len(changes)!=9:raise ValueError('R15_EXPECT_EXACTLY_NINE_SOURCE_UPDATES')
    return changes

def stage(root,r13,donor,pair,trial,reports):
    root=Path(root);r13=Path(r13);donor=Path(donor);pair=Path(pair);trial=Path(trial);reports=Path(reports)
    load_main(root)
    if (git(donor,'rev-parse','HEAD')!=DONOR_COMMIT or git(donor,'status','--porcelain') or
        git(trial,'rev-parse','HEAD')!=DONOR_COMMIT or
        git(pair,'rev-parse','HEAD')!=PAIR_COMMIT or git(pair,'status','--porcelain')):
        raise ValueError('R15_REPO_NOT_PINNED_OR_UNCHANGED')
    for rel,blob in PAIR_BLOBS.items():
        data=(pair/rel).read_bytes()
        if (pair/rel).is_symlink() or git(pair,'rev-parse','HEAD:'+rel)!=blob or gitblob(data)!=blob:
            raise ValueError('R15_PAIR_AUTHENTICITY_FAILED:'+rel)
    for rel,blob in DONOR_BLOBS.items():
        data=(trial/rel).read_bytes()
        if (trial/rel).is_symlink() or git(trial,'rev-parse','HEAD:'+rel)!=blob or gitblob(data)!=blob:
            raise ValueError('R15_DONOR_SOURCE_BASE_DRIFT:'+rel)
    if sha((trial/'include/linux/sched.h').read_bytes())!=STOCK_TASK_SHA:
        raise ValueError('R15_STOCK_TASK_MODIFIED')
    stocks={n:(root/'reference'/n).read_text() for n in STOCK_HEADERS}
    s=(r13/'reference/stock_sysctl.h').read_bytes()
    if sha(s)!=STOCK_SYSC_SHA:raise ValueError('R15_STOCK_SYSCTL_NOT_GENUINE')
    stocks['sysctl.h']=s.decode()
    required=list(DONOR_BLOBS)+['include/linux/sysctl.h','kernel/sysctl.c']
    original={p:(trial/p).read_text() for p in required}
    pair_sources={p:(pair/p).read_text() for p in PAIR_BLOBS}
    changes=apply(original,stocks,pair_sources)
    if any((trial/k).is_symlink() for k in changes):raise ValueError('R15_SYMLINK_TARGET')
    before={k:sha((trial/k).read_bytes()) for k in changes}
    for rel,data in changes.items():(trial/rel).write_text(data)
    if git(donor,'status','--porcelain') or sha((trial/'include/linux/sched.h').read_bytes())!=STOCK_TASK_SHA:
        raise ValueError('R15_R6_OR_STOCK_TASK_VIOLATION')
    out={'schema':SCHEMA,'source_commits':{'pair':PAIR_COMMIT,'donor':DONOR_COMMIT},
         'pair_git_blobs':PAIR_BLOBS,'stock_header_sha256':STOCK_HEADERS,
         'experimental_source_changes':{k:{'before':before[k],'after':sha((trial/k).read_bytes())} for k in changes},
         'genuine_source_updates':len(changes),'donor_clean':True,'stock_task_preserved':True,
         'stock_rtmm_ported':False,'full_link_completed':False,'boot_tested':False,
         'oem_abi_verified':False,'flash_allowed':False}
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R15_GENUINE_SOURCE_PROVIDER_STAGE.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R15_SOURCE_PROVIDER_STAGE':len(changes),'R6_CLEAN':True,'FLASH':False}))
    return out

def summarize(reports,build_dir):
    reports=Path(reports);build_dir=Path(build_dir)
    objs={}
    for name,obj in R15_PROVIDERS.items():
        rcfile=reports/f'R15_{name}_RC.txt';logfile=reports/f'R15_{name}_BUILD.log'
        rc=int(rcfile.read_text().strip()) if rcfile.is_file() else None
        log=logfile.read_text(errors='replace') if logfile.is_file() else ''
        errs=[x[:450] for x in log.splitlines() if re.search(r'\berror:|\bfatal error:|make(?:\[\d+\])?: \*\*\*',x)]
        exists=(build_dir/obj).is_file() and (build_dir/obj).stat().st_size>0
        objs[name]={'object':obj,'rc':rc,'compiler_errors':errs[:30],'exists':exists}
    r14path=reports/'R14_NINE_WALT_OBJECTS_SUMMARY.json'
    r14=json.loads(r14path.read_text()) if r14path.is_file() else {}
    good=bool(r14.get('individual_compiled_objects_ok')) and all(x['rc']==0 and not x['compiler_errors'] and x['exists'] for x in objs.values())
    d={'schema':SCHEMA,'status':'R15_TWELVE_OBJECTS_COMPILE_ONLY' if good else 'R15_SOURCE_PROVIDER_BLOCKERS',
       'component_objects':r14.get('nine_objects',{}),'provider_objects':objs,
       'twelve_object_compilation_pass':good,'stock_rtmm_ported':False,'vmlinux_linked':False,
       'all_walt_hooks_installed':False,'oem_abi_verified':False,'boot_tested':False,'flash_allowed':False,
       'note':'Compile 12 objects only; no full vmlinux link or OEM-module ABI/boot proof. 5.4.61 source is experimental.'}
    (reports/'R15_TWELVE_OBJECTS_SUMMARY.json').write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'R15_COMPILER_GREEN':good,'R14_WALT_9':bool(r14.get('individual_compiled_objects_ok')),
                      'R15_PROVIDER_RCS':{k:v['rc'] for k,v in objs.items()},'FLASH':False}))
    return d

def main():
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['verify','stage','summary'])
    for x in ['root','r13','donor','pair','trial','reports','build-dir']:p.add_argument('--'+x)
    a=p.parse_args()
    if a.mode=='verify':print(json.dumps({'schema':load_main(a.root)['schema'],'flash':False}))
    elif a.mode=='stage':stage(a.root,a.r13,a.donor,a.pair,a.trial,a.reports)
    else:summarize(a.reports,a.build_dir)
if __name__=='__main__':main()
