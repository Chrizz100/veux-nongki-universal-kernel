import importlib.util
import json
import os
import tempfile
import unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('r15',HERE/'r15_walt_providers.py')
r15=importlib.util.module_from_spec(spec);spec.loader.exec_module(r15)
ROOT=HERE.parent

class R15Test(unittest.TestCase):
    def test_01_valid_main_and_auth(self):
        m=r15.load_main(ROOT)
        self.assertEqual(m['schema'],r15.SCHEMA)
    def test_02_original_stock_header_hashes(self):
        self.assertEqual(len(r15.STOCK_HEADERS),4)
        for k,v in r15.STOCK_HEADERS.items():self.assertEqual(r15.sha((ROOT/'reference'/k).read_bytes()),v)
    def test_03_parent_original_hash(self):
        self.assertEqual(r15.sha((ROOT/'reference/R14_MAIN_ORIGINAL.zip').read_bytes()),r15.R14_SHA)
    def test_04_object_names(self):
        self.assertEqual(set(r15.R15_PROVIDERS),{'SYSCTL','WATCHDOG','HRTIMER','TIMER'})
    def test_05_real_stock_cpuhp_enum(self):
        s=(ROOT/'reference/cpuhotplug.h').read_text()
        self.assertIn('#ifdef CONFIG_SCHED_WALT\n\tCPUHP_CORE_CTL_ISOLATION_DEAD,\n#endif',s)
    def test_06_real_stock_watchdog_declarations(self):
        s=(ROOT/'reference/nmi.h').read_text()
        self.assertIn('extern bool watchdog_configured(unsigned int cpu);',s)
        self.assertIn('static inline bool watchdog_configured(unsigned int cpu)',s)
    def test_07_real_stock_timer_entrypoints(self):
        self.assertIn('extern void hrtimer_quiesce_cpu(void *cpup);',(ROOT/'reference/hrtimer.h').read_text())
        self.assertIn('extern void timer_quiesce_cpu(void *cpup);',(ROOT/'reference/timer.h').read_text())
    def test_08_source_pins(self):
        self.assertEqual(len(r15.PAIR_BLOBS),4)
        self.assertEqual(len(r15.DONOR_BLOBS),7)
    def test_09_original_task_sha(self):
        self.assertEqual(r15.STOCK_TASK_SHA,'a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111')
    def test_10_single_anchor_success(self):
        self.assertEqual(r15.single_replace('def XYZ more','XYZ','abc'),'def abc more')
    def test_11_bad_anchor_fails(self):
        with self.assertRaises(ValueError):r15.single_replace('abaaba','aba','test')
    def test_12_stock_headers_from_real_bytes(self):
        stocks={n:(ROOT/'reference'/n).read_text() for n in r15.STOCK_HEADERS}
        originals={
            'cpuhotplug.h':'enum cpuhp_state {\n\tCPUHP_RCUTREE_PREP,\n\tCPUHP_CPUIDLE_COUPLED_PREPARE,\n};\n',
            'nmi.h':'#ifdef CONFIG_LOCKUP_DETECTOR\nvoid lockup_detector_init(void);\n#else\nstatic inline void lockup_detector_cleanup(void) { }\n#endif\n',
            'hrtimer.h':'extern void hrtimer_init(struct hrtimer *, int, int);\n',
            'timer.h':'extern void add_timer(struct timer_list *);\n'
        }
        result=r15.patch_stock_headers(originals,stocks)
        self.assertIn('CPUHP_CORE_CTL_ISOLATION_DEAD',result['cpuhotplug.h'])
        self.assertIn('watchdog_configured',result['nmi.h'])
        self.assertIn('hrtimer_quiesce_cpu',result['hrtimer.h'])
        self.assertIn('timer_quiesce_cpu',result['timer.h'])
    def test_13_stock_cpuhp_duplicates_fails(self):
        stocks={n:(ROOT/'reference'/n).read_text() for n in r15.STOCK_HEADERS}
        base={n:'CPUHP_CORE_CTL_ISOLATION_DEAD' for n in stocks}
        with self.assertRaises(ValueError):r15.patch_stock_headers(base,stocks)
    def test_14_extracted_original_capacity_decl(self):
        a=(Path('/mnt/data/r15_work/r13/reference/stock_sysctl.h'))
        if a.is_file():self.assertIn('extern int proc_douintvec_capacity(',a.read_text())
    def test_15_watchdog_fake_block_rejected(self):
        donor='static DEFINE_PER_CPU(struct hrtimer, watchdog_hrtimer);\nstatic void watchdog_enable(unsigned int cpu)\n{\n}\nstatic int softlockup_stop_fn('
        pair='static DEFINE_PER_CPU(unsigned int, watchdog_en);\nvoid watchdog_enable(unsigned int cpu)\n{\n}\nstatic int softlockup_stop_fn('
        with self.assertRaises(ValueError):r15.patch_watchdog(donor,pair)
    def test_16_migration_missing_branch_fails(self):
        with self.assertRaises(ValueError):r15.upstream_migration('void migrate_timer_list()','static void migrate_timer_list(')
    def test_17_summary_missing_rc_never_green(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);r15.summarize(out,out)
            d=json.loads((out/'R15_TWELVE_OBJECTS_SUMMARY.json').read_text())
            self.assertFalse(d['twelve_object_compilation_pass']);self.assertFalse(d['flash_allowed'])
    def test_18_summary_true_after_all_objects_only(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);(out/'R14_NINE_WALT_OBJECTS_SUMMARY.json').write_text('{"individual_compiled_objects_ok":true}')
            for name,obj in r15.R15_PROVIDERS.items():
                (out/f'R15_{name}_RC.txt').write_text('0');(out/f'R15_{name}_BUILD.log').write_text('CC '+obj)
                p=out/obj;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fake-fixture-object')
            d=r15.summarize(out,out)
            self.assertTrue(d['twelve_object_compilation_pass']);self.assertFalse(d['oem_abi_verified'])
    def test_19_summary_negative_rc(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t);(out/'R14_NINE_WALT_OBJECTS_SUMMARY.json').write_text('{"individual_compiled_objects_ok":true}')
            for name,obj in r15.R15_PROVIDERS.items():
                (out/f'R15_{name}_RC.txt').write_text('2' if name=='WATCHDOG' else '0')
                (out/f'R15_{name}_BUILD.log').write_text('error: missing' if name=='WATCHDOG' else 'done')
                p=out/obj;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'fixture')
            d=r15.summarize(out,out)
            self.assertFalse(d['twelve_object_compilation_pass'])
    def test_20_source_update_excludes_production(self):
        s=(HERE/'r15_walt_providers.py').read_text()
        self.assertNotIn('boot.img',s)
        self.assertNotIn('fastboot',s)
        self.assertNotIn('fastboot flash',s)
    def test_21_all_objects_have_unique_paths(self):
        self.assertEqual(len(set(r15.R15_PROVIDERS.values())),len(r15.R15_PROVIDERS))
    def test_22_contract_parent_contains_real_sources(self):
        import zipfile
        with zipfile.ZipFile(ROOT/'reference/R14_MAIN_ORIGINAL.zip') as z:
            self.assertIn('reference/R13_MAIN_ORIGINAL.zip',z.namelist())
    def test_23_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            out=Path(t)
            for p in ROOT.rglob('*'):
                if p.is_file():
                    q=out/p.relative_to(ROOT);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
            q=out/'reference/cpuhotplug.h';q.write_bytes(q.read_bytes()+b'\n')
            with self.assertRaises(ValueError):r15.load_main(out)
    def test_24_no_mock_logic_or_crc_spoof(self):
        s=(HERE/'r15_walt_providers.py').read_text()
        self.assertNotIn('KBUILD_EXTRA_SYMBOLS',s)
        self.assertNotIn('CONFIG_MODVERSIONS=n',s)
        self.assertNotIn('EXPORT_SYMBOL(fake',s)

if __name__=='__main__':unittest.main()
