# VEUX 5.4.274 – R15: Authentische WALT-Laufzeit-Schnittstellen (nur Compilerexperiment)

R14: sieben von neun Objekten kompiliert. `qc_vas.o` verlangte sieben echte APIs; `core_ctl.o` einen CPUHP-Enum.

R15 übernimmt in einem **isolierten** Arbeitsbaum (nicht in dein Kernel-Repository):

- Vier originale OEM-Header aus der Stock-5.4.274-kheaders-Referenz: cpuhotplug.h, nmi.h, hrtimer.h, timer.h. Nur die zugehörigen bekannten Deklarationen werden an ihren geprüften Ankern verwendet.
- Die echte Qualcomm-Sysctl-Kapazitäts-Handler-Familie + ihre Deklaration aus dem originalen Stock-sysctl.h (über das eingeschlossene R13).
- Die originale Qualcomm-Watchdog-Implementierung und Timer-Migrations-Implementierungen aus dem **fest gepinnten** 5.4.61-Quellbaum. Kein Dummy, keine CRC-Fälschung, keine abgeschalteten benötigten Funktionen.
- Alle neun WALT-Compilerobjekte plus drei Anbieter-Objekte (Watchdog/Timer/Hrtimer); das Sysctl-Objekt wird nach dem Port neu kompiliert. Fehler führen auf GitHub zu ROT, aber die Logs werden immer veröffentlicht.

**Was R15 NICHT belegt:** Komplette Scheduler-Laufzeit, finalen Link von vmlinux, Module.symvers/CRC-Kompatibilität, OEM-Bootfähigkeit, 5.4.274-Originalquellen, RTMM-Integration oder Flashfreigabe. Das ist ein isolierter, potentiell inkompatibler 5.4.61→5.4.268-Quellversuch. Vor späterem Flashen sind ABI-/Vendor-/Bootprüfungen zwingend.

Das eingebettete R14-MAIN wurde unverändert und per SHA-256 gebunden übernommen; darin befinden sich wiederum R13/R12/R11. Alle vier Stock-Header sind original aus der R1-kheaders-Datei.
