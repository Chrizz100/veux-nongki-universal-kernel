#!/usr/bin/env python3
"""Restore real stock ABI storage and complete related source changes on R14."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DEPENDENCY_SHA = 'a8f0bd5f24382ef1ea7e2af6210457291f4a288828b222cae295d372a5dcc3dd'
EXPECTED_LAYOUT = '0x945d02f2'
EXPECTED_CONFIG_DELTA = {'CONFIG_HAVE_HW_BREAKPOINT': [None, 'y'],
                         'CONFIG_MM_STAT_UNRECLAIMABLE_PAGES': [None, 'y']}
OEM = {'hardwareinfo_set_prop': '0x8124e3e6', 'smartpa_type': '0xed687ffd',
       'snd_soc_set_smartpa_type': '0x777f6815'}
NEW_UNITS = ['kernel/module.o', 'mm/vmscan.o', 'mm/vmstat.o', 'kernel/fork.o',
             'arch/arm64/kernel/hw_breakpoint.o', 'kernel/events/hw_breakpoint.o',
             'drivers/gpu/msm/kgsl.o', 'drivers/gpu/msm/kgsl_sharedmem.o',
             'drivers/gpu/msm/kgsl_pool.o',
             'drivers/staging/android/ion/heaps/ion_msm_system_heap.o']


def require(value, reason):
    if not value:
        raise ValueError(reason)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def token_sha(text):
    return hashlib.sha256(re.sub(r'\s+', '', re.sub(r'/\*.*?\*/|//[^\n]*', '',
                          text, flags=re.S)).encode()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def dependency():
    archive = ROOT / 'Dependencies/R14_R2_MAIN.zip'
    require(sha(archive) == DEPENDENCY_SHA, 'R14_DEPENDENCY_CHANGED')
    out = ROOT / 'runtime-r14'
    if not out.exists():
        with zipfile.ZipFile(archive) as z:
            members = z.infolist()
            require(z.testzip() is None and len(members) < 200
                    and len(members) == len({x.filename for x in members})
                    and sum(x.file_size for x in members) < 64_000_000, 'BAD_R14_ARCHIVE')
            for item in members:
                p = Path(item.filename)
                require(not p.is_absolute() and '..' not in p.parts and '\\' not in item.filename
                        and not item.is_dir() and (item.external_attr >> 16 & 0o170000) != 0o120000,
                        'UNSAFE_R14_ARCHIVE')
            z.extractall(out)
    spec = importlib.util.spec_from_file_location('r15_r14', out / 'Tools/restore_oem.py')
    r14 = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(r14)
    r14.verify_package()
    return r14


def verify_package():
    listed = set()
    for row in (ROOT / 'MANIFEST_SHA256.txt').read_text().splitlines():
        digest, name = row.split('  ', 1)
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and name not in listed,
                'UNSAFE_MANIFEST')
        require(not (ROOT / p).is_symlink() and sha(ROOT / p) == digest,
                'PACKAGE_CHANGED:' + name)
        listed.add(name)
    actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file()
              and '__pycache__' not in p.parts and 'runtime-r14' not in p.parts
              and p.name != 'MANIFEST_SHA256.txt'}
    require(actual == listed, 'MANIFEST_SCOPE_CHANGED')
    dependency().dependency()


def pins():
    result = json.loads((ROOT / 'References/FILE_PINS.json').read_text())
    require(len(result) == 10, 'SOURCE_SCOPE_CHANGED')
    return result


def check_source(source, baseline=False):
    source = Path(source).resolve(strict=True)
    locked = pins()
    earlier = dependency().dependency()[1].pins() if baseline else {}
    for name, pin in locked.items():
        p = source / name
        require(p.is_file() and not p.is_symlink()
                and all(not a.is_symlink() for a in p.parents if a != source.parent),
                'SOURCE_NOT_A_REGULAR_FILE:' + name)
        if name in earlier:
            require(sha(p) == earlier[name]['before_sha256'], 'BASELINE_DRIFT:' + name)
        elif pin['normalized_preimage']:
            require(token_sha(p.read_text()) == pin['before_tokens_sha256'],
                    'PUBLIC_HEADER_TOKEN_DRIFT:' + name)
        else:
            require(sha(p) == pin['before_sha256'], 'PREIMAGE_DRIFT:' + name)
    return {'files_verified': len(locked), 'source_changed': False, 'baseline_stage': baseline}


def apply_source(source):
    source = Path(source).resolve(strict=True)
    check_source(source)
    prepared = {}
    for name, pin in pins().items():
        if name == 'include/linux/sched.h':
            text = (source / name).read_text()
            old = '\t#ifdef CONFIG_RTMM\n\tu64\t\t\t\tproc_load;\n\t#endif'
            require(text.count(old) == 1, 'ORIGINAL_RTMM_SLOT_GUARD_CHANGED')
            text = text.replace(old, '\t/* Original VEUX stock ABI slot; optional RTMM stays disabled. */\n'
                               '\tu64\t\t\t\tproc_load;')
            require(token_sha(text) == pin['after_tokens_sha256'], 'WRONG_SCHEDULER_POSTIMAGE')
            prepared[name] = text.encode()
        else:
            p = ROOT / 'Candidate_R15' / name
            require(sha(p) == pin['after_sha256'], 'BAD_CANDIDATE:' + name)
            prepared[name] = p.read_bytes()
    # No file is changed until every original file and every new byte is checked.
    for name, data in prepared.items():
        (source / name).write_bytes(data)
    return {'changed_files': len(prepared), 'real_stock_proc_load_storage_restored': True,
            'rtmm_driver_enabled': False, 'rtmm_functionality_restored': False,
            'complete_memory_accounting_commits_restored': 2,
            'complete_optimization_commits_reversed': 3,
            'crcs_overridden': False}


def verify_config(before, after):
    delta = {k: [before.get(k), after.get(k)] for k in before.keys() | after.keys()
             if before.get(k) != after.get(k)}
    require(delta == EXPECTED_CONFIG_DELTA, 'UNEXPECTED_CONFIG_CHANGE:' + repr(delta))
    require(after.get('CONFIG_RTMM') is None, 'RTMM_ENABLED_WITHOUT_IMPLEMENTATION')
    for key in ('CONFIG_QGKI', 'CONFIG_SCHED_WALT', 'CONFIG_SPECULATIVE_PAGE_FAULT',
                'CONFIG_HARDWARE_INFO', 'CONFIG_LTO', 'CONFIG_LTO_CLANG', 'CONFIG_CFI_CLANG'):
        require(after.get(key) == 'y', 'REQUIRED_FUNCTION_DISABLED:' + key)
    return delta


def verify_abi(actual, reference, expected):
    require(actual.get('module_layout') == EXPECTED_LAYOUT, 'STOCK_MODULE_LAYOUT_NOT_RESTORED')
    require(all(actual.get(n) == crc for n, crc in OEM.items()), 'OEM_EXPORT_REGRESSION')
    old_matches = {n for n, crc in expected.items() if reference.get(n) == crc}
    new_matches = {n for n, crc in expected.items() if actual.get(n) == crc}
    lost = sorted(old_matches - new_matches)
    require(not lost, 'PREVIOUS_STOCK_MATCH_LOST:' + repr(lost))
    missing = sorted(n for n in expected if n not in actual)
    require(not missing, 'MISSING_ORIGINAL_IMPORTS:' + repr(missing))
    return {'gained_matching_symbols': sorted(new_matches - old_matches),
            'lost_matching_symbols': lost, 'remaining_missing_symbols': missing,
            'module_layout_matches_stock': EXPECTED_LAYOUT}


def build(args):
    verify_package()
    r14 = dependency()
    r13, r12, h = r14.dependency()
    r6 = r14.load(Path(args.r6_tool), 'r15_r6_verifier')
    src = Path(args.source).resolve(strict=True)
    obj = Path(args.objout).resolve(strict=True)
    out = Path(args.output).resolve()
    ws = Path(os.environ['GITHUB_WORKSPACE']).resolve(strict=True)
    project = Path(args.project).resolve(strict=True)
    require(not out.exists() and out.is_relative_to(ws), 'OUTPUT_MUST_BE_NEW')
    require(src.is_relative_to(ws) and obj.is_relative_to(ws)
            and not out.is_relative_to(src) and not out.is_relative_to(obj)
            and not out.is_relative_to(project) and not src.is_relative_to(project), 'UNSAFE_OUTPUT')
    base = json.loads(Path(args.r6_report).read_text())
    require(base['status'] == 'R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH',
            'R6_CONTROL_NOT_GREEN')
    require(sha(obj / '.config') == h.CONFIG_SHA and sha(obj / 'Module.symvers') == h.SYMVERS_SHA
            and sha(obj / 'arch/arm64/boot/Image') == base['image_sha256'], 'R6_CONTROL_CHANGED')
    guards = {n: sha(obj / n) for n in ('.config', 'Module.symvers', 'arch/arm64/boot/Image')}
    expected, imports = h.references()
    reference = h.parse_symvers(ROOT / 'References/R14_Module.symvers')
    _, _, old_counts = h.compare(reference, expected, imports)
    require(old_counts == {'MATCH': 583, 'CRC_MISMATCH': 840, 'NOT_EXPORTED': 0}, 'R14_NOT_AUTHENTIC')
    before = r12.config_values((ROOT / 'References/R14.config').read_text())
    commands = {row['target']: row['invocation'] for row in base['make_results']}
    require(set(commands) == {'Image', 'dtbs', 'modules'}, 'BASELINE_COMMANDS_MISSING')
    out.mkdir(parents=True)
    result = dict(status='R15_BUILD_PENDING', kernel_compiled=False, vendor_abi_proven=False,
                  flash_allowed=False, device_boot_tested=False, make_results=[],
                  baseline_verified_run=43366456014, baseline_r14_qgki_counts=old_counts,
                  rtmm_driver_enabled=False, rtmm_functionality_restored=False)
    try:
        candidate, candidate_out = out / 'candidate-source', out / 'candidate-out'
        shutil.copytree(src, candidate, ignore=shutil.ignore_patterns('.git'), symlinks=True)
        candidate_out.mkdir()
        shutil.copyfile(obj / '.config', candidate_out / '.config')
        result['r11_iommu'] = h.apply_scoped(candidate, h.generated_patches())
        result['r11_dependencies'] = h.audit_dependencies(candidate)
        result['r12_spf'] = r12.apply_source(candidate)
        result['r13_cpu_exports'] = r13.apply_source(candidate)
        result['r14_oem'] = r14.apply_source(candidate)
        result['r15_layout'] = apply_source(candidate)
        request = subprocess.run(['bash', str(candidate / 'scripts/config'), '--file',
                                  str(candidate_out / '.config'), '-e', 'SPECULATIVE_PAGE_FAULT',
                                  '-e', 'HARDWARE_INFO', '-e', 'MM_STAT_UNRECLAIMABLE_PAGES'],
                                 text=True, capture_output=True)
        require(request.returncode == 0, 'CONFIG_REQUEST_FAILED:' + request.stderr)
        units = sorted(set(r12.object_targets(obj) + NEW_UNITS
                           + ['kernel/smp.o', 'lib/cpumask.o', 'sound/soc/soc-core.o',
                              'drivers/misc/hardware_info.o']))
        resolved_sha = None
        for target in ['olddefconfig'] + units + ['Image', 'dtbs', 'modules']:
            argv = list(commands.get(target, commands['Image']))
            require(argv[0] == 'make' and argv.count('-C') == 1
                    and argv[argv.index('-C') + 1] == str(src)
                    and argv.count('O=' + str(obj)) == 1, 'INVALID_BASELINE_INVOCATION')
            argv[argv.index('-C') + 1] = str(candidate)
            argv[argv.index('O=' + str(obj))] = 'O=' + str(candidate_out)
            argv[-1] = target
            row = h.run_make(argv, out, target.replace('/', '_'), r6.pinned_llvm_tool_env(argv))
            row['target'] = target
            result['make_results'].append(row)
            require(row['exit_code'] == 0, 'ARM64_BUILD_FAILED:' + target)
            if target == 'olddefconfig':
                result['config_delta_against_r14'] = verify_config(before,
                    r12.config_values((candidate_out / '.config').read_text()))
                resolved_sha = sha(candidate_out / '.config')
            require(sha(candidate_out / '.config') == resolved_sha, 'CONFIG_DRIFT')
        require(r6.is_arm64_image(candidate_out / 'arch/arm64/boot/Image')
                and r6.is_arm64_elf(candidate_out / 'vmlinux'), 'NOT_AN_ARM64_KERNEL')
        result['kernel_compiled'] = True
        result['release'] = r6.verify_generated_release(candidate_out)
        result['rmnet_initcalls'] = r6.prove_real_linked_initcalls(candidate_out / 'System.map')
        result['real_build_log'] = r6.prove_build_log(out / 'Image.log')
        require(result['real_build_log']['linker_warning_free'], 'LINKER_WARNINGS')
        actual = h.parse_symvers(candidate_out / 'Module.symvers')
        symbols, modules, counts = h.compare(actual, expected, imports)
        h.save_csv(out / 'QGKI_1423_SYMBOL_RESULTS.csv', symbols)
        h.save_csv(out / 'QGKI_37_MODULE_RESULTS.csv', modules)
        result['qgki_counts'] = counts
        result['module_layout_crc'] = actual.get('module_layout')
        result['fully_matching_modules'] = sum(row['fully_compatible'] for row in modules)
        result['linked_cpu_exports'] = r13.prove_linked_exports(candidate_out / 'System.map')
        result['linked_oem_exports'] = r14.prove_linked(candidate_out / 'System.map')
        result['abi_progress'] = verify_abi(actual, reference, expected)
        result['source_postimage_hashes'] = {n: sha(candidate / n) for n in pins()}
        result['kernel_product_hashes'] = {n: sha(candidate_out / n) for n in
            ('.config', 'Module.symvers', 'arch/arm64/boot/Image', 'vmlinux')}
        result['status'] = 'R15_FULL_ARM64_BUILD_AND_STOCK_MODULE_LAYOUT_PROVEN_NOFLASH'
    except Exception as error:
        result.update(status='R15_BUILD_OR_ABI_GATE_FAILED_NOFLASH', error=str(error))
        raise
    finally:
        result['r6_baseline_unchanged'] = all(sha(obj / n) == digest for n, digest in guards.items())
        write_json(out / 'R15_RESULT.json', result)
    require(result['r6_baseline_unchanged'], 'R6_BASELINE_MUTATED')
    print(result['status'], result['qgki_counts'], 'RTMM_IMPLEMENTATION=UNAVAILABLE FLASH=NO')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='operation', required=True)
    sub.add_parser('verify-package')
    for operation in ('patch-source', 'check-source', 'check-baseline'):
        sub.add_parser(operation).add_argument('--source', required=True)
    bp = sub.add_parser('build')
    for name in ('source', 'objout', 'r6-report', 'r6-tool', 'project', 'output'):
        bp.add_argument('--' + name, required=True)
    args = parser.parse_args()
    verify_package()
    if args.operation == 'verify-package':
        print('R15_REAL_SOURCE_AND_PRIOR_REPAIRS_AUTHENTICATED')
    elif args.operation == 'patch-source':
        print(json.dumps(apply_source(args.source), sort_keys=True))
    elif args.operation.startswith('check-'):
        print(json.dumps(check_source(args.source, args.operation == 'check-baseline'), sort_keys=True))
    else:
        build(args)


if __name__ == '__main__':
    main()
