#!/usr/bin/env python3
"""Restore authenticated large dependencies for the small R15 upload package."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
RECIPE_COMMIT = 'b0647d5939f11887f651590852bb356ec1590988'
DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
RECIPE_BASE = ('https://raw.githubusercontent.com/Chrizz100/'
               'veux-nongki-universal-kernel/' + RECIPE_COMMIT + '/')
DONOR_BASE = ('https://raw.githubusercontent.com/dereference23/'
              'kernel_xiaomi_sm6375/' + DONOR_COMMIT + '/')


def require(ok, reason):
    if not ok:
        raise ValueError(reason)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def download(url, path, expected_sha, max_size):
    require(not path.exists(), 'DOWNLOAD_TARGET_ALREADY_EXISTS:' + str(path))
    request = urllib.request.Request(url, headers={'User-Agent': 'VEUX-R15-source-bootstrap'})
    with urllib.request.urlopen(request, timeout=60) as response:
        require(response.geturl().startswith('https://'), 'NON_HTTPS_REDIRECT')
        data = response.read(max_size + 1)
    require(len(data) <= max_size and digest(data) == expected_sha,
            'PINNED_DOWNLOAD_HASH_MISMATCH:' + path.name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def patch(source, patch_path, historical_reference=False):
    for flags in (['--check'], []):
        # Original Module.symvers rows end with a tab; preserve those exact
        # reference bytes. Kernel source changes retain strict whitespace checks.
        whitespace = '--whitespace=nowarn' if historical_reference else '--whitespace=error'
        result = subprocess.run(['git', 'apply', whitespace, *flags, str(patch_path)],
                                cwd=source, text=True, capture_output=True)
        require(result.returncode == 0, 'AUTHENTICATED_PATCH_FAILED:' + result.stderr)


def main():
    pins = json.loads((ROOT / 'References/REHYDRATED_FILE_SHA256.json').read_text())
    expected_files = set(pins)
    require(len(expected_files) == 23, 'HYDRATION_SCOPE_CHANGED')
    for name in expected_files:
        p = Path(name)
        require(not p.is_absolute() and '..' not in p.parts and not (ROOT / p).exists(),
                'HYDRATION_TARGET_ALREADY_EXISTS:' + name)
    # This ZIP already exists in the user's repository at the immutable commit.
    dep_name = 'Dependencies/R14_R2_MAIN.zip'
    download(RECIPE_BASE + 'VEUX_R46_R14_R2_LTO_CFI_AUDIT_MAIN.zip',
             ROOT / dep_name, pins[dep_name], 17_000_000)
    spec = importlib.util.spec_from_file_location('r15_small_repair', ROOT / 'Tools/restore_layout.py')
    repair = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(repair)
    r14 = repair.dependency()
    _, r12, _ = r14.dependency()
    files = json.loads((ROOT / 'References/FILE_PINS.json').read_text())

    with tempfile.TemporaryDirectory(prefix='r15-source-bootstrap-') as temp:
        stage = Path(temp)
        # Reproduce the exact four R12 files after the already-proven SPF port.
        spf = stage / 'spf'
        shutil.copytree(r12.ROOT / 'Original_R11', spf)
        r12.apply_source(spf)
        r12_files = r12.pins()
        original = stage / 'original'
        for name in sorted(files):
            out = original / name
            out.parent.mkdir(parents=True, exist_ok=True)
            expected = pins['Original_R14/' + name]
            if name in r12_files:
                shutil.copyfile(spf / name, out)
            elif name == 'include/linux/sched.h':
                with tarfile.open(r14.ROOT / 'References/R13_COMPILED_HEADERS.tar.xz') as archive:
                    members = [m for m in archive.getmembers()
                               if m.name.lstrip('./') == 'include/linux/sched.h']
                    require(len(members) == 1 and members[0].isfile()
                            and members[0].size < 100_000, 'SCHED_HEADER_ARCHIVE_SCOPE')
                    out.write_bytes(archive.extractfile(members[0]).read())
            else:
                download(DONOR_BASE + name, out, expected, 500_000)
            require(digest(out.read_bytes()) == expected, 'ORIGINAL_SOURCE_NOT_REPRODUCED:' + name)

        candidate = stage / 'candidate'
        shutil.copytree(original, candidate)
        patch(candidate, ROOT / 'References/RESTORE_STOCK_MODULE_LAYOUT.patch')
        for name in files:
            require(digest((candidate / name).read_bytes()) == pins['Candidate_R15/' + name],
                    'CANDIDATE_SOURCE_NOT_REPRODUCED:' + name)

        # Reconstruct read-only historical comparison inputs, never kernel outputs.
        # Their exact R14 hashes are checked before the build verifier uses them.
        references = stage / 'reference-replay'
        (references / 'References').mkdir(parents=True)
        for old, new in [('R13.config', 'R14.config'), ('R13_Module.symvers', 'R14_Module.symvers')]:
            shutil.copyfile(r14.ROOT / 'References' / old, references / 'References' / new)
        patch(references, ROOT / 'References/RECREATE_VERIFIED_R14_REFERENCES.patch',
              historical_reference=True)
        for name in ('References/R14.config', 'References/R14_Module.symvers'):
            require(digest((references / name).read_bytes()) == pins[name],
                    'HISTORICAL_R14_REFERENCE_NOT_REPRODUCED:' + name)
        shutil.copytree(original, ROOT / 'Original_R14')
        shutil.copytree(candidate, ROOT / 'Candidate_R15')
        for name in ('References/R14.config', 'References/R14_Module.symvers'):
            shutil.copyfile(references / name, ROOT / name)

    for name, expected in pins.items():
        require(digest((ROOT / name).read_bytes()) == expected, 'HYDRATED_FILE_CHANGED:' + name)
    repair.verify_package()
    print('R15_SMALL_UPLOAD_FULL_SOURCES_AND_REFERENCES_RECONSTRUCTED_BYTE_EXACTLY')
    print('R15_KERNEL_REPAIR_UNCHANGED; 10_SOURCE_FILES_IDENTICAL; NO_KERNEL_BUILT; FLASH=NO')


if __name__ == '__main__':
    main()
