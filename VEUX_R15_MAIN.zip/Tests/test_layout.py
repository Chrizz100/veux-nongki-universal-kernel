import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('layout_under_test', ROOT / 'Tools/restore_layout.py')
repair = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(repair)


class LayoutTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.source = Path(self.temp.name) / 'source'
        shutil.copytree(ROOT / 'Original_R14', self.source)

    def tearDown(self):
        self.temp.cleanup()

    def snapshot(self):
        return {str(p.relative_to(self.source)): p.read_bytes()
                for p in self.source.rglob('*') if p.is_file()}

    def test_complete_port_restores_real_layout_and_both_memory_counters(self):
        result = repair.apply_source(self.source)
        self.assertEqual(result['changed_files'], 10)
        for name, pin in repair.pins().items():
            self.assertEqual(repair.token_sha((self.source / name).read_text()), pin['after_tokens_sha256'])
        self.assertIn('NR_UNRECLAIMABLE_PAGES', (self.source / 'include/linux/mmzone.h').read_text())
        self.assertIn('"nr_unreclaimable_pages"', (self.source / 'mm/vmstat.c').read_text())
        self.assertIn('NAMED_ARRAY_INDEX(MM_UNRECLAIMABLE)', (self.source / 'kernel/fork.c').read_text())
        vmscan = (self.source / 'mm/vmscan.c').read_text()
        self.assertIn('DECLARE_RWSEM(shrinker_rwsem)', vmscan)
        self.assertNotIn('->del_rwsem', vmscan)
        self.assertFalse(result['rtmm_functionality_restored'])

    def test_late_drift_stops_before_any_file_is_changed(self):
        p = self.source / 'mm/vmstat.c'
        p.write_text(p.read_text() + '\nint unexpected_change;\n')
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, 'PREIMAGE_DRIFT'):
            repair.apply_source(self.source)
        self.assertEqual(before, self.snapshot())

    def test_header_token_drift_is_rejected(self):
        p = self.source / 'include/linux/sched.h'
        p.write_text(p.read_text().replace('u64', 'u32', 1))
        with self.assertRaisesRegex(ValueError, 'TOKEN_DRIFT'):
            repair.apply_source(self.source)

    def test_header_comments_survive_the_bounded_field_restoration(self):
        p = self.source / 'include/linux/sched.h'
        p.write_text('/* original comment retained */\n' + p.read_text())
        repair.apply_source(self.source)
        self.assertTrue(p.read_text().startswith('/* original comment retained */'))
        self.assertNotIn('#ifdef CONFIG_RTMM', p.read_text())
        self.assertIn('u64\t\t\t\tproc_load;', p.read_text())

    def test_symlink_cannot_redirect_a_source_write(self):
        p = self.source / 'include/linux/dcache.h'
        outside = Path(self.temp.name) / 'outside'
        outside.write_bytes(p.read_bytes())
        original = outside.read_bytes()
        p.unlink()
        p.symlink_to(outside)
        with self.assertRaisesRegex(ValueError, 'REGULAR_FILE'):
            repair.apply_source(self.source)
        self.assertEqual(outside.read_bytes(), original)

    def test_reapplication_is_rejected(self):
        repair.apply_source(self.source)
        with self.assertRaises(ValueError):
            repair.apply_source(self.source)

    def test_only_two_real_config_changes_are_allowed(self):
        r14 = repair.dependency()
        r12 = r14.dependency()[1]
        before = r12.config_values((ROOT / 'References/R14.config').read_text())
        after = dict(before, CONFIG_HAVE_HW_BREAKPOINT='y', CONFIG_MM_STAT_UNRECLAIMABLE_PAGES='y')
        self.assertEqual(repair.verify_config(before, after), repair.EXPECTED_CONFIG_DELTA)
        after['CONFIG_RTMM'] = 'y'
        with self.assertRaises(ValueError):
            repair.verify_config(before, after)

    def test_stock_module_layout_is_mandatory(self):
        expected = dict(repair.OEM, module_layout=repair.EXPECTED_LAYOUT)
        actual = dict(expected, module_layout='0x71c13c49')
        with self.assertRaisesRegex(ValueError, 'STOCK_MODULE_LAYOUT'):
            repair.verify_abi(actual, expected, expected)

    def test_no_previous_stock_match_may_be_lost(self):
        expected = dict(repair.OEM, module_layout=repair.EXPECTED_LAYOUT, existing='0x12345678')
        actual = dict(expected, existing='0x22222222')
        with self.assertRaisesRegex(ValueError, 'STOCK_MATCH_LOST'):
            repair.verify_abi(actual, expected, expected)

    def test_inherited_real_cohort_and_csv_contract(self):
        h = repair.dependency().dependency()[2]
        expected, imports = h.references()
        actual = h.parse_symvers(ROOT / 'References/R14_Module.symvers')
        rows, modules, counts = h.compare(actual, expected, imports)
        self.assertEqual(counts, {'MATCH': 583, 'CRC_MISMATCH': 840, 'NOT_EXPORTED': 0})
        self.assertEqual(len(rows), 1423)
        self.assertEqual(len(modules), 37)
        self.assertTrue(all(isinstance(r['fully_compatible'], bool) for r in modules))
        h.save_csv(Path(self.temp.name) / 'symbols.csv', rows)
        with self.assertRaisesRegex(ValueError, 'STOCK_MODULE_LAYOUT'):
            repair.verify_abi(actual, actual, expected)

    def test_early_baseline_guard_accounts_for_prior_spf_restoration(self):
        r12 = repair.dependency().dependency()[1]
        for name in repair.pins():
            original = r12.ROOT / 'Original_R11' / name
            if original.is_file():
                shutil.copyfile(original, self.source / name)
        result = repair.check_source(self.source, baseline=True)
        self.assertEqual(result['files_verified'], 10)
        self.assertFalse(result['source_changed'])


if __name__ == '__main__':
    unittest.main()
