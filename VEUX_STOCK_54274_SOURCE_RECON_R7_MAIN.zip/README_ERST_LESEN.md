VEUX STOCK/stocknah 5.4.274 – R7 Kontrollierte ABI-Delta-Probe
===============================================================
BASIS: Run 42031451479 (R6), authentisch gepinnte historische OEM-Imports
VERSION: Spender-Quellbaum 5.4.268, KEIN neu erzeugter echter Xiaomi 5.4.274 Source.
ZIEL: Prüfen, ob GENAU EINE originale im 5.4.274-Image enthaltene Headerdatei
(include/linux/device.h, 44309 Bytes) einen reproduzierbaren QGKI-ABI-Effekt hat.

* R7 verwendet den echten R6 Module.symvers+Report aus dem Originalartefakt,
  statt erneut ohne Änderung 25 Minuten den R6-Kernel zu kompilieren.
* Stock-Header nur in isoliertem R4/R5 Git-Worktree; kein Produktionspatch.
* Clang-r383902b1 (11.0.2), gleicher Spendercommit, identische .config.
* Vollständige NEUE ARM64-Kompilierung, danach Symbol-CRC-Delta pro QGKI/GKI-Modul.
* Bei Compilerfehlern: Diagnose, KEINE vorgetäuschte ABI-Verbesserung.
* Auch wenn CRCs passen, beweist das weder sichere Kernelstrukturen noch ABI-/Bootfunktion.
* PRODUKTION=NEIN, FLASH=NEIN, kein boot.img, kein AK3, keine Änderungen an root-Installationen.
* NUR Reports, hashes und Module.symvers; keine Systempartitionen geändert.

FILES: MAIN-ZIP in Repo-Root, YAML in .github/workflows/ .
R1/R2/R4/R5/R6 MAIN-Dateien müssen in der Repo verbleiben.
Dokumentierte Original-R6-Basis: https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42031451479
