import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import tarfile
import unittest
from unittest import mock

DIR=Path(__file__).resolve().parent
sp=importlib.util.spec_from_file_location('r7_trial',str(DIR/'r7_trial.py'))
r7=importlib.util.module_from_spec(sp);sp.loader.exec_module(r7)
TEST_ROOT=DIR if (DIR/'reference').is_dir() else DIR.parent
BASE=TEST_ROOT/'reference'
R6_TOOL=os.getenv('VEUX_R7_R6_TOOL',str(TEST_ROOT/'tools/r6_abi.py'))
IMPORTS=os.getenv('VEUX_R7_IMPORTS',str(BASE/'OEM_R21_IMPORTS.csv'))


class R7Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=None
        if os.getenv('VEUX_R7_R1_DIR'):
            cls.r1=Path(os.environ['VEUX_R7_R1_DIR'])
            return
        import zipfile
        outer=zipfile.ZipFile('/mnt/data/VEUX_STOCK_54274_SOURCE_RECON_R1_MAIN_UND_YAML_NEU.zip')
        import io
        inner=zipfile.ZipFile(io.BytesIO(outer.read('VEUX_STOCK_54274_SOURCE_RECON_R1_MAIN.zip')))
        cls.tmp=tempfile.TemporaryDirectory()
        cls.r1=Path(cls.tmp.name)
        (cls.r1/'reference').mkdir()
        (cls.r1/'reference/stock_kheaders.tar.xz').write_bytes(inner.read('reference/stock_kheaders.tar.xz'))

    @classmethod
    def tearDownClass(cls):
        if cls.tmp is not None:cls.tmp.cleanup()

    def test_01_verified_stock_header(self):
        b=r7.stock_header(self.r1)
        self.assertEqual(len(b),44309)
        self.assertEqual(r7.sha(b),r7.STOCK_HEADER_SHA)
        self.assertIn(b'struct device',b)

    def test_02_corrupted_archive_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'reference';p.mkdir()
            (p/'stock_kheaders.tar.xz').write_bytes(b'fake')
            with self.assertRaisesRegex(ValueError,'KHEADERS_ORIGIN_DRIFT'):r7.stock_header(d)

    def test_03_symlink_stock_archive_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'reference';p.mkdir()
            (p/'stock_kheaders.tar.xz').symlink_to(self.r1/'reference/stock_kheaders.tar.xz')
            with self.assertRaisesRegex(ValueError,'KHEADERS_ORIGIN_DRIFT'):r7.stock_header(d)

    def test_04_separate_stage_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'NOT_SEPARATE'):r7.check_original(d,d)
            nested=Path(d)/'inner';nested.mkdir()
            with self.assertRaisesRegex(ValueError,'NOT_SEPARATE'):r7.check_original(d,nested)

    def _args(self,temp,rc='0',candidate=None):
        from types import SimpleNamespace
        root=Path(temp)
        (root/'rc').write_text(rc)
        (root/'build.log').write_text('  CC foo.o\n  LD vmlinux\n  OBJCOPY Image\n')
        (root/'Image').write_bytes(b'Image test bytes, not actual kernel image')
        cand=root/'symvers'
        cand.write_bytes(Path(BASE/'R6_COMPILED_CANDIDATE_Module.symvers').read_bytes() if candidate is None else candidate)
        return SimpleNamespace(r6_tool=R6_TOOL,imports=IMPORTS,
              baseline_report=str(BASE/'R6_CANDIDATE_ABI_REPORT.json'),baseline_symvers=str(BASE/'R6_COMPILED_CANDIDATE_Module.symvers'),
              candidate_symvers=str(cand),image=str(root/'Image'),rc_file=str(root/'rc'),build_log=str(root/'build.log'),reports=str(root/'out'))

    def test_05_baseline_full_14648_recomputed_zero_delta(self):
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d); report=r7.summary(a)
            self.assertTrue(report['abi_compared'])
            self.assertEqual(report['QGKI']['R6_match'],1470)
            self.assertEqual(report['QGKI']['R7_match'],1470)
            self.assertEqual(report['GKI']['R6_match'],5485)
            self.assertEqual(report['GKI']['delta_match'],0)
            self.assertFalse(report['vendor_abi_approved'])
            self.assertFalse(report['flash_allowed'])

    def test_06_qgki_api_change_measured_not_promoted(self):
        syms=Path(BASE/'R6_COMPILED_CANDIDATE_Module.symvers').read_text()
        self.assertIn('0x3eb190bf\t_dev_err',syms)
        altered=syms.replace('0x3eb190bf\t_dev_err','0x321e7cb7\t_dev_err')
        self.assertNotEqual(syms,altered)
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d,candidate=altered.encode());report=r7.summary(a)
            self.assertEqual(report['QGKI']['delta_match'],26)
            self.assertEqual(report['GKI']['delta_match'],0)
            self.assertFalse(report['production_patch_approved'])
            self.assertTrue(report['observed_qgki_import_improvement'])

    def test_07_compile_failure_blocks_comparison(self):
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d,rc='2');p=Path(a.build_log);p.write_text("fatal error: header not found\nLLVM ERROR: IO failure on output stream: Broken pipe\n")
            report=r7.summary(a);self.assertFalse(report['abi_compared']);self.assertFalse(report['flash_allowed']);self.assertEqual(report['compiler_errors_count'],1);self.assertEqual(report['llvm_broken_pipe_count'],1)

    def test_08_corrupt_baseline_symvers_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d);a.baseline_symvers=str(Path(d)/'wrong')
            Path(a.baseline_symvers).write_text('tampered')
            with self.assertRaisesRegex(ValueError,'BASELINE_SYMVERS_DRIFT'):r7.summary(a)

    def test_09_corrupt_proof_report_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d);p=Path(d)/'bad.json';b=json.loads(Path(a.baseline_report).read_text());b['candidate_symvers_sha256']='0'*64;p.write_text(json.dumps(b));a.baseline_report=str(p)
            with self.assertRaisesRegex(ValueError,'BASELINE_REPORT_DRIFT'):r7.summary(a)

    def test_10_bad_rc_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            a=self._args(d,rc='a trick')
            with self.assertRaisesRegex(ValueError,'BAD_COMPILER_EXIT_CODE'):r7.summary(a)

    def test_11_unresolved_source_never_flash(self):
        self.assertNotIn('production_patch_approved\':True',Path(DIR/'r7_trial.py').read_text())
        self.assertEqual(r7.DONOR_COMMIT,'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632')


if __name__=='__main__':unittest.main()
