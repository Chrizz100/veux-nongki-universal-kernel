#!/usr/bin/env python3
"""VEUX R7: exact stock-header provenance + controlled ABI delta probe.

NEVER a production source patch. NEVER authorizes flashing or OEM module loads.
"""
import argparse
import csv
import hashlib
import importlib.util
import io
import json
import os
import re
import stat
import subprocess
import sys
import tarfile
from collections import Counter, defaultdict
from pathlib import Path

STOCK_HEADER = 'include/linux/device.h'
STOCK_HEADER_TAR = 'reference/stock_kheaders.tar.xz'
STOCK_HEADER_SHA = 'dc28c43819628f359cc3776b53a4b0a09e4cc99e321d08d25b23ab81df6eb027'
STOCK_HEADER_BYTES = 44309
STOCK_KHEADERS_SHA = '39be17eec6033eb154baaf71a77ce17db0d998043301b9e3dd5cf060b2cad279'
DONOR_HEADER_GIT_BLOB = '3937c1c06f9c152e6272743d1536303b9eea09df'
DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
BASELINE_SYMVERS_SHA = 'd0cce8b3920dd22ab6eafc6c68e6bfb6dd1e4635835e2d6c4a5ad798bf0761e3'
R6_IMAGE_SHA = 'c54cb61c6bc1b1f815ce9a3ded00c698aeb6ce67467fbceeb9e4c2596ed71416'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def disk_sha(path):
    return sha(Path(path).read_bytes())


def git(args):
    p = subprocess.run(['git', *args], capture_output=True, text=True, check=True)
    return p.stdout.strip()


def stock_header(r1):
    archive = Path(r1) / STOCK_HEADER_TAR
    if archive.is_symlink() or not archive.is_file() or disk_sha(archive) != STOCK_KHEADERS_SHA:
        raise ValueError('R7_STOCK_KHEADERS_ORIGIN_DRIFT')
    matching = []
    with tarfile.open(archive, 'r:xz') as t:
        for entry in t:
            if entry.name.removeprefix('./') == STOCK_HEADER:
                if not entry.isfile() or entry.size != STOCK_HEADER_BYTES:
                    raise ValueError('R7_STOCK_HEADER_TYPE_SIZE_DRIFT')
                matching.append(t.extractfile(entry).read())
    if len(matching) != 1 or sha(matching[0]) != STOCK_HEADER_SHA:
        raise ValueError('R7_STOCK_HEADER_BYTES_DRIFT')
    return matching[0]


def check_original(donor, stage):
    donor, stage = Path(donor).resolve(), Path(stage).resolve()
    if donor == stage or donor in stage.parents or stage in donor.parents:
        raise ValueError('R7_DONOR_STAGE_NOT_SEPARATE')
    if git(['-C', str(donor), 'rev-parse', 'HEAD']) != DONOR_COMMIT:
        raise ValueError('R7_DONOR_COMMIT_DRIFT')
    if git(['-C', str(stage), 'rev-parse', 'HEAD']) != DONOR_COMMIT:
        raise ValueError('R7_STAGE_COMMIT_DRIFT')
    if git(['-C', str(donor), 'status', '--porcelain']):
        raise ValueError('R7_ORIGINAL_DONOR_MODIFIED')
    expected = git(['-C', str(donor), 'rev-parse', 'HEAD:'+STOCK_HEADER])
    if expected != DONOR_HEADER_GIT_BLOB:
        raise ValueError('R7_DONOR_BLOB_DRIFT')
    donor_header = donor / STOCK_HEADER
    stage_header = stage / STOCK_HEADER
    if donor_header.is_symlink() or stage_header.is_symlink():
        raise ValueError('R7_HEADER_SYMLINK_FORBIDDEN')
    if git(['-C', str(donor), 'hash-object', str(donor_header)]) != expected:
        raise ValueError('R7_DONOR_HEADER_CHANGED')
    if git(['-C', str(stage), 'hash-object', str(stage_header)]) != expected:
        raise ValueError('R7_STAGE_HEADER_NOT_ORIGINAL')
    return stage_header


def stage(args):
    b = stock_header(args.r1)
    p = check_original(args.donor, args.stage)
    if sha(p.read_bytes()) == STOCK_HEADER_SHA:
        raise ValueError('R7_STAGE_ALREADY_APPLIED')
    p.write_bytes(b)
    if disk_sha(p) != STOCK_HEADER_SHA:
        raise ValueError('R7_COPY_FAILED')
    if git(['-C', str(args.donor), 'status', '--porcelain']):
        raise ValueError('R7_ORIGINAL_DONOR_DIRTY_AFTER_COPY')
    changes = git(['-C', str(args.stage), 'diff', '--name-only'])
    if STOCK_HEADER not in changes.splitlines():
        raise ValueError('R7_STAGE_NOT_TRACKED_AS_MODIFIED')
    report = {'schema':'VEUX_R7_STOCK_HEADER_ABI_PROBE','stock_header':STOCK_HEADER,
              'stock_header_sha256':STOCK_HEADER_SHA,'stock_header_bytes':len(b),
              'donor_original_git_blob':DONOR_HEADER_GIT_BLOB,
              'donor_commit':DONOR_COMMIT,'stage_only':True,'original_donor_unchanged':True,
              'runtime_struct_layout_verified':False,'flash_allowed':False}
    out=Path(args.reports);out.mkdir(parents=True,exist_ok=True)
    (out/'R7_STOCK_HEADER_STAGE.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    print('R7_STOCK_DEVICE_HEADER_STAGED=PASS; ORIGINAL_DONOR=UNCHANGED; FLASH=NO')


def load_r6(path):
    spec=importlib.util.spec_from_file_location('r6_abi', str(Path(path).resolve()))
    if spec is None or spec.loader is None:
        raise ValueError('R7_R6_COMPARATOR_MISSING')
    lib=importlib.util.module_from_spec(spec);spec.loader.exec_module(lib)
    if lib.R28_SOURCE_SHA != 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394':
        raise ValueError('R7_R6_IMPORT_PIN_DRIFT')
    return lib


def classify_errors(log):
    lines=Path(log).read_text(encoding='utf-8',errors='replace').splitlines()
    hard=[x for x in lines if ('LLVM ERROR: IO failure on output stream: Broken pipe' not in x and re.search(r'(?:fatal\s+error:|\berror:|undefined reference|ld\.lld: error:)', x, re.I))]
    pipes=sum('LLVM ERROR: IO failure on output stream: Broken pipe' in s for s in lines)
    return hard[:200],len(hard),pipes,len(lines)


def summary(args):
    out=Path(args.reports);out.mkdir(parents=True,exist_ok=True)
    baseline_report=json.loads(Path(args.baseline_report).read_text())
    if baseline_report.get('schema')!='VEUX_STOCK_R6_CANDIDATE_ABI_EVIDENCE' or baseline_report.get('candidate_symvers_sha256')!=BASELINE_SYMVERS_SHA or baseline_report.get('candidate_image_sha256')!=R6_IMAGE_SHA:
        raise ValueError('R7_R6_BASELINE_REPORT_DRIFT')
    if disk_sha(args.baseline_symvers) != BASELINE_SYMVERS_SHA:
        raise ValueError('R7_R6_BASELINE_SYMVERS_DRIFT')
    try: rc=int(Path(args.rc_file).read_text().strip())
    except Exception as exc: raise ValueError('R7_BAD_COMPILER_EXIT_CODE') from exc
    errors,hard,pipes,lines=classify_errors(args.build_log)
    result={'schema':'VEUX_R7_ABI_EXPERIMENT','source_commit':DONOR_COMMIT,
            'source_release':'5.4.268','target_release':'5.4.274-qgki-g82179e362f33',
            'experiment':'replace ONLY include/linux/device.h with verified stock embedded header IN ISOLATED WORKTREE',
            'stock_header_sha256':STOCK_HEADER_SHA,'baseline_symvers_sha256':BASELINE_SYMVERS_SHA,
            'build_exit_code':rc,'compiler_errors_count':hard,'compiler_error_lines':errors[:30],
            'llvm_broken_pipe_count':pipes,'build_log_lines':lines,
            'vendor_abi_approved':False,'active_module_set_proven':False,
            'production_patch_approved':False,'boot_tested':False,'flash_allowed':False}
    if rc==0 and hard==0:
        lib=load_r6(args.r6_tool)
        imports=lib.parse_imports(args.imports)
        baseline,base_count=lib.parse_symvers(args.baseline_symvers)
        if baseline['module_layout']!={'0xcfa46a10'} or base_count!=baseline_report['candidate_symvers_exports']:
            raise ValueError('R7_R6_BASELINE_LAYOUT_OR_COUNT_DRIFT')
        candidate,candidate_count=lib.parse_symvers(args.candidate_symvers)
        candidate_sha=disk_sha(args.candidate_symvers)
        result['candidate_symvers_sha256']=candidate_sha
        result['candidate_exports']=candidate_count
        result['candidate_image_sha256']=disk_sha(args.image)
        result['abi_compared']=True
        modified_symbols=[]
        for cohort,rows in imports.items():
            old_results,old_totals,old_complete,old_mods=lib.evaluate(rows,baseline)
            new_results,new_totals,new_complete,new_mods=lib.evaluate(rows,candidate)
            if old_totals.get('MATCH',0)!=baseline_report[cohort]['match']:
                raise ValueError('R7_R6_RECOMPUTED_BASELINE_DRIFT:'+cohort)
            m1={x['path']:x for x in old_mods};m2={x['path']:x for x in new_mods}
            per_module=[]
            for name in sorted(m1):
                a,b=m1[name],m2[name]
                per_module.append([name,a['match'],b['match'],b['match']-a['match'],a['crc_mismatch'],b['crc_mismatch'],a['not_exported'],b['not_exported'],str(b['complete_match']).lower()])
            with (out/('R7_'+cohort+'_MODULE_DELTA.csv')).open('w',newline='') as f:
                w=csv.writer(f,lineterminator='\n');w.writerow(['module','R6_match','R7_match','delta_matches','R6_crc_mismatch','R7_crc_mismatch','R6_no_export','R7_no_export','R7_complete']);w.writerows(per_module)
            sym_report=defaultdict(lambda: Counter())
            for old,new in zip(old_results,new_results):
                if old[:3]!=new[:3]:raise ValueError('R7_IMPORT_ORDER_DRIFT')
                if old[-1]!=new[-1]:
                    c=sym_report[old[1]];c['changed']+=1;c['improved' if new[-1]=='MATCH' else 'regressed']+=1
            with (out/('R7_'+cohort+'_SYMBOL_CHANGES.csv')).open('w',newline='') as f:
                w=csv.writer(f,lineterminator='\n');w.writerow(['symbol','changed_imports','improved_to_match','regressed_from_match']);w.writerows([[s,c['changed'],c['improved'],c['regressed']] for s,c in sorted(sym_report.items(),key=lambda z:(-z[1]['changed'],z[0]))])
            result[cohort]={'R6_match':old_totals.get('MATCH',0), 'R7_match':new_totals.get('MATCH',0),'delta_match':new_totals.get('MATCH',0)-old_totals.get('MATCH',0),
                           'R6_crc_mismatch':old_totals.get('CRC_MISMATCH',0), 'R7_crc_mismatch':new_totals.get('CRC_MISMATCH',0),
                           'R6_not_exported':old_totals.get('NOT_EXPORTED',0),'R7_not_exported':new_totals.get('NOT_EXPORTED',0),
                           'R6_complete_module_files':old_complete,'R7_complete_module_files':new_complete,
                           'expected_module_layout':lib.EXPECTED[cohort][3],
                           'candidate_module_layout':sorted(candidate.get('module_layout',set()))}
        result['observed_qgki_import_improvement']=result['QGKI']['delta_match']>0
        result['interpretation']='ABI DELTA ONLY. A matching CRC does NOT prove driver safety, and the stock module source remains unverified.'
    else:
        result['abi_compared']=False
        result['status']='COMPILATION_BLOCKED_NO_ABI_CLAIMS'
    (out/'R7_ABI_EXPERIMENT_RESULT.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps({k:result.get(k) for k in ('build_exit_code','compiler_errors_count','abi_compared','QGKI','GKI','vendor_abi_approved','flash_allowed')},sort_keys=True))
    return result


def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='operation',required=True)
    s=sub.add_parser('stage')
    for x in ['r1','donor','stage','reports']:s.add_argument('--'+x,required=True)
    s=sub.add_parser('summary')
    for x in ['r6_tool','imports','baseline_report','baseline_symvers','candidate_symvers','image','rc_file','build_log','reports']:
        s.add_argument('--'+x.replace('_','-'),required=True)
    args=p.parse_args()
    if args.operation=='stage': stage(args)
    else: summary(args)

if __name__=='__main__':main()
