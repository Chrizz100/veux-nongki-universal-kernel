#!/usr/bin/env python3
"""Restore RTMM and process reclaim on the authenticated green R23 build path."""
import argparse,hashlib,importlib.util,json,re,subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
FLAGS=('CONFIG_RTMM','CONFIG_PROCESS_RECLAIM')
UNITS=('drivers/staging/rtmm/rtmm_main','drivers/staging/rtmm/rtmm_reclaim',
       'mm/rmap','mm/vmscan','fs/proc/task_mmu','fs/proc/base')
STATUS='R24_FULL_RTMM_PROCESS_RECLAIM_1423_CRCS_37_MODULES_STOCK_RELEASE_PASS_NOFLASH'

def require(ok,message):
    if not ok:raise ValueError(message)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
    return h.hexdigest()

def profile():return json.loads((ROOT/'References/PROFILE.json').read_text())
def pins():return json.loads((ROOT/'References/SOURCE_PINS.json').read_text())
def config_values(text):
    values={}
    for line in text.splitlines():
        if line.startswith('CONFIG_'):key,value=line.split('=',1)
        elif line.startswith('# CONFIG_')and line.endswith(' is not set'):key,value=line[2:-11],'n'
        else:continue
        require(key not in values,'DUPLICATE_CONFIG:'+key);values[key]=value
    return values

def normalize_memory(values):
    require(all(values.get(n)=='y'for n in FLAGS),'REAL_RTMM_AND_PROCESS_PROVIDERS_MUST_BE_BUILTIN')
    old=dict(values)
    for n in FLAGS:del old[n]
    digest=hashlib.sha256(json.dumps(old,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    require(digest==profile()['baseline_config_values_sha256'],'CONFIG_CHANGED_OUTSIDE_TWO_MEMORY_KEYS')
    return old

def verify_package():
    names=set()
    for line in(ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest,name=line.split('  ',1);p=Path(name)
        require(not p.is_absolute()and'..'not in p.parts and name not in names,'UNSAFE_MANIFEST')
        require(not(ROOT/p).is_symlink()and sha(ROOT/p)==digest,'PACKAGE_FILE_CHANGED:'+name);names.add(name)
    actual={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()
            and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt'}
    require(actual==names and len(pins())==16,'PACKAGE_SCOPE_CHANGED')
    for name,pin in pins().items():
        require(sha(ROOT/'After'/name)==pin['after_sha256'],'AFTER_FIXTURE_CHANGED:'+name)
        if pin['before_sha256']is not None:
            require(sha(ROOT/'Before'/name)==pin['before_sha256'],'BEFORE_FIXTURE_CHANGED:'+name)

def source_check(source,after=False):
    source=Path(source).resolve(strict=True);result={}
    for name,pin in pins().items():
        path=source/name
        require(all(not p.is_symlink()for p in [path,*path.parents]if p.is_relative_to(source)),
                'SOURCE_SYMLINK:'+name)
        expected=pin['after_sha256'if after else'before_sha256']
        if expected is None:
            require(not path.exists(),'NEW_SOURCE_ALREADY_EXISTS:'+name);result[name]=None
        else:
            require(path.is_file(),'SOURCE_MISSING:'+name);result[name]=sha(path)
            require(result[name]==expected,'SOURCE_CONTEXT_CHANGED:'+name)
    return result

def apply_source(source):
    source=Path(source).resolve(strict=True);source_check(source)
    # Complete preflight precedes the first candidate-source write.
    for name in pins():
        path=source/name;path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes((ROOT/'After'/name).read_bytes())
    return source_check(source,after=True)

def request_memory(source,config):
    source=Path(source);require(sha(source/'scripts/config')==profile()['scripts_config_sha256'],
                               'SCRIPTS_CONFIG_CHANGED')
    args=['bash',str(source/'scripts/config'),'--file',str(config)]
    for n in FLAGS:args+=['--enable',n.removeprefix('CONFIG_')]
    p=subprocess.run(args,text=True,capture_output=True)
    require(p.returncode==0,'MEMORY_CONFIG_REQUEST_FAILED:'+p.stderr)
    return {'only_new_requested_keys':list(FLAGS),'defconfig_modified':False}

def load_parent(path):
    path=Path(path).resolve(strict=True)
    require(sha(path)==profile()['r23_tool_sha256'],'AUTHENTIC_R23_TOOL_CHANGED')
    spec=importlib.util.spec_from_file_location('r24_authentic_r23',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.verify_package();return module

def linked_proof(text):
    patterns={'rtmm_initcall':r'__initcall_\S*rtmm_init4(?:\.llvm\.\S+)?',
              'proc_reclaim_operations':r'proc_reclaim_operations(?:\.llvm\.\S+)?',
              'rtmm_pmd_callback':r'rtmm_reclaim_pte_range(?:[.$]\S+)?'}
    result={}
    for key,pattern in patterns.items():
        matches=re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+('+pattern+r')$',text)
        require(matches,'MEMORY_PROVIDER_NOT_LINKED:'+key);result[key]=sorted(set(matches))
    return result

def memory_proof(build):
    build=Path(build).resolve(strict=True);out=build/'candidate-out'
    values=config_values((out/'.config').read_text());normalize_memory(values)
    sources=source_check(build/'candidate-source',after=True);objects={}
    for unit in UNITS:
        obj=out/(unit+'.o');cmd=obj.parent/('.'+obj.name+'.cmd')
        with obj.open('rb')as f:magic=f.read(4)
        require(magic in(b'BC\xc0\xde',b'\xde\xc0\x17\x0b'),'PROVIDER_OBJECT_NOT_LLVM_BITCODE:'+unit)
        text=cmd.read_text()
        require(unit+'.c'in text and'-flto=thin'in text and'-fsanitize=cfi'in text,
                'REAL_PROVIDER_CFI_COMMAND_MISSING:'+unit)
        objects[unit]={'object_sha256':sha(obj),'command_sha256':sha(cmd)}
    return {'only_new_config_changes_against_actual_R23':{n:[None,'y']for n in FLAGS},
            'provider_source_hashes':sources,'provider_objects':objects,
            'linked_memory_interfaces':linked_proof((out/'System.map').read_text()),
            'System_map_sha256':sha(out/'System.map')}

def write_result(out,name,result):
    if out.is_dir():(out/name).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')

def build(args):
    verify_package();parent=load_parent(args.r23_tool)
    original_request,original_normalize=parent.request_fingerprint,parent.normalize_fingerprint
    out=Path(args.output).resolve()
    result={'status':'R24_BUILD_PENDING','kernel_compiled':False,'device_pass':False,'flash_allowed':False,
            'baseline_run':profile()['baseline_run'],'rtmm_provider_chain_compiled_and_linked':False,
            'runtime_memory_functionality_tested':False,
            'legacy_report_config_scope':'R21 release and R23 fingerprint subreports normalize the two explicit R24 memory keys. R24_RESULT contains the measured complete new delta.'}
    def request(source,config):
        old=original_request(source,config)
        result['applied_provider_source_hashes']=apply_source(source)
        result['memory_config_request']=request_memory(source,config)
        return dict(old,memory_request=result['memory_config_request'])
    def normalize(values):return original_normalize(normalize_memory(values))
    parent.request_fingerprint,parent.normalize_fingerprint=request,normalize
    try:
        parent.build(args)
        legacy=json.loads((out/'R23_RESULT.json').read_text())
        require(legacy['status']==parent.STATUS and legacy['kernel_compiled']is True
                and legacy['fully_matching_modules']==37 and legacy['all_1423_import_crcs_match']is True,
                'R23_FULL_BUILD_FINGERPRINT_AND_ABI_GATES_REQUIRED')
        result.update(memory_proof(out))
        require(result['provider_source_hashes']==result['applied_provider_source_hashes'],
                'PROVIDER_SOURCE_CHANGED_DURING_BUILD')
        for n,h in legacy['kernel_product_hashes'].items():
            require(sha(out/'candidate-out'/n)==h,'FULL_BUILD_PRODUCT_CHANGED:'+n)
        result.update(status=STATUS,kernel_compiled=True,rtmm_provider_chain_compiled_and_linked=True,fully_matching_modules=37,
            qgki_counts=legacy['qgki_counts'],all_1423_import_crcs_match=True,
            kernel_product_hashes=legacy['kernel_product_hashes'],release=legacy['release'])
    except Exception as error:
        result.update(status='R24_BUILD_OR_MEMORY_PROVIDER_GATE_FAILED_NOFLASH',error=str(error));raise
    finally:
        parent.request_fingerprint,parent.normalize_fingerprint=original_request,original_normalize
        write_result(out,'R24_RESULT.json',result)
    print(result['status'],'DEVICE_PASS=NO FLASH=NO')

def verify_fresh(build):
    build=Path(build).resolve(strict=True);r=json.loads((build/'R24_RESULT.json').read_text())
    require(r.get('status')==STATUS and r.get('kernel_compiled')is True
            and r.get('device_pass')is False and r.get('flash_allowed')is False
            and r.get('rtmm_provider_chain_compiled_and_linked')is True
            and r.get('runtime_memory_functionality_tested')is False,'FRESH_R24_FULL_BUILD_REQUIRED')
    actual=memory_proof(build);require(all(r.get(k)==v for k,v in actual.items()),'MEMORY_PROOF_CHANGED')
    require(r['qgki_counts']=={'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0}
            and r['fully_matching_modules']==37,'OEM_MODULE_COHORT_CHANGED')
    for n,h in r['kernel_product_hashes'].items():
        require(sha(build/'candidate-out'/n)==h,'MEMORY_KERNEL_PRODUCT_CHANGED:'+n)
    return r

def package(args):
    verify_package();r=verify_fresh(args.build);parent=load_parent(args.r23_tool)
    original_normalize=parent.normalize_fingerprint
    parent.normalize_fingerprint=lambda values:original_normalize(normalize_memory(values))
    try:parent.package(args)
    finally:parent.normalize_fingerprint=original_normalize
    out=Path(args.output).resolve(strict=True)
    prior=json.loads((out/'R23_PACKAGE_RESULT.json').read_text())
    require(prior['static_boot_path_pass']is True and prior['device_pass']is False,
            'STATIC_BOOT_AK3_PAIR_NOT_PROVEN')
    pair={}
    for p in sorted((out/'review').iterdir()):
        require(p.is_file()and p.name.startswith('VEUX_R23_'),'UNEXPECTED_REVIEW_FILE')
        q=p.with_name(p.name.replace('VEUX_R23_','VEUX_R24_',1));require(not q.exists(),'REVIEW_TARGET_EXISTS')
        p.rename(q);pair[q.name]=sha(q)
    require(len(pair)==2 and any(n.endswith('_boot.img')for n in pair)
            and any(n.endswith('_AK3.zip')for n in pair),'COMPLETE_PAIR_REQUIRED')
    verify_fresh(args.build)
    write_result(out,'R24_PACKAGE_RESULT.json',{'status':'R24_STATIC_BOOT_AK3_PAIR_PASS_DEVICE_UNTESTED_NOFLASH',
        'static_boot_path_pass':True,'device_pass':False,'flash_allowed':False,
        'review_pair_sha256':pair,'image_sha256':prior['image_sha256'],
        'kernel_release':r['release']['verified_release'],'underlying_container_evidence':'R21_PACKAGE_RESULT.json'})
    print('R24_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')

def main():
    p=argparse.ArgumentParser(description=__doc__);s=p.add_subparsers(dest='op',required=True)
    s.add_parser('verify-package');c=s.add_parser('check-source');c.add_argument('--source',required=True)
    b=s.add_parser('build')
    for n in ('r23-tool','r21-tool','r19-tool','r18-tool','r17-tool','base-tool','source','objout',
              'r6-report','r6-tool','project','output'):b.add_argument('--'+n,required=True)
    a=s.add_parser('package')
    for n in ('r23-tool','r21-package-tool','build','packager-tool','work','output'):a.add_argument('--'+n,required=True)
    args=p.parse_args();verify_package()
    if args.op=='build':build(args)
    elif args.op=='package':package(args)
    elif args.op=='check-source':print(json.dumps(source_check(args.source)))
    else:print('R24_PACKAGE_VERIFIED FULL_KERNEL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')

if __name__=='__main__':main()
