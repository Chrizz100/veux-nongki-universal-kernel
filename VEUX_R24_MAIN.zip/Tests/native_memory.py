"""Execute actual patched C functions with host mocks; this is not a device test."""
from pathlib import Path
import re,subprocess

def function(text,name):
    match=re.search(r'(?m)^.*\b'+re.escape(name)+r'\([^;]*?\)\n\{',text)
    if not match:raise ValueError('FUNCTION_MISSING:'+name)
    depth=1
    for pos in range(match.end(),len(text)):
        depth+=(text[pos]=='{')-(text[pos]=='}')
        if depth==0:return text[match.start():pos+1]
    raise ValueError('UNCLOSED_FUNCTION:'+name)

def compile_harness(root,output):
    worker=(root/'After/drivers/staging/rtmm/rtmm_reclaim.c').read_text()
    proc=(root/'After/fs/proc/task_mmu.c').read_text()
    selected='\n\n'.join([function(worker,'rtmm_mb_valid'),function(worker,'rtmm_command_valid'),
        function(proc,'rtmm_reclaim_pte_range'),function(worker,'mem_process_reclaim'),function(proc,'reclaim_write')])
    code=PREFIX+'\n'+selected+'\n'+MAIN
    path=output/'actual_memory_functions.c';path.write_text(code)
    result=subprocess.run(['cc','-std=gnu11','-O1','-g','-Wall','-Werror','-Wno-unused-function',
        '-Wno-sign-compare','-fsanitize=undefined','-fno-sanitize-recover=all',str(path),'-o',str(output/'native_memory')],
        capture_output=True,text=True,timeout=30)
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    return output/'native_memory'

PREFIX=r'''
#include <assert.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#define __user
#define PAGE_SHIFT 12
#define PAGE_SIZE (1UL << PAGE_SHIFT)
#define PAGE_MASK (~(PAGE_SIZE-1))
#define SWAP_CLUSTER_MAX 32
#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))
#define min_t(t,a,b) min((t)(a),(t)(b))
#define RECLAIM_NONE 0
#define RECLAIM_TYPE_NR 5
#define RECLAIM_PAGE_FILE 1
#define RECLAIM_PAGE_ANON 2
#define RECLAIM_PAGE_ALL 3
struct reclaim_cmd {int type;};
struct list_head {struct list_head *next,*prev;};
#define LIST_HEAD(n) struct list_head n={&n,&n}
static void list_add(struct list_head *p,struct list_head *h){p->next=h->next;p->prev=h;h->next->prev=p;h->next=p;}
struct page {int id,isolated,lazy;struct list_head lru;};
struct mm_struct;
struct vm_area_struct {unsigned long vm_start,vm_end;void *vm_file;int huge;struct mm_struct *vm_mm;struct vm_area_struct *vm_next;};
struct mm_struct {struct vm_area_struct *mmap;int mmap_sem;};
struct task_struct {int unused;};
struct rtmm_reclaim_proc {struct vm_area_struct *vma;unsigned long nr_reclaimed,nr_to_reclaim;};
typedef int pmd_t;typedef int pte_t;typedef int spinlock_t;
struct mm_walk {void *private;};
struct mm_walk_ops {int(*pmd_entry)(pmd_t*,unsigned long,unsigned long,struct mm_walk*);};
enum reclaim_type {RECLAIM_FILE,RECLAIM_ANON,RECLAIM_ALL,RECLAIM_RANGE};
static struct page pages[64];static pte_t ptes[64];
static int isolated_nodes,unmaps,putbacks,walks,task_puts,mmputs,locks,missing,no_mm,walk_error,proc_write_mode;
static struct task_struct task;static struct mm_struct mm;
static int is_vm_hugetlb_page(struct vm_area_struct*v){return v->huge;}
static void split_huge_pmd(struct vm_area_struct*v,unsigned long a,pmd_t*p){(void)v;(void)a;(void)p;}
static int pmd_trans_unstable(pmd_t*p){(void)p;return 0;}
static pte_t *pte_offset_map_lock(struct mm_struct*m,pmd_t*p,unsigned long a,spinlock_t**l){(void)m;(void)p;*l=NULL;assert(a/PAGE_SIZE<64);return &ptes[a/PAGE_SIZE];}
static void pte_unmap_unlock(pte_t*p,spinlock_t*l){(void)l;assert(p>=ptes&&p<ptes+64);unmaps++;}
static int pte_present(pte_t p){return p;}
static struct page *vm_normal_page(struct vm_area_struct*v,unsigned long a,pte_t p){(void)v;(void)p;return &pages[a/PAGE_SIZE];}
static struct page *compound_head(struct page*p){return p;}
static int isolate_lru_page(struct page*p){if(p->isolated)return 1;p->isolated=1;return 0;}
static int PageAnon(struct page*p){return p->lazy;}
static int PageSwapBacked(struct page*p){return !p->lazy;}
static void putback_lru_page(struct page*p){p->isolated=0;putbacks++;}
#define NR_ISOLATED_ANON 0
static int page_is_file_cache(struct page*p){(void)p;return 0;}
static void inc_node_page_state(struct page*p,int n){(void)p;(void)n;isolated_nodes++;}
static unsigned long reclaim_pages_from_list(struct list_head*h,struct vm_area_struct*v){
 (void)v;unsigned long n=0;while(h->next!=h){struct list_head*p=h->next;p->prev->next=p->next;p->next->prev=p->prev;
 struct page*q=(struct page*)((char*)p-offse tof(struct page,lru));q->isolated=0;isolated_nodes--;n++;}return n;}
static void cond_resched(void){}
static struct task_struct *find_get_task_by_pid(pid_t p){(void)p;return missing?NULL:&task;}
static struct mm_struct *get_task_mm(struct task_struct*t){(void)t;return no_mm?NULL:&mm;}
static void down_read(int*p){(void)p;locks++;}static void up_read(int*p){(void)p;locks--;}
static void flush_tlb_mm(struct mm_struct*m){(void)m;}static void mmput(struct mm_struct*m){(void)m;mmputs++;}
static void put_task_struct(struct task_struct*t){(void)t;task_puts++;}
static int rtmm_reclaim_pte_range(pmd_t*,unsigned long,unsigned long,struct mm_walk*);
static int reclaim_pte_range(pmd_t*p,unsigned long a,unsigned long e,struct mm_walk*w){(void)p;(void)a;(void)e;(void)w;return 0;}
static int walk_page_range(struct mm_struct*m,unsigned long a,unsigned long e,const struct mm_walk_ops*ops,void*arg){
 (void)m;(void)a;(void)e;(void)ops;walks++;if(walk_error)return -EIO;if(proc_write_mode)return 0;
 struct rtmm_reclaim_proc*r=arg;assert(r->nr_reclaimed==(unsigned long)(walks-1)*3);
 unsigned long n=min(3UL,r->nr_to_reclaim);r->nr_to_reclaim-=n;r->nr_reclaimed+=n;return r->nr_to_reclaim?0:-EPIPE;}
struct inode {int unused;};struct dentry {struct inode*d_inode;};struct file {struct {struct dentry*dentry;}f_path;};
static struct task_struct *get_proc_task(struct inode*i){(void)i;return missing?NULL:&task;}
static int copy_from_user(void*d,const void*s,size_t n){memcpy(d,s,n);return 0;}
static char *strstrip(char*s){while(isspace(*s))s++;char*e=s+strlen(s);while(e>s&&isspace(e[-1]))*--e=0;return s;}
static unsigned long long memparse(const char*s,char**e){return strtoull(s,e,0);}
static struct vm_area_struct *find_vma(struct mm_struct*m,unsigned long a){struct vm_area_struct*v=m->mmap;while(v&&v->vm_end<=a)v=v->vm_next;return v;}
'''.replace('offse tof','offsetof')

MAIN=r'''
static void reset(void){memset(pages,0,sizeof(pages));for(int i=0;i<64;i++){pages[i].id=i;ptes[i]=1;}
 isolated_nodes=unmaps=putbacks=walks=task_puts=mmputs=locks=missing=no_mm=walk_error=proc_write_mode=0;}
int main(int argc,char**argv){assert(argc==2);reset();
 struct vm_area_struct v[3]={{.vm_start=0,.vm_end=PAGE_SIZE,.vm_mm=&mm},
 {.vm_start=PAGE_SIZE,.vm_end=2*PAGE_SIZE,.vm_mm=&mm},
 {.vm_start=2*PAGE_SIZE,.vm_end=3*PAGE_SIZE,.vm_mm=&mm}};
 v[0].vm_next=&v[1];v[1].vm_next=&v[2];mm.mmap=&v[0];
 if(!strcmp(argv[1],"limits")){assert(!rtmm_mb_valid(-1));assert(!rtmm_mb_valid(0));
 assert(rtmm_mb_valid(INT_MAX>>8));assert(!rtmm_mb_valid((INT_MAX>>8)+1));assert(!rtmm_mb_valid(INT_MAX));}
 else if(!strcmp(argv[1],"commands")){struct reclaim_cmd c={0};assert(!rtmm_command_valid(NULL));assert(!rtmm_command_valid(&c));
 c.type=4;assert(rtmm_command_valid(&c));c.type=5;assert(!rtmm_command_valid(&c));c.type=-1;assert(!rtmm_command_valid(&c));}
 else if(!strncmp(argv[1],"pmd",3)){struct rtmm_reclaim_proc rr={.vma=&v[0],.nr_reclaimed=2};
 struct mm_walk w={.private=&rr};pmd_t pmd=0;
 if(!strcmp(argv[1],"pmd-zero")){assert(rtmm_reclaim_pte_range(&pmd,0,64*PAGE_SIZE,&w)==-EPIPE);assert(unmaps==0);}
 else if(!strcmp(argv[1],"pmd-batches")){rr.nr_to_reclaim=40;assert(rtmm_reclaim_pte_range(&pmd,0,64*PAGE_SIZE,&w)==-EPIPE);assert(rr.nr_reclaimed==42);assert(unmaps==2);}
 else if(!strcmp(argv[1],"pmd-lazy")){rr.nr_to_reclaim=2;pages[0].lazy=1;assert(rtmm_reclaim_pte_range(&pmd,0,3*PAGE_SIZE,&w)==-EPIPE);assert(rr.nr_reclaimed==4);assert(putbacks==1);}
 else{rr.nr_to_reclaim=5;assert(rtmm_reclaim_pte_range(&pmd,0,64*PAGE_SIZE,&w)==-EPIPE);assert(rr.nr_reclaimed==7);assert(unmaps==1);}
 assert(rr.nr_to_reclaim==0);assert(isolated_nodes==0);}
 else if(!strcmp(argv[1],"process-budget")){assert(mem_process_reclaim(7,RECLAIM_PAGE_ALL,5)==5);assert(walks==2);assert(task_puts==1&&mmputs==1&&!locks);}
 else if(!strcmp(argv[1],"process-no-mm")){no_mm=1;assert(mem_process_reclaim(7,RECLAIM_PAGE_ALL,5)==-EINVAL);assert(!walks&&task_puts==1&&!mmputs);}
 else if(!strcmp(argv[1],"process-missing")){missing=1;assert(mem_process_reclaim(7,RECLAIM_PAGE_ALL,5)==-ESRCH);assert(!walks&&!task_puts);}
 else if(!strcmp(argv[1],"process-zero")){assert(mem_process_reclaim(7,RECLAIM_PAGE_ALL,0)==-EINVAL);assert(!walks&&!task_puts);}
 else if(!strcmp(argv[1],"process-error")){walk_error=1;assert(mem_process_reclaim(7,RECLAIM_PAGE_ALL,5)==-EIO);assert(!locks&&task_puts==1&&mmputs==1);}
 else if(!strcmp(argv[1],"range-progress")){proc_write_mode=1;v[0].huge=1;v[1].vm_next=NULL;
 struct inode inode={0};struct dentry d={.d_inode=&inode};struct file f={.f_path={.dentry=&d}};loff_t off=0;
 char text[]="0 8192";assert(reclaim_write(&f,text,strlen(text),&off)==(ssize_t)strlen(text));
 assert(walks==1&&!locks&&task_puts==1&&mmputs==1);}
 else{assert(!"UNKNOWN_TEST");}
 return 0;
}
'''
