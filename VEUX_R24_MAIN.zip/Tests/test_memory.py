import argparse,contextlib,importlib.util,io,json,lzma,os
from pathlib import Path
import shutil,subprocess,sys,tempfile,textwrap,unittest
from unittest.mock import patch
from native_memory import compile_harness

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r24_tested',ROOT/'Tools/r24_memory.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def baseline():return m.config_values(lzma.decompress((ROOT/'References/R23.config.xz').read_bytes()).decode())
def enabled():return dict(baseline(),CONFIG_RTMM='y',CONFIG_PROCESS_RECLAIM='y')
def fixture(where):
    shutil.copytree(ROOT/'Before',where,dirs_exist_ok=True)
    (where/'scripts').mkdir(exist_ok=True);shutil.copyfile(ROOT/'References/scripts_config',where/'scripts/config')

class MemoryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.binary=compile_harness(ROOT,Path(cls.temp.name))
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def native(self,*cases):
        for case in cases:
            with self.subTest(case=case):
                p=subprocess.run([str(self.binary),case],capture_output=True,text=True,timeout=5)
                self.assertEqual(p.returncode,0,p.stdout+p.stderr)

    def test_native_size_limits_reject_negative_zero_and_signed_overflow(self):self.native('limits')
    def test_native_command_validation_never_dereferences_null(self):self.native('commands')
    def test_native_pmd_budget_accumulates_without_over_reclaim(self):self.native('pmd-zero','pmd-small','pmd-batches')
    def test_native_lazyfree_isolation_is_balanced(self):self.native('pmd-lazy')
    def test_native_process_budget_is_initialized_and_stops_at_request(self):self.native('process-budget')
    def test_native_process_failures_return_errors_and_release_references(self):self.native('process-no-mm','process-missing','process-zero','process-error')
    def test_native_huge_vma_in_range_advances_instead_of_hanging(self):self.native('range-progress')

    def test_only_two_new_memory_values_are_accepted(self):
        self.assertEqual(m.normalize_memory(enabled()),baseline())
        import hashlib
        self.assertEqual(hashlib.sha256(lzma.decompress((ROOT/'References/R23.config.xz').read_bytes())).hexdigest(),m.profile()['baseline_config_sha256'])
        for name in m.FLAGS:
            for bad in ['n','m',None]:
                v=enabled()
                if bad is None:del v[name]
                else:v[name]=bad
                with self.subTest(name=name,value=bad),self.assertRaises(ValueError):m.normalize_memory(v)

    def test_fingerprint_cfi_walt_and_release_cannot_regress(self):
        for name,value in [('CONFIG_FINGERPRINT_FPC','n'),('CONFIG_CFI_CLANG','n'),
                           ('CONFIG_SCHED_WALT','n'),('CONFIG_LOCALVERSION','"-Positron"')]:
            v=enabled();v[name]=value
            with self.subTest(name=name),self.assertRaisesRegex(ValueError,'OUTSIDE_TWO'):m.normalize_memory(v)

    def test_complete_16_file_patch_preserves_two_argument_unmap_API(self):
        with tempfile.TemporaryDirectory()as tmp:
            source=Path(tmp);fixture(source);m.source_check(source)
            hashes=m.apply_source(source);self.assertEqual(len(hashes),16)
            self.assertEqual(hashes,m.source_check(source,after=True))
            header=(source/'include/linux/rmap.h').read_text()
            self.assertIn('bool try_to_unmap(struct page *, enum ttu_flags flags);',header)
            self.assertIn('bool try_to_unmap_vma(',header)
            self.assertIn('select PROCESS_RECLAIM',(source/'drivers/staging/rtmm/Kconfig').read_text())
            with self.assertRaises(ValueError):m.apply_source(source)

    def test_late_preimage_failure_prevents_all_writes(self):
        with tempfile.TemporaryDirectory()as tmp:
            source=Path(tmp);fixture(source);victim=source/'mm/vmscan.c'
            victim.write_text(victim.read_text()+'\n/* unexpected drift */\n')
            before={str(p.relative_to(source)):m.sha(p)for p in source.rglob('*')if p.is_file()}
            with self.assertRaisesRegex(ValueError,'SOURCE_CONTEXT_CHANGED'):m.apply_source(source)
            self.assertEqual(before,{str(p.relative_to(source)):m.sha(p)for p in source.rglob('*')if p.is_file()})

    def test_new_source_and_symlink_collisions_are_rejected(self):
        with tempfile.TemporaryDirectory()as tmp:
            source=Path(tmp)/'source';source.mkdir();fixture(source)
            file=source/'include/linux/rtmm.h';file.write_text('unrelated existing file')
            with self.assertRaisesRegex(ValueError,'ALREADY_EXISTS'):m.apply_source(source)
            file.unlink();(source/'drivers/staging/rtmm').symlink_to(Path(tmp),target_is_directory=True)
            with self.assertRaisesRegex(ValueError,'SYMLINK'):m.apply_source(source)

    def test_real_config_tool_requests_only_memory_flags(self):
        with tempfile.TemporaryDirectory()as tmp:
            source=Path(tmp);fixture(source);cfg=source/'.config'
            cfg.write_bytes(lzma.decompress((ROOT/'References/R23.config.xz').read_bytes()))
            m.request_memory(source,cfg);self.assertEqual(m.config_values(cfg.read_text()),enabled())

    def test_genuine_r23_contract_and_failed_build_cannot_claim_pass(self):
        parent_root=Path(os.environ.get('R23_DIR',str(ROOT.parent/'r23-main')))
        parent=m.load_parent(parent_root/'Tools/r23_fingerprint.py')
        original_request,original_normalize=parent.request_fingerprint,parent.normalize_fingerprint
        with tempfile.TemporaryDirectory()as tmp:
            source=Path(tmp)/'source';source.mkdir();fixture(source)
            out=Path(tmp)/'result';out.mkdir();cfg=out/'.config'
            cfg.write_bytes(lzma.decompress((ROOT/'References/R23.config.xz').read_bytes()))
            def stopped(args):
                parent.request_fingerprint(source,cfg)
                normalized=parent.normalize_fingerprint(m.config_values(cfg.read_text()))
                self.assertNotIn('CONFIG_RTMM',normalized)
                self.assertEqual(normalized['CONFIG_INPUT_FINGERPRINT'],'n')
                m.source_check(source,after=True)
                raise RuntimeError('TEST_STOPS_BEFORE_KERNEL_COMPILATION')
            with patch.object(m,'load_parent',return_value=parent),patch.object(parent,'build',side_effect=stopped):
                with self.assertRaisesRegex(RuntimeError,'TEST_STOPS_BEFORE_KERNEL_COMPILATION'):
                    m.build(argparse.Namespace(source=str(source),output=str(out),r23_tool=str(parent_root/'Tools/r23_fingerprint.py')))
            self.assertIs(parent.request_fingerprint,original_request)
            self.assertIs(parent.normalize_fingerprint,original_normalize)
            r=json.loads((out/'R24_RESULT.json').read_text());self.assertFalse(r['kernel_compiled']);self.assertFalse(r['flash_allowed'])

    def test_all_linked_memory_interfaces_required_including_cfi_variants(self):
        lines=['ffffffc012000000 d __initcall_178_40_rtmm_init4',
               'ffffffc012000100 D proc_reclaim_operations',
               'ffffffc012000200 t rtmm_reclaim_pte_range$123ab.cfi_jt']
        self.assertEqual(len(m.linked_proof('\n'.join(lines))),3)
        for i in range(3):
            with self.subTest(missing=i),self.assertRaises(ValueError):m.linked_proof('\n'.join(lines[:i]+lines[i+1:]))

    def test_old_green_build_is_not_a_new_memory_build(self):
        with tempfile.TemporaryDirectory()as tmp:
            (Path(tmp)/'R24_RESULT.json').write_text(json.dumps({'status':'R23_FULL_BUILD_PASS'}))
            with self.assertRaisesRegex(ValueError,'FRESH_R24_FULL_BUILD_REQUIRED'):m.verify_fresh(tmp)

class WorkflowTests(unittest.TestCase):
    def command(self):
        expected=(ROOT/'References/R24_BUILD_COMMAND.sh').read_text()
        if 'R24_WORKFLOW'not in os.environ:return expected
        rows=Path(os.environ['R24_WORKFLOW']).read_text().splitlines();matches=[]
        for i,row in enumerate(rows):
            if not row.strip().startswith('run: |'):continue
            indent=len(row)-len(row.lstrip());body=[]
            for line in rows[i+1:]:
                if line.strip()and len(line)-len(line.lstrip())<=indent:break
                body.append(line)
            script=textwrap.dedent('\n'.join(body))+'\n'
            if 'python3 -B "$R24_DIR/Tools/r24_memory.py" build'in script:matches.append(script)
        self.assertEqual(matches,[expected]);return matches[0]

    def capture(self,body):
        with tempfile.TemporaryDirectory(prefix='r24 argv spaces ')as tmp:
            root=Path(tmp);b=root/'bin';b.mkdir();shim=b/'python3'
            shim.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$R24_CAPTURE"\n');shim.chmod(0o755)
            keys=['R23_DIR','R21_SCHED_DIR','R19_RMNET_DIR','R18_IRQ_DIR','R17_CACHE_DIR','R16_REPAIR_DIR',
                  'R9_SNAPSHOT','R13_OBJOUT','R47_REPORT_DIR','R47_TOOLS_DIR','GITHUB_WORKSPACE','R16_REPAIR_OUTPUT']
            values={n:str(root/(n+' spaces'))for n in keys};values['R24_DIR']=str(ROOT)
            env=dict(os.environ,**values,PATH=str(b)+os.pathsep+os.environ['PATH'],R24_CAPTURE=str(root/'argv'))
            p=subprocess.run(['bash','-c',body],env=env,text=True,capture_output=True,timeout=10)
            self.assertEqual(p.returncode,0,p.stderr);data=(root/'argv').read_bytes().split(b'\0');self.assertEqual(data.pop(),b'')
            return[x.decode()for x in data],values

    def test_actual_yaml_bash_command_and_all_twelve_paths_reach_real_parser(self):
        argv,env=self.capture(self.command());self.assertEqual(argv[:2],['-B',str(ROOT/'Tools/r24_memory.py')])
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'verify_package'),patch.object(m,'build')as build:m.main()
        expected={'op':'build'}
        for key,var,suffix in [('r23_tool','R23_DIR','/Tools/r23_fingerprint.py'),
            ('r21_tool','R21_SCHED_DIR','/Tools/r21_scheduler_release.py'),
            ('r19_tool','R19_RMNET_DIR','/Tools/r19_rmnet_vendor_abi.py'),
            ('r18_tool','R18_IRQ_DIR','/Tools/r18_irq_affinity.py'),('r17_tool','R17_CACHE_DIR','/Tools/r17_cache_alignment.py'),
            ('base_tool','R16_REPAIR_DIR','/Tools/restore_memory_network.py'),('source','R9_SNAPSHOT',''),
            ('objout','R13_OBJOUT',''),('r6_report','R47_REPORT_DIR','/R47_RESULT.json'),
            ('r6_tool','R47_TOOLS_DIR','/Tools/veux_r47_r13_on_r46.py'),('project','GITHUB_WORKSPACE','/project'),
            ('output','R16_REPAIR_OUTPUT','')]:expected[key]=env[var]+suffix
        self.assertEqual(vars(build.call_args.args[0]),expected)

    def test_stray_plus_is_rejected_before_build(self):
        body=self.command().replace(' build \\\n',' build \\\n  + \\\n',1);argv,_=self.capture(body)
        with patch.object(sys,'argv',[argv[1],*argv[2:]]),patch.object(m,'build')as build,contextlib.redirect_stderr(io.StringIO()):
            with self.assertRaises(SystemExit)as error:m.main()
        self.assertEqual(error.exception.code,2);build.assert_not_called()

if __name__=='__main__':unittest.main()
