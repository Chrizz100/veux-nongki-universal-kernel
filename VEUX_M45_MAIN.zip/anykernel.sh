# AnyKernel3 review for the exact stock base. No partition is written.
properties() { '
kernel.string=VEUX M45 AK3 Stock-Repack-Pruefung NOFLASH
do.devicecheck=1
do.modules=0
do.systemless=0
do.cleanup=1
do.cleanuponabort=1
device.name1=veux
supported.versions=13
supported.patchlevels=
'; }

BLOCK=boot
IS_SLOT_DEVICE=1
SLOT_SELECT=active
PATCH_VBMETA_FLAG=0
. tools/ak3-core.sh
case "$SLOT" in _a|_b) ;; *) abort "Slot unklar" ;; esac
case "${BLOCK##*/}" in "boot$SLOT") ;; *) abort "Kein eindeutiger aktiver Boot-Slot" ;; esac
dd if="$BLOCK" of="$AKHOME/m45-stock.img" bs=1048576 || abort "Boot-Abbild konnte nicht gelesen werden"
sh "$AKHOME/veux/render.sh" "$AKHOME/m45-stock.img" "$AKHOME/Image" "$AKHOME/veux/boot-avb-page.bin" "$AKHOME/m45-review" "$BIN/magiskboot" || abort "M45-Abgleich fehlgeschlagen"
ui_print "M45-Pruefung bestanden. Keine Partition beschrieben. Keine Flash-Freigabe."
