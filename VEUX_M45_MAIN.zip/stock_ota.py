"""Reconstruct only the verified stock boot partition from Xiaomi's full OTA."""

import bz2
import concurrent.futures
import hashlib
import json
import lzma
from pathlib import Path
from urllib.request import Request, urlopen

OTA = "OS1.0.12.0.TKCMIXM/miui_VEUXGlobal_OS1.0.12.0.TKCMIXM_c42114b47d_13.0.zip"
OTA_BYTES = 4020559092
STOCK_SHA = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
BLOCK = 4096


def fetch_chunk(span):
    offset, length = span
    end = offset + length - 1
    for host in ("cdnorg", "bigota", "hugeota", "bn"):
        url = f"https://{host}.d.miui.com/{OTA}?range={offset}-{length}"
        request = Request(
            url,
            headers={"Range": f"bytes={offset}-{end}", "Accept-Encoding": "identity"},
        )
        try:
            with urlopen(request, timeout=40) as response:
                expected = f"bytes {offset}-{end}/{OTA_BYTES}"
                if (
                    response.status != 206
                    or response.headers["Content-Range"] != expected
                ):
                    raise ValueError("Unexpected Xiaomi HTTP byte range")
                data = response.read(length + 1)
                if len(data) != length:
                    raise ValueError("Incomplete Xiaomi response")
                return data
        except (OSError, ValueError) as error:
            last = error
    raise RuntimeError(f"Xiaomi OTA bytes {offset}-{end} unavailable") from last


def restore(path):
    ops = json.loads(Path(__file__).with_name("stock-ota.json").read_text())
    start = min(o["offset"] for o in ops)
    end = max(o["offset"] + o["length"] for o in ops)
    step = 2 * 1024 * 1024
    chunks = [(i, min(step, end - i)) for i in range(start, end, step)]
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
        compressed = b"".join(pool.map(fetch_chunk, chunks))
    image = bytearray(134217728)
    for op in ops:
        i = op["offset"] - start
        data = compressed[i : i + op["length"]]
        if hashlib.sha256(data).hexdigest() != op["sha256"]:
            raise ValueError("OTA operation checksum mismatch")
        if op["type"] == 1:
            data = bz2.decompress(data)
        elif op["type"] == 8:
            data = lzma.decompress(data)
        elif op["type"] != 0:
            raise ValueError("Unexpected OTA operation")
        cursor = 0
        for block, count in op["extents"]:
            off, length = block * BLOCK, count * BLOCK
            if off < 0 or off + length > len(image) or cursor + length > len(data):
                raise ValueError("Invalid OTA extent")
            image[off : off + length] = data[cursor : cursor + length]
            cursor += length
        if cursor != len(data):
            raise ValueError("Unexpected OTA payload length")
    if hashlib.sha256(image).hexdigest() != STOCK_SHA:
        raise ValueError("Stock boot SHA-256 mismatch")
    path.write_bytes(image)
