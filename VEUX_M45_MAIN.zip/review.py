"""Verify the pinned M44 artifact and run the M45 read-only Android packaging path."""

import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
import os
import shlex
import shutil
import struct
import subprocess
import tempfile
import zipfile

import avbtool as avb
from stock_ota import STOCK_SHA, restore

ROOT = Path(__file__).resolve().parent
ARCHIVE = "0834c0e5b0e3ec9777168de415e9dd4661ab0ff2fdc0afda9e521cbce9a762bc"
ORIGINAL_AK3 = "b02bbd3a093371f1019fe26c7213de11c2bcfe063dc93b5b0fc4506697df175f"
KERNEL = "22a7292d90fbe2d498d70fb659d8338a072234f23fa078811d00b7145bddc5f1"
BOOT = "6958229b835f87269776dd4bcbfda7f8e052a8c19a7a8edb871945aab3c43b6d"
RAMDISK = "0bc8b54373b5501818e8b252517419786db207771047b6def7ec9bc89beb607a"
RELEASE = "5.4.274-qgki-g82179e362f33"
AVB_SALT = bytes.fromhex(
    "b67fd062f74bae5899a3586f11d1dee62cd7d6a3591093e48ea979893cbdf547"
)
STOCK_DESCRIPTOR = "fc6d91cd4ce2e89703c59e6a35c60e3efd984cfb54a29760e4a3105c42399d8a"
BUILD = "r46-r16-result/"
PAIR = "r46-m44-boot-ak3/"
REVIEW = PAIR + "review/VEUX_M44_5.4.274_QGKI_NOFLASH_"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(condition, message):
    if not condition:
        raise ValueError(message)


def boot_descriptor(metadata, signed):
    header = avb.AvbVBMetaHeader(metadata[:256])
    need(
        header.algorithm_type == (1 if signed else 0),
        "Unexpected vbmeta signature algorithm",
    )
    if signed:
        need(
            header.flags == 0 and avb.verify_vbmeta_signature(header, metadata),
            "Invalid stock vbmeta signature",
        )
    start = 256 + header.authentication_data_block_size + header.descriptors_offset
    descriptors = avb.parse_descriptors(
        metadata[start : start + header.descriptors_size]
    )
    matches = [
        item
        for item in descriptors
        if isinstance(item, avb.AvbHashDescriptor) and item.partition_name == "boot"
    ]
    need(len(matches) == 1, "Expected one boot descriptor")
    desc = matches[0]
    need(
        desc.hash_algorithm == "sha256" and desc.salt == AVB_SALT,
        "Unexpected boot hash parameters",
    )
    return desc


def image_info(blob):
    need(
        len(blob) == 134217728
        and blob[:8] == b"ANDROID!"
        and struct.unpack_from("<I", blob, 40)[0] == 3,
        "Expected a full stock-layout v3 boot partition",
    )
    kernel_size, ramdisk_size = struct.unpack_from("<II", blob, 8)
    ramdisk_offset = 4096 + (kernel_size + 4095) // 4096 * 4096
    footer = avb.AvbFooter(blob[-64:])
    end = footer.original_image_size
    need(
        end == footer.vbmeta_offset
        and end == (ramdisk_offset + ramdisk_size + 4095) // 4096 * 4096,
        "Unexpected boot footer",
    )
    desc = boot_descriptor(blob[end : end + footer.vbmeta_size], signed=False)
    need(
        desc.image_size == end
        and hashlib.sha256(desc.salt + blob[:end]).digest() == desc.digest,
        "Embedded boot descriptor does not match its own image",
    )
    return dict(
        kernel_sha256=sha(blob[4096 : 4096 + kernel_size]),
        ramdisk_sha256=sha(blob[ramdisk_offset : ramdisk_offset + ramdisk_size]),
        ramdisk_bytes=ramdisk_size,
        embedded_boot_digest=desc.digest.hex(),
    )


def write_review_ak3(original, dest):
    with (
        zipfile.ZipFile(io.BytesIO(original)) as old,
        zipfile.ZipFile(dest, "x") as new,
    ):
        for info in old.infolist():
            if info.filename == "anykernel.sh":
                data = (ROOT / "anykernel.sh").read_bytes()
            else:
                data = old.read(info)
            new.writestr(info, data)
        for name in ("render.sh", "boot-avb-page.bin"):
            info = zipfile.ZipInfo("veux/" + name, (2026, 11, 21, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            new.writestr(info, (ROOT / name).read_bytes())


def test_entry(package, stock, canonical, temp, qemu):
    # Only the recovery slot discovery is substituted. Exercise the packaged Android entry and ARM tool.
    home = temp / "ak"
    with zipfile.ZipFile(package) as z:
        for name in (
            "anykernel.sh",
            "Image",
            "veux/render.sh",
            "veux/boot-avb-page.bin",
            "tools/magiskboot",
            "tools/ak3-core.sh",
        ):
            z.extract(name, home)
    binary = home / "tools/magiskboot"
    arm = binary.with_name("magiskboot.arm")
    binary.rename(arm)
    arm.chmod(0o700)
    binary.write_text(
        "#!/bin/sh\nexec "
        + shlex.quote(str(qemu))
        + " "
        + shlex.quote(str(arm))
        + ' "$@"\n'
    )
    binary.chmod(0o700)
    core = home / "tools/ak3-core.sh"
    # Keep Abort/UI and every other framework method. Supply regular files in place of hardware discovery.
    src = core.read_text()
    need(src.count("\nsetup_ak;") == 1, "Wrong AK3 core")
    core.write_text(
        src.replace("\nsetup_ak;", '\nBLOCK="$TEST_SOURCE"; SLOT="$TEST_SLOT";')
    )

    def run(source, slot, ok):
        args = dict(
            os.environ,
            TEST_SOURCE=str(source),
            TEST_SLOT=slot,
            AKHOME=str(home),
            OUTFD="1",
        )
        proc = subprocess.run(
            ["sh", "anykernel.sh"],
            cwd=home,
            env=args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        need(
            (proc.returncode == 0) == ok,
            "Unexpected AK3 result: " + proc.stdout.decode(errors="replace")[-1100:],
        )
        return proc.stdout

    a = temp / "boot_a"
    os.link(stock, a)
    bad = temp / "boot_b"
    bad.write_bytes(b"wrong base")
    run(a, "_b", False)
    run(a, "", False)
    run(bad, "_b", False)
    need(not (home / "m45-review").exists(), "Unexpected output after rejected input")
    run(a, "_a", True)
    rendered = (home / "m45-review/reviewed-boot.img").read_bytes()
    need(rendered == canonical, "AK3 result differs from reviewed boot.img")
    need(sha(stock.read_bytes()) == STOCK_SHA, "Input changed")
    # The same payload must work on a stock copy in slot B.
    shutil.rmtree(home / "m45-review")
    bad.unlink()
    os.link(stock, bad)
    run(bad, "_b", True)
    need(
        (home / "m45-review/reviewed-boot.img").read_bytes() == canonical,
        "Slot B result differs",
    )
    return sha(rendered)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--artifact", type=Path, required=True)
    p.add_argument("--stock", type=Path)
    p.add_argument("--qemu", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    with a.artifact.open("rb") as f:
        h = hashlib.sha256()
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    need(h.hexdigest() == ARCHIVE, "Wrong M44 artifact")
    with zipfile.ZipFile(a.artifact) as z:
        original = z.read(REVIEW + "AK3.zip")
        canonical = z.read(REVIEW + "boot.img")
        build = json.loads(z.read(BUILD + "M44_RESULT.json"))
        pair = json.loads(z.read(PAIR + "M44_PACKAGE_RESULT.json"))
        rows = list(
            csv.DictReader(
                io.StringIO(z.read(BUILD + "QGKI_1423_SYMBOL_RESULTS.csv").decode())
            )
        )
        modules = list(
            csv.DictReader(
                io.StringIO(z.read(BUILD + "QGKI_37_MODULE_RESULTS.csv").decode())
            )
        )
        need(
            len({v["module"] for v in modules}) == len(modules) == 37
            and all(
                v["imports"] == v["match"]
                and v["crc_mismatch"] == v["missing"] == "0"
                and v["fully_compatible"] == "True"
                for v in modules
            ),
            "Stock module cohort mismatch",
        )
        need(
            build["release"]["verified_release"] == RELEASE
            and build["fully_matching_modules"] == 37
            and build["kernel_compiled"]
            and len({v["symbol"] for v in rows}) == len(rows) == 1423
            and all(
                v["status"] == "MATCH" and v["oem_crc"] == v["candidate_crc"]
                for v in rows
            ),
            "M44 kernel or vendor ABI mismatch",
        )
        need(
            pair["static_boot_path_pass"]
            and pair["device_pass"] is False
            and pair["flash_allowed"] is False,
            "Unexpected M44 status",
        )
        need(
            sha(z.read(BUILD + "candidate-out/arch/arm64/boot/Image")) == KERNEL,
            "Wrong linked Image",
        )
    need(sha(original) == ORIGINAL_AK3 and sha(canonical) == BOOT, "Wrong M44 pair")
    with zipfile.ZipFile(io.BytesIO(original)) as z:
        need(sha(z.read("Image")) == KERNEL, "Wrong AK3 kernel")
    info = image_info(canonical)
    need(
        info["kernel_sha256"] == KERNEL and info["ramdisk_sha256"] == RAMDISK,
        "Unexpected M44 boot contents",
    )
    a.out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=a.out.parent) as td:
        temp = Path(td).resolve()
        stock = temp / "stock.img"
        if a.stock:
            shutil.copyfile(a.stock, stock)
        else:
            restore(stock)
        stock_data = stock.read_bytes()
        need(sha(stock_data) == STOCK_SHA, "Wrong stock boot")
        si = image_info(stock_data)
        need(
            si["ramdisk_sha256"] == info["ramdisk_sha256"]
            and si["embedded_boot_digest"] == STOCK_DESCRIPTOR,
            "Wrong stock reference",
        )
        metadata = (ROOT / "stock-vbmeta.bin").read_bytes()
        need(
            sha(metadata)
            == "62a5b1a94c2247c786e8148b9d9d0aea943b57b1034b3fd82d9cac9a85fcde97",
            "Wrong OEM vbmeta",
        )
        signed_desc = boot_descriptor(metadata, signed=True)
        need(
            signed_desc.image_size == 67551232
            and signed_desc.digest.hex() == STOCK_DESCRIPTOR
            and hashlib.sha256(
                signed_desc.salt + stock_data[: signed_desc.image_size]
            ).digest()
            == signed_desc.digest,
            "OEM boot descriptor mismatch",
        )
        del stock_data
        out = temp / "VEUX_M45_AK3_REVIEW_ONLY.zip"
        write_review_ak3(original, out)
        digest = test_entry(out, stock, canonical, temp, a.qemu.resolve(strict=True))
        report = dict(
            run=44879323567,
            release=RELEASE,
            stock_boot_sha256=STOCK_SHA,
            review_boot_sha256=digest,
            AK3_replay_byte_identical=True,
            stock_ramdisk_byte_identical=True,
            boot=info,
            m44_stock_vbmeta_digest=hashlib.sha256(
                signed_desc.salt + canonical[: signed_desc.image_size]
            ).hexdigest(),
            stock_vbmeta_expected=STOCK_DESCRIPTOR,
            device_pass=False,
            flash_allowed=False,
            pc_free_recovery_demonstrated=False,
            abi_symbols=len(rows),
            modules=37,
            m45_review_zip_sha256=sha(out.read_bytes()),
        )
        for name, data in [
            ("M45_RESULT.json", (json.dumps(report, indent=2) + "\n").encode()),
            ("VEUX_M44_REVIEW_ONLY_boot.img", canonical),
        ]:
            (temp / name).write_bytes(data)
        for file in (
            out,
            temp / "VEUX_M44_REVIEW_ONLY_boot.img",
            temp / "M45_RESULT.json",
        ):
            os.replace(file, a.out / file.name)
        print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
