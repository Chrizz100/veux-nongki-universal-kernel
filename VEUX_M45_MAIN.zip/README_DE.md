# VEUX M45 · Reparatur des AK3-Packvorgangs

Für den POCO X4 Pro 5G (veux), Android 13, HyperOS OS1.0.12.0.TKCMIXM. Grundlage ist der M44-Kernel aus Lauf 44879323567 mit Kennung `5.4.274-qgki-g82179e362f33`.

## Was repariert wurde

Die M44-AK3 und das separat erzeugte M44-Boot-Image enthielten denselben Kernel. Beim Nachspielen von `dump_boot` und `write_boot` mit dem mitgelieferten ARM-Werkzeug änderte die AK3 den Ramdisk von 22.061.278 auf 22.109.894 Byte. Der eingebettete AVB-Deskriptor verwies auf den Stock-Digest und die ursprüngliche Prüflänge. Der Hash des erzeugten Abbilds stimmte damit nicht überein. Die Messung fand an einer Kopie des Original-Boot-Images statt und endete vor dem ersten Partitionsschreibzugriff.

M45 übernimmt den komprimierten Ramdisk unverändert und ersetzt nur den Kernel. In diesem Zwischenergebnis weicht genau eine 4-KiB-Seite vom geprüften M44-Boot-Image ab. M45 kontrolliert die Prüfsumme des ganzen Zwischenergebnisses, übernimmt die passende Metadatenseite aus dem geprüften Image und gleicht alle 134.217.728 Byte mit der Referenz ab. Das betrifft ausschließlich die im Boot-Image enthaltenen Metadaten. Xiaomis separat signierte vbmeta-Partition bleibt die Referenz für den zusätzlichen Stock-Vergleich.

## GitHub

1. `VEUX_M45_MAIN.zip` unverändert ins Hauptverzeichnis des Repositorys legen.
2. `VEUX_M45_AK3_STOCK_REPLAY.yml` in `.github/workflows/` hinzufügen und den Workflow **VEUX M45 AK3 Stock-Replay (NOFLASH)** manuell starten.
3. Der Workflow bezieht das fest referenzierte M44-Artefakt und prüft dessen SHA-256. Aus Xiaomis OTA lädt er die für die Original-Boot-Partition benötigten Bereiche. Dafür müssen das Artefakt von Lauf 44879323567 und die Xiaomi-Downloadquelle erreichbar sein.
4. Das Ergebnis enthält den Prüfbericht, das geprüfte M44-Boot-Image und die M45-Prüf-AK3. Die M45-Prüf-AK3 schreibt keine Boot-Partition. Die MAIN.zip ist ein Eingabepaket für GitHub.

## Prüfumfang und offene Punkte

- Alle 32 M44-Archive wurden anhand von Größe, SHA-256 und ZIP-Inhalt geprüft. Die Liste steht in `M44-Artefakte.json`. `M44-M45-Vergleich.json` enthält den gemessenen Fehler und die Vergleichswerte.
- Die M44-Konfiguration ist im ARM64-Image und in vmlinux identisch zur Build-Konfiguration. Die Symbolversionen aller 1.423 geprüften Imports und alle 37 geprüften Stock-QGKI-Module passen. Qualcomm-UFS und dm-verity sind im Kernel verlinkt.
- Der M45-Test führt das Render-Skript der erzeugten AK3 und deren originales ARM-magiskboot aus. Die Android-Sloterkennung wird im Test durch reguläre Dateien ersetzt. Stock-Eingaben für Slot A und B ergeben das kanonische M44-Image. Eine fremde Basis, eine unpassende Slotzuordnung und ein fehlender Slot führen zum Abbruch.
- Xiaomis signierte vbmeta erwartet weiterhin den Originalkernel. Die tatsächliche Annahme durch den entsperrten Bootloader, UFS und frühe Mounts am Gerät, Laden und OTG, Temperatur und die übrigen Laufzeittests sind offen. Die 59 M44-Konfigurationsabweichungen gegenüber Stock bleiben bestehen. M45 ändert das Verpacken.
- Der Stock-Boot-Ramdisk enthält sowohl `system/bin/recovery` als auch `system/etc/recovery.fstab`. Welche Recovery nach einem fehlerhaften Kernel unabhängig von diesem Slot ohne PC erreichbar ist, muss gesondert belegt werden. Ein Rückweg oder ein Gerätestart ist durch diesen Dateitest nicht nachgewiesen. **Keine Flash-Freigabe.**

[GitHub-Lauf M44](https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/44879323567/job/136770925290) · [Stock-Firmware](https://xmfirmwareupdater.com/hyperos/veux/stable/OS1.0.12.0.TKCMIXM/)
