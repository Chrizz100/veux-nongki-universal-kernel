#!/bin/sh
# Generate the reviewed boot image in a new directory. All writes target regular files there.
set -eu
[ "$#" -eq 5 ] || { echo "usage: render.sh STOCK_BOOT IMAGE AVB_PAGE NEW_DIRECTORY MAGISKBOOT" >&2; exit 2; }
stock=$1
kernel=$2
page=$3
directory=$4
magiskboot=$5
for path in "$stock" "$kernel" "$page" "$directory" "$magiskboot"; do
    case "$path" in /*) ;; *) echo "absolute path required" >&2; exit 2 ;; esac
done
check() {
    observed=$(sha256sum "$1") || return 1
    [ "${observed%% *}" = "$2" ] || { echo "SHA-256 mismatch: $1" >&2; return 1; }
}
[ -f "$stock" ] && [ -f "$kernel" ] && [ -f "$page" ] && [ -x "$magiskboot" ] || exit 2
check "$stock" ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5
check "$kernel" 22a7292d90fbe2d498d70fb659d8338a072234f23fa078811d00b7145bddc5f1
check "$page" 332dddc06431cccdf3439a6cb18ac422748514c5f6bbd54223a0ea1c5a2aa8dc
umask 077
mkdir "$directory"
cd "$directory"
# -n keeps the original compressed ramdisk. Only the kernel is replaced.
"$magiskboot" unpack -n -h "$stock"
check ramdisk.cpio 0bc8b54373b5501818e8b252517419786db207771047b6def7ec9bc89beb607a
cp "$kernel" kernel
PATCHVBMETAFLAG=false "$magiskboot" repack "$stock" draft.img
check draft.img e60bce1b0268e6122546f0706cd8985f4a887fbd0f7a57d0c8191a1f4f7aa224
# This is the embedded vbmeta page of the reviewed boot image. The vbmeta partition is separate.
dd if="$page" of=draft.img bs=4096 seek=16287 count=1 conv=notrunc
check draft.img 6958229b835f87269776dd4bcbfda7f8e052a8c19a7a8edb871945aab3c43b6d
mv draft.img reviewed-boot.img
