#!/usr/bin/env python3
"""Propagate rejected WT current requests and publish the override only on success."""
import argparse
import contextlib
import copy
import hashlib
import importlib.util
import json
import mmap
import re
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
WT='drivers/power/supply/qcom/wt_chg.c'
BQ='drivers/power/supply/qcom/bq2589x_charger.c'
STATUS='M41_FULL_WT_CURRENT_ERROR_PROPAGATION_M40_BQ_CONFIG_ABI_PASS_NOFLASH'
MARKER=b'wt_chg: input current request failed'
INPUT_MARKER=b'bq2589x: below-minimum input current request'

def require(ok,message):
    if not ok:raise ValueError(message)

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def profile():return json.loads((ROOT/'References/PROFILE.json').read_text())

def function(text,name):
    m=re.search(r'^(?:static\s+)?[^\n;]+\b'+name+r'\([^;]+?\n\{',text,re.M)
    require(m is not None,'FUNCTION_REQUIRED:'+name)
    return text[m.start():text.index('\n}',m.end())+2]

def verify_package():
    expected=set()
    for line in(ROOT/'MANIFEST_SHA256.txt').read_text().splitlines():
        digest,name=line.split('  ',1);p=Path(name)
        require(not p.is_absolute()and'..'not in p.parts and name not in expected,'UNSAFE_MANIFEST')
        require(not(ROOT/p).is_symlink()and sha(ROOT/p)==digest,'PACKAGE_CHANGED:'+name);expected.add(name)
    actual={str(p.relative_to(ROOT))for p in ROOT.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt'}
    require(actual==expected,'PACKAGE_SCOPE_CHANGED')
    p=profile();before=(ROOT/'Before'/WT).read_bytes()
    require(p['source_commit']=='b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'and p['wt_proven_sha256']=='f324d9bbc630c1ced1048fa2bc196c3139867ce375c8cffdee70a2d250ee6bd0'and p['bq_proven_sha256']=='dd71a256bea1b7dc170482ac3bda85d7523c3c896812b1cf34e43dbbf4f6d0c0','INDEPENDENT_M40_BASE_REQUIRED')
    require(sha(ROOT/'Before'/WT)==p['wt_before_sha256']and hashlib.sha1(b'blob '+str(len(before)).encode()+b'\0'+before).hexdigest()==p['wt_donor_git_blob'],'AUTHENTIC_WT_DONOR_REQUIRED')
    proven=(ROOT/'References/M40_PROVEN_WT.c').read_text();after=(ROOT/'After'/WT).read_text()
    require(hashlib.sha256(proven.encode()).hexdigest()==p['wt_proven_sha256']and hashlib.sha256(after.encode()).hexdigest()==p['wt_after_sha256'],'WT_SOURCE_FIXTURE_CHANGED')
    old=function(proven,'mtbf_current_store');new=function(after,'mtbf_current_store')
    allowed=old.replace('\tint val;','\tint val;\n\tint rc;',1).replace('\tchg->mtbf_current = val;\n\n\tbatt_set_iio_channel(chg, MAIN, MAIN_INPUT_CURRENT_SETTLED, val);',
       '\trc = batt_set_iio_channel(chg, MAIN, MAIN_INPUT_CURRENT_SETTLED, val);\n\tif (rc < 0) {\n\t\tpr_err_ratelimited("wt_chg: input current request failed rc=%d\\n", rc);\n\t\treturn rc;\n\t}\n\tchg->mtbf_current = val;',1)
    allowed=allowed.replace('\trc = batt_set_iio_channel(chg, MAIN, MAIN_INPUT_CURRENT_SETTLED, val);', '\t/* Zero clears the existing MTBF override; it is not a 0 mA request. */\n\tif (val == 0) {\n\t\tif (READ_ONCE(chg->shutdown_flag))\n\t\t\treturn -ENODEV;\n\t\tWRITE_ONCE(chg->mtbf_current, 0);\n\t\treturn count;\n\t}\n\n\trc = batt_set_iio_channel(chg, MAIN, MAIN_INPUT_CURRENT_SETTLED, val);',1)
    require(new==allowed and after.replace(new,old,1)==proven,'ONLY_WT_CURRENT_ERROR_PROPAGATION_ALLOWED')
    for side,key in [('Before','bq_before_sha256'),('After','bq_after_sha256')]:
        require(sha(ROOT/side/BQ)==p[key],'BQ_FIXTURE_CHANGED')
    base=(ROOT/'References/M40_PROVEN_BQ.c').read_text();require(hashlib.sha256(base.encode()).hexdigest()==p['bq_proven_sha256'],'PROVEN_M40_BQ_CHANGED')
    actual=(ROOT/'After'/BQ).read_text();guard=(ROOT/'References/BQ_INPUT_GUARD.txt').read_text()
    require(sha(ROOT/'References/BQ_INPUT_GUARD.txt')=='a8be2ecd2c0dbea64c7bedbc602f825fb926f849a4df2d95e2c6d0c2fd4b86ca','EXACT_MINIMUM_INPUT_GUARD_REQUIRED')
    require(actual.count(guard)==1 and actual.replace(guard,'',1)==base,'ONLY_BQ_MINIMUM_INPUT_GUARD_ALLOWED')

def check_file(source,name,after=False):
    source=Path(source).resolve(strict=True);path=source/name
    require(path.is_file()and all(not p.is_symlink()for p in[path,*path.parents]if p.is_relative_to(source)),'SOURCE_NOT_REGULAR')
    prefix='wt_'if name==WT else'bq_';digest=sha(path);require(digest==profile()[prefix+('after_sha256'if after else'before_sha256')],'SOURCE_CONTEXT_CHANGED:'+name)
    return{name:digest}

def check_source(source,after=False):return{**check_file(source,WT,after),**check_file(source,BQ,after)}

def check_git_source(source):
    source=Path(source).resolve(strict=True)
    def git(*args):
        r=subprocess.run(['git','-C',str(source),*args],text=True,capture_output=True,timeout=30)
        require(r.returncode==0,'REAL_DONOR_CHECKOUT_REQUIRED');return r.stdout.strip()
    p=profile();require(Path(git('rev-parse','--show-toplevel')).resolve()==source and git('rev-parse','HEAD')==p['source_commit'],'PINNED_DONOR_COMMIT_REQUIRED')
    for name,key in [(WT,'wt_donor_git_blob'),(BQ,'bq_donor_git_blob')]:
        row=git('ls-files','--stage','--',name).split();require(len(row)==4 and row[1]==p[key]and row[2]=='0','PINNED_DONOR_INDEX_REQUIRED:'+name)
    return{'donor_commit':p['source_commit'],'source_hashes':check_source(source),'wt_git_blob':p['wt_donor_git_blob'],'bq_git_blob':p['bq_donor_git_blob']}

def apply_overlay(source):
    path=Path(source)/WT;require(sha(path)==profile()['wt_proven_sha256'],'AUTHENTIC_M40_WT_POSTIMAGE_REQUIRED')
    path.write_bytes((ROOT/'After'/WT).read_bytes());return check_file(source,WT,after=True)

def apply_bq_overlay(source):
    path=Path(source)/BQ;require(sha(path)==profile()['bq_proven_sha256'],'AUTHENTIC_M40_BQ_POSTIMAGE_REQUIRED')
    path.write_bytes((ROOT/'After'/BQ).read_bytes());return check_file(source,BQ,after=True)

def load_m40(path):
    path=Path(path).resolve(strict=True);require(sha(path)==profile()['m40_tool_sha256'],'AUTHENTIC_M40_TOOL_REQUIRED')
    require(sha(path)=='11a3b37aa4a63c88406fb01cf33693adeacc311f9db386e4d3006bff7edaecd1','INDEPENDENT_M40_ENGINE_REQUIRED')
    s=importlib.util.spec_from_file_location('m41_original_m40',path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify_package();return m

@contextlib.contextmanager
def engine(m40_path,m28_path):
    """Retain complete source checks with two explicitly authenticated postimages."""
    m40=load_m40(m40_path);old_loader=m40.load_parent;m28=old_loader(m28_path)
    source_check=m28.source_check;apply=m28.apply_source;pins=m28.pins
    bq_check=m40.source_check;bq_apply=m40.apply_source;bq_pins=m40.pins
    def extended_check(source,after=False):
        if not after:return source_check(source,after=False)
        check_file(source,WT,after=True)
        extended=copy.deepcopy(pins());require(extended[WT]['after_sha256']==profile()['wt_proven_sha256'],'M28_WT_BASE_DISAGREES_WITH_CURRENT_M40')
        extended[WT]['after_sha256']=profile()['wt_after_sha256']
        m28.pins=lambda:extended
        try:return source_check(source,after=True)
        finally:m28.pins=pins
    def extended_apply(source):
        m28.source_check=source_check
        try:apply(source)
        finally:m28.source_check=extended_check
        apply_overlay(source);return extended_check(source,after=True)
    def extended_bq_check(source,after=False):
        if not after:return bq_check(source,after=False)
        check_file(source,BQ,after=True)
        extended=copy.deepcopy(bq_pins());require(extended[BQ]['after_sha256']==profile()['bq_proven_sha256'],'M40_BQ_BASE_CHANGED')
        extended[BQ]['after_sha256']=profile()['bq_after_sha256'];m40.pins=lambda:extended
        try:return bq_check(source,after=True)
        finally:m40.pins=bq_pins
    def extended_bq_apply(source):
        m40.source_check=bq_check
        try:bq_apply(source)
        finally:m40.source_check=extended_bq_check
        apply_bq_overlay(source);return extended_bq_check(source,after=True)
    def loader(path):
        require(Path(path).resolve()==Path(m28_path).resolve(),'UNEXPECTED_M28_TOOL_PATH')
        require(sha(path)==m40.profile()['m28_tool_sha256'],'AUTHENTIC_M28_TOOL_REQUIRED');return m28
    m28.source_check=extended_check;m28.apply_source=extended_apply;m40.load_parent=loader
    m40.source_check=extended_bq_check;m40.apply_source=extended_bq_apply
    try:yield m40,m28
    finally:
        m28.source_check=source_check;m28.apply_source=apply;m28.pins=pins;m40.load_parent=old_loader
        m40.source_check=bq_check;m40.apply_source=bq_apply;m40.pins=bq_pins

def current_proof(build):
    build=Path(build).resolve(strict=True);out=build/'candidate-out';sources=check_source(build/'candidate-source',after=True)
    require(sha(out/'.config')==profile()['baseline_config_sha256']and sha(out/'Module.symvers')==profile()['full_symvers_sha256'],'CONFIG_OR_FULL_EXPORT_TABLE_CHANGED')
    obj=out/WT.replace('.c','.o');cmd=obj.parent/('.'+obj.name+'.cmd')
    with obj.open('rb')as f:require(f.read(4)in[b'BC\xc0\xde',b'\xde\xc0\x17\x0b'],'WT_LLVM_OBJECT_REQUIRED')
    command=cmd.read_text();require(WT in command and'-flto=thin'in command and'-fsanitize=cfi'in command,'WT_CFI_COMMAND_REQUIRED')
    symbols=re.findall(r'(?m)^[0-9a-fA-F]+\s+[a-zA-Z]\s+(mtbf_current_store(?:[.$]\S+)?)$',(out/'System.map').read_text());require(symbols,'WT_CURRENT_CALLBACK_NOT_LINKED')
    offsets={}
    for name in ['arch/arm64/boot/Image','vmlinux']:
        with(out/name).open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as data:offsets[name]=data.find(MARKER)
        require(offsets[name]>=0,'WT_CURRENT_REJECTION_BRANCH_NOT_LINKED:'+name)
    input_offsets={}
    for name in ['arch/arm64/boot/Image','vmlinux']:
        with(out/name).open('rb')as f,mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ)as data:input_offsets[name]=data.find(INPUT_MARKER)
        require(input_offsets[name]>=0,'BQ_MINIMUM_INPUT_BRANCH_NOT_LINKED:'+name)
    return{'wt_current_source_hashes':sources,'wt_current_object_sha256':sha(obj),'wt_current_command_sha256':sha(cmd),'linked_wt_current_callback':sorted(set(symbols)),'wt_current_error_marker_offsets':offsets,'bq_minimum_input_marker_offsets':input_offsets}

def write_result(out,name,result):
    out=Path(out)
    if out.is_dir():(out/name).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')

def verify_fresh(args):
    build=Path(args.build).resolve(strict=True);r=json.loads((build/'M41_RESULT.json').read_text())
    require(r.get('status')==STATUS and r.get('kernel_compiled')is True and r.get('wt_current_error_paths_compiled_and_linked')is True and r.get('bq_minimum_input_paths_compiled_and_linked')is True and r.get('runtime_charging_tested')is False and r.get('device_pass')is False and r.get('flash_allowed')is False,'FRESH_M41_FULL_BUILD_REQUIRED')
    with engine(args.m40_tool,args.m28_tool)as(m40,m28):prior=m40.verify_fresh(build,m28,args.m27_tool,args.m26_tool,args.m25_tool)
    proof=current_proof(build);require(all(r.get(k)==v for k,v in proof.items()),'FRESH_WT_CURRENT_PROOF_CHANGED')
    require(r['kernel_product_hashes']==prior['kernel_product_hashes']and r['qgki_counts']==prior['qgki_counts'],'FRESH_M41_PARENT_PRODUCT_CHANGED')
    return r

def build(args):
    verify_package();out=Path(args.output).resolve();r={'status':'M41_BUILD_PENDING','kernel_compiled':False,'device_pass':False,'flash_allowed':False,'runtime_charging_tested':False,'baseline_run':profile()['baseline_run']}
    try:
        with engine(args.m40_tool,args.m28_tool)as(m40,m28):
            m40.build(args);prior=m40.verify_fresh(out,m28,args.m27_tool,args.m26_tool,args.m25_tool)
        require(prior['qgki_counts']=={'MATCH':1423,'CRC_MISMATCH':0,'NOT_EXPORTED':0}and prior['fully_matching_modules']==37,'COMPLETE_STOCK_COHORT_REQUIRED')
        r.update(current_proof(out));r.update(status=STATUS,kernel_compiled=True,wt_current_error_paths_compiled_and_linked=True,bq_minimum_input_paths_compiled_and_linked=True,kernel_product_hashes=prior['kernel_product_hashes'],release=prior['release'],qgki_counts=prior['qgki_counts'],fully_matching_modules=37)
    except Exception as error:r.update(status='M41_BUILD_OR_WT_CURRENT_GATE_FAILED_NOFLASH',error=str(error));raise
    finally:write_result(out,'M41_RESULT.json',r)
    print(STATUS,'DEVICE_PASS=NO FLASH=NO')

def package(args):
    verify_package();r=verify_fresh(args);out=Path(args.output).resolve();result={'status':'M41_PACKAGE_PENDING','static_boot_path_pass':False,'device_pass':False,'flash_allowed':False}
    try:
        with engine(args.m40_tool,args.m28_tool)as(m40,_):m40.package(args)
        old=json.loads((out/'M40_PACKAGE_RESULT.json').read_text());require(old['static_boot_path_pass']is True and old['device_pass']is False,'M40_STATIC_BOOT_GATES_REQUIRED')
        for path in sorted((out/'review').iterdir()):
            require(path.is_file()and path.name.startswith('VEUX_M40_'),'UNEXPECTED_REVIEW_FILE');target=path.with_name(path.name.replace('VEUX_M40_','VEUX_M41_',1));require(not target.exists(),'REVIEW_TARGET_EXISTS');path.rename(target)
        s=importlib.util.spec_from_file_location('m41_m25_pair',args.m25_tool);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify_package();pair=m.audit_pair(args.build,out)
        verify_fresh(args);result.update(status='M41_WT_CURRENT_ERROR_PROPAGATION_CONFIG_ABI_BOOT_AK3_PASS_NOFLASH',static_boot_path_pass=True,review_pair_sha256=pair,kernel_release=r['release']['verified_release'])
    except Exception as error:
        result.update(status='M41_PACKAGE_GATE_FAILED_NOFLASH',error=str(error));review=out/'review'
        if review.exists():review.rename(out/'unverified-review')
        raise
    finally:write_result(out,'M41_PACKAGE_RESULT.json',result)
    print('M41_STATIC_BOOT_AK3_PAIR_PASS DEVICE_PASS=NO FLASH=NO')

def main():
    p=argparse.ArgumentParser(description=__doc__);sub=p.add_subparsers(dest='op',required=True);sub.add_parser('verify-package');sub.add_parser('check-git-source').add_argument('--source',required=True)
    b=sub.add_parser('build')
    for n in ['m40-tool','m28-tool','m27-tool','m26-tool','m25-tool','r25-tool','r24-tool','r23-tool','r21-tool','r19-tool','r18-tool','r17-tool','base-tool','source','objout','r6-report','r6-tool','project','output']:b.add_argument('--'+n,required=True)
    a=sub.add_parser('package')
    for n in ['m40-tool','m28-tool','m27-tool','m26-tool','m25-tool','r25-tool','r24-tool','r23-tool','r21-package-tool','build','packager-tool','work','output']:a.add_argument('--'+n,required=True)
    args=p.parse_args();verify_package()
    if args.op=='build':build(args)
    elif args.op=='package':package(args)
    elif args.op=='check-git-source':print(json.dumps(check_git_source(args.source),sort_keys=True))
    else:print('M41_PACKAGE_VERIFIED FULL_BUILD_PENDING DEVICE_PASS=NO FLASH=NO')

if __name__=='__main__':main()
