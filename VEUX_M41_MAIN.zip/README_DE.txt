VEUX M41 - BQ-Eingangsstromgrenze und WT-Fehlerrueckgabe - NOFLASH
Gruene Referenz: M40-R2, Lauf 44008193025, Commit
1405d90119332f96f28c2568d1a676cd505f85be.

UPLOAD AM SMARTPHONE
1. VEUX_M41_MAIN.zip unveraendert ins Repo-Hauptverzeichnis hochladen.
   MAIN nicht entpacken; angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M41_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach den M41-Workflow manuell starten.
   Aeltere Pakete werden aus festen Commits authentifiziert geladen.

M40-R2 AUSGEWERTET
Alle 32 Artefakte heruntergeladen und mit API-SHA256, ZIP-CRC und sicheren Pfaden
geprueft: 1.527 Dateien, 1.440 Textdateien, 394 JSON-Dateien, 42.463.437 Textbytes.
Neun Archive enthalten historische Zwischenfehler oder negative Kontrollbelege.
Die sechs alten Fehlerziele sind spaeter in R18 erfolgreich unter den 15 ARM64-
Objekten enthalten; R19 belegt 13 typisierte Provider. Historische R20-Produkte
stimmen mit ihrem eigenen Bericht ueberein. Dessen alter negativer Vendor-CRC-
Status beschreibt nicht den finalen M40. Keine aktuellen Compilerfehler.
Der finale M40 wurde erneut auf echte Quellen, LLVM-Objekte/CFI-Kommandos,
14 verlinkte BQ-Schnittstellen, den Zahlenwert-Guard, konsistente
.config/config_data/Image/vmlinux/autoconf und die komplette Exporttabelle geprueft.
40 make-Kommandos erfolgreich. Unabhaengiger Abgleich der bekannten Vendor-Kohorte:
1.423 passende Import-CRCs, null CRC-Abweichungen oder fehlende Exporte, 37 Module.
Boot.img und AK3 aus gepinnten Referenzen byteidentisch rekonstruiert; Stock-
Ramdisk, Header, AVB-Hash und identischer eingebauter Kernel geprueft.
Diese tiefen Binaer-/ABI-/Boot-Pruefungen betreffen den finalen M40.
Reports/RUN44008193025_32_ARTEFAKTE.zip und M40_R2_INDEPENDENT_VERIFICATION.json
enthalten die Auswertung. Static Boot Pass ist kein Device Pass.

M41: ZWEI ZUSAMMENHAENGENDE REPARATUREN
1. Der BQ-Eingangsstromkanal weist Werte unter der bestehenden IINLIM-Basis
   von 100 mA vor Bus-, GPIO-, Provider- oder Cache-Zugriff mit -EINVAL ab.
   M40 setzte einen direkten 0-mA-Auftrag auf Feldwert 62, also 3.200 mA.
   Das wurde mit der echten M40-Funktion reproduziert. Die bisherigen oberen
   3.100-mA-Begrenzungen und alle gueltigen Umrechnungen bleiben gleich.
2. WT mtbf_current_store gibt den Fehler des nachgeordneten IIO-Treibers zurueck.
   Es speichert einen neuen Override erst nach erfolgreicher Programmierung.
   M40 meldete auch nach einer Abweisung Erfolg und speicherte den Wert vorher.
   Ein Busfehler kann teilweise Hardwareaenderungen hinterlassen; kein Rollback
   wird behauptet. Der gespeicherte Wunschwert wird bei Fehler nicht veroeffentlicht.

Die bestehende WT-Nullwert-Bedeutung bleibt erhalten: mtbf_current=0 schaltet
den Test-Override ab, wie die bestehende Bedingung >500 && <=4000 voraussetzt.
M41 loescht bei diesem Kommando den Override ohne einen 0-mA-Hardwareauftrag.
Nach WT-Shutdown wird auch dieses Kommando mit -ENODEV abgewiesen.
Direkte 0-mA-Auftraege an den BQ-IIO-Zahlenkanal bleiben ungueltig.

Genau zwei Funktionskoerper aendern sich gegen die gebaute M40-Referenz:
mtbf_current_store und bq_iio_write_raw_unlocked. Alle weiteren WT-/BQ-Bytes,
Header, Defconfig, GPIO-Zuordnungen und numerischen Lade-/Temperaturregeln bleiben
gleich. Insbesondere bleibt der Steuerwert -1 des HIZ-Kanals erlaubt.
Originalkennung: 5.4.274-qgki-g82179e362f33.
M40s vollstaendige unveraenderte Pruefwerkzeuge werden authentifiziert geladen.
Die M41-Schicht erweitert genau die zwei Quellen-Nachabbild-Hashes und prueft
beide neuen Zweige in Image UND vmlinux, echtes LLVM-Objekt/CFI-Kommando und den
verlinkten WT-Store-Callback. Alle anderen Quellen-Pins bleiben verpflichtend.
Alte gruene M40-Berichte koennen den neuen M41-Nachweis nicht ersetzen.

PRUEFUNGEN
Der native Vertragstest benutzt den echten WT-Store, modellierten IIO-Dispatch
und den echten BQ-Writer samt Registerfunktionen. Nur Dispatch/Hardware sind
Mocks; das ist kein Test am Smartphone. 36.414 C-Assertions: alle 4.095 negativen
Provider-Fehlerwerte, 12 Busfehlerfaelle, 4.914 unveraenderte Erfolgsablaeufe,
ungueltige Klein-/Negativwerte, Parsefehler, Start-/Stoppfaelle und Nullwert-Loeschen.
Zusaetzlich laufen die zwoelf bisherigen nativen BQ-Suiten auf der echten M41-
Quelle: 145.081 C-Assertions. Zusammen 181.495 aktuelle C-Assertions.
20 Regressionen pruefen auch Quellumfang, Hash-Faelschungen, alte Produkte,
wirkliche Eltern-Bau-Callbacks, Paket-Quarantaene und beide CLI-Kommandos.
Der komplette geaenderte WT- und BQ-Treiber kompiliert mit AOSP Clang 12.0.5,
ARM64, CFI/ThinLTO und den Headern des aktuellen M40-Laufs.
Alle 17 ausgelieferten Vorpruef-Kommandos wurden gegen einen echten gepinnten
Git-Checkout ausgefuehrt, waehrend die spaetere R9-Kopie noch nicht existiert.
Die originale M40-R2-Suite laeuft mit ihrer authentischen Original-YAML weiter.
Kein vollstaendiger lokaler M41-Kernelbau. Dieser ist der naechste GitHub-Schritt.

GEMEINSAME RESTLISTE UND ABSCHLUSSKRITERIEN
P2 - hoechste verbleibende Prioritaet: Eine VINDPM-Messung kann einen inzwischen
erfolgreichen CHARGING_ENABLED=0-Auftrag durch ihr bedingungsloses Wiedereinschalten
ueberschreiben. Ein echter Thread-Test reproduziert dies mit fuenf Assertions.
Das ist ausdruecklich ein offener Release-Blocker, kein Sicherheits-Pass.
Zu loesen: Reihenfolge und Prioritaet von Messung, explizitem/thermischem Abschalten,
OTG und anderen Workern, ohne Lock-Zyklen ueber Provider oder synchrones Canceln.
P1: BQ drainiert bereits Worker/IIO vor dem Freigeben seiner Providerreferenzen.
WT remove ist dagegen leer, shutdown setzt nur ein Flag. Provider-Lebensdauer,
Probe-Unwind und laufende Nutzer muessen gemeinsam abgesichert werden.
P3: Eingangsstrom-/WT-Vertrag oben repariert. Bereiche und Einheiten der anderen
Zahlenkanaele sowie kompletter GPIO-/DT-Abgleich bleiben offen.
K1: Historische >7.100 Ganzkernel-Abweichungen sind nicht vollstaendig bewertet.
Boot-/ABI-/Hardware-kritische Abweichungen bleiben vor Abschluss nachzuweisen.
D1: Echte Boot-, Lade-/OTG-, Temperatur-, Suspend-, Unplug-/Remove-Tests und ein
verfuegbarer Wiederherstellungsweg fehlen. Device Pass NEIN. Flashfreigabe NEIN.
Details: Reports/M41_CONSOLIDATED_RESTLIST.json. Keine neuen Zusatzfunktionen.
