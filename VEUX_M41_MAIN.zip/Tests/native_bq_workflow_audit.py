"""Reproduce the remaining P2 workflow conflict using real driver functions."""
import argparse,subprocess,tempfile
from pathlib import Path
from native_wt_current import bq_parts,function

def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args();prefix,defs,body,reset,baseline=bq_parts();source=a.source.read_text()
 for n in ['bq_iio_write_raw_unlocked','bq_iio_write_raw']:body=body.replace(function(baseline,n),function(source,n))
 # This diagnostic deliberately tests an unresolved P2 path, not flash readiness.
 prefix=prefix.replace('registers[256], saved_registers[256]','registers[256]').replace('events[256], saved_events[256]','events[256]')
 sync=r'''
#define dev_err_ratelimited(...) ((void)0)
#define dev_info(...) ((void)0)
#define BQ2589X_VBUS_USB_SDP 1
static atomic_int asleep,released;
static void msleep(int ms){if(ms==1000){atomic_store(&asleep,1);while(!atomic_load(&released))sched_yield();}}
'''
 body+='\n'+function(source,'bq2589x_adc_read_vbus_volt')+'\n'+function(source,'bq2589x_adjust_absolute_vindpm')
 tests=r'''
static void*measurement(void*p){bq2589x_adjust_absolute_vindpm(&state);return NULL;}
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
int main(void){reset(1,1,0,0,1);state.vbus_type=BQ2589X_VBUS_USB_SDP;registers[BQ2589X_REG_03]|=BQ2589X_CHG_CONFIG_MASK;state.status|=BQ2589X_STATUS_CHARGE_ENABLE;
 pthread_t thread;CHECK(!pthread_create(&thread,NULL,measurement,NULL));while(!atomic_load(&asleep))sched_yield();
 struct iio_chan_spec channel={PSY_IIO_CHARGING_ENABLED};CHECK(bq_iio_write_raw(&iio,&channel,0,0,0)==0);CHECK(!(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK));
 atomic_store(&released,1);CHECK(!pthread_join(thread,NULL));CHECK(registers[BQ2589X_REG_03]&BQ2589X_CHG_CONFIG_MASK);
 printf("P2_EXPLICIT_CHARGE_DISABLE_OVERRIDDEN_BY_VINDPM=REPRODUCED; assertions=%d; release_blocker=true; not a hardware safety pass\n",assertions);return 0;}
'''
 with tempfile.TemporaryDirectory(prefix='m41-workflow-audit-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(prefix+'\n'+defs+'\n'+sync+'\n'+body+'\n'+reset+'\n'+tests)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True);subprocess.run([str(exe)],check=True,timeout=15)
if __name__=='__main__':main()
