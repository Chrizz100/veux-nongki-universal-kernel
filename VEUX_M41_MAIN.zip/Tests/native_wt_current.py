"""Actual WT sysfs callback -> modeled IIO dispatch -> actual M41 BQ writer/setters."""
import argparse,ast,json,os,re,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
WT='drivers/power/supply/qcom/wt_chg.c'
BQ='drivers/power/supply/qcom/bq2589x_charger.c'

def function(s,n):
 m=re.search(r'^(?:static\s+)?[^\n;]+\b'+n+r'\([^;]+?\n\{',s,re.M)
 if not m:raise ValueError(n)
 return s[m.start():s.index('\n}',m.end())+2]

def bq_parts():
 parent=Path(os.environ['M40_DIR']);src=(parent/'After'/BQ).read_text();tree=ast.parse((parent/'Tests/native_bq_writes.py').read_text());values={}
 for n in ast.walk(tree):
  if isinstance(n,ast.Assign)and isinstance(n.value,ast.Constant):
   for t in n.targets:
    if isinstance(t,ast.Name)and t.id in ['prefix','tests']:values[t.id]=ast.literal_eval(n.value)
 prefix=values['prefix'].replace('state, other, saved_state, *g_bq','state, other, *g_bq').replace('int status, hz_flag,','int vbus_type, vbus_volt, status, hz_flag,')
 prefix+='\n#include <limits.h>\n#include <stddef.h>\n#include <stdatomic.h>\n#include <sched.h>\ntypedef uint16_t u16;\n'
 ids=json.loads((parent/'References/BOUND_IIO_CHANNEL_IDS.json').read_text())['channels'];constants='\n'.join('#define '+c['name']+' '+str(c['id'])for c in ids)
 definitions='\n'.join(l for l in(parent/'Before/drivers/power/supply/qcom/bq2589x_reg.h').read_text().splitlines()if l.startswith('#define BQ2589X_'))
 names=['bq2589x_read_byte','bq2589x_write_byte','bq2589x_update_bits','bq2589x_enable_otg','bq2589x_disable_otg','bq2589x_set_otg_volt','bq2589x_set_otg_current','bq2589x_enable_charger','bq2589x_disable_charger','bq2589x_set_charge_current','bq2589x_set_term_current','bq2589x_set_chargevoltage','bq2589x_set_input_volt_limit','bq2589x_set_input_current_limit','bq2589x_enter_hiz_mode','bq2589x_exit_hiz_mode','bq2589x_enable_term','bq2589x_usb_switch','bq2589x_resolve_supply','bq_iio_write_raw_unlocked','bq_iio_write_raw']
 body='\n\n'.join(function(src,n)for n in names);reset=re.search(r'static void reset\([^\n]+ \{\n.*?\n\}',values['tests'],re.S).group(0)
 return prefix,definitions+'\n'+constants,body,reset,src

def main():
 p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args();prefix,defs,body,reset,baseline_bq=bq_parts();prefix+='\n#define WRITE_ONCE(p,v) __atomic_store_n(&(p),(v),__ATOMIC_SEQ_CST)\n'
 candidate_bq=(ROOT/'After/drivers/power/supply/qcom/bq2589x_charger.c').read_text()
 for n in ['bq_iio_write_raw_unlocked','bq_iio_write_raw']:body=body.replace(function(baseline_bq,n),function(candidate_bq,n))
 original_bq='\n\n'.join(function(baseline_bq,n).replace('bq_iio_write_raw_unlocked(','original_bq_unlocked(').replace('bq_iio_write_raw(','original_bq_writer(')for n in ['bq_iio_write_raw_unlocked','bq_iio_write_raw'])
 current=function(a.source.read_text(),'mtbf_current_store');old=function((ROOT/'References/M40_PROVEN_WT.c').read_text(),'mtbf_current_store').replace('mtbf_current_store(','reference_store(',1)
 bridge=r'''
struct class {int unused;};struct class_attribute {int unused;};
struct batt_chg {struct class battery_class;int mtbf_current,shutdown_flag;};
#define container_of(p,t,m) ((t *)((char *)(p)-offsetof(t,m)))
#define MAIN 1
#define MAIN_INPUT_CURRENT_SETTLED 2
static struct batt_chg wt;
static int parse_rc,parse_value,parse_calls,provider_rc,dispatch_calls,cache_at_dispatch;
static bool original_route;
static int kstrtoint(const char*b,int base,int*v){parse_calls++;if(base!=10)abort();if(parse_rc)return parse_rc;*v=parse_value;return 0;}
/* Only dispatch is modeled: the complete BQ callback and hardware helpers are real. */
static int batt_set_iio_channel(struct batt_chg*chg,int type,int channel,int value){
 dispatch_calls++;cache_at_dispatch=chg->mtbf_current;
 if(chg->shutdown_flag)return -ENODEV;
 if(type!=MAIN||channel!=MAIN_INPUT_CURRENT_SETTLED)abort();
 if(provider_rc)return provider_rc;
 struct iio_chan_spec c={PSY_IIO_MAIN_INPUT_CURRENT_SETTLED};return bq_iio_write_raw(&iio,&c,value,0,0);
}
'''
 tests=r'''
#define CHECK(x)do{assertions++;if(!(x)){fprintf(stderr,"FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void prepare(int value){reset(1,1,0,0,1);memset(&wt,0,sizeof(wt));wt.mtbf_current=777;parse_rc=provider_rc=parse_calls=dispatch_calls=0;parse_value=value;cache_at_dispatch=-999;}
static ssize_t invoke(bool old){original_route=old;return old?reference_store(&wt.battery_class,NULL,"request",11):mtbf_current_store(&wt.battery_class,NULL,"request",11);}
int main(void){
 int provider_cases=0,bus_cases=0,success_cases=0,negative_cases=0,parse_cases=0,state_cases=0;
 prepare(1000);provider_rc=-EREMOTEIO;CHECK(invoke(true)==11&&wt.mtbf_current==1000);
 puts("WT_M40_REJECTED_REQUEST_REPORTED_SUCCESS_AND_CACHED=REPRODUCED");
 for(int err=1;err<=4095;err++){
  prepare(1000);provider_rc=-err;memcpy(saved_registers,registers,sizeof(registers));
  CHECK(invoke(false)==-err);CHECK(wt.mtbf_current==777&&cache_at_dispatch==777);
  CHECK(used==0&&!memcmp(saved_registers,registers,sizeof(registers)));CHECK(dispatch_calls==1&&parse_calls==1);provider_cases++;
 }
 prepare(0);struct iio_chan_spec input={PSY_IIO_MAIN_INPUT_CURRENT_SETTLED};CHECK(original_bq_writer(&iio,&input,0,0,0)==0);CHECK((registers[BQ2589X_REG_00]&BQ2589X_IINLIM_MASK)==62);puts("BQ_M40_ZERO_INPUT_CURRENT_PROGRAMS_3200MA=REPRODUCED");
 int values[]={100,256,500,512,1000,1500,2000,3000,3099,3100,3101,4000,INT_MAX};
 for(unsigned vi=0;vi<sizeof(values)/sizeof(*values);vi++){
  prepare(values[vi]);CHECK(invoke(true)==11);int old_cache=wt.mtbf_current,old_used=used;
  memcpy(saved_registers,registers,sizeof(registers));memcpy(saved_events,events,sizeof(events));
  prepare(values[vi]);CHECK(invoke(false)==11);CHECK(wt.mtbf_current==old_cache&&cache_at_dispatch==777);
  CHECK(used==old_used&&!memcmp(saved_registers,registers,sizeof(registers))&&!memcmp(saved_events,events,used*sizeof(*events)));success_cases++;
 }
 for(int value=100;value<=5000;value++){
  prepare(value);CHECK(invoke(true)==11);int old_cache=wt.mtbf_current,old_used=used;memcpy(saved_registers,registers,sizeof(registers));memcpy(saved_events,events,sizeof(events));
  prepare(value);CHECK(invoke(false)==11);CHECK(wt.mtbf_current==old_cache&&cache_at_dispatch==777);CHECK(used==old_used&&!memcmp(saved_registers,registers,sizeof(registers))&&!memcmp(saved_events,events,used*sizeof(*events)));success_cases++;
 }
 int errors[]={-EIO,-EREMOTEIO,-ENXIO};
 for(unsigned ei=0;ei<3;ei++)for(int kind=READ;kind<=WRITE;kind++)for(int at=1;at<=2;at++){
  prepare(1000);fail_kind=kind;fail_at=at;fail_code=errors[ei];
  CHECK(invoke(false)==errors[ei]);CHECK(wt.mtbf_current==777&&cache_at_dispatch==777);CHECK(last_failure>=0);bus_cases++;
 }
 int neg[]={-1,-64,-100,-3100,-1000000,INT_MIN,INT_MIN+1,1,50,63,64,99};
 for(unsigned vi=0;vi<sizeof(neg)/sizeof(*neg);vi++){
  prepare(neg[vi]);CHECK(invoke(false)==-EINVAL);CHECK(wt.mtbf_current==777&&cache_at_dispatch==777&&used==0);negative_cases++;
 }
 int parse_errors[]={-EINVAL,-ERANGE,-EFAULT};
 for(unsigned i=0;i<3;i++){prepare(1000);parse_rc=parse_errors[i];CHECK(invoke(false)==-EINVAL);CHECK(wt.mtbf_current==777&&dispatch_calls==0&&used==0);parse_cases++;}
 prepare(1000);wt.shutdown_flag=1;CHECK(invoke(false)==-ENODEV);CHECK(wt.mtbf_current==777&&used==0);state_cases++;
 prepare(1000);state.startup_ready=false;CHECK(invoke(false)==-EPROBE_DEFER);CHECK(wt.mtbf_current==777&&used==0);state_cases++;
 prepare(1000);state.stopping=true;CHECK(invoke(false)==-ESHUTDOWN);CHECK(wt.mtbf_current==777&&used==0);state_cases++;
 /* Every nonnegative value below the actual IINLIM base is rejected. */
 for(int value=1;value<BQ2589X_IINLIM_BASE;value++){
  prepare(value);CHECK(invoke(false)==-EINVAL);CHECK(wt.mtbf_current==777&&used==0);CHECK(cache_at_dispatch==777);
 }
 puts("BQ_M41_BELOW_MINIMUM_INPUT_REJECTED_BEFORE_BUS=PASS");
 prepare(0);CHECK(bq_iio_write_raw(&iio,&input,0,0,0)==-EINVAL);CHECK(used==0);
 prepare(0);CHECK(invoke(false)==11);CHECK(wt.mtbf_current==0&&dispatch_calls==0&&used==0);prepare(0);wt.shutdown_flag=1;CHECK(invoke(false)==-ENODEV);CHECK(wt.mtbf_current==777&&dispatch_calls==0&&used==0);
 printf("WT_CURRENT_HOST_TESTS=PASS; assertions=%d; provider_error_cases=%d; bus_error_cases=%d; unchanged_success_cases=%d; negative_cases=%d; parse_cases=%d; lifecycle_cases=%d\n",assertions,provider_cases,bus_cases,success_cases,negative_cases,parse_cases,state_cases);return 0;
}
'''
 with tempfile.TemporaryDirectory(prefix='m41-wt-current-')as t:
  c=Path(t)/'test.c';exe=Path(t)/'test';c.write_text(prefix+'\n'+defs+'\n'+body+'\n'+original_bq+'\n'+reset+'\n'+bridge+'\n'+current+'\n'+old+'\n'+tests)
  subprocess.run(['cc','-std=gnu11','-O2','-Wall','-Wextra','-Werror','-Wno-unused-parameter','-Wno-unused-function','-pthread','-fsanitize=undefined','-fno-sanitize-recover=all',str(c),'-o',str(exe)],check=True);subprocess.run([str(exe)],check=True,timeout=20)
if __name__=='__main__':main()
