import argparse,contextlib,copy,hashlib,importlib.util,io,json,os,shutil,subprocess,sys,tempfile,textwrap,unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sp=importlib.util.spec_from_file_location('m41_tested',ROOT/'Tools/m41_wt_current.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
P40=Path(os.environ.get('M40_DIR',str(ROOT.parent/'current-m40-r2-main')))
P28=Path(os.environ.get('M28_DIR',str(ROOT.parent/'m40r2-success-run/veux-m28-wt-tools')))
P27=Path(os.environ.get('M27_DIR',str(ROOT.parent/'m40r2-success-run/veux-m27-sc8551-tools')))
P26=Path(os.environ.get('M26_DIR',str(ROOT.parent/'m40r2-success-run/veux-m26-rpm-tools')))

def refresh(root):
    files=sorted(p for p in root.rglob('*')if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256.txt')
    (root/'MANIFEST_SHA256.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n'for p in files))

def run_blocks(path):
    rows=Path(path).read_text().splitlines();result=[]
    for i,row in enumerate(rows):
        if row.strip()!='run: |':continue
        indent=len(row)-len(row.lstrip());body=[]
        for line in rows[i+1:]:
            if line.strip()and len(line)-len(line.lstrip())<=indent:break
            body.append(line)
        result.append(textwrap.dedent('\n'.join(body))+'\n')
    return result

class SourceTests(unittest.TestCase):
    def test_complete_package_and_exact_two_function_scope(self):
        m.verify_package();wt=(ROOT/'After'/m.WT).read_text();before=(ROOT/'References/M40_PROVEN_WT.c').read_text()
        self.assertEqual(wt.replace(m.function(wt,'mtbf_current_store'),m.function(before,'mtbf_current_store'),1),before)
        bq=(ROOT/'After'/m.BQ).read_text();self.assertEqual(bq.replace((ROOT/'References/BQ_INPUT_GUARD.txt').read_text(),'',1),(ROOT/'References/M40_PROVEN_BQ.c').read_text())

    def test_native_current_pipeline_and_all_provider_errors(self):
        r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_wt_current.py'),str(ROOT/'After'/m.WT)],text=True,capture_output=True,timeout=30)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn('assertions=36414; provider_error_cases=4095; bus_error_cases=12; unchanged_success_cases=4914;',r.stdout);self.assertIn('BQ_M41_BELOW_MINIMUM_INPUT_REJECTED_BEFORE_BUS=PASS',r.stdout);self.assertNotIn('runtime error:',r.stderr)

    def test_twelve_inherited_native_bq_suites_on_actual_m41_source(self):
        names=['reads','writes','startup','shutdown','init_errors','adapter_errors','monitor_errors','vindpm_hiz','rmw','bundle','bundle_probe','providers']
        total=0
        for name in names:
            with self.subTest(name=name):
                script=P40/'Tests'/('native_bq_'+name+'.py')
                r=subprocess.run([sys.executable,'-B',str(script),str(ROOT/'After'/m.BQ)],text=True,capture_output=True,timeout=35)
                self.assertEqual(r.returncode,0,r.stdout+r.stderr)
                import re
                total+=int(re.search(r'assertions=(\d+)',r.stdout).group(1))
                self.assertNotIn('runtime error:',r.stderr)
        self.assertEqual(total,145081)

    def test_original_wt_callback_cannot_pass_correct_error_and_cache_expectations(self):
        r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_wt_current.py'),str(ROOT/'References/M40_PROVEN_WT.c')],text=True,capture_output=True,timeout=30)
        self.assertNotEqual(r.returncode,0);self.assertIn('FAIL line ',r.stderr)

    def test_remaining_parallel_workflow_bug_is_reproduced_and_labelled_blocker(self):
        r=subprocess.run([sys.executable,'-B',str(ROOT/'Tests/native_bq_workflow_audit.py'),str(ROOT/'After'/m.BQ)],text=True,capture_output=True,timeout=25)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr);self.assertIn('P2_EXPLICIT_CHARGE_DISABLE_OVERRIDDEN_BY_VINDPM=REPRODUCED',r.stdout);self.assertIn('release_blocker=true',r.stdout)

    def test_self_consistent_unapproved_thermal_edit_is_rejected(self):
        with tempfile.TemporaryDirectory()as t:
            root=Path(t);shutil.copytree(ROOT,root,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'));p=root/'After'/m.WT;before=p.read_text();self.assertIn('temp >= 480',before);p.write_text(before.replace('temp >= 480','temp >= 481',1));pr=json.loads((root/'References/PROFILE.json').read_text());pr['wt_after_sha256']=m.sha(p);(root/'References/PROFILE.json').write_text(json.dumps(pr));refresh(root)
            with patch.object(m,'ROOT',root),self.assertRaisesRegex(ValueError,'ONLY_WT_CURRENT'):m.verify_package()

    def test_self_consistent_different_minimum_guard_is_rejected(self):
        with tempfile.TemporaryDirectory()as t:
            root=Path(t);shutil.copytree(ROOT,root,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'));p=root/'References/BQ_INPUT_GUARD.txt';p.write_text(p.read_text().replace('BQ2589X_IINLIM_BASE','101'));refresh(root)
            with patch.object(m,'ROOT',root),self.assertRaisesRegex(ValueError,'EXACT_MINIMUM_INPUT_GUARD_REQUIRED'):m.verify_package()

    def test_fixture_directory_is_not_a_donor_checkout(self):
        with tempfile.TemporaryDirectory()as t:
            shutil.copytree(ROOT/'Before',t,dirs_exist_ok=True)
            with self.assertRaisesRegex(ValueError,'REAL_DONOR_CHECKOUT_REQUIRED'):m.check_git_source(t)

    def test_authentic_engine_applies_both_new_postimages_and_preserves_all_other_pins(self):
        with tempfile.TemporaryDirectory()as t,m.engine(P40/'Tools/m40_bq_numeric_inputs.py',P28/'Tools/m28_wt_reporting.py')as(e,p28):
            source=Path(t)
            for p in [P28,P40]:shutil.copytree(p/'Before',source,dirs_exist_ok=True)
            wt=p28.apply_source(source);bq=e.apply_source(source)
            self.assertEqual(wt[m.WT],m.profile()['wt_after_sha256']);self.assertEqual(bq[m.BQ],m.profile()['bq_after_sha256']);m.check_source(source,after=True)
            (source/'include/linux/power_supply.h').write_bytes(b'wrong unrelated header')
            with self.assertRaisesRegex(ValueError,'SOURCE_CONTEXT_CHANGED'):p28.source_check(source,after=True)

    def test_original_m40_postimages_do_not_satisfy_m41_source_proof(self):
        with tempfile.TemporaryDirectory()as t:
            source=Path(t)
            for name,ref in [(m.WT,'M40_PROVEN_WT.c'),(m.BQ,'M40_PROVEN_BQ.c')]:
                p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((ROOT/'References'/ref).read_bytes())
            with self.assertRaisesRegex(ValueError,'SOURCE_CONTEXT_CHANGED'):m.check_source(source,after=True)

    def test_exact_lower_build_callback_chain_before_compilation(self):
        with tempfile.TemporaryDirectory()as t,m.engine(P40/'Tools/m40_bq_numeric_inputs.py',P28/'Tools/m28_wt_reporting.py')as(e,p28):
            out=Path(t);source=out/'candidate-source'
            for p in [P26,P27,P28,P40]:shutil.copytree(p/'Before',source,dirs_exist_ok=True)
            sc=p28.load_parent(P27/'Tools/m27_sc8551.py');rpm=sc.load_parent(P26/'Tools/m26_rpm_sleep.py');saved=p28.apply_source
            def stop(args):
                rpm.apply_source(source);rpm.source_check(source,after=True);sc.source_check(source,after=True);p28.source_check(source,after=True);e.source_check(source,after=True);m.check_source(source,after=True);raise RuntimeError('ACTUAL_LAYERED_CALLBACKS_PASS_BEFORE_COMPILE')
            with patch.object(p28,'load_parent',return_value=sc),patch.object(sc,'load_parent',return_value=rpm),patch.object(rpm,'build',side_effect=stop),patch.object(m,'engine',return_value=contextlib.nullcontext((e,p28))):
                args=argparse.Namespace(m40_tool='fixture',m28_tool=str(P28/'Tools/m28_wt_reporting.py'),m27_tool='fixture',m26_tool='fixture',output=str(out))
                with self.assertRaisesRegex(RuntimeError,'ACTUAL_LAYERED_CALLBACKS'):m.build(args)
            self.assertIs(p28.apply_source,saved);r=json.loads((out/'M41_RESULT.json').read_text());self.assertFalse(r['kernel_compiled']);self.assertFalse(r['flash_allowed'])

    def test_old_green_m40_result_cannot_pass_m41_gate(self):
        with tempfile.TemporaryDirectory()as t:
            (Path(t)/'M41_RESULT.json').write_text(json.dumps({'status':'M40_GREEN','kernel_compiled':True}))
            with self.assertRaisesRegex(ValueError,'FRESH_M41_FULL_BUILD_REQUIRED'):m.verify_fresh(argparse.Namespace(build=t))

    def test_package_failure_quarantines_review_pair(self):
        with tempfile.TemporaryDirectory()as t:
            out=Path(t);(out/'review').mkdir();(out/'review/old.img').write_bytes(b'fixture')
            def fail(a):raise RuntimeError('PARENT_STATIC_GATE_FAILED')
            with patch.object(m,'verify_package'),patch.object(m,'verify_fresh',return_value={}),patch.object(m,'engine',return_value=contextlib.nullcontext((argparse.Namespace(package=fail),None))):
                with self.assertRaisesRegex(RuntimeError,'PARENT_STATIC_GATE_FAILED'):m.package(argparse.Namespace(m40_tool='x',m28_tool='y',output=t))
            self.assertTrue((out/'unverified-review/old.img').exists());self.assertFalse(json.loads((out/'M41_PACKAGE_RESULT.json').read_text())['flash_allowed'])

class ProductTests(unittest.TestCase):
    def fixture(self,root):
        shutil.copytree(ROOT/'After',root/'candidate-source');out=root/'candidate-out';(out/'arch/arm64/boot').mkdir(parents=True)
        (out/'.config').write_bytes(b'CONFIG_SYNTHETIC_UNIT_FIXTURE=y\n');(out/'Module.symvers').write_bytes(b'synthetic unit fixture\n')
        obj=out/m.WT.replace('.c','.o');obj.parent.mkdir(parents=True);obj.write_bytes(b'BC\xc0\xdeSYNTHETIC UNIT FIXTURE');(obj.parent/('.'+obj.name+'.cmd')).write_text(m.WT+' -flto=thin -fsanitize=cfi')
        for name in ['arch/arm64/boot/Image','vmlinux']:(out/name).write_bytes(b'SYNTHETIC UNIT FIXTURE '+m.MARKER+b' '+m.INPUT_MARKER)
        (out/'System.map').write_text('ffffffc010000000 t mtbf_current_store$123.cfi_jt\n')
        return out,dict(m.profile(),baseline_config_sha256=m.sha(out/'.config'),full_symvers_sha256=m.sha(out/'Module.symvers'))
    def test_both_new_branches_and_actual_sources_are_required(self):
        with tempfile.TemporaryDirectory()as t:
            out,p=self.fixture(Path(t))
            with patch.object(m,'profile',return_value=p):r=m.current_proof(t)
            self.assertEqual(len(r['wt_current_source_hashes']),2);self.assertEqual(len(r['linked_wt_current_callback']),1)
    def test_each_branch_must_be_in_both_kernel_products(self):
        for name in ['arch/arm64/boot/Image','vmlinux']:
            for marker in [m.MARKER,m.INPUT_MARKER]:
                with self.subTest(name=name,marker=marker),tempfile.TemporaryDirectory()as t:
                    out,p=self.fixture(Path(t));(out/name).write_bytes(b'old synthetic fixture '+(m.INPUT_MARKER if marker==m.MARKER else m.MARKER))
                    with patch.object(m,'profile',return_value=p),self.assertRaisesRegex(ValueError,'NOT_LINKED'):m.current_proof(t)
    def test_cfi_callback_object_config_and_exports_cannot_drift(self):
        for name in [m.WT.replace('.c','.o'),'.config','Module.symvers','System.map','drivers/power/supply/qcom/.wt_chg.o.cmd']:
            with self.subTest(name=name),tempfile.TemporaryDirectory()as t:
                out,p=self.fixture(Path(t));(out/name).write_bytes(b'wrong product')
                with patch.object(m,'profile',return_value=p),self.assertRaises(ValueError):m.current_proof(t)

@unittest.skipUnless(os.environ.get('M41_WORKFLOW'),'M41_WORKFLOW required')
class WorkflowTests(unittest.TestCase):
    def command(self,op):
        found=[s for s in run_blocks(os.environ['M41_WORKFLOW'])if '"$M41_DIR/Tools/m41_wt_current.py" '+op in s];self.assertEqual(found,[(ROOT/f'References/M41_{op.upper()}_COMMAND.sh').read_text()]);return found[0]
    def capture(self,op):
        with tempfile.TemporaryDirectory(prefix='m41 cli paths spaces ')as t:
            root=Path(t);(root/'bin').mkdir();p=root/'bin/python3';p.write_text('#!/bin/bash\nprintf \'%s\\0\' "$@" > "$M41_CAPTURE"\n');p.chmod(0o755)
            keys=['M40_DIR','M28_DIR','M27_DIR','M26_DIR','M25_DIR','R25_DIR','R24_DIR','R23_DIR','R21_SCHED_DIR','R19_RMNET_DIR','R18_IRQ_DIR','R17_CACHE_DIR','R16_REPAIR_DIR','R9_SNAPSHOT','R13_OBJOUT','R47_REPORT_DIR','R47_TOOLS_DIR','GITHUB_WORKSPACE','R16_REPAIR_OUTPUT','R21_PACK_DIR','R21_PACKAGE_OUTPUT'];env={k:str(root/(k+' spaces'))for k in keys};env['M41_DIR']=str(ROOT)
            r=subprocess.run(['bash','-c',self.command(op)],env=dict(os.environ,**env,PATH=str(root/'bin')+os.pathsep+os.environ['PATH'],M41_CAPTURE=str(root/'argv')),text=True,capture_output=True,timeout=10);self.assertEqual(r.returncode,0,r.stderr);argv=(root/'argv').read_bytes().decode().split('\0');self.assertEqual(argv.pop(),'');self.assertEqual(argv.pop(0),'-B');return argv,env
    def test_build_command_has_all_nineteen_paths(self):
        argv,env=self.capture('build')
        with patch.object(sys,'argv',argv),patch.object(m,'verify_package'),patch.object(m,'build')as call:m.main()
        a=vars(call.call_args.args[0]);self.assertEqual(len(a),20);self.assertEqual(a['m40_tool'],env['M40_DIR']+'/Tools/m40_bq_numeric_inputs.py');self.assertEqual(a['source'],env['R9_SNAPSHOT'])
    def test_package_command_has_all_thirteen_paths(self):
        argv,env=self.capture('package')
        with patch.object(sys,'argv',argv),patch.object(m,'verify_package'),patch.object(m,'package')as call:m.main()
        a=vars(call.call_args.args[0]);self.assertEqual(len(a),14);self.assertEqual(a['work'],env['GITHUB_WORKSPACE']+'/r46-m41-pack-work')
    def test_plus_typo_is_still_rejected_before_action(self):
        for op in ['build','package']:
            argv,_=self.capture(op);argv.insert(2,'+')
            with patch.object(sys,'argv',argv),patch.object(m,'verify_package'),patch.object(m,op)as call,contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):m.main()
            call.assert_not_called()
    def test_all_seventeen_preflight_calls_use_existing_checkout(self):
        found=[s for s in run_blocks(os.environ['M41_WORKFLOW'])if '"$M41_DIR/Tools/m41_wt_current.py" check-git-source'in s];self.assertEqual(len(found),1);self.assertEqual(found[0].count('--source "$GITHUB_WORKSPACE/kernel"'),17);self.assertNotIn('$R9_SNAPSHOT',found[0])

if __name__=='__main__':unittest.main()
