# VEUX R20-R7 original Qualcomm scheduler topology diagnostic — NOFLASH

Parent R20-R6 Action 42184977509 (job 127783069922): **8/8 target + 12/12 R17 regression objects** compiled successfully. The full build stopped in `kernel/sched/topology.c` before linking vmlinux.

Source-backed diagnostics:
- Donor `build_perf_domains` references `min_cap_cpu_mask` originating in donor `core.c` (removed by the pinned Qualcomm core trial); the original Qualcomm `build_perf_domains` has no such donor / SPRD dependency and preserves WALT Energy-Aware Scheduling policy.
- Donor `init_sched_groups_capacity` is `static`; the pinned Qualcomm `sched.h` declares it `extern` because `qc_vas.c` invokes it. The original Qualcomm implementation is global and excludes isolated CPUs from group weights under WALT.

Only **these two complete, unmodified upstream function bodies** are substituted inside disposable `kernel/sched/topology.c`, after `git show` and original Git blob checks. This is not a generic source-file transplant. The donor and Qualcomm trees are checked clean before and after. A new ninth compiler gate for `topology.o` runs alongside the eight previously successful targets, followed by all 12 R17 regression objects, then real Image/dtbs build if and only if every gate passes.

An existing `CONFIG_SPRD_ROTATION_TASK=y` configuration is rejected rather than silently removing an in-use donor function. Nothing is changed in production kernel, BakaSU, SUSFS, ReSukiSU, NoMount, ROM boot, ABI, flash or installer. The source experiment is not proof of OEM ABI, WALT runtime, Stock 5.4.274 reproducibility or device boot. **NOFLASH**.
