#!/system/bin/sh
# Read-only inventory for the currently running environment. No root request and no slot switch.
LC_ALL=C
export LC_ALL

STOCK_SHA=ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5
CANDIDATE_SHA=6958229b835f87269776dd4bcbfda7f8e052a8c19a7a8edb871945aab3c43b6d
print_value() { printf '%s=%s\n' "$1" "${2:-unbekannt}"; }
prop() { getprop "$1" 2>/dev/null; }
bootarg() {
    # Return only the requested public boot parameter from cmdline or bootconfig.
    for src in /proc/bootconfig /proc/cmdline; do
        [ -r "$src" ] || continue
        if [ "$src" = /proc/bootconfig ]; then
            v=$(awk -F= -v k="$1" '{key=$1; gsub(/[[:space:]]/,"",key); if(key==k){v=$2; gsub(/["[:space:]]/,"",v); print v; exit}}' "$src" 2>/dev/null)
        else
            v=$(awk -v k="$1=" '{for(i=1;i<=NF;i++) if(index($i,k)==1){print substr($i,length(k)+1);exit}}' "$src" 2>/dev/null)
        fi
        [ -n "$v" ] && { printf '%s' "$v"; return; }
    done
}
identity() {
    case "$1" in "$STOCK_SHA") echo 'Xiaomi-Stock' ;; "$CANDIDATE_SHA") echo 'M44-M45-Kandidatenabbild' ;;
        '') echo 'unbekannt' ;; *) echo 'anderes-Abbild' ;; esac
}
hash_file() { out=$(sha256sum "$1" 2>/dev/null) && printf '%s' "${out%% *}"; }

command -v getprop >/dev/null 2>&1 || { echo 'Android oder Android-Recovery erforderlich.' >&2; exit 2; }
[ "$#" -le 1 ] || { echo 'Optional ein Pfad zum entpackten Stock-boot.img.' >&2; exit 2; }
print_value format M46
print_value geraet "$(prop ro.product.device)"
print_value build "$(prop ro.build.version.incremental)"
print_value kernel "$(uname -r)"
print_value bootmodus "$(prop ro.bootmode)"
print_value verifiedbootstate "$(prop ro.boot.verifiedbootstate)"
print_value veritymode "$(prop ro.boot.veritymode)"
slot=$(prop ro.boot.slot_suffix)
[ -n "$slot" ] || slot=$(bootarg androidboot.slot_suffix)
print_value slot "$slot"
for key in dtbo_idx dtb_idx vbmeta.invalidate_on_error; do
    v=$(bootarg "androidboot.$key")
    [ -n "$v" ] || v=$(prop "ro.boot.$key")
    print_value "$key" "$v"
done
avbdev=$(bootarg androidboot.vbmeta.device)
[ -n "$avbdev" ] || avbdev=$(prop ro.boot.vbmeta.device)
if [ -n "$avbdev" ]; then echo vbmeta_device_parameter=vorhanden; else echo vbmeta_device_parameter=unbekannt; fi

for short in ufshc@4804000 ufsphy_mem@4807000; do
    dt="/proc/device-tree/soc/$short"
    if [ -r "$dt/status" ]; then state=$(tr -d '\000' < "$dt/status")
    elif [ -r "$dt/compatible" ]; then state='okay (Standardwert)'
    else state=unbekannt; fi
    print_value "$short.status" "$state"
    driver=''
    case "$short" in ufshc*) prefix=4804000 ;; *) prefix=4807000 ;; esac
    for d in /sys/bus/platform/devices/"$prefix".*/driver; do
        [ -L "$d" ] || continue
        link=$(readlink "$d") && driver=${link##*/}
        [ -n "$driver" ] && break
    done
    print_value "$short.treiber" "$driver"
done
for node in /sys/class/block/dm-*/dm/name; do
    [ -r "$node" ] || continue
    read -r name < "$node" || continue
    case "$name" in system-verity|system_ext-verity|product-verity|vendor-verity|odm-verity) print_value dm_name "$name" ;; esac
done
case "$slot" in
    _a|_b)
        for part in boot_a boot_b recovery recovery_a recovery_b; do
            seen=unbekannt
            for dir in /dev/block/by-name /dev/block/bootdevice/by-name; do
                block="$dir/$part"
                [ -b "$block" ] || continue
                seen=sichtbar
                if [ "$part" = "boot$slot" ] && [ -r "$block" ]; then
                    digest=$(hash_file "$block")
                    print_value aktiver_boot_sha256 "$digest"
                    print_value aktives_boot_abbild "$(identity "$digest")"
                fi
                break
            done
            print_value "$part" "$seen"
        done ;;
esac
if [ "$#" -eq 1 ]; then
    [ -f "$1" ] && [ -r "$1" ] || { echo stockdatei=unlesbar; exit 3; }
    case "$1" in /*) backup=$1 ;; *) backup=./$1 ;; esac
    digest=$(hash_file "$backup")
    print_value stockdatei_sha256 "$digest"
    print_value stockdatei "$(identity "$digest")"
    [ "$digest" = "$STOCK_SHA" ] || exit 3
fi
echo 'geraetestart_des_kandidaten=offen'
echo 'unabhaengige_wiederherstellung_ohne_pc=offen'
