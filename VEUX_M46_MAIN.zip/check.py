"""Compare pinned M45 outputs with the Xiaomi firmware and the R37 device capture."""

import argparse
import ctypes
import ctypes.util
import hashlib
import io
import json
import lzma
import os
from pathlib import Path
import struct
import subprocess
import tempfile
import zipfile

import avbtool
from stock_ota import restore, STOCK_SHA

ROOT = Path(__file__).resolve().parent
REF = ROOT / "reference"
ARCHIVE = "90a263362497c2a57bde8edfdc9f05d1b004ed39d5b9539ed4af0dbd7c388783"
BOOT = "6958229b835f87269776dd4bcbfda7f8e052a8c19a7a8edb871945aab3c43b6d"
AK3 = "e610d73a3966cf3125d9b198072f1fee682f79535b72b0afaae96d3904f93d43"
IMAGE = "22a7292d90fbe2d498d70fb659d8338a072234f23fa078811d00b7145bddc5f1"
STOCK_IMAGES = {
    "vendor_boot": "583e1f4c0e09c2267cda88bd48a8b4f56cf5c5e034fbda7b25bd65aa86385425",
    "dtbo": "e9f3bae2c5417ff297162f1e7d2652ee98b347488fdf091d61daa986fbfb7690",
}
NODES = ("/soc/ufshc@4804000", "/soc/ufsphy_mem@4807000")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def signed_descriptors():
    data = (REF / "vbmeta.img").read_bytes()
    require(
        sha(data) == "62a5b1a94c2247c786e8148b9d9d0aea943b57b1034b3fd82d9cac9a85fcde97",
        "Stock vbmeta mismatch",
    )
    h = avbtool.AvbVBMetaHeader(data[:256])
    require(
        h.algorithm_type == 1
        and h.flags == 0
        and avbtool.verify_vbmeta_signature(h, data),
        "Invalid OEM metadata",
    )
    pos = 256 + h.authentication_data_block_size + h.descriptors_offset
    desc = avbtool.parse_descriptors(data[pos : pos + h.descriptors_size])
    return {
        d.partition_name: d for d in desc if isinstance(d, avbtool.AvbHashDescriptor)
    }


def signed_hash(desc, data):
    require(
        desc.hash_algorithm == "sha256" and len(data) >= desc.image_size,
        "Invalid signed extent",
    )
    return hashlib.sha256(desc.salt + data[: desc.image_size]).digest()


def get(tree, path, name, fmt="s"):
    result = subprocess.run(
        ["fdtget", "-t", fmt, tree, path, name], capture_output=True, text=True
    )
    if result.returncode:
        if "FDT_ERR_NOTFOUND" in result.stderr:
            return None
        raise ValueError(result.stderr)
    return result.stdout.strip()


def trees(vendor, table, work):
    require(
        vendor[:8] == b"VNDRBOOT" and struct.unpack_from("<I", vendor, 8)[0] == 3,
        "Vendor boot v3 required",
    )
    page = struct.unpack_from("<I", vendor, 12)[0]
    rd = struct.unpack_from("<I", vendor, 24)[0]
    header, size = struct.unpack_from("<II", vendor, 2096)
    offset = ((header + page - 1) // page + (rd + page - 1) // page) * page
    pos = offset
    bases = []
    while pos < offset + size:
        magic, n = struct.unpack_from(">II", vendor, pos)
        require(
            magic == 0xD00DFEED and 40 <= n <= offset + size - pos,
            "Truncated vendor DTB",
        )
        tree = work / f"base-{len(bases)}.dtb"
        tree.write_bytes(vendor[pos : pos + n])
        bases.append(tree)
        pos += n
    magic, total, head, esize, count, start, _, version = struct.unpack_from(
        ">8I", table
    )
    require(
        magic == 0xD7B7AB1E
        and version == 0
        and head <= start
        and esize >= 32
        and start + esize * count <= total <= len(table),
        "Invalid DT table",
    )
    overlays = []
    for i in range(count):
        n, off = struct.unpack_from(">II", table, start + i * esize)
        require(
            start + esize * count <= off and 40 <= n <= total - off, "Truncated overlay"
        )
        tree = work / f"overlay-{i}.dtbo"
        tree.write_bytes(table[off : off + n])
        overlays.append(tree)
    return bases, overlays, sha(table[:total])


def check_ufs(images, kernel, work):
    capture = json.loads((REF / "R37_DEVICE_EVIDENCE.json").read_text())
    bases, overlays, table_sha = trees(images["vendor_boot"], images["dtbo"], work)
    require(
        capture["dtbo_table_sha256"] == table_sha
        and len(overlays) == capture["dtbo_entry_count"] == 16,
        "R37 table mismatch",
    )
    identity = capture["runtime_fdt_metadata"]["root"]

    def matches(tree):
        for key in ("model", "compatible", "qcom,msm-id", "qcom,board-id"):
            if key.startswith("qcom,"):
                raw = get(tree, "/", key, "x")
                value = None if raw is None else [int(x, 16) for x in raw.split()]
                if value != [int(x, 16) for x in identity[key]]:
                    return False
            elif get(tree, "/", key) != " ".join(identity[key]):
                return False
        return True

    chosen = [(i, p) for i, p in enumerate(overlays) if matches(p)]
    require(len(chosen) == 1, "Expected one overlay consistent with device identity")
    index, overlay = chosen[0]
    require(
        sha(overlay.read_bytes()) == capture["candidate_entry_sha256"],
        "R37 overlay differs",
    )
    matching_bases = [
        p
        for p in bases
        if sha(p.read_bytes()) == capture["vendor_boot_base_dtb_sha256"]
    ]
    require(len(matching_bases) == 1, "Missing R37 base")
    base = matching_bases[0]
    merged = work / "merged.dtb"
    subprocess.run(["fdtoverlay", "-i", base, "-o", merged, overlay], check=True)
    entries = capture["runtime_target_nodes"]
    for node in entries:
        path = node["path"]
        compat = get(merged, path, "compatible")
        require(
            compat == " ".join(node["compatible"]),
            "Device-tree match differs at " + path,
        )
        status = get(merged, path, "status") or "okay (default)"
        require(status == node["status"], "Device-tree status differs at " + path)
    link = get(merged, NODES[0], "phys", "x")
    require(
        link
        and link == get(merged, NODES[1], "phandle", "x")
        and get(merged, NODES[0], "phy-names") == "ufsphy",
        "UFS PHY link differs",
    )
    cfg = kernel_config(kernel)
    for opt in (
        "SCSI_UFS_QCOM",
        "SCSI_UFSHCD_PLATFORM",
        "PHY_QCOM_UFS",
        "PHY_QCOM_UFS_V4",
        "DM_VERITY",
        "DM_VERITY_FEC",
    ):
        require(f"CONFIG_{opt}=y" in cfg, "Missing built-in " + opt)
    states = {}
    for path in NODES:
        compat = get(merged, path, "compatible")
        before = get(base, path, "status")
        after = get(merged, path, "status")
        require(
            before == "disabled" and after in ("ok", "okay"), "UFS activation mismatch"
        )
        # Compatible field of an OF match entry, preceded by empty name/type arrays.
        field = bytes(64) + compat.encode().ljust(128, b"\0")
        require(field in kernel, "Missing compiled OF match for " + compat)
        states[path] = {"base": before, "with_overlay": after, "kernel_match": compat}
    return {
        "base_dtbs": len(bases),
        "overlay_count": len(overlays),
        "matching_overlay_indices": [index],
        "matching_historical_nodes": len(entries),
        "ufs_nodes": states,
        "phy_phandle": link,
        "bootloader_selection_observed": False,
        "device_driver_probe_tested": False,
    }


def kernel_config(kernel):
    import zlib

    start = kernel.index(b"IKCFG_ST") + 8
    return zlib.decompress(kernel[start:], wbits=31).decode().splitlines()


def split_boot(data):
    require(
        data[:8] == b"ANDROID!" and struct.unpack_from("<I", data, 40)[0] == 3,
        "Expected Android boot v3",
    )
    k, rd = struct.unpack_from("<II", data, 8)
    offset = 4096 + ((k + 4095) // 4096) * 4096
    require(0 < rd <= len(data) - offset, "Truncated boot ramdisk")
    return data[4096 : 4096 + k], data[offset : offset + rd]


def recovery_entries(ramdisk):
    require(ramdisk[:4] == bytes.fromhex("02214c18"), "Expected legacy LZ4")
    library = ctypes.CDLL(ctypes.util.find_library("lz4") or "liblz4.so.1")
    library.LZ4_decompress_safe.argtypes = [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_int,
    ]
    pos = 4
    parts = []
    buf = ctypes.create_string_buffer(8 * 1024**2)
    while pos + 4 <= len(ramdisk):
        n = struct.unpack_from("<I", ramdisk, pos)[0]
        pos += 4
        if n == 0:
            break
        require(n <= len(ramdisk) - pos, "Bad LZ4 block")
        size = library.LZ4_decompress_safe(ramdisk[pos : pos + n], buf, n, len(buf))
        require(size > 0, "LZ4 decompression failed")
        parts.append(buf.raw[:size])
        pos += n
    archive = b"".join(parts)
    pos = 0
    found = {}
    while archive[pos : pos + 6] == b"070701":
        vals = [int(archive[pos + 6 + i * 8 : pos + 14 + i * 8], 16) for i in range(13)]
        size, namelen = vals[6], vals[11]
        name = archive[pos + 110 : pos + 109 + namelen].decode()
        start = (pos + 110 + namelen + 3) & ~3
        require(start + size <= len(archive), "Truncated CPIO")
        if name in ("system/bin/recovery", "system/etc/recovery.fstab"):
            found[name] = {"bytes": size, "sha256": sha(archive[start : start + size])}
        if name == "TRAILER!!!":
            break
        pos = (start + size + 3) & ~3
    require(
        len(found) == 2 and all(x["bytes"] for x in found.values()),
        "Expected Stock-Recovery files",
    )
    return found


def candidates(archive):
    require(sha(archive.read_bytes()) == ARCHIVE, "Wrong M45 Actions artifact")
    with zipfile.ZipFile(archive) as z:
        require(
            len(z.namelist()) == 3 and z.testzip() is None,
            "Damaged or unexpected M45 artifact",
        )
        result = json.loads(z.read("M45_RESULT.json"))
        boot = z.read("VEUX_M44_REVIEW_ONLY_boot.img")
        ak3 = z.read("VEUX_M45_AK3_REVIEW_ONLY.zip")
    require(
        result["AK3_replay_byte_identical"] is True
        and result["device_pass"] is False
        and result["flash_allowed"] is False
        and result["abi_symbols"] == 1423
        and result["modules"] == 37
        and sha(boot) == result["review_boot_sha256"] == BOOT
        and sha(ak3) == result["m45_review_zip_sha256"] == AK3,
        "Wrong M45 pair",
    )
    kernel, rd = split_boot(boot)
    with zipfile.ZipFile(io.BytesIO(ak3)) as z:
        require(
            z.testzip() is None and z.read("Image") == kernel and sha(kernel) == IMAGE,
            "AK3/kernel mismatch",
        )
    return boot, kernel, rd


def phone_archive(path, stock):
    with zipfile.ZipFile(path, "w") as z:
        for name, data in [
            ("GERAET.txt", (ROOT / "GERAET.txt").read_bytes()),
            (
                "VEUX_M46_Geraetecheck.sh",
                (ROOT / "VEUX_M46_Geraetecheck.sh").read_bytes(),
            ),
            ("boot.img", stock),
        ]:
            info = zipfile.ZipInfo(name, (2026, 11, 21, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
    with zipfile.ZipFile(path) as z:
        require(
            z.testzip() is None
            and sha(z.read("boot.img")) == STOCK_SHA
            and len(z.namelist()) == 3,
            "Invalid stock reference archive",
        )


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--artifact", type=Path, required=True)
    ap.add_argument("--stock", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    candidate, kernel, new_rd = candidates(args.artifact)
    args.out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=args.out.parent) as td:
        temp = Path(td)
        if args.stock:
            stock = args.stock.read_bytes()
        else:
            restore(temp / "stock.img")
            stock = (temp / "stock.img").read_bytes()
        require(sha(stock) == STOCK_SHA, "Original stock image required")
        original, old_rd = split_boot(stock)
        require(old_rd == new_rd, "Ramdisk differs")
        imgs = {
            name: lzma.decompress((REF / (name + ".img.xz")).read_bytes())
            for name in STOCK_IMAGES
        }
        descriptors = signed_descriptors()
        for n, b in {"boot": stock, **imgs}.items():
            require(
                sha(b) == ({"boot": STOCK_SHA, **STOCK_IMAGES}[n])
                and signed_hash(descriptors[n], b) == descriptors[n].digest,
                "Stock partition mismatch: " + n,
            )
        ufs = check_ufs(imgs, kernel, temp)
        marker = b"androidboot.vbmeta.invalidate_on_error\0"
        scfg = kernel_config(original)
        ccfg = kernel_config(kernel)
        require(
            "CONFIG_DM_VERITY_AVB=y" in scfg
            and "CONFIG_DM_VERITY_AVB=y" not in ccfg
            and marker in original
            and marker not in kernel,
            "Verity baseline changed; reevaluate the difference",
        )
        result = {
            "m45_run": 44885785447,
            "m45_archive_sha256": ARCHIVE,
            "candidate": BOOT,
            "stock": STOCK_SHA,
            "release": "5.4.274-qgki-g82179e362f33",
            "ufs": ufs,
            "stock_ramdisk_matches": True,
            "recovery_in_boot_ramdisk": recovery_entries(old_rd),
            "external_stock_boot_descriptor_matches_candidate": signed_hash(
                descriptors["boot"], candidate
            )
            == descriptors["boot"].digest,
            "stock_dm_verity_avb_handler_present": True,
            "candidate_dm_verity_avb_handler_present": False,
            "hardware_device_pass": False,
            "independent_pc_free_rollback_confirmed": False,
            "flash_allowed": False,
        }
        name = "VEUX_M46_Stock_und_Geraetecheck.zip"
        phone_archive(temp / name, stock)
        (temp / "M46_ERGEBNIS.json").write_text(json.dumps(result, indent=2) + "\n")
        for f in (name, "M46_ERGEBNIS.json"):
            os.replace(temp / f, args.out / f)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
