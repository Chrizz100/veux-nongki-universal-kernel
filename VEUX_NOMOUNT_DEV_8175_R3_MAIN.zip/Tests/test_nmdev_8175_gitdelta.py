#!/usr/bin/env python3
import sys,pathlib,tempfile,subprocess,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'common/scripts'))
import veux_nomount_dev_8175 as nm

def run(dir,*args):
 p=subprocess.run(['git','-C',str(dir),*args],capture_output=True,text=True)
 if p.returncode: raise AssertionError((args,p.stderr))
 return p.stdout.strip()
class RealGitCommitDeltaTests(unittest.TestCase):
  def setUp(self):
    self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
    self.root=pathlib.Path(self.tmp.name)
    run(self.root,'init','-q')
    run(self.root,'config','user.name','LocalTest')
    run(self.root,'config','user.email','tests@example.invalid')
    (self.root/'kernel/src').mkdir(parents=True)
    self.c=self.root/'kernel/src/nomount.c'
    self.h=self.root/'kernel/src/nomount.h';self.h.write_text('unchanged header\n')
    self.older='prefix\nstatic struct dentry *nm_materialize_rule(a)\n{\n if (!nm_inode_is_new(inode))\n   return res;\n}\n/*** i_op / s_op / f_op Hijacking Hooks ***/\nfooter\n'
    self.c.write_text(self.older)
    self.oldhash=self.commit('prior baseline')
    self.c.write_text(self.older.replace('   return res;', '   nm_hijack_dentry_ops(dir, dentry, true);\n   return res;'))
    self.mid=self.commit('cache hit handling')
    self.newtext=self.c.read_text().replace('   return res;', '   if (!IS_ERR(res))\n     nm_hijack_dentry_ops(dir, dentry, true);\n   nm_hijack_dentry_ops(dir, dentry, true);\n   return res;')
    self.c.write_text(self.newtext)
    self.newhash=self.commit('virtual directory')
    self.pins={'PREVIOUS_DEVICE_DEV':self.oldhash, 'DEV':self.newhash, 'PREVIOUS_C_BLOB':nm.gitblob(self.older.encode())}
  def commit(self,msg):
    run(self.root,'add','-A');run(self.root,'commit','-qm',msg)
    return run(self.root,'rev-parse','HEAD')
  def proof(self):
    with patch.multiple(nm,**self.pins):return nm.exact_two_commit_delta(self.root)
  def test_positive_exact_git_delta(self):
    x=self.proof()
    self.assertTrue(x['exact_two_commits'])
    self.assertEqual(x['dentry_hijack_calls_added'],3)
  def test_two_commits_exactly(self):
    self.pins['PREVIOUS_DEVICE_DEV']=self.mid
    self.pins['PREVIOUS_C_BLOB']=nm.gitblob(self.c.read_bytes())
    with self.assertRaises(nm.PortBlocked):self.proof()
  def test_unexpected_header_difference_refused(self):
    run(self.root,'reset','--soft','HEAD~1')
    self.h.write_text('modified header\n')
    self.newhash=self.commit('unauthorized h change')
    self.pins['DEV']=self.newhash
    with self.assertRaisesRegex(nm.PortBlocked,'DEV_DELTA_CHANGES_MORE_THAN_NOMOUNT_C'):
      self.proof()
  def test_unexpected_outside_function_refused(self):
    run(self.root,'reset','--soft','HEAD~1')
    self.c.write_text(self.newtext.replace('prefix\n','prefix outside change\n'))
    self.newhash=self.commit('outside function')
    self.pins['DEV']=self.newhash
    with self.assertRaisesRegex(nm.PortBlocked,'DEV_CHANGE_OUTSIDE_NM_MATERIALIZE_RULE'):self.proof()
  def test_not_three_hook_calls_refused(self):
    run(self.root,'reset','--soft','HEAD~1')
    self.c.write_text(self.newtext.replace('   nm_hijack_dentry_ops(dir, dentry, true);\n', '', 1))
    self.newhash=self.commit('removed one hook')
    self.pins['DEV']=self.newhash
    with self.assertRaisesRegex(nm.PortBlocked,'DEV_DENTRY_HOOK_DELTA_NOT_EXACTLY_THREE'):self.proof()
  def test_previous_commit_corruption_refused(self):
    self.pins['PREVIOUS_C_BLOB']='0'*40
    with self.assertRaisesRegex(nm.PortBlocked,'DEVICE_DEV_C_GIT_BLOB_DRIFT'):
      self.proof()
if __name__=='__main__':unittest.main()
