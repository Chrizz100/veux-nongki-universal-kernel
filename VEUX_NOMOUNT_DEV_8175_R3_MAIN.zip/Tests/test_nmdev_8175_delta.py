#!/usr/bin/env python3
import pathlib, sys, unittest, tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'common/scripts'))
import veux_nomount_dev_8175 as nm
class ExactDeltaHostTests(unittest.TestCase):
  def test_expected_immutable_pins(self):
    self.assertEqual(nm.DEV,'8175c9dcfbb333bfb1d14603c65c370687c5aa5b')
    self.assertEqual(nm.PREVIOUS_DEVICE_DEV,'2ef0b153d85cfa67408b520f8c66e1c5952de594')
    self.assertEqual(nm.BLOB['nomount.c'][1],'bebb9fc6ca5c217569a91985d74e1a65142a12be')
    self.assertEqual(nm.BLOB['nomount.h'][1],'560256c8f4fcffb9569629797efbf24d5b0bbc0c')
  def test_delta_range_only_function(self):
    test='prefix\nstatic struct dentry *nm_materialize_rule(a)\n{\nhi\n}\n\n/*** i_op / s_op / f_op Hijacking Hooks ***/\nfooter'
    a,b,c=nm.materialize_region(test)
    self.assertEqual(a,'prefix\n')
    self.assertIn('hi',b)
    self.assertIn('footer',c)
  def test_missing_function_fails_closed(self):
    with self.assertRaisesRegex(nm.PortBlocked,'NO_NM_MATERIALIZE_ANCHOR'):
      nm.materialize_region('other')
  def test_missing_post_anchor_fails_closed(self):
    with self.assertRaisesRegex(nm.PortBlocked,'NO_NM_HIJACK_POST_ANCHOR'):
      nm.materialize_region('static struct dentry *nm_materialize_rule(a) {}')
  def test_previous_image_sha_matches_audit(self):
    self.assertEqual(nm.BASE_IMAGE,'df92b8b21f3cc3f5b76a0456b0c565a1aa7ad84a995e3eab27a078015d2d16ea')
  def test_do_not_relax_vintf_or_security(self):
    code=pathlib.Path(nm.__file__).read_text()
    self.assertNotIn('patch -p1',code)
    self.assertNotIn('CONFIG_MODVERSIONS=n',code)
    self.assertNotIn('setenforce 0',code)
    self.assertNotIn('override_vintf',code)
  def test_unique_parity_precompile_stage(self):
    code=pathlib.Path(nm.__file__).read_text()
    self.assertIn('VEUX_SUSFS_BAKASU_COMPOSED_SOURCE_PARITY_BLOCKED',code)
    self.assertIn("'SUSFS_BAKASU_54_PARITY_8175.json'",code.replace('report/SUSFS_BAKASU_54_PARITY_8175.json',"'SUSFS_BAKASU_54_PARITY_8175.json'"))
    self.assertIn('source_parity_gate_passed',code)
  def test_nomount_gate_requires_git_donor(self):
    with tempfile.TemporaryDirectory() as p:
      with self.assertRaises((nm.PortBlocked,OSError)):
        nm.donor_check(pathlib.Path(p))
if __name__=='__main__':unittest.main()
