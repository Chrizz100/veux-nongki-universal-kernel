#!/usr/bin/env python3
import sys, unittest, tempfile, pathlib, hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'common/scripts'))
from veux_susfs54_parity_gate import check_source,sha,function_body
SRC=ROOT/'evidence/BAKASU_R5S1_COMPILED_SELINUX_REFERENCE.c'
class RealBakaSUReferenceTests(unittest.TestCase):
  def test_authentic_compiled_reference_sha(self):
    self.assertEqual(sha(SRC.read_bytes()),'78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78')
  def test_preprocessed_54_setprocattr_definition_found(self):
    body=function_body(SRC.read_text(),'ksu_handle_selinux_setprocattr')
    self.assertIn('!ksu_selinux_hide_running',body)
    self.assertIn('error2 || error',body)
    self.assertIn('ksu_orig_setprocattr',body)
  def test_actual_bakasu_source_against_valid_native_fixtures(self):
    with tempfile.TemporaryDirectory() as d:
      root=pathlib.Path(d)
      srcs={'KernelSU/kernel/feature/selinux_hide.c':SRC.read_bytes(),
            'security/selinux/hooks.c':b'/* native SELinux hooks identity substituted for host-only reference test */\n',
            'security/selinux/selinuxfs.c':b'/* native SELinuxFS identity substituted for host-only reference test */\n',
            'Makefile':b'VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n'}
      for name,raw in srcs.items():
        f=root/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
      exp={k:sha(v) for k,v in srcs.items() if k!='Makefile'}
      res=check_source(root,exp)
      self.assertEqual(res['result'],'SOURCE_PARITY_PASS_DEVICE_UNTESTED',res)
if __name__=='__main__':unittest.main()
