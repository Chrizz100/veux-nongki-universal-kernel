#!/usr/bin/env python3
from pathlib import Path
import json,sys,unittest
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE/'common/scripts'))
import veux_nomount_dev_8175 as nm

class NewUpstreamRefs(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.a=json.loads((HERE/'evidence/VEUX_UPSTREAM_PIN_MATRIX_20261019.json').read_text())
    def test_kernel_blob_pins_match_source_port(self):
        self.assertEqual(self.a['upstreams']['NoMount']['kernel_C_blob'],nm.BLOB['nomount.c'][1])
        self.assertEqual(self.a['upstreams']['NoMount']['kernel_H_blob'],nm.BLOB['nomount.h'][1])
    def test_updated_head_does_not_touch_kernel_code(self):
        new=self.a['upstreams']['NoMount']
        self.assertEqual(new['commits_from_target_to_latest'],2)
        self.assertFalse(new['post_target_changes_kernel_source'])
        self.assertEqual(new['latest_dev_as_checked'],'0b1c56456571ea9a2a7ca2a0d34ec0ca72fdefe3')
        self.assertTrue(all(not p.startswith('kernel/') for p in new['post_target_files_changed']))
    def test_bakasu_kernel_not_arbitrarily_updated(self):
        self.assertEqual(self.a['upstreams']['BakaSU']['kernel_sync_head'],'f308ed0936bdd31163cb53da3f42bc7a698f5512')
        self.assertEqual(self.a['baseline']['bakasu_kernel'],'35234')
    def test_gki_host_patches_only_and_no_false_canonical_claim(self):
        s=self.a['upstreams']['SUSFS']
        self.assertFalse(s['canonical_gitlab_head_independently_verified'])
        self.assertEqual(len(s['diff_files']),2)
        self.assertEqual(s['currently_integrated_core'],'5326e21a7eb232f9e21debdd5164e99bee3d1e2f')
    def test_absolute_scope_guards(self):
        x=self.a['rules']
        self.assertTrue(all(x.values()))
        self.assertFalse(any('brene' in str(k).lower() for k in (HERE/'common/scripts').iterdir()))
    def test_dev_target_derived_from_baseline_not_from_latest_module_head(self):
        target=self.a['upstreams']['NoMount']['kernel_target']
        self.assertEqual(target,nm.DEV)
        self.assertEqual(self.a['baseline']['nomount_kernel'],nm.PREVIOUS_DEVICE_DEV)
        self.assertNotEqual(target,self.a['upstreams']['NoMount']['latest_dev_as_checked'])
if __name__=='__main__':unittest.main()
