#!/usr/bin/env python3
"""R61: source-only NoMount v2.2 graft into immutable VEUX R60 CASS build.

Changes only isolated R60's fs/nomount directory. The linked donor resides in
RUNNER_TEMP and was already checked out at its immutable upstream commit.
Never creates a boot image, installer or a flash recommendation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

DONOR_SHA = 'bf1847f98fed382369c43bfd652cd93774b9b8e3'
DONOR_REMOTE = 'https://github.com/maxsteeel/nomount.git'
PINNED_BLOBS = {
    'nomount.c': '5ad954ee3b5c2f21be9de14c760101b60afb39d5',
    'nomount.h': 'c850611ff1b37582c7f3e09058616096f8ef7930',
    'Makefile': 'cb4d3eef3ae93645591c1dcf8afaf4efef90c20a',
    'Kconfig': '638b9427ef638f786d288d0a93f731676cf32c62',
}
SUSFS_SNAPSHOT = '937232ce8c4bdcbe4216e99a1b3d7b5cf633f7c6'
BAKASU_LOCAL_COMMIT = 'e90e2a7b4528ada451e0e84c41ff6b1af0a8a1bd'
R60_BASE_CONFIG_SHA = '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4'


def require(yes: bool, msg: str) -> None:
    if not yes:
        raise RuntimeError('R61_NOMOUNT22_BLOCKED:' + msg)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    return sha(path.read_bytes())


def git_blob_sha(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def cmd(*args: str) -> str:
    proc = subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc.stdout.strip()


def validate_donor(donor_root: Path) -> tuple[Path, int]:
    require(donor_root.is_dir() and not donor_root.is_symlink(), 'DONOR_NOT_DIRECTORY')
    require(cmd('git', '-C', str(donor_root), 'rev-parse', 'HEAD') == DONOR_SHA, 'DONOR_COMMIT_DRIFT')
    require(cmd('git', '-C', str(donor_root), 'remote', 'get-url', 'origin') == DONOR_REMOTE, 'DONOR_REMOTE_DRIFT')
    require(not cmd('git', '-C', str(donor_root), 'status', '--porcelain', '--untracked-files=all'), 'DONOR_DIRTY')
    src = donor_root / 'kernel' / 'src'
    for name, expected in PINNED_BLOBS.items():
        file = src / name
        require(file.is_file() and not file.is_symlink(), 'DONOR_FILE_MISSING_OR_LINK:' + name)
        require(git_blob_sha(file.read_bytes()) == expected, 'DONOR_BLOB_HASH_DRIFT:' + name)
    require('#define NOMOUNT_BASE_VERSION "22"' in (src/'nomount.h').read_text(), 'DONOR_VERSION_NOT_22')
    require('NOMOUNT_COMMITS' in (src/'Makefile').read_text(), 'DYNAMIC_COMMIT_VERSION_MISSING')
    count = int(cmd('git', '-C', str(donor_root), 'rev-list', '--count', 'HEAD'))
    require(count >= 300, 'DONOR_COMMIT_COUNT_INCOHERENT')
    return src, count


PROTECTED_FILES = (
    'fs/Makefile', 'fs/Kconfig', 'fs/susfs.c', 'include/linux/susfs.h',
    'include/linux/susfs_def.h', 'security/selinux/avc.c',
    'security/selinux/hooks.c', 'security/selinux/selinuxfs.c',
    'security/selinux/ss/services.c',
)
PROTECTED_DIRS = ('KernelSU', 'drivers/kernelsu')


def protected_hashes(root: Path) -> dict[str, str]:
    found = {}
    for name in PROTECTED_FILES:
        p = root / name
        if p.is_file():
            require(not p.is_symlink(), 'PROTECTED_FILE_SYMLINK:' + name)
            found[name] = sha_file(p)
    for name in PROTECTED_DIRS:
        d = root / name
        if d.is_dir() and not d.is_symlink():
            for p in sorted(d.rglob('*')):
                if p.is_file() and not p.is_symlink():
                    found[p.relative_to(root).as_posix()] = sha_file(p)
    require('fs/Makefile' in found and 'fs/Kconfig' in found, 'FS_BUILD_WIRING_NOT_FOUND')
    require('fs/susfs.c' in found, 'FROZEN_SUSFS_MISSING')
    require(any(x.startswith('KernelSU/') or x.startswith('drivers/kernelsu/') for x in found), 'FROZEN_BAKASU_MISSING')
    return found


def check_existing_wiring(root: Path) -> None:
    kconfig = (root/'fs/Kconfig').read_text()
    make = (root/'fs/Makefile').read_text()
    require(len(re.findall(r'^\s*source\s+["\']?fs/nomount/Kconfig["\']?\s*$', kconfig, re.M)) == 1,
            'KCONFIG_NOMOUNT_NOT_EXACTLY_ONCE')
    require(len(re.findall(r'^\s*obj-\$\(CONFIG_NOMOUNT\)\s*\+=\s*nomount/\s*$', make, re.M)) == 1,
            'MAKEFILE_NOMOUNT_NOT_EXACTLY_ONCE')


def stage(kernel: Path, donor_root: Path, out: Path) -> dict:
    require(kernel.is_dir() and not kernel.is_symlink(), 'KERNEL_SOURCE_MISSING_OR_LINK')
    require(not out.exists(), 'REPORT_REUSE')
    require(out.parent.is_dir() and not out.parent.is_symlink(), 'REPORT_DIR_NOT_READY')
    source_proof = kernel.parent.parent/'R58_SOURCE_STAGE.json'
    require(source_proof.is_file() and not source_proof.is_symlink(), 'R60_SOURCE_PROOF_MISSING')
    source_json = json.loads(source_proof.read_text())
    require(source_json.get('version_from_history') == 35260 and
            source_json.get('bakasu_local_bridge_git') == BAKASU_LOCAL_COMMIT,
            'R60_BAKASU_VERSION_OR_COMMIT_DRIFT')
    require(source_json.get('susfs_snapshot_basis') == SUSFS_SNAPSHOT and
            source_json.get('susfs_8a120081_update_ported') is False,
            'R60_FROZEN_SUSFS_DRIFT')
    check_existing_wiring(kernel)
    donor, count = validate_donor(donor_root)
    protected = protected_hashes(kernel)
    target = kernel/'fs/nomount'
    require(target.is_dir() and not target.is_symlink(), 'PRIOR_NOMOUNT_NOT_NORMAL_DIRECTORY')
    originals = sorted(p.name for p in target.iterdir())
    require(originals == sorted(PINNED_BLOBS), 'PRIOR_NOMOUNT_UNEXPECTED_FILES')
    require(all((target/n).is_file() and not (target/n).is_symlink() for n in PINNED_BLOBS), 'PRIOR_NOMOUNT_FILE_LINK')
    old = {n: sha_file(target/n) for n in PINNED_BLOBS}
    require(old['nomount.c'] != sha_file(donor/'nomount.c'), 'NOMOUNT_ALREADY_V22_NO_UPDATE_NEEDED')
    backup = out.parent/'R61_PREVIOUS_NOMOUNT_BACKUP'
    require(not backup.exists(), 'BACKUP_REUSE')
    shutil.copytree(target, backup)
    shutil.rmtree(target)
    target.symlink_to(donor, target_is_directory=True)
    require(target.is_symlink() and target.resolve(strict=True) == donor.resolve(strict=True), 'DONOR_LINK_NOT_ACTIVE')
    for n in PINNED_BLOBS:
        require(sha_file(target/n) == sha_file(donor/n), 'NOMOUNT_SOURCE_COPY_MISMATCH:' + n)
    require(protected_hashes(kernel) == protected, 'BAKASU_SUSFS_OR_UNRELATED_SOURCE_CHANGED')
    report = {
        'schema':'VEUX_R61_NOMOUNT22_ONLY_STAGE_V1',
        'result':'NOMOUNT_2_2_SOURCE_ONLY_STAGED',
        'kernel':'5.4.274', 'scheduler':'CASS',
        'nomount_release':'2.2.0', 'nomount_protocol':22,
        'nomount_upstream_git':DONOR_SHA, 'nomount_upstream_git_count':count,
        'nomount_runtime_version_expected':f'22 ({count})',
        'original_nomount_sha256':old,
        'new_nomount_sha256':{n:sha_file(target/n) for n in PINNED_BLOBS},
        'changed_source_paths':['fs/nomount/'],
        'protected_source_sha256':protected,
        'bakasu_expected_local_commit':BAKASU_LOCAL_COMMIT,
        'susfs_expected_snapshot':SUSFS_SNAPSHOT,
        'bakasu_or_susfs_updated':False,
        'flash_allowed':False, 'device_test':False,
    }
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print('R61_NOMOUNT22_SOURCE_ONLY=PASS; FROZEN_BAKASU_SUSFS=PASS; NOFLASH')
    return report


def verify(kernel: Path, build: Path, stage_report: Path, out: Path) -> dict:
    require(not out.exists(), 'REPORT_REUSE')
    r = json.loads(stage_report.read_text())
    require(r.get('schema')=='VEUX_R61_NOMOUNT22_ONLY_STAGE_V1', 'STAGE_RESULT_WRONG')
    require(r.get('bakasu_or_susfs_updated') is False, 'COMPONENT_FREEZE_BROKEN')
    require(protected_hashes(kernel)==r['protected_source_sha256'], 'PROTECTED_SOURCE_CHANGED_DURING_COMPILE')
    fs = kernel/'fs/nomount'
    require(fs.is_symlink(), 'DONOR_LINK_LOST')
    for n,v in r['new_nomount_sha256'].items():
        require(sha_file(fs/n)==v, 'NOMOUNT_SOURCE_CHANGED_DURING_COMPILE:' + n)
    cfg = build/'.config'
    require(cfg.is_file() and sha_file(cfg)==R60_BASE_CONFIG_SHA, 'R60_BASE_CONFIG_CHANGED')
    require(re.search(r'^CONFIG_NOMOUNT=y$',cfg.read_text(),re.M) is not None, 'NOMOUNT_NOT_BUILTIN')
    required = {
      'NOMOUNT_OBJECT':build/'fs/nomount/nomount.o',
      'VMLINUX':build/'vmlinux',
      'ARM64_IMAGE':build/'arch/arm64/boot/Image',
      'MODULE_SYMVERS':build/'Module.symvers',
    }
    hashes = {}
    for label,path in required.items():
        require(path.is_file() and not path.is_symlink() and path.stat().st_size>100, 'COMPILED_FILE_MISSING:'+label)
        hashes[label]={'size':path.stat().st_size,'sha256':sha_file(path)}
    native=build.parent/'R58_SOURCE_STAGE.json'
    report=build.parent/'R59_FULL_INTEGRATION_EVIDENCE.json'
    require(native.is_file() and report.is_file(), 'ORIGINAL_R60_PROOFS_MISSING')
    s=json.loads(native.read_text());ev=json.loads(report.read_text())
    require(s.get('version_from_history')==35260 and s.get('bakasu_local_bridge_git')==BAKASU_LOCAL_COMMIT,
            'BAKASU_R60_LINEAGE_CHANGED')
    require(s.get('susfs_snapshot_basis')==SUSFS_SNAPSHOT and s.get('susfs_8a120081_update_ported') is False,
            'SUSFS_R60_LINEAGE_CHANGED')
    require(ev.get('source_and_compiler_pass') is True and ev.get('rmnet_132_all_match') is True,
            'ORIGINAL_R60_COMPILER_OR_RMNET_UNPROVEN')
    require('nomount_init' in ev.get('linked_symbols_found',[]), 'NOMOUNT_NOT_LINKED')
    require(ev.get('flash_allowed') is False and ev.get('device_test') is False,'ORIGINAL_R60_RELEASE_CONTRACT_CHANGED')
    result = {
        'schema':'VEUX_R61_NOMOUNT22_ONLY_COMPILE_V1',
        'status':'NOMOUNT_V22_BUILT_WITH_FROZEN_R60_BAKASU35260_SUSFS230',
        'nomount_protocol':22,'nomount_commit':DONOR_SHA,
        'nomount_version':r['nomount_runtime_version_expected'],
        'bakasu_version':35260,'bakasu_local_bridge_git':BAKASU_LOCAL_COMMIT,
        'susfs_version':'2.3.0','susfs_snapshot_git':SUSFS_SNAPSHOT,
        'preserved_r60_config_sha256':R60_BASE_CONFIG_SHA,
        'files':hashes,'rmnet_132_match':True,
        'vendor_abi_proven':False,'flash_allowed':False,'device_test':False,
    }
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print('R61_NOMOUNT22_LINKED_IMAGE_AND_FROZEN_COMPONENTS=PASS; OEM_ABI_PENDING; NOFLASH')
    return result


def main():
    a=argparse.ArgumentParser()
    sub=a.add_subparsers(dest='cmd',required=True)
    stage_args=sub.add_parser('stage')
    stage_args.add_argument('--kernel',type=Path,required=True)
    stage_args.add_argument('--donor',type=Path,required=True)
    stage_args.add_argument('--out',type=Path,required=True)
    verify_args=sub.add_parser('verify')
    verify_args.add_argument('--kernel',type=Path,required=True)
    verify_args.add_argument('--build',type=Path,required=True)
    verify_args.add_argument('--stage-report',type=Path,required=True)
    verify_args.add_argument('--out',type=Path,required=True)
    n=a.parse_args()
    if n.cmd=='stage': stage(n.kernel,n.donor,n.out)
    else: verify(n.kernel,n.build,n.stage_report,n.out)


if __name__=='__main__': main()
