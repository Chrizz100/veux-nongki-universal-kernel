import importlib.util
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase, main, mock
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import veux_r61_nomount22_only as n

class NoMountOnly(TestCase):
    def setUp(self):
        self.tmp=TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        self.kernel=self.base/'stage'/'kernel'
        self.donor=self.base/'donor'/'kernel'/'src'
        self.donor.mkdir(parents=True)
        (self.kernel/'fs/nomount').mkdir(parents=True)
        (self.kernel/'include/linux').mkdir(parents=True)
        (self.kernel/'KernelSU/kernel').mkdir(parents=True)
        (self.kernel/'fs/Makefile').write_text('obj-$(CONFIG_NOMOUNT) += nomount/\n')
        (self.kernel/'fs/Kconfig').write_text('source "fs/nomount/Kconfig"\n')
        (self.kernel/'fs/susfs.c').write_text('ORIGINAL SUSFS NEVER CHANGED')
        (self.kernel/'KernelSU/kernel/core.c').write_text('ORIGINAL BAKASU NEVER CHANGED')
        for item in n.PINNED_BLOBS:
            (self.kernel/'fs/nomount'/item).write_text('old-'+item)
            (self.donor/item).write_text('new-v22-'+item)
        (self.base/'R58_SOURCE_STAGE.json').write_text(json.dumps({
            'version_from_history':35260,
            'bakasu_local_bridge_git':n.BAKASU_LOCAL_COMMIT,
            'susfs_snapshot_basis':n.SUSFS_SNAPSHOT,
            'susfs_8a120081_update_ported':False,
        }))
        self.report=self.base/'R61_NOMOUNT22_SOURCE.json'
    def run_stage(self):
        with mock.patch.object(n,'validate_donor',return_value=(self.donor, 300)):
            return n.stage(self.kernel,self.donor.parents[1],self.report)
    def test_stage_changes_only_nomount(self):
        pre=n.protected_hashes(self.kernel)
        result=self.run_stage()
        self.assertTrue((self.kernel/'fs/nomount').is_symlink())
        self.assertEqual(n.protected_hashes(self.kernel),pre)
        self.assertEqual(result['nomount_protocol'],22)
        self.assertEqual(result['changed_source_paths'],['fs/nomount/'])
        self.assertFalse(result['flash_allowed'])
        self.assertFalse(result['bakasu_or_susfs_updated'])
    def test_rerun_fails_closed(self):
        self.run_stage()
        with self.assertRaisesRegex(RuntimeError,'REPORT_REUSE'):
            self.run_stage()
    def test_missing_wiring_fails_closed(self):
        (self.kernel/'fs/Kconfig').write_text('source "fs/susfs/Kconfig"\n')
        with self.assertRaisesRegex(RuntimeError,'KCONFIG_NOMOUNT_NOT_EXACTLY_ONCE'):
            self.run_stage()
    def test_duplicate_wiring_fails_closed(self):
        with (self.kernel/'fs/Makefile').open('a') as f:f.write('obj-$(CONFIG_NOMOUNT) += nomount/\n')
        with self.assertRaisesRegex(RuntimeError,'MAKEFILE_NOMOUNT_NOT_EXACTLY_ONCE'):
            self.run_stage()
    def test_extra_prior_nomount_file_fails_closed(self):
        (self.kernel/'fs/nomount/extra').write_text('sentinel')
        with self.assertRaisesRegex(RuntimeError,'PRIOR_NOMOUNT_UNEXPECTED_FILES'):
            self.run_stage()
    def test_prior_nomount_source_same_fails_closed(self):
        (self.kernel/'fs/nomount/nomount.c').write_bytes((self.donor/'nomount.c').read_bytes())
        with self.assertRaisesRegex(RuntimeError,'NOMOUNT_ALREADY_V22'):
            self.run_stage()
    def test_missing_original_bakasu_fails_closed(self):
        (self.kernel/'KernelSU/kernel/core.c').unlink()
        with self.assertRaisesRegex(RuntimeError,'FROZEN_BAKASU_MISSING'):
            self.run_stage()
    def test_original_susfs_never_changes(self):
        r=self.run_stage()
        (self.kernel/'fs/susfs.c').write_text('CHANGED!!')
        self.assertNotEqual(n.protected_hashes(self.kernel),r['protected_source_sha256'])
    def test_verify_requires_real_compilation(self):
        self.run_stage()
        build=self.base/'build';build.mkdir()
        with self.assertRaisesRegex(RuntimeError,'R60_BASE_CONFIG_CHANGED'):
            n.verify(self.kernel,build,self.report,self.base/'R61_NOMOUNT22_COMPILED.json')

if __name__=='__main__':main()
