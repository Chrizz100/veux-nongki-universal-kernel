R61 fuer GitHub MAIN (kein flashbares Kernelpaket)

ZIP entpacken. GitHub: Chrizz100/veux-nongki-universal-kernel / main
Diese drei Dateien an ihren Pfaden hochladen:
.github/workflows/VEUX_R61_R60_CASS_BAKASU35260_SUSFS230_NOMOUNT22_ONLY_NOFLASH.yml
common/scripts/veux_r61_nomount22_only.py
common/scripts/tests_r61_nomount/test_nomount22_only.py

Kein Update an BakaSU und SUSFS, NoMount 2.2.0; kein Flashen.
