#!/usr/bin/env python3
"""VEUX R6 + NoMount stable v2.1.1 source-only candidate.

Uses the existing *unchanged* R6 BakaSU/SUSFS/RMNET device-fix source pipeline.
The only component pin changed in the temporary worker is NoMount 21.

No GitHub mutation, release promotion, kernel build, AK3, boot.img or device PASS.
The upstream SUSFS build blocker remains intact.  STOP on unexpected changes.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import re
import sys

REPO_NAME = "Chrizz100/veux-nongki-universal-kernel"
KERNEL = "5.4.274"
R6_RUN = 38530535344
R6_SCRIPT = "common/scripts/veux_fleet_35222_selinux_r3.py"
R6_SCRIPT_BLOB = "699e29573aeb8e5f5902edae51905b685b630693"
ENGINE_SCRIPT = "common/scripts/veux_update_engine.py"
ENGINE_SCRIPT_BLOB = "1b59c48392fa63af9640dce47b111057ab237b31"
BAKASU_PIN = "5b76b884c75f729a220bb317aa4a4fc78f0e0e9c"
SUSFS_PIN = "5326e21a7eb232f9e21debdd5164e99bee3d1e2f"
NOMOUNT_R6 = "1ded61dc908c511072162fa0bee44e6ccdb7b4c7"
NOMOUNT_NEW = "7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3"
NOMOUNT_URL = "https://github.com/maxsteeel/nomount.git"
NOMOUNT_REF = "refs/heads/master"
NOMOUNT_VERSION = "21"
NO_UNCHECKED_FLAG = "-fno-stack-protector"
DONOR_BLOBS = {  # immutable Git object IDs, checked against actual pinned checkout
    "kernel/src/nomount.c": "e698b2a93fbd77b5f390613e22237c4c8454c3de",
    "kernel/src/Kconfig": "638b9427ef638f786d288d0a93f731676cf32c62",
    "kernel/src/nomount.h": "95deecac12db6b6680df3c8db54b0bb3dbbfbc08",
    "kernel/src/Makefile": "35710cda171161578e498e809d89be9a673ea2d3",
}

class Blocked(RuntimeError):
    pass


def guard(test: bool, why: str) -> None:
    if not test:
        raise Blocked(why)


def blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def file_blob(path: Path) -> str:
    guard(path.is_file() and not path.is_symlink(), f"FILE_MISSING_OR_LINK:{path}")
    return blob(path.read_bytes())


def load_r6(repo: Path):
    scripts = repo / "common/scripts"
    guard(file_blob(repo / R6_SCRIPT) == R6_SCRIPT_BLOB, "R6_BUILDER_CHANGED")
    guard(file_blob(repo / ENGINE_SCRIPT) == ENGINE_SCRIPT_BLOB, "ENGINE_CHANGED")
    sys.path.insert(0, str(scripts))
    import veux_fleet_35222_selinux_r3 as r6  # noqa: PLC0415
    return r6


def pin_r6_temporary(r6) -> dict:
    """Fail-closed: only NoMount SHA may differ from proven R6 target manifest."""
    old = copy.deepcopy(r6.TARGETS)
    guard(set(old) == {"resukisu", "susfs", "nomount"}, "COMPONENT_TOPOLOGY_CHANGED")
    guard(old["resukisu"]["commit"] == BAKASU_PIN, "BAKASU_PIN_CHANGED")
    guard(old["resukisu"]["version"] == "35222", "BAKASU_VERSION_CHANGED")
    guard(old["susfs"]["commit"] == SUSFS_PIN, "SUSFS_PIN_CHANGED")
    guard(old["susfs"]["version"] == "2.3.0", "SUSFS_VERSION_CHANGED")
    guard(old["nomount"]["commit"] == NOMOUNT_R6, "R6_NOMOUNT_BASE_CHANGED")
    guard(old["nomount"]["url"] == NOMOUNT_URL, "NOMOUNT_URL_CHANGED")
    guard(old["nomount"]["ref"] == NOMOUNT_REF, "NOMOUNT_REF_CHANGED")
    guard(old["nomount"]["version"] == NOMOUNT_VERSION, "NOMOUNT_PROTOCOL_CHANGED")
    guard(r6.EXPECTED_KERNEL_R3 == KERNEL, "R6_KERNEL_SCOPE_CHANGED")
    guard(r6.BUILT_NOMOUNT21 == "c7f63e3feb4125d591b6969a33aac04feb40f8ba",
          "R6_NOMOUNT_WIRE_BASE_CHANGED")
    r6.TARGETS["nomount"] = {**old["nomount"], "commit": NOMOUNT_NEW}
    expected = copy.deepcopy(old)
    expected["nomount"]["commit"] = NOMOUNT_NEW
    guard(r6.TARGETS == expected, "UNEXPECTED_COMPONENT_MUTATION")
    return old


def verify_candidate(r6, root: Path) -> dict:
    """Read-only post-clone identity and wire compatibility proof."""
    donor = root / "bundle/nomount"
    guard(donor.is_dir() and not donor.is_symlink(), "NOMOUNT_CHECKOUT_MISSING_OR_LINK")
    head = r6.run("git", "-C", donor, "rev-parse", "HEAD")
    guard(head == NOMOUNT_NEW, "NEW_NOMOUNT_SOURCE_MISMATCH")
    guard(r6.run("git", "-C", donor, "status", "--porcelain", "--untracked-files=all") == "",
          "NOMOUNT_DONOR_DIRTY")
    # Ensure R6 parent is in checked out history, no unrelated fork.
    r6.run("git", "-C", donor, "merge-base", "--is-ancestor", NOMOUNT_R6, NOMOUNT_NEW)
    for path, expected in DONOR_BLOBS.items():
        guard(file_blob(donor / path) == expected, "NOMOUNT_KNOWN_SOURCE_BLOB_DRIFT:" + path)
    header_old = r6.run("git", "-C", donor, "show", NOMOUNT_R6 + ":kernel/src/nomount.h")
    header_new = (donor / "kernel/src/nomount.h").read_text()
    wire = r6.validate_wire_abi(header_old, header_new)
    guard(set(wire) == {"enum", "nm_payload", "nm_rule_hdr", "nm_del_hdr"}
          and all(v == "IDENTICAL" for v in wire.values()), "NOMOUNT_WIRE_ABI_MISMATCH")
    mk = (donor / "kernel/src/Makefile").read_text()
    guard(mk.count(NO_UNCHECKED_FLAG) == 1, "UPSTREAM_STACK_FLAGS_DRIFT_REVIEW_REQUIRED")
    guard({p.name for p in (donor / "kernel/src").iterdir()} ==
          {"Makefile", "Kconfig", "nomount.c", "nomount.h"},
          "NOMOUNT_KERNEL_LAYOUT_DRIFT")
    return {"commit": NOMOUNT_NEW, "previous_r6_commit": NOMOUNT_R6,
            "wire_protocol": 21, "wire_declarations": wire,
            "stable_release": "v2.1.1", "donor_hashes": DONOR_BLOBS,
            "stack_protector_disabled_by_upstream_makefile": True,
            "stack_protector_needs_explicit_build_review": True}


def report(root: Path, status: dict) -> None:
    p = root / "report/NOMOUNT211_R6_SOURCE_ONLY.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def run_stage(repo: Path, root: Path, operation: str) -> dict:
    repo = repo.resolve(strict=True)
    guard(not root.resolve().is_relative_to(repo), "WORKDIR_MUST_BE_OUTSIDE_REPOSITORY")
    r6 = load_r6(repo)
    old = pin_r6_temporary(r6)
    result = {"schema": 1, "operation": operation, "status": "BLOCKED",
              "kernel": KERNEL, "proven_r6_run": R6_RUN,
              "base_bakasu": BAKASU_PIN, "base_susfs": SUSFS_PIN,
              "r6_nomount": NOMOUNT_R6, "candidate_nomount": NOMOUNT_NEW,
              "bakasu_or_susfs_upgraded": False, "main_mutated": False,
              "source_preflight": False, "kernel_built": False,
              "device_pass": False, "flash_permission": False,
              "cannot_claim_full_green_pass": True}
    try:
        if operation == "prepare":
            guard(not root.exists() and not root.is_symlink(), "REQUIRE_FRESH_WORKDIR")
            r6.prepare(repo, root, KERNEL)
        else:
            guard(root.is_dir() and not root.is_symlink(), "PREPARE_FIRST")
            guard((root / "bundle/targets.json").is_file(), "MISSING_PREPARED_TARGETS")
        targets = json.loads((root / "bundle/targets.json").read_text())
        guard(targets["components"] == r6.TARGETS, "EFFECTIVE_TARGETS_NOT_ONLY_NOMOUNT")
        proof = verify_candidate(r6, root)
        guard(r6.TARGETS["resukisu"] == old["resukisu"] and
              r6.TARGETS["susfs"] == old["susfs"], "BASE_COMPONENTS_CHANGED")
        result["nomount_proof"] = proof
        if operation == "prepare":
            result["status"] = "PINNED_CANDIDATE_PREPARED"
        elif operation == "preflight":
            validation = r6.check_src(repo, root, KERNEL)
            guard(validation.get("status") == "SOURCE_PREFLIGHT_PASS",
                  "R6_SOURCE_CHECK_FAILED")
            integration = json.loads((root / "source-audit" / KERNEL / "integration.json").read_text())
            guard(integration["targets"] == r6.TARGETS, "INTEGRATED_TARGETS_CHANGED")
            susfs = json.loads((root / "report/SUSFS_54_PORT_PROBE_R1.json").read_text())
            guard(susfs["decision"] == "MANUAL_REVIEW_5_4_HOOKS_REQUIRED" and
                  susfs["host_5_4"]["host_paths_requiring_manual_port"] == 2,
                  "SUSFS_SELINUX_SCOPE_DRIFT")
            guard(susfs["baseline_susfs_pin"] == SUSFS_PIN,
                  "SUSFS_FROZEN_BASE_CHANGED")
            guard((root / "report/BAKASU-OFFICIAL-D726-R6.json").is_file(),
                  "PROVEN_R6_OFFICIAL_FIX_DROPPED")
            result["status"] = "SOURCE_PREFLIGHT_ONLY_PASS"
            result["source_preflight"] = True
            result["susfs_manual_review"] = ["security/selinux/hooks.c", "security/selinux/selinuxfs.c"]
            result["nomount_stack_protector_review_required"] = True
        else:
            raise Blocked("UNKNOWN_OPERATION")
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        if root.is_dir() and not root.is_symlink():
            report(root, result)
        raise
    report(root, result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("operation", choices=("prepare", "preflight"))
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--kernel", default=KERNEL, choices=[KERNEL])
    args = parser.parse_args()
    try:
        status = run_stage(args.repo, args.work, args.operation)
        print("VEUX_R6_NOMOUNT211_" + status["status"])
        print("NO_FLASH=YES; BAKASU_AND_SUSFS_UNCHANGED=YES")
        return 0
    except (Blocked, OSError, ValueError, KeyError, ImportError, RuntimeError) as exc:
        print(f"VEUX_R6_NOMOUNT211_BLOCKED: {exc}", file=sys.stderr, flush=True)
        return 1

if __name__ == "__main__":
    raise SystemExit(main())
