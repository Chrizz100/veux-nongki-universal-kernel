#!/usr/bin/env python3
"""VEUX R6 + NoMount v2.1.1 isolated experimental kernel build.

Uses the hash-pinned R6 build helper, unchanged source component pins except
NoMount master 7046c7ad, and preserves R6 device fixes and build gates.

ALL changes are in runner.temp. The official NoMount donor stays immutable.
No source promotion, no device validation, and NO FLASH RELEASE.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from types import SimpleNamespace

import veux_r6_nomount211_preflight_r1 as r1

KERNEL = r1.KERNEL
NOFLASH = True
RUN_BASE = r1.R6_RUN
EXPECTED_NM_MK_SHA256 = 'ce9ca3ca442e6e30e3091168dbc1091a93d65dfbe0e93caf92d3a21be148779f'
BASE_IMAGE_SHA256 = '74cf87153b37a9ffad274494f18d93859bab38d4a3938b0ccb3330b990d3c61a'
BAD_FLAG = b' -fno-stack-protector'
MAKEFILE_REL = 'fs/nomount/Makefile'
OVERLAY_ANCHOR = '        overlay_hash = r.save_overlay(src, before, args.overlays / label, label, targets)\n'
COMPILE_ANCHOR = '        image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n'


class BuildBlocked(RuntimeError):
    pass


def require(cond: bool, reason: str) -> None:
    if not cond:
        raise BuildBlocked(reason)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_root(src: Path, rel: str) -> Path:
    src = src.resolve(strict=True)
    require(src.name == 'kernel', 'SOURCE_IS_NOT_KERNEL_ROOT')
    makefile = src/'Makefile'
    require(makefile.is_file() and not makefile.is_symlink(), 'KERNEL_MAKEFILE_UNSAFE')
    source = makefile.read_text()
    require(re.search(r'(?m)^VERSION\s*=\s*5\s*$', source) is not None and
            re.search(r'(?m)^PATCHLEVEL\s*=\s*4\s*$', source) is not None,
            'TARGET_IS_NOT_KERNEL_5_4')
    target = src/rel
    require(target.is_file() and not target.is_symlink() and
            target.resolve(strict=True).is_relative_to(src), 'INVALID_SOURCE_PATH_'+rel)
    return target


def expected_hardened(original: bytes) -> bytes:
    require(sha(original) == EXPECTED_NM_MK_SHA256,
            'NOMOUNT_UPSTREAM_MAKEFILE_SHA_CHANGED')
    require(original.count(BAD_FLAG) == 1 and original.count(b'-fno-stack-protector') == 1,
            'STACK_OPT_OUT_SCOPE_CHANGED')
    hardened = original.replace(BAD_FLAG, b'', 1)
    require(hardened != original and b'-fno-stack-protector' not in hardened,
            'STACK_HARDENING_EDIT_FAILED')
    require(hardened.replace(b' -O3\n', b' -O3 -fno-stack-protector\n', 1) == original,
            'MAKEFILE_UNRELATED_CHANGES_DETECTED')
    return hardened


def stage_stack_protection(src: Path, donor: Path, work: Path) -> dict:
    """Exactly one Makefile token removal after R6 verified source integration.

    Must execute in disposable worker after e.apply_update, before r.save_overlay,
    so the overlay hash reflects the hardening patch, not the unmodified donor.
    """
    src = src.resolve(strict=True)
    donor = donor.resolve(strict=True)
    work = work.resolve(strict=True)
    require(work.name == KERNEL and work.parent.name == 'builds' and
            work.parent.parent.is_dir(), 'UNEXPECTED_WORKDIR')
    root = work.parent.parent
    require(not src.is_relative_to(donor) and not donor.is_relative_to(src),
            'SOURCE_DONOR_OVERLAP')
    require((donor/'.git').is_dir(), 'DONOR_GIT_MISSING')
    # git identity is already verified by R6.prepare and the R1 source audit,
    # but verify the actual checkout again immediately before staging.
    proc = subprocess.run(['git','-C',str(donor),'rev-parse','HEAD'],
                          capture_output=True,text=True,timeout=20,check=False)
    require(proc.returncode == 0, 'DONOR_COMMIT_LOOKUP_FAILED')
    head = proc.stdout.strip()
    require(head == r1.NOMOUNT_NEW, 'DONOR_CHANGED_DURING_WORKER')
    original = (donor/'kernel/src/Makefile').read_bytes()
    require(sha(original) == EXPECTED_NM_MK_SHA256,
            'DONOR_MAKEFILE_SHA_CHANGED')
    target = verify_root(src, MAKEFILE_REL)
    before = target.read_bytes()
    require(before == original, 'R6_NOMOUNT_INTEGRATION_MODIFIED_UPSTREAM_MAKEFILE')
    after = expected_hardened(before)
    require(target.read_bytes() == before, 'CONCURRENT_MAKEFILE_MUTATION')
    target.write_bytes(after)
    require(target.read_bytes() == after, 'MAKEFILE_HARDENING_WRITE_FAILED')
    require((donor/'kernel/src/Makefile').read_bytes() == original,
            'IMMUTABLE_UPSTREAM_DONOR_CHANGED')
    proof = {
        'status':'STAGED_ONLY_NOT_BUILT','kernel':KERNEL,
        'source_commit':r1.NOMOUNT_NEW,'source_file':MAKEFILE_REL,
        'source_sha256':sha(before),'hardened_sha256':sha(after),
        'removed_makefile_flag':'-fno-stack-protector',
        'only_changed_file':MAKEFILE_REL,
        'upstream_donor_untouched':True,'kernel_compiled':False,
        'device_pass':False,'flash_release':False,
    }
    out = root/'report/NOMOUNT211_R2_STACK_SOURCE.json'
    require(not out.exists() and not out.is_symlink(), 'STACK_REPORT_ALREADY_EXISTS')
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(proof, indent=2, sort_keys=True)+'\n')
    return proof


def verify_compiled_stack(work: Path, source_proof: dict, result: dict) -> dict:
    """Check the compiled NoMount object command and linker evidence.

    Strong and CFI/LTO gates are mandatory. This does NOT mean bootability.
    """
    work = work.resolve(strict=True)
    root = work.parent.parent
    require(source_proof['status']=='STAGED_ONLY_NOT_BUILT' and
            source_proof['source_commit']==r1.NOMOUNT_NEW,
            'SOURCE_HARDENING_PROOF_MISSING')
    cmd_path=work/'build/fs/nomount/.nomount.o.cmd'
    obj_path=work/'build/fs/nomount/nomount.o'
    config_path=work/'config-reports/actual-build.config'
    sysmap_path=work/'build/System.map'
    symvers_path=work/'build/Module.symvers'
    for path in (cmd_path,obj_path,config_path,sysmap_path,symvers_path):
        require(path.is_file() and not path.is_symlink() and path.stat().st_size>0,
                'REQUIRED_BUILD_EVIDENCE_MISSING_'+path.relative_to(work).as_posix())
    command=cmd_path.read_text(errors='replace')
    config=config_path.read_text(errors='replace')
    system_map=sysmap_path.read_text(errors='replace')
    expected_configs=(
        'CONFIG_STACKPROTECTOR=y','CONFIG_STACKPROTECTOR_STRONG=y',
        'CONFIG_CFI_CLANG=y','CONFIG_THINLTO=y',
        'CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y',
    )
    for line in expected_configs:
        require(re.search(r'(?m)^'+re.escape(line)+r'$',config) is not None,
                'R6_KERNEL_CONFIGURATION_REGRESSION_'+line)
    require('-fno-stack-protector' not in command,
            'NOMOUNT_OBJECT_OPTED_OUT_OF_STACK_PROTECTION')
    require('-fstack-protector-strong' in command,
            'NOMOUNT_OBJECT_LACKS_STRONG_STACK_PROTECTION')
    require('-flto=thin' in command,
            'NOMOUNT_OBJECT_THINLTO_MISSING')
    for symbol in ('__stack_chk_guard','__stack_chk_fail'):
        require(re.search(r'(?m)^\S+\s+[A-Za-z]\s+'+re.escape(symbol)+r'$',system_map) is not None,
                'STACK_GUARD_LINK_SYMBOL_MISSING_'+symbol)
    require(result.get('kernel')==KERNEL, 'RESULT_KERNEL_MISMATCH')
    compiled = {
        'status':'KERNEL_COMPILE_STACK_EVIDENCE_PASS',
        'source_commit':r1.NOMOUNT_NEW,
        'kernel':KERNEL,'target_object':'fs/nomount/nomount.o',
        'source_hardening_sha256':source_proof['hardened_sha256'],
        'command_sha256':sha(cmd_path.read_bytes()),
        'object_sha256':sha(obj_path.read_bytes()),
        'config_sha256':sha(config_path.read_bytes()),
        'system_map_sha256':sha(sysmap_path.read_bytes()),
        'module_symvers_sha256':sha(symvers_path.read_bytes()),
        'strong_stack_protector_on_nomount_object':True,
        'cfi_configured':True,'thinlto_on_nomount_object':True,
        'vendor_abi_full_validation':False,
        'device_pass':False,'flash_release':False,
    }
    out=root/'report/NOMOUNT211_R2_STACK_COMPILED.json'
    require(not out.exists() and not out.is_symlink(),'BUILD_REPORT_ALREADY_EXISTS')
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(compiled,indent=2,sort_keys=True)+'\n')
    return compiled


def inject_stack_gates(generated_worker: Path) -> dict:
    """Modify ONLY the disposable R6 SELinux R3 worker after official injection."""
    require(generated_worker.is_file() and not generated_worker.is_symlink(),
            'DISPOSABLE_WORKER_MISSING')
    source=generated_worker.read_text()
    require(source.count(OVERLAY_ANCHOR)==1 and source.count(COMPILE_ANCHOR)==1,
            'EXACT_R6_WORKER_ANCHOR_DRIFT')
    require("result['bakasu_official_r6'] = bakasu_official_r6" in source,
            'R6_OFFICIAL_SELINUX_GATE_MISSING')
    require('NOMOUNT211_R2_STACK' not in source,'WORKER_ALREADY_INJECTED')
    stage=(
        '        from veux_r6_nomount211_build_r2 import stage_stack_protection\n'
        '        nomount_r2_source = stage_stack_protection(src, bundle / "nomount", work)\n'
        + OVERLAY_ANCHOR
    )
    post=(
        COMPILE_ANCHOR
        + '        from veux_r6_nomount211_build_r2 import verify_compiled_stack\n'
        + '        nomount_r2_compiled = verify_compiled_stack(work, nomount_r2_source, result)\n'
        + "        result['nomount211_r2'] = nomount_r2_compiled\n"
    )
    updated=source.replace(OVERLAY_ANCHOR,stage,1).replace(COMPILE_ANCHOR,post,1)
    ast.parse(updated,filename=str(generated_worker))
    require(updated.count('stage_stack_protection(src, bundle / "nomount", work)')==1 and
            updated.count('verify_compiled_stack(work, nomount_r2_source, result)')==1,
            'STACK_INJECTION_DUPLICATED')
    generated_worker.write_text(updated)
    require(generated_worker.read_text()==updated,'DISPOSABLE_WORKER_WRITE_FAILED')
    return {'original_worker_sha256':sha(source.encode()),
            'patched_worker_sha256':sha(updated.encode()),
            'worker_source_modified_only_in_temp':True,
            'stack_opt_out_removed_before_overlay_and_compile':True}


def build(repo: Path,root: Path,jobs: int) -> dict:
    repo=repo.resolve(strict=True)
    root=root.resolve(strict=True)
    require(1<=jobs<=16,'INVALID_BUILD_JOBS')
    require(not root.is_relative_to(repo) and
            (root/'report/NOMOUNT211_R6_SOURCE_ONLY.json').is_file(),
            'R1_SOURCE_PREFLIGHT_REQUIRED')
    previous=json.loads((root/'report/NOMOUNT211_R6_SOURCE_ONLY.json').read_text())
    require(previous['status']=='SOURCE_PREFLIGHT_ONLY_PASS' and
            previous.get('source_preflight') is True and
            previous['candidate_nomount']==r1.NOMOUNT_NEW,
            'R1_SOURCE_PREFLIGHT_NOT_GREEN')
    r6=r1.load_r6(repo)
    r1.pin_r6_temporary(r6)
    targets=json.loads((root/'bundle/targets.json').read_text())
    require(targets['components']==r6.TARGETS,'R2_COMPONENT_DRIFT')
    src_r6 = r6.selinux_r3
    old_inject=src_r6.inject_worker
    injected=[]
    def guarded_inject(original: Path, dest: Path):
        info=old_inject(original,dest)
        proof=inject_stack_gates(dest)
        injected.append({**info,**proof})
        return info
    src_r6.inject_worker=guarded_inject
    # R6 build() prepends existing AWINIC and proven repo script paths.
    # Adding this hash-authenticated overlay path allows the temp worker to
    # import our two fail-closed stack-check functions without editing the repo.
    scripts=Path(__file__).resolve().parent
    previous_pythonpath=os.environ.get('PYTHONPATH','')
    os.environ['PYTHONPATH']=os.pathsep.join([str(scripts),previous_pythonpath])
    try:
        result=r6.build(repo,root,KERNEL,jobs)
    finally:
        src_r6.inject_worker=old_inject
        os.environ['PYTHONPATH']=previous_pythonpath
    require(len(injected)==1 and injected[0]['worker_source_modified_only_in_temp'],
            'R2_WORKER_INJECTION_PROOF_INCOMPLETE')
    out=root/'public'/KERNEL/'RESULT.json'
    require(out.is_file() and not out.is_symlink(),'NO_R2_RESULT_JSON')
    payload=json.loads(out.read_text())
    hardened=payload.get('nomount211_r2',{})
    require(hardened.get('status')=='KERNEL_COMPILE_STACK_EVIDENCE_PASS' and
            hardened.get('strong_stack_protector_on_nomount_object') is True and
            hardened.get('thinlto_on_nomount_object') is True,
            'NOMOUNT_211_STACK_BUILD_PROOF_MISSING')
    require(payload.get('image_sha256')!=BASE_IMAGE_SHA256,
            'NEW_NOMOUNT_IMAGE_IDENTICAL_TO_R6')
    require(payload.get('targets')==r6.TARGETS and
            all(payload.get(k) is True for k in ('compile','package','static_boot')) and
            payload.get('device') is False,
            'R2_OUTPUT_TARGETS_OR_GATES_MISMATCH')
    require(result.get('image_sha256')==payload['image_sha256'],
            'R6_R2_IMAGE_PROOF_MISMATCH')
    audit={'status':'EXPERIMENTAL_BUILD_GATES_PASS_DEVICE_NOT_TESTED',
           'old_build_run':RUN_BASE,'kernel':KERNEL,
           'original_r6_kernel_sha256':BASE_IMAGE_SHA256,
           'candidate_kernel_sha256':payload['image_sha256'],
           'nomount_r6_commit':r1.NOMOUNT_R6,
           'nomount_r2_commit':r1.NOMOUNT_NEW,
           'bakasu_pin':r1.BAKASU_PIN,'susfs_pin':r1.SUSFS_PIN,
           'disposable_worker_injection':injected[0],
           'stack_protection':hardened,
           'compile':True,'package':True,'static_boot':True,
           'device_pass':False,'flash_release':False,
           'repo_mutated':False,'susfs_update_applied':False}
    audit_path=root/'report/NOMOUNT211_R2_FINAL.json'
    require(not audit_path.exists(),'R2_FINAL_REPORT_ALREADY_EXISTS')
    audit_path.write_text(json.dumps(audit,indent=2,sort_keys=True)+'\n')
    print('VEUX_R6_NOMOUNT211_R2_COMPILE_AND_STACK_GATES=PASS; DEVICE_PASS=NO; NO_FLASH',flush=True)
    return audit


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=('build',))
    parser.add_argument('--repo',type=Path,required=True)
    parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--jobs',type=int,default=4)
    args=parser.parse_args()
    try:
        build(args.repo,args.work,args.jobs)
        return 0
    except Exception as exc:
        print(f'VEUX_R6_NM211_R2_BLOCKED: {type(exc).__name__}: {exc}',file=sys.stderr,flush=True)
        return 1


if __name__=='__main__':
    sys.exit(main())
