#!/usr/bin/env python3
"""Offline fail-closed tests for the R6 NoMount 2.1.1 source-only candidate."""
from __future__ import annotations
import copy
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'common/scripts'))
import veux_r6_nomount211_preflight_r1 as c

class Base:
    EXPECTED_KERNEL_R3 = c.KERNEL
    BUILT_NOMOUNT21 = 'c7f63e3feb4125d591b6969a33aac04feb40f8ba'
    def __init__(self):
        self.TARGETS = {
          'resukisu': {'url': 'https://github.com/Baka-SU/BakaSU.git',
                       'commit': c.BAKASU_PIN, 'version': '35222'},
          'susfs': {'commit': c.SUSFS_PIN, 'version': '2.3.0'},
          'nomount': {'url':c.NOMOUNT_URL,'ref':c.NOMOUNT_REF,
                      'commit':c.NOMOUNT_R6,'version':'21'}
        }
    def run(self,*args):
        operation = args[3] if len(args)>3 else ''
        if operation=='rev-parse': return c.NOMOUNT_NEW
        if operation=='status': return ''
        if operation=='merge-base': return ''
        if operation=='show': return self.old_header
        raise AssertionError(f'unexpected simulated Git operation {args}')
    def validate_wire_abi(self,old,new):
        if 'NOMOUNT_BASE_VERSION "21"' not in old or old!=new:
            raise c.Blocked('PROTOCOL_MISMATCH')
        return {name:'IDENTICAL' for name in ('enum','nm_payload','nm_rule_hdr','nm_del_hdr')}

class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.snapshot = ROOT / 'common/r6_nm211/pinned_nomount_7046c7ad_source.tar.gz'
        with tarfile.open(cls.snapshot, 'r:gz') as z:
            cls.blobs={i.name:z.extractfile(i).read() for i in z if i.isfile()}
    def test_snapshot_scope(self):
        self.assertEqual(set(self.blobs),{
          'kernel/src/nomount.c','kernel/src/nomount.h','kernel/src/Makefile',
          'kernel/src/Kconfig','kernel/LICENSE','kernel/setup.sh','kernel/README.md'})
    def test_snapshot_matches_declared_git_blobs(self):
        for name, expected in c.DONOR_BLOBS.items():
            self.assertEqual(c.blob(self.blobs[name]),expected,name)
    def test_snapshot_keeps_wire21(self):
        self.assertIn(b'NOMOUNT_BASE_VERSION "21"',self.blobs['kernel/src/nomount.h'])
    def test_makefile_flag_requires_review(self):
        self.assertEqual(self.blobs['kernel/src/Makefile'].count(b'-fno-stack-protector'),1)
    def test_correct_pins_only_update_nomount(self):
        b=Base(); old=copy.deepcopy(b.TARGETS)
        returned=c.pin_r6_temporary(b)
        self.assertEqual(returned,old)
        self.assertEqual(b.TARGETS['resukisu'],old['resukisu'])
        self.assertEqual(b.TARGETS['susfs'],old['susfs'])
        self.assertEqual(b.TARGETS['nomount']['commit'],c.NOMOUNT_NEW)
    def test_bakasu_drift_fails(self):
        b=Base();b.TARGETS['resukisu']['commit']='f'*40
        with self.assertRaisesRegex(c.Blocked,'BAKASU_PIN_CHANGED'):
            c.pin_r6_temporary(b)
    def test_susfs_drift_fails(self):
        b=Base();b.TARGETS['susfs']['commit']='f'*40
        with self.assertRaisesRegex(c.Blocked,'SUSFS_PIN_CHANGED'):
            c.pin_r6_temporary(b)
    def test_nomount_base_drift_fails(self):
        b=Base();b.TARGETS['nomount']['commit']='f'*40
        with self.assertRaisesRegex(c.Blocked,'R6_NOMOUNT_BASE_CHANGED'):
            c.pin_r6_temporary(b)
    def test_nomount_protocol_drift_fails(self):
        b=Base();b.TARGETS['nomount']['version']='22'
        with self.assertRaisesRegex(c.Blocked,'NOMOUNT_PROTOCOL_CHANGED'):
            c.pin_r6_temporary(b)
    def test_bakasu_version_drift_fails(self):
        b=Base();b.TARGETS['resukisu']['version']='35230'
        with self.assertRaisesRegex(c.Blocked,'BAKASU_VERSION_CHANGED'):
            c.pin_r6_temporary(b)
    def test_kernel_drift_fails(self):
        b=Base();b.EXPECTED_KERNEL_R3='5.4.300'
        with self.assertRaisesRegex(c.Blocked,'R6_KERNEL_SCOPE_CHANGED'):
            c.pin_r6_temporary(b)
    def test_reject_link_as_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'real').write_text('safe')
            (root/'bad').symlink_to(root/'real')
            with self.assertRaisesRegex(c.Blocked,'FILE_MISSING_OR_LINK'):
                c.file_blob(root/'bad')
    def _sample_checkout(self,root):
        donor=root/'bundle/nomount'
        donor.mkdir(parents=True)
        (donor/'.git').mkdir()
        for path, data in self.blobs.items():
            dest=donor/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        b=Base();b.old_header=self.blobs['kernel/src/nomount.h'].decode()
        return b,donor
    def test_candidate_post_checkout(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b,_=self._sample_checkout(root)
            result=c.verify_candidate(b,root)
            self.assertEqual(result['commit'],c.NOMOUNT_NEW)
            self.assertTrue(result['stack_protector_needs_explicit_build_review'])
            self.assertEqual(len(result['wire_declarations']),4)
    def test_candidate_modified_makefile_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b,d=self._sample_checkout(root)
            f=d/'kernel/src/Makefile';f.write_text(f.read_text().replace(c.NO_UNCHECKED_FLAG,''))
            with self.assertRaisesRegex(c.Blocked,'NOMOUNT_KNOWN_SOURCE_BLOB_DRIFT'):
                c.verify_candidate(b,root)
    def test_candidate_modified_header_blocked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);b,d=self._sample_checkout(root)
            f=d/'kernel/src/nomount.h';f.write_text(f.read_text().replace('NOMOUNT_BASE_VERSION "21"', 'NOMOUNT_BASE_VERSION "22"'))
            with self.assertRaisesRegex(c.Blocked,'NOMOUNT_KNOWN_SOURCE_BLOB_DRIFT'):
                c.verify_candidate(b,root)
    def test_write_report_not_a_release(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=Path(tmp); status={'device_pass':False,'flash_permission':False,'kernel_built':False}
            c.report(r,status)
            self.assertEqual(json.loads((r/'report/NOMOUNT211_R6_SOURCE_ONLY.json').read_text()),status)
    def test_git_blob_matches_digest_formula(self):
        x=b'Safe source'; expected=hashlib.sha1(b'blob 11\0'+x).hexdigest()
        self.assertEqual(c.blob(x),expected)

if __name__=='__main__':
    unittest.main(verbosity=2)
