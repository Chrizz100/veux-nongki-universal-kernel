"""Offline positive and fail-closed tests for the temporary VEUX R6 R2 hook."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch

SCRIPT_DIR=Path(__file__).resolve().parents[1]/'common/scripts'
sys.path.insert(0,str(SCRIPT_DIR))
import veux_r6_nomount211_build_r2 as b


class R2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with tarfile.open(SCRIPT_DIR.parent/'r6_nm211/pinned_nomount_7046c7ad_source.tar.gz') as t:
            cls.official_makefile=t.extractfile('kernel/src/Makefile').read()
            cls.official_header=t.extractfile('kernel/src/nomount.h').read()

    def test_01_expected_upstream_makefile_sha(self):
        self.assertEqual(hashlib.sha256(self.official_makefile).hexdigest(), b.EXPECTED_NM_MK_SHA256)

    def test_02_hardened_original_exact(self):
        data=b.expected_hardened(self.official_makefile)
        self.assertNotIn(b'-fno-stack-protector',data)
        self.assertIn(b' -O3\n',data)
        self.assertEqual(len(data),len(self.official_makefile)-len(b.BAD_FLAG))

    def test_03_reject_tampered_upstream(self):
        with self.assertRaisesRegex(b.BuildBlocked,'UPSTREAM_MAKEFILE_SHA'):
            b.expected_hardened(self.official_makefile+b'\n')

    def test_04_reject_double_patch(self):
        with self.assertRaisesRegex(b.BuildBlocked,'UPSTREAM_MAKEFILE_SHA'):
            b.expected_hardened(b.expected_hardened(self.official_makefile))

    def test_05_protect_scope_non_target_kernel(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)/'kernel';root.mkdir(); (root/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 10\n')
            path=root/'fs/nomount/Makefile';path.parent.mkdir(parents=True);path.write_bytes(self.official_makefile)
            with self.assertRaisesRegex(b.BuildBlocked,'TARGET_IS_NOT_KERNEL_5_4'):
                b.verify_root(root,'fs/nomount/Makefile')

    def test_06_scope_valid_kernel(self):
        with tempfile.TemporaryDirectory() as t:
            kernel=Path(t)/'kernel';kernel.mkdir();(kernel/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\n')
            f=kernel/'fs/nomount/Makefile';f.parent.mkdir(parents=True);f.write_bytes(self.official_makefile)
            self.assertEqual(b.verify_root(kernel,'fs/nomount/Makefile'),f)

    def test_07_scope_reject_external_symlink(self):
        with tempfile.TemporaryDirectory() as t:
            kernel=Path(t)/'kernel';kernel.mkdir();(kernel/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\n')
            f=kernel/'fs/nomount/Makefile';f.parent.mkdir(parents=True)
            outside=Path(t)/'outside';outside.write_bytes(self.official_makefile)
            f.symlink_to(outside)
            with self.assertRaisesRegex(b.BuildBlocked,'INVALID_SOURCE_PATH'):
                b.verify_root(kernel,'fs/nomount/Makefile')

    def _worker_text(self):
        return '''def worker():\n    if 1:\n        src = 1\n        overlay_hash = r.save_overlay(src, before, args.overlays / label, label, targets)\n        image, result = compat.compile_kernel(label, state, targets, work, args.jobs)\n        result['bakasu_official_r6'] = bakasu_official_r6\n'''

    def test_08_temp_worker_injection_valid(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'tempworker.py';path.write_text(self._worker_text())
            proof=b.inject_stack_gates(path)
            self.assertTrue(proof['stack_opt_out_removed_before_overlay_and_compile'])
            self.assertEqual(path.read_text().count('stage_stack_protection(src, bundle / "nomount", work)'),1)
            self.assertEqual(path.read_text().count('verify_compiled_stack(work, nomount_r2_source, result)'),1)

    def test_09_temp_worker_reject_duplicate_anchor(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'worker.py';path.write_text(self._worker_text()+b.OVERLAY_ANCHOR)
            with self.assertRaisesRegex(b.BuildBlocked,'WORKER_ANCHOR_DRIFT'):
                b.inject_stack_gates(path)

    def test_10_temp_worker_reject_missing_official_selinux(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'worker.py';path.write_text(self._worker_text().replace("        result['bakasu_official_r6'] = bakasu_official_r6\n",''))
            with self.assertRaisesRegex(b.BuildBlocked,'R6_OFFICIAL_SELINUX_GATE'):
                b.inject_stack_gates(path)

    def test_11_temp_worker_reject_injection_twice(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'worker.py';path.write_text(self._worker_text())
            b.inject_stack_gates(path)
            with self.assertRaises(b.BuildBlocked):
                b.inject_stack_gates(path)

    def _compiled(self,base:Path):
        work=base/'builds/5.4.274'; work.mkdir(parents=True)
        files={
            'build/fs/nomount/.nomount.o.cmd':'cmd := clang -flto=thin -fstack-protector-strong -c source.c\n',
            'build/fs/nomount/nomount.o':'object bytes',
            'config-reports/actual-build.config':'\n'.join((
                'CONFIG_STACKPROTECTOR=y','CONFIG_STACKPROTECTOR_STRONG=y','CONFIG_CFI_CLANG=y',
                'CONFIG_THINLTO=y','CONFIG_KSU=y','CONFIG_KSU_SUSFS=y','CONFIG_NOMOUNT=y'))+'\n',
            'build/System.map':'0000000000100000 T __stack_chk_guard\n0000000000200000 T __stack_chk_fail\n',
            'build/Module.symvers':'0xbff14f69\tmodule_layout\tvmlinux\tEXPORT_SYMBOL\n',
        }
        for name,value in files.items():
            p=work/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value.encode())
        return work

    def _source_proof(self):
        return {'status':'STAGED_ONLY_NOT_BUILT','source_commit':b.r1.NOMOUNT_NEW,
                'hardened_sha256':hashlib.sha256(b.expected_hardened(self.official_makefile)).hexdigest()}

    def test_12_build_proof_valid_fixture(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d))
            row=b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})
            self.assertEqual(row['status'],'KERNEL_COMPILE_STACK_EVIDENCE_PASS')
            self.assertFalse(row['device_pass'])

    def test_13_build_reject_disabled_canary(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d));p=work/'build/fs/nomount/.nomount.o.cmd';p.write_text(p.read_text().replace(' -fstack-protector-strong',' -fno-stack-protector'))
            with self.assertRaisesRegex(b.BuildBlocked,'OBJECT_OPTED_OUT'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})

    def test_14_build_reject_missing_thinlto(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d));p=work/'build/fs/nomount/.nomount.o.cmd';p.write_text(p.read_text().replace(' -flto=thin',''))
            with self.assertRaisesRegex(b.BuildBlocked,'THINLTO_MISSING'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})

    def test_15_build_reject_lost_strong_config(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d));p=work/'config-reports/actual-build.config';p.write_text(p.read_text().replace('CONFIG_STACKPROTECTOR_STRONG=y',''))
            with self.assertRaisesRegex(b.BuildBlocked,'CONFIGURATION_REGRESSION'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})

    def test_16_build_reject_missing_system_map_guard(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d));p=work/'build/System.map';p.write_text(p.read_text().replace('__stack_chk_guard','other'))
            with self.assertRaisesRegex(b.BuildBlocked,'STACK_GUARD_LINK_SYMBOL_MISSING'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})

    def test_17_build_reject_missing_object(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d));(work/'build/fs/nomount/nomount.o').unlink()
            with self.assertRaisesRegex(b.BuildBlocked,'REQUIRED_BUILD_EVIDENCE_MISSING'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':b.KERNEL})

    def test_18_build_reject_wrong_result_kernel(self):
        with tempfile.TemporaryDirectory() as d:
            work=self._compiled(Path(d))
            with self.assertRaisesRegex(b.BuildBlocked,'RESULT_KERNEL_MISMATCH'):
                b.verify_compiled_stack(work,self._source_proof(),{'kernel':'5.4.300'})

    def test_19_source_report_cannot_claim_flash(self):
        self.assertTrue(b.NOFLASH)
        self.assertFalse(self._source_proof().get('device_pass',False))

    def test_20_safety_anchor_enforces_build_after_overlay(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'worker.py';p.write_text(self._worker_text())
            b.inject_stack_gates(p)
            t=p.read_text()
            self.assertLess(t.index('stage_stack_protection(src, bundle'),t.index('overlay_hash = r.save_overlay'))
            self.assertLess(t.index('overlay_hash = r.save_overlay'),t.index('compat.compile_kernel('))

    def _stage_fixture(self, base: Path):
        src=base/'source-work/kernel';src.mkdir(parents=True)
        (src/'Makefile').write_text('VERSION = 5\nPATCHLEVEL = 4\n')
        target=src/'fs/nomount/Makefile';target.parent.mkdir(parents=True)
        target.write_bytes(self.official_makefile)
        donor=base/'bundle/nomount';(donor/'.git').mkdir(parents=True)
        mk=donor/'kernel/src/Makefile';mk.parent.mkdir(parents=True)
        mk.write_bytes(self.official_makefile)
        work=base/'builds/5.4.274';work.mkdir(parents=True)
        return src,donor,work,target,mk

    def test_21_temporal_stage_exactly_one_makefile(self):
        with tempfile.TemporaryDirectory() as d:
            src,donor,work,target,mk=self._stage_fixture(Path(d))
            proc=subprocess.CompletedProcess(args=[],returncode=0,stdout=b.r1.NOMOUNT_NEW+'\n')
            with patch.object(b.subprocess,'run',return_value=proc):
                data=b.stage_stack_protection(src,donor,work)
            self.assertEqual(data['status'],'STAGED_ONLY_NOT_BUILT')
            self.assertEqual(target.read_bytes(),b.expected_hardened(self.official_makefile))
            self.assertEqual(mk.read_bytes(),self.official_makefile)
            self.assertTrue((Path(d)/'report/NOMOUNT211_R2_STACK_SOURCE.json').is_file())

    def test_22_stage_reject_altered_kernel_makefile(self):
        with tempfile.TemporaryDirectory() as d:
            src,donor,work,target,mk=self._stage_fixture(Path(d))
            target.write_bytes(self.official_makefile+b'\n')
            proc=subprocess.CompletedProcess(args=[],returncode=0,stdout=b.r1.NOMOUNT_NEW+'\n')
            with patch.object(b.subprocess,'run',return_value=proc):
                with self.assertRaisesRegex(b.BuildBlocked,'INTEGRATION_MODIFIED'):
                    b.stage_stack_protection(src,donor,work)

    def test_23_stage_reject_unpinned_donor(self):
        with tempfile.TemporaryDirectory() as d:
            src,donor,work,target,mk=self._stage_fixture(Path(d))
            proc=subprocess.CompletedProcess(args=[],returncode=0,stdout=b.r1.NOMOUNT_R6+'\n')
            with patch.object(b.subprocess,'run',return_value=proc):
                with self.assertRaisesRegex(b.BuildBlocked,'DONOR_CHANGED_DURING_WORKER'):
                    b.stage_stack_protection(src,donor,work)
            self.assertEqual(target.read_bytes(),self.official_makefile)

    def test_24_stage_reject_repeated_attempt(self):
        with tempfile.TemporaryDirectory() as d:
            src,donor,work,target,mk=self._stage_fixture(Path(d))
            proc=subprocess.CompletedProcess(args=[],returncode=0,stdout=b.r1.NOMOUNT_NEW+'\n')
            with patch.object(b.subprocess,'run',return_value=proc):
                b.stage_stack_protection(src,donor,work)
                with self.assertRaisesRegex(b.BuildBlocked,'INTEGRATION_MODIFIED'):
                    b.stage_stack_protection(src,donor,work)

if __name__=='__main__':
    unittest.main(verbosity=2)
