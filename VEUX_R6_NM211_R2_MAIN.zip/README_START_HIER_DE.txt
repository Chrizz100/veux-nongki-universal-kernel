VEUX 5.4.274 – R6 NO-MOUNT v2.1.1 – EXPERIMENTELLER R2-BUILD
Stand: 16.10.2026

WICHTIG: KEINE FLASHFREIGABE.

Ausgangspunkt GitHub Run 38530535344, BakaSU 35222 mit d726, SUSFS 2.3.0
fest bei 5326e21a, NoMount bisher 1ded61dc. Proven source green:
GitHub Run 38960694902, main SHA 554e1d2f19bf138760c9b9bef8ec94ae1684ad5c.

R2 aktualisiert nur den temporären NoMount-Bestand auf den offiziellen
master Commit 7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3 (v2.1.1,
Kernel-/Userspace-Protokoll 21); offizielle vier Kerneldatei-Git-BLOBS sind
hashgeprüft. Upstream-Makefile deaktiviert Stackschutz für NoMount.

Der R2-Kernel-Build entfernt vor dem Übersetzen in einem TEMPORÄREN Worker
nur die einzelnen Bytes ` -fno-stack-protector` aus fs/nomount/Makefile,
vor Erstellung des Integrations-Overlays. Git-Donor, Repository und alte R6-
Quellen bleiben vollständig unverändert. Der unveränderte R6-Buildworker führt
seine AWINIC-, RPM-, WAKEUP-, RMNET-, BakaSU-/SELinux- und Static-Boot-Gates
weiter aus. Neue R2-Gates prüfen die tatsächlich verwendete Clang-Kommando-
zeile, CONFIG_STACKPROTECTOR_STRONG, ThinLTO/CFI-Konfiguration, Kernel-Symbole
und Module.symvers. Kein Gerätetest, keine finale Vendor-KMI-Freigabe.

INSTALLATION:
1. VEUX_R6_NM211_R2_MAIN.zip in das Repository-Hauptverzeichnis hochladen.
   Der Name muss unverändert bleiben. ZIP NICHT in die Repo entpacken.
2. VEUX_R6_NM211_R2_EXPERIMENTAL_BUILD.yml nach .github/workflows/ hochladen.
3. Actions > VEUX R6 NoMount v2.1.1 R2 - Experimental Build - NO FLASH
   > Run workflow; enable_build=true für einen echten isolierten Build.
4. Ergebnis und die originalen Logs hier bereitstellen. Nichts flashen.

SUSFS:
R2 lässt SUSFS 2.3.0 auf Commit 5326e21a unverändert. Die neue
frozen GitLab HEAD fec037cb liegt vier Commits voraus; zwei SELinux-5.4-
Hostdateien aus dem ersten Differenzabgleich müssen manuell angepasst werden.
Ohne auswertbaren Runtime-/ABI-Test keine gemeinsame Aktualisierung.
Die BakaSU-Upstream-SUSFS-Sperre wird nicht entfernt.

Green-Pass-Aussage: lokale Workflow-Syntax, Quell- und Fehlerfalltests können
grün sein, während der echte GitHub-Kernel-Build noch nicht gelaufen ist.
