#!/usr/bin/env python3
"""VEUX R46-R8, actual WALT ARM64 OEM configuration A/B check.

Read-only OEM import baselines; writes only to existing ephemeral kernel build output.
Never forges symbol CRCs, changes vendor modules, spoofs Xiaomi's Git ID, or packages flash images.
"""
from __future__ import annotations
import argparse,csv,hashlib,json,os,pathlib,re,subprocess,sys,time,collections
from pathlib import Path

R46_CONFIG_SHA='7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe'
STOCK_CONFIG_SHA='334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
R46_SYMVERS_SHA='4da484027430b94492a383c9f32db5cff7c252b25868996696ef8b27e849b302'
STOCK_RELEASE='5.4.274-qgki-g82179e362f33'
CANDIDATE_RELEASE='5.4.274-qgki'
EXPECTED_ORIGINAL_LAYOUT='0x945d02f2'
EXPECTED_ORIGINAL_COUNTS={'MATCH':578,'CRC_MISMATCH':841,'NOT_EXPORTED':4}
SOURCE_KEY='CONFIG_ARM64_LSE_ATOMICS'

class GateError(RuntimeError): pass
def need(ok, why):
    if not ok: raise GateError(why)
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def read_json(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write_json(p,obj):Path(p).write_text(json.dumps(obj,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
def readcsv(p):
    with open(p,newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def writecsv(path, rows, fields):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader();w.writerows(rows)

def parse_config(text):
    out={}
    for line in text.splitlines():
        m=re.fullmatch(r'(CONFIG_[A-Z0-9_]+)=(.*)',line)
        n=re.fullmatch(r'# (CONFIG_[A-Z0-9_]+) is not set',line)
        if m or n:
            key=m.group(1) if m else n.group(1)
            need(key not in out,'CONFIG_DUPLICATE:'+key)
            out[key]=m.group(2) if m else 'n'
    need(len(out)>100,'BAD_CONFIG')
    return out

def parse_symvers(path):
    found={};n=0
    for line in Path(path).read_text(encoding='utf-8',errors='replace').splitlines():
        fields=line.split()
        need(len(fields)>=4,'SYMVERS_ROW_MALFORMED')
        crc,name=fields[0].lower(),fields[1]
        need(re.fullmatch(r'0x[0-9a-f]{8}',crc) is not None,'SYMVERS_CRC_INVALID')
        need(name not in found,'SYMVERS_DUPLICATE:'+name)
        found[name]=crc;n+=1
    need(n>=10000,'SYMVERS_TOO_SMALL')
    return found

def profile(evidence):
    evidence=Path(evidence)
    need(sha(evidence/'R46_EFFECTIVE_BUILD.config')==R46_CONFIG_SHA,'CANDIDATE_CONFIG_SOURCE_DRIFT')
    need(sha(evidence/'STOCK_ORIGINAL_IKCONFIG.config')==STOCK_CONFIG_SHA,'STOCK_CONFIG_SOURCE_DRIFT')
    c=parse_config((evidence/'R46_EFFECTIVE_BUILD.config').read_text())
    s=parse_config((evidence/'STOCK_ORIGINAL_IKCONFIG.config').read_text())
    need(c[SOURCE_KEY]=='y' and s[SOURCE_KEY]=='n','UNEXPECTED_OEM_LSE_DELTA')
    sym=readcsv(evidence/'QGKI_R46_ORIGINAL_VERIFIED_SYMBOL_CRC.csv')
    sym=[x for x in sym if x.get('cohort')=='QGKI']
    need(len(sym)==1423 and len({x['symbol'] for x in sym})==1423,'OEM_1423_UNIQUE_SYMBOLS')
    expected={x['symbol']:x['expected_oem_crc'].lower() for x in sym}
    original={x['symbol']:x['r46_crc'].lower() for x in sym}
    need(original['module_layout']=='0x0bcef28c' and expected['module_layout']==EXPECTED_ORIGINAL_LAYOUT,
         'OEM_MODULE_LAYOUT_REFERENCE_CHANGED')
    counted=collections.Counter('NOT_EXPORTED' if x['r46_crc'].upper() in ('','NOT_EXPORTED','MISSING') else
                                ('MATCH' if x['r46_crc'].lower()==x['expected_oem_crc'].lower() else 'CRC_MISMATCH') for x in sym)
    # Some historical fixtures represent missing exports with a blank cell.
    need(dict(counted)==EXPECTED_ORIGINAL_COUNTS,'BASELINE_PROFILE_COUNTS_CHANGED:'+str(dict(counted)))
    imports=readcsv(evidence/'QGKI_37_ORIGINAL_MODULE_IMPORTS.csv')
    need(len(imports)==3148 and len({x['module'] for x in imports})==37,'QGKI_MODULE_PROFILE_NOT_37')
    need(all(x['symbol'] in expected and x['expected_crc'].lower()==expected[x['symbol']]
             for x in imports),'QGKI_IMPORT_CRC_REFERENCE_CHANGED')
    need(len({(x['module'],x['symbol']) for x in imports})==3148,'QGKI_DUPLICATE_MODULE_IMPORT')
    return c,s,expected,original,imports

def compare_symbols(symvers, expected, imports):
    symbols=[]
    for name,crc in sorted(expected.items()):
        got=symvers.get(name)
        kind='NOT_EXPORTED' if got is None else ('MATCH' if got==crc else 'CRC_MISMATCH')
        symbols.append(dict(symbol=name,oem_crc=crc,candidate_crc=got or '',status=kind))
    status={x['symbol']:x['status'] for x in symbols}
    bymodule=collections.defaultdict(collections.Counter)
    for i in imports:bymodule[i['module']][status[i['symbol']]]+=1
    mod=[]
    for m in sorted(bymodule):
        q=bymodule[m]
        mod.append(dict(module=m,imports=sum(q.values()),match=q['MATCH'],crc_mismatch=q['CRC_MISMATCH'],missing=q['NOT_EXPORTED'],fully_compatible=(q['CRC_MISMATCH']==0 and q['NOT_EXPORTED']==0)))
    counts=collections.Counter(x['status'] for x in symbols)
    return symbols,mod,counts

def pinned_invocations(report, source, objout):
    arr=report['make_results'];need(len(arr)==3,'BASELINE_MAKE_COUNT')
    commands={}
    for row in arr:
        argv=row['invocation'];kind=row['target']
        need(kind in ('Image','dtbs','modules') and kind not in commands,'MAKE_TARGET_DUPLICATE')
        need(argv[0]=='make' and argv[-1]==kind and '-j2' in argv,'MAKE_NOT_PINNED:'+kind)
        need('-C' in argv and Path(argv[argv.index('-C')+1]).resolve()==source,'MAKE_SOURCE_NOT_SAME')
        need('O='+str(objout) in argv,'MAKE_OUTPUT_NOT_SAME')
        for token in ('ARCH=arm64','LLVM=1','LLVM_IAS=1','CC=','LD=','AR=','NM=','OBJCOPY='):
            need(any(z.startswith(token) for z in argv),'MAKE_ENV_MISSING:'+token)
        commands[kind]=argv
    return commands

def env_for(argv):
    nm=[a[3:] for a in argv if a.startswith('NM=')]
    need(len(nm)==1,'NM_NOT_UNIQUE')
    p=Path(nm[0]);need(p.is_absolute() and p.is_file() and os.access(p,os.X_OK),'NM_NOT_PINNED_EXECUTABLE')
    env=os.environ.copy();env['PATH']=str(p.parent)+os.pathsep+env.get('PATH','')
    return env

def run_command(argv,env,log,timeout=1500):
    t=time.monotonic()
    try:
        with open(log,'wb') as f: r=subprocess.run(argv,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=timeout)
        rc=r.returncode
    except subprocess.TimeoutExpired:rc=124
    return {'rc':rc,'elapsed_sec':round(time.monotonic()-t,1),'log_sha256':sha(log),'command':argv,'timeout':rc==124}

def run(args):
    src=Path(args.source).resolve(strict=True);obj=Path(args.objout).resolve(strict=True)
    out=Path(args.output).resolve();need(not out.exists(),'R8_OUTPUT_MUST_BE_NEW')
    ws=Path(os.environ.get('GITHUB_WORKSPACE','/INVALID')).resolve()
    need(src!=obj and src.is_relative_to(ws) and obj.is_relative_to(ws),'R8_EPHEMERAL_SOURCES_ONLY')
    rep=read_json(args.r47)
    need(rep['status']=='R46_R6_ROOTLESS_CONFIG_RELEASE_AND_RMNET_BUILD_PROVEN_NOFLASH','R46R6_NOT_GREEN')
    need(rep['module_symvers_sha256']==R46_SYMVERS_SHA and rep['config_sha256']==R46_CONFIG_SHA,'BASELINE_SHA_MISMATCH')
    need(rep['vendor_abi_proven'] is False and rep['flash_allowed'] is False,'BAD_FLASH_CLAIM')
    need(rep['candidate_release_verified']==CANDIDATE_RELEASE and rep['original_stock_release_reference']==STOCK_RELEASE,
         'RELEASE_REFERENCE_CHANGED')
    need(sha(obj/'Module.symvers')==R46_SYMVERS_SHA and sha(obj/'.config')==R46_CONFIG_SHA,'R47_BASE_ARTIFACTS_NOT_FROZEN')
    need(sha(obj/'arch/arm64/boot/Image')==rep['image_sha256'],'R47_IMAGE_NOT_VERIFIED')
    orig,s,expected,r46_crcs,imports=profile(args.evidence)
    cur=parse_symvers(obj/'Module.symvers')
    need(all(cur.get(name)==(v if v not in ('','NOT_EXPORTED') else None) for name,v in r46_crcs.items()),
         'BASELINE_OEM_PROFILE_DOES_NOT_MATCH_TRUE_SYMVERS')
    before_s,before_m,before_cnt=compare_symbols(cur,expected,imports)
    need(dict(before_cnt)==EXPECTED_ORIGINAL_COUNTS,'BASELINE_ABI_NUMBERS_CHANGED')
    cfgbefore=parse_config((obj/'.config').read_text());need(cfgbefore==orig,'EFFECTIVE_KERNEL_CONFIG_CHANGED')
    base_commands=pinned_invocations(rep,src,obj)
    release_file=obj/'include/config/kernel.release'
    need(release_file.read_text().strip()==CANDIDATE_RELEASE,'RELEASE_CHANGED')
    config_tool=src/'scripts/config'
    need(config_tool.is_file() and not config_tool.is_symlink(),'CONFIG_SCRIPT_MISSING')
    out.mkdir(parents=True,exist_ok=False)
    result={'schema':'VEUX_R46_R8_REAL_OEM_LSE_SINGLE_VARIABLE_ABI_V1',
            'status':'BLOCKED_NO_FLASH','source':'R46-R6 genuine WALT build',
            'single_delta':SOURCE_KEY,'stock_reference':STOCK_RELEASE,'candidate_release':CANDIDATE_RELEASE,
            'source_modified':False,'oem_vendor_abi_proven':False,'flash_allowed':False,
            'baseline':{'module_symvers_sha256':R46_SYMVERS_SHA,'image_sha256':rep['image_sha256'],
                        'config_sha256':R46_CONFIG_SHA,'qgki_counts':dict(before_cnt)},'steps':[]}
    try:
        p=run_command(['bash',str(config_tool),'--file',str(obj/'.config'),'-d','ARM64_LSE_ATOMICS'],os.environ.copy(),out/'R8_CHANGE_CONFIG.log',60)
        result['steps'].append({'target':'scripts/config',**p});need(p['rc']==0,'SCRIPTS_CONFIG_FAILED')
        new=parse_config((obj/'.config').read_text());changes={k:(orig.get(k),new.get(k)) for k in orig.keys()|new.keys() if orig.get(k)!=new.get(k)}
        need(changes=={SOURCE_KEY:('y','n')},'CONFIG_NOT_EXACT_ONE_DELTA_BEFORE_OLDDEFCONFIG:'+str(changes))
        argv=base_commands['Image'][:-1]+['olddefconfig']
        q=run_command(argv,env_for(argv),out/'R8_OLDDEFCONFIG.log',300)
        result['steps'].append({'target':'olddefconfig',**q});need(q['rc']==0,'OLDDEFCONFIG_FAILED')
        after=parse_config((obj/'.config').read_text());all_diff={k:(orig.get(k),after.get(k)) for k in orig.keys()|after.keys() if orig.get(k)!=after.get(k)}
        result['resolved_config_diff']=all_diff
        need(all_diff=={SOURCE_KEY:('y','n')},'NOT_ONE_CONFIG_DELTA_AFTER_KCONFIG:'+str(all_diff))
        for target in ('Image','dtbs','modules'):
            q=run_command(base_commands[target],env_for(base_commands[target]),out/f'R8_{target}_MAKE.log')
            result['steps'].append({'target':target,**q});need(q['rc']==0,'REAL_ARM64_BUILD_FAILED:'+target)
        need(release_file.read_text().strip()==CANDIDATE_RELEASE,'KERNEL_RELEASE_MISMATCH_AFTER_BUILD')
        need(sha(obj/'.config')!=R46_CONFIG_SHA,'CONFIG_CHANGE_DID_NOT_APPLY')
        image=obj/'arch/arm64/boot/Image';vmlinux=obj/'vmlinux';dtb=obj/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb'
        with image.open('rb') as f:f.seek(0x38);need(f.read(4)==b'ARM\x64','IMAGE_NOT_ARM64')
        with vmlinux.open('rb') as f:magic=f.read(20);need(magic[:4]==b'\x7fELF' and magic[18:20]==b'\xb7\x00','VMLINUX_NOT_ARM64')
        need(dtb.read_bytes()[:4]==b'\xd0\x0d\xfe\xed','DTB_NOT_FDT')
        need('~positron' not in release_file.read_text(),'POS_REMOVE_REGRESSION')
        symvers=obj/'Module.symvers';modified=parse_symvers(symvers)
        syms,mods,counts=compare_symbols(modified,expected,imports)
        need(len(syms)==1423 and len(mods)==37 and sum(x['imports'] for x in mods)==3148,'QGKI_PROFILE_WRONG')
        writecsv(out/'R8_QGKI_1423_SYMBOL_RESULTS.csv',syms,['symbol','oem_crc','candidate_crc','status'])
        writecsv(out/'R8_QGKI_37_MODULE_RESULTS.csv',mods,['module','imports','match','crc_mismatch','missing','fully_compatible'])
        baseline_match=before_cnt['MATCH'];new_match=counts['MATCH']
        changed=[s for s in syms if modified.get(s['symbol'])!=cur.get(s['symbol'])]
        better=new_match>baseline_match
        full=all(m['fully_compatible'] for m in mods)
        result.update({'status':'STATIC_QGKI_37_FULLY_MATCH_BUT_BOOT_UNTESTED' if full else
                        'PARTIAL_OEM_ABI_IMPROVEMENT_NOFLASH' if better else 'ABI_NOT_IMPROVED_NOFLASH',
                        'candidate':{'module_symvers_sha256':sha(symvers),'config_sha256':sha(obj/'.config'),
                                     'image_sha256':sha(image),'vmlinux_sha256':sha(vmlinux),'dtb_sha256':sha(dtb),
                                     'qgki_counts':dict(counts),'module_layout_crc':modified.get('module_layout'),
                                     'fully_matching_37_modules':sum(m['fully_compatible'] for m in mods),
                                     'symbols_crc_changed':len(changed)},
                        'oem_vendor_abi_proven':False, 'device_boot_tested':False,'flash_allowed':False})
        result['source_modified']=False
    except Exception as e:
        result['error']=str(e)
        print('R8_FAIL_CLOSED: '+str(e),file=sys.stderr)
        raise
    finally:
        write_json(out/'R8_RESULT.json',result)
        (out/'R8_README.txt').write_text('R46-R8: ABI single-variable test. OEM module CRCs cannot be overwritten. Do not flash.\n',encoding='utf-8')
    print('R8_REAL_ARM64_CANDIDATE='+result['status']+'; ABI='+str(result['candidate']['qgki_counts'])+'; FLASH=NO')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',required=True);p.add_argument('--objout',required=True)
    p.add_argument('--r47',required=True);p.add_argument('--evidence',required=True)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    run(args)
if __name__=='__main__':
    try:main()
    except (GateError,ValueError,KeyError,OSError) as e:
        print('R8_ABI_REPAIR_CANDIDATE_BLOCKED:'+str(e),file=sys.stderr)
        sys.exit(1)
