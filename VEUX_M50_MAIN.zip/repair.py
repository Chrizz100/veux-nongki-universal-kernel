"""Apply the M50 repair to an authenticated control tree and test its actual functions."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parent
P3 = "7f97dbbff432d61bbf11cae03de257a21f1d3c74"
OPTIONS = ("UFS_WB", "CPUMAXFREQ", "DEBUG_POLICY_STATUS", "SIMTRAY_STATUS")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifest(name):
    return json.loads((ROOT / name).read_text())


def verify(source, name):
    for rel, pin in manifest(name).items():
        path = source / rel
        actual = digest(path) if path.is_file() else None
        require(actual == pin, f"{rel}: expected {pin}, found {actual}")


def apply(source):
    verify(source, "preimages.json")
    command = ["patch", "--batch", "--forward", "--fuzz=0", "-p1", "-i", str(ROOT / "stock-drivers.patch")]
    subprocess.run(command + ["--dry-run"], cwd=source, check=True)
    subprocess.run(command, cwd=source, check=True)
    verify(source, "postimages.json")


def native(source, work):
    ufs = source / "drivers/scsi/ufs"
    functions = []
    for filename, names in [
        ("ufshcd.h", ["ufshcd_is_wb_allowed", "ufshcd_wb_selector", "ufshcd_wb_get_query_index"]),
        ("ufshcd.c", ["ufshcd_wb_probe", "ufshcd_wb_ctrl", "ufshcd_wb_config"]),
    ]:
        text = (ufs / filename).read_text()
        for name in names:
            match = re.findall(r"(?m)^[\w ]+ " + name + r"\([^;{]+\)\n\{[\s\S]*?^\}", text)
            require(len(match) == 1, "Expected one definition: " + name)
            functions.extend(match)
    (work / "wb-under-test.inc").write_text("\n".join(functions))
    text = (ufs / "ufshcd.c").read_text()
    func = re.search(r"(?m)^int ufshcd_read_desc_param\([^;{]+\)\n\{[\s\S]*?^\}", text)
    require(func, "Missing descriptor reader")
    (work / "desc-under-test.inc").write_text(func.group())
    descriptor_test = work / "descriptor-test"
    subprocess.run(["cc", "-Wall", "-Wextra", "-Werror", "-O2", "-I", str(work),
                    str(ROOT / "test_desc.c"), "-o", str(descriptor_test)], check=True)
    subprocess.run([descriptor_test], check=True)
    board_functions = []
    for rel, names in [
        ("drivers/misc/simtray.c", ["simtray_status_show", "simtray_probe", "simtray_remove"]),
        ("drivers/soc/qcom/cpumaxfreq.c", ["cpumaxfreq_read"]),
        ("drivers/soc/qcom/dp_status.c", ["dp_status_proc_show"]),
    ]:
        content = (source / rel).read_text()
        for name in names:
            definition = re.findall(r"(?m)^static [\w ]+ " + name + r"\([^;{]+\)\n\{[\s\S]*?^\}", content)
            require(len(definition) == 1, "Missing board driver function: " + name)
            board_functions.extend(definition)
    (work / "board-under-test.inc").write_text("\n".join(board_functions))
    board_test = work / "board-test"
    subprocess.run(["cc", "-Wall", "-Wextra", "-Werror", "-Wno-unused-parameter", "-I", str(work),
                    str(ROOT / "test_board.c"), "-o", str(board_test)], check=True)
    subprocess.run([board_test], check=True)
    for setting in ("0", "1"):
        exe = work / ("test-wb-" + setting)
        subprocess.run(["cc", "-Wall", "-Wextra", "-Werror", "-std=gnu11", "-O2",
                        "-DCONFIG_UFS_WB=" + setting, "-I", str(work), str(ROOT / "test_wb.c"), "-o", str(exe)], check=True)
        subprocess.run([exe], check=True)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--replay", type=Path)
    args = cli.parse_args()
    with tempfile.TemporaryDirectory() as tmp:
        work = Path(tmp)
        source = work / "source"
        if args.replay:
            for rel, pin in manifest("preimages.json").items():
                obj = P3 + ":" + rel
                cmd = ["git", "-C", str(args.replay)]
                if pin is None:
                    require(subprocess.run(cmd + ["cat-file", "-e", obj], stderr=subprocess.DEVNULL).returncode != 0, "Unexpected file: " + rel)
                    continue
                path = source / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(subprocess.check_output(cmd + ["show", obj]))
        else:
            shutil.copytree(ROOT / "baseline", source)
        apply(source)
        native(source, work)


if __name__ == "__main__":
    main()
