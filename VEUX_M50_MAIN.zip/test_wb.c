/* Compile the selected functions verbatim from the patched kernel with mock UFS I/O. */
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
typedef uint8_t u8;
typedef uint32_t u32;
#define IS_ENABLED(x) (x)
#define UFS_VENDOR_SAMSUNG 0x1ce
#define UFSHCD_CAP_WB_EN 4
#define UFS_DEVICE_QUIRK_SUPPORT_EXTENDED_FEATURES 1
#define DEVICE_DESC_PARAM_EXT_UFS_FEATURE_SUP 0x4f
#define DEVICE_DESC_PARAM_WB_PRESRV_USRSPC_EN 0x53
#define DEVICE_DESC_PARAM_WB_TYPE 0x54
#define DEVICE_DESC_PARAM_WB_SHARED_ALLOC_UNITS 0x55
#define UFS_DEV_WRITE_BOOSTER_SUP (1U << 8)
#define UFS_UPIU_MAX_WB_LUN_ID 8
#define UNIT_DESC_PARAM_WB_BUF_ALLOC_UNITS 0x29
#define WB_BUF_MODE_LU_DEDICATED 0
#define WB_BUF_MODE_SHARED 1
#define dev_info(...) ((void)0)
#define dev_err(...) ((void)0)
#define dev_dbg(...) ((void)0)
enum query_opcode { UPIU_QUERY_OPCODE_SET_FLAG, UPIU_QUERY_OPCODE_CLEAR_FLAG };
enum { QUERY_FLAG_IDN_WB_EN };
struct ufs_dev_info {
	unsigned int wmanufacturerid, wspecversion, d_ext_ufs_feature_sup;
	unsigned int b_wb_buffer_type, b_presrv_uspc_en, d_wb_alloc_units, wb_dedicated_lu;
};
struct ufs_hba {
	unsigned int caps, dev_quirks;
	struct { unsigned int dev_desc; } desc_size;
	struct ufs_dev_info dev_info;
	bool wb_enabled;
};
static int allocated_lun, erroneous_lun, update_error, flags, flush, h8;
static unsigned int observed_index;
static enum query_opcode last_op;
static u32 get_unaligned_be32(const u8 *p)
{
	return (u32)p[0] << 24 | (u32)p[1] << 16 | (u32)p[2] << 8 | p[3];
}
static int ufshcd_read_unit_desc_param(struct ufs_hba *h, int lun, int offs, u8 *buf, unsigned int len)
{
	(void)h;
	assert(len == 4 && offs == UNIT_DESC_PARAM_WB_BUF_ALLOC_UNITS);
	memset(buf, lun == allocated_lun || lun == erroneous_lun, len);
	return lun == erroneous_lun ? -1 : 0;
}
static int ufshcd_query_flag_retry(struct ufs_hba *h, enum query_opcode op, int flag, u8 index, bool *value)
{
	(void)h;
	assert(flag == QUERY_FLAG_IDN_WB_EN && !value);
	flags++;
	observed_index = index;
	last_op = op;
	return update_error;
}
static int ufshcd_wb_toggle_flush_during_h8(struct ufs_hba *h, bool en)
{
	(void)h; assert(en); h8++; return 0;
}
static int ufshcd_wb_toggle_flush(struct ufs_hba *h, bool en)
{
	(void)h; assert(!en); flush++; return 0;
}
#include "wb-under-test.inc"

static int cases;
static void one_probe(unsigned int version, bool quirk, u8 mode, int lun, int bad,
		      u8 allocated_len, u8 descriptor_len, bool feature, bool allocation, bool accept)
{
	u8 buf[0x59] = { 0 };
	struct ufs_hba h = { .caps = UFSHCD_CAP_WB_EN, .dev_quirks = quirk,
			     .desc_size.dev_desc = allocated_len, .dev_info.wspecversion = version };
	buf[0] = descriptor_len;
	buf[0x51] = feature;
	buf[0x54] = mode;
	buf[0x58] = allocation;
	allocated_lun = lun;
	erroneous_lun = bad;
	ufshcd_wb_probe(&h, buf);
	assert(ufshcd_is_wb_allowed(&h) == (CONFIG_UFS_WB && accept));
	if (CONFIG_UFS_WB && accept)
		assert(ufshcd_wb_get_query_index(&h) == (mode == 0 ? lun : 0));
	cases++;
}
int main(void)
{
	unsigned int lengths[] = { 0, 0x4f, 0x53, 0x55, 0x58, 0x59 };
	unsigned int i, j;
	struct ufs_hba h = { .caps = UFSHCD_CAP_WB_EN, .dev_info.wmanufacturerid = UFS_VENDOR_SAMSUNG };
	for (i = 0; i < 6; i++)
		for (j = 0; j < 6; j++)
			one_probe(0x310, false, 1, -1, -1, lengths[i], lengths[j], true, true, i == 5 && j == 5);
	one_probe(0x210, false, 1, -1, -1, 89, 89, true, true, false);
	one_probe(0x210, true, 1, -1, -1, 89, 89, true, true, true);
	one_probe(0x220, false, 1, -1, -1, 89, 89, true, true, true);
	one_probe(0x310, false, 1, -1, -1, 89, 89, false, true, false);
	one_probe(0x310, false, 1, -1, -1, 89, 89, true, false, false);
	one_probe(0x310, false, 2, 1, -1, 89, 89, true, true, false);
	for (i = 0; i < 8; i++) {
		one_probe(0x310, false, 0, i, -1, 89, 89, true, false, true);
		one_probe(0x310, false, 0, -1, i, 89, 89, true, false, false);
	}
	one_probe(0x310, false, 0, 5, 3, 89, 89, true, false, true);
	assert(ufshcd_wb_selector(&h) == CONFIG_UFS_WB);
	h.dev_info.wmanufacturerid = 0x1ad;
	assert(ufshcd_wb_selector(&h) == 0);
	h.dev_info.wb_dedicated_lu = 3;
	update_error = -5;
	assert(ufshcd_wb_ctrl(&h, true) == (CONFIG_UFS_WB ? -5 : 0));
	assert(!h.wb_enabled);
	update_error = 0;
	assert(ufshcd_wb_ctrl(&h, true) == 0 && h.wb_enabled == CONFIG_UFS_WB);
	assert(flags == 2 * CONFIG_UFS_WB);
	assert(ufshcd_wb_ctrl(&h, true) == 0 && flags == 2 * CONFIG_UFS_WB);
	if (CONFIG_UFS_WB)
		assert(last_op == UPIU_QUERY_OPCODE_SET_FLAG && observed_index == 3);
	assert(ufshcd_wb_ctrl(&h, false) == 0 && !h.wb_enabled);
	if (CONFIG_UFS_WB)
		assert(last_op == UPIU_QUERY_OPCODE_CLEAR_FLAG);
	ufshcd_wb_config(&h);
	assert(h8 == CONFIG_UFS_WB && flush == CONFIG_UFS_WB);
	h.caps = 0;
	ufshcd_wb_config(&h);
	assert(h8 == CONFIG_UFS_WB && !ufshcd_is_wb_allowed(&h));
	printf("%d descriptor scenarios passed, selector, state, error and startup assertions passed (CONFIG_UFS_WB=%d)\n", cases, CONFIG_UFS_WB);
}
