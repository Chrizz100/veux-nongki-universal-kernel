#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef uint8_t u8;
struct ufs_hba { void *dev; };
enum desc_idn { QUERY_DESC_IDN_DEVICE, QUERY_DESC_IDN_MAX };
#define QUERY_DESC_DESC_TYPE_OFFSET 1
#define UPIU_QUERY_OPCODE_READ_DESC 0
#define GFP_KERNEL 0
#define dev_err(...) ((void)0)
static int max_size, received, declared, reply_id, failures;
static int ufshcd_map_desc_id_to_length(struct ufs_hba *h, int id, int *s)
{ (void)h; (void)id; *s=max_size; return 0; }
static void *kmalloc(int size, int flags)
{ (void)flags; return malloc(size); }
#define kfree free
static int ufshcd_query_descriptor_retry(struct ufs_hba *h, int op, int id, int index, int sel, u8 *out, int *len)
{
	(void)h; (void)op; (void)id; (void)index; (void)sel;
	memset(out, 0xA5, *len);
	out[0]=declared; out[1]=reply_id; *len=received; return failures;
}
#include "desc-under-test.inc"
int main(void)
{
	struct ufs_hba h={0};
	u8 value[100];
	int i;
	max_size=100; declared=received=100;
	for(i=0;i<100;i++) {
		value[0]=0;
		int r=ufshcd_read_desc_param(&h, QUERY_DESC_IDN_DEVICE, 0, i, value, 4);
		assert(r == (i<=96 ? 0 : -EINVAL));
		if(i>96) assert(value[0]==0);
	}
	declared=99;
	assert(ufshcd_read_desc_param(&h,0,0,96,value,4)==-EINVAL);
	declared=100; received=98;
	assert(ufshcd_read_desc_param(&h,0,0,95,value,4)==-EINVAL);
	received=1; assert(ufshcd_read_desc_param(&h,0,0,0,value,100)==-EINVAL);
	received=100; reply_id=2; assert(ufshcd_read_desc_param(&h,0,0,2,value,1)==-EINVAL);
	reply_id=0; failures=-EIO; assert(ufshcd_read_desc_param(&h,0,0,2,value,1)==-EIO);
	failures=0; max_size=0; assert(ufshcd_read_desc_param(&h,0,0,2,value,1)==-EINVAL);
	puts("100 descriptor field offsets and 6 response error cases passed");
}
