"""Build the M50 candidate in the M48 control workspace. Keep independent kernel evidence."""
import argparse
import csv
import json
import mmap
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

from repair import OPTIONS, ROOT, apply, native, require
from stock import firmware, stock_kernel

M48_CONFIG = "71d46bf2990174e456c6bdfc65f0c15c69149c6afd6228a813a7d2b4db2937de"
OBJECTS = ["drivers/scsi/ufs/ufshcd.o", "drivers/scsi/ufs/ufs-sysfs.o", "drivers/misc/simtray.o",
           "drivers/soc/qcom/cpumaxfreq.o", "drivers/soc/qcom/dp_status.o"]


def differences(before, after):
    return {k: [before.get(k), after.get(k)] for k in sorted(before.keys() | after.keys()) if before.get(k) != after.get(k)}


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def run(args, target):
    build = args.build.resolve()
    out, src = build / "candidate-out", build / "candidate-source"
    sys.path.insert(0, str(args.engine.resolve()))
    import full_build as engine
    cfg = engine.cfg
    proof = json.loads(args.control.read_text())
    original = (out / ".config").read_bytes()
    control = cfg.config_values(original)
    m48_image = engine.sha(out / engine.IMAGE)
    require(proof["release"] == engine.REL and proof["m47_handler_in_full_kernel"]
            and proof["matched_symbols"] == 1423 and proof["matched_vendor_modules"] == 37
            and proof["module_imports_checked"] == 3148
            and proof["embedded_config_proof"]["byte_identical_config_image_vmlinux"]
            and proof["embedded_config_proof"]["image_sha256"] == m48_image
            and engine.sha(out / ".config") == M48_CONFIG, "Invalid live M48 control")
    stock = stock_kernel(args.stock)
    stock_config = cfg.config_values(cfg.extract_config(stock))
    original_delta = differences(stock_config, control)
    require(len(original_delta) == 58, "Unexpected M48 to stock delta")
    records = firmware(stock)
    require(records == json.loads((ROOT / "stock-ffu-table.json").read_text()), "Stock FFU mismatch")
    write_json(target / "M50_STOCK_FFU.json", records)
    dtbs = engine.tree_dtbs(out)
    require(dtbs and dtbs == proof["m44_identical_dtbs"], "Control DTBs differ")
    commands = {row["target"]: row["invocation"] for row in json.loads((build / "R16_RESULT.json").read_text())["make_results"]}
    runner = engine.load(args.r6, engine.R6_ENGINE)
    apply(src)
    with tempfile.TemporaryDirectory() as tmp:
        native(src, Path(tmp))
    switches = [arg for option in OPTIONS for arg in ("-e", option)]
    subprocess.run(["bash", src / "scripts/config", "--file", out / ".config", *switches], check=True)
    for goal in ("olddefconfig", "Image", "dtbs", "modules"):
        cmd = commands[goal]
        require(cmd[0] == "make" and cmd.count("-C") == 1 and cmd[cmd.index("-C") + 1] == str(src)
                and cmd.count("O=" + str(out)) == 1 and cmd[-1] == goal, "Wrong control Kbuild command")
        print("Kbuild", goal, flush=True)
        log = target / (goal + ".log")
        with log.open("w") as stream:
            result = subprocess.run(cmd, env=runner.pinned_llvm_tool_env(cmd), stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            print(log.read_text(errors="replace")[-8000:], flush=True)
            result.check_returncode()
        if goal == "olddefconfig":
            effective = cfg.config_values((out / ".config").read_bytes())
            delta = differences(control, effective)
            expected = {"CONFIG_" + name: [None, "y"] for name in OPTIONS}
            require(delta == expected, "Unexpected Kconfig changes: " + str(delta))
            remaining = differences(stock_config, effective)
            require(remaining == {k: v for k, v in original_delta.items() if k not in expected}, "Unexpected remaining stock differences")
            with (target / "M50_REST_CONFIG.csv").open("w", newline="") as stream:
                writer = csv.writer(stream, delimiter=";")
                writer.writerow(["Option", "Xiaomi Stock", "M50"])
                writer.writerows((key, *value) for key, value in remaining.items())
    log = (target / "Image.log").read_text(errors="replace")
    require(all(name in log for name in OBJECTS + ["vmlinux", engine.IMAGE]), "Missing actual Kbuild compile or link evidence")
    require("ld.lld: warning:" not in log and "llvm-nm: not found" not in log, "Link/toolchain warning")
    embedded = cfg.audit_build(build, strict=False)
    require(embedded["image_sha256"] != m48_image, "M48 binary reused")
    require((out / "include/config/kernel.release").read_text().strip() == engine.REL and
            (out / "include/generated/utsrelease.h").read_text().split('"')[1] == engine.REL, "Wrong release")
    require(engine.tree_dtbs(out) == dtbs, "Device tree changed")
    required_strings = [b"Write Booster Configured", b"ufstw\0", b"enable_tw\0", b"enable_flush_en\0",
                        b"enable_autoflush_in_h8\0", b"xiaomi,simtray-status\0", b"cpumaxfreq\0", b"dp_flag\0",
                        b"androidboot.vbmeta.invalidate_on_error\0", b"androidboot.vbmeta.device\0",
                        b"AVB error handler called for", b"qcom,ufshc\0", b"qcom,ufs-phy-qmp-v4-yupik\0",
                        b"bq2589x: fault settings restore failed", ("Linux version " + engine.REL + " (").encode()]
    for name in [engine.IMAGE, "vmlinux"]:
        with (out / name).open("rb") as stream, mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as data:
            missing = [m.decode().strip("\0") for m in required_strings if data.find(m) < 0]
            require(not missing, f"{name}: missing compiled functions or driver strings: {missing}")
    raw = (out / engine.IMAGE).read_bytes()
    sym = {}
    for line in (out / "System.map").read_text().splitlines():
        address, kind, name = line.split()[:3]
        if name in ("_text", "ufshcd_wb_ctrl"):
            sym[name] = int(address, 16)
    index = sym["ufshcd_wb_ctrl"] - sym["_text"]
    require(0 <= index <= len(raw)-8 and raw[index:index+8] != bytes.fromhex("e0031f2ac0035fd6"),
            "WriteBooster still compiles as return 0")
    abi = engine.check_abi(args.abi, out / "Module.symvers", target)
    for name in ("QGKI_SYMBOLS", "QGKI_MODULES"):
        (target / ("M48_" + name + ".csv")).rename(target / ("M50_" + name + ".csv"))
    for module in json.loads((build / "M44_RESULT.json").read_text())["release"]["artifacts"]:
        if module["file"].endswith(".ko"):
            require(("vermagic=" + engine.REL + " ").encode() in (out / module["file"]).read_bytes(), "Wrong module release: " + module["file"])
    for name in [".config", "Module.symvers", "System.map", "vmlinux", engine.IMAGE]:
        shutil.copyfile(out / name, target / ("kernel.config" if name == ".config" else Path(name).name))
    write_json(target / "M50_KERNEL.json", dict(release=engine.REL, control_image_sha256=m48_image, config_delta=delta,
               remaining_stock_config_differences=len(remaining), embedded_config=embedded, device_trees=dtbs,
               compiled_objects=OBJECTS, vendor_abi=abi, device_pass=False, flash_allowed=False))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("engine", "build", "control", "stock", "r6", "abi", "result"):
        p.add_argument("--" + name, required=True, type=Path)
    args = p.parse_args()
    target = args.result.resolve()
    target.mkdir(parents=True, exist_ok=True)
    try:
        run(args, target)
    except Exception as exc:
        write_json(target / "M50_FEHLER.json", dict(error=str(exc), device_pass=False, flash_allowed=False))
        raise


if __name__ == "__main__":
    main()
