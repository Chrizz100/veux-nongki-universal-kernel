#!/system/bin/sh
# Liest Modell, Firmwarestand und GPT-Zuordnung. Keine Blockgeräte werden geöffnet.
one_line() {
    if [ -r "$1" ]; then
        value=$(cat "$1" 2>/dev/null) && [ -n "$value" ] && { printf '%s' "$value"; return; }
    fi
    printf 'unbekannt'
}
printf 'format=M50-UFS\n'
printf 'geraet=%s\n' "$(getprop ro.product.device)"
printf 'laufender_kernel=%s\n' "$(uname -r)"
for f in vendor model rev; do
    printf 'ufs_%s=%s\n' "$f" "$(one_line "/sys/class/block/sda/device/$f")"
done
for f in start size partition; do
    printf 'sda8_%s=%s\n' "$f" "$(one_line "/sys/class/block/sda8/$f")"
done
printf 'sda_logische_blockgroesse=%s\n' "$(one_line /sys/class/block/sda/queue/logical_block_size)"
label=$(sed -n 's/^PARTNAME=//p' /sys/class/block/sda8/uevent 2>/dev/null)
printf 'sda8_gpt_name=%s\n' "${label:-unbekannt}"
for f in /dev/block/by-name/*; do
    [ -L "$f" ] || continue
    dest=$(readlink -f "$f" 2>/dev/null) || continue
    [ "${dest##*/}" = sda8 ] && printf 'sda8_alias=%s\n' "${f##*/}"
done
for node in /sys/bus/platform/devices/*4804000*/ufstw /sys/class/scsi_host/host*/device/ufstw; do
    [ -d "$node" ] || continue
    for f in enable_tw enable_flush_en enable_autoflush_in_h8; do
        printf '%s=%s\n' "$f" "$(one_line "$node/$f")"
    done
    break
done
printf 'ende=M50-UFS\n'
