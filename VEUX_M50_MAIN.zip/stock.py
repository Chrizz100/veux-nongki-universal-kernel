"""Extract the exact stock IKCONFIG and authenticate the six firmware table relocations."""
import hashlib
import json
from pathlib import Path
import struct
from repair import ROOT, require

STOCK_BOOT = "ac6522e4eed55782dd2ae61362e9d345d01a1f229c87333818511d5537fa79c5"
STOCK_IMAGE = "6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b"
IMAGE_BASE = 0xffffffc010080000


def stock_kernel(path):
    boot = path.read_bytes()
    require(hashlib.sha256(boot).hexdigest() == STOCK_BOOT, "Wrong Xiaomi boot reference")
    require(boot[:8] == b"ANDROID!" and struct.unpack_from("<I", boot, 40)[0] in (3, 4), "Unknown boot header")
    length = struct.unpack_from("<I", boot, 8)[0]
    image = boot[4096:4096 + length]
    require(hashlib.sha256(image).hexdigest() == STOCK_IMAGE, "Wrong Xiaomi Image")
    return image


def firmware(image):
    inputs = json.loads((ROOT / "oem-firmware.json").read_text())
    table = image.index(b"SKhynix\0\0H9HQ54AECMMDAR\0\0\0A002\0A043\0")
    records = []
    for i in range(6):
        offset = table + i * 48
        fields = struct.unpack_from("<9s17s5s5sQI", image, offset)
        vendor, model, src, target = [s.rstrip(b"\0").decode("ascii") for s in fields[:4]]
        pointer = struct.pack("<QQ", IMAGE_BASE + offset + 36, 1027)
        require(image.count(pointer) == 1, "Expected one R_AARCH64_RELATIVE firmware reference")
        relative = struct.unpack_from("<Q", image, image.index(pointer) + 16)[0] - IMAGE_BASE
        length = fields[-1]
        require(relative >= 0 and relative + length <= len(image), "Firmware outside Image")
        sha = hashlib.sha256(image[relative:relative + length]).hexdigest()
        matches = [name for name, data in inputs.items() if data["bytes"] == length and data["sha256"] == sha]
        require(len(matches) == 1, "Stock firmware differs from the public Xiaomi payloads: " + model)
        records.append(dict(vendor=vendor, model=model, source_revision=src, target_revision=target,
                            oem_firmware=matches[0], bytes=length, sha256=sha))
    require(len({r["model"] for r in records}) == 6 and records[-1]["model"] == "H9QT1G6DN6X132", "Unexpected firmware table")
    return records
