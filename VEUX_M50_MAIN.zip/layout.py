"""Cross-check the M50 kernel against the stock boot layout after kernel evidence is archived."""
import argparse
import json
from pathlib import Path
import sys
import tempfile
from repair import require

p = argparse.ArgumentParser(description=__doc__)
for name in ("engine", "stock", "evidence", "report"):
    p.add_argument("--" + name, required=True, type=Path)
args = p.parse_args()
sys.path.insert(0, str(args.engine.resolve()))
from package_pair import make_image, unpack_m45, sha

record = json.loads((args.evidence / "M50_KERNEL.json").read_text())
raw = (args.evidence / "Image").read_bytes()
require(sha(raw) == record["embedded_config"]["image_sha256"], "Kernel evidence mismatch")
with tempfile.TemporaryDirectory() as tmp:
    m45 = unpack_m45(Path(tmp))
    candidate, page, position = make_image(m45, args.stock.read_bytes(), raw)
    info = m45.image_info(candidate)
    require(info["kernel_sha256"] == sha(raw) and info["ramdisk_sha256"] == m45.RAMDISK, "Invalid boot layout")
    args.report.write_text(json.dumps(dict(kernel_sha256=info["kernel_sha256"],
        boot_partition_bytes=len(candidate), stock_ramdisk_sha256=info["ramdisk_sha256"],
        avb_page=position, avb_page_bytes=len(page), device_pass=False, flash_allowed=False), indent=2) + "\n")
