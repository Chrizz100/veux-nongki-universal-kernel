#include <assert.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct device_node { int ignored; };
struct device { struct device_node *of_node; int kobj; void *data; };
struct device_attribute { int attr; } dev_attr_status;
struct platform_device { struct device dev; };
struct simtray_data { int status_gpio; };
struct seq_file { char text[32]; };
struct scm_desc { uint64_t ret[3]; };
struct cpufreq_policy { struct { unsigned int max_freq; } cpuinfo; };
static struct cpufreq_policy policies[4];
static bool registered, allocation_failure, reading_first;
static int gpio, create_error, gpio_value, available, acquired, returned, scm_error;
static unsigned int scm_supported, scm_flag;
static struct simtray_data storage;
#define GFP_KERNEL 0
#define PAGE_SIZE 32
#define pr_info(...) ((void)0)
#define dev_err(...) ((void)0)
#define READ_ONCE(x) (x)
#define max(a,b) ((a) > (b) ? (a) : (b))
#define for_each_possible_cpu(cpu) for ((cpu)=0; (cpu)<4; (cpu)++)
#define seq_printf(m,...) snprintf((m)->text,sizeof((m)->text),__VA_ARGS__)
#define scnprintf snprintf
#define SCM_SIP_FNID(service,cmd) (cmd)
#define TZ_DUMP_SECURITY_ALLOWS_MEM_DUMP 0x10

static void *devm_kzalloc(struct device *d, size_t size, int flag)
{ (void)d; (void)flag; assert(size==sizeof(storage)); return allocation_failure?NULL:&storage; }
static int of_get_named_gpio(struct device_node *n, const char *name, int index)
{ (void)n; assert(!strcmp(name,"status-gpio") && !index); return gpio; }
static void platform_set_drvdata(struct platform_device *p, void *data) { p->dev.data=data; }
static void *dev_get_drvdata(struct device *d) { return d->data; }
static struct platform_device *probing;
static int sysfs_create_file(int *k, int *attr)
{
	(void)k; (void)attr; assert(probing->dev.data==&storage);
	reading_first=true; registered=!create_error; return create_error;
}
static void sysfs_remove_file(int *k, int *a) { (void)k; (void)a; registered=false; }
static int gpio_get_value_cansleep(int pin) { assert(pin==gpio); return gpio_value; }
static struct cpufreq_policy *cpufreq_cpu_get(int cpu)
{ if (!(available & (1<<cpu))) return NULL; acquired++; return &policies[cpu]; }
static void cpufreq_cpu_put(struct cpufreq_policy *p) { (void)p; returned++; }
static int qcom_scm_qseecom_call(int cmd, struct scm_desc *d)
{ assert(cmd==0x10); d->ret[0]=scm_supported; d->ret[2]=scm_flag; return scm_error; }
#include "board-under-test.inc"
int main(void)
{
	struct platform_device board={0};
	struct seq_file seq={0};
	char buf[32];
	probing=&board;
	allocation_failure=true; assert(simtray_probe(&board)==-ENOMEM && !reading_first);
	allocation_failure=false; gpio=-517; assert(simtray_probe(&board)==-517 && !reading_first);
	gpio=8; create_error=-EIO; assert(simtray_probe(&board)==-EIO && reading_first && !registered);
	create_error=0; assert(simtray_probe(&board)==0 && registered);
	gpio_value=1; assert(simtray_status_show(&board.dev,NULL,buf)==2 && !strcmp(buf,"1\n"));
	gpio_value=0; assert(simtray_status_show(&board.dev,NULL,buf)==2 && !strcmp(buf,"0\n"));
	assert(simtray_remove(&board)==0 && !registered);
	available=0; assert(cpumaxfreq_read(&seq,NULL)==0 && !strcmp(seq.text,"0.0\n"));
	available=9; policies[0].cpuinfo.max_freq=1600000; policies[3].cpuinfo.max_freq=2200000;
	assert(cpumaxfreq_read(&seq,NULL)==0 && !strcmp(seq.text,"2.2\n") && acquired==2 && returned==2);
	available=1; assert(cpumaxfreq_read(&seq,NULL)==0 && !strcmp(seq.text,"1.6\n") && acquired==returned);
	scm_error=-ETIMEDOUT; assert(dp_status_proc_show(&seq,NULL)==-ETIMEDOUT);
	scm_error=3; assert(dp_status_proc_show(&seq,NULL)==-EIO);
	scm_error=0; scm_flag=0xBA; assert(dp_status_proc_show(&seq,NULL)==0 && !strcmp(seq.text,"0x0"));
	scm_supported=1; assert(dp_status_proc_show(&seq,NULL)==0 && !strcmp(seq.text,"0xA"));
	puts("14 SIM-tray, CPU-frequency and SCM status scenarios passed");
}
