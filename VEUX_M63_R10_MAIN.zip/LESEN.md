# VEUX M63-R10 für das POCO X4 Pro 5G

Die Referenz ist das originale Xiaomi-Bootabbild der Global-ROM OS1.0.12.0.TKCMIXM. R10 baut auf dem GitHub-Quellbaum von M63-R9 aus Lauf 45407528158 auf. Der genaue Ausgangsbaum, der Ergebnisbaum und die Hashes aller geänderten Dateien stehen in `source.json`.

Der AArch32-Systemaufruf `process_madvise` liegt wieder wie bei Xiaomi auf Nummer 436. Das gelinkte Image muss für sämtliche 441 nativen und 441 kompatiblen Systemaufrufe die gleichen Zielnamen wie Xiaomi liefern. Die Startaufrufe und die Abhängigkeiten der 37 Originalmodule werden ebenfalls am fertigen Kernel geprüft.

Der Goodix-Treiber meldet gescheiterte Schlaf- und Aufwachvorgänge an den Aufrufer zurück. Der Palm-Zustand wird nach erfolgreicher Übertragung gesetzt. Die beiden Goodix-Werkstatttests verwenden den Messcode aus Xiaomis öffentlichem VEUX-Quellbaum sowie die Kalibrierdatei der jeweiligen Firmware. Der DSI-Connector liest den Panelnamen aus der aktiven Verbindung. Für HBM, Flatmode und Doze verwendet er die Kommandos aus dem Device Tree. Der Schreibpfad von `disp_param` und beide Richtungen von `doze_brightness` sind implementiert. Der separate Leseweg von `disp_param`, `mipi_reg` und die Diagnosedatei `tp_data_dump` sind offen.

## GitHub Actions

`VEUX_M63_R10_MAIN.zip` liegt im Repository-Hauptverzeichnis. Der Workflow liegt in `.github/workflows/VEUX_M63_R10_DISPLAY_GOODIX_NOFLASH.yml`. Er kann auf dem Standardbranch manuell und auf `repair/m63-r10-stock-abgleich` auch durch Push der beiden Dateien starten. Er archiviert den Quellstand, die Debug-Symbole, die LLDB-Tabellen und das statisch geprüfte Boot-/AK3-Paar.

## Lokaler Bau

Voraussetzungen sind Python 3.12, Git, die Werkzeuge für Kbuild, Android-Clang r416183b, LLDB 19 und qemu-arm für das ARM-Paketierwerkzeug.

```sh
python3 -B prepare.py R9-source.zip work/src /pfad/zum/stock/boot.img
LLDB=lldb-19 bash build.sh work /pfad/zu/clang-r416183b /pfad/zum/stock/boot.img
```

Die Vorbereitung prüft das R9-Archiv und alle geänderten Quelldateien vor und nach dem Patch. Über `--from-r6 comparison` beziehungsweise `--from-r6 archive` lassen sich die vorherigen Reparaturen aus der gesicherten R6-Basis nachstellen. Die Firmware für den optionalen Kalibriertest liegt auf der authentischen Vendorpartition unter `/vendor/firmware/gtx8_limits.csv`. Der Vergleichsbericht benennt die Grenzen der statischen Diagnose und den Stand des Gerätetests.
