#!/usr/bin/env bash
set -euo pipefail
kit=$(cd "$(dirname "$0")" && pwd)
work=$(realpath "$1")
toolchain=$(realpath "$2")
stock=$(realpath "$3")
out="$work/out"
mkdir -p "$out" "$work/evidence"
python3 -B "$kit/tests/techpack_order.py" "$work/src" | tee "$work/evidence/Techpack-Reihenfolge.txt"
python3 -B "$kit/tests/touch_contract.py" "$work/src" | tee "$work/evidence/Treiber-Funktionstests.txt"
python3 -B "$kit/tests/oem_contract.py" "$work/src" | tee "$work/evidence/OEM-Funktionstests.txt"
python3 -B "$kit/tests/r10_interfaces.py" "$work/src" | tee "$work/evidence/R10-Treiberfaelle.txt"
python3 -B "$kit/tests/display_contract.py" "$work/src" "$stock" | tee "$work/evidence/DSI-Stocktest.txt"
export SOURCE_DATE_EPOCH=1794009600 KBUILD_BUILD_TIMESTAMP='Sat Nov 7 00:00:00 UTC 2026'
export KBUILD_BUILD_USER=veux-ci KBUILD_BUILD_HOST=github-actions KBUILD_BUILD_VERSION=1
if ! cmp -s "$kit/kernel.config" "$out/.config"; then
    cp "$kit/kernel.config" "$out/.config"
fi
builder=(bash "$kit/tools/kbuild.sh" "$work/src" "$out" "$toolchain")
"${builder[@]}" olddefconfig
cmp "$kit/kernel.config" "$out/.config"
"${builder[@]}" Image
python3 -B "$kit/proof.py" "$stock" "$out" "$work/evidence" --lldb "${LLDB:-lldb}" --objcopy "$toolchain/bin/llvm-objcopy"
python3 -B "$kit/pair.py" "$kit/tools" "$stock" "$out/arch/arm64/boot/Image" "$work/pair"
