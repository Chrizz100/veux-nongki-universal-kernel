"""Verify the four linked Xiaomi initializers, real attribute callbacks and IRQ paths."""
from collections import Counter
import csv
import re
import struct

from image_symbols import BASE, normal

FUSES = [
    ("sn_fuse", "sn_read", "qcom,sn-fuse", "serial_num", "sn-base"),
    ("secboot_fuse", "secboot_fuse_read", "qcom,sec-boot-fuse", "secboot_fuse_reg", "sec-boot-base"),
    ("feature_id", "feature_id_read", "qcom,cpu-feature-id", "cpu_feature_id", "cpu-feature-id"),
]
STAGES = [(3, name + "_init") for name, *_ in FUSES] + [(7, "wakeup_reason_init")]
POWER = """wakeup_reason_init wakeup_reason_pm_event clear_wakeup_reasons last_resume_reason_show
last_suspend_time_show log_irq_wakeup_reason log_threaded_irq_wakeup_reason log_suspend_abort_reason
log_abnormal_wakeup_reason pm_system_irq_wakeup pm_wakeup_pending pm_get_active_wakeup_sources
suspend_devices_and_enter suspend_prepare suspend_enter syscore_suspend dpm_prepare
__device_suspend __device_suspend_late __device_suspend_noirq gic_handle_irq handle_level_irq
handle_simple_irq handle_edge_irq handle_fasteoi_irq handle_untracked_irq irq_may_run""".split()
FUNCTIONS = POWER + [n for prefix, read, *_ in FUSES
                     for n in (prefix + "_init", prefix + "_probe", prefix + "_remove", read)]


def need(yes, message):
    if not yes:
        raise ValueError(message)


def name_at(kernel, address):
    names = kernel.by_addr.get(address,set())
    if any(name.endswith(".cfi_jt") or name.startswith("__typeid_") for name in names):
        word, = struct.unpack_from("<I", kernel.raw, address)
        if word >> 26 == 5:
            delta = word & 0x3ffffff
            if delta & 0x2000000:
                delta -= 0x4000000
            names = names | kernel.by_addr.get(address + 4*delta, set())
    return names


def check_attributes(kernel):
    raw = kernel.raw
    wanted = {"resume_reason": "last_resume_reason", "suspend_time": "last_suspend_time"}
    locations = {name: [a for a,t,n in kernel.symbol_rows
                        if normal(n) == name and t.lower() in ("d","r") and a+32 <= len(raw)]
                 for name in wanted}
    needed = {addr + offset for group in locations.values() for addr in group for offset in (0,16,24)}
    pointers = {addr:struct.unpack_from("<Q", raw, addr)[0] for addr in needed}
    if kernel.name == "Stock":
        for match in re.finditer(re.escape(struct.pack("<Q",1027)),raw):
            off = match.start()
            if off >= 8 and off + 16 <= len(raw):
                address = struct.unpack_from("<Q",raw,off-8)[0] - BASE
                if address in needed:
                    pointers[address] = struct.unpack_from("<Q",raw,off+8)[0]
    out = {}
    for variable, name in wanted.items():
        valid = []
        for a in locations[variable]:
            address, show = pointers[a]-BASE, pointers[a+16]-BASE
            mode, = struct.unpack_from("<H",raw,a+8)
            if (0 <= address < len(raw) and raw.startswith(name.encode()+b"\0",address)
                and mode == 0o444 and pointers[a+24]==0
                and name+"_show" in name_at(kernel,show)):
                valid.append((a,show))
        need(len(valid)==1,f"{kernel.name}: mode, callback or store mismatch for {name}")
        out[name] = {"mode":"0444", "attribute":hex(BASE+valid[0][0]),
                     "read_callback":hex(BASE+valid[0][1]), "write_callback":None}
    return out


def machine(kernel, targets, assembly):
    def edge(fn, *alternatives):
        result={n:targets.get(fn,{}).get(n) for n in alternatives if n in targets.get(fn,{})}
        need(result, f"{kernel.name}: missing ARM64 path {fn} -> {alternatives}")
        return result

    result = {}
    for prefix, read, compatibility, proc, resource in FUSES:
        for label in (compatibility, proc, resource):
            need(label.encode() + b"\0" in kernel.raw, f"{kernel.name}: {label}")
        registration=edge(prefix+"_init","__platform_driver_register","platform_driver_register")
        result[prefix]={"registration":registration, "probe_targets":targets[prefix+"_probe"],
                        "read_targets":targets[read], "remove_targets":targets[prefix+"_remove"]}
        edge(prefix+"_probe","platform_get_resource_byname")
        edge(prefix+"_probe","devm_ioremap")
        edge(prefix+"_probe","proc_create","proc_create_data")
        call, = edge(read,"seq_printf")["seq_printf"]
        call_pc = int(call,16) - BASE
        start,stop = kernel.ranges[read]
        loads = []
        format_addresses = []
        for pc in range(start, min(stop,call_pc),4):
            word, = struct.unpack_from("<I",kernel.raw,pc)
            if word & 0xfffffc1f == 0xb9400002 and pc >= start+4:
                prev, = struct.unpack_from("<I",kernel.raw,pc-4)
                if prev & 0xfffffc00 == 0xf9400000 and (prev & 31)==((word>>5)&31):
                    loads.append(hex(BASE+pc))
            if word & 0x9f00001f == 0x90000001:
                second, = struct.unpack_from("<I",kernel.raw,pc+4)
                if second & 0xffc003ff == 0x91000021:
                    imm = ((word>>5 & 0x7ffff)<<2) | (word>>29 & 3)
                    if imm & 0x100000:
                        imm -= 0x200000
                    format_addresses.append(((BASE+pc)&~4095)+(imm<<12)+(second>>10&4095)-BASE)
        fmt = b"0x%08x\n\0" if prefix=="sn_fuse" else b"0x%x\n\0"
        need(loads and all(int(pc,16)-BASE in assembly for pc in loads), f"{kernel.name}: hardware register load {read}")
        need(any(kernel.raw.startswith(fmt,a) for a in format_addresses if a>=0), f"{kernel.name}: output format {read}")
        table = kernel.symbols[prefix + "_match"]
        need(kernel.raw.startswith(compatibility.encode()+b"\0",table+64), f"{kernel.name}: OF match {prefix}")
        result[prefix].update(mmio_reads=loads, output_format=fmt[:-1].decode(),
                              device_tree_compatible=compatibility, resource=resource)
        if kernel.name != "Stock":
            edge(prefix+"_remove","proc_remove")
    result["wake_attributes"]=check_attributes(kernel)
    guard = kernel.symbols["msm_show_resume_irq_mask"]
    need(guard < len(kernel.raw) and struct.unpack_from("<I",kernel.raw,guard)[0]==1,
         f"{kernel.name}: IRQ reporting default")
    result["IRQ_mask"] = {"address":hex(BASE+guard), "initial_value":1}
    key_paths = {
        "irq":edge("pm_system_irq_wakeup","log_irq_wakeup_reason"),
        "power_notifier":edge("wakeup_reason_pm_event","clear_wakeup_reasons"),
        "pending_abort":edge("pm_wakeup_pending","log_suspend_abort_reason"),
        "syscore_abort":edge("syscore_suspend","log_suspend_abort_reason"),
        "device_prepare_abort":edge("dpm_prepare","log_suspend_abort_reason"),
        "GIC_abnormal": {fn:calls["log_abnormal_wakeup_reason"] for fn,calls in targets.items()
                         if fn.split("@")[0] == "gic_handle_irq" and "log_abnormal_wakeup_reason" in calls},
    }
    need(key_paths["GIC_abnormal"], f"{kernel.name}: GICv3 abnormal wake IRQ")
    for fn in ("__device_suspend","__device_suspend_late","__device_suspend_noirq"):
        key_paths[fn]=edge(fn,"log_suspend_abort_reason")
    # Clang can inline irq_may_run into individual handlers or keep one copy.
    bad_irq={fn:targets[fn]["log_abnormal_wakeup_reason"] for fn in
             ("irq_may_run","handle_level_irq","handle_simple_irq","handle_untracked_irq",
              "handle_fasteoi_irq","handle_edge_irq") if "log_abnormal_wakeup_reason" in targets.get(fn,{})}
    need(bad_irq,f"{kernel.name}: abnormal IRQ handler")
    key_paths["abnormal_irq"]=bad_irq
    suspend = [(fn,targets[fn]) for fn in ("suspend_prepare","suspend_enter","suspend_devices_and_enter")
               if fn in targets]
    need(any("log_suspend_abort_reason" in calls for _,calls in suspend), "system suspend abort")
    need(any("clear_wakeup_reasons" in calls for _,calls in suspend)
         or "clear_wakeup_reasons" in targets.get("s2idle_loop",{}), "idle cycle reset")
    result["ARM64_call_sites"]=key_paths
    result["checked_words"]=sum(end-start for key,(start,end) in kernel.ranges.items() if key in FUNCTIONS)//4
    return result


def initcalls(stock, candidate, references, old_csv):
    def simplify(seq):
        return [(level,re.sub(r"\.\d+$","",name)) for level,name in seq]
    def sequence(path):
        with path.open() as inp:
            return [(int(r["Stufe"]),r["Name"]) for r in csv.DictReader(inp)]
    r8 = sequence(old_csv)
    before = simplify(r8)
    after = simplify(candidate)
    original=simplify(stock)
    for entry in STAGES:
        need(entry not in before and original.count(entry)==after.count(entry)==1, f"Initializer {entry}")
    need([item for item in after if item not in STAGES]==before, "existing R8 initializer order")
    for start, size in [(STAGES[0],3),(STAGES[-1],1)]:
        i=original.index(start); j=after.index(start)
        need(original[i-1:i+size+1]==after[j-1:j+size+1],f"Stock neighbors of {start}")
    shared=Counter(original)&Counter(simplify(references["Diag10"]["initcalls"]))
    need(not (Counter(original)-Counter(after)), "missing Stock initializer")
    need(not (shared-Counter(after)), "missing common historical initializer")
    need(len(r8)==1197 and len(candidate)==1201,"R8/R10 table counts")
    primary = (6,"msm_vidc_init")
    for series in (stock,candidate):
        at=series.index(primary)
        need(series[at+1]==(6,"msm_drm_register"),"video/display order")
    return {"Stock":len(stock),"R8":len(r8),"R10":len(candidate),
            "previous_R8_order_retained":True,"stock_initcalls_with_same_stage_and_normalized_name":len(stock),
            "historical_common_same_stage_normalized":sum(shared.values()),
            "restored":[{"stage":level,"function":name,"Stock_position":stock.index((level,name))+1,
                         "R10_position":candidate.index((level,name))+1} for level,name in STAGES]}
