#!/usr/bin/env python3
"""Negative-focused R39 tests. No network, device writes, shell or flash operations."""
import csv
import io
import json
from pathlib import Path
import shutil
import struct
import sys
import tempfile
import unittest
from unittest import mock
import zipfile

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'scripts'))
import r39_gate as gate


def r20_fdt():
    with zipfile.ZipFile(BASE/'evidence/VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip') as z:
        return z.read('evidence/R20_VEUX.dtb')


def reserved(path,address,size,flags='no-map',reference_count=1,state='STATIC_REG'):
    return {'path':path,'label':path.rsplit('/',1)[-1].split('@',1)[0],
      'address':address,'size':size,'flags':flags,'state':state,
      'reference_count':reference_count,'references':[],'reg_ranges':1,'declared_size':False}


class Evidence(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.r38,cls.bound,cls.vendors,cls.fdt,cls.capture,cls.deployed,cls.variants=gate.verify_original_reports(BASE)
        cls.realr20=r20_fdt()
        cls.nodes,cls.resheader=gate.parse_fdt_selected(cls.realr20)
        cls.res=gate.extract_reserved(cls.nodes)
    def test_01_r39_manifest(self): self.assertEqual(gate.verify_package(BASE)['schema'],'VEUX_R39_IMMUTABLE_READONLY_PACKAGE_V1')
    def test_02_r30_pin(self): self.assertEqual(gate.PINS['evidence/VEUX_R30_ABI_ORIGINALMODULE_NACHWEIS_20261023.zip'],gate.digest((BASE/'evidence/VEUX_R30_ABI_ORIGINALMODULE_NACHWEIS_20261023.zip').read_bytes()))
    def test_03_r38_main_pin(self): self.assertEqual(gate.PINS['evidence/VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip'],gate.digest((BASE/'evidence/VEUX_R38_OVERLAY_VENDOR_ABI_MAIN.zip').read_bytes()))
    def test_04_r38_report_pin(self): self.assertEqual(gate.PINS['evidence/VEUX_R38_RUN_40080527188_ERGEBNIS.zip'],gate.digest((BASE/'evidence/VEUX_R38_RUN_40080527188_ERGEBNIS.zip').read_bytes()))
    def test_05_r38_nodes(self): self.assertEqual((self.r38['stock_merged_nodes'],self.r38['r20_merged_nodes']),(2652,2200))
    def test_06_bound_count(self): self.assertEqual(len(self.bound),503)
    def test_07_vendor_count(self): self.assertEqual(len(self.vendors),218)
    def test_08_fdt_diff_count(self): self.assertEqual(len(self.fdt),499)
    def test_09_crc_match(self): self.assertEqual(self.r38['vendor_crc_matches'],6960)
    def test_10_crc_mismatch(self): self.assertEqual(self.r38['vendor_crc_mismatches'],7653)
    def test_11_crc_missing(self): self.assertEqual(self.r38['vendor_missing_exports'],35)
    def test_12_r35_all_matched(self): self.assertEqual(self.r38['r35_65_after_overlay'],{'COMPAT_OVERLAP_AND_STATUS_MATCH':65})
    def test_13_r20_base_parses(self): self.assertEqual(len(self.nodes),1829)
    def test_14_r20_base_reserved(self): self.assertGreaterEqual(len(self.res),20)
    def test_15_r20_base_cdsp(self): self.assertEqual(self.res['/reserved-memory/cdsp@88700000']['address'],0x89300000)
    def test_16_r20_base_gpu(self): self.assertEqual(self.res['/reserved-memory/gpu_micro_code@8aa1a000']['address'],0x8b61a000)
    def test_17_r20_base_no_duplicate(self): self.assertEqual(len(self.nodes),len(set(self.nodes)))
    def test_18_r20_ufs_built(self): self.assertEqual(self.r38['ufs_pmic_27_exact_runtime_matches_stock_and_r20'],True)
    def test_19_r30_ids(self): self.assertEqual(self.capture['loaded_build_ids']['rmnet_shs'],'52967b0490abea75')
    def test_20_r30_loadpath_unproven(self): self.assertIs(self.capture['conclusion']['actual_loading_path_proven'],False)
    def test_21_brene_false(self): self.assertIs(self.r38['brene_changed'],False)
    def test_22_boot_false(self): self.assertIs(self.r38['boot_ready'],False)
    def test_23_no_flash(self): self.assertIs(self.r38['flash_allowed'],False)
    def test_24_reg_cells(self): self.assertEqual(gate.u32(self.nodes['/']['#address-cells'],0),2)
    def test_25_memreserve_read(self): self.assertIsInstance(self.resheader,list)
    def test_26_r30_source_2ef0(self): self.assertTrue(self.deployed['modules']['rmnet_offload']['matches_r30_loaded_build_id'])
    def test_27_r38_nested_original_sha(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);gate.safe_extract_r38(BASE,path)
            self.assertEqual((path/'evidence/R20_VEUX.dtb').stat().st_size,275689)


class Adversarial(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.raw=r20_fdt()
    def test_28_bad_magic(self):
        b=bytearray(self.raw);b[0]=0
        with self.assertRaisesRegex(ValueError,'BAD_HEADER'):gate.parse_fdt_selected(bytes(b))
    def test_29_truncated(self):
        with self.assertRaisesRegex(ValueError,'SIZE|BAD_HEADER'):gate.parse_fdt_selected(self.raw[:28])
    def test_30_too_long(self):
        with self.assertRaisesRegex(ValueError,'SIZE'):gate.parse_fdt_selected(b'\0'*(8_000_001))
    def test_31_unsupported_version(self):
        b=bytearray(self.raw);struct.pack_into('>I',b,20,44)
        with self.assertRaisesRegex(ValueError,'BAD_HEADER'):gate.parse_fdt_selected(bytes(b))
    def test_32_invalid_strings_offset(self):
        b=bytearray(self.raw);struct.pack_into('>I',b,12,len(b)+2)
        with self.assertRaisesRegex(ValueError,'BAD_HEADER'):gate.parse_fdt_selected(bytes(b))
    def test_33_invalid_structure_size(self):
        b=bytearray(self.raw);struct.pack_into('>I',b,36,len(b)+40)
        with self.assertRaisesRegex(ValueError,'BAD_HEADER'):gate.parse_fdt_selected(bytes(b))
    def test_34_zero_byte_reservation(self):
        n={'/':{'#address-cells':struct.pack('>I',2),'#size-cells':struct.pack('>I',2)},
           '/reserved-memory':{},'/reserved-memory/x@1000':{'reg':struct.pack('>4I',0,0x1000,0,0)}}
        self.assertEqual(gate.extract_reserved(n)['/reserved-memory/x@1000']['state'],'REG_ZERO_OR_OVERFLOW')
    def test_35_bad_reservation_size(self):
        n={'/reserved-memory/x@1000':{'reg':b'bad'},'/reserved-memory':{},'/':{}}
        self.assertEqual(gate.extract_reserved(n)['/reserved-memory/x@1000']['state'],'REG_PARSE_ERROR')
    def test_36_bad_cells(self):
        n={'/reserved-memory':{'#address-cells':struct.pack('>I',4)}}
        with self.assertRaisesRegex(ValueError,'ADDRESS_CELLS'):gate.extract_reserved(n)
    def test_37_compat_node_not_cdev(self):
        self.assertEqual(gate.inspect_gpu_cooling({'/soc/x':{}},{'/soc/x':{}}),[])
    def test_38_unknown_classification_detected(self):
        data=[{'classification':'OTHER','stock_compatible':'x','path':'/soc/x','stock_drivers':'x','r20_compatible':'', 'stock_status':'ok','r20_status':'MISSING'}]*9
        self.assertTrue(all(x['interpretation'].startswith('UNCLASSIFIED') for x in gate.r38_exceptions(data)))
    def test_39_wrong_exception_count(self):
        with self.assertRaisesRegex(ValueError,'NINE'):gate.r38_exceptions([])
    def test_40_unsigned_dynamic(self):
        s={'/reserved-memory/x':reserved('/reserved-memory/x',None,None,state='NO_REG_DYNAMIC_OR_UNKNOWN')}
        self.assertEqual(gate.reservations_report(s,s)[0]['comparison'],'INDETERMINATE_NONSTATIC_REG')
    def test_41_overlap_detected(self):
        s={'a':reserved('/reserved-memory/a',0x1000,0x200),
           'b':reserved('/reserved-memory/b',0x1100,0x200)}
        r=gate.detect_overlaps('X',s)
        self.assertEqual((len(r),r[0]['overlap_bytes']),(1,0x100))
    def test_42_touch_is_not_overlap(self):
        s={'a':reserved('/reserved-memory/a',0x1000,0x200),
           'b':reserved('/reserved-memory/b',0x1200,0x200)}
        self.assertEqual(gate.detect_overlaps('X',s),[])
    def test_43_identical_range(self):
        s={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        self.assertEqual(gate.reservations_report(s,s)[0]['comparison'],'PHYSICAL_RANGE_AND_FLAGS_MATCH')
    def test_44_relocated_equal_size(self):
        a={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        b={'b':reserved('/reserved-memory/cdsp@2000',0x2000,0x200)}
        self.assertEqual(gate.reservations_report(a,b)[0]['comparison'],'RELOCATED_SAME_SIZE')
    def test_45_size_changed(self):
        a={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        b={'b':reserved('/reserved-memory/cdsp@1000',0x1000,0x400)}
        self.assertEqual(gate.reservations_report(a,b)[0]['comparison'],'SIZE_OR_FLAGS_DIFFER')
    def test_46_flags_changed(self):
        a={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        b={'b':reserved('/reserved-memory/cdsp@1000',0x1000,0x200,flags='reusable')}
        self.assertEqual(gate.reservations_report(a,b)[0]['comparison'],'SIZE_OR_FLAGS_DIFFER')
    def test_47_only_stock(self):
        a={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        self.assertEqual(gate.reservations_report(a,{})[0]['comparison'],'STOCK_ONLY')
    def test_48_only_r20(self):
        a={'a':reserved('/reserved-memory/cdsp@1000',0x1000,0x200)}
        self.assertEqual(gate.reservations_report({},a)[0]['comparison'],'R20_ONLY')
    def test_49_vendor_names_not_file_proof(self):
        sample={'modules':{'rmnet_shs':{}}}
        rows=[{'vendor_file_path':'/vendor/lib/modules/rmnet_shs.ko','load_list':'x',
              'historical_matched':44,'historical_crc_mismatched':55,'historical_exports_absent':1,
              'historical_total_imports':100,'runtime_module_name_seen':'True'}]
        self.assertEqual(gate.historic_modules(rows,sample)[0]['runtime_file_provenance'],'NO_PROOF_FROM_VENDOR_PATH')
    def test_50_missing_tool_closed(self):
        with mock.patch('r39_gate.shutil.which',return_value=None):
            with self.assertRaisesRegex(ValueError,'NOT_INSTALLED'):
                gate.run_merge(Path('/no'),Path('/no'),Path('/no'))
    def test_51_output_csv_no_extra_fields(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'out.csv'
            gate.write_csv(p,[{'x':'a','extra':'b'}],['x'])
            self.assertEqual(p.read_text(),'x\na\n')
    def test_52_bad_manifest_hash(self):
        with tempfile.TemporaryDirectory() as td:
            from copy import deepcopy
            man=json.loads((BASE/'MANIFEST_SHA256.json').read_text())
            man['files']['README_ZUERST_DE.txt']['sha256']='0'*64
            self.assertNotEqual(man['files']['README_ZUERST_DE.txt']['sha256'],gate.digest((BASE/'README_ZUERST_DE.txt').read_bytes()))
    def test_53_readonly_requirement(self):
        text=(BASE/'scripts/r39_gate.py').read_text()
        self.assertNotIn('fastboot flash',text)
        self.assertNotIn('dd if=',text)
        self.assertNotIn('magiskboot repack',text)
    def test_54_no_source_edits(self):
        text=(BASE/'scripts/r39_gate.py').read_text()
        self.assertNotIn('git apply',text)
        self.assertNotIn('git reset --hard',text)
    def test_55_report_schema(self):self.assertIn('PINNED_MEMORY_RESERVATION',gate.SCHEMA)
    def test_56_root_archive_no_boot(self):self.assertTrue(all(not x.endswith(('.img','.ko','.dtbo','.dtb')) for x in gate.COLUMNS))
    def test_57_unsupported_loaded_proven(self):
        row=gate.historic_modules([{'vendor_file_path':'/vendor/lib/modules/abc.ko',
             'load_list':'x','historical_matched':0,'historical_crc_mismatched':1,
             'historical_exports_absent':0,'historical_total_imports':1,'runtime_module_name_seen':'False'}],
             {'modules':{}})[0]
        self.assertIn('HISTORIC_CRC_ONLY',row['assessment'])
    def test_58_mem_size_as_int(self):self.assertEqual(gate.hex64(0x89300000),'0x0000000089300000')
    def test_59_empty_prop(self):self.assertEqual(gate.prop_str(None),'')
    def test_60_runtime_probe_never(self):
        self.assertIs(gate.verify_original_reports(BASE)[0]['r20_live_driver_probe_proven'],False)

if __name__=='__main__':unittest.main()
