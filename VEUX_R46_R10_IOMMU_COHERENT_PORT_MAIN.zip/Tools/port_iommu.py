#!/usr/bin/env python3
"""VEUX R46-R10: pin & stage a coherent Xiaomi QCOM lazy-IOMMU/ION source port.

This deliberately never edits the target checkout. It does not compile the
kernel, modify CRCs, modify kernel release, or approve flashing.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Mapping

DONOR_REPO = "dereference23/kernel_xiaomi_sm6375"
DONOR_COMMIT = "b2b7a3bbc36d120ee523ebc8d68e0f13a97df632"
XIAOMI_REPO = "MiCode/Xiaomi_Kernel_OpenSource"
XIAOMI_COMMIT = "61397e524093d1ccb94769b5460825e2eaf8871e"
STOCK_RELEASE_REFERENCE = "5.4.274-qgki-g82179e362f33"

# git-blob hashes confirmed from the corresponding pinned GitHub blobs.
# All six files are one dependency group: device, its init, QCOM mapping API,
# the mapping implementation, the ION client, and the ION data structure.
PINS: dict[str, tuple[str, str]] = {
    "include/linux/device.h": (
        "3937c1c06f9c152e6272743d1536303b9eea09df",
        "dfd3303baaa74243cd2137e1abbf563136785837"),
    "drivers/base/core.c": (
        "777cfffd26336bb8f1a7edf06e5d8a30fb914133",
        "be17a30b533f147554080dd2ba2c86b94bb6caba"),
    "include/linux/msm_dma_iommu_mapping.h": (
        "8db505249af57fb2207f54fac01d693f6baa6ce0",
        "6a0c89292f4b6bfd7753f1ab33151ed9c8f325bd"),
    "drivers/iommu/msm_dma_iommu_mapping.c": (
        "885a87f839e22ed52c5f09a0ce8a8d778324397c",
        "a23aa9a48c40ceb98ac30c798cbd5ef0a86317d6"),
    "include/linux/ion.h": (
        "256da705bffe8b6f2450a1952fc677d429ec30dc",
        "80c6fdeb48225109dc4fa1a99e9d04309ed32518"),
    "drivers/staging/android/ion/heaps/msm_ion_dma_buf.c": (
        "20909a97a7dbd5599bb3613d234bc1cc691d4f8c",
        "aba5c4d401db8249ea9cf9a9c3d7dc1eaa9344b2"),
}
# Stable, unchanged external IOMMU client in both pinned lines.
DISPLAY = "techpack/display/msm/msm_smmu.c"
DISPLAY_SHA = "53f5f926560a2d7c539843e33e72a0a9b37f1367"

class PortBlocked(RuntimeError):
    pass


def git_blob_sha(raw: bytes) -> str:
    prefix = f"blob {len(raw)}\0".encode()
    return hashlib.sha1(prefix + raw).hexdigest()


def hash_file(path: pathlib.Path) -> str:
    return git_blob_sha(path.read_bytes())


def git_commit(path: pathlib.Path) -> str:
    p = subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"],
                       capture_output=True, text=True, check=False)
    if p.returncode:
        raise PortBlocked(f"NOT_A_GIT_CHECKOUT:{path}")
    return p.stdout.strip()


def read_locked(root: pathlib.Path, rel: str, expected: str) -> bytes:
    path = root / rel
    if not path.is_file() or path.is_symlink():
        raise PortBlocked(f"FILE_MISSING_OR_SYMLINK:{root.name}/{rel}")
    raw = path.read_bytes()
    seen = git_blob_sha(raw)
    if seen != expected:
        raise PortBlocked(f"SOURCE_BLOB_DRIFT:{rel}:{seen}!={expected}")
    return raw


def trim_c(s: str) -> str:
    return re.sub(r"\s+", "", re.sub(r"//[^\n]*", "", re.sub(r"/\*[\s\S]*?\*/", "", s)))


def struct_body(s: str, name: str) -> str:
    clean = re.sub(r"//[^\n]*", "", re.sub(r"/\*[\s\S]*?\*/", "", s))
    m = re.search(r"\bstruct\s+" + re.escape(name) + r"\s*\{", clean)
    if m is None:
        raise PortBlocked(f"MISSING_STRUCT:{name}")
    depth = 0
    for i in range(m.end() - 1, len(clean)):
        if clean[i] == "{":
            depth += 1
        elif clean[i] == "}":
            depth -= 1
            if depth == 0:
                return trim_c(clean[m.start():i+1])
    raise PortBlocked(f"UNCLOSED_STRUCT:{name}")


def verified_six(donor: pathlib.Path, xiaomi: pathlib.Path,
                 stock: pathlib.Path, locks: Mapping[str, tuple[str, str]],
                 display_sha: str) -> tuple[dict[str, tuple[bytes, bytes]], dict]:
    """Pure validation used by tests; CLI pins are immutable constants."""
    files = {}
    for rel, (orig_sha, xiaomi_sha) in locks.items():
        before = read_locked(donor, rel, orig_sha)
        after = read_locked(xiaomi, rel, xiaomi_sha)
        if before == after:
            raise PortBlocked(f"NO_ACTUAL_SOURCE_DELTA:{rel}")
        files[rel] = before, after
    donor_display = read_locked(donor, DISPLAY, display_sha)
    xiaomi_display = read_locked(xiaomi, DISPLAY, display_sha)
    if b"msm_dma_unmap_all_for_dev" not in donor_display or donor_display != xiaomi_display:
        raise PortBlocked("DISPLAY_DEPENDENT_SOURCE_DRIFT")
    old_device = files["include/linux/device.h"][0].decode()
    new_device = files["include/linux/device.h"][1].decode()
    stock_device_file = stock / "include/linux/device.h"
    stock_header_file = stock / "include/linux/msm_dma_iommu_mapping.h"
    if hashlib.sha256(stock_device_file.read_bytes()).hexdigest() != "dc28c43819628f359cc3776b53a4b0a09e4cc99e321d08d25b23ab81df6eb027":
        raise PortBlocked("STOCK_DEVICE_HEADER_SHA256_DRIFT")
    if hashlib.sha256(stock_header_file.read_bytes()).hexdigest() != "9394f06ede665497ab41652e354683e384ee78bc1c39f2ff2659ea39f6638a54":
        raise PortBlocked("STOCK_DMA_HEADER_SHA256_DRIFT")
    stock_device = stock_device_file.read_text()
    if struct_body(new_device, "device") != struct_body(stock_device, "device"):
        raise PortBlocked("XIAOMI_DEVICE_STRUCT_NOT_EXACTLY_STOCK")
    if "iommu_map_list" not in struct_body(old_device, "device") or "iommu_map_lock" not in struct_body(old_device, "device"):
        raise PortBlocked("DONOR_IOMMU_FIELDS_ABSENT")
    if "iommu_map_list" in struct_body(new_device, "device") or "iommu_map_lock" in struct_body(new_device, "device"):
        raise PortBlocked("NEW_IOMMU_DEVICE_FIELDS_STILL_PRESENT")
    for rel in ("drivers/base/core.c", "drivers/iommu/msm_dma_iommu_mapping.c"):
        if re.search(r"\b(?:iommu_map_list|iommu_map_lock)\b", files[rel][1].decode()):
            raise PortBlocked(f"ORPHANED_OLD_IOMMU_FIELD:{rel}")
    old_header = files["include/linux/msm_dma_iommu_mapping.h"][0].decode()
    new_header = files["include/linux/msm_dma_iommu_mapping.h"][1].decode()
    stock_header = stock_header_file.read_text()
    if not re.search(r"msm_dma_buf_freed\s*\(\s*struct msm_iommu_data\s*\*", old_header):
        raise PortBlocked("DONOR_OLD_DMA_API_NOT_FOUND")
    for kind, data in (("XI",new_header),("STOCK",stock_header)):
        if not re.search(r"msm_dma_buf_freed\s*\(\s*void\s*\*\s*buffer\s*\)", data):
            raise PortBlocked(f"{kind}_STOCK_DMA_SIGNATURE_BAD")
        if not re.search(r"int\s+msm_dma_unmap_all_for_dev\s*\(\s*struct\s+device\s*\*\s*dev\s*\)", data):
            raise PortBlocked(f"{kind}_DMA_UNMAP_SIGNATURE_BAD")
    if re.search(r"\bstruct\s+msm_iommu_data\s+\w+\s*;",files["include/linux/ion.h"][1].decode()):
        raise PortBlocked("XI_ION_DATA_STILL_EMBEDS_OLD_TYPE")
    if "msm_dma_buf_freed(buffer)" not in re.sub(r"\s+", "", files["drivers/staging/android/ion/heaps/msm_ion_dma_buf.c"][1].decode()):
        raise PortBlocked("XI_ION_FREE_CALL_MISSING")
    if not ("msm_dma_buf_freed" in files["drivers/iommu/msm_dma_iommu_mapping.c"][1].decode()):
        raise PortBlocked("XI_DMA_IMPL_MISSING")
    report = {
        "status": "XIAOMI_5_4_134_SIX_FILE_OEM_IOMMU_SOURCE_STAGED_NOFLASH",
        "stock_release_reference": STOCK_RELEASE_REFERENCE,
        "pin_donor_commit": DONOR_COMMIT,
        "pin_xiaomi_commit": XIAOMI_COMMIT,
        "checks": ["six_source_blob_pins","external_display_blob_pin",
                   "stock_device_struct_identity", "matched_ION_DMA_API",
                   "old_IOMMU_fields_removed_as_group"],
        "six_files": sorted(files), "changes": 6,
        "kernel_compiled": False, "vendor_abi_proven": False,
        "flash_allowed": False, "kernel_release_spoofed": False,
    }
    return files, report


def stage(donor: pathlib.Path, xiaomi: pathlib.Path, stock: pathlib.Path,
          out: pathlib.Path):
    if out.exists():
        raise PortBlocked("OUTPUT_EXISTS_NO_OVERWRITE")
    if donor.resolve() == xiaomi.resolve() or donor.resolve() == out.resolve() or xiaomi.resolve() == out.resolve():
        raise PortBlocked("SOURCE_OVERWRITE_DENIED")
    if git_commit(donor) != DONOR_COMMIT or git_commit(xiaomi) != XIAOMI_COMMIT:
        raise PortBlocked("SOURCE_COMMIT_DRIFT")
    files, report = verified_six(donor, xiaomi, stock, PINS, DISPLAY_SHA)
    # No source writes until all validation succeeds.
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="veux-r10-staged-",dir=out.parent))
    try:
        for rel,(before,after) in files.items():
            dst=tmp/"overlay"/rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(after)
            diff=''.join(difflib.unified_diff(
                before.decode().splitlines(keepends=True),
                after.decode().splitlines(keepends=True),
                fromfile=f"a/{rel}",tofile=f"b/{rel}"))
            d=tmp/"diffs"/(rel+".patch")
            d.parent.mkdir(parents=True, exist_ok=True)
            d.write_text(diff)
        report["file_git_blob_sha1"] = {p:{"donor":a,"xiaomi":b}
                                            for p,(a,b) in PINS.items()}
        (tmp/"SOURCE_PORT_RESULT.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
        (tmp/"NOFLASH_README.txt").write_text(
            "R46-R10 OEM-Quelle: staging only, no kernel compilation, no ABI proof.\n"
            "Six pinned Xiaomi 5.4.134 files are present as a coherent set;\n"
            "do not flash or apply to a device. Backport to 5.4.274\n"
            "must pass a real compiler and QGKI 37-module CRC audit.\n")
        tmp.rename(out)
    except BaseException:
        shutil.rmtree(tmp,ignore_errors=True)
        raise
    return report


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--donor",type=pathlib.Path,required=True)
    p.add_argument("--xiaomi",type=pathlib.Path,required=True)
    p.add_argument("--stock-headers",type=pathlib.Path,required=True)
    p.add_argument("--out",type=pathlib.Path,required=True)
    a=p.parse_args(argv)
    try:
        r=stage(a.donor,a.xiaomi,a.stock_headers,a.out)
    except (PortBlocked, OSError, UnicodeError) as e:
        print("R10_FAIL_CLOSED:"+str(e),file=sys.stderr)
        return 1
    print("R10_SOURCE_PORT_STAGED=PASS; FILES="+str(r["changes"])+"; BUILD=NO; ABI=NO; FLASH=NO")
    return 0

if __name__ == "__main__":
    sys.exit(main())
