import hashlib
import json
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'Tools'))
import port_iommu as p

STOCK = ROOT / 'References' / 'stock_headers'


def init_fixture(base):
    donor, xiaomi = base/'donor', base/'xiaomi'
    base_device=(STOCK/'include/linux/device.h').read_bytes()
    base_api=(STOCK/'include/linux/msm_dma_iommu_mapping.h').read_bytes()
    before={
        'include/linux/device.h':base_device.replace(b'struct device {', b'struct device {\nstruct list_head iommu_map_list;\nstruct mutex iommu_map_lock;'),
        'drivers/base/core.c':b'void device_initialize(struct device *dev) { INIT_LIST_HEAD(&dev->iommu_map_list); mutex_init(&dev->iommu_map_lock); }',
        'include/linux/msm_dma_iommu_mapping.h':b'void msm_dma_buf_freed(struct msm_iommu_data *data);',
        'drivers/iommu/msm_dma_iommu_mapping.c':b'void kernel(struct device *dev) { x=dev->iommu_map_list; x=dev->iommu_map_lock; }',
        'include/linux/ion.h':b'struct ion_buffer { struct msm_iommu_data iommu_data; };',
        'drivers/staging/android/ion/heaps/msm_ion_dma_buf.c':b'msm_dma_buf_freed(&buffer->iommu_data);'
    }
    after={
        'include/linux/device.h':base_device,
        'drivers/base/core.c':b'void device_initialize(struct device *dev) { /* no old IOMMU fields */ }',
        'include/linux/msm_dma_iommu_mapping.h':base_api,
        'drivers/iommu/msm_dma_iommu_mapping.c':b'void msm_dma_buf_freed(void *buffer) { (void)buffer; }',
        'include/linux/ion.h':b'struct ion_buffer { void *private_data; };',
        'drivers/staging/android/ion/heaps/msm_ion_dma_buf.c':b'void release(void *buffer){ msm_dma_buf_freed(buffer); }'
    }
    display=b'void smmu(){msm_dma_unmap_all_for_dev(client->dev);}'
    for root,files in [(donor,before),(xiaomi,after)]:
        for rel,data in {**files,p.DISPLAY:display}.items():
            f=root/rel; f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
    locks={rel:(p.git_blob_sha(before[rel]),p.git_blob_sha(after[rel])) for rel in before}
    return donor,xiaomi,locks,p.git_blob_sha(display)


class PortTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)
        self.donor,self.xi,self.locks,self.display=init_fixture(self.root)

    def checked(self):
        return p.verified_six(self.donor,self.xi,STOCK,self.locks,self.display)

    def test_01_full_six_file_staging(self):
        files,result=self.checked()
        self.assertEqual(result['changes'],6)
        self.assertFalse(result['flash_allowed'])
        self.assertFalse(result['vendor_abi_proven'])
        self.assertFalse(result['kernel_compiled'])
        self.assertEqual(set(files),set(p.PINS))

    def test_02_every_donor_blob_tamper_rejected(self):
        for rel in p.PINS:
            with self.subTest(rel=rel):
                f=self.donor/rel;original=f.read_bytes();f.write_bytes(original+b' ')
                with self.assertRaisesRegex(p.PortBlocked,'SOURCE_BLOB_DRIFT'):
                    self.checked()
                f.write_bytes(original)

    def test_03_every_xiaomi_blob_tamper_rejected(self):
        for rel in p.PINS:
            with self.subTest(rel=rel):
                f=self.xi/rel;original=f.read_bytes();f.write_bytes(original+b' ')
                with self.assertRaisesRegex(p.PortBlocked,'SOURCE_BLOB_DRIFT'):
                    self.checked()
                f.write_bytes(original)

    def test_04_missing_file_fail_closed(self):
        (self.xi/'include/linux/ion.h').unlink()
        with self.assertRaisesRegex(p.PortBlocked,'FILE_MISSING'):
            self.checked()

    def test_05_symlink_source_rejected(self):
        f=self.donor/'include/linux/ion.h';f.unlink();f.symlink_to(self.xi/'include/linux/ion.h')
        with self.assertRaisesRegex(p.PortBlocked,'SYMLINK'):
            self.checked()

    def test_06_wrong_stock_header_rejected(self):
        import shutil
        altered=self.root/'fake_stock'
        shutil.copytree(STOCK,altered)
        f=altered/'include/linux/device.h';f.write_bytes(f.read_bytes()+b'\n')
        with self.assertRaisesRegex(p.PortBlocked,'STOCK_DEVICE_HEADER_SHA256_DRIFT'):
            p.verified_six(self.donor,self.xi,altered,self.locks,self.display)

    def test_07_wrong_stock_dma_header_rejected(self):
        import shutil
        altered=self.root/'fake_stock'
        shutil.copytree(STOCK,altered)
        f=altered/'include/linux/msm_dma_iommu_mapping.h';f.write_bytes(f.read_bytes()+b' ')
        with self.assertRaisesRegex(p.PortBlocked,'STOCK_DMA_HEADER_SHA256_DRIFT'):
            p.verified_six(self.donor,self.xi,altered,self.locks,self.display)

    def test_08_old_field_in_new_mapping_rejected(self):
        rel='drivers/iommu/msm_dma_iommu_mapping.c';f=self.xi/rel
        bad=f.read_bytes()+b'\nfoo->iommu_map_list;'
        f.write_bytes(bad)
        locks=dict(self.locks);locks[rel]=(locks[rel][0],p.git_blob_sha(bad))
        with self.assertRaisesRegex(p.PortBlocked,'ORPHANED_OLD_IOMMU_FIELD'):
            p.verified_six(self.donor,self.xi,STOCK,locks,self.display)

    def test_09_old_ion_type_rejected(self):
        rel='include/linux/ion.h';f=self.xi/rel
        bad=b'struct ion_buffer { struct msm_iommu_data iommu_data; }; /* still old */'
        f.write_bytes(bad)
        locks=dict(self.locks);locks[rel]=(locks[rel][0],p.git_blob_sha(bad))
        with self.assertRaisesRegex(p.PortBlocked,'XI_ION_DATA_STILL_EMBEDS_OLD_TYPE'):
            p.verified_six(self.donor,self.xi,STOCK,locks,self.display)

    def test_10_incorrect_free_call_rejected(self):
        rel='drivers/staging/android/ion/heaps/msm_ion_dma_buf.c';f=self.xi/rel
        bad=b'void release(void *buffer) { msm_dma_buf_freed(&buffer->iommu_data); }'
        f.write_bytes(bad)
        locks=dict(self.locks);locks[rel]=(locks[rel][0],p.git_blob_sha(bad))
        with self.assertRaisesRegex(p.PortBlocked,'XI_ION_FREE_CALL_MISSING'):
            p.verified_six(self.donor,self.xi,STOCK,locks,self.display)

    def test_11_unpinned_display_caller_rejected(self):
        f=self.xi/p.DISPLAY;f.write_bytes(b'unpinned')
        with self.assertRaisesRegex(p.PortBlocked,'SOURCE_BLOB_DRIFT'):
            self.checked()

    def test_12_incorrect_new_api_rejected(self):
        rel='include/linux/msm_dma_iommu_mapping.h';f=self.xi/rel
        bad=b'void msm_dma_buf_freed(struct msm_iommu_data *data); /* still wrong */'
        f.write_bytes(bad)
        locks=dict(self.locks);locks[rel]=(locks[rel][0],p.git_blob_sha(bad))
        with self.assertRaisesRegex(p.PortBlocked,'XI_STOCK_DMA_SIGNATURE_BAD'):
            p.verified_six(self.donor,self.xi,STOCK,locks,self.display)

    def test_13_complete_overlay_generated_without_writes_to_input(self):
        originals={r:{rel:(r/rel).read_bytes() for rel in p.PINS} for r in (self.donor,self.xi)}
        out=self.root/'result';
        with patch.object(p,'git_commit',side_effect=[p.DONOR_COMMIT,p.XIAOMI_COMMIT]), \
             patch.object(p,'PINS',self.locks),patch.object(p,'DISPLAY_SHA',self.display):
            result=p.stage(self.donor,self.xi,STOCK,out)
        self.assertEqual(result['changes'],6)
        self.assertEqual(len(list((out/'overlay').rglob('*.c'))),3)
        self.assertEqual(len(list((out/'overlay').rglob('*.h'))),3)
        self.assertEqual(len(list((out/'diffs').rglob('*.patch'))),6)
        self.assertTrue((out/'SOURCE_PORT_RESULT.json').is_file())
        for root,records in originals.items():
            for rel,raw in records.items():self.assertEqual((root/rel).read_bytes(),raw)

    def test_14_existing_output_refused(self):
        out=self.root/'result';out.mkdir()
        with self.assertRaisesRegex(p.PortBlocked,'OUTPUT_EXISTS'):
            p.stage(self.donor,self.xi,STOCK,out)

    def test_15_wrong_source_commit_refused(self):
        with patch.object(p,'git_commit',return_value='0'*40):
            with self.assertRaisesRegex(p.PortBlocked,'SOURCE_COMMIT_DRIFT'):
                p.stage(self.donor,self.xi,STOCK,self.root/'out')

    def test_16_structural_parity_of_real_stock_header(self):
        s=(STOCK/'include/linux/device.h').read_text()
        self.assertEqual(p.struct_body(s,'device'),p.struct_body(s+'\n/* comment */','device'))
        self.assertNotIn('iommu_map_lock',p.struct_body(s,'device'))

    def test_17_blob_git_sha_correct(self):
        raw=b'a\n'
        self.assertEqual(p.git_blob_sha(raw),hashlib.sha1(b'blob 2\0a\n').hexdigest())

    def test_18_no_release_or_crc_changes_in_port_manifest(self):
        _,r=self.checked()
        self.assertEqual(r['stock_release_reference'],'5.4.274-qgki-g82179e362f33')
        self.assertFalse(r['kernel_release_spoofed'])
        self.assertTrue(all(x.endswith(('.h','.c')) for x in r['six_files']))

if __name__=='__main__': unittest.main(verbosity=2)
