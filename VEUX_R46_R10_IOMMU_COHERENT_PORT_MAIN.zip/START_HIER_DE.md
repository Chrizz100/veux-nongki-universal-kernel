# VEUX R46-R10: zusammenhängender Xiaomi-IOMMU-/ION-Quellport

**Stand:** Tatsächlicher, reproduzierbarer Quellübernahme-Code für sechs zusammengehörige Dateien. Keine Kernelkompilierung, keine reparierte ABI, keine Flashfreigabe.

Die erfolgreiche R46-R6-Basis bleibt unverändert. Die Xiaomi-Stock-Kennung `5.4.274-qgki-g82179e362f33` ist ausschließlich Vergleichsreferenz und wird nicht in den Neubau hineingeschrieben.

## Was der Port wirklich macht

Das Python-Werkzeug `Tools/port_iommu.py` überprüft vor der Übernahme **beide exakten Git-Commits** und jeweils den SHA-1-**Git-Blob** jeder der sechs Quelldateien. Es prüft anschließend die originalen 5.4.274-Stock-Header, die identische OEM-`struct device`, die DMA-API-Signaturen, den zusammengehörigen ION-Kunden, die alten IOMMU-Felder und den unveränderten externen Display-Aufrufer. Nur bei vollständig bestandenen Prüfungen erzeugt es **sechs neue Dateien im separaten Ausgabeordner** und zu jeder einen echten Unified-Diff-Patch. Das Original-Repository wird nicht verändert.

| Dateipfad | Zweck |
| --- | --- |
| `include/linux/device.h` | OEM-naher `struct device`-Aufbau ohne zwei nachträgliche IOMMU-Felder |
| `drivers/base/core.c` | passende Geräteinitialisierung |
| `include/linux/msm_dma_iommu_mapping.h` | passende öffentliche Qualcomm-DMA-API |
| `drivers/iommu/msm_dma_iommu_mapping.c` | dazugehörige Mapping-Implementierung |
| `include/linux/ion.h` | passender ION-Buffer-Typ |
| `drivers/staging/android/ion/heaps/msm_ion_dma_buf.c` | dazugehöriger ION-Aufrufer |

Der nicht übernommene Display-Aufrufer `techpack/display/msm/msm_smmu.c` ist in beiden geprüften Git-Commits bytegleich und wird separat auf seinen Git-Blob-SHA überprüft.

## Noch offen

- Die sechs Quellen stammen aus Xiaomis öffentlichem **Linux 5.4.134**, nicht aus dem unvollständig veröffentlichten **Stock 5.4.274**. Das Werkzeug **testet noch keine Kompilierbarkeit** im tatsächlich aufgebauten R46-R6-Quellbaum.
- Der vollständige `SPECULATIVE_PAGE_FAULT`-Backport sowie `net_device` und `task_struct` sind **nicht Teil dieses Portschritts**. Ein unvollständiges Kopieren einzelner Felder würde die ABI eher beschädigen.
- Der zuletzt gemessene QGKI-ABI-Status bleibt **578 passend / 841 abweichend / 4 fehlend** für 1.423 Symbole und 37 OEM-Module. Der Quellport verbessert diesen Wert **erst nach bestätigtem Neubau**, nicht allein durch sein Vorhandensein.
- Der direkte Schreibzugriff auf GitHub wurde bei einem separaten Branch-Versuch mit HTTP 403 abgelehnt. Es gab **keinen Commit auf main**.

## Dateien

- `Tools/port_iommu.py` – tatsächliche, fail-closed Quellübernahme (Quelle und Ziel unverändert)
- `Tests/test_port_iommu.py` – 18 lokal geprüfte Testfälle samt 12 Datei-Tampering-Unterfällen
- `References/stock_headers/` – zwei originale Header aus dem Stock-Image als Prüfreferenz
- `References/R46_R9_*.csv` – tatsächliche alte ABI-Matrix zum Vergleich
- `Reports/TESTS.log` – Testprotokoll

Die mitgelieferte YAML ist ausschließlich eine **optionale** GitHub-Quellevaluierung per `workflow_dispatch`. Sie erzeugt Quell-Patches, **keine boot.img und kein AK3**. Kein laufender oder geplanter GitHub-Kernelbuild wird dadurch verändert.
