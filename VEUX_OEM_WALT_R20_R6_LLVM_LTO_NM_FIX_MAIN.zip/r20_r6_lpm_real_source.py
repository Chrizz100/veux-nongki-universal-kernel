#!/usr/bin/env python3
"""VEUX R20-R6: source-verified Qualcomm LPM caller ABI repair.

The old R4 diagnostic assumed include/linux/sched/walt.h exists; VEUX P11
stages kernel/sched/walt/walt.h instead. Read *actual* WALT function body,
limit allowed client edit to pinned drivers/cpuidle/lpm-levels.c in the
throwaway snapshot, and never fabricate a WALT implementation.

If ABI evidence is insufficient, fail closed and write source evidence.
"""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

DRIVER='drivers/cpuidle/lpm-levels.c'
INTERNAL='kernel/sched/walt/walt.h'
STAT='include/linux/sched/stat.h'
WALT_MAKE='kernel/sched/walt/Makefile'
PROVIDERS=('kernel/sched/walt/sched_avg.c','kernel/sched/walt/walt.c','kernel/sched/walt/boost.c')
DRIVER_PIN_BLOB='ef589378adf49fc78cf4adc2ac90ba7b9091d059'
OLD_STUB='static inline uint64_t sched_lpm_disallowed_time(int cpu)\n{\n\treturn 0;\n}\n'
OLD_CALL='\tbias_time = sched_lpm_disallowed_time(cpu);\n\tif (bias_time) {\n'
NEW_CALL='\tif (!sched_lpm_disallowed_time(cpu, &bias_time)) {\n'
ABI_TWO=re.compile(r'(?m)^\s*int\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*,\s*u64\s*\*\s*timeout\s*\)\s*\{')
ABI_ONE=re.compile(r'(?m)^\s*(?:u64|uint64_t)\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*\)\s*\{')
ANY_DECL=re.compile(r'(?m)^\s*(?:extern\s+|static\s+inline\s+)?(?:u64|uint64_t|int)\s+sched_lpm_disallowed_time\s*\(([^)]*)\)')
CALL_NAME='sched_lpm_disallowed_time('

class ContractError(Exception):pass

def require(ok,msg):
    if not ok:raise ContractError(msg)

def shasum(b):return hashlib.sha256(b).hexdigest()

def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()

def regular_inside(root,path,required=True):
    p=root/path
    if not p.exists():
        if required:raise ContractError('MISSING_AUTHENTIC_SOURCE:'+path)
        return None
    require(p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(root.resolve()),
            'UNSAFE_STAGE_INPUT:'+path)
    return p

def read_inside(root,path,required=True):
    p=regular_inside(root,path,required)
    if p is None:return None
    b=p.read_bytes()
    require(b'\r\n' not in b,'CRLF_SOURCE:'+path)
    return b

def provider_evidence(contents):
    findings=[]
    for path,b in contents.items():
        c=b.decode('utf-8')
        for kind,rx in (('one-u64',ABI_ONE),('two-int-timeout',ABI_TWO)):
            for m in rx.finditer(c):
                begin=m.start();context=c[begin:begin+950]
                findings.append({'path':path,'kind':kind,'line':c.count('\n',0,begin)+1,
                                 'excerpt':context[:520]})
    return findings

def validate_global_text_symbol(nm_stdout):
    """Accept ELF hexadecimal addresses and LLVM bitcode's 16-dash address.

    Require exactly one T definition. Reject U/t/W/D and malformed or
    contradictory output: the tool is only evidence, not source mutation.
    """
    sym = 'sched_lpm_disallowed_time'
    candidates = [line.strip() for line in nm_stdout.splitlines()
                  if re.search(r'\b'+re.escape(sym)+r'\s*$',line)]
    require(len(candidates)==1,'REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    line = candidates[0]
    match = re.fullmatch(r'(?P<address>[0-9a-fA-F]+|-{16})\s+(?P<kind>[A-Za-z?])\s+'
                         +re.escape(sym),line)
    require(match is not None and match.group('kind')=='T',
            'REAL_PROVIDER_SYMBOL_NOT_DEFINED_GLOBAL_TEXT')
    address = match.group('address')
    return {'type': 'T', 'symbol': sym, 'nm_line': line,
            'address': address, 'llvm_bitcode_address': address=='-'*16,
            'nm_output_sha256': shasum(nm_stdout.encode('utf-8'))}

def prove_abi(snapshot,source,proof,config,objdir,nm,audit_dir):
    require(config.count(b'CONFIG_SCHED_WALT=y\n')==1,'CONFIG_WALT_ON_NOT_PROVEN')
    data=json.loads(proof.decode('utf-8'))
    require(data.get('object_success_count')==15,'R18_15_OBJECTS_NOT_PROVEN')
    objects=data.get('objects',{})
    items=provider_evidence({p:source[p] for p in PROVIDERS if p in source})
    require(len(items)==1,'LPM_PROVIDER_COUNT_OR_SIGNATURE_UNSUPPORTED:'+str(len(items)))
    item=items[0];impl=item['path'];kind=item['kind'];obj=impl[:-1]+'o'
    o=objects.get(obj,{})
    require(o.get('compiled') is True and o.get('exit_code')==0,
            'R18_PROVIDER_OBJECT_NOT_COMPILED:'+obj)
    require(re.fullmatch(r'[0-9a-f]{64}',o.get('object_sha256','')) is not None,
            'R18_PROVIDER_OBJECT_SHA_MISSING:'+obj)
    provider_object=regular_inside(objdir,obj)
    require(shasum(provider_object.read_bytes())==o['object_sha256'],
            'REAL_ARM64_PROVIDER_OBJECT_SHA_DRIFT')
    require(nm.is_file() and not nm.is_symlink(), 'PINNED_LLVM_NM_MISSING')
    proc=subprocess.run([str(nm),'-g',str(provider_object)],capture_output=True,text=True,check=False,timeout=60)
    # Preserve actual llvm-nm evidence even if no suitable symbol is found.
    (audit_dir/'R20_R6_LLVM_NM_PROVIDER.txt').write_text(
        '# object: '+obj+'\n# argv: llvm-nm -g\n# rc: '+str(proc.returncode)+'\n'+
        '# SHA256 object: '+o['object_sha256']+'\n'+proc.stdout+proc.stderr)
    require(proc.returncode==0,'LLVM_NM_PROVIDER_OBJECT_FAILED')
    require(len(proc.stdout) < 2_000_000,'LLVM_NM_OUTPUT_TOO_LARGE')
    symbol_evidence=validate_global_text_symbol(proc.stdout)
    actual=source[impl].decode('utf-8')
    # Reject a second, incompatible function declaration within the provider file.
    defns=[m for m in ANY_DECL.finditer(actual) if not actual[max(0,m.start()-7):m.start()].endswith('/*')]
    require(len(defns)==1,'LPM_PROVIDER_AMBIGUOUS_DECLARATIONS:'+str(len(defns)))
    snippet=item['excerpt']
    semantic=re.sub(r'/\*.*?\*/','',snippet,flags=re.S)
    semantic=re.sub(r'//[^\n]*','',semantic)
    require('busy_hyst_end_time' in actual and 'sched_clock()' in actual and
            'bias_end_time' in semantic,'LPM_NOT_PROVEN_SCHEDULER_BUSY_HYST_BACKEND')
    if kind=='two-int-timeout':
        require(re.search(r'\*timeout\s*=',semantic) is not None and 'return 0' in semantic and 'INT_MAX' in semantic,
                'TWO_ARG_RETURN_SEMANTICS_UNPROVEN')
    else:
        require('return 0' in semantic and 'return bias_end_time' in semantic,
                'ONE_ARG_RETURN_SEMANTICS_UNPROVEN')
    # The real staged Makefile must compile the actual provider module.
    make=source[WALT_MAKE].decode('utf-8')
    require(re.search(r'(?<![\w-])'+re.escape(obj.rsplit('/',1)[-1])+r'\b',make) is not None,
            'LPM_PROVIDER_OBJECT_NOT_IN_WALT_MAKEFILE')
    stat=source[STAT].decode('utf-8');intr=source[INTERNAL].decode('utf-8')
    # Declared symbol must not have an incompatible source ABI.
    for path,text in [(STAT,stat),(INTERNAL,intr)]:
        decls=[m for m in ANY_DECL.finditer(text)]
        for d in decls:
            sig=text[d.start():d.end()]
            if kind=='two-int-timeout':
                require(re.search(r'\bint\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*,\s*u64\s*\*\s*timeout\s*\)',sig),
                        'CONFLICTING_WALT_DECLARATION:'+path)
            else:
                require(re.search(r'\b(?:u64|uint64_t)\s+sched_lpm_disallowed_time\s*\(\s*int\s+cpu\s*\)',sig),
                        'CONFLICTING_WALT_DECLARATION:'+path)
    # No new WALT subsystem implementation: only the downstream client changes.
    return {'kind':kind,'function_source':impl,'provider_object':obj,
            'object_sha256':o['object_sha256'],'line':item['line'],
            'llvm_nm_symbol':symbol_evidence,
            'signature':('int (int, u64*)' if kind=='two-int-timeout' else 'u64 (int)')}

def patch_driver(before,kind):
    s=before.decode('utf-8')
    require(gitblob(before)==DRIVER_PIN_BLOB,'DRIVER_PINNED_PREIMAGE_SHA_DRIFT')
    require(s.count(OLD_STUB)==1,'ORIGINAL_NONWALT_STUB_DRIFT')
    require(s.count(OLD_CALL)==1,'ORIGINAL_CPUIDLE_CALL_DRIFT')
    require(s.count(CALL_NAME)==2,'LPM_SYMBOL_SCOPE_DRIFT')
    anchor='#ifdef CONFIG_SCHED_WALT\nstatic bool check_cpu_isolated(int cpu)'
    require(s.count(anchor)==1,'WALT_BRANCH_ANCHOR_DRIFT')
    require('#include <linux/sched/stat.h>' in s,'LEGACY_STAT_HEADER_MISSING')
    require('#include <linux/sched/walt.h>' not in s,'INCOMPATIBLE_NEWER_HEADER_PRESENT')
    if kind=='one-u64':
        s=s.replace(anchor,'#ifdef CONFIG_SCHED_WALT\nextern u64 sched_lpm_disallowed_time(int cpu);\n\nstatic bool check_cpu_isolated(int cpu)',1)
        require(s.count(OLD_CALL)==1 and s.count(OLD_STUB)==1,'ONEARG_CLIENT_SEMANTICS_CHANGED')
    elif kind=='two-int-timeout':
        s=s.replace(anchor,'#ifdef CONFIG_SCHED_WALT\nextern int sched_lpm_disallowed_time(int cpu, u64 *timeout);\n\nstatic bool check_cpu_isolated(int cpu)',1)
        s=s.replace(OLD_STUB,'static inline int sched_lpm_disallowed_time(int cpu, u64 *timeout)\n{\n\treturn INT_MAX;\n}\n',1)
        s=s.replace(OLD_CALL,NEW_CALL,1)
        marker='#include <linux/sched/stat.h>\n'
        require(s.count(marker)==1,'LIMITS_INCLUDE_ANCHOR_MISSING')
        s=s.replace(marker,marker+'#include <linux/limits.h>\n',1)
        require(s.count(NEW_CALL)==1 and s.count('*timeout')==2,'TWOARG_CLIENT_SCOPE_DRIFT')
    else:raise ContractError('UNKNOWN_ABI_KIND')
    return s.encode('utf-8')

def run(snapshot,canonical,project,config,result,output,objects,llvm_nm):
    snapshot,canonical,project,config,result,output,objects,llvm_nm=map(Path,(snapshot,canonical,project,config,result,output,objects,llvm_nm))
    for name,p in [('SNAPSHOT',snapshot),('CANONICAL',canonical),('PROJECT',project),('OBJECTS',objects)]:
        require(p.is_dir() and not p.is_symlink(),'UNSAFE_'+name+'_ROOT')
    s,c,p,o=snapshot.resolve(),canonical.resolve(),project.resolve(),output.resolve()
    require(s!=c and not s.is_relative_to(c) and not c.is_relative_to(s),'CANONICAL_OVERLAP')
    require(not s.is_relative_to(p) and not o.is_relative_to(p),'PROJECT_WRITE_PROHIBITED')
    require(not o.is_relative_to(s) and not o.is_relative_to(c) and
            not output.exists() and not output.is_symlink(),'UNSAFE_DIAGNOSTIC_OUTPUT')
    require(config.is_file() and not config.is_symlink() and result.is_file() and not result.is_symlink(),
            'MISSING_PINNED_CONFIG_OR_R18_PROOF')
    # Materialize a failure evidence directory before any source ABI assertions.
    output.mkdir(parents=True,exist_ok=False)
    evidence={'stage':'R20_R6_REAL_VEUX_LPM_ABI_GATE',
              'status':'UNVERIFIED','expected_source_layout':'kernel/sched/walt/walt.h',
              'full_build_proven':False,'flash_allowed':False,'vendor_abi_proven':False,
              'brene_changed':False,'bakasusu_nomount_changed':False}
    target=output/'R20_R6_SOURCE_INSPECTION.json'
    tracked={}; source={}
    try:
        for path in [DRIVER,INTERNAL,STAT,WALT_MAKE,*PROVIDERS]:
            b=read_inside(snapshot,path,required=(path not in PROVIDERS))
            if b is not None:
                source[path]=b;tracked[path]=shasum(b)
        evidence['source_sha256']=tracked
        evidence['possible_provider_defs']=provider_evidence({x:y for x,y in source.items() if x in PROVIDERS})
        target.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
        before=source[DRIVER];orig=read_inside(canonical,DRIVER)
        require(orig==before,'CANONICAL_DRIVER_DRIFT')
        abi=prove_abi(snapshot,source,result.read_bytes(),config.read_bytes(),objects,llvm_nm,output)
        evidence['provider_abi']=abi
        after=patch_driver(before,abi['kind'])
        diff=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),
             after.decode().splitlines(keepends=True),fromfile='a/'+DRIVER,tofile='b/'+DRIVER))
        require(diff and diff.startswith('--- a/'+DRIVER),'DIFF_SCOPE_MISMATCH')
        # No source content other than pinned client may be changed by this script.
        require(snapshot/DRIVER==snapshot/DRIVER,'INTERNAL_ASSERT')
        require(read_inside(snapshot,DRIVER)==before,'PREWRITE_SOURCE_DRIFT')
        (snapshot/DRIVER).write_bytes(after)
        try:
            require(read_inside(snapshot,DRIVER)==after,'POSTWRITE_SOURCE_DRIFT')
            require(read_inside(canonical,DRIVER)==orig,'CANONICAL_MUTATION')
            for key,old_hash in tracked.items():
                if key!=DRIVER:require(shasum(read_inside(snapshot,key))==old_hash,'OTHER_SOURCE_MUTATION:'+key)
            (output/'R20_R6_SOURCE_DIFF.patch').write_text(diff)
            evidence.update(status='PASS',modified_paths=[DRIVER],
               client_original_sha256=shasum(before),client_modified_sha256=shasum(after),
               canonical_unmodified=True,full_build_proven=False)
            target.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
            print('R20_R6_SOURCE_ABI=PASS; MODE='+abi['kind']+'; REAL_PROVIDER='+abi['provider_object']+'; PATCHED_FILES=1; FLASH=NO')
            return evidence
        except Exception:
            if (snapshot/DRIVER).read_bytes()==after:(snapshot/DRIVER).write_bytes(before)
            raise
    except Exception as exc:
        evidence.update(status='FAIL_CLOSED',failure_code=str(exc))
        target.write_text(json.dumps(evidence,indent=2,sort_keys=True)+'\n')
        raise

def main():
    ap=argparse.ArgumentParser()
    for opt in ('snapshot','canonical','project','config','result','output','objects','llvm-nm'):
        ap.add_argument('--'+opt,required=True)
    args=ap.parse_args()
    try:
        run(args.snapshot,args.canonical,args.project,args.config,args.result,args.output,args.objects,args.llvm_nm)
        return 0
    except (ContractError,ValueError,OSError,UnicodeError,json.JSONDecodeError) as e:
        print('R20_R6_FAIL_CLOSED:'+str(e),file=sys.stderr)
        return 2

if __name__=='__main__':raise SystemExit(main())
