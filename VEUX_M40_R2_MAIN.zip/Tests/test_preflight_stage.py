"""Execute the delivered donor preflight in its actual early-stage directory layout.

The shim checks workflow argument routing only. A separate integration record
executes the complete stage with authentic tools and the actual pinned Git tree.
"""
import json
import os
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path


def preflight_script(workflow):
    rows=Path(workflow).read_text().splitlines();found=[]
    for i,row in enumerate(rows):
        if row.strip()!='run: |':continue
        indent=len(row)-len(row.lstrip());body=[]
        for line in rows[i+1:]:
            if line.strip()and len(line)-len(line.lstrip())<=indent:break
            body.append(line)
        script=textwrap.dedent('\n'.join(body))+'\n'
        if '"$M40_DIR/Tools/m40_bq_numeric_inputs.py" check-git-source'in script:found.append(script)
    if len(found)!=1:raise ValueError('ONE_DELIVERED_DONOR_PREFLIGHT_REQUIRED')
    return found[0]


@unittest.skipUnless(os.environ.get('M40_WORKFLOW'),'M40_WORKFLOW required')
class PreflightStageTests(unittest.TestCase):
    def script(self):return preflight_script(os.environ['M40_WORKFLOW'])

    def execute(self,script,create_kernel=True):
        with tempfile.TemporaryDirectory(prefix='m40 early checkout spaces ')as temp:
            root=Path(temp);bindir=root/'bin';bindir.mkdir()
            if create_kernel:(root/'kernel').mkdir()
            shim=bindir/'python3'
            shim.write_text('''#!/usr/bin/python3
import json,os,sys
from pathlib import Path
args=sys.argv[1:]
with open(os.environ['PREFLIGHT_CAPTURE'],'a')as f:f.write(json.dumps(args)+'\\n')
source=Path(args[args.index('--source')+1])
if not source.is_dir():
    print('PREFLIGHT_SOURCE_DIRECTORY_NOT_YET_CREATED:'+str(source),file=sys.stderr)
    raise SystemExit(23)
print(json.dumps({'source':str(source),'tool':Path(args[1]).name}))
''');shim.chmod(0o755)
            env=dict(os.environ,GITHUB_WORKSPACE=str(root),R9_SNAPSHOT=str(root/'later-r9-copy'),
                     PATH=str(bindir)+os.pathsep+os.environ['PATH'],PREFLIGHT_CAPTURE=str(root/'capture.jsonl'))
            env.update({'M'+str(i)+'_DIR':str(root/('m'+str(i)+' tools'))for i in range(25,41)})
            r=subprocess.run(['bash','-c',script],env=env,text=True,capture_output=True,timeout=15)
            records=[json.loads(s)for s in(root/'capture.jsonl').read_text().splitlines()]
            proofs={p.name:p.read_text()for p in root.glob('*donor-proof.json')}
            return r,records,proofs,str(root/'kernel')

    def test_every_preflight_uses_the_already_checked_out_kernel(self):
        script=self.script()
        self.assertEqual(script.count('--source "$GITHUB_WORKSPACE/kernel"'),16)
        self.assertNotIn('$R9_SNAPSHOT',script)

    def test_exact_delivered_preflight_passes_before_r9_copy_exists(self):
        r,calls,proofs,kernel=self.execute(self.script())
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        self.assertEqual(len(calls),16)
        self.assertEqual(len(proofs),12)
        for args in calls:self.assertEqual(args[args.index('--source')+1],kernel)
        for proof in proofs.values():self.assertEqual(json.loads(proof)['source'],kernel)
        self.assertEqual(json.loads(proofs['m40-donor-proof.json'])['tool'],'m40_bq_numeric_inputs.py')

    def test_original_m40_wrong_directory_reproduces_failure_and_empty_proof(self):
        line='"$M40_DIR/Tools/m40_bq_numeric_inputs.py" check-git-source --source "$GITHUB_WORKSPACE/kernel"'
        self.assertEqual(self.script().count(line),1)
        old=self.script().replace(line,line.replace('$GITHUB_WORKSPACE/kernel','$R9_SNAPSHOT'),1)
        r,calls,proofs,_=self.execute(old)
        self.assertEqual(r.returncode,23)
        self.assertEqual(len(calls),16)
        self.assertIn('PREFLIGHT_SOURCE_DIRECTORY_NOT_YET_CREATED:',r.stderr)
        self.assertEqual(proofs['m40-donor-proof.json'],'')

    def test_missing_real_checkout_fails_at_first_check(self):
        r,calls,proofs,_=self.execute(self.script(),create_kernel=False)
        self.assertEqual(r.returncode,23)
        self.assertEqual(len(calls),1)
        self.assertEqual(proofs,{})


if __name__=='__main__':unittest.main()
