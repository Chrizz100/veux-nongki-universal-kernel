VEUX M40-R2 - Negative BQ-Zahlenwerte abweisen - NOFLASH
Basis: gruener M39-Lauf 43893136877, Commit 2a839764ba774eb5d6c949fdb36eaa26cc218d59.

UPLOAD AM SMARTPHONE
1. VEUX_M40_R2_MAIN.zip unveraendert ins Hauptverzeichnis der Repo hochladen.
   MAIN nicht entpacken. Ein angehaengtes (1) im Dateinamen entfernen.
2. VEUX_M40_R2_YAML.zip entpacken und die enthaltene Datei
   .github/workflows/VEUX_R46_R15_STOCK_MODULE_LAYOUT_NOFLASH.yml dort ersetzen.
3. VEUX_R25_MAIN.zip behalten. Danach Workflow manuell starten.
   Historische Pakete werden aus festen Commits authentifiziert geladen.

M40-R2: KORREKTUR DES LAUFS 43918011454
Der Lauf scheitert vor dem Kernelbau im Quell-Preflight. Der neue M40-Aufruf
benutzte R9_SNAPSHOT, obwohl diese Arbeitskopie dort noch nicht existiert.
Alle bisherigen Aufrufe nutzten bereits den echten Checkout GITHUB_WORKSPACE/kernel.
M40-R2 korrigiert ausschliesslich diesen letzten Quellenpfad. Kein Kernel-,
Konfigurations-, Header-, ABI-, Boot- oder Installer-Byte wird neu geaendert.
Der M40-Treiber bleibt SHA256 dd71a256bea1b7dc170482ac3bda85d7523c3c896812b1cf34e43dbbf4f6d0c0.
Die M40-Zahlenwert-Reparatur wartet weiterhin auf den vollstaendigen GitHub-Bau.
Es gab in diesem fehlgeschlagenen Lauf keine neuen Boot.img/AK3-Dateien.
Beide Artefakte wurden geprueft; m40-donor-proof.json ist erwartungsgemaess leer,
weil tee die Datei vor dem gescheiterten Python-Aufruf angelegt hat.
56 aktuelle Regressionen umfassen die bisherigen 52 sowie vier neue Ablaufpruefungen.
Die vier neuen Ablaufregressionen testen den exakt ausgelieferten Preflight mit
vorhandenem kernel-Checkout und noch nicht vorhandener R9-Arbeitskopie.
Der alte M40-Aufruf wird als negative Kontrolle reproduziert. Ein separater
Integrationstest fuehrt alle 16 echten Tools gegen den gepinnten Git-Checkout aus.

M39 AUSGEWERTET
Alle 32 Artefakte heruntergeladen, SHA-256, sichere Pfade und komplette ZIP-CRC
geprueft: 1.431 Dateien, 1.345 Textdateien, 367 JSON-Dateien und 41.230.716 Textbytes.
Neun Archive enthalten historische Zwischenfehler oder alte Negativkontrolllogs.
Die sechs damals betroffenen Objektziele werden spaeter in R18 erfolgreich gebaut;
R18 umfasst 15 ARM64-Objekte, R19 belegt 13 typisierte Provider.
Der finale M39 besteht die erneute Quellen-/LLVM-Objekt-/CFI-/14-Schnittstellen-
Pruefung. Alle 40 make-Kommandos erfolgreich. .config, config_data, Image,
vmlinux und autoconf sind konsistent; die komplette Exporttabelle ist unveraendert.
Die bekannte Stock-Vendor-Kohorte wurde unabhaengig erneut abgeglichen:
1.423 passende Import-CRCs, null fehlende Exporte oder CRC-Abweichungen, 37 Module.
Boot.img und AK3 sind aus den gepinnten Referenzen byteidentisch rekonstruiert,
mit unveraenderter Stock-Ramdisk und geprueftem AVB-Hash. Diese tiefen Binaer-/ABI-/
Boot-Pruefungen betreffen den finalen M39, nicht jeden historischen Kernel.
Details: Reports/RUN43893136877_32_ARTEFAKTE.zip und
Reports/M39_INDEPENDENT_VERIFICATION.json. Static Boot Pass ist kein Device Pass.

M40: BELEGTER FEHLER UND GENAU EINE AENDERUNG
Der reale WT-Aufrufer mtbf_current_store liest einen beliebigen vorzeichenbehafteten
Integer ein und reicht ihn an den BQ-Eingangsstromkanal durch. M39 wandelt -1
bisher in einen IINLIM-Feldwert von 62 um: 100 + 62 * 50 = 3.200 mA. Bei INT_MIN
kann die Subtraktion ausserdem einen vorzeichenbehafteten Integer-Ueberlauf ausloesen.
Die aktuelle M39-Umrechnung und der ungeschuetzte alte Writer reproduzieren dies.
M40 weist negative Werte in genau fuenf physikalischen Zahlenkanaelen vor
Bus-, GPIO-, Provider- oder Cache-Zugriff mit -EINVAL ab:
- MAIN_INPUT_CURRENT_SETTLED
- MAIN_INPUT_VOLTAGE_SETTLED
- MAIN_CHAGER_CURRENT
- MAIN_CHAGER_TERM
- BATTERY_VOLTAGE_TERM
Nur bq_iio_write_raw_unlocked erhaelt diesen Guard. Alle anderen Treiberbytes
bleiben gegen die gebaute M39-Referenz identisch. Fehlende Startbereitschaft und
Stoppzustand behalten ihre bisherigen Fehlerprioritaeten.
Nichtnegative Werte, Rundung, bisherige Obergrenzen und alle Lade-/Temperaturregeln
bleiben gleich. Der echte WT-Sonderwert -1 fuer MAIN_CHARGER_HZ bleibt wirksam;
auch die weiteren Schaltkanaele und unbekannte/read-only Kanaele behalten ihre
bisherigen Rueckgaben und Ablaufe. Kein pauschales Abweisen negativer Steuerwerte.
Keine Defconfig-, Header- oder Export-Aenderung. Originalkennung:
5.4.274-qgki-g82179e362f33. bq2589x_iio.h bleibt 1.763 Bytes ohne EOF-Zeilenumbruch.
References/NUMERIC_CONSUMER_EVIDENCE.json und WT_NUMERIC_CALLSITE_EXCERPTS.c.txt
enthalten die Aufruferbelege aus dem tatsaechlich gebauten M39.

PRUEFUNGEN UND NAECHSTER LAUF
Neuer nativer Test: 16.022 C-Assertions, 360 negative Wertefaelle ohne Seiteneffekt,
2.760 differentielle Nichtnegativ-/Busfehlerfaelle, 120 differentielle Steuerfaelle
und 90 Start-/Stopp-Prioritaetsfaelle. Die Original-M39-Kontrolle scheitert an der
fehlenden Eingabeabweisung; -1 -> 3.200 mA wird gesondert reproduziert.
Die bisherigen Register-, Lade-, Shutdown- und Provider-Tests laufen auf M40 weiter.
52 M40-Regressionen werden mit GCC 11.4 (Ubuntu 22.04) und GCC 14 sowie UBSan
geprueft; die bisherigen 611 Regressionen werden unveraendert weitergefuehrt.
Aktuelle native Testsumme: 161.103 C-Assertions plus 156 alte Probe-Assertions auf
der separaten M31-Referenz. Dies ist kein Laufzeittest am Smartphone.
Der komplette geaenderte Treiber kompiliert mit AOSP Clang 12.0.5, ARM64,
CFI/ThinLTO und den Headern des aktuellen M39-Baus. Kein voller lokaler M40-Bau.
Der naechste GitHub-Lauf muss die aktuelle Quelle, ihr LLVM-Objekt/CFI-Kommando,
alle 14 Schnittstellen und den neuen Guard-Zweig in Image UND vmlinux nachweisen.
Die Gates fuer Konfiguration, alle 1.423 CRCS, 37 Module, RPM/ADC/WT sowie das
Boot-/AK3-Paar bleiben verpflichtend. Alte gruene M39-Berichte reichen dafuer nicht.

FESTE RESTLISTE
P1: Provider-Hot-Unregister und die tatsaechliche Teardown-Reihenfolge bleiben offen.
P2: Ganze Adapter-/Monitor-/IIO-Ablaeufe sind noch nicht gegeneinander geordnet.
P3: Positive und nullwertige Register-Unter-/Obergrenzen, vollstaendige Konsumenten-
vertraege, WT-Fehlerrueckgabe sowie GPIO-/DT-Zuordnung sind weiterhin offen.
WT mtbf_current_store ignoriert derzeit Providerfehler und meldet count zurueck;
M40 verhindert den negativen Registerzugriff, repariert diese WT-Rueckgabe aber nicht.
D1: Echte Boot-, Lade-/OTG-, Temperatur-, Suspend-, Unplug-/Remove-/Rebind-Tests
und eine verfuegbare Wiederherstellung fehlen. Device Pass NEIN. Flashfreigabe NEIN.
K1: Die historischen >7.100 Ganzkernel-Abweichungen sind damit nicht vollstaendig
abgearbeitet. Das BQ-Inventar umfasst 67 aktive Funktionen: eine M40-Funktion,
sechs M39-Funktionen, 21 bisherige native Zuordnungen und 39 reine Quellpruefungen.
Das ist weder ein eigener Fehlertest pro Funktion noch ein universeller GKI-Nachweis.
