import json, os, sys, tempfile, unittest
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import r9_abi_roots as r9
ROOT=HERE.parent

class R9Regression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.summary,cls.groups,cls.mods=r9.analyze(ROOT)

    def test_01_bundle_hashes_manifest(self):
        self.assertEqual(r9.check_bundle(ROOT)['schema'],'VEUX_STOCK_R9_ROOT_CAUSE_READONLY')

    def test_02_all_cohort_module_counts(self):
        self.assertEqual(self.summary['QGKI']['module_files_in_loader'],37)
        self.assertEqual(self.summary['QGKI']['import_occurrences'],3148)
        self.assertEqual(self.summary['GKI']['import_occurrences'],11500)

    def test_03_layout_alone_one_qgki(self):
        self.assertEqual(self.summary['QGKI']['module_layout_only_files'],['q6_pdr_dlkm.ko'])
        self.assertEqual(sum(x['bad_without_module_layout']>0 for x in self.mods['QGKI']),36)

    def test_04_r8_changes_without_qgki_wins(self):
        q=self.summary['QGKI']
        self.assertEqual(q['export_crc_changed_import_occurrences'],1568)
        self.assertEqual(q['r6_matches'],q['r8_matches'])
        self.assertEqual(q['fully_compatible_r8'],0)

    def test_05_changed_export_total(self):
        self.assertEqual(self.summary['common_export_crc_changed'],8638)
        self.assertEqual(self.summary['R8_new_exports'],4)

    def test_06_gki_has_one_match_improvement(self):
        self.assertEqual(self.summary['GKI']['r8_matches'],5486)
        self.assertEqual(self.summary['GKI']['r8_missing'],22)

    def test_07_stock_walt_not_donor(self):
        self.assertEqual(self.summary['config_stock_SCHED_WALT'],'y')
        self.assertEqual(self.summary['config_candidate_SCHED_WALT'],'(absent)')

    def test_08_loader_snapshot_is_not_proof(self):
        self.assertFalse(self.summary['loaded_module_cohort_verified'])
        self.assertEqual(self.summary['proc_modules_snapshot_count'],0)

    def test_09_never_claim_flashable(self):
        self.assertFalse(self.summary['flash_allowed'])
        self.assertFalse(self.summary['source_patch_allowed'])
        self.assertFalse(self.summary['module_runtime_compatibility_verified'])

    def test_10_module_layout_group_affects_37(self):
        row=next(x for x in self.groups['QGKI'] if x['symbol']=='module_layout')
        self.assertEqual(row['modules_with_blocker'],37)
        self.assertEqual(row['import_occurrences'],37)

    def test_11_all_qgki_module_names_unique(self):
        mods=[m['module'] for m in self.mods['QGKI']]
        self.assertEqual(len(mods),len(set(mods)))

    def test_12_all_qgki_module_names_in_loader(self):
        self.assertTrue(all(m['present_in_load_file'] for m in self.mods['QGKI']))

    def test_13_status_function(self):
        self.assertEqual(r9.status('0xaaaaaaaa','0xaaaaaaaa'),'MATCH')
        self.assertEqual(r9.status('0xaaaaaaaa','0xbbbbbbbb'),'CRC_MISMATCH')
        self.assertEqual(r9.status('0xaaaaaaaa',None),'NOT_EXPORTED')

    def test_14_ambiguous_export_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.symvers';p.write_text('0x11111111\tdup\tvmlinux\tEXPORT_SYMBOL\n0x22222222\tdup\tvmlinux\tEXPORT_SYMBOL\n')
            with self.assertRaisesRegex(ValueError,'AMBIGUOUS_EXPORT'):r9.parse_symvers(p)

    def test_15_bad_import_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.csv';p.write_text('module,symbol,expected_crc,candidate_crc,result\n/vendor/lib/modules/test.ko,=bad,0x00000000,0x00000000,MATCH\n')
            with self.assertRaisesRegex(ValueError,'BAD_IMPORT_ID'):r9.read_imports(p)

    def test_16_hash_tamper_rejected(self):
        manifest=r9.check_bundle(ROOT)
        with tempfile.TemporaryDirectory() as d:
            dst=Path(d);(dst/'reference').mkdir()
            (dst/'MANIFEST_SHA256.json').write_text(json.dumps({'schema':manifest['schema'],'flash_allowed':False,'kernel_build_requested':False,'source_patch_allowed':False,'files':{'reference/example.txt':'0'*64}}))
            (dst/'reference/example.txt').write_text('changed\n')
            with self.assertRaisesRegex(ValueError,'BAD_SHA256'):r9.check_bundle(dst)

    def test_17_manifests_only_readonly(self):
        man=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
        self.assertFalse(man['flash_allowed']);self.assertFalse(man['kernel_build_requested']);self.assertFalse(man['source_patch_allowed'])

    def test_18_report_files_nonempty(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)
            summary=r9.write_report(ROOT,out)
            self.assertEqual(len(list(out.iterdir())),8)
            self.assertTrue((out/'R9_PRUEFBERICHT_DE.md').stat().st_size>1900)
            self.assertEqual(json.loads((out/'R9_ABI_GESAMT.json').read_text())['QGKI']['r8_matches'],1470)

if __name__ == '__main__':unittest.main()
