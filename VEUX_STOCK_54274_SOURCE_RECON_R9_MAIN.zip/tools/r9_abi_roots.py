#!/usr/bin/env python3
"""VEUX R9 read-only evidence audit; no Linux/Android execution, no flashing."""
from __future__ import annotations
import argparse, collections, csv, hashlib, io, json, re
from pathlib import Path

BASE_EXPECTED = {'QGKI':(3148,37,1470,1664,14),'GKI':(11500,181,5485,5989,26)}
CRC = re.compile(r'^0x[0-9a-f]{8}$')
SYMBOL = re.compile(r'^[A-Za-z_][A-Za-z0-9_.$]*$')


def sha(p:Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def check_bundle(root:Path):
    manifest=json.loads((root/'MANIFEST_SHA256.json').read_text(encoding='utf8'))
    if (manifest.get('schema') != 'VEUX_STOCK_R9_ROOT_CAUSE_READONLY'
        or manifest.get('flash_allowed') is not False
        or manifest.get('source_patch_allowed') is not False
        or manifest.get('kernel_build_requested') is not False):
        raise ValueError('R9_PROVENANCE_OR_NOFLASH_GATE')
    expected=set(manifest['files'])
    present={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}-{'MANIFEST_SHA256.json'}
    if expected!=present:raise ValueError('R9_FILESET_CHANGED')
    for name,digest in manifest['files'].items():
        if not re.fullmatch(r'[a-f0-9]{64}',digest):raise ValueError('INVALID_SHA256')
        p=root/name
        if not p.is_file() or p.is_symlink() or sha(p)!=digest:raise ValueError('R9_BAD_SHA256:'+name)
    return manifest


def parse_symvers(path:Path) -> dict:
    out={}
    for n,line in enumerate(path.read_text(encoding='utf8').splitlines(),1):
        p=line.split('\t')
        if len(p)<4 or not CRC.fullmatch(p[0]) or not SYMBOL.fullmatch(p[1]):
            raise ValueError(f'BAD_SYMVERS_LINE:{path.name}:{n}')
        sym=p[1]
        if sym in out:raise ValueError('AMBIGUOUS_EXPORT:'+sym)
        out[sym]=p[0]
    if not out:raise ValueError('EMPTY_SYMVERS')
    return out


def read_imports(p:Path):
    with p.open(encoding='utf8',newline='') as f:
        reader=csv.DictReader(f)
        if reader.fieldnames!=['module','symbol','expected_crc','candidate_crc','result']:
            raise ValueError('BAD_IMPORT_HEADER')
        rows=list(reader)
    for r in rows:
        if not r['module'].startswith('/vendor/lib/modules/') or not r['module'].endswith('.ko') or not SYMBOL.fullmatch(r['symbol']):
            raise ValueError('BAD_IMPORT_ID')
        if not CRC.fullmatch(r['expected_crc']):raise ValueError('BAD_IMPORT_CRC')
        if r['result'] not in {'MATCH','CRC_MISMATCH','NOT_EXPORTED'}:raise ValueError('BAD_IMPORT_RESULT')
    return rows


def read_config(p:Path):
    d={}
    for line in p.read_text(encoding='utf8').splitlines():
        x=re.fullmatch(r'(CONFIG_[A-Za-z0-9_]+)=(.*)',line)
        if x:d[x.group(1)]=x.group(2)
        y=re.fullmatch(r'# (CONFIG_[A-Za-z0-9_]+) is not set',line)
        if y:d[y.group(1)]='n'
    return d


def status(expected, actual):
    return 'NOT_EXPORTED' if actual is None else ('MATCH' if expected==actual else 'CRC_MISMATCH')


def analyze(root:Path,verify=True):
    if verify:check_bundle(root)
    ref=root/'reference'
    s6=parse_symvers(ref/'R6_Module.symvers');s8=parse_symvers(ref/'R8_Module.symvers')
    old=json.loads((ref/'R6_CANDIDATE_ABI_REPORT.json').read_text())
    new=json.loads((ref/'R8_ABI_REPORT.json').read_text())
    m=json.loads((ref/'R60_MODULE_METADATA.json').read_text())
    stock=read_config(ref/'STOCK.config'); cand=read_config(ref/'R6_CANDIDATE.config'); r8conf=read_config(ref/'R8_CANDIDATE.config')
    if cand!=r8conf or sha(ref/'R6_CANDIDATE.config')!=sha(ref/'R8_CANDIDATE.config'):raise ValueError('CONFIG_DRIFT_R6_R8')
    checks={'CONFIG_SCHED_WALT':('y',None),'CONFIG_QGKI':('y','y'),'CONFIG_MODVERSIONS':('y','y'),'CONFIG_CFI_CLANG':('y','y'),'CONFIG_LTO_CLANG':('y','y'),'CONFIG_NR_CPUS':('32','32')}
    for name,(expected,actual) in checks.items():
        if stock.get(name)!=expected or cand.get(name)!=actual:raise ValueError('SOURCE_CONFIG_DRIFT:'+name)
    if (m['loaded_module_count_snapshot'] != 0 or m['schema'] != 'VEUX_R60_MODULE_METADATA_READONLY'
        or len(m['module_load_files']['/vendor/lib/modules/modules.load']) != 38):
        raise ValueError('LOAD_SNAPSHOT_DRIFT')
    common=set(s6)&set(s8);changed={x for x in common if s6[x]!=s8[x]}
    if len(s6)!=14255 or len(s8)!=14259 or len(changed)!=8638 or len(set(s8)-set(s6))!=4:
        raise ValueError('EXPORT_BASELINE_DRIFT')
    results={}; module_summaries={}; groups={};status_changes={}
    for cohort,(cnt,modct,match0,mismatch0,missing0) in BASE_EXPECTED.items():
        rows=read_imports(ref/f'R6_{cohort}_IMPORT_ABI.csv')
        expected_by_mod=collections.defaultdict(list);sym_by_mod=collections.defaultdict(set)
        transitions=collections.Counter();by_symbol=collections.defaultdict(list)
        for r in rows:
            symbol=r['symbol']; expected=r['expected_crc'];sb=status(expected,s6.get(symbol));sa=status(expected,s8.get(symbol));
            if r['result']!=sb or r['candidate_crc']!=(s6.get(symbol) or ''):
                raise ValueError('SOURCE_IMPORT_BASELINE_MISMATCH')
            transitions[(sb,sa)]+=1
            expected_by_mod[r['module']].append((symbol,sb,sa));by_symbol[symbol].append((r['module'],sb,sa,expected,s6.get(symbol),s8.get(symbol)))
        if len(rows)!=cnt or len(expected_by_mod)!=modct:raise ValueError('IMPORT_COUNTS_CHANGED:'+cohort)
        counts0=collections.Counter(s for r in expected_by_mod.values() for _,s,_ in r)
        counts8=collections.Counter(s for r in expected_by_mod.values() for _,_,s in r)
        if tuple(counts0[x] for x in ('MATCH','CRC_MISMATCH','NOT_EXPORTED'))!=(match0,mismatch0,missing0):
            raise ValueError('R6_HISTORIC_COUNTS_CHANGED:'+cohort)
        if (old[cohort]['match']!=match0 or old[cohort]['crc_mismatch']!=mismatch0 or old[cohort]['not_exported']!=missing0):
            raise ValueError('R6_REPORT_DRIFT')
        if tuple(counts8[x] for x in ('MATCH','CRC_MISMATCH','NOT_EXPORTED'))!=(new[cohort]['R8_match'],new[cohort]['R8_crc_mismatch'],new[cohort]['R8_missing']):
            raise ValueError('R8_REPORT_DRIFT')
        per_module=[]
        loadlist=m['module_load_files']['/vendor/lib/modules/modules.load' if cohort=='QGKI' else '/vendor/lib/modules/5.4-gki/modules.load']
        loadset=set(loadlist)
        in_loader=0;only_layout=[]
        for path,v in sorted(expected_by_mod.items()):
            basename=path.rsplit('/',1)[-1]
            bad=[(s,oldstate) for s,oldstate,_ in v if oldstate!='MATCH']
            only=bool(len(bad)==1 and bad[0][0]=='module_layout' and bad[0][1]=='CRC_MISMATCH')
            if only:only_layout.append(basename)
            if basename in loadset:in_loader+=1
            per_module.append({'module':basename,'imports':len(v),'r6_match':sum(s=='MATCH' for _,s,_ in v),
             'r6_wrong_crc':sum(s=='CRC_MISMATCH' for _,s,_ in v),
             'r6_missing':sum(s=='NOT_EXPORTED' for _,s,_ in v),
             'r8_match':sum(s=='MATCH' for _,_,s in v),
             'r8_wrong_crc':sum(s=='CRC_MISMATCH' for _,_,s in v),
             'r8_missing':sum(s=='NOT_EXPORTED' for _,_,s in v),
             'bad_without_module_layout':sum(s!='MATCH' and name!='module_layout' for name,s,_ in v),
             'module_layout_only_blocker':only,
             'present_in_load_file':basename in loadset,
             'present_in_sys_module_snapshot':basename.removesuffix('.ko') in m['sys_module_names_snapshot']})
        if cohort=='QGKI' and (in_loader!=37 or only_layout!=['q6_pdr_dlkm.ko']):raise ValueError('QGKI_LOADER_OR_LAYOUT_MISMATCH')
        group=[]
        for symbol,records in by_symbol.items():
            bad=[r for r in records if r[1]!='MATCH']
            if not bad:continue
            group.append({'symbol':symbol,'modules_with_blocker':len({r[0] for r in bad}),
              'import_occurrences':len(bad),
              'type':'MISSING' if all(x[1]=='NOT_EXPORTED' for x in bad) else 'CRC_MISMATCH',
              'r6_crc':s6.get(symbol,''),'r8_crc':s8.get(symbol,''),
              'crc_changed_r6_to_r8':s6.get(symbol)!=s8.get(symbol),
              'example_modules':';'.join(sorted({r[0].rsplit('/',1)[-1] for r in bad})[:7])})
        group.sort(key=lambda v:(-v['modules_with_blocker'],-v['import_occurrences'],v['symbol']))
        results[cohort]={'import_occurrences':len(rows),'module_files':len(per_module),
           'r6_matches':counts0['MATCH'],'r8_matches':counts8['MATCH'],
           'r6_wrong_crc':counts0['CRC_MISMATCH'],'r8_wrong_crc':counts8['CRC_MISMATCH'],
           'r6_missing':counts0['NOT_EXPORTED'],'r8_missing':counts8['NOT_EXPORTED'],
           'export_crc_changed_symbols_used':len(set(by_symbol)&changed),
           'export_crc_changed_import_occurrences':sum(r['symbol'] in changed for r in rows),
           'module_layout_only_files':only_layout,
           'module_files_in_loader':in_loader,
           'observed_sys_module_names_in_cohort':sum(x['present_in_sys_module_snapshot'] for x in per_module),
           'fully_compatible_r8':sum(x['r8_wrong_crc']==0 and x['r8_missing']==0 for x in per_module),
           'transitions':{f'{a}_TO_{b}':v for (a,b),v in sorted(transitions.items())}}
        module_summaries[cohort]=per_module;groups[cohort]=group
    summary={
     'schema':'VEUX_STOCK_R9_ABI_ROOT_CAUSE_AUDIT',
     'flash_allowed':False,'source_patch_allowed':False,'kernel_build_performed':False,
     'target_stock_release':'5.4.274-qgki-g82179e362f33',
     'source_reproduction_verified':False,'module_runtime_compatibility_verified':False,
     'loaded_module_cohort_verified':False,
     'candidate_source_release':'5.4.268',
     'R6_exports':len(s6),'R8_exports':len(s8),'common_export_names':len(common),
     'common_export_crc_changed':len(changed),'R8_new_exports':len(set(s8)-set(s6)),
     'R6_R8_configs_byte_identical':True,
     'config_stock_SCHED_WALT':stock.get('CONFIG_SCHED_WALT'),
     'config_candidate_SCHED_WALT':cand.get('CONFIG_SCHED_WALT','(absent)'),
     'config_stock_QGKI':stock.get('CONFIG_QGKI'),
     'module_load_metadata_snapshot':'2026-11-04T10:13:15Z',
     'proc_modules_snapshot_count':m['loaded_module_count_snapshot'],
     'QGKI':results['QGKI'],'GKI':results['GKI']}
    assert results['QGKI']['r8_matches']==1470 and results['QGKI']['r6_matches']==1470
    assert results['GKI']['r8_matches']==5486
    return summary,groups,module_summaries


def write_csv(path,rows):
    if not rows:return
    with path.open('w',encoding='utf8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def write_report(root,out):
    summary,groups,modules=analyze(root)
    out.mkdir(parents=True,exist_ok=True)
    (out/'R9_ABI_GESAMT.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf8')
    for cohort in ('QGKI','GKI'):
        write_csv(out/f'R9_{cohort}_MODULE_PRIORITAET.csv',modules[cohort])
        write_csv(out/f'R9_{cohort}_SYMBOLE_GRUPPIERT.csv',groups[cohort])
    q=summary['QGKI'];g=summary['GKI'];top=groups['QGKI'][:12]
    lines=['# VEUX R9 – unabhängiger Offline-ABI-Ursachenbericht','',
      '**Status: NOFLASH.** Keine Quelländerung, kein neues Kernel-Image, kein Boot-Test.\n',
      '## Gesicherte Messergebnisse',
      f'- R6: {summary["R6_exports"]} Exporte; R8: {summary["R8_exports"]}. Von {summary["common_export_names"]} gemeinsamen Symbolen änderten {summary["common_export_crc_changed"]} die CRC.',
      f'- QGKI: {q["r6_matches"]} → {q["r8_matches"]} passende Importe; {q["r8_wrong_crc"]} falsche CRCs und {q["r8_missing"]} nicht exportierte Importe.',
      f'- GKI: {g["r6_matches"]} → {g["r8_matches"]} passende Importe; {g["r8_wrong_crc"]} falsche CRCs und {g["r8_missing"]} nicht exportierte Importe.',
      f'- {q["export_crc_changed_symbols_used"]} unterschiedliche QGKI-Symbole ({q["export_crc_changed_import_occurrences"]} Importvorkommen) änderten ihre Kandidaten-CRC, **ohne einen QGKI-Importstatus zu verbessern**.',
      '- Alle 37 QGKI-Moduldateien sind mit der gesicherten `/vendor/lib/modules/modules.load` namentlich abgeglichen.',
      '- R60 meldete `/proc/modules` mit 0 Einträgen. Das beweist nicht, dass keine Module zur Laufzeit nötig sind; `/sys/module` enthält auch Built-ins.',
      f'- `module_layout` ist alleiniger R6-Blocker nur bei: {", ".join(q["module_layout_only_files"])}. Bei den übrigen 36 QGKI-Modulen bleiben zusätzliche Konflikte.',
      '- `CONFIG_SCHED_WALT=y` ist im Original nachgewiesen, im aufgelösten Spender-Kconfig fehlt diese Option. WALT-Quellimplementierung und ABI sind damit **nicht** nachgewiesen.',
      '', '## Häufigste QGKI-Gemeinsamkeiten (keine bewiesenen gemeinsamen Ursachen)',
      '| Symbol | Betroffene QGKI-Module | Importvorkommen |','|---|---:|---:|']
    lines += [f'| `{r["symbol"]}` | {r["modules_with_blocker"]} | {r["import_occurrences"]} |' for r in top]
    lines += ['', '## Entscheidung und Reihenfolge',
      '1. **R6 als unveränderte ABI-Referenz beibehalten.** R8 ist ein erfolgreicher Kompilierungsversuch, keine QGKI-Verbesserung.',
      '2. **Originalquellen für WALT, `struct module` und die OEM-Gerätefunktionen zusammenhängend nachweisen**, mit gepinnten Commit-Hashes. WALT-Kconfig-Fragmente allein reichen nicht.',
      '3. **QGKI-Modulladeliste und Laufzeitpriorität getrennt bewerten**; besonders WLAN, Mobilfunk, Kamera, Energieversorgung, Audio. `modules.load` ist ein Indiz, keine Live-Ladebestätigung.',
      '4. **Erst nach kohärenter Quellkorrektur neu bauen**, dann `Module.symvers` gegen alle 37 QGKI-Dateien vergleichen. Keine CRC-Fälschung, keine Dummy-Exporte und keine erzwungenen Modul-Ladevorgänge.',
      '', '## Grenzen',
      'Dieses Paket wertet historische Modulimports, zwei kompilierte `Module.symvers` und ein Geräte-Metadatenprotokoll aus. Es kann weder die volle Stock-Quelle rekonstruieren noch Bootfähigkeit, Modul-Laufzeitsicherheit, aktive Ladeliste oder ABI-Freigabe bestätigen.',
      '','## Quellen',
      '- GitHub R6: https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42031451479',
      '- GitHub R8: https://github.com/Chrizz100/veux-nongki-universal-kernel/actions/runs/42066038148',
      '- R60: geräteeigene read-only-Aufnahme vom 04.11.2026, SHA-256 im `reference/R60_MODULE_METADATA.json`',
      '- Donor: https://github.com/dereference23/kernel_xiaomi_sm6375 , Commit `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`.',
      '']
    (out/'R9_PRUEFBERICHT_DE.md').write_text('\n'.join(lines),encoding='utf8')
    (out/'R9_NOFLASH_GATE.json').write_text(json.dumps({'schema':'VEUX_R9_NOFLASH_GATE','source_patch_allowed':False,'flash_allowed':False,'boot_verified':False,'abi_green':False,'runtime_module_cohort_verified':False,'kernel_built_in_R9':False},indent=2)+'\n')
    hashes={p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file()}
    (out/'R9_SHA256SUMS.txt').write_text(''.join(f'{digest}  {name}\n' for name,digest in hashes.items()))
    return summary

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    r=write_report(args.root,args.out)
    print(json.dumps({'R9_STATUS':'READ_ONLY_DIAGNOSTICS_PASS','QGKI_MATCH':r['QGKI']['r8_matches'],
     'QGKI_MODULE_LAYOUT_ONLY':len(r['QGKI']['module_layout_only_files']),
     'R8_CRC_CHANGES':r['common_export_crc_changed'],'FLASH_ALLOWED':r['flash_allowed']}))
