# VEUX R46-R4 – Korrigierter RMNET-Built-in-Linknachweis (NOFLASH)

**Ausgangspunkt:** GitHub Run 42407210047, Job 128507384061, Commit `4006e996abbb0cb7e3b85924042e73314cb27d3f`.

**Befund:** Nach unverändertem, grünem R46-R2-Basisbau hat der zweite ARM64-WALT-Build beide originalen R13-Built-in-Kbuild-Hunks übernommen. `make Image`, `make dtbs` und `make modules` endeten jeweils mit 0. Beide `built-in.a`-Archive und die echten SHS-/Offload-Initcalls erscheinen im `R47_Image_MAKE.log`. Der Job scheiterte anschließend **nicht am Compiler**, sondern an `R47_RMNET_NOT_IN_MODULES_BUILTIN`.

## Fehlerursache und Reparatur

In der gepinnten Linux-5.4-Quelle (`scripts/Makefile.modbuiltin`) wird `modules.builtin` aus `obj-Y` (Konfigurations-Tristate Y) erzeugt. Die **bytegenauen historischen R13-Hunks** verwenden jedoch unbedingtes `obj-y += rmnet_shs.o` und `obj-y += rmnet_offload.o`. Diese können tatsächlich gelinkt werden, ohne als die zwei erwarteten `.ko`-Pfade in `modules.builtin` zu erscheinen.

Der neue Prüfer fordert deshalb:

1. Die beiden unveränderten historischen R13-Kbuild-Postimage-Hashes.
2. Ein von R46 verschiedenes ARM64-`Image`, ein ARM64-`vmlinux`, korrekte `.config` und unveränderten experimentellen Release.
3. `System.map` enthält **genau einmal** die initcall6-Symbole aus SHS (`DATARMNET163e93649e`), Offload (`DATARMNETb1c42acd9c`) und RMNET-Core (`rmnet_init`), jeweils **innerhalb des tatsächlichen initcall6-Adressbereichs**.
4. Das echte Buildlog nennt die zwei Built-in-Archive, `LTO vmlinux.o`, `MODPOST vmlinux.o` und `OBJCOPY Image`.
5. Die ursprünglichen zwei `.ko` sind **nicht mehr in `modules.order`**, die anderen vier Module bleiben erhalten.
6. Der gepinnte `llvm-nm` wird unter demselben bereits festgelegten LLVM-Toolchainverzeichnis im `PATH` der Kind-Shells verfügbar gemacht; ein fehlendes `llvm-nm` ist ein harter Fehler.

`modules.builtin` und `modules.builtin.modinfo` bleiben als Diagnose verfügbar, **nicht** als zwingender Nachweis. Der R46-R3-Lauf enthielt 16 `/bin/sh: llvm-nm: not found`-Meldungen und 3624 `ld.lld`-Warnungen zur Initcall-Sektionsplatzierung. Letztere werden gezählt und als **offener Prüfpunkt** dokumentiert; keine Behauptung eines warnungsfreien Kernelbaus.

## GitHub-Upload

- `VEUX_R46_R4_R13_BUILTIN_MAIN.zip` unverändert in das Repo-Hauptverzeichnis `main`.
- `VEUX_R46_R4_R13_BUILTIN_LINK_PROOF_NOFLASH.yml` in `.github/workflows/`.
- Workflow `VEUX R46-R4 R13 original RMNET builtins genuine WALT System.map proof - NO FLASH` starten.

**Einschränkung:** R46-Baseline wird neu kompiliert, dann ausschließlich zwei historische `obj-m`→`obj-y`-Hunks in einer Wegwerfquelle übernommen. Keine Änderungen am unveränderlichen P13, an der originalen Xiaomi-Kernelkennung `5.4.274-qgki-g82179e362f33`, an OEM-Vendor-Modulen oder Rootkomponenten. Der experimentelle R46-Release `5.4.274~positron` bleibt unverändert. Kein boot.img, kein AK3, kein Flash. OEM-ABI, funktionale Initcall-Reihenfolge und Geräteboot **nicht nachgewiesen**.

**Grüner GitHub-Workflow ist kein Stock-/Flash-Green-Pass.** Die verbleibenden 3624 LLD-Initcall-Warnungen sind vor einer Bootfreigabe separat zu untersuchen.
