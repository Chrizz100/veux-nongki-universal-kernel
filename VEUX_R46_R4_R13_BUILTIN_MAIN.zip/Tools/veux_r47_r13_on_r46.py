#!/usr/bin/env python3
"""VEUX: ONLY verified historical R13 RMNET Built-in hunks on disposable R46 WALT snapshot.

Two build stages: archived successful R46 full build first (in workflow), then
this separate in-place re-link experiment. Never edits GitHub checkout,
firmware, kernel release metadata, or a device. Never produces a flashable zip.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import time

SCHEMA = 'VEUX_R47_R13_ORIGINAL_TWO_HUNKS_ON_R46_WALT_V1'
STOCK_RELEASE = '5.4.274-qgki-g82179e362f33'  # immutable REFERENCE, never written
R46_EFFECTIVE_CONFIG_SHA256 = '7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe'
CONFIG_MARKERS = {'CONFIG_SCHED_WALT': 'y', 'CONFIG_MODULES': 'y',
                  'CONFIG_MODVERSIONS': 'y', 'CONFIG_QGKI': 'y'}
FILES = {
    'shs': {
        'path': 'techpack/datarmnet-ext/shs/Kbuild',
        'module': 'rmnet_shs',
        'pre_sha': 'd925c55928bf8a71b262e6ae190e9a781db31df69231b10ab2c303e55871624d',
        'post_sha': '47e131453e5cb1ea83e557908ea65a95da76cd3d67e6b573b7e6e992091874df',
    },
    'offload': {
        'path': 'techpack/datarmnet-ext/offload/Kbuild',
        'module': 'rmnet_offload',
        'pre_sha': 'a129f77f785bd5e0f2bfd84356b6fdd44a9d341622dcc8c4c06c325cfdbb01f4',
        'post_sha': '0e41e01735746fe14d6ed79df0926263dccbcc5ea5d3926f76527ff553443618',
    },
}
ORIGINAL_MODULE_PATHS = {
    'techpack/datarmnet-ext/shs/rmnet_shs.ko',
    'techpack/datarmnet-ext/offload/rmnet_offload.ko',
}
OTHER_MODULE_PATHS = {
    'drivers/bluetooth/bt_fm_slim.ko',
    'drivers/bluetooth/btpower.ko',
    'drivers/char/rdbg.ko',
    'drivers/media/rc/ir-spi.ko',
}


class GateError(Exception):
    pass


def require(ok, message):
    if not ok:
        raise GateError(message)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for buf in iter(lambda: f.read(1048576), b''):
            h.update(buf)
    return h.hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def kernel_config(path):
    return Path(path).read_text(encoding='utf-8', errors='replace')


def config_assert(text):
    kv = {}
    for line in text.splitlines():
        match = re.fullmatch(r'CONFIG_([A-Z0-9_]+)=(.*)', line)
        if match:
            kv['CONFIG_'+match.group(1)] = match.group(2)
        else:
            match = re.fullmatch(r'# (CONFIG_[A-Z0-9_]+) is not set', line)
            if match:
                kv[match.group(1)] = 'n'
    for key, expected in CONFIG_MARKERS.items():
        require(kv.get(key) == expected, 'CONFIG_DRIFT:'+key+':'+str(kv.get(key)))
    require(kv.get('CONFIG_SCHED_CASS') != 'y', 'CASS_CANNOT_BE_ENABLED_IN_WALT_PROBE')
    for key in ('CONFIG_KSU', 'CONFIG_KSU_SUSFS', 'CONFIG_SUSFS', 'CONFIG_NOMOUNT', 'CONFIG_KSU_MANUAL_HOOK'):
        require(kv.get(key) != 'y' and kv.get(key) != 'm', 'ROOT_COMPONENT_ENABLED:'+key)
    return kv


def expected_postimage(blob, spec):
    old = ('obj-m += '+spec['module']+'.o').encode()
    new = ('obj-y += '+spec['module']+'.o').encode()
    require(blob.count(old) == 1, 'SOURCE_TARGET_NOT_EXACTLY_ONCE:'+spec['path'])
    result = blob.replace(old, new, 1)
    require(sha_bytes(result) == spec['post_sha'], 'R13_POSTIMAGE_HASH_MISMATCH:'+spec['path'])
    require(blob.count(b'KBUILD_EXTRA_SYMBOLS') == result.count(b'KBUILD_EXTRA_SYMBOLS'),
            'UNAUTHORIZED_CHANGE_TO_EXTRA_SYMBOLS')
    return result


def validate_pinned_source(source):
    """Prove ALL preimages before returning any replacement; no writes on errors."""
    base = Path(source).resolve(strict=True)
    planned = {}
    for spec in FILES.values():
        target = base / spec['path']
        require(target.is_file() and not target.is_symlink(), 'SOURCE_MISSING_OR_SYMLINK:'+spec['path'])
        require(target.resolve(strict=True).is_relative_to(base), 'SOURCE_ESCAPE:'+spec['path'])
        original = target.read_bytes()
        require(sha_bytes(original) == spec['pre_sha'], 'SOURCE_SHA_MISMATCH:'+spec['path'])
        post = expected_postimage(original, spec)
        planned[spec['path']] = (target, original, post)
    return planned


def apply_two_hunks(source):
    planned = validate_pinned_source(source)
    # Both files proved before the first write. Roll back on I/O failures.
    committed = []
    try:
        for path, (target, before, after) in planned.items():
            target.write_bytes(after)
            committed.append((target, before))
            require(sha_file(target) == FILES[path.split('/')[-2]]['post_sha'],
                    'SOURCE_POSTWRITE_HASH_MISMATCH:'+path)
    except Exception:
        for target, old in committed:
            target.write_bytes(old)
        raise
    return [{'path':path,'original_sha256':sha_bytes(old),'new_sha256':sha_bytes(new),
             'same_byte_length':len(old) == len(new),'historical_r13_exact_byte_match':True}
            for path,(_,old,new) in planned.items()]


def validate_r46_baseline(baseline, warnings, source, objout):
    original = load_json(baseline)
    repair = load_json(warnings)
    require(original.get('full_image_proven') is True and original.get('vmlinux_linked') is True,
            'R46_FULL_BUILD_NOT_PROVEN')
    require(original.get('vendor_abi_proven') is False and original.get('flash_allowed') is False,
            'R46_BASELINE_UNEXPECTED_RELEASE_CLAIM')
    require(repair.get('status') == 'R46_FIVE_WARNINGS_FIXED_BUILD_PASS_NOFLASH'
            and repair.get('old_warning_occurrences_after_rebuild') == 0,
            'R46_SOURCE_WARNING_FIXES_NOT_PROVEN')
    modules = {x['path'] for x in original['module_files']}
    require(modules == ORIGINAL_MODULE_PATHS | OTHER_MODULE_PATHS,
            'R46_SIX_BASELINE_MODULES_CHANGED')
    cfg = Path(objout)/'.config'
    require(cfg.is_file() and sha_file(cfg) == R46_EFFECTIVE_CONFIG_SHA256,
            'R46_EFFECTIVE_CONFIG_SHA_MISMATCH')
    config_assert(kernel_config(cfg))
    require(sha_file(Path(objout)/'arch/arm64/boot/Image') == original['image']['sha256'],
            'R46_BASELINE_IMAGE_HASH_MISMATCH')
    require(sha_file(Path(objout)/'Module.symvers') == original['module_symvers_sha256'],
            'R46_BASELINE_SYMVERS_HASH_MISMATCH')
    make_targets = original['make_targets']
    validated = {}
    for target in ('Image','dtbs','modules'):
        spec = make_targets[target]
        argv = spec['invocation']
        require(spec.get('exit_code') == 0 and isinstance(argv,list), 'R46_MAKE_NOT_GREEN:'+target)
        require(argv[0] == 'make' and argv[-1] == target and '-j2' in argv,
                'R46_MAKE_COMMAND_INVALID:'+target)
        require('-C' in argv and Path(argv[argv.index('-C')+1]).resolve(strict=True)
                == Path(source).resolve(strict=True), 'R46_WRONG_SOURCE_CWD')
        require('O='+str(Path(objout).resolve(strict=True)) in argv,'R46_WRONG_OUTPUT_DIR')
        for prefix in ('ARCH=arm64','LLVM=1','LLVM_IAS=1','CC=','LD=','AR=','NM=','OBJCOPY='):
            require(any(x==prefix or x.startswith(prefix) for x in argv),
                    'R46_MISSING_PINNED_TOOL:'+prefix)
        validated[target] = argv
    return original,validated


def safe_log(out, target):
    p=Path(out)/('R47_'+target+'_MAKE.log')
    return p


def pinned_llvm_tool_env(argv):
    """Only expose the already pinned LLVM tools to Kbuild's child shells.

    Linux 5.4 may execute `llvm-nm` by its bare name, even when the top-level
    make invocation also supplies an absolute NM= path.  The failed R46-R3
    build had 15 such /bin/sh warnings despite a zero make exit code.
    """
    nm_args = [x.removeprefix('NM=') for x in argv if x.startswith('NM=')]
    require(len(nm_args) == 1, 'PINNED_LLVM_NM_NOT_SPECIFIED')
    nm = Path(nm_args[0])
    require(nm.is_absolute() and nm.name == 'llvm-nm', 'PINNED_LLVM_NM_INVALID')
    require(nm.is_file() and os.access(nm, os.X_OK), 'PINNED_LLVM_NM_NOT_EXECUTABLE')
    env = os.environ.copy()
    env['PATH'] = str(nm.parent) + os.pathsep + env.get('PATH', '')
    return env


def invoke_exact_make(argv, out, target, timeout_seconds=1500):
    p = safe_log(out,target)
    started=time.monotonic()
    try:
        with p.open('wb') as f:
            r = subprocess.run(argv, stdout=f, stderr=subprocess.STDOUT,
                               timeout=timeout_seconds, check=False)
        ret=r.returncode; timeout=False
    except subprocess.TimeoutExpired:
        ret=124; timeout=True
    duration=round(time.monotonic()-started,2)
    return {'target':target,'exit_code':ret,'timed_out':timeout,
            'seconds':duration,'log_sha256':sha_file(p),
            'log_size':p.stat().st_size,'invocation':argv}


def is_arm64_image(p):
    with Path(p).open('rb') as f:
        f.seek(0x38)
        return f.read(4) == b'ARM\x64'


def is_arm64_elf(p):
    with Path(p).open('rb') as f:
        b=f.read(20)
    return len(b)==20 and b[:4]==b'\x7fELF' and b[4]==2 and b[5]==1 and struct.unpack('<H',b[18:20])[0]==183


def normalize_module_lines(path):
    p=Path(path)
    require(p.is_file(),'MISSING_KBUILD_MODULE_LIST:'+str(p))
    # Kbuild uses relative paths, occasionally prefixed with ./
    return {line.removeprefix('./').strip() for line in p.read_text().splitlines() if line.strip()}


INITCALL_NAMES = {
    'rmnet_shs': 'DATARMNET163e93649e',
    'rmnet_offload': 'DATARMNETb1c42acd9c',
    'rmnet_core': 'rmnet_init',
}


def prove_real_linked_initcalls(system_map):
    """Prove exactly one linked initcall for each genuine driver in level 6.

    `modules.builtin` is not authoritative for this pinned Linux 5.4 Kbuild:
    scripts/Makefile.modbuiltin iterates obj-Y from tristate.conf, whereas
    the proven original R13 patch selects both objects via literal obj-y.
    """
    lines = Path(system_map).read_text(encoding='utf-8', errors='replace').splitlines()
    names = {}
    for row in lines:
        fields = row.split()
        if len(fields) != 3 or not re.fullmatch(r'[0-9a-fA-F]+', fields[0]):
            continue
        address, kind, symbol = fields
        names.setdefault(symbol, []).append((int(address,16),kind))
    def one(name):
        matches=names.get(name, [])
        require(len(matches)==1,'R47_EXPECT_ONE_SYMBOL:'+name+':'+str(len(matches)))
        return matches[0][0]
    begin=one('__initcall6_start')
    end=one('__initcall7_start')
    require(begin < end, 'R47_INVALID_INITCALL6_ADDRESS_RANGE')
    result={}
    for module, fn in INITCALL_NAMES.items():
        # clang LTO decorates the __initcall label with source-file and line IDs.
        candidates=[(name,val) for name,vals in names.items()
                    if re.fullmatch(r'__initcall_[0-9]+_[0-9]+_'+re.escape(fn)+r'6',name)
                    for val in vals]
        require(len(candidates)==1,'R47_EXPECT_EXACT_ONE_LINKED_INITCALL:'+module+':'+str(len(candidates)))
        name,(address,typ)=candidates[0]
        require(begin <= address < end, 'R47_INITCALL_OUTSIDE_LEVEL6:'+module)
        require(typ in ('d','D'), 'R47_INITCALL_SYMBOL_NOT_DATA:'+module)
        result[module]={'symbol':name, 'address_hex':hex(address),
                        'section_range':'initcall6','symbol_type':typ}
    return result


def prove_build_log(image_log):
    """Require real compiler, built-in archive and final Image link traces."""
    log=Path(image_log).read_text(encoding='utf-8',errors='replace')
    wanted=[
        'CC      techpack/datarmnet-ext/shs/rmnet_shs_config.o',
        'CC      techpack/datarmnet-ext/offload/rmnet_offload_state.o',
        'AR      techpack/datarmnet-ext/shs/built-in.a',
        'AR      techpack/datarmnet-ext/offload/built-in.a',
        'LTO     vmlinux.o',
        'MODPOST vmlinux.o',
        'OBJCOPY arch/arm64/boot/Image',
    ]
    for token in wanted:
        require(token in log, 'R47_REAL_LINK_TRACE_NOT_FOUND:'+token)
    missing_llvm_nm=sum('llvm-nm: not found' in line for line in log.splitlines())
    require(missing_llvm_nm==0,'R47_LLVM_NM_MISSING_DURING_LINK:'+str(missing_llvm_nm))
    ld_warnings=sum('ld.lld: warning:' in line for line in log.splitlines())
    return {'all_real_build_traces_seen':True, 'required_trace_count':len(wanted),
            'missing_llvm_nm_errors':missing_llvm_nm,
            'linker_warnings_requires_review':ld_warnings,
            'linker_warning_free':ld_warnings==0}


def verify_relink_result(objout, baseline, before_release, before_cfg, before_system_map_sha=None,
                         image_log=None):
    out=Path(objout)
    cfg=out/'.config'
    require(sha_file(cfg)==before_cfg==R46_EFFECTIVE_CONFIG_SHA256,'CONFIG_CHANGED_DURING_R47_LINK')
    config_assert(kernel_config(cfg))
    release_file=out/'include/config/kernel.release'
    require(release_file.is_file() and release_file.read_text().strip()==before_release,
            'KERNEL_RELEASE_CHANGED_DURING_R47_LINK')
    image=out/'arch/arm64/boot/Image'
    vmlinux=out/'vmlinux'
    dtb=out/'arch/arm64/boot/dts/vendor/xiaomi/veux.dtb'
    sym=out/'Module.symvers'
    require(is_arm64_image(image),'R47_IMAGE_NOT_ARM64')
    require(is_arm64_elf(vmlinux),'R47_VMLINUX_NOT_ARM64_ELF')
    require(dtb.is_file() and dtb.read_bytes()[:4]==b'\xd0\x0d\xfe\xed','R47_DTB_NOT_FDT')
    require(sym.is_file() and sym.stat().st_size>50000,'R47_MISSING_SYMVERS')
    require(sha_file(image)!=baseline['image']['sha256'], 'R47_IMAGE_UNCHANGED_NO_BUILTIN_LINK_PROOF')
    if isinstance(baseline.get('dtb'),dict) and baseline['dtb'].get('sha256'):
        require(sha_file(dtb)==baseline['dtb']['sha256'],'R47_DTB_DRIFT_IN_RMNET_ONLY_TEST')
    new_modules=normalize_module_lines(out/'modules.order')
    require(ORIGINAL_MODULE_PATHS.isdisjoint(new_modules),'R47_RMNET_STILL_EXTERNAL_IN_MODULE_ORDER')
    require(OTHER_MODULE_PATHS.issubset(new_modules),'R47_OTHER_FOUR_MODULES_MISSING')
    map_file=out/'System.map'
    require(map_file.is_file(), 'R47_MISSING_SYSTEM_MAP')
    if before_system_map_sha is not None:
        require(sha_file(map_file)!=before_system_map_sha,'R47_SYSTEM_MAP_UNCHANGED')
    proven_initcalls=prove_real_linked_initcalls(map_file)
    logproof=prove_build_log(image_log) if image_log is not None else None
    # Original R13 literal obj-y entries do not populate all variants of
    # modules.builtin: 5.4 scripts/Makefile.modbuiltin tracks obj-Y only.
    builtin_path=out/'modules.builtin'
    builtin_entries=normalize_module_lines(builtin_path) if builtin_path.is_file() else set()
    info=out/'modules.builtin.modinfo'
    return {
        'release_unchanged':before_release,
        'config_sha256':sha_file(cfg),
        'image_sha256':sha_file(image),
        'vmlinux_sha256':sha_file(vmlinux),
        'system_map_sha256':sha_file(map_file),
        'dtb_sha256':sha_file(dtb),
        'module_symvers_sha256':sha_file(sym),
        'built_in_rmnet_initcall_proven':proven_initcalls,
        'genuine_link_log_proof':logproof,
        'built_in_rmnet_requested':sorted(ORIGINAL_MODULE_PATHS),
        'modules_builtin_metadata_only_matches':sorted(ORIGINAL_MODULE_PATHS & builtin_entries),
        'modules_builtin_metadata_not_authoritative_for_literal_obj_y':True,
        'modules_builtin_modinfo_contains':{name:(info.is_file() and name.encode() in info.read_bytes())
                                            for name in ('rmnet_shs','rmnet_offload')},
        'external_original_rmnet_in_modules_order':sorted(ORIGINAL_MODULE_PATHS & new_modules),
        'external_other_four':sorted(OTHER_MODULE_PATHS),
        'verified_other_four':sorted(OTHER_MODULE_PATHS & new_modules),
        'stale_rmnet_ko_may_remain_from_previous_build':True,
        'initcall_boot_order_and_runtime_not_certified':True,
        'vendor_abi_proven':False,
        'flash_allowed':False,
    }


def do_build(args):
    source=Path(args.source).resolve(strict=True)
    objout=Path(args.objout).resolve(strict=True)
    output=Path(args.output).resolve()
    require(not output.exists(),'R47_OUTPUT_ALREADY_EXISTS')
    require(source != objout,'R47_SOURCE_AND_OBJOUT_SAME')
    require(source != Path(args.project).resolve(strict=True), 'R47_REFUSE_PROJECT_SOURCE_MUTATION')
    require(source.is_relative_to(Path(os.environ.get('GITHUB_WORKSPACE','/INVALID')).resolve()),
            'R47_SOURCE_OUTSIDE_GITHUB_EPHEMERAL_WORKSPACE')
    baseline, commands=validate_r46_baseline(args.baseline,args.r46,source,objout)
    original_release=(objout/'include/config/kernel.release').read_text().strip()
    require(original_release and original_release != STOCK_RELEASE,
            'R47_CANNOT_IMPERSONATE_STOCK_RELEASE')
    before_cfg=sha_file(objout/'.config')
    baseline_system_map=sha_file(objout/'System.map')
    planned=validate_pinned_source(source)
    output.mkdir(parents=True,exist_ok=False)
    summary={'schema':SCHEMA,'status':'R47_LINK_PENDING','original_stock_release_reference':STOCK_RELEASE,
             'experimental_release_before':original_release, 'r46_baseline_image_sha256':baseline['image']['sha256'],
             'r46_baseline_symvers_sha256':baseline['module_symvers_sha256'],
             'historical_r13_hunks':[],'make_results':[],'stock_vendor_abi_proven':False,
             'device_boot_tested':False,'flash_allowed':False,'repository_mutated':False}
    report=output/'R47_RESULT.json'
    try:
        summary['historical_r13_hunks']=apply_two_hunks(source)
        (output/'R47_HISTORICAL_TWO_HUNKS.json').write_text(json.dumps(summary['historical_r13_hunks'],indent=2)+'\n')
        for target in ('Image','dtbs','modules'):
            step=invoke_exact_make(commands[target],output,target)
            summary['make_results'].append(step)
            if step['exit_code']!=0:
                raise GateError('R47_ARM64_MAKE_FAILED:'+target+':'+str(step['exit_code']))
        result=verify_relink_result(objout,baseline,original_release,before_cfg,
                                    before_system_map_sha=baseline_system_map,
                                    image_log=output/'R47_Image_MAKE.log')
        summary.update(result)
        summary['status']='R47_R13_EXACT_BUILTIN_WALT_IMAGE_LINK_PROVEN_NOFLASH'
        (output/'R47_VERIFY_STATUS.txt').write_text('BUILTIN_WALT_LINK=PASS\nOEM_VENDOR_ABI=UNPROVEN\nDEVICE_BOOT=NO\nFLASH=NO\n')
        print('R47_R13_EXACT_TWO_HUNKS_LINKED_IN_WALT=PASS; IMAGE='+result['image_sha256']+'; NOFLASH')
    except Exception as e:
        summary['status']='R47_BUILTIN_RELINK_FAILED_NOFLASH'
        summary['error']=str(e)
        print('R47_FAIL_CLOSED: '+str(e),file=sys.stderr)
        raise
    finally:
        report.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
    return summary


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    sub=ap.add_subparsers(dest='operation',required=True)
    a=sub.add_parser('check-fixtures')
    a.add_argument('--fixtures',required=True)
    a=sub.add_parser('build')
    a.add_argument('--source',required=True);a.add_argument('--objout',required=True)
    a.add_argument('--baseline',required=True);a.add_argument('--r46',required=True)
    a.add_argument('--project',required=True);a.add_argument('--output',required=True)
    args=ap.parse_args(argv)
    if args.operation=='check-fixtures':
        base=Path(args.fixtures)
        for kind,spec in FILES.items():
            data=(base/(kind+'_Kbuild')).read_bytes()
            require(sha_bytes(data)==spec['pre_sha'],'FIXTURE_PREIMAGE_FAILED:'+kind)
            expected_postimage(data,spec)
        print('R13_ORIGINAL_BYTE_EXACT_TWO_HUNKS_VERIFIED=PASS')
    else:
        do_build(args)

if __name__=='__main__':
    try:
        main()
    except (GateError, OSError, ValueError, KeyError) as e:
        print('R47_BUILTIN_SOURCE_OR_BUILD_GATE_BLOCKED:'+str(e), file=sys.stderr)
        sys.exit(1)
