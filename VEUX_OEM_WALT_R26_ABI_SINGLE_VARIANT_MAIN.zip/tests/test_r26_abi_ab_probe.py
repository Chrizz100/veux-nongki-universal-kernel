"""R26 local/unit security and regression coverage; never executes a kernel build."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

P = Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('r26abi',P/'r26_abi_ab_probe.py')
r=importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
F=P/'fixtures'

class ReferenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.preflight=r.expected_reference(F)
        cls.baseline_text=(F/'R20_REAL_BUILD_CONFIG.config').read_text()
        cls.device_text=(F/'VEUX_R22_RUNNING_KERNEL_CONFIG.config').read_text()
        cls.symvers=r.symvers_map((F/'R20_REAL_Module.symvers').read_text())
        cls.imports=r.read_imports(F/'R21_IMPORTS.csv')

    def test_fixture_sha_all(self):
        for name,h in r.REFERENCE_HASHES.items():
            with self.subTest(name=name): self.assertEqual(r.sha256(F/name),h)

    def test_proven_run(self): self.assertEqual(r.PROVEN_RUN,39774000774)
    def test_proven_commit(self): self.assertEqual(len(r.PROVEN_COMMIT),40)
    def test_config_keys_count(self):
        self.assertEqual(self.preflight['baseline_config_keys'],5292)
        self.assertEqual(self.preflight['device_config_keys'],4664)
    def test_config_difference_879(self): self.assertEqual(self.preflight['config_diff_count'],879)
    def test_ref_symvers_14260(self): self.assertEqual(len(self.symvers),14260)
    def test_symvers_layout(self): self.assertEqual(self.symvers['module_layout'][0],'0x0bcef28c')
    def test_imports_14648(self): self.assertEqual(len(self.imports),14648)
    def test_replay_match(self): self.assertEqual(self.preflight['baseline_imports']['all']['MATCH'],6960)
    def test_replay_mismatch(self): self.assertEqual(self.preflight['baseline_imports']['all']['CRC_MISMATCH'],7653)
    def test_replay_absent(self): self.assertEqual(self.preflight['baseline_imports']['all']['ABSENT_IN_SYMVERS'],35)
    def test_qgki_matches(self): self.assertEqual(self.preflight['baseline_imports']['groups']['qgki']['MATCH'],1474)
    def test_qgki_mismatches(self): self.assertEqual(self.preflight['baseline_imports']['groups']['qgki']['CRC_MISMATCH'],1663)
    def test_qgki_absent(self): self.assertEqual(self.preflight['baseline_imports']['groups']['qgki']['ABSENT_IN_SYMVERS'],11)
    def test_gki_matches(self): self.assertEqual(self.preflight['baseline_imports']['groups']['5.4-gki']['MATCH'],5486)
    def test_gki_mismatch(self): self.assertEqual(self.preflight['baseline_imports']['groups']['5.4-gki']['CRC_MISMATCH'],5990)
    def test_gki_absent(self): self.assertEqual(self.preflight['baseline_imports']['groups']['5.4-gki']['ABSENT_IN_SYMVERS'],24)
    def test_localversion_equal(self):
        a=r.config_values(self.baseline_text);b=r.config_values(self.device_text)
        self.assertEqual(a['CONFIG_LOCALVERSION'],b['CONFIG_LOCALVERSION'])
    def test_pin_modversions_lto_cfi(self):
        cfg=r.config_values(self.baseline_text)
        for v in ('CONFIG_MODVERSIONS','CONFIG_LTO_CLANG','CONFIG_CFI_CLANG'):
            with self.subTest(v=v):self.assertEqual(cfg[v],'y')
    def test_required_walt(self): self.assertEqual(r.config_values(self.baseline_text)['CONFIG_SCHED_WALT'],'y')
    def test_two_vendor_groups(self):self.assertEqual(set(self.preflight['baseline_imports']['groups']),{'qgki','5.4-gki'})
    def test_real_r20_no_flash(self):
        obj=json.loads((F/'R20_BUILD_RESULT.json').read_text())
        self.assertTrue(obj['full_image_proven']);self.assertFalse(obj['vendor_abi_proven'])
        self.assertFalse(obj['flash_allowed']);self.assertTrue(obj['vmlinux_linked'])
    def test_real_r20_config_provenance(self):
        obj=json.loads((F/'R20_BUILD_RESULT.json').read_text())
        self.assertEqual(obj['provenance']['actual_objout_config_sha256'],r.REFERENCE_HASHES['R20_REAL_BUILD_CONFIG.config'])
    def test_sha_validator_source(self):self.assertEqual(r.sha256(F/'R20_REAL_Module.symvers'),r.REFERENCE_HASHES['R20_REAL_Module.symvers'])
    def test_r20_image_sane_report(self):
        obj=json.loads((F/'R20_BUILD_RESULT.json').read_text())
        self.assertTrue(obj['image']['arm64_header_ok']);self.assertTrue(obj['vmlinux']['aarch64_elf_ok'])

class NegativeTests(unittest.TestCase):
    def test_parse_config_set(self):self.assertEqual(r.config_values('CONFIG_X=y\n'),{'CONFIG_X':'y'})
    def test_parse_config_unset(self):self.assertEqual(r.config_values('# CONFIG_X is not set\n'),{'CONFIG_X':'n'})
    def test_parse_config_missing(self):
        with self.assertRaises(r.ProbeError):r.config_values('hi\n')
    def test_parse_config_duplicate_set(self):
        with self.assertRaises(r.ProbeError):r.config_values('CONFIG_X=y\nCONFIG_X=n\n')
    def test_parse_config_duplicate_set_unset(self):
        with self.assertRaises(r.ProbeError):r.config_values('CONFIG_X=y\n# CONFIG_X is not set\n')
    def test_delta_added(self):self.assertEqual(r.config_diff({'CONFIG_A':'y'},{'CONFIG_A':'y','CONFIG_B':'n'}),[('CONFIG_B',None,'n')])
    def test_delta_removed(self):self.assertEqual(r.config_diff({'CONFIG_A':'y'},{'CONFIG_B':'n'}),[('CONFIG_A','y',None),('CONFIG_B',None,'n')])
    def test_delta_unchanged(self):self.assertEqual(r.config_diff({'CONFIG_A':'y'},{'CONFIG_A':'y'}),[])
    def test_bad_variant(self):
        with self.assertRaises(r.ProbeError):r.config_variant('CONFIG_NR_CPUS=32\n','unknown')
    def test_bad_variant_preimage(self):
        with self.assertRaises(r.ProbeError):r.config_variant('CONFIG_NR_CPUS=8\n','nr_cpus_8')
    def test_variant_missing_key(self):
        with self.assertRaises(r.ProbeError):r.config_variant('CONFIG_ANY=y\n','nr_cpus_8')
    def test_nr_cpus_delta_only(self):
        text='\nCONFIG_NR_CPUS=32\nCONFIG_OTHER=y\n'
        updated=r.config_variant(text,'nr_cpus_8')
        self.assertEqual(r.config_diff(r.config_values(text),r.config_values(updated)),[('CONFIG_NR_CPUS','32','8')])
    def test_kabi_delta_only(self):
        text='\nCONFIG_ANDROID_KABI_RESERVE=y\nCONFIG_OTHER=y\n'
        updated=r.config_variant(text,'kabi_reserve_off')
        self.assertEqual(r.config_diff(r.config_values(text),r.config_values(updated)),[('CONFIG_ANDROID_KABI_RESERVE','y','n')])
    def test_oem_delta_only(self):
        text='\nCONFIG_ANDROID_VENDOR_OEM_DATA=y\nCONFIG_OTHER=y\n'
        updated=r.config_variant(text,'vendor_oem_data_off')
        self.assertIn('# CONFIG_ANDROID_VENDOR_OEM_DATA is not set',updated)
    def test_all_real_variants_one_change(self):
        old=(F/'R20_REAL_BUILD_CONFIG.config').read_text()
        for var in r.VARIANTS:
            with self.subTest(var=var):
                new=r.config_variant(old,var)
                self.assertEqual(len(r.config_diff(r.config_values(old),r.config_values(new))),1)
    def test_crc_map(self):self.assertEqual(r.symvers_map('0xaabbccdd\ttest\tvmlinux\tEXPORT_SYMBOL\t\n')['test'],('0xaabbccdd','vmlinux'))
    def test_reject_bad_crc(self):
        with self.assertRaises(r.ProbeError):r.symvers_map('0xBAD\tsym\tvmlinux\tEXPORT_SYMBOL\t\n')
    def test_reject_duplicate_crc_conflict(self):
        with self.assertRaises(r.ProbeError):r.symvers_map('0xaabbccdd\tsym\tvmlinux\tEXPORT_SYMBOL\t\n0x11223344\tsym\tvmlinux\tEXPORT_SYMBOL\t\n')
    def test_accept_exact_duplicate(self):self.assertEqual(len(r.symvers_map('0xaabbccdd\tsym\tvmlinux\tEXPORT_SYMBOL\t\n'*2)),1)
    def test_compare_symvers(self):
        out=r.compare_symvers({'x':('0x00000001','vmlinux'),'r':('0x00000002','vmlinux')},
                              {'x':('0x00000003','vmlinux'),'a':('0x00000004','vmlinux')})
        self.assertEqual(out,{'changed':['x'],'added':['a'],'removed':['r']})
    def test_match_classification(self):
        imp=[{'path':'/vendor/lib/modules/example.ko','symbol':'a','module_crc':'0xaabbccdd'},
             {'path':'/vendor/lib/modules/5.4-gki/example.ko','symbol':'c','module_crc':'0x11223344'},
             {'path':'/vendor/lib/modules/example.ko','symbol':'b','module_crc':'0xaabbccdd'}]
        v=r.classify_imports({'a':('0xaabbccdd','vmlinux'),'c':('0xffffffff','vmlinux')},imp)
        self.assertEqual(v['all'],{'MATCH':1,'CRC_MISMATCH':1,'ABSENT_IN_SYMVERS':1})
        self.assertEqual(v['groups']['qgki']['MATCH'],1)
    def test_invalid_json_object(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'x.json';p.write_text('[]')
            with self.assertRaises(r.ProbeError):r.read_json(p)
    def test_bad_symlink_sha(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);p=root/'test.txt';p.write_text('x');link=root/'link';link.symlink_to(p)
            with self.assertRaises(r.ProbeError):r.sha256(link)
    def test_missing_file_sha(self):
        with self.assertRaises(r.ProbeError):r.sha256('/no/such/file/r26')
    def test_malformed_imports(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.csv';p.write_text('path,symbol,module_crc\na,b,c\n')
            with self.assertRaises(r.ProbeError):r.read_imports(p)
    def test_import_path_traversal_reject(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.csv';p.write_text('path,symbol,module_crc,r20_crc,r20_provider,status\n/vendor/lib/modules/../../x.ko,sym,0x01010101,0x01010101,vmlinux,MATCH\n')
            with self.assertRaises(r.ProbeError):r.read_imports(p)
    def test_unrecognized_import_status_reject(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'bad.csv';p.write_text('path,symbol,module_crc,r20_crc,r20_provider,status\n/vendor/lib/modules/x.ko,sym,0x01010101,0x01010101,vmlinux,FAKE_PASS\n')
            with self.assertRaises(r.ProbeError):r.read_imports(p)
    def test_provenance_modified_hash_fails(self):
        with tempfile.TemporaryDirectory() as td:
            for n in r.REFERENCE_HASHES:
                shutil.copyfile(F/n,Path(td)/n)
            config=Path(td)/'R20_REAL_BUILD_CONFIG.config'
            config.write_bytes(config.read_bytes()+b'\n# attack\n')
            with self.assertRaises(r.ProbeError):r.expected_reference(td)
    def test_baseline_missing_config_fails(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(r.ProbeError):r.baseline_validation(F,td,F/'R20_BUILD_RESULT.json')
    def test_corrupt_build_proof_fails(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);(root/'.config').write_bytes((F/'R20_REAL_BUILD_CONFIG.config').read_bytes());
            (root/'Module.symvers').write_bytes((F/'R20_REAL_Module.symvers').read_bytes());
            d=json.loads((F/'R20_BUILD_RESULT.json').read_text());d['full_image_proven']=False
            (root/'forged.json').write_text(json.dumps(d))
            with self.assertRaises(r.ProbeError):r.baseline_validation(F,root,root/'forged.json')
    def test_validate_make_good(self):
        root='/tmp/veux-r26-source';out='/tmp/veux-r26-out';clang='/tmp/r9-clang'
        a=['make','--no-print-directory','-C',root,'O='+out,'ARCH=arm64','LLVM=1',
           'CC='+clang+'/bin/clang','LD='+clang+'/bin/ld.lld','-j2','Image']
        r.validate_argv(a,Path(root),Path(out),Path(clang),'Image')
    def test_validate_make_wrong_out_rejected(self):
        a=['make','-C','/tmp/a','O=/tmp/b','ARCH=arm64','LLVM=1','CC=/tmp/t/bin/clang','LD=/tmp/t/bin/ld.lld','-j2','Image']
        with self.assertRaises(r.ProbeError):r.validate_argv(a,Path('/tmp/a'),Path('/tmp/c'),Path('/tmp/t'),'Image')
    def test_validate_make_unapproved_target(self):
        a=['make','-C','/tmp/a','O=/tmp/b','ARCH=arm64','LLVM=1','CC=/tmp/t/bin/clang','LD=/tmp/t/bin/ld.lld','-j2','flash']
        with self.assertRaises(r.ProbeError):r.validate_argv(a,Path('/tmp/a'),Path('/tmp/b'),Path('/tmp/t'),'flash')
    def test_elf_header(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'vmlinux'; data=bytearray(64);data[:4]=b'\x7fELF';data[4:6]=b'\x02\x01';data[18:20]=struct.pack('<H',183);p.write_bytes(data)
            self.assertTrue(r.file_header(p,'elf')['valid_header'])
    def test_image_header(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'Image';data=bytearray(64);data[56:60]=b'ARMd';p.write_bytes(data)
            self.assertTrue(r.file_header(p,'image')['valid_header'])
    def test_image_linux_version(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'Image'
            p.write_bytes(b'a'*520000+b'Linux version 5.4.274-r26 (android clang)\x00 end'+b'b'*10)
            self.assertTrue(any('5.4.274-r26' in x for x in r.image_linux_version_strings(p)))
    def test_image_version_absent(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'Image';p.write_bytes(b'no_linux_version_here')
            self.assertEqual(r.image_linux_version_strings(p),[])
    def test_module_vermagic(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'sample.ko';data=bytearray(72)
            data[:4]=b'\x7fELF';data[4:6]=b'\x02\x01';data[18:20]=struct.pack('<H',183)
            p.write_bytes(bytes(data)+b'\x00vermagic=5.4.274-r26 SMP modversions aarch64\x00')
            self.assertEqual(r.module_vermagic(p)['vermagic'],'5.4.274-r26 SMP modversions aarch64')
            self.assertTrue(r.module_vermagic(p)['aarch64_elf'])
    def test_module_bad_elf(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'sample.ko';p.write_bytes(b'bad-header')
            self.assertFalse(r.module_vermagic(p)['aarch64_elf'])
    def test_fdt_magic(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'x.dtb';p.write_bytes(b'\xd0\x0d\xfe\xed')
            self.assertTrue(r.is_fdt_header(p))
            p.write_bytes(b'BADF');self.assertFalse(r.is_fdt_header(p))
    def test_image_bad_header(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'Image';p.write_bytes(b'not a kernel')
            self.assertFalse(r.file_header(p,'image')['valid_header'])

import struct
if __name__=='__main__':unittest.main()
