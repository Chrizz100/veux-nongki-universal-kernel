#!/usr/bin/env python3
"""VEUX R26: fail-closed, NO-FLASH, source-read-only ABI config A/B experiment.

Baseline is an independently proven R20-R11 build; never reconstruct or fake
an ABI, vermagic, CRC or a stock image. All candidate outputs are disposable.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import struct
import subprocess
import sys
import time

PROVEN_RUN = 39774000774
PROVEN_COMMIT = 'd83bcf8e069629a3502211aab391ba6e9fa0c5d0'
REFERENCE_HASHES = {
    'R20_REAL_BUILD_CONFIG.config': '7fa8abbe8e6496ec1613df60fa33da01f1614121a642a780ff909cd438ca6ffe',
    'VEUX_R22_RUNNING_KERNEL_CONFIG.config': '405a4b3384212aa693ca2ce19f4c1ebef74f9cfc2568ce5da2107efe84fc0ff4',
    'R20_REAL_Module.symvers': 'c626fc72563b7e96ebd2f50236a3b840847a65e9cc7affb2f47bf9b9c0692c21',
    'R21_IMPORTS.csv': 'bc772c1bdf961a25c0da60aae0352383ef93f9b6106960c2234aef7317fff394',
    'R20_BUILD_RESULT.json': '1ac165d7faed60af2c3ab43b086a4693d5a7dddace6026c39764ef73433aab19',
}
VARIANTS = {
    'kabi_reserve_off': ('CONFIG_ANDROID_KABI_RESERVE', 'y', 'n'),
    'vendor_oem_data_off': ('CONFIG_ANDROID_VENDOR_OEM_DATA', 'y', 'n'),
    'nr_cpus_8': ('CONFIG_NR_CPUS', '32', '8'),
}
PRIORITIES = (
    'CONFIG_NR_CPUS', 'CONFIG_ANDROID_KABI_RESERVE',
    'CONFIG_ANDROID_VENDOR_OEM_DATA', 'CONFIG_GKI_HACKS_TO_FIX',
    'CONFIG_SCHED_WALT', 'CONFIG_SCHED_CASS', 'CONFIG_MODVERSIONS',
    'CONFIG_LTO_CLANG', 'CONFIG_CFI_CLANG', 'CONFIG_LOCALVERSION',
)
SYMBOL_FOCUS = (
    'module_layout', '_dev_err', 'devm_kmalloc', '__platform_driver_register',
    'kmalloc_caches', 'kmem_cache_alloc_trace', 'of_find_property',
    'of_property_read_variable_u32_array', 'snd_soc_add_component_controls',
)
REQUIRED = ('CONFIG_SCHED_WALT', 'CONFIG_MODVERSIONS', 'CONFIG_LTO_CLANG',
            'CONFIG_CFI_CLANG', 'CONFIG_MODULES', 'CONFIG_OF', 'CONFIG_QGKI')
SHA_PATTERN = re.compile(r'^[0-9a-f]{64}$')
CONFIG_SET = re.compile(r'^(CONFIG_[A-Za-z0-9_]+)=(.+)$')
CONFIG_UNSET = re.compile(r'^# (CONFIG_[A-Za-z0-9_]+) is not set$')
CRC_PATTERN = re.compile(r'^0x[0-9a-fA-F]{8}$')
PROVEN_STATUS = 'R20_WALT_ON_VMLINUX_IMAGE_DTB_AND_MODULE_BUILD_PROVEN_NO_FLASH'

class ProbeError(RuntimeError):
    pass


def require(flag, code):
    if not flag:
        raise ProbeError(code)


def sha256(path):
    p = Path(path)
    require(p.is_file() and not p.is_symlink(), 'FILE_UNAVAILABLE_OR_SYMLINK:'+str(p))
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    p = Path(path)
    require(p.is_file() and not p.is_symlink() and p.stat().st_size < 400000,
            'INVALID_JSON_FILE:'+str(p))
    v = json.loads(p.read_text())
    require(isinstance(v, dict), 'JSON_OBJECT_EXPECTED')
    return v


def config_values(data):
    out = {}
    for text in data.splitlines():
        m = CONFIG_SET.match(text) or CONFIG_UNSET.match(text)
        if m:
            key = m.group(1)
            require(key not in out, 'DUPLICATE_CONFIG_KEY:'+key)
            out[key] = m.group(2) if m.lastindex == 2 else 'n'
    require(len(out) >= 1, 'EMPTY_CONFIG')
    return out


def config_diff(a, b):
    names = sorted(set(a) | set(b))
    return [(key, a.get(key), b.get(key)) for key in names if a.get(key) != b.get(key)]


def config_variant(text, variant):
    require(variant in VARIANTS, 'VARIANT_NOT_ALLOWLISTED')
    key, expected, replacement = VARIANTS[variant]
    config = config_values(text)
    require(config.get(key) == expected, 'VARIANT_PREIMAGE_DRIFT:'+key)
    if replacement == 'n':
        needle = key+'='+expected
        target = '# '+key+' is not set'
    else:
        needle = key+'='+expected
        target = key+'='+replacement
    require(text.count('\n'+needle+'\n') == 1,
            'EXACT_CONFIG_PREIMAGE_NOT_UNIQUE:'+key)
    return text.replace('\n'+needle+'\n', '\n'+target+'\n', 1)


def symvers_map(text):
    entries = {}
    for row in text.splitlines():
        parts = row.split('\t')
        require(len(parts) >= 4, 'MALFORMED_SYMVERS')
        crc, symbol, source = parts[:3]
        require(CRC_PATTERN.fullmatch(crc) and symbol and source,
                'SYMVERS_INVALID_EXPORT')
        # Export namespaces can be blank on older kernels.
        if symbol in entries:
            require(entries[symbol][0] == crc.lower() and entries[symbol][1] == source,
                    'SYMVERS_CONFLICTING_DUPLICATE:'+symbol)
        entries[symbol] = (crc.lower(), source)
    require(len(entries) > 0, 'EMPTY_SYMVERS')
    return entries


def read_imports(path):
    with Path(path).open(newline='') as f:
        r = csv.DictReader(f)
        require(set(r.fieldnames or ()) == {'path', 'symbol', 'module_crc',
                'r20_crc', 'r20_provider', 'status'}, 'UNEXPECTED_IMPORT_CSV_SCHEMA')
        data = list(r)
    require(data, 'EMPTY_IMPORTS')
    for row in data:
        require(row['path'].startswith('/vendor/lib/modules/') and
                row['path'].endswith('.ko') and '..' not in Path(row['path']).parts,
                'IMPORT_PATH_UNEXPECTED')
        require(CRC_PATTERN.fullmatch(row['module_crc']) and row['symbol'],
                'IMPORT_CRC_INVALID')
        require(row['status'] in ('MATCH','CRC_MISMATCH','ABSENT_IN_R20_SYMVERS'),
                'IMPORT_STATUS_INVALID')
    return data


def classify_imports(loaded, imports):
    result = {'MATCH':0, 'CRC_MISMATCH':0, 'ABSENT_IN_SYMVERS':0}
    groups = {}
    for r in imports:
        group = 'qgki' if not r['path'].startswith('/vendor/lib/modules/5.4-gki/') else '5.4-gki'
        counts = groups.setdefault(group, {'MATCH':0,'CRC_MISMATCH':0,'ABSENT_IN_SYMVERS':0})
        target = loaded.get(r['symbol'])
        status = ('ABSENT_IN_SYMVERS' if target is None else
                  'MATCH' if target[0].lower() == r['module_crc'].lower() else
                  'CRC_MISMATCH')
        result[status] += 1
        counts[status] += 1
    return {'all':result, 'groups':groups}


def compare_symvers(base, variant):
    old = set(base); new = set(variant)
    changed = sorted(s for s in old & new if base[s][0] != variant[s][0])
    return {'changed':changed, 'added':sorted(new-old), 'removed':sorted(old-new)}


def expected_reference(fixtures):
    fixtures=Path(fixtures)
    for name, digest in REFERENCE_HASHES.items():
        require(sha256(fixtures/name)==digest, 'R25_REFERENCE_HASH_DRIFT:'+name)
    baseline_cfg=config_values((fixtures/'R20_REAL_BUILD_CONFIG.config').read_text())
    device_cfg=config_values((fixtures/'VEUX_R22_RUNNING_KERNEL_CONFIG.config').read_text())
    diff=config_diff(baseline_cfg,device_cfg)
    require(len(diff)==879, 'R25_CONFIG_DIFFERENCE_COUNT_DRIFT')
    require(baseline_cfg.get('CONFIG_SCHED_WALT')=='y' and
            baseline_cfg.get('CONFIG_NR_CPUS')=='32' and
            device_cfg.get('CONFIG_NR_CPUS')=='8', 'WRONG_R25_CONFIG_INPUTS')
    for key in REQUIRED:
        require(baseline_cfg.get(key)=='y', 'BASELINE_REQUIRED_CONFIG_MISSING:'+key)
    base=symvers_map((fixtures/'R20_REAL_Module.symvers').read_text())
    require(len(base)==14260 and base['module_layout'][0]=='0x0bcef28c',
            'R20_REFERENCE_SYMVERS_MISMATCH')
    imports=read_imports(fixtures/'R21_IMPORTS.csv')
    require(len(imports)==14648, 'R21_IMPORTS_COUNT_DRIFT')
    statuses=classify_imports(base,imports)
    require(statuses['all']=={'MATCH':6960, 'CRC_MISMATCH':7653,
                             'ABSENT_IN_SYMVERS':35},'R21_IMPORT_REPLAY_MISMATCH')
    require(statuses['groups']['qgki']=={'MATCH':1474,'CRC_MISMATCH':1663,
                                         'ABSENT_IN_SYMVERS':11},
            'R21_QGKI_IMPORT_REPLAY_MISMATCH')
    return {'config_diff_count':len(diff), 'baseline_config_keys':len(baseline_cfg),
            'device_config_keys':len(device_cfg), 'baseline_symbol_count':len(base),
            'imports_count':len(imports), 'baseline_imports':statuses,
            'focus_config':{k:{'r20':baseline_cfg.get(k),'device':device_cfg.get(k)}
                            for k in PRIORITIES},
            'original_build_run':PROVEN_RUN,'original_build_commit':PROVEN_COMMIT,
            'fixtures_sha256':dict(REFERENCE_HASHES)}


def baseline_validation(fixtures, objout, report_path):
    info=expected_reference(fixtures)
    objout=Path(objout)
    report=read_json(report_path)
    require(report.get('status')==PROVEN_STATUS and report.get('full_image_proven') is True
            and report.get('kernel_image_built') is True and
            report.get('vmlinux_linked') is True and
            report.get('vendor_abi_proven') is False and
            report.get('flash_allowed') is False, 'R20_REFERENCE_BUILD_NOT_FULL')
    require(report.get('provenance',{}).get('config_sha256')==
            REFERENCE_HASHES['R20_REAL_BUILD_CONFIG.config'],
            'R20_CONFIG_PROVENANCE_DRIFT')
    require(report.get('module_symvers_sha256')==
            REFERENCE_HASHES['R20_REAL_Module.symvers'],
            'R20_MODULE_SYMVERS_PROVENANCE_DRIFT')
    require(sha256(objout/'.config')==REFERENCE_HASHES['R20_REAL_BUILD_CONFIG.config'],
            'R20_EFFECTIVE_OBJOUT_CONFIG_DRIFT')
    require(sha256(objout/'Module.symvers')==REFERENCE_HASHES['R20_REAL_Module.symvers'],
            'R20_EFFECTIVE_OBJOUT_SYMVERS_DRIFT')
    for filename,expected in (('arch/arm64/boot/Image',report['image']['sha256']),
                              ('vmlinux', report['vmlinux']['sha256'])):
        require(sha256(objout/filename)==expected,'R20_EFFECTIVE_BUILD_OUTPUT_DRIFT:'+filename)
    info['baseline_image_sha256']=report['image']['sha256']
    info['baseline_vmlinux_sha256']=report['vmlinux']['sha256']
    return info


def make_driver(path):
    spec=importlib.util.spec_from_file_location('r26_pinned_r9_make',path)
    require(spec is not None and spec.loader is not None, 'R9_DRIVER_NOT_LOADABLE')
    instance=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=instance
    spec.loader.exec_module(instance)
    require(callable(getattr(instance,'make_argv',None)),'R9_MAKE_BUILDER_UNAVAILABLE')
    return instance


def validate_argv(argv,snapshot,objout,toolchain,target):
    require(isinstance(argv,list) and 8<len(argv)<48, 'INVALID_MAKE_COMMAND')
    require(argv[0]=='make' and argv.count(target)==1 and
            '-C' in argv and argv[argv.index('-C')+1]==str(snapshot) and
            'O='+str(objout) in argv and 'ARCH=arm64' in argv and 'LLVM=1' in argv,
            'MAKE_NOT_ISOLATED_OR_NOT_ARM64')
    require('CC='+str(Path(toolchain)/'bin/clang') in argv and
            'LD='+str(Path(toolchain)/'bin/ld.lld') in argv,
            'MAKE_NOT_USING_PINNED_ANDROID_CLANG')
    require(target in ('olddefconfig','Image','dtbs','modules'), 'UNSAFE_MAKE_TARGET')
    require(not any(word in ('modules_install','install','flash','clean','mrproper',
                            'dtbo.img','boot.img') for word in argv), 'UNSAFE_BUILD_ARG')


def execute(argv,log,seconds,env):
    started=time.monotonic(); ret=127; timeout=False
    with Path(log).open('wb') as f:
        try:
            proc=subprocess.Popen(argv,stdout=f,stderr=subprocess.STDOUT,
                                  start_new_session=True,env=env)
            try:ret=proc.wait(timeout=seconds)
            except subprocess.TimeoutExpired:
                timeout=True;os.killpg(proc.pid,signal.SIGKILL);proc.wait();ret=124
        except OSError as err:f.write(('R26_START_ERROR:'+str(err)+'\n').encode())
    return {'exit_code':ret,'timeout':timeout,'elapsed_seconds':round(time.monotonic()-started,2),
            'log_sha256':sha256(log),'log_size':Path(log).stat().st_size}


def file_header(path,mode):
    p=Path(path)
    result={'exists':p.is_file() and not p.is_symlink()}
    if result['exists']:
        with p.open('rb') as f: head=f.read(64)
        result['size']=p.stat().st_size
        result['sha256']=sha256(p)
        result['valid_header']=(len(head)>=60 and head[56:60]==b'ARMd') if mode=='image' else (
            len(head)>=20 and head[:4]==b'\x7fELF' and head[4]==2 and head[5]==1 and
            struct.unpack_from('<H',head,18)[0]==183)
    return result


def image_linux_version_strings(path, max_scan=64_000_000):
    """Extract bounded printable Linux build banner evidence from an uncompressed ARM64 Image."""
    p=Path(path)
    require(p.is_file() and not p.is_symlink(),'IMAGE_BANNER_FILE_UNSAFE')
    pat=re.compile(rb'Linux version [ -~]{10,240}')
    found=set()
    previous=b''
    with p.open('rb') as stream:
        remaining=max_scan
        while remaining>0:
            b=stream.read(min(512*1024,remaining))
            if not b:break
            remaining-=len(b)
            sample=previous+b
            for m in pat.finditer(sample):
                banner=m.group(0).decode('ascii','replace').strip()
                if len(banner)>12:found.add(banner)
            previous=sample[-512:]
    return sorted(found)[:5]


def module_vermagic(path,max_bytes=40_000_000):
    p=Path(path)
    require(p.is_file() and not p.is_symlink() and p.stat().st_size<=max_bytes,
            'MODULE_MODINFO_UNSAFE')
    content=p.read_bytes()
    if not (len(content)>=20 and content[:4]==b'\x7fELF' and
            content[4]==2 and content[5]==1 and
            struct.unpack_from('<H',content,18)[0]==183):
        return {'aarch64_elf':False,'vermagic':None}
    tag=b'vermagic='
    idx=content.find(tag)
    if idx<0:return {'aarch64_elf':True,'vermagic':None}
    raw=content[idx+len(tag):].split(b'\x00',1)[0]
    value=raw.decode('ascii','replace').strip() if len(raw)<=400 else None
    return {'aarch64_elf':True,'vermagic':value}


def is_fdt_header(path):
    p=Path(path)
    require(p.is_file() and not p.is_symlink(),'DTB_MISSING_OR_SYMLINK')
    with p.open('rb') as f: return f.read(4)==b'\xd0\x0d\xfe\xed'


def source_provenance(snapshot, r20_report):
    post=r20_report['provenance']['source_sha256']
    require(len(post)==8,'R20_SOURCE_PROVENANCE_INCOMPLETE')
    for name,digest in post.items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts,
                'SOURCE_HASH_PATH_UNSAFE')
        require(sha256(Path(snapshot)/name)==digest,'R20_SOURCE_HASH_DRIFT:'+name)
    return post


def probe(args):
    fixtures=Path(args.fixtures);snapshot=Path(args.snapshot)
    baseline=Path(args.baseline_objout);variant_out=Path(args.variant_objout)
    output=Path(args.output);toolchain=Path(args.toolchain)
    canonical=Path(args.canonical);project=Path(args.project)
    require(args.variant in VARIANTS,'PROBE_VARIANT_NOT_SUPPORTED')
    for p in (snapshot,baseline,toolchain,canonical,project):
        require(p.is_dir() and not p.is_symlink(), 'RUN_INPUT_DIRECTORY_INVALID:'+str(p))
    require(snapshot.resolve()!=canonical.resolve(),'VARIANT_WOULD_TOUCH_CANONICAL_TREE')
    for p in (output,variant_out):
        require(not p.exists() and not p.is_symlink(),'VARIANT_OUTPUT_ALREADY_EXISTS:'+str(p))
        require(not p.resolve().is_relative_to(project.resolve()),
                'VARIANT_OUTPUT_INSIDE_REPO:'+str(p))
    report=read_json(args.r20_report)
    proven=baseline_validation(fixtures,baseline,args.r20_report)
    source_sha=source_provenance(snapshot,report)
    baseline_text=(fixtures/'R20_REAL_BUILD_CONFIG.config').read_text()
    new_text=config_variant(baseline_text,args.variant)
    planned=config_diff(config_values(baseline_text),config_values(new_text))
    require(len(planned)==1,'VARIANT_CONFIG_IS_NOT_ONE_VARIABLE')
    key,expected,replacement=VARIANTS[args.variant]
    require(planned==[(key,expected,replacement)],'VARIANT_DIFF_UNEXPECTED')
    driver=make_driver(Path(args.r9_driver))
    output.mkdir(parents=True)
    logdir=output/'make_logs';logdir.mkdir()
    variant_out.mkdir(parents=True)
    cfg=variant_out/'.config';cfg.write_text(new_text)
    record={'status':'R26_CONFIG_PROBE_DIAGNOSTIC_NO_FLASH', 'variant':args.variant,
            'single_intended_change':{'symbol':key,'from':expected,'to':replacement},
            'baseline':proven,'results':{},'make_targets':{},'variant_build_complete':False,
            'variant_isolation':True,'source_read_only':True,'repo_read_only':True,
            'vendor_abi_proven':False,'flash_allowed':False,'boot_image_created':False,
            'brene_changed':False,'bakasusu_nomount_changed':False,
            'notice':'Diagnostic experiment only. A CRC change is not a vendor ABI approval.'}
    def save():
        (output/'R26_RESULT.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
    save()
    env=os.environ.copy()
    env['PATH']=str(toolchain/'bin')+os.pathsep+env.get('PATH','')
    env['KBUILD_BUILD_USER']='veux-r26-abi-probe'
    env['KBUILD_BUILD_HOST']='github-actions'
    def one(target,seconds):
        argv=driver.make_argv(snapshot,variant_out,toolchain,target,2)
        validate_argv(argv,snapshot,variant_out,toolchain,target)
        log=logdir/('R26_'+target+'_make.log')
        run=execute(argv,log,seconds,env)
        record['make_targets'][target]=dict(run,invocation=argv)
        save()
        return run['exit_code']==0 and not run['timeout']
    if not one('olddefconfig',600):
        record['status']='R26_DIAGNOSTIC_OLDDEFCONFIG_FAILED';save();return record
    actual=config_values(cfg.read_text())
    difference=config_diff(config_values(baseline_text),actual)
    record['results']['effective_config_sha256']=sha256(cfg)
    record['results']['effective_change_count']=len(difference)
    record['results']['effective_config_changes']=[dict(symbol=a,base=b,variant=c)
                                                    for a,b,c in difference[:250]]
    save()
    if difference!=planned:
        record['status']='R26_DIAGNOSTIC_UNEXPECTED_CONFIG_PROPAGATION'
        record['results']['expected_only_change']=[key,expected,replacement]
        save();return record
    if not one('Image',5400):
        record['status']='R26_DIAGNOSTIC_IMAGE_COMPILER_FAILED';save();return record
    if not one('dtbs',1500):
        record['status']='R26_DIAGNOSTIC_DTB_BUILD_FAILED';save();return record
    if not one('modules',2400):
        record['status']='R26_DIAGNOSTIC_MODULE_BUILD_FAILED';save();return record
    image=file_header(variant_out/'arch/arm64/boot/Image','image')
    elf=file_header(variant_out/'vmlinux','elf')
    dtbs=[p for p in variant_out.glob('arch/arm64/boot/dts/**/*.dtb')
          if p.is_file() and not p.is_symlink() and p.stat().st_size>=100]
    mods=[p for p in variant_out.glob('**/*.ko')
          if p.is_file() and not p.is_symlink() and p.stat().st_size>=100]
    sym=variant_out/'Module.symvers'
    if not (image.get('valid_header') and image.get('size',0)>1000000 and
            elf.get('valid_header') and elf.get('size',0)>1000000 and
            dtbs and mods and sym.is_file() and sym.stat().st_size>1000):
        record['status']='R26_DIAGNOSTIC_INCOMPLETE_KERNEL_LINK_PRODUCTS'
        record['results']['image']=image;record['results']['vmlinux']=elf
        record['results']['dtbs_found']=len(dtbs);record['results']['modules_found']=len(mods)
        save();return record
    base=symvers_map((fixtures/'R20_REAL_Module.symvers').read_text())
    newer=symvers_map(sym.read_text())
    diff=compare_symvers(base,newer)
    imports=read_imports(fixtures/'R21_IMPORTS.csv')
    matches=classify_imports(newer,imports)
    with (output/'R26_SYMVERS_CRC_DIFF.csv').open('w',newline='') as stream:
        w=csv.writer(stream)
        w.writerow(['symbol','baseline_crc','variant_crc','baseline_provider','variant_provider','change'])
        for symbol in sorted(set(base)|set(newer)):
            b=base.get(symbol);n=newer.get(symbol)
            if b is None or n is None or b[0]!=n[0] or b[1]!=n[1]:
                w.writerow([symbol,b[0] if b else '',n[0] if n else '',
                            b[1] if b else '',n[1] if n else '',
                            'added' if b is None else 'removed' if n is None else 'changed'])
    record['results'].update({
        'image':image, 'vmlinux':elf,
        'dtbs_found':len(dtbs),'modules_found':len(mods),
        'valid_fdt_headers':sum(is_fdt_header(p) for p in dtbs),
        'image_linux_version_banners':image_linux_version_strings(variant_out/'arch/arm64/boot/Image'),
        'module_vermagic':{str(p.relative_to(variant_out)):module_vermagic(p)
                           for p in mods},
        'symvers_sha256':sha256(sym),
        'baseline_export_count':len(base),'candidate_export_count':len(newer),
        'crc_changed_export_count':len(diff['changed']),
        'added_exports':len(diff['added']),'removed_exports':len(diff['removed']),
        'focus_symbols':{s:{'baseline_crc':base.get(s,(None,))[0],
                            'variant_crc':newer.get(s,(None,))[0]} for s in SYMBOL_FOCUS},
        'candidate_imports':matches,
        'qgki_crc_matches_delta':matches['groups']['qgki']['MATCH'] -
                                 proven['baseline_imports']['groups']['qgki']['MATCH'],
        'gki_crc_matches_delta':matches['groups']['5.4-gki']['MATCH'] -
                                proven['baseline_imports']['groups']['5.4-gki']['MATCH'],
    })
    for name,digest in source_sha.items():
        require(sha256(snapshot/name)==digest,'VARIANT_CHANGED_SOURCE:'+name)
    record['status']='R26_SINGLE_VARIABLE_IMAGE_ABI_DIAGNOSTIC_COMPLETE_NO_FLASH'
    record['variant_build_complete']=True
    save()
    print('R26_REAL_VARIANT_IMAGE=YES; CRC_CHANGED='+str(len(diff['changed']))+
          '; QGKI_MATCH_DELTA='+str(record['results']['qgki_crc_matches_delta'])+
          '; ABI=UNPROVEN; FLASH=NO')
    return record


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=['preflight','probe'],required=True)
    p.add_argument('--fixtures',required=True)
    p.add_argument('--variant',choices=sorted(VARIANTS),default='kabi_reserve_off')
    p.add_argument('--output')
    for key in ('snapshot','canonical','project','baseline-objout','variant-objout',
                'toolchain','r9-driver','r20-report'):
        p.add_argument('--'+key)
    a=p.parse_args()
    try:
        if a.mode=='preflight':
            info=expected_reference(Path(a.fixtures))
            print('R26_PINNED_R25_PREIMAGE=PASS; DIFF='+str(info['config_diff_count'])+
                  '; IMPORTS='+str(info['imports_count'])+'; NO_FLASH')
        else:
            require(all(getattr(a,k.replace('-','_')) for k in
                        ('output','snapshot','canonical','project','baseline-objout',
                         'variant-objout','toolchain','r9-driver','r20-report')),
                    'R26_MISSING_REQUIRED_RUN_INPUT')
            probe(a)
    except (ProbeError,ValueError,OSError,KeyError,TypeError,ImportError,AssertionError) as e:
        print('R26_FAIL_CLOSED:'+str(e),file=sys.stderr)
        return 2
    return 0

if __name__=='__main__':
    raise SystemExit(main())
