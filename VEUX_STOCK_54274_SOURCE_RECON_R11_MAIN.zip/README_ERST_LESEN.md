# VEUX R11 – isolierter WALT-Objekt-Compilerprobe, NICHT FLASHEN

**Ziel:** Erste tatsächliche Compilerdiagnose zur Übertragung der in R10 mit SHA/ Git-Blob geprüften Qualcomm WALT-Quellen auf den 5.4.268-Donor, mit echtem aus Stock-Kheaders extrahiertem `include/linux/sched.h` (5.4.274 QGKI).

Der Probe ist **kein vollständiger WALT-Port**. Der ältere interne Scheduler-Header `kernel/sched/sched.h` wird ausschließlich im isolierten temporären Test-Worktree als Kompiliergerüst verwendet, **nicht** als genehmigter Stock-ABI-Code. Originaler Stock-Kernel und R6-ABI-Basis werden nicht verändert.

Das WALT-Subsystem benötigt die nicht vorhandene RTMM-Implementierung, Scheduler-Hooks, Cgroup- und CPU-Isolation-Anbindung sowie echte Stock-Runqueue-Quellstruktur. **Der Test erstellt weder `boot.img`, noch AK3, noch verteilbare `Image`-Binärdateien.** Es werden nur zwei Objektziele mit exakt gepinntem Android Clang 11.0.2 versucht:

- `kernel/sched/walt.o` (schwache Scheduler-Kompatibilitätshooks)
- `techpack/sched/walt.o` (echte WALT-Berechnung)

**Compilergates:** Bei Fehlercode != 0 wird GitHub-Job ROT und die Diagnostik trotzdem als Text/JSON hochgeladen. Grün für einzelne Objekte bedeutet **nicht** OEM ABI-Green, Stock 5.4.274 oder Flashfreigabe. `R11_WALT_OBJECT_COMPILER_SUMMARY.json` enthält die tatsächlichen RCs und ersten Fehler.

Der gepinnte Spender (`b2b7a3bbc36d120ee523ebc8d68e0f13a97df632`) und die Paarquelle (`01cb3a8824b7b4caf3e3540274e71abba5ade538`) werden in GitHub nur lesend abgeholt. Kein Merge, keine Veränderung der Haupt-Repo und keine Geheimnisse. Die originale `R10_PINNED_WALT_SOURCES.tar.gz` wird in MAIN verifiziert. Die relevante Stock-Referenz wurde mit SHA-Pins übernommen.

**R11 ist bewusst ein früher Compilerprobe, kein kompletter Build.** Der vollständige Port benötigt danach explizit die zugehörigen Aufrufstellen, RTMM und den ABI-Abgleich aller QGKI-Module. Kein automatisches Patchen der produktiven Kernelquellen.
