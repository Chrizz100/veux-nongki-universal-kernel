# VEUX R10 – WALT-/Scheduler-Quellport: geprüfte Ausgangslage

Stand: gepinnte Linux-5.4.61-Quelle `01cb3a8824b7b4caf3e3540274e71abba5ade538` gegen R6-Donor `b2b7a3bbc36d120ee523ebc8d68e0f13a97df632` und originale Stock-Header (5.4.274).

## Gesicherte Befunde

- Echte WALT-Implementierung: `techpack/sched/walt.c` (nicht mit `kernel/sched/walt.c` verwechseln: letzteres enthält schwache Ersatzfunktionen).
- Stock- und WALT-Pair-Quellbaum besitzen `task_struct.wts`. Im 5.4.268-Donor fehlt es.
- Der WALT-Pair-Quellbaum besitzt `rq.wrq` und `struct walt_rq`; beides fehlt im Donor. Die originale Stock-interne `rq`-Struktur liegt nicht in den eingebetteten kheaders.
- Die Stock-`walt_task_struct` unterscheidet sich vom Pair-Stand: Stock `u8 low_latency`, Pair `bool low_latency`; Stock zusätzliche Felder `iowaited` und optional `proc_load` mit `CONFIG_RTMM=y`.
- Stock-Kconfig: `CONFIG_SCHED_WALT=y`, `CONFIG_RTMM=y`. R6-Kandidat besitzt diese Optionen nicht.
- Es gibt derzeit 0 vollständig CRC-kompatible QGKI-Moduldateien (37 in gesicherter Ladeliste); WALT ist allein kein ABI-Fix.

## Geprüfte Quellgruppen und nächste Portreihenfolge

1. WALT-Implementierung und schwache Stub-Aufrufstellen auseinanderhalten.
2. Originales Stock-Tasklayout inklusive RTMM-Feldern erhalten; nicht blind die ältere `sched.h` kopieren.
3. Scheduler-Runqueue-/Cgroup-/Core-Control-Hooks mit dazugehörigen Quellpatches zuordnen.
4. Komplette Kconfig-/Makefile-/`techpack`-Einbindung isoliert umsetzen.
5. Erst dann einen isolierten Clang-11-Kernelbuild starten, ohne neue Bootdateien zu veröffentlichen.
6. Danach QGKI-Modul-CRC-Deltas gegen R6 messen und Quellport nur bei erklärbarer Verbesserung beibehalten.

## Artefakte

`R10_PINNED_WALT_SOURCES.tar.gz`: 19 source files mit identifizierten Git-Blob-SHAs; **nur zur Prüfung, kein integrierter Kernel**.
`R10_WALT_TASK_STRUCTURE_DIFF.patch.txt`: Vergleich der WALT-Taskstrukturen, **kein automatisch anwendbarer Patch**.
`R10_QUELL_HASH_INDEX.csv`: Original-Git-Blob-IDs und SHA-256 der geprüften Dateien.

## Sicherheitssperren

NOFLASH. Kein Kernelbuild in R10, keine CRC-Änderung, kein automatisch eingespielter Quellpatch, keine Laufzeit-/OEM-ABI-Freigabe.
