import hashlib
import json
import tempfile
import unittest
import sys
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).parent))
import r11_walt_probe as r

class WALTProbeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.files,cls.provenance=r.load_inputs(ROOT)

    def test_01_manifest_authenticated(self):
        self.assertEqual(r.sha((ROOT/'reference/stock_sched.h').read_bytes()),r.STOCK_SCHED_SHA)

    def test_02_19_pinned_walt_inputs(self):
        self.assertEqual(len([x for x in self.files if x.startswith('PAIR_SOURCE/')]),19)

    def test_03_real_walt_implementation(self):
        self.assertIn(b'walt_update_task_ravg',self.files['PAIR_SOURCE/techpack/sched/walt.c'])

    def test_04_weak_shim_not_real_walt(self):
        self.assertIn(b'void __weak walt_update_task_ravg',self.files['PAIR_SOURCE/kernel/sched/walt.c'])

    def test_05_stock_low_latency_u8(self):
        self.assertIn(b'u8\t\t\t\tlow_latency;', (ROOT/'reference/stock_sched.h').read_bytes())

    def test_06_stock_iowaited_rtmm(self):
        h=(ROOT/'reference/stock_sched.h').read_text()
        self.assertIn('iowaited;',h);self.assertIn('proc_load;',h);self.assertIn('CONFIG_RTMM',h)

    def test_07_stock_config(self):
        s=(ROOT/'reference/stock.config').read_text()
        self.assertIn('CONFIG_SCHED_WALT=y',s);self.assertIn('CONFIG_RTMM=y',s)

    def test_08_pair_kconfig_verbatim(self):
        x=r.pair_kconfig(self.files['PAIR_SOURCE/init/Kconfig'])
        self.assertIn('config SCHED_WALT',x);self.assertIn('depends on SMP',x)

    def test_09_bad_kconfig_rejected(self):
        with self.assertRaises(ValueError):r.pair_kconfig(b'config OTHER\n bool "x"\n')

    def test_10_trial_source_map(self):
        files=r.convert_source(self.files, (ROOT/'reference/stock_sched.h').read_bytes(),(ROOT/'reference/core_ctl.h').read_bytes(),(ROOT/'reference/stock_cpumask.h').read_bytes())
        self.assertIn('techpack/sched/walt.c',files)
        self.assertEqual(r.sha(files['include/linux/sched.h']),r.STOCK_SCHED_SHA)
        self.assertNotIn('PAIR_SOURCE/.gitignore',files)

    def test_11_no_boot_or_images(self):
        manifest=json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
        self.assertIs(manifest['flash_allowed'],False)
        self.assertIs(manifest['oem_abi_green'],False)
        self.assertIs(manifest['production_patch_approved'],False)
        self.assertNotIn('boot.img',' '.join(manifest['files']))

    def test_12_dry_run(self):
        x=r.stage(ROOT,None,None,None,dry_run=True)
        self.assertGreaterEqual(x['source_files_staged'],14)
        self.assertIn('techpack/sched/walt.c',x['source_paths'])

    def test_13_sha_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            from shutil import copytree
            copytree(ROOT,Path(d)/'main')
            p=Path(d)/'main/reference/stock_sched.h'
            p.write_bytes(p.read_bytes()+b'unsafe')
            with self.assertRaisesRegex(ValueError,'AUTHENTICATION_FAILED'):
                r.load_inputs(Path(d)/'main')

    def test_14_manifest_guard_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            from shutil import copytree
            copytree(ROOT,Path(d)/'main')
            p=Path(d)/'main/MANIFEST_SHA256.json'
            m=json.loads(p.read_text());m['flash_allowed']=True;p.write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError,'UNSAFE_MANIFEST_CONTRACT'):
                r.load_inputs(Path(d)/'main')

    def test_15_wrong_pair_commit_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            from shutil import copytree
            copytree(ROOT,Path(d)/'main')
            p=Path(d)/'main/MANIFEST_SHA256.json'
            m=json.loads(p.read_text());m['pair_commit']='bad';p.write_text(json.dumps(m))
            with self.assertRaisesRegex(ValueError,'PINNED_REPO_DRIFT'):
                r.load_inputs(Path(d)/'main')

    def test_16_summary_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            (root/'R11_PREPARE_RC.txt').write_text('0')
            (root/'R11_WEAK_RC.txt').write_text('2')
            (root/'R11_REAL_RC.txt').write_text('1')
            (root/'R11_WEAK_BUILD.log').write_text('x.c:99: error: missing type\n')
            out=r.build_summary(ROOT,root)
            self.assertFalse(out['object_compilation_pass'])
            self.assertEqual(out['stages']['weak']['compiler_error_count'],1)
            self.assertFalse(out['flash_allowed'])

    def test_17_summary_success_not_flash(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for n in ['PREPARE','WEAK','REAL']:
                (root/f'R11_{n}_RC.txt').write_text('0')
                (root/f'R11_{n}_BUILD.log').write_text('compiled okay')
            out=r.build_summary(ROOT,root)
            self.assertTrue(out['object_compilation_pass'])
            self.assertFalse(out['linked_vmlinux_built'])
            self.assertFalse(out['oem_abi_verified'])
            self.assertFalse(out['flash_allowed'])

    def test_18_missing_rc_is_not_success(self):
        with tempfile.TemporaryDirectory() as d:
            out=r.build_summary(ROOT,Path(d))
            self.assertFalse(out['object_compilation_pass'])

    def test_19_donor_guard(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(ValueError,'DONOR_NOT_GIT'):
                r.stage(ROOT,Path(d),Path(d)/'worktree',Path(d)/'reports')

    def test_20_originals_immutable_in_plan(self):
        x=r.stage(ROOT,None,None,None,dry_run=True)
        self.assertNotIn('drivers/base/core.c',x['source_paths'])
        self.assertNotIn('drivers/iommu/msm_dma_iommu_mapping.c',x['source_paths'])

    def test_21_mock_worktree_preserves_original_donor(self):
        import subprocess
        with tempfile.TemporaryDirectory() as d:
            home=Path(d);base=home/'donor';base.mkdir()
            subprocess.run(['git','-C',str(base),'init','-q'],check=True)
            subprocess.run(['git','-C',str(base),'config','user.name','R11 Fixture'],check=True)
            subprocess.run(['git','-C',str(base),'config','user.email','r11@example.invalid'],check=True)
            (base/'init').mkdir();(base/'kernel/sched').mkdir(parents=True)
            (base/'init/Kconfig').write_text('config FIXTURE\n\tbool "test"\n')
            (base/'kernel/sched/Makefile').write_text('obj-y += core.o\n')
            subprocess.run(['git','-C',str(base),'add','.'],check=True)
            subprocess.run(['git','-C',str(base),'commit','-qm','fixture'],check=True)
            head=subprocess.check_output(['git','-C',str(base),'rev-parse','HEAD'],text=True).strip()
            out=home/'walt-trial'
            with patch.object(r,'load_inputs',return_value=(self.files,self.provenance)),patch.object(r,'DONOR_COMMIT',head):
                report=r.stage(ROOT,base,out,home/'reports')
            self.assertTrue(report['donor_original_clean'])
            self.assertEqual(r.sha((out/'include/linux/sched.h').read_bytes()),r.STOCK_SCHED_SHA)
            self.assertIn('config SCHED_WALT',(out/'init/Kconfig').read_text())
            self.assertNotIn('config SCHED_WALT',(base/'init/Kconfig').read_text())
            self.assertTrue((out/'techpack/sched/walt.c').is_file())
            self.assertFalse(report['flash_allowed'])
            self.assertFalse(report['full_walt_scheduler_hooks_ported'])

if __name__=='__main__':unittest.main()
