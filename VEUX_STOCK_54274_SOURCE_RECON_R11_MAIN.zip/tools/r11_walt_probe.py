#!/usr/bin/env python3
"""R11 isolated WALT object-level compile diagnostic. Never a production port."""
import argparse
import hashlib
import io
import json
import re
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

SCHEMA = 'VEUX_R11_STOCK_TASK_WALT_OBJECT_PROBE_NOFLASH'
PAIR_COMMIT = '01cb3a8824b7b4caf3e3540274e71abba5ade538'
DONOR_COMMIT = 'b2b7a3bbc36d120ee523ebc8d68e0f13a97df632'
STOCK_RELEASE = '5.4.274-qgki-g82179e362f33'
WALT_TAR_SHA = 'e9e8a40f394548f9dba32a2c80dc04cb518d48a1a452b5b963f80d9702ba48c7'
STOCK_SCHED_SHA = 'a9923e4444aaa3a58c08776268914b3e3ee5f0042676d4c86a48eaf88381b111'
STOCK_CFG_SHA = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
STOCK_CORECTL_SHA = 'bc73b24be7b7ffad9807d23f7eae5b16771c08aa37082493cd41f2b191ccd1d8'
STOCK_CPUMASK_SHA = '05fa97b100809efdd2d1484e871cdbb1613c996f02724d22f8665c605bd3cef4'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_inputs(root):
    root=Path(root)
    main=json.loads((root/'MANIFEST_SHA256.json').read_text())
    if (main.get('schema')!=SCHEMA or main.get('flash_allowed') is not False or
        main.get('production_patch_approved') is not False or main.get('oem_abi_green') is not False):
        raise ValueError('R11_UNSAFE_MANIFEST_CONTRACT')
    if main.get('pair_commit')!=PAIR_COMMIT or main.get('donor_commit')!=DONOR_COMMIT:
        raise ValueError('R11_PINNED_REPO_DRIFT')
    for rel, expected in main['files'].items():
        path=root / rel
        if not path.is_file() or path.is_symlink() or sha(path.read_bytes())!=expected:
            raise ValueError('R11_FILE_AUTHENTICATION_FAILED:'+rel)
    checks={'reference/R10_PINNED_WALT_SOURCES.tar.gz':WALT_TAR_SHA,
            'reference/stock_sched.h':STOCK_SCHED_SHA,
            'reference/stock.config':STOCK_CFG_SHA,
            'reference/core_ctl.h':STOCK_CORECTL_SHA,
            'reference/stock_cpumask.h':STOCK_CPUMASK_SHA}
    for rel,s in checks.items():
        if sha((root/rel).read_bytes()) != s:raise ValueError('R11_STOCK_OR_SOURCE_PROVENANCE_DRIFT:'+rel)
    with tarfile.open(fileobj=io.BytesIO((root/'reference/R10_PINNED_WALT_SOURCES.tar.gz').read_bytes()),mode='r:gz') as tf:
        members=tf.getmembers()
        if len(members)!=len({x.name for x in members}) or len(members)>60 or sum(x.size for x in members)>3_000_000:
            raise ValueError('R11_UNSAFE_TAR_MEMBERSET')
        files={}
        for m in members:
            rel=PurePosixPath(m.name)
            if not m.isfile() or m.size>500_000 or rel.is_absolute() or '..' in rel.parts or '\\' in m.name:
                raise ValueError('R11_UNSAFE_TAR_PATH_OR_KIND')
            files[m.name]=tf.extractfile(m).read()
    prov=json.loads(files['SOURCE_PROVENANCE.json'])
    # R10 source bundle provenance varies; enforce anchor content and file count.
    pair=[p for p in files if p.startswith('PAIR_SOURCE/')]
    if len(pair)!=19 or 'PAIR_SOURCE/techpack/sched/walt.c' not in files:
        raise ValueError('R11_INCOMPLETE_WALT_SOURCE_FAMILY')
    if b'void walt_update_task_ravg' not in files['PAIR_SOURCE/techpack/sched/walt.c']:
        raise ValueError('R11_REAL_WALT_MISSING')
    if b'void __weak walt_update_task_ravg' not in files['PAIR_SOURCE/kernel/sched/walt.c']:
        raise ValueError('R11_WEAK_AND_REAL_WALT_CONFUSED')
    if not re.search(rb'\bu8\s+low_latency\s*;', (root/'reference/stock_sched.h').read_bytes()):
        raise ValueError('R11_STOCK_LOW_LATENCY_NOT_PRESERVED')
    if not re.search(rb'\biowaited\s*;', (root/'reference/stock_sched.h').read_bytes()):
        raise ValueError('R11_STOCK_IOWAITED_NOT_PRESERVED')
    if b'CONFIG_RTMM' not in (root/'reference/stock_sched.h').read_bytes() or b'proc_load' not in (root/'reference/stock_sched.h').read_bytes():
        raise ValueError('R11_STOCK_RTMM_LAYOUT_NOT_PRESERVED')
    if b'CONFIG_SCHED_WALT=y' not in (root/'reference/stock.config').read_bytes():
        raise ValueError('R11_STOCK_WALT_CONFIG_DRIFT')
    return files, prov


def pair_kconfig(blob):
    txt=blob.decode()
    m=re.search(r'(?m)^config SCHED_WALT\n(?:(?!^config |^menuconfig |^choice|^endchoice|^menu |^endmenu).*(?:\n|$))*',txt)
    if not m or 'depends on SMP' not in m.group(0):
        raise ValueError('R11_PAIR_KCONFIG_WALT_BLOCK_MISSING')
    return m.group(0).strip()+'\n'


def convert_source(files,stock_sched,stock_core_ctl,stock_cpumask):
    out={}
    for n,v in files.items():
        if n.startswith('PAIR_SOURCE/techpack/sched/') and n!='PAIR_SOURCE/techpack/sched/.gitignore':
            out[n[len('PAIR_SOURCE/'):]]=v
    # Diagnostic-only: use pair internal scheduler structure to compile WALT API.
    # This is not a stock ABI replacement and MUST NOT be committed to production.
    for p in ['kernel/sched/walt.c','kernel/sched/walt.h','kernel/sched/sched.h']:
        out[p]=files['PAIR_SOURCE/'+p]
    out['include/linux/sched.h']=stock_sched
    out['include/linux/sched/core_ctl.h']=stock_core_ctl
    out['include/linux/cpumask.h']=stock_cpumask
    return out


def stage(root, donor, stage_dir, reports, dry_run=False):
    root=Path(root)
    files,prov=load_inputs(root)
    kconf=pair_kconfig(files['PAIR_SOURCE/init/Kconfig'])
    maker=files['PAIR_SOURCE/kernel/sched/Makefile'].decode()
    needed='obj-$(CONFIG_SCHED_WALT) += walt.o'
    if needed not in maker:raise ValueError('R11_REAL_PAIR_MAKEFILE_RULE_MISSING')
    patch=convert_source(files,(root/'reference/stock_sched.h').read_bytes(),(root/'reference/core_ctl.h').read_bytes(),(root/'reference/stock_cpumask.h').read_bytes())
    if dry_run:
        return {'source_files_staged':len(patch),'source_paths':sorted(patch),'config_fragment':kconf}
    donor=Path(donor);stage_dir=Path(stage_dir);reports=Path(reports)
    if not (donor/'.git').exists():raise ValueError('R11_DONOR_NOT_GIT')
    actual=subprocess.check_output(['git','-C',str(donor),'rev-parse','HEAD'],text=True).strip()
    if actual!=DONOR_COMMIT:raise ValueError('R11_DONOR_COMMIT_DRIFT')
    if stage_dir.exists():raise ValueError('R11_STAGE_ALREADY_EXISTS')
    if subprocess.check_output(['git','-C',str(donor),'status','--porcelain'],text=True).strip():
        raise ValueError('R11_DIRTY_DONOR')
    subprocess.run(['git','-C',str(donor),'worktree','add','--detach',str(stage_dir),DONOR_COMMIT],check=True,stdout=subprocess.DEVNULL)
    base_kconfig=(stage_dir/'init/Kconfig').read_text()
    if re.search(r'(?m)^config SCHED_WALT\s*$',base_kconfig):raise ValueError('R11_DONOR_ALREADY_HAS_WALT_OPTION')
    kconfig=base_kconfig.rstrip()+'\n\n'+kconf
    mk=(stage_dir/'kernel/sched/Makefile').read_text()
    if needed in mk:raise ValueError('R11_DONOR_ALREADY_HAS_WALT_RULE')
    mk=mk.rstrip()+'\n'+needed+'\n'
    for p,v in patch.items():
        dest=stage_dir/p;dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(v)
    (stage_dir/'init/Kconfig').write_text(kconfig)
    (stage_dir/'kernel/sched/Makefile').write_text(mk)
    if sha((stage_dir/'include/linux/sched.h').read_bytes())!=STOCK_SCHED_SHA:
        raise ValueError('R11_STOCK_TASK_MISMATCH_AFTER_STAGE')
    report={'schema':SCHEMA,'trial_only':True,'no_flash':True,'donor_commit':DONOR_COMMIT,'pair_commit':PAIR_COMMIT,
            'donor_original_clean':not bool(subprocess.check_output(['git','-C',str(donor),'status','--porcelain'],text=True).strip()),
            'source_files_staged':len(patch),'source_paths':sorted(patch),
            'experimental_pair_internal_sched_header_used':True,
            'stock_task_struct_header_sha256':STOCK_SCHED_SHA,
            'config_scheduling_source_added':True,'config_rtmm_implementation_ported':False,
            'full_walt_scheduler_hooks_ported':False,
            'full_5_4_274_stock_source_available':False,'oem_abi_verified':False,'flash_allowed':False}
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R11_WALT_STAGE_PROVENANCE.json').write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
    return report


def build_summary(root, reports):
    reports=Path(reports)
    stages={}
    for name in ['prepare','weak','real']:
        p=reports/('R11_'+name.upper()+'_RC.txt')
        if not p.exists():stages[name]={'rc':None,'compiler_error_count':None,'first_errors':[]};continue
        rc=int(p.read_text().strip()); log_file=reports/('R11_'+name.upper()+'_BUILD.log')
        log=log_file.read_text(errors='replace') if log_file.exists() else ''
        err=[x[:550] for x in log.splitlines() if re.search(r'(?:\berror:|\bfatal error:|make(?:\[\d+\])?: \*\*\*|Error \d+)',x)]
        stages[name]={'rc':rc,'compiler_error_count':len(err),'first_errors':err[:30],
                      'llvm_broken_pipe_count':log.count('LLVM ERROR: IO failure on output stream: Broken pipe'),
                      'log_lines':len(log.splitlines())}
    success=all(stages.get(x,{}).get('rc')==0 for x in ['prepare','weak','real'])
    result={'schema':SCHEMA,'status':'R11_OBJECT_PROBE_PASSED_NOT_ABI' if success else 'R11_OBJECT_PROBE_HAS_BLOCKERS',
            'stages':stages,'object_compilation_pass':success,'linked_vmlinux_built':False,'abi_recomputed':False,
            'full_walt_scheduler_hooks_integrated':False,'stock_rtmm_implemented':False,
            'oem_abi_verified':False,'boot_tested':False,'flash_allowed':False}
    reports.mkdir(exist_ok=True,parents=True)
    (reports/'R11_WALT_OBJECT_COMPILER_SUMMARY.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
    print(json.dumps({'R11_STATUS':result['status'],'R11_OBJECTS_COMPILATION_GREEN':success,
                      'PREPARE_RC':stages['prepare']['rc'],'WEAK_RC':stages['weak']['rc'],'REAL_RC':stages['real']['rc'],
                      'FLASH_ALLOWED':False},sort_keys=True))
    return result


def main():
    a=argparse.ArgumentParser();a.add_argument('mode',choices=['stage','verify','summarize'])
    a.add_argument('--root',required=True);a.add_argument('--donor');a.add_argument('--stage-dir');a.add_argument('--reports');args=a.parse_args()
    if args.mode=='verify':print(json.dumps(stage(args.root,'.','.','.',dry_run=True),sort_keys=True))
    elif args.mode=='stage':print(json.dumps(stage(args.root,args.donor,args.stage_dir,args.reports),sort_keys=True))
    else:build_summary(args.root,args.reports)

if __name__=='__main__':main()
