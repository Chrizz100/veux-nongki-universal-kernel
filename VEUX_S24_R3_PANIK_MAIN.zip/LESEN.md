# VEUX S24-R3 für den GitHub-Webupload

Die MAIN-ZIP gehört ungeöffnet ins Hauptverzeichnis des Zweigs main. Die zugehörige VEUX_S24_R3_PANIK_NOFLASH.yml gehört nach .github/workflows/. Lade zuerst die MAIN-ZIP und danach die YAML hoch.

Die ZIP enthält die binäre Differenz zwischen dem veröffentlichten R2-Baupaket und dem geprüften vollständigen R3-Baupaket. GitHub Actions setzt R3 aus der festgelegten R2-Basis und der Differenz zusammen. Vor dem Entpacken prüft der Workflow das vollständige Ergebnis.

R2-Baupaket in GitHub-Revision 03534d35ef9750416f74fee017a3982d41369edf
SHA-256 R2: a3220efea5594440c3449b0535a98e4dd8a870c5f0c72812e0d820a9c69c3744
SHA-256 vollständiges R3: 96581a4e8c391a8b3dc5162b9e807550e0b483ca50efc19e80f13df413a0ec56
