"""R13 negative/positive CI fixtures, no real kernel build or flash."""
import copy, hashlib, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import r13_walt_subsystem_probe as audit

WALT_MAKEFILE = '# SPDX-License-Identifier: GPL-2.0\nobj-$(CONFIG_SCHED_WALT) += walt.o boost.o sched_avg.o qc_vas.o core_ctl.o trace.o\nobj-$(CONFIG_CPU_FREQ) += cpu-boost.o\n'
CONFIG = 'CONFIG_SCHED_WALT=y\nCONFIG_CPU_FREQ=y\nCONFIG_PROC_SYSCTL=y\nCONFIG_QGKI=y\nCONFIG_MODVERSIONS=y\n'

class Tests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root=Path(self.temp.name)
        self.objout=self.root/'out';self.objout.mkdir()
        self.snap=self.root/'src';self.snap.mkdir()
        self.logdir=self.root/'logs';self.logdir.mkdir()
        self.config=self.root/'cfg';self.config.write_text(CONFIG)
        self.objects={}
        for path in audit.R12_FOUR:
            obj=self.objout/path;obj.parent.mkdir(parents=True,exist_ok=True)
            obj.write_bytes(b'object'+path.encode())
            self.objects[path]={'compiled':True,'exit_code':0,'object_file_present':True,
                'object_bytes':obj.stat().st_size,'object_sha256':audit.sha256(obj)}
        self.gate={'status':'R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED',
                  'canonical_p10_tree':audit.R12_TREE,'after_sha256':{'a':'x'}}
        self.result={'status':audit.R12_STATUS,'object_make_attempted':True,
            'four_object_compile_proven':True,'object_success_count':4,'kernel_version':'5.4.274',
            'config_walt_y':True,'vendor_abi_proven':False,'flash_allowed':False,
            'image_built':False,'brene_changed':False,
            'symbol_contract':{'checked':True,'defined':True,'referenced':True},
            'source_r12_sha256':self.gate['after_sha256'],'objects':self.objects}

    def good(self):
        self.assertTrue(audit.assert_r12(self.result,self.gate,self.objout,self.config))

    def reject(self,change,reason):
        copy_result=copy.deepcopy(self.result);copy_gate=copy.deepcopy(self.gate)
        change(copy_result,copy_gate)
        with self.assertRaisesRegex(audit.GateError,reason):
            audit.assert_r12(copy_result,copy_gate,self.objout,self.config)

    def test_01_positive_r12_result(self): self.good()
    def test_02_reject_no_r12_success(self): self.reject(lambda r,g:r.update(status='R12_COMPILER_ERRORS_RECORDED'),'R12_STATUS_NOT_SUCCESS')
    def test_03_reject_false_make_attempt(self): self.reject(lambda r,g:r.update(object_make_attempted=False),'R12_MAKE_NOT_ATTEMPTED')
    def test_04_reject_false_four_compile(self): self.reject(lambda r,g:r.update(four_object_compile_proven=False),'R12_FOUR_OBJECTS_NOT_PROVEN')
    def test_05_reject_three_objects(self): self.reject(lambda r,g:r.update(object_success_count=3),'R12_OBJECT_COUNT_BAD')
    def test_06_reject_wrong_kernelversion(self): self.reject(lambda r,g:r.update(kernel_version='5.4.268'),'R12_KERNEL_VERSION_OR_WALT_CONFIG')
    def test_07_reject_walt_off(self): self.reject(lambda r,g:r.update(config_walt_y=False),'R12_KERNEL_VERSION_OR_WALT_CONFIG')
    def test_08_reject_abi_claim(self): self.reject(lambda r,g:r.update(vendor_abi_proven=True),'R12_UNSAFE_SUCCESS_CLAIM')
    def test_09_reject_flash_claim(self): self.reject(lambda r,g:r.update(flash_allowed=True),'R12_UNSAFE_SUCCESS_CLAIM')
    def test_10_reject_image_claim(self): self.reject(lambda r,g:r.update(image_built=True),'R12_UNSAFE_SUCCESS_CLAIM')
    def test_11_reject_brene_claim(self): self.reject(lambda r,g:r.update(brene_changed=True),'R12_UNSAFE_SUCCESS_CLAIM')
    def test_12_reject_symbol_missing(self): self.reject(lambda r,g:r['symbol_contract'].update(referenced=False),'R12_SYMBOL_CONTRACT_INCOMPLETE')
    def test_13_reject_wrong_source(self): self.reject(lambda r,g:g.update(status='invalid'),'R12_SOURCE_GATE_INVALID')
    def test_14_reject_wrong_tree(self): self.reject(lambda r,g:g.update(canonical_p10_tree='wrong'),'R12_SOURCE_TREE_DRIFT')
    def test_15_reject_broken_chain(self): self.reject(lambda r,g:g.update(after_sha256={'a':'bad'}),'R12_SOURCE_HASH_CHAIN_BROKEN')
    def test_16_reject_missing_object(self):
        (self.objout/audit.R12_FOUR[0]).unlink()
        with self.assertRaisesRegex(audit.GateError,'R12_OBJECT_BYTES_CHANGED'):self.good()
    def test_17_reject_mutated_object(self):
        (self.objout/audit.R12_FOUR[0]).write_bytes(b'tampered')
        with self.assertRaisesRegex(audit.GateError,'R12_OBJECT_BYTES_CHANGED'):self.good()
    def test_18_reject_wrong_sha(self): self.reject(lambda r,g:r['objects'][audit.R12_FOUR[0]].update(object_sha256='b'*64),'R12_OBJECT_BYTES_CHANGED')
    def test_19_reject_object_false(self): self.reject(lambda r,g:r['objects'][audit.R12_FOUR[0]].update(compiled=False),'R12_OBJECT_REPORT_FAILED')
    def test_20_reject_missing_config(self):
        self.config.write_text(CONFIG.replace('CONFIG_CPU_FREQ=y','CONFIG_CPU_FREQ=n'))
        with self.assertRaisesRegex(audit.GateError,'R13_CONFIG_REQUIREMENT_MISSING'):self.good()
    def test_21_validate_oem_makefile(self): self.assertTrue(audit.verify_makefile(WALT_MAKEFILE))
    def test_22_reject_no_walt_makefile(self):
        with self.assertRaisesRegex(audit.GateError,'NO_WALT_KBUILD_LINE'):audit.verify_makefile('obj-y += sched.o')
    def test_23_reject_no_cpu_boost(self):
        with self.assertRaisesRegex(audit.GateError,'MISSING_FREQ_KBUILD_OBJECT'):audit.verify_makefile('\n'.join(WALT_MAKEFILE.splitlines()[:2]))
    def test_24_reject_duplicate_targets(self):
        with self.assertRaisesRegex(audit.GateError,'DUPLICATE_WALT_KBUILD_OBJECT'):audit.verify_makefile(WALT_MAKEFILE.replace('walt.o boost.o','walt.o walt.o boost.o'))
    def test_25_reject_missing_boost(self):
        with self.assertRaisesRegex(audit.GateError,'MISSING_WALT_KBUILD_OBJECT'):audit.verify_makefile(WALT_MAKEFILE.replace('boost.o',''))
    def test_26_all_six_success(self):
        s,n=audit.decide({x:{'compiled':True} for x in audit.TARGETS})
        self.assertEqual((s,n),('R13_SIX_ADDITIONAL_WALT_OBJECTS_COMPILED',6))
    def test_27_five_success(self):
        d={x:{'compiled':True} for x in audit.TARGETS};d[audit.TARGETS[0]]['compiled']=False
        self.assertEqual(audit.decide(d),('R13_COMPONENT_COMPILER_ERRORS_RECORDED',5))
    def test_28_missing_target_report(self):
        with self.assertRaisesRegex(audit.GateError,'INCOMPLETE_TARGET_REPORT'):audit.decide({x:{} for x in audit.TARGETS[:-1]})
    def test_29_reject_unapproved_target(self):
        with self.assertRaisesRegex(audit.GateError,'UNAUTHORIZED_TARGET'):audit.probe_one('Image',self.snap,self.objout,self.root,self.logdir,None,None,{})
    def test_30_missing_c_source_produces_diagnostic(self):
        x=audit.probe_one(audit.TARGETS[0],self.snap,self.objout,self.root,self.logdir,None,None,{})
        self.assertEqual(x['failure'],'SOURCE_FILE_MISSING');self.assertFalse(x['compiled'])
    def test_31_real_make_zero_requires_real_object(self):
        t=audit.TARGETS[0];(self.snap/(t[:-1]+'c')).parent.mkdir(parents=True,exist_ok=True)
        (self.snap/(t[:-1]+'c')).write_text('int abc;')
        def runner(argv,log,limit,env):
            log.write_text('CC')
            return {'exit_code':0,'timed_out':False,'log':str(log),'log_sha256':audit.sha256(log)}
        out=audit.probe_one(t,self.snap,self.objout,self.root,self.logdir,runner,lambda *a:['make'],{})
        self.assertFalse(out['compiled'])
    def test_32_real_object_zero_detected(self):
        t=audit.TARGETS[0];(self.snap/(t[:-1]+'c')).parent.mkdir(parents=True,exist_ok=True)
        (self.snap/(t[:-1]+'c')).write_text('int abc;')
        def runner(argv,log,limit,env):
            log.write_text('CC');p=self.objout/t;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'legit')
            return {'exit_code':0,'timed_out':False,'log':str(log),'log_sha256':audit.sha256(log)}
        out=audit.probe_one(t,self.snap,self.objout,self.root,self.logdir,runner,lambda *a:['make'],{})
        self.assertTrue(out['compiled']);self.assertEqual(out['object_sha256'],hashlib.sha256(b'legit').hexdigest())
    def test_33_nonzero_exit_rejected_even_with_object(self):
        t=audit.TARGETS[0];(self.snap/(t[:-1]+'c')).parent.mkdir(parents=True,exist_ok=True)
        (self.snap/(t[:-1]+'c')).write_text('int abc;')
        def runner(argv,log,limit,env):
            log.write_text('error: x');p=self.objout/t;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'stale')
            return {'exit_code':1,'timed_out':False,'log':str(log),'log_sha256':audit.sha256(log)}
        out=audit.probe_one(t,self.snap,self.objout,self.root,self.logdir,runner,lambda *a:['make'],{})
        self.assertFalse(out['compiled'])
    def test_34_output_guard(self):
        t=audit.TARGETS[0];p=self.objout/t;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'stale')
        with self.assertRaisesRegex(audit.GateError,'R13_OBJECT_ALREADY_EXISTS'):audit.probe_one(t,self.snap,self.objout,self.root,self.logdir,None,None,{})
    def test_35_exact_six_unique(self):
        self.assertEqual(len(audit.TARGETS),6);self.assertEqual(len(set(audit.TARGETS)),6)
    def test_36_no_flash_or_image(self):
        s=Path(audit.__file__).read_text()
        self.assertNotIn('make Image',s)
        self.assertNotIn('fastboot flash',s)
    def test_37_bounded_timeout(self):
        s=Path(audit.__file__).read_text()
        self.assertIn('log,300,env=env',s)
    def test_38_makefiles_pinned(self):
        self.assertEqual(audit.R12_TREE,'04e3831b70ed3ba19a7bd59e3054b7df5418941d')
    def test_39_all_oem_donor_files_pinned(self):
        self.assertEqual(len(audit.DONOR_PINS),7)
        self.assertTrue(all(len(x)==64 for x in audit.DONOR_PINS.values()))
    def test_40_donor_makefile_pin_correct(self):
        self.assertEqual(audit.DONOR_PINS['Makefile'],hashlib.sha256(WALT_MAKEFILE.encode()).hexdigest())

if __name__=='__main__':unittest.main()
