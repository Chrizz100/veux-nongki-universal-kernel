#!/usr/bin/env python3
"""VEUX R13: real, bounded ARM64 WALT-ON Kbuild probes of remaining subsystem objects.

Requires an independently verified R12 4/4 + symbol-contract result. Reuses the
historical pinned R9 compiler invocation on the disposable R12 kernel snapshot.
Never builds Image/vmlinux/AK3, modifies BReNE, or asserts Xiaomi vendor ABI.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys

R9_DRIVER_SHA = '3f4e00867d4d9bde05a89578c936e3c8cb51beaccc5d5c6382af7fb280593d66'
R12_TREE = '04e3831b70ed3ba19a7bd59e3054b7df5418941d'
R12_STATUS = 'R12_FOUR_REAL_OBJECTS_AND_SYMBOL_CONTRACT_PROVEN'
R12_FOUR = ('kernel/sched/walt/walt.o', 'kernel/sched/core.o',
            'kernel/sched/fair.o', 'kernel/sysctl.o')
WALT_OTHER = ('boost', 'sched_avg', 'qc_vas', 'core_ctl', 'trace')
FREQ_HELPER = 'cpu-boost'
TARGETS = tuple('kernel/sched/walt/'+x+'.o' for x in (*WALT_OTHER,FREQ_HELPER))
PINNED_STOCK_SHA = '334536114ee2c11287bc73c20a18073bc4fcc4d59656991e43a16bb917c7c868'
# Byte-exact donor files in P10 (authenticated MiCode source lineage).
DONOR_PINS = {
    'Makefile': 'd9cc1ca7540b940b89ac00197ca5c6e5cee2d5cc0fbf134fcf98c88cfe610906',
    'boost.c': '1b5a0017f66670265dd56bf9e47abbc425a0056eb56fbcbacd6c66a5373debc3',
    'sched_avg.c': 'f8948d50fc1b521d1963aa1da80a66cad4035a56bed1d1bcd7b4eb1d2ce82918',
    'qc_vas.c': '37b15da2f1cf93be1a56c085b838a8b13e4c0ff5db0a7afaebbe3fa887113942',
    'core_ctl.c': 'bd6ef23607128a3e5d806480947d14c3f16e91b9b365e1cbfa8ef434f32f65d2',
    'trace.c': 'a86ceeab941c8f2afeddf5169834b77ed3f706140c413a2853730e8ab89dadfc',
    'cpu-boost.c': '3337e10ae0eb9980598728c4b3f85e0985a00b9731c13586d52e2096ea06f634',
}

class GateError(Exception):
    pass

def demand(ok, message):
    if not ok:
        raise GateError(message)

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path):
    obj = json.loads(Path(path).read_text(encoding='utf-8'))
    demand(isinstance(obj, dict),'NOT_A_JSON_OBJECT')
    return obj

def is_regular(path):
    p=Path(path)
    return p.is_file() and not p.is_symlink()

def assert_r12(result, source_gate, objout, effective_config):
    """Authenticate four real compiled objects and exact source-stage contract."""
    demand(result.get('status')==R12_STATUS,'R12_STATUS_NOT_SUCCESS')
    demand(result.get('object_make_attempted') is True,'R12_MAKE_NOT_ATTEMPTED')
    demand(result.get('four_object_compile_proven') is True,'R12_FOUR_OBJECTS_NOT_PROVEN')
    demand(result.get('object_success_count')==4,'R12_OBJECT_COUNT_BAD')
    demand(result.get('kernel_version')=='5.4.274' and result.get('config_walt_y') is True,
           'R12_KERNEL_VERSION_OR_WALT_CONFIG')
    demand(result.get('vendor_abi_proven') is False and result.get('flash_allowed') is False
           and result.get('image_built') is False and result.get('brene_changed') is False,
           'R12_UNSAFE_SUCCESS_CLAIM')
    symbols=result.get('symbol_contract',{})
    demand(all(symbols.get(k) is True for k in ('checked','defined','referenced')),
           'R12_SYMBOL_CONTRACT_INCOMPLETE')
    demand(source_gate.get('status')=='R12_EXACT_XIAOMI_RAVG_SYSCTL_STAGED_NOT_COMPILED',
           'R12_SOURCE_GATE_INVALID')
    demand(source_gate.get('canonical_p10_tree')==R12_TREE,'R12_SOURCE_TREE_DRIFT')
    demand(result.get('source_r12_sha256')==source_gate.get('after_sha256'),
           'R12_SOURCE_HASH_CHAIN_BROKEN')
    for target in R12_FOUR:
        rec = result.get('objects',{}).get(target,{})
        obj=Path(objout)/target
        demand(rec.get('compiled') is True and rec.get('exit_code')==0 and
               rec.get('object_file_present') is True and rec.get('object_bytes',0)>0,
               'R12_OBJECT_REPORT_FAILED:'+target)
        demand(is_regular(obj) and obj.stat().st_size==rec['object_bytes']
               and sha256(obj)==rec.get('object_sha256'),
               'R12_OBJECT_BYTES_CHANGED:'+target)
    config=Path(effective_config).read_text(encoding='utf-8')
    for item in ('CONFIG_SCHED_WALT=y','CONFIG_CPU_FREQ=y','CONFIG_PROC_SYSCTL=y',
                 'CONFIG_QGKI=y','CONFIG_MODVERSIONS=y'):
        demand(re.search('(?m)^'+re.escape(item)+'$',config) is not None,
               'R13_CONFIG_REQUIREMENT_MISSING:'+item)
    return True

def verify_makefile(text):
    """Validate original source Makefile wiring; not just file-name similarity."""
    found=re.search(r'(?m)^obj-\$\(CONFIG_SCHED_WALT\)\s*\+=\s*(.+)$',text)
    demand(found is not None,'NO_WALT_KBUILD_LINE')
    toks=found.group(1).split()
    demand(len(toks)==len(set(toks)),'DUPLICATE_WALT_KBUILD_OBJECT')
    for x in ('walt.o',*(n+'.o' for n in WALT_OTHER)):
        demand(x in toks,'MISSING_WALT_KBUILD_OBJECT:'+x)
    demand(re.search(r'(?m)^obj-\$\(CONFIG_CPU_FREQ\)\s*\+=\s*cpu-boost\.o\s*$',text) is not None,
           'MISSING_FREQ_KBUILD_OBJECT')
    return True

def decide(records):
    demand(set(records)==set(TARGETS),'INCOMPLETE_TARGET_REPORT')
    n=sum(v.get('compiled') is True for v in records.values())
    return ('R13_SIX_ADDITIONAL_WALT_OBJECTS_COMPILED' if n==len(TARGETS) else
            'R13_COMPONENT_COMPILER_ERRORS_RECORDED'),n

def probe_one(target,snapshot,objout,toolchain,logdir,runner,argv_factory,env):
    demand(target in TARGETS,'UNAUTHORIZED_TARGET')
    name=target.replace('/','_')+'.log'
    log=logdir/name
    path=Path(objout)/target
    demand(not path.is_symlink() and not path.exists(), 'R13_OBJECT_ALREADY_EXISTS:'+target)
    source=Path(snapshot)/(target[:-1]+'c')
    if not is_regular(source):
        log.write_text('R13 SOURCE_FILE_MISSING: '+str(source)+'\n',encoding='utf-8')
        return {'compiled':False,'failure':'SOURCE_FILE_MISSING','exit_code':None,
                'log':str(log),'log_sha256':sha256(log),'object_file_present':False}
    outcome=runner(argv_factory(Path(snapshot),Path(objout),Path(toolchain),target,2),
                   log,300,env=env)
    present=is_regular(path) and path.stat().st_size>0
    good=bool(outcome.get('exit_code')==0 and not outcome.get('timed_out') and present)
    return {**outcome,'compiled':good,'object_file_present':present,
            'object_bytes':path.stat().st_size if present else 0,
            **({'object_sha256':sha256(path)} if present else {})}

def main_run(args):
    for d in (args.snapshot,args.objout,args.r12_report,args.r12_source_dir,args.toolchain):
        demand(d.is_dir() and not d.is_symlink(),'DIRECTORY_MISSING_OR_SYMLINK:'+str(d))
    demand(args.snapshot.resolve()!=args.project.resolve(),'R13_SNAPSHOT_IS_REPOSITORY')
    demand(not args.output.exists() and not args.output.is_symlink(),'R13_OUTPUT_ALREADY_EXISTS')
    demand(is_regular(args.driver) and sha256(args.driver)==R9_DRIVER_SHA,'R9_DRIVER_PIN_CHANGED')
    demand(is_regular(args.stock) and sha256(args.stock)==PINNED_STOCK_SHA,'OEM_STOCK_CONFIG_CHANGED')
    demand(is_regular(args.r12_report/'R12_COMPILER_RESULT.json'),'R12_REPORT_MISSING')
    demand(is_regular(args.r12_source_dir/'R12_SOURCE_GATE.json'),'R12_SOURCE_GATE_MISSING')
    demand(is_regular(args.r12_report/'R9_EFFECTIVE_CONFIG.config'),'R12_EFFECTIVE_CONFIG_MISSING')
    r12=read_json(args.r12_report/'R12_COMPILER_RESULT.json')
    gate=read_json(args.r12_source_dir/'R12_SOURCE_GATE.json')
    assert_r12(r12,gate,args.objout,args.r12_report/'R9_EFFECTIVE_CONFIG.config')
    for name,digest in gate['after_sha256'].items():
        f=args.snapshot/name
        demand(is_regular(f) and sha256(f)==digest,'R12_SOURCE_CHANGED:'+name)
    makefile=args.snapshot/'kernel/sched/walt/Makefile'
    demand(is_regular(makefile),'WALT_MAKEFILE_MISSING')
    verify_makefile(makefile.read_text(encoding='utf-8'))
    for name,digest in DONOR_PINS.items():
        p=args.snapshot/'kernel/sched/walt'/name
        demand(is_regular(p) and sha256(p)==digest,'R13_DONOR_SOURCE_DRIFT:'+name)
    # The pinned Android toolchain uses valid bin/ symlinks for some tools.
    demand((args.toolchain/'bin/clang').is_file() and (args.toolchain/'bin/llvm-nm').is_file(),
           'R13_HISTORICAL_TOOLCHAIN_MISSING')
    mod_name='veux_r9_build_driver'
    spec=importlib.util.spec_from_file_location(mod_name,args.driver)
    demand(spec is not None and spec.loader is not None,'PINNED_BUILD_DRIVER_NOT_LOADABLE')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    demand(getattr(mod,'make_argv',None) is not None and getattr(mod,'run_cmd',None) is not None,
           'PINNED_BUILD_DRIVER_INCOMPLETE')
    args.output.mkdir(parents=True)
    logdir=args.output/'compiler_logs';logdir.mkdir()
    results={}
    report={'status':'R13_STARTED','expected_targets':list(TARGETS),'objects':results,
      'source_r12_verified':True,'source_original_unchanged':True,'object_success_count':0,
      'kernel_image_built':False,'vmlinux_linked':False,'module_symvers_verified':False,
      'vendor_abi_proven':False,'flash_allowed':False,'brene_changed':False,
      'bakasusu_nomount_changed':False,'kernel_version':'5.4.274','walt_enabled':True}
    json_file=args.output/'R13_SUBSYSTEM_RESULT.json'
    json_file.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    env=os.environ.copy();env['PATH']=str(args.toolchain/'bin')+os.pathsep+env.get('PATH','')
    for target in TARGETS:
        results[target]=probe_one(target,args.snapshot,args.objout,args.toolchain,logdir,
                                  mod.run_cmd,mod.make_argv,env)
        report['objects']=results
        json_file.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    status,n=decide(results)
    report.update({'status':status,'object_success_count':n,'all_additional_objects_compiled':n==len(TARGETS)})
    json_file.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(f'R13_REAL_WALT_SUBSYSTEM_OBJECTS={n}/{len(TARGETS)}; STATUS={status}; IMAGE=NO; ABI=UNPROVEN; FLASH=NO')
    return report

def main():
    p=argparse.ArgumentParser()
    for n in ('snapshot','objout','r12-report','r12-source-dir','toolchain','driver','stock','output','project'):
        p.add_argument('--'+n,required=True,type=Path)
    args=p.parse_args()
    try:
        main_run(args)
    except (GateError,OSError,ValueError,KeyError,RuntimeError) as exc:
        print('R13_PRECOMPILATION_GATE_FAILED:'+str(exc),file=sys.stderr)
        return 2
    return 0
if __name__=='__main__':
    raise SystemExit(main())
