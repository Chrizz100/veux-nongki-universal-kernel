VEUX R60 — authentifizierte R13/R56-R4 Native54 CASS Compiler-/ABI-Fortsetzung
Datum: 03.11.2026, NO FLASH. Die Basis-Archive R13 und R56-R4 bleiben unveraendert.

Verbindlicher technischer Stand:
1) R59 stellt echte Source-Tools bereit, die auf dem separaten CI-Runner BakaSU 35259,
   SUSFS-5.4-Teildelta, CASS, NoMount und vier Native54 SELinux-Hostdateien
   zu einem gemeinsamen ARM64-Komprimierungs-Kandidaten zusammenfuehren.
2) Der R59-Build ist noch nicht tatsaechlich auf GitHub ausgefuehrt.
3) Die 14.648 historischen Imports stammen aus 218 Dateien in ZWEI
   inkompatiblen Kohorten. Der originale R30-R2-Befund nennt 836
   gleichnamige Symbole mit verschiedenen GKI-/QGKI-CRCs.
   Die neue R60-Analyse rechnet den Befund reproduzierbar aus dem
   SHA256-fixierten Original-R21-Datensatz nach.
4) Ein vollstaendiger CRC-PASS ueber beide historischen Kohorten ist fuer
   ein einzelnes Kernel-Module.symvers nicht gleichzeitig erreichbar.
   Ein Quell-/Compiler-PASS wird deshalb klar vom ABI-Release-PASS getrennt.
5) Das neue R60-Finalgate meldet einen unverifizierten OEM-Bootmodulsatz als
   BLOCKED und verhindert das falsche Gruen des kompletten Releases.
6) Native 5.4 SELinux/Postcompile Pruefung: postimage-SHA aller vier Hostdateien,
   tatsaechliche Objektdateien, nm-Symbole und 132 RMNET-CRCs werden erzwungen.
   Das Kontrollprogramm verwendet keine wegoptimierbaren Python-asserts.

Dateien fuer GitHub (in einem neuen Commit):
  VEUX_R60_NATIVE54_CASS_MAIN_NOFLASH.zip     (Repo-Hauptordner)
  .github/workflows/VEUX_R60_NATIVE54_CASS_BUILD_NOFLASH.yml

GitHub: Actions > VEUX R60 CASS native54 source compiler and cohort gate NOFLASH.
Der Workflow fuehrt actionlint 1.7.12 aus, dann den echten Build, den
getrennten QGKI/GKI Vergleich und das Final-Gate. Fail-closed bei Befunden.
Achtung: bisher nur lokale Tests, KEIN neuer GitHub-Vollbuild. Kein Image,
boot.img oder AK3 wird als flashbar publiziert. Keine Veraenderung am Telefon.
Fuer einen spaeteren OEM-ABI-PASS muss die tatsaechlich fuer den Bootvorgang
benoetigte Module-Load-Liste anhand belastbarer Geraete-/ROM-Belege feststehen.
Full Boot-/Device-/DTBO-/AK3-PASS ist weiterhin nicht erreicht.

R60 KCONFIG-KORREKTUR (03.11.2026):
  - Die originale R13 .config (4664 Einstellungen) bleibt die unveraenderliche Basis.
  - Neuer *fail-closed* tools/r60_config_guard.py prueft alle 4664 Baseline-Optionen.
  - Nur vier namentlich bekannte BakaSU 35259 Optionen und evtl. WALT=n
    duerfen als NEUE, DEAKTIVIERTE Schalter in olddefconfig hinzukommen.
  - Bei Aenderung einer einzigen alten Option oder unbekanntem Flag BLOCKED.
  - Das alte rohe byteweise cmp ist deshalb durch exakten semantischen
    Vergleich mit maschinenlesbarem R60_OLDDEFCONFIG_DELTA.json ersetzt.
  - Keine neuen Boot-Images, keine geaenderten OEM-CRCs, keine Flashfreigabe.
  - Native SUSFS type hash bucket matches now use stored exact type_value
    and check it at insertion/lookup; fixes false matches on collisions.
  - Dieser Patch ist ein lokaler 5.4-Backport-Fix, kein offizieller SUSFS-Commit.
  - R60-Compiler/GitHub-Run muss noch erfolgen.


R60-R4 (03.11.2026)
- Lauf 41602987413: alte R13-Basiskompilierung PASS, alle 132 RMNET-CRCs PASS, BakaSU-Replay PASS.
- R60-Integration scheiterte NUR an einem veralteten Preimage-Gate fuer services.c:
  Es erwartete den unveraenderten Xiaomi-/dereference23-Git-Blob, obwohl im
  nachweislich kompilierten R13-Quellbaum die R11/R13-Host-Exports vorliegen.
- Die zuvor erfolgreiche R13-Quellinventur und ein weiterer R13-Beleg nennen
  fuer security/selinux/ss/services.c genau SHA256 5e96d63c90cd102c6a92a4173430d44a44d5f86cf63345b39c678a842bad1e19.
- Die neue Integrationsstufe akzeptiert ausschliesslich genau diese R13-Datei,
  danach muessen Original-Patch, native Host-Hooks und der gemeinsame Kernelbau
  unveraendert alle weiteren Kbuild- und ABI-Gates bestehen.
- Original-R13 und R56 bleiben unveraendert. QUELLTEST-ERFOLG IST KEIN BUILDPASS.
- Kein boot.img/AK3, kein Flash, keine Bootfreigabe.
