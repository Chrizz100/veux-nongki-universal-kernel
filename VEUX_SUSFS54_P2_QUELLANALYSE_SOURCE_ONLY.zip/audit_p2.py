#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,subprocess,ast,re,sys,zipfile
from ruamel.yaml import YAML
base=Path('/mnt/data')
out=base/'veux_susfs_port_p2'
wf=base/'VEUX_SUSFS54_P2_R4_SOURCE_EXPORT_NO_FLASH.yml'
ref=base/'VEUX_NOMOUNT_DEV_8175_R4_BAKASU35234_BUILD.yml'
checks={}
def req(cond,name):
    checks[name]=bool(cond)
    if not cond: raise AssertionError(name)
sha=lambda data:hashlib.sha256(data).hexdigest()
a=YAML(typ='safe').load(wf.read_text())
b=YAML(typ='safe').load(ref.read_text())
req(a.get('on')==b.get('on'),'dispatch_input_preserved')
req(a.get('permissions')=={'contents':'read'},'read_only_permissions')
req(a.get('env')==b.get('env'),'pin_env_unchanged')
steps=a['jobs']['r5s2_bakasu_522']['steps']; orig=b['jobs']['r5s2_bakasu_522']['steps']
req(len(steps)==len(orig)+1==21,'one_step_addition')
copy=[s for s in steps if 'Export exact R4-composed' in s['name']]
req(len(copy)==1,'single_composed_source_export')
copy=copy[0]
req(copy.get('uses')=='actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a','upload_action_pinned')
req(copy['with']['if-no-files-found']=='error','required_source_files')
req(copy['if']==r'${{ inputs.enable_build == true }}','export_only_after_enabled_build')
sources=[x.strip() for x in copy['with']['path'].splitlines() if x.strip()]
req(len(sources)==9,'exactly_nine_capture_files')
req(len(set(sources))==9,'capture_paths_unique')
req(all(x.startswith('${{ runner.temp }}/veux-r5s2-work/builds/5.4.274/source-work/kernel/') for x in sources),'exact_composed_r4_kernel_path')
req(all('brene' not in x.lower() for x in sources),'brene_unmodified_uncaptured')
req(all(not any(s in x for s in ['..','*','?']) for x in sources),'no_capture_wildcards_or_parent_paths')
req('fs/namespace.c' in sources[1], 'namespace_capture_present')
req(any(x.endswith('/security/selinux/hooks.c') for x in sources) and any(x.endswith('/security/selinux/selinuxfs.c') for x in sources),'selinux_both_captured')
req(any(x.endswith('/fs/susfs.c') for x in sources),'susfs_core_captured')
req(any(x.endswith('/KernelSU/kernel/feature/selinux_hide.c') for x in sources),'bakasu_impl_captured')
# The 17 run blocks are identical to the SUCCESS R4 workflow save the workflow filename.
runs=[s.get('run') for s in steps if s.get('run') is not None]
orig_runs=[s.get('run') for s in orig if s.get('run') is not None]
req(len(runs)==17==len(orig_runs),'all_17_r4_shell_blocks_preserved')
old=ref.name;new=wf.name
req(all(x==y.replace(old,new) for x,y in zip(runs,orig_runs)),'r4_run_blocks_byte_identical_except_actionlint_filename')
for i,run in enumerate(runs,1):
    p=subprocess.run(['bash','-n'],input=run,text=True,capture_output=True)
    req(p.returncode==0,f'bash_n_{i:02}')
    # Inline Python is owned by heredoc and can be parsed verbatim.
    snippets=re.findall(r"(?ms)^python3?\s+-\s+<<'PY'\n(.*?)^PY\s*$",run)
    for j,sn in enumerate(snippets,1):
        ast.parse(sn,filename=f'inline_python_{i}_{j}')
        req(True,f'inline_python_{i}_{j}')
p=subprocess.run(['/mnt/data/veux_work/linter/actionlint','-oneline',str(wf)],capture_output=True,text=True)
req(p.returncode==0,'actionlint_1_7_12_clean')
req(all('brene' not in str(x).lower() for x in sources),'no_brene')
req('flash_approved' not in copy,'no_flash_approval')
req(a['jobs']['r5s2_bakasu_522']['timeout-minutes']==240,'original_timeout_preserved')
req(a['jobs']['r5s2_bakasu_522']['runs-on']==b['jobs']['r5s2_bakasu_522']['runs-on'],'original_runner_preserved')
req(a['jobs']['r5s2_bakasu_522']['if']==b['jobs']['r5s2_bakasu_522']['if'],'main_branch_repo_gate_preserved')
req(a['on']['workflow_dispatch']['inputs']['enable_build']['default']==False,'build_default_disabled')
req('ENABLE' not in a.get('permissions',{}),'no_elevated_permissions')
archives={p.name:sha(p.read_bytes()) for p in [base/'VEUX_NOMOUNT_DEV_8175_R4_MAIN.zip',base/'VEUX_SUSFS_54_CLONEMNT_PORT_P1_SOURCE_ONLY.zip']}
req(archives['VEUX_NOMOUNT_DEV_8175_R4_MAIN.zip']==a['env']['NMDEV_MAIN_SHA256'],'r4_zip_pin_matches_repo')
req(archives['VEUX_SUSFS_54_CLONEMNT_PORT_P1_SOURCE_ONLY.zip']=='9e5ca0aaa7df55332de39636e6b50fcbd3583bfe0966be2dd4748781425c405c','p1_reference_unchanged')
pys=[x for x in (out/'src').glob('*.py')]+[x for x in (out/'Tests').glob('*.py')]
for f in pys:
    ast.parse(f.read_text(),filename=f.name)
    req(True,'python_ast_'+f.stem)
(out/'evidence'/'STATIC_GREEN_PARTIAL.log').write_text('\n'.join(f'{k}=PASS' for k in checks)+'\nACTIONLINT_STDOUT='+p.stdout.strip()+'\n')
report={'schema':1,'result':'PASS_WITH_LOCAL_SHELLCHECK_NOT_AVAILABLE','checks_passed':sum(checks.values()),'checks_failed':0,'checks':checks,'workflow_sha256':sha(wf.read_bytes()),'source_zip_sha256':archives['VEUX_NOMOUNT_DEV_8175_R4_MAIN.zip'],'workflow_shell_block_count':len(runs),'yaml_steps':len(steps),'exported_source_file_count':len(sources),'no_flash':True,'r4_unchanged':True,'new_kernel_build_not_executed':True,'new_selinux_port_not_integrated':True,'standalone_shellcheck_final_p2':'NOT_RUN_LOCAL_BINARY_ABSENT','previous_r4_shellcheck':'PASS_17_OF_17_GITHUB_RUN_39207040902','next_step':'upload new yaml and enable_build=true for R4 baseline rebuild and source export'}
(out/'evidence'/'STATIC_AUDIT_P2.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
