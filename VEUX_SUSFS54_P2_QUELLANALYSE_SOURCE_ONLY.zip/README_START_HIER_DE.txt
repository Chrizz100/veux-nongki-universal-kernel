VEUX SUSFS 5.10 -> 5.4, P2: REALER R4 QUELLEXPORT + KLON_MNT-PRUEFKANDIDAT
Stand: 19.10.2026 | SOURCE-DIAGNOSE | KEIN FLASH | KEIN NEUER SUSFS KERNELPORT

ZIELE:
- R4 bleibt der unveraenderte, erfolgreich kompilierte Ausgangsstand.
- Neue GitHub-Actions-YAML exportiert 9 exakt zusammengesetzte Kernelquelldateien
  des erneuten R4-Kompilierlaufs, anstelle weiterer synthetischer Rateversuche.
- P2-Portierungsskript kennt den REALEN CI-Kernelpfad
  builds/5.4.274/source-work/kernel (P1-Pfadirrtum behoben).
- Read-only-Pruefung klassifiziert clone_mnt als PATCH_CANDIDATE, ALREADY_CORRECT
  oder BLOCKED. Kein Patch wird im P2-GitHub-Lauf angewendet.

GITHUB UPLOAD:
YAML: VEUX_SUSFS54_P2_R4_SOURCE_EXPORT_NO_FLASH.yml
Ziel: .github/workflows/
KEINE NEUE MAIN-ZIP fuer dieses Diagnose-Stadium benoetigt!
NICHT die bestehende R4-YAML oder R4_MAIN.zip ersetzen.

MANUELLER WORKFLOW-START:
Actions -> VEUX SUSFS 5.4 P2 R4 Composed Source Export - NO FLASH
-> Run workflow (branch main), enable_build=true
(Das fuehrt den bewaehrten R4-Kompilierlauf erneut aus; der Port ist NICHT aktiviert.)
Nach Abschluss: neuer Artefaktname VEUX-SUSFS54-P2-R4-COMPOSED-SOURCE-NO-FLASH-<run_id>.
Der Source-Snapshot enthaelt alle fuer P1 und SELinux-Port wichtigen Originalquellen.
Der bisherige unveraenderte AK3/boot.img wird NICHT geflasht.

DIE YML WURDE NICHT INS GITHUB REPOSITORY GESCHRIEBEN.
ACTIONS STATUS: Nicht gestartet. Neues P2-Source-Artefakt: noch nicht vorhanden.

Lokal geprueft:
- 53/53 neue P2-Tests erfolgreich, darunter 2 synthetische C-Smokes
- 281/281 R4-Regressionstests in 9 Gruppen bestanden
- 55/55 statische Workflow-Checks (ruamel.yaml, actionlint v1.7.12, Bash -n)
- Verwendete 17 Bash-Run-Bloecke unveraendert bis auf YAML-Dateinamen
- R4 GitHub Referenz: Run 39207040902 ShellCheck 17/17 PASS
OFFEN: Standalone ShellCheck auf den finalen P2-YAML-Bytes hier nicht installiert.
Deshalb noch KEIN vollstaendiger lokaler Static Green Pass! GitHub Actions
ueberprueft standalone shellcheck VOR der Kompilierung im unveraenderten Gate.

AKTUELLE UPSTREAM-REFERENZEN:
JackA1ltman NonGKI_Kernel_Build_2nd mainline susfs_patch_to_5.4.patch
Git blob: e2d4f7ad31f9a7b6819fbcedd1ba775bc10bb143
clone_mnt-Fix: 118ac2bc4f8bc25a41f0aef0d766ddc977feaec3
SUSFS alter Source Pin 5326e21a7eb232f9e21debdd5164e99bee3d1e2f
SUSFS neuer 5.10-Kandidat c1a8ccbb36f8e7d2cf9c28194fa8f2745dc767c1
R4 Firmware-Stand BakaSU 35234, NoMount DEV 8175; BReNE NICHT BERUEHRT.

Noch ungeprueft: exakter namespace.c Preimage-SHA, P1-Port auf realem VEUX,
SELinux hooks.c/selinuxfs.c Port, Kernelobjekte/ABI eines NEUEN Backports,
Gerateboot, Termux, Hunter/Duck. KEINE FLASHFREIGABE.
