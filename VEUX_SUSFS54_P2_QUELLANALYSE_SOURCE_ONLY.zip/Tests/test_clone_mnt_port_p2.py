"""Negative and positive isolated host checks. This does not build a kernel."""
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from veux_susfs54_clone_mnt_p2 import (Blocked, analyze, clone_span, plan_patch,
                                       plan_idempotence, sha256, TARGET, REFERENCE_SHA)

MAKE='VERSION = 5\nPATCHLEVEL = 4\nSUBLEVEL = 274\n'
OLD = r'''#include <linux/susfs_def.h>
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
#define CL_COPY_MNT_NS BIT(25)
#endif
static void mnt_free_id(struct mount *mnt)
{
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
    if (mnt->mnt.mnt_flags & VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT)
        return;
#endif
    ida_free(&mnt_id_ida, mnt->mnt_id);
}
static struct mount *susfs_alloc_unshare_ksu_vfsmnt(const char *name, int old_mnt_id)
{
 return (struct mount *)0;
}
static struct mount *clone_mnt(struct mount *old, struct dentry *root,
                              int flag)
{
    struct super_block *sb = old->mnt.mnt_sb;
    struct mount *mnt;
    int err;
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
    if (static_branch_unlikely(&susfs_is_sdcard_android_data_not_decrypted)) {
        if (susfs_is_current_ksu_domain()) {
            if (flag & CL_COPY_MNT_NS) {
                mnt = susfs_alloc_unshare_ksu_vfsmnt(old->mnt_devname, old->mnt_id);
                goto bypass_orig_flow;
            }
        }
    }
#endif // CONFIG_KSU_SUSFS_SUS_MOUNT
    mnt = alloc_vfsmnt(old->mnt_devname);
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
bypass_orig_flow:
#endif
    if (!mnt)
        return ERR_PTR(-ENOMEM);
    mnt->mnt.mnt_flags = old->mnt.mnt_flags;
    mnt->mnt.mnt_flags &= ~(MNT_WRITE_HOLD|MNT_MARKED|MNT_INTERNAL);
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
    if (static_branch_unlikely(&susfs_is_sdcard_android_data_not_decrypted)) {
        if (susfs_is_current_ksu_domain() && (flag & CL_COPY_MNT_NS))
            mnt->mnt.mnt_flags |= VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT;
    }
#endif // CONFIG_KSU_SUSFS_SUS_MOUNT
    // String brace should be ignored: "}"
    /* Comment brace { is not C block end */
    atomic_inc(&sb->s_active);
    return mnt;
}
/* Function outside clone_mnt; never change */
int brene_device_helper(void) { return 9; }
'''

class Case(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.top=Path(self.temp.name)
        self.src=self.top/'builds'/'5.4.274'/'source-work'/'kernel'
        self.src.mkdir(parents=True)
        self.mk=self.src/'Makefile'; self.mk.write_text(MAKE)
        self.dest=self.src/TARGET; self.dest.parent.mkdir()
        self.dest.write_text(OLD)
    def study(self, source=OLD):
        return plan_patch(source)
    def test_core_positive_candidate(self):
        st,result=self.study()
        self.assertEqual(st,'PATCH_CANDIDATE')
        self.assertIn('if (unlikely(is_mnt_ksu_unshared))',result)
    def test_modifies_only_three_explicit_sites(self):
        st,result=self.study()
        self.assertEqual(result.count('bool is_mnt_ksu_unshared = false;'),1)
        self.assertEqual(result.count('is_mnt_ksu_unshared = true;'),1)
        self.assertEqual(result.count('if (unlikely(is_mnt_ksu_unshared))'),1)
        self.assertEqual(result.count('brene_device_helper'),1)
    def test_identical_outside_clone(self):
        _,r=self.study()
        i,j=clone_span(OLD)
        a,b=clone_span(r)
        self.assertEqual(OLD[:i],r[:a]);self.assertEqual(OLD[j:],r[b:])
    def test_idempotent_existing_fix(self):
        _,r=self.study()
        self.assertEqual(plan_patch(r),('ALREADY_CORRECT',r))
    def test_read_only_audit_does_not_touch_source(self):
        before=self.dest.read_bytes()
        r=analyze(self.src)
        self.assertEqual(r['state'],'PATCH_CANDIDATE')
        self.assertFalse(r['source_updated'])
        self.assertEqual(before,self.dest.read_bytes())
    def test_diff_changes_only_namespace(self):
        r=analyze(self.src)
        self.assertTrue(r['diff'].startswith('--- a/fs/namespace.c\n+++ b/fs/namespace.c\n'))
        self.assertNotIn('security/selinux/',r['diff'])
    def test_no_pin_blocks_apply(self):
        with self.assertRaisesRegex(Blocked,'EXACT_PREIMAGE_SHA256_REQUIRED'):
            analyze(self.src,apply=True)
    def test_wrong_pin_blocks_apply(self):
        with self.assertRaisesRegex(Blocked,'PREIMAGE_HASH_MISMATCH'):
            analyze(self.src,apply=True,expected_sha256='a'*64)
    def test_exact_pin_applies_only_to_disposable_source(self):
        original=self.dest.read_bytes();hashold=sha256(original)
        r=analyze(self.src,apply=True,expected_sha256=hashold)
        self.assertTrue(r['source_updated'])
        self.assertNotEqual(original,self.dest.read_bytes())
        self.assertEqual(sha256(self.dest.read_bytes()),r['candidate_sha256'])
    def test_reapplication_blocked(self):
        analyze(self.src,apply=True,expected_sha256=sha256(self.dest.read_bytes()))
        with self.assertRaisesRegex(Blocked,'NO_NEW_SOURCE_CHANGE_TO_APPLY'):
            analyze(self.src,apply=True,expected_sha256=sha256(self.dest.read_bytes()))
    def test_not_disposable_path_blocks_apply(self):
        elsewhere=self.top/'normal'/'kernel'
        shutil.copytree(self.src,elsewhere)
        with self.assertRaisesRegex(Blocked,'DISPOSABLE_CI_BUILD_SOURCE_REQUIRED'):
            analyze(elsewhere,apply=True,expected_sha256=sha256((elsewhere/TARGET).read_bytes()))
    def test_previous_incorrect_ci_path_rejected(self):
        previous=self.top/'builds'/'5.4.274'/'kernel'
        shutil.copytree(self.src,previous)
        with self.assertRaisesRegex(Blocked,'DISPOSABLE_CI_BUILD_SOURCE_REQUIRED'):
            analyze(previous,apply=True,expected_sha256=sha256((previous/TARGET).read_bytes()))
    def test_p2_exact_ci_path_accepted(self):
        self.assertEqual(self.src.parent.name,'source-work')
        self.assertEqual(self.src.parent.parent.name,'5.4.274')
        self.assertEqual(self.src.parent.parent.parent.name,'builds')
        got=analyze(self.src,apply=True,expected_sha256=sha256(self.dest.read_bytes()))
        self.assertTrue(got['source_updated'])
    def test_bad_version_blocked(self):
        self.mk.write_text(MAKE.replace('274','273'))
        with self.assertRaisesRegex(Blocked,'KERNEL_NOT_5_4_274'): analyze(self.src)
    def test_wrong_major_blocked(self):
        self.mk.write_text(MAKE.replace('VERSION = 5','VERSION = 6'))
        with self.assertRaisesRegex(Blocked,'KERNEL_NOT_5_4_274'): analyze(self.src)
    def test_bad_makefile_parent_symlink(self):
        orig=self.dest.read_bytes()
        self.mk.unlink();self.mk.symlink_to(self.dest)
        with self.assertRaisesRegex(Blocked,'SYMLINK_FORBIDDEN'): analyze(self.src)
        self.assertEqual(self.dest.read_bytes(),orig)
    def test_target_symlink_blocked(self):
        target=self.src/'elsewhere.c'
        target.write_text(OLD)
        self.dest.unlink();self.dest.symlink_to(target)
        with self.assertRaisesRegex(Blocked,'SYMLINK_FORBIDDEN'): analyze(self.src)
    def test_missing_makefile_blocked(self):
        self.mk.unlink()
        with self.assertRaisesRegex(Blocked,'KERNEL_SOURCE_FILE_MISSING'): analyze(self.src)
    def test_missing_namespace_blocked(self):
        self.dest.unlink()
        with self.assertRaisesRegex(Blocked,'KERNEL_SOURCE_FILE_MISSING'): analyze(self.src)
    def test_missing_allocator_blocked(self):
        with self.assertRaisesRegex(Blocked,'EXPECTED_SUSFS_54_SOURCE_MISSING'):
            self.study(OLD.replace('susfs_alloc_unshare_ksu_vfsmnt','x' ))
    def test_missing_free_guard_blocked(self):
        with self.assertRaisesRegex(Blocked,'MNT_FREE_ID_GUARD_MISSING'):
            self.study(OLD.replace('if (mnt->mnt.mnt_flags & VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT)\n        return;','if (1)\n        break;'))
    def test_duplicate_function_blocked(self):
        with self.assertRaisesRegex(Blocked,'CLONE_MNT_DEFINITION_NOT_UNIQUE'):
            self.study(OLD+OLD)
    def test_unknown_flag_guard_blocked(self):
        with self.assertRaisesRegex(Blocked,'LEGACY_MOUNT_FLAG_GUARD_NOT_UNIQUE'):
            self.study(OLD.replace('static_branch_unlikely(&susfs_is_sdcard_android_data_not_decrypted)) {\n        if (susfs_is_current_ksu_domain() &&', 'static_branch_likely(&susfs_is_sdcard_android_data_not_decrypted)) {\n        if (susfs_is_current_ksu_domain() &&'))
    def test_partial_decl_blocked(self):
        with self.assertRaisesRegex(Blocked,'PARTIAL_OR_UNKNOWN'):
            self.study(OLD.replace('int err;','int err;\n    bool is_mnt_ksu_unshared = false;'))
    def test_missing_allocation_blocked(self):
        with self.assertRaisesRegex(Blocked,'UNSHARED_ALLOCATION_GOTO_NOT_UNIQUE'):
            self.study(OLD.replace('goto bypass_orig_flow;', 'return ERR_PTR(-ENOMEM);'))
    def test_double_allocation_blocked(self):
        with self.assertRaisesRegex(Blocked,'UNSHARED_ALLOCATION'):
            self.study(OLD.replace('goto bypass_orig_flow;', 'goto bypass_orig_flow;\n                mnt = susfs_alloc_unshare_ksu_vfsmnt(old->mnt_devname, old->mnt_id);'))
    def test_out_of_scope_allocation_blocked(self):
        with self.assertRaisesRegex(Blocked,'UNSHARED_ALLOCATION_NOT_UNDER_CL_COPY_MNT_NS'):
            self.study(OLD.replace('if (flag & CL_COPY_MNT_NS) {','if (flag & CL_COPY_MNT_NS) {\n                x=1;'))
    def test_legacy_not_in_config_scope_blocked(self):
        s=OLD.replace('#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT\n    if (static_branch_unlikely(&susfs_is_sdcard_android_data_not_decrypted)) {\n        if (susfs_is_current_ksu_domain() && (flag & CL_COPY_MNT_NS))',
                    '#endif // badly closed\n    if (static_branch_unlikely(&susfs_is_sdcard_android_data_not_decrypted)) {\n        if (susfs_is_current_ksu_domain() && (flag & CL_COPY_MNT_NS))')
        with self.assertRaisesRegex(Blocked,'LEGACY_FLAG_GUARD_WRONG_CONFIG_SCOPE'):
            self.study(s)
    def test_wrong_kernel_source_with_nul_blocked(self):
        self.dest.write_bytes(OLD.encode()+b'\x00')
        with self.assertRaisesRegex(Blocked,'SOURCE_CONTAINS_NUL'): analyze(self.src)
    def test_only_one_file_is_written(self):
        before_make=self.mk.read_bytes()
        analyze(self.src,apply=True,expected_sha256=sha256(self.dest.read_bytes()))
        self.assertEqual(before_make,self.mk.read_bytes())
    def test_decl_inside_config_guard(self):
        _,r=self.study()
        self.assertRegex(r,r'int err;\n#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT\n\s*bool is_mnt_ksu_unshared = false;\n#endif')
    def test_allocation_first_flag_later(self):
        _,r=self.study()
        self.assertLess(r.index('is_mnt_ksu_unshared = true;'),r.index('if (unlikely(is_mnt_ksu_unshared))'))
    def test_reference_pin_present(self):
        self.assertEqual(REFERENCE_SHA,'e2d4f7ad31f9a7b6819fbcedd1ba775bc10bb143')
    def test_new_flag_scope_preserved(self):
        _,r=self.study()
        self.assertIn('#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT\n    if (unlikely(is_mnt_ksu_unshared))',r)
    def test_generated_hash_is_correct(self):
        r=analyze(self.src)
        _,s=self.study()
        self.assertEqual(r['candidate_sha256'],sha256(s.encode()))
    def test_unexpected_old_guard_parenthesization_blocked(self):
        with self.assertRaisesRegex(Blocked,'LEGACY_MOUNT_FLAG_GUARD_NOT_UNIQUE'):
            self.study(OLD.replace('(flag & CL_COPY_MNT_NS))\n            mnt->mnt.mnt_flags', '(flag & (CL_COPY_MNT_NS | CL_EXPIRE)))\n            mnt->mnt.mnt_flags'))
    def test_extra_unexpected_duplicate_new_flag_blocked(self):
        _,r=self.study()
        s=r.replace('if (unlikely(is_mnt_ksu_unshared))','if (unlikely(is_mnt_ksu_unshared))\n    if (unlikely(is_mnt_ksu_unshared))')
        with self.assertRaisesRegex(Blocked,'CORRECT_GUARD_DUPLICATED'):
            self.study(s)
    def test_device_and_flash_always_false(self):
        r=analyze(self.src)
        self.assertFalse(r['device_tested'])
        self.assertFalse(r['flash_approved'])
    def test_report_schema_immutable_reference(self):
        r=analyze(self.src)
        self.assertEqual(r['kernel'],'5.4.274')
        self.assertEqual(r['scope'],'fs/namespace.c')
        self.assertEqual(r['reference_jack_git_blob'],REFERENCE_SHA)

if __name__=='__main__': unittest.main()
