"""Bounded ZIP read-only source snapshot tests (P2)."""
from pathlib import Path
import json
import zipfile
import tempfile
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from veux_susfs54_p2_export_review import read_capture,review,SCOPE,PINNED_R4
from test_clone_mnt_port_p2 import OLD,MAKE

class ArchiveCases(unittest.TestCase):
    def setUp(self):
        self.d=tempfile.TemporaryDirectory()
        self.addCleanup(self.d.cleanup)
        self.zip=Path(self.d.name)/'src.zip'
        self.files={x:('R4_SOURCE_ONLY '+x+'\n').encode() for x in SCOPE}
        self.files['fs/namespace.c']=OLD.encode()
        self.files['Makefile']=MAKE.encode()
    def make(self, files=None, prefix=''):
        with zipfile.ZipFile(self.zip,'w') as z:
            for p,b in (files if files is not None else self.files).items():
                z.writestr(prefix+p,b)
    def test_archive_core_success(self):
        self.make()
        got=read_capture(self.zip)
        self.assertEqual(set(got),set(SCOPE))
        self.assertEqual(got['fs/namespace.c'],OLD.encode())
    def test_capture_with_uniform_prefix(self):
        self.make(prefix='source-work/kernel/')
        self.assertEqual(len(read_capture(self.zip)),len(SCOPE))
    def test_r4_pins_are_checked_not_invented(self):
        self.make()
        r=review(self.zip)
        self.assertEqual(r['port_state'],'PATCH_CANDIDATE')
        self.assertFalse(r['r4_selinux_pins_all_match'])
        self.assertFalse(r['real_kernel_source_mutated'])
        self.assertIn('if (unlikely(is_mnt_ksu_unshared))',r['candidate_diff'])
    def test_version_mismatch_rejected(self):
        x=dict(self.files);x['Makefile']=MAKE.replace('274','273').encode();self.make(x)
        with self.assertRaisesRegex(ValueError,'WRONG_KERNEL_VERSION'):read_capture(self.zip)
    def test_missing_file_rejected(self):
        x=dict(self.files);x.pop('fs/susfs.c');self.make(x)
        with self.assertRaisesRegex(ValueError,'EXACT_FILE_COUNT'):read_capture(self.zip)
    def test_unexpected_file_rejected(self):
        x=dict(self.files);x.pop('fs/susfs.c');x['kernel/evil.c']=b'x';self.make(x)
        with self.assertRaisesRegex(ValueError,'UNEXPECTED_SOURCE_FILE'):read_capture(self.zip)
    def test_inconsistent_prefix_rejected(self):
        x=dict(self.files)
        with zipfile.ZipFile(self.zip,'w') as z:
            for i,(p,b) in enumerate(x.items()):z.writestr(('one/' if i==0 else 'two/')+p,b)
        with self.assertRaisesRegex(ValueError,'INCONSISTENT_PREFIX'):read_capture(self.zip)
    def test_double_path_rejected(self):
        with zipfile.ZipFile(self.zip,'w') as z:
            for p,b in self.files.items():z.writestr(p,b)
            z.writestr('fs/namespace.c',OLD)
        with self.assertRaisesRegex(ValueError,'EXACT_FILE_COUNT'):read_capture(self.zip)
    def test_traversal_rejected(self):
        x=dict(self.files);x.pop('fs/susfs.c');x['../fs/susfs.c']=b'x';self.make(x)
        with self.assertRaisesRegex(ValueError,'UNSAFE_ARCHIVE_PATH'):read_capture(self.zip)
    def test_bad_archive_crc_rejected(self):
        self.zip.write_bytes(b'not a zip')
        with self.assertRaises(zipfile.BadZipFile):read_capture(self.zip)
    def test_brene_never_captured(self):
        self.make()
        self.assertFalse(any('brene' in s.lower() for s in read_capture(self.zip)))
    def test_pinned_r4_hashes_present(self):
        self.assertEqual(len(PINNED_R4),3)
        self.assertTrue(all(len(s)==64 for s in PINNED_R4.values()))

if __name__=='__main__':unittest.main()
