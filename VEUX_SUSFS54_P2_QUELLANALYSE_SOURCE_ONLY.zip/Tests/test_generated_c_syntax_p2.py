"""Synthetic C smoke checks; NOT real VEUX/Linux header or vendor-ABI tests."""
from pathlib import Path
import os
import shutil
import subprocess
import tempfile
import unittest
from test_clone_mnt_port_p2 import OLD
from veux_susfs54_clone_mnt_p2 import plan_patch

STUB=r'''
#include <stdbool.h>
#include <stddef.h>
#include <stdio.h>
#define BIT(n) (1U << (n))
#define unlikely(x) (x)
#define static_branch_unlikely(x) (*(x))
#define MNT_WRITE_HOLD (1U << 0)
#define MNT_MARKED (1U << 1)
#define MNT_INTERNAL (1U << 2)
#define VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT (1U << 4)
#define ENOMEM 12
#define ERR_PTR(x) ((struct mount *)0)
#define atomic_inc(x) (++*(x))
struct super_block { int s_active; };
struct dentry { int dummy; };
struct mount {struct {struct super_block *mnt_sb; unsigned mnt_flags;} mnt;const char *mnt_devname; int mnt_id;};
static struct mount global_new;
static int mnt_id_ida;
static int susfs_is_sdcard_android_data_not_decrypted=0;
static bool ksu_domain = false;
static int ida_free(int *ignored, int id) { (void)ignored; (void)id; return 0; }
static bool susfs_is_current_ksu_domain(void) {return ksu_domain;}
static struct mount *alloc_vfsmnt(const char *name) { (void)name;return &global_new; }
'''
MAIN=r'''
int main(void) {
    struct super_block sb={0};
    struct mount old={0}; struct dentry d={0};
    old.mnt.mnt_sb=&sb;
    ksu_domain=true;
    susfs_is_sdcard_android_data_not_decrypted=1;
    global_new.mnt.mnt_flags=0;
    if (!clone_mnt(&old,&d,(1U<<25))) return 1;
#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT
    if (!(global_new.mnt.mnt_flags & VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT)) return 2;
    ksu_domain=false;
    global_new.mnt.mnt_flags=0;
    if (!clone_mnt(&old,&d,(1U<<25))) return 3;
    if (global_new.mnt.mnt_flags & VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT) return 4;
    ksu_domain=true;
    susfs_is_sdcard_android_data_not_decrypted=0;
    global_new.mnt.mnt_flags=0;
    if (!clone_mnt(&old,&d,(1U<<25))) return 5;
    if (global_new.mnt.mnt_flags & VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT) return 6;
#endif
    return 0;
}
'''
class CSmoke(unittest.TestCase):
    def compile_and_run(self,config):
        cc=shutil.which('gcc') or shutil.which('cc')
        if not cc: self.skipTest('no host C compiler')
        _,patched=plan_patch(OLD)
        # Discard fixture's artificial marker include; Linux C types are mocked.
        src=patched.replace('#include <linux/susfs_def.h>\n','').replace(
             'return (struct mount *)0;', 'return &global_new;')
        source=STUB+src+MAIN
        with tempfile.TemporaryDirectory() as td:
            c=Path(td)/'test.c'; o=Path(td)/'a.out'
            c.write_text(source)
            cmd=[cc,'-std=gnu11','-Werror','-Wno-unused-function','-Wno-unused-variable',
                 '-Wno-unused-parameter','-Wno-unused-label','-Wno-unused-but-set-variable',
                 '-o',str(o),str(c)]
            if config: cmd.insert(1,'-DCONFIG_KSU_SUSFS_SUS_MOUNT=1')
            p=subprocess.run(cmd,capture_output=True,text=True)
            self.assertEqual(p.returncode,0,p.stderr)
            p=subprocess.run([str(o)],capture_output=True,text=True)
            self.assertEqual(p.returncode,0,f'runtime code={p.returncode}: {p.stderr}')
    def test_config_susfs_y_synthetic_c(self): self.compile_and_run(True)
    def test_config_susfs_n_synthetic_c(self): self.compile_and_run(False)
