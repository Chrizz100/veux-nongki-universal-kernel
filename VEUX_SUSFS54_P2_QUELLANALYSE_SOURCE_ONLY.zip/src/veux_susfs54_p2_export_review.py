#!/usr/bin/env python3
"""Inspect the EXACT source snapshot from the VEUX R4 P2 GitHub action.

Read-only: no kernel file is modified. This local tool audits a bounded ZIP,
probes the clone_mnt P2 patch, emits SHA-256 and an optional .patch proposal.
All source changes must be separately authorized, pinned and tested on the
composed 5.4.274 kernel before any build or flash.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import re
import stat
import tempfile
import zipfile
from veux_susfs54_clone_mnt_p2 import analyze, Blocked, TARGET

SCOPE = (
    'Makefile', 'fs/namespace.c', 'fs/susfs.c', 'fs/statfs.c',
    'security/selinux/hooks.c', 'security/selinux/selinuxfs.c',
    'KernelSU/kernel/feature/selinux_hide.c',
    'include/linux/susfs.h', 'include/linux/susfs_def.h',
)
PINNED_R4 = {
    'security/selinux/hooks.c': '57a84c1b0f41d108e9557314c0039e5bfd6fc4b15aa60532711d32e551cc2992',
    'security/selinux/selinuxfs.c': '16533ae84611ddc908759231a06ac09722cbeda3cba7ebc361baa1ee462729a1',
    'KernelSU/kernel/feature/selinux_hide.c': '78231ad073f1437804cd6b340dfd7273f5d25591c43ebb69f443cabacdfa8b78',
}
LIMIT_ONE = 4_000_000
LIMIT_ALL = 12_000_000

def sha(data: bytes)->str:
    return hashlib.sha256(data).hexdigest()


def require(ok, why):
    if not ok:
        raise ValueError(why)


def read_capture(path: Path) -> dict[str, bytes]:
    """Read only known source paths, accepting one normalized common prefix."""
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None, 'SNAPSHOT_ZIP_CRC_ERROR')
        files = [i for i in z.infolist() if not i.is_dir()]
        require(len(files) == len(SCOPE), 'SNAPSHOT_EXACT_FILE_COUNT_MISMATCH')
        seen=set(); chosen={}; prefix=None; total=0
        for i in files:
            fn = i.filename
            require(fn not in seen, 'SNAPSHOT_DUPLICATE_ENTRY')
            seen.add(fn)
            require(not fn.startswith('/') and '\\' not in fn and '\x00' not in fn
                    and '..' not in Path(fn).parts, 'SNAPSHOT_UNSAFE_ARCHIVE_PATH')
            require(stat.S_IFMT(i.external_attr>>16) != stat.S_IFLNK, 'SNAPSHOT_SYMLINK_FORBIDDEN')
            require(i.file_size <= LIMIT_ONE and i.compress_size < LIMIT_ONE,
                    'SNAPSHOT_FILE_TOO_LARGE')
            total += i.file_size
            require(total <= LIMIT_ALL, 'SNAPSHOT_UNCOMPRESSED_LIMIT')
            possible=[p for p in SCOPE if fn == p or fn.endswith('/'+p)]
            require(len(possible)==1, 'SNAPSHOT_UNEXPECTED_SOURCE_FILE:'+fn)
            expected=possible[0]
            start=fn[:-len(expected)]
            require(prefix is None or start == prefix, 'SNAPSHOT_INCONSISTENT_PREFIX')
            prefix=start
            require(expected not in chosen, 'SNAPSHOT_DUPLICATE_CANONICAL_FILE')
            chosen[expected]=z.read(i)
        require(set(chosen)==set(SCOPE), 'SNAPSHOT_MISSING_EXPECTED_FILE')
    m=chosen['Makefile'].decode('utf-8','replace')
    v=[]
    for key in ('VERSION','PATCHLEVEL','SUBLEVEL'):
        lines=re.findall(r'^\s*'+key+r'\s*=\s*(\d+)\s*$',m,re.M)
        require(len(lines)==1,'SNAPSHOT_INVALID_MAKEFILE_VERSION:'+key)
        v.append(lines[0])
    require('.'.join(v)=='5.4.274','SNAPSHOT_WRONG_KERNEL_VERSION')
    return chosen


def review(archive:Path)->dict:
    files=read_capture(archive)
    digests={p:sha(v) for p,v in files.items()}
    pins={p:{'sha256':digests[p],'expected_r4_sha256':ref,'match':digests[p]==ref}
          for p,ref in PINNED_R4.items()}
    with tempfile.TemporaryDirectory() as d:
        base=Path(d)/'builds'/'5.4.274'/'source-work'/'kernel'
        for name,data in files.items():
            p=base/name; p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
        try:
            p1=analyze(base)
            outcome=p1['state']
            diff=p1.pop('diff')
        except (Blocked, OSError, UnicodeError) as e:
            outcome='BLOCKED'
            p1={'state':outcome,'reason':str(e),'source_updated':False}
            diff=''
    return {'schema':2,'status':'SOURCE_CAPTURE_VERIFIED',
            'port_state':outcome,'clone_mnt_p2':p1,'candidate_diff':diff,
            'files_sha256':digests,'r4_baseline_pin_checks':pins,
            'r4_selinux_pins_all_match':all(v['match'] for v in pins.values()),
            'all_files_exported':True,'composed_kernel_compiled_under_r4_pipeline':True,
            'real_kernel_source_mutated':False,'native_510_susfs_imported':False,
            'device_tested':False,'flash_approved':False}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source_snapshot_zip', type=Path)
    ap.add_argument('--report',type=Path)
    ap.add_argument('--patch',type=Path)
    args=ap.parse_args()
    out=review(args.source_snapshot_zip)
    diff=out.pop('candidate_diff')
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(out,sort_keys=True,indent=2)+'\n')
    if args.patch and diff:
        args.patch.parent.mkdir(parents=True,exist_ok=True)
        args.patch.write_text(diff)
    print(json.dumps(out,sort_keys=True,indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
