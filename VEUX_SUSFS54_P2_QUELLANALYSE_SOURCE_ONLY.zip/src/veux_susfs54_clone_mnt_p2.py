#!/usr/bin/env python3
"""VEUX Linux 5.4.274: fail-closed, one-function SUSFS clone_mnt fix candidate.

Reference: JackA1ltman NonGKI_Kernel_Build_2nd, mainline,
Patches/Patch/susfs_patch_to_5.4.patch @ Git blob e2d4f7ad31f9a7b6819fbcedd1ba775bc10bb143
last relevant change: 118ac2bc4f8bc25a41f0aef0d766ddc977feaec3.

Read-only by default. Applies ONLY with expected exact full preimage SHA256,
and only inside the temporary GitHub build layout builds/5.4.274/source-work/kernel.
Neither production kernel nor GitHub repo nor Android phone is modified.
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile

KERNEL = '5.4.274'
TARGET = 'fs/namespace.c'
REFERENCE_SHA = 'e2d4f7ad31f9a7b6819fbcedd1ba775bc10bb143'
JACK_COMMIT = '118ac2bc4f8bc25a41f0aef0d766ddc977feaec3'
FILE_LINE = 'mnt->mnt.mnt_flags |= VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT;'
EXPECTED_NEW_GUARD = 'if (unlikely(is_mnt_ksu_unshared))'


class Blocked(RuntimeError):
    """Do not patch. Exact anchors, layout or source integrity not proven."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(x: bool, reason: str) -> None:
    if not x:
        raise Blocked(reason)


def clone_span(source: str) -> tuple[int, int]:
    """Return full clone_mnt function span, ignoring braces in C comments/strings."""
    defs = list(re.finditer(r'\bstatic\s+struct\s+mount\s*\*\s*clone_mnt\s*\(', source))
    require(len(defs) == 1, 'CLONE_MNT_DEFINITION_NOT_UNIQUE')
    start = defs[0].start()
    pos = defs[0].end()
    # Prototype ending before function body is not an accepted source.
    brace = source.find('{', pos)
    semi = source.find(';', pos)
    require(brace >= 0 and (semi < 0 or semi > brace), 'CLONE_MNT_NOT_A_FUNCTION')
    depth = 0
    state = 'normal'
    i = brace
    while i < len(source):
        ch = source[i]
        nxt = source[i+1] if i+1 < len(source) else ''
        if state == 'line':
            if ch == '\n':
                state = 'normal'
        elif state == 'block':
            if ch == '*' and nxt == '/':
                state = 'normal'; i += 1
        elif state == 'string':
            if ch == '\\': i += 1
            elif ch == '"': state = 'normal'
        elif state == 'char':
            if ch == '\\': i += 1
            elif ch == "'": state = 'normal'
        elif ch == '/' and nxt == '/':
            state = 'line'; i += 1
        elif ch == '/' and nxt == '*':
            state = 'block'; i += 1
        elif ch == '"': state = 'string'
        elif ch == "'": state = 'char'
        elif ch == '{': depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                return start, i+1
            require(depth >= 0, 'BRACES_UNBALANCED')
        i += 1
    raise Blocked('CLONE_MNT_BRACE_UNCLOSED')


OLD_GUARD = re.compile(
    r'(?P<indent>^[ \t]*)if\s*\(\s*static_branch_unlikely\s*\(\s*'
    r'&susfs_is_sdcard_android_data_not_decrypted\s*\)\s*\)\s*\{\s*'
    r'if\s*\(\s*susfs_is_current_ksu_domain\s*\(\s*\)\s*&&\s*'
    r'\(\s*flag\s*&\s*CL_COPY_MNT_NS\s*\)\s*\)\s*'
    r'mnt->mnt\.mnt_flags\s*\|=\s*VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT\s*;\s*\}',
    flags=re.M,
)
ALLOC = re.compile(
    r'(?P<indent>^[ \t]*)mnt\s*=\s*susfs_alloc_unshare_ksu_vfsmnt\s*\('
    r'\s*old->mnt_devname\s*,\s*old->mnt_id\s*\)\s*;\s*'
    r'(?P<goto>goto\s+bypass_orig_flow\s*;)',
    flags=re.M,
)
DECL = re.compile(r'(?m)^(?P<indent>[ \t]*)int\s+err\s*;[ \t]*$')


def eligible(source: str) -> bool:
    # The fix only addresses an already-integrated SUS_MOUNT implementation.
    for s in ('CONFIG_KSU_SUSFS_SUS_MOUNT', 'CL_COPY_MNT_NS',
              'susfs_alloc_unshare_ksu_vfsmnt', 'VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT',
              'static void mnt_free_id('):
        require(s in source, 'EXPECTED_SUSFS_54_SOURCE_MISSING:' + s)
    # Require free guard for reused IDs, not just text anywhere in file.
    a = source.index('static void mnt_free_id(')
    b = source.find('}', a)
    require(b > a and 'VFSMOUNT_MNT_FLAGS_KSU_UNSHARED_MNT' in source[a:b]
            and 'return;' in source[a:b], 'MNT_FREE_ID_GUARD_MISSING')
    return True


def plan_patch(source: str) -> tuple[str, str]:
    """Pure function: return (state, proposed_source). No filesystem writes."""
    eligible(source)
    a, b = clone_span(source)
    func = source[a:b]
    correct = EXPECTED_NEW_GUARD in func
    decl_present = bool(re.search(r'\bbool\s+is_mnt_ksu_unshared\s*=\s*false\s*;', func))
    mark_present = bool(re.search(r'\bis_mnt_ksu_unshared\s*=\s*true\s*;', func))
    old = list(OLD_GUARD.finditer(func))
    if correct and decl_present and mark_present and not old:
        require(func.count(EXPECTED_NEW_GUARD) == 1
                and func.count('is_mnt_ksu_unshared = true;') == 1,
                'CORRECT_GUARD_DUPLICATED')
        return 'ALREADY_CORRECT', source
    require(not (correct or decl_present or mark_present), 'PARTIAL_OR_UNKNOWN_CLONE_MNT_PORT')
    require(len(old) == 1, 'LEGACY_MOUNT_FLAG_GUARD_NOT_UNIQUE')
    # The old conditional must be part of the precise CONFIG_KSU_SUSFS_SUS_MOUNT block.
    prefix = func[:old[0].start()]
    suffix = func[old[0].end():]
    require(prefix.rfind('#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT') >
            prefix.rfind('#endif'), 'LEGACY_FLAG_GUARD_WRONG_CONFIG_SCOPE')
    require(re.search(r'#endif\s*(?://[^\n]*)?\s*', suffix),
            'LEGACY_FLAG_GUARD_NO_ENDIF')
    require(len(DECL.findall(func)) == 1, 'CLONE_MNT_ERR_DECL_NOT_UNIQUE')
    allocations = list(ALLOC.finditer(func))
    require(len(allocations) == 1, 'UNSHARED_ALLOCATION_GOTO_NOT_UNIQUE')
    require(func.count('susfs_alloc_unshare_ksu_vfsmnt(') == 1,
            'UNSHARED_ALLOCATION_COUNT_DRIFT')
    # Ensure the path is allocated only for a CL_COPY_MNT_NS copy.
    aprefix = func[:allocations[0].start()]
    require(re.search(r'if\s*\(\s*flag\s*&\s*CL_COPY_MNT_NS\s*\)\s*\{\s*$', aprefix),
            'UNSHARED_ALLOCATION_NOT_UNDER_CL_COPY_MNT_NS')
    # Modify exactly three sites: local bool, assignment on reused-ID branch,
    # and mnt_flags test using that bool. No changes to other kernel files.
    def insert_decl(m: re.Match) -> str:
        indent = m.group('indent')
        return (m.group(0) + '\n#ifdef CONFIG_KSU_SUSFS_SUS_MOUNT\n'
                + indent + 'bool is_mnt_ksu_unshared = false;\n'
                + '#endif // CONFIG_KSU_SUSFS_SUS_MOUNT')
    newer = DECL.sub(insert_decl, func, count=1)
    def insert_mark(m: re.Match) -> str:
        indent = m.group('indent')
        return (indent + 'mnt = susfs_alloc_unshare_ksu_vfsmnt(old->mnt_devname, old->mnt_id);\n'
                + indent + 'is_mnt_ksu_unshared = true;\n'
                + indent + m.group('goto'))
    newer, n = ALLOC.subn(insert_mark, newer)
    require(n == 1, 'UNSHARED_ALLOCATION_UPDATE_FAILED')
    def insert_guard(m: re.Match) -> str:
        indent = m.group('indent')
        return (indent + 'if (unlikely(is_mnt_ksu_unshared))\n'
                + indent + '\t' + FILE_LINE)
    newer, n = OLD_GUARD.subn(insert_guard, newer)
    require(n == 1, 'MOUNT_FLAG_FIX_FAILED')
    result = source[:a] + newer + source[b:]
    new_span = clone_span(result)
    ported = result[new_span[0]:new_span[1]]
    require(ported.count(EXPECTED_NEW_GUARD) == 1
            and ported.count('is_mnt_ksu_unshared = true;') == 1
            and ported.count('bool is_mnt_ksu_unshared = false;') == 1,
            'POST_PATCH_CLONE_MNT_REVIEW_FAILED')
    require(plan_idempotence(result), 'NON_IDEMPOTENT_PATCH')
    return 'PATCH_CANDIDATE', result


def plan_idempotence(source: str) -> bool:
    a,b = clone_span(source)
    f=source[a:b]
    return (f.count(EXPECTED_NEW_GUARD)==1
            and f.count('is_mnt_ksu_unshared = true;')==1
            and f.count('bool is_mnt_ksu_unshared = false;')==1
            and len(OLD_GUARD.findall(f))==0)


def validate_source(source: Path) -> tuple[Path, bytes, str]:
    require(not source.is_symlink(), 'KERNEL_ROOT_SYMLINK')
    src = source.resolve(strict=True)
    mk = src / 'Makefile'
    target = src / TARGET
    for p in (mk, src / 'fs', target):
        require(not p.is_symlink(), 'SYMLINK_FORBIDDEN:'+str(p))
    require(mk.is_file() and target.is_file(), 'KERNEL_SOURCE_FILE_MISSING')
    text = mk.read_text(errors='replace')
    v = []
    for key in ('VERSION','PATCHLEVEL','SUBLEVEL'):
        m = re.findall(r'^\s*'+key+r'\s*=\s*(\d+)\s*$', text, flags=re.M)
        require(len(m)==1, 'KERNEL_VERSION_FIELD_MISSING_OR_MULTIPLE:'+key)
        v.append(m[0])
    require('.'.join(v) == KERNEL, 'KERNEL_NOT_5_4_274')
    blob = target.read_bytes()
    require(b'\x00' not in blob, 'SOURCE_CONTAINS_NUL')
    require(len(blob) < 4_000_000, 'SOURCE_TOO_LARGE')
    return target,blob,blob.decode('utf-8')


def analyze(src: Path, *, apply=False, expected_sha256='') -> dict:
    target, original, source = validate_source(src)
    state, candidate = plan_patch(source)
    before = sha256(original)
    after = sha256(candidate.encode('utf-8'))
    diff = ''.join(difflib.unified_diff(source.splitlines(True),candidate.splitlines(True),
                                       fromfile='a/'+TARGET,tofile='b/'+TARGET))
    report = {'schema': 1, 'kernel': KERNEL, 'scope': TARGET,
              'state': state, 'old_sha256': before, 'candidate_sha256': after,
              'changed': before != after, 'writes_to_brene': False,
              'bakasu_or_nomount_or_selinux_changed': False,
              'full_510_susfs_port_complete': False,
              'reference_jack_git_blob': REFERENCE_SHA,
              'reference_jack_commit': JACK_COMMIT,
              'device_tested': False, 'flash_approved': False,
              'source_updated': False, 'diff': diff}
    # Strictest rule: NEVER stage without a caller-supplied exact preimage pin.
    if apply:
        require(state == 'PATCH_CANDIDATE', 'NO_NEW_SOURCE_CHANGE_TO_APPLY')
        require(re.fullmatch(r'[0-9a-f]{64}', expected_sha256 or '') is not None,
                'EXACT_PREIMAGE_SHA256_REQUIRED')
        require(before == expected_sha256, 'PREIMAGE_HASH_MISMATCH')
        canonical = src.resolve(strict=True)
        require(src == canonical, 'ROOT_NOT_CANONICAL')
        require(canonical.name == 'kernel' and canonical.parent.name == 'source-work'
                and canonical.parent.parent.name == '5.4.274'
                and canonical.parent.parent.parent.name == 'builds',
                'DISPOSABLE_CI_BUILD_SOURCE_REQUIRED')
        require(target.read_bytes() == original, 'PREIMAGE_CHANGED_DURING_REVIEW')
        # Atomic same-directory write; mode preserved, no permission escalation.
        fd, name = tempfile.mkstemp(prefix='.veux-susfs54-', dir=target.parent)
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(candidate.encode('utf-8'))
                f.flush(); os.fsync(f.fileno())
            os.chmod(name, stat.S_IMODE(target.stat().st_mode))
            require(target.read_bytes()==original, 'SOURCE_CHANGED_DURING_STAGE')
            os.replace(name,target)
        finally:
            if os.path.exists(name): os.unlink(name)
        require(sha256(target.read_bytes())==after, 'STAGED_POSTIMAGE_DRIFT')
        report['source_updated'] = True
    return report


def main(argv=None) -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True)
    p.add_argument('--report',type=Path)
    p.add_argument('--diff',type=Path)
    p.add_argument('--apply-to-temporary-source',action='store_true')
    p.add_argument('--expected-preimage-sha256',default='')
    args=p.parse_args(argv)
    try:
        report=analyze(args.source,apply=args.apply_to_temporary_source,
                       expected_sha256=args.expected_preimage_sha256)
        exitcode=0
    except (Blocked, OSError, UnicodeError) as e:
        report={'schema':1,'state':'BLOCKED','reason':str(e),
                'source_updated':False,'device_tested':False,'flash_approved':False}
        exitcode=2
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps({k:v for k,v in report.items() if k!='diff'},indent=2,sort_keys=True)+'\n')
    if args.diff and report.get('diff'):
        args.diff.parent.mkdir(parents=True,exist_ok=True)
        args.diff.write_text(report['diff'])
    print(json.dumps({k:v for k,v in report.items() if k!='diff'},indent=2,sort_keys=True))
    return exitcode

if __name__=='__main__':
    sys.exit(main())
