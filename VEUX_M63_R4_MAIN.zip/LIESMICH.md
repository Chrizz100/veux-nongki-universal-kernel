# VEUX M63-R4 · UFS beim Kernelstart

Für das POCO X4 Pro 5G (veux), Xiaomi HyperOS OS1.0.12.0.TKCMIXM. Basis sind die geprüften M63-R2- und M63-R3-Pakete dieses Repositorys. Die Kerneländerungen liegen in drivers/scsi/ufs/ufshcd.c und kernel/sched/walt/walt.c. Der Kernel meldet 5.4.274-qgki-g82179e362f33.

Die Gerätekennung wird aus einer vollständigen, längengeprüften UFS-Gerätebeschreibung gelesen. Bei UFS 2.x erreicht ein Fehler beim erneuten Einschalten des Hosts für Gear 3 den Aufrufer. Die optionale Spannungsabsenkung setzt einen vorhandenen VCC-Regler voraus. Im signierten VEUX-Gerätebaum ist ein VCC-Regler eingetragen und limit-phy-submode steht auf 0. Diese beiden ergänzenden Korrekturen erklären dort keinen regulären Neustart.

Beim frühen CPU-Wechsel unterbindet WALT eine doppelte Verrechnung, solange die Ziel-CPU zur Verrechnungsgruppe der Quell-CPU gehört. Vor dem Start des Qualcomm-Frequenztreibers teilen sich die CPUs eine provisorische Gruppe. Die Frequenzmasken können zu diesem Zeitpunkt noch eine CPU pro Maske enthalten. Fünf Tests prüfen CPU-Beiträge, Summen und vorgemerkte Abzüge sowohl vor als auch nach dem Aufbau der 6+2-Topologie.

Der Workflow führt vor dem Kernelbau die bisherige Geräteerkennung und nach der Reparatur zwölf Deskriptortests sowie fünf Gear-3-Tests aus. Nach dem Bau vergleicht er das Boot-Image mit Xiaomis Format und die Imports von 37 originalen Vendor-Modulen. Das AnyKernel3-Paket wird auf zwei simulierten Stock-Slots durchgespielt. Der Kernel aus dem fertigen Image muss in einer ARM64-Maschine einen bekannten Sektor über ein virtuelles UFS-Laufwerk lesen. Der Android-init-Vergleich übernimmt die Startargumente aus Xiaomis signiertem Gerätebaum und die Speicherpfade aus der funktionierenden Sicherung. In der virtuellen Maschine endet dieser separate Test an den fehlenden Android-Partitionen.

Für GitHub gehört VEUX_M63_R4_MAIN.zip ins Hauptverzeichnis und VEUX_M63_R4_UFS_START_NOFLASH.yml nach .github/workflows/. Die bereits vorhandenen R2- und R3-Archive dienen als feste Eingaben. Über Actions lässt sich der Workflow manuell starten, sobald beide Dateien auf main stehen.

Gerätestatus: R2 und R3 gingen im Gerätetest in einen Bootloop. R4 hat bislang keinen bestätigten Start auf dem physischen POCO. Das Image und das zugehörige AnyKernel3-Paket tragen NOFLASH.
