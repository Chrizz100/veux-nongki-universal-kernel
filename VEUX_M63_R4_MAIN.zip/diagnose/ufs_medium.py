"""Read and verify a known sector over a virtual UFS host with the packaged kernel."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import zipfile

from fruehstart import MACHINE, digest, require, unpack_boot


def main(work, dest, stock_cpus):
    kit = Path(__file__).resolve().parent.parent
    qemu = 'qemu-system-aarch64'
    dest.mkdir(parents=True, exist_ok=True)
    kernel = work / 'out/arch/arm64/boot/Image'
    boot = work / 'pair/VEUX_M63-R4_boot_NOFLASH.img'
    require(kernel.read_bytes() == unpack_boot(boot), 'Packaged kernel identity')
    marker = b'VEUX_UFS_READ_OK\n'.ljust(512, b'\0')
    expected = hashlib.sha256(marker).hexdigest()
    name = 'Medium-VEUX-CPU' if stock_cpus else 'Medium'
    serial = dest / (name+'.log')
    version = subprocess.check_output([qemu, '--version'], text=True).splitlines()[0]
    with tempfile.TemporaryDirectory() as directory:
        temp = Path(directory)
        with zipfile.ZipFile(kit / 'ak3-tools.zip') as ak3:
            (temp / 'busybox').write_bytes(ak3.read('tools/busybox'))
        init = kit / 'diagnose/ufs-init.sh'
        dirs = ''.join(f'dir /{name} 0755 0 0\n' for name in ('bin','dev','sys','proc'))
        listing = temp / 'cpio.list'
        listing.write_text(dirs + 'nod /dev/console 0600 0 0 c 5 1\n' +
                           f'file /bin/busybox {temp}/busybox 0755 0 0\nfile /init {init} 0755 0 0\n')
        initrd = temp / 'initrd.cpio'
        with initrd.open('wb') as out:
            subprocess.run([work / 'out/usr/gen_init_cpio', listing], check=True, stdout=out)
        media = temp / 'disk.raw'
        with media.open('wb') as disk:
            disk.write(marker)
            disk.truncate(32 * 1024 * 1024)
        cpu = 'cortex-a76' if stock_cpus else 'cortex-a55'
        count = 8 if stock_cpus else 4
        qemu_base = [qemu, '-no-user-config', '-nodefaults', '-cpu', cpu, '-smp', str(count),
                     '-m', '1024M', '-accel', 'tcg', '-display', 'none', '-monitor', 'none', '-nic', 'none']
        extra = []
        if stock_cpus:
            from pstore_stock import signed_regions, device_tree, nodes
            from probe_epss import BASE, model_tree, registers, stock_domains
            domains = stock_domains(nodes(device_tree(signed_regions(temp))))
            dtb = model_tree(qemu_base, work/'out/scripts/dtc/dtc', temp, domains)
            bank = temp/'epss.bin'
            bank.write_bytes(registers(domains))
            extra = ['-dtb', dtb, '-device', f'loader,file={bank},addr={BASE:#x},force-raw=on']
        bootargs = 'console=ttyAMA0 earlycon=pl011,0x09000000 rdinit=/init kpti=off panic=-1'
        if stock_cpus:
            bootargs += ' mem=896M'
        with serial.open('wb') as out:
            command = qemu_base + ['-machine',MACHINE,'-kernel',kernel,'-initrd',initrd,'-append',bootargs,
                                   '-device','ufs,id=ufs0,serial=VEUXTEST',
                                   '-drive',f'if=none,format=raw,snapshot=on,file={media},id=disk',
                                   '-device','ufs-lu,bus=ufs0,lun=0,drive=disk','-serial','stdio','-no-reboot'] + extra
            proc = subprocess.Popen(command, stdout=out, stderr=subprocess.STDOUT)
            try:
                deadline = time.monotonic() + 90
                while time.monotonic() < deadline:
                    data = serial.read_bytes()
                    if b'Kernel panic - not syncing' in data or proc.poll() is not None:
                        raise RuntimeError('Virtual machine stopped before the UFS read completed')
                    if re.search(rb'(?m)^UFS_READ_COMPLETE\r?$', data):
                        break
                    time.sleep(0.15)
                else:
                    raise TimeoutError('Virtual UFS read timed out')
            finally:
                if proc.poll() is None:
                    proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
    log = serial.read_text(errors='replace')
    dev = re.search(r'^UFS_ID ([^\n]+)$', log, re.M)
    path = re.search(r'^UFS_PATH (/[^\n]+)$', log, re.M)
    require(dev and path and '/0000:00:' in path[1] and
            re.search(r'^UFS_SECTOR ' + expected + r'\s+/sector$', log, re.M) and
            'UFS_READ_COMPLETE' in log and 'Kernel panic' not in log, 'Virtual UFS sector verification')
    policies = dict(re.findall(r'^UFS_POLICY policy(\d+) ([0-9 ]+)$',log,re.M))
    if stock_cpus:
        require(policies == {'0':'0 1 2 3 4 5','6':'6 7'}, 'Combined EPSS and virtual UFS topology')
    report = dict(model=version, cpus=count, cpufreq_policies=policies, controller='PCI UFSHCI', storage=dev[1], sysfs_path=path[1],
                  kernel_sha256=digest(kernel.read_bytes()), boot_sha256=digest(boot.read_bytes()),
                  sector_bytes=512, sector_sha256=expected, serial_sha256=digest(serial.read_bytes()),
                  read_verified=True, physical_qualcomm_ufs_verified=False, device_pass=False, flash_allowed=False)
    (dest / (name+'.json')).write_text(json.dumps(report, indent=2)+'\n')
    print('PASS packaged kernel read one verified sector from its virtual UFS LUN')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('work',type=Path)
    parser.add_argument('dest',type=Path)
    parser.add_argument('--stock-cpus', action='store_true')
    args = parser.parse_args()
    main(args.work.resolve(), args.dest.resolve(), args.stock_cpus)
