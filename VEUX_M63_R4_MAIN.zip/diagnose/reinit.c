#include <errno.h>
#include <stdbool.h>
#include <stdio.h>

enum { UFSHCD_STATE_RESET, UFSHCD_STATE_OPERATIONAL, UFSHCD_STATE_ERROR };
struct ufs_hba {
	struct { int wspecversion; } dev_info;
	int limit_phy_submode, ufshcd_state;
	struct { int host_lock; } *host;
};
static int enable_status, enables;
#define ufshcd_vops_device_reset(h) ((void)(h))
#define ufshcd_hba_stop(h, mode) ((void)(h))
#define spin_lock_irqsave(lock, flags) ((flags) = 0)
#define spin_unlock_irqrestore(lock, flags) ((void)(flags))
static int ufshcd_hba_enable(struct ufs_hba *hba)
{
	(void)hba;
	enables++;
	return enable_status;
}
static int probe_transition(struct ufs_hba *hba)
{
	int ret = 0;
	bool reinit_needed = true;
	unsigned long flags;
reinit:
#include "transition.h"
out:
#include "finish.h"
	return ret;
}
static void run(const char *name, int version, int limited, int failure)
{
	struct ufs_hba h = { .dev_info.wspecversion = version,
		.limit_phy_submode = limited, .ufshcd_state = UFSHCD_STATE_RESET };
	enables = 0;
	enable_status = failure;
	int ret = probe_transition(&h);
	printf("%s:%d %d %d\n", name, ret, h.ufshcd_state, enables);
}
int main(void)
{
	run("ufs22_ok", 0x220, 1, 0);
	run("ufs22_timeout", 0x220, 1, -ETIMEDOUT);
	run("ufs22_io", 0x220, 1, -EIO);
	run("ufs30", 0x300, 1, -EIO);
	run("no_gear_change", 0x220, 0, -EIO);
	return 0;
}
