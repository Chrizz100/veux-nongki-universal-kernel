#!/bin/busybox sh
set -eu
box=/bin/busybox
$box mount -t proc proc /proc
$box mount -t sysfs sysfs /sys
# Bind QEMU's UFSHCI PCI function to the generic 5.4 driver.
for pci in /sys/bus/pci/devices/*; do
    case "$($box cat "$pci/class")" in 0x0109??) ;; *) continue ;; esac
    [ -L "$pci/driver" ] || echo "$($box cat "$pci/vendor") $($box cat "$pci/device")" > /sys/bus/pci/drivers/ufshcd/new_id
done
for block in $($box seq 1 15); do
    [ ! -f /sys/block/sda/dev ] || break
    $box sleep 1
done
IFS=: read -r major minor < /sys/block/sda/dev
[ -b /dev/sda ] || $box mknod /dev/sda b "$major" "$minor"
echo "UFS_PATH $($box readlink -f /sys/block/sda/device)"
echo "UFS_ID $($box cat /sys/block/sda/device/vendor) $($box cat /sys/block/sda/device/model)"
$box dd if=/dev/sda of=/sector bs=512 count=1
echo "UFS_SECTOR $($box sha256sum /sector)"
for policy in /sys/devices/system/cpu/cpufreq/policy*; do
    [ -r "$policy/related_cpus" ] || continue
    echo "UFS_POLICY ${policy##*/} $($box cat "$policy/related_cpus")"
done
echo UFS_READ_COMPLETE
exec $box sleep 3600
