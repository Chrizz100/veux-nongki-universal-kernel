// SPDX-License-Identifier: GPL-2.0-only
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#include <stdio.h>
#include <string.h>

typedef uint64_t u64;
typedef uint32_t u32;
#define NUM_TRACKED_WINDOWS 2
struct cpumask { unsigned bits; };
struct walt_sched_cluster { struct cpumask cpus; };
struct sub { u64 window_start, subs, new_subs; };
struct rq {
	struct {
		struct walt_sched_cluster *cluster;
		struct sub load_subs[NUM_TRACKED_WINDOWS];
		u64 window_start, prev_window_size;
		u64 curr_runnable_sum, prev_runnable_sum, nt_curr_runnable_sum, nt_prev_runnable_sum;
	} wrq;
};
struct task_struct {
	struct { u32 curr_window, prev_window, curr_window_cpu[8], prev_window_cpu[8]; } wts;
};

static struct rq queues[8];
static struct cpumask freq[8];
#define cpu_rq(i) (&queues[i])
#define cpu_cluster(i) (cpu_rq(i)->wrq.cluster)
#define cpumask_test_cpu(i, mask) (!!((mask)->bits & (1U << (i))))
#define cpumask_clear_cpu(i, mask) ((mask)->bits &= ~(1U << (i)))
#define same_freq_domain(src, dst) cpumask_test_cpu(dst, &freq[src])
#define for_each_cpu(i, mask) for ((i)=0; (i)<8; (i)++) if (cpumask_test_cpu(i, mask))
#define raw_spin_lock(lock) ((void)0)
#define raw_spin_unlock(lock) ((void)0)
#define printk_deferred(...) ((void)0)
#define walt_task_dump(p) ((void)0)
#define SCHED_BUG_ON(condition) assert(!(condition))
#include "migration.h"

static void run(const char *name, bool boot, int from, int to, bool young)
{
	struct walt_sched_cluster all = {{0xff}}, little = {{0x3f}}, big = {{0xc0}};
	struct task_struct p = {0};
	memset(queues, 0, sizeof(queues));
	for (int i=0; i<8; i++) {
		cpu_rq(i)->wrq.cluster = boot ? &all : i < 6 ? &little : &big;
		freq[i].bits = boot ? 1U << i : cpu_cluster(i)->cpus.bits;
		cpu_rq(i)->wrq.window_start = 200;
		cpu_rq(i)->wrq.prev_window_size = 100;
	}
	int peer = from < 6 ? 1 : 7;
	p.wts.curr_window_cpu[from]=9; p.wts.prev_window_cpu[from]=6;
	p.wts.curr_window_cpu[peer]=4; p.wts.prev_window_cpu[peer]=2;
	p.wts.curr_window=13; p.wts.prev_window=8;
	for (int i=0; i<8; i++) {
		cpu_rq(i)->wrq.curr_runnable_sum=p.wts.curr_window_cpu[i];
		cpu_rq(i)->wrq.prev_runnable_sum=p.wts.prev_window_cpu[i];
		cpu_rq(i)->wrq.nt_curr_runnable_sum=young ? p.wts.curr_window_cpu[i] : 0;
		cpu_rq(i)->wrq.nt_prev_runnable_sum=young ? p.wts.prev_window_cpu[i] : 0;
	}
	bool local = cpu_cluster(from) == cpu_cluster(to);
	inter_cluster_migration_fixup(&p,to,from,young);
	bool task_ok=true, queues_ok=true, debits_ok=true;
	for (int i=0; i<8; i++) {
		unsigned curr = i==from ? 9 : i==peer ? 4 : 0;
		unsigned prev = i==from ? 6 : i==peer ? 2 : 0;
		unsigned tc = local ? curr : i==to ? 13 : 0;
		unsigned tp = local ? prev : i==to ? 8 : 0;
		unsigned qc = local ? curr : i==to ? 13 : i==peer ? 4 : 0;
		unsigned qp = local ? prev : i==to ? 8 : i==peer ? 2 : 0;
		task_ok &= p.wts.curr_window_cpu[i]==tc && p.wts.prev_window_cpu[i]==tp;
		queues_ok &= cpu_rq(i)->wrq.curr_runnable_sum==qc && cpu_rq(i)->wrq.prev_runnable_sum==qp;
		queues_ok &= cpu_rq(i)->wrq.nt_curr_runnable_sum==(young?qc:0) && cpu_rq(i)->wrq.nt_prev_runnable_sum==(young?qp:0);
		unsigned current_debit=0, previous_debit=0, new_debit=0;
		for (int j=0; j<NUM_TRACKED_WINDOWS; j++) {
			struct sub *s=&cpu_rq(i)->wrq.load_subs[j];
			if (s->window_start==200) current_debit+=s->subs;
			if (s->window_start==100) previous_debit+=s->subs;
			new_debit+=s->new_subs;
		}
		debits_ok &= current_debit==(!local && i==peer ? 4U : 0U);
		debits_ok &= previous_debit==(!local && i==peer ? 2U : 0U);
		debits_ok &= new_debit==(!local && i==peer && young ? 6U : 0U);
	}
	printf("%s:%d %d %d\n",name,task_ok,queues_ok,debits_ok);
}
int main(void)
{
	run("bootstrap",true,2,3,false);
	run("bootstrap_new_task",true,2,3,true);
	run("same_policy",false,2,3,true);
	run("little_to_big",false,2,6,false);
	run("big_to_little",false,6,2,true);
	return 0;
}
