// SPDX-License-Identifier: GPL-2.0-only
/* The controller fixture only answers descriptor reads. */
#include <assert.h>
#include <endian.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "defs.h"

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
#define QUERY_OSF_SIZE 20
#define GENERAL_UPIU_REQUEST_SIZE 32
#define MASK_QUERY_DATA_SEG_LEN 0xffff
#define UPIU_QUERY_OPCODE_READ_DESC 1
#define SD_ASCII_STD true
#define GFP_KERNEL 0
#define likely(x) (x)
#define cpu_to_be16 htobe16
#define be16_to_cpu be16toh
#define be32_to_cpu be32toh
#define max_t(type, a, b) ((type)(a) > (type)(b) ? (type)(a) : (type)(b))
#define kmalloc(n, flags) malloc(n)
#define kfree free
#define dev_err(...) ((void)0)
#define dev_warn(...) ((void)0)
#define dev_dbg(...) ((void)0)

struct query_fields { u8 opcode, unused[5]; u16 length; u8 tail[12]; };
struct ufs_query_res { struct query_fields upiu_res; };
struct response { struct { u32 dword_0,dword_1,dword_2; } header; struct query_fields qr; u8 payload[255]; };
struct ufshcd_lrb { struct response *ucd_rsp_ptr; };
struct ufs_dev_info { u16 wmanufacturerid, wspecversion; u8 *model; };
struct ufs_hba {
    struct { int dev_desc,pwr_desc,interc_desc,conf_desc,unit_desc,geom_desc,hlth_desc; } desc_size;
    struct { struct { struct ufs_query_res response; struct { struct query_fields upiu_req; } request; u8 *descriptor; } query; } dev_cmd;
    struct ufs_dev_info dev_info;
};
#include "reply.h"

enum fixture { NORMAL, SHORT_HINT, FALLBACK, SHORT_FORM, LONGEST, IO_ERROR, WRONG_TYPE,
               TOO_SMALL, SHORT_DATA, TRUNCATED, ZERO_LENGTH, SEGMENT_SHORT };
static enum fixture scenario;
static int max_requested, header_reads, model_reads;

static int ufshcd_query_descriptor_retry(struct ufs_hba *hba, int op, enum desc_idn id,
                                         int index, int selector, u8 *out, int *len)
{
    struct response reply = {0};
    struct ufshcd_lrb lrb = { .ucd_rsp_ptr = &reply };
    int declared = 0x59, available, copied;
    assert(op == UPIU_QUERY_OPCODE_READ_DESC && index == 0 && selector == 0);
    if (id != QUERY_DESC_IDN_DEVICE) {
        assert(*len == QUERY_DESC_HDR_SIZE);
        out[0] = 0x40; out[1] = id; return 0;
    }
    if (scenario == IO_ERROR) return -EIO;
    if (scenario == FALLBACK) declared = 0x60;
    if (scenario == SHORT_FORM) declared = 0x40;
    if (scenario == LONGEST) declared = 255;
    if (scenario == TOO_SMALL) declared = 0x15;
    if (scenario == ZERO_LENGTH) declared = 0;
    available = declared;
    if (scenario == TRUNCATED || scenario == SEGMENT_SHORT) available = 0x20;
    if (scenario == SHORT_DATA) available = 1;
    if (*len == QUERY_DESC_HDR_SIZE) {
        header_reads++;
        if (scenario == FALLBACK) return -ETIMEDOUT;
        if (scenario == SHORT_HINT) declared = 0x40;
    }
    if (*len > max_requested) max_requested = *len;
    copied = available < *len ? available : *len;
    reply.payload[0] = declared;
    reply.payload[1] = scenario == WRONG_TYPE ? QUERY_DESC_IDN_UNIT : QUERY_DESC_IDN_DEVICE;
    reply.payload[DEVICE_DESC_PARAM_MANF_ID] = 0x01;
    reply.payload[DEVICE_DESC_PARAM_MANF_ID + 1] = 0xce;
    reply.payload[DEVICE_DESC_PARAM_SPEC_VER] = 0x02;
    reply.payload[DEVICE_DESC_PARAM_SPEC_VER + 1] = 0x20;
    reply.payload[DEVICE_DESC_PARAM_PRDCT_NAME] = 2;
    reply.qr.opcode = UPIU_QUERY_OPCODE_READ_DESC;
    reply.qr.length = htobe16(scenario == SEGMENT_SHORT && *len > 2 ? declared : copied);
    reply.header.dword_2 = htobe32(copied);
    hba->dev_cmd.query.descriptor = out;
    hba->dev_cmd.query.request.upiu_req.length = htobe16(*len);
    int ret = ufshcd_copy_query_response(hba, &lrb);
    hba->dev_cmd.query.descriptor = NULL;
    *len = be16toh(hba->dev_cmd.query.response.upiu_res.length);
    return ret;
}
static int ufshcd_read_string_desc(struct ufs_hba *hba, u8 index, u8 **model, bool ascii)
{
    model_reads++;
    if (index != 2 || !ascii) return -EINVAL;
    *model = (u8 *)"KM8F9001JM-B813"; return 16;
}
#define ufshcd_get_ref_clk_gating_wait(hba) ((void)0)
#define ufs_fixup_device_setup(hba) ((void)0)
#define ufshcd_wb_probe(hba, buf) ((void)0)
#include "methods.h"

int main(void)
{
    static const char *const names[] = {"normal","short_hint","fallback","short_form","longest","io_error",
        "wrong_type","too_small","short_data","truncated","zero_length","segment_short"};
    #ifdef REFERENCE
    const enum fixture last = LONGEST;
#else
    const enum fixture last = SEGMENT_SHORT;
#endif
    for (scenario=NORMAL; scenario<=last; scenario++) {
        struct ufs_hba hba = {0};
        max_requested = model_reads = header_reads = 0;
        ufshcd_init_desc_sizes(&hba);
        int rc = ufs_get_device_desc(&hba);
        printf("%s:%d %u %d %u %u %d %d\n",names[scenario],rc,hba.desc_size.dev_desc,
               max_requested,hba.dev_info.wmanufacturerid,hba.dev_info.wspecversion,model_reads,header_reads);
    }
    return 0;
}
