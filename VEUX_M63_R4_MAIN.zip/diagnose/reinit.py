"""Check the Qualcomm UFS2/Gear3 transition and host state using the kernel branch."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import tempfile

from test_ufs_start import definition


def test(source):
    probe = definition(source.read_text(), 'ufshcd_probe_hba')
    branch = re.search(r'\tif \(hba->dev_info.wspecversion < 0x300 &&.*?^\t\}', probe, re.M | re.S)
    tail = re.search(r'^out:\s*(spin_lock_irqsave.*?spin_unlock_irqrestore\([^;]+;)', probe, re.M | re.S)
    if not (branch and tail and re.search(r'return ret;\s*\}$', probe)):
        raise ValueError('Qualcomm Gear3 probe/state signature')
    with tempfile.TemporaryDirectory() as directory:
        temp = Path(directory)
        (temp / 'transition.h').write_text(branch.group())
        (temp / 'finish.h').write_text(tail[1])
        exe = temp / 'gear3'
        subprocess.run(['cc','-std=c11','-Wall','-Werror','-I',temp,
                        Path(__file__).with_name('reinit.c'),'-o',exe],check=True)
        lines = subprocess.check_output([exe],text=True).splitlines()
    return {name:dict(zip(('status','state','enables'), map(int, fields.split()), strict=True))
            for name,fields in (s.split(':',1) for s in lines)}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('report', type=Path)
    parser.add_argument('--verify-repair',action='store_true')
    args = parser.parse_args()
    rows = test(args.source)
    expected = {'ufs22_ok':(0,1,1),'ufs22_timeout':(-110,2,1),'ufs22_io':(-5,2,1),
                'ufs30':(0,1,0),'no_gear_change':(0,1,0)}
    if args.verify_repair and any(tuple(rows[k].values())!=v for k,v in expected.items()):
        raise SystemExit(str(rows))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(rows, indent=2)+'\n')
    print(args.report, len(rows), 'Gear3 transition cases')
