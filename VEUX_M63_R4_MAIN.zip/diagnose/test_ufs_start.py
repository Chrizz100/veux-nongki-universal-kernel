"""Exercise the kernel's actual UFS discovery functions with bounded, read-only replies."""
import argparse
import json
from pathlib import Path
import re
import subprocess
import tempfile


def definition(text, name, *, optional=False):
    pattern = r'^(?:static\s+)?(?:inline\s+)?(?:int|void|bool)\s+' + name + r'\s*\([^;{}]*\)\s*\{.*?^\}'
    match = re.search(pattern, text, re.M | re.S)
    if not match and not optional:
        raise ValueError('Missing definition ' + name)
    return match.group(0) if match else ''


def exercise(source, header, repaired):
    funcs = ['ufshcd_read_desc_length', 'ufshcd_map_desc_id_to_length', 'ufshcd_read_desc_param',
             'ufshcd_read_desc', 'ufshcd_read_device_desc', 'ufshcd_init_desc_sizes', 'ufs_get_device_desc']
    text = source.read_text()
    h = header.read_text()
    enums = ['desc_idn','desc_header_offset','ufs_desc_def_size','device_desc_param']
    definitions = [re.search(r'enum ' + e + r'\s*\{.*?^\};', h, re.M | re.S).group() for e in enums]
    constants = ['QUERY_DESC_MAX_SIZE','QUERY_DESC_HDR_SIZE']
    definitions.extend(re.search(r'^#define\s+' + n + r'\s+\d+', h, re.M).group() for n in constants)
    with tempfile.TemporaryDirectory() as dirname:
        temp = Path(dirname)
        (temp/'defs.h').write_text('\n'.join(definitions))
        (temp/'methods.h').write_text('\n'.join(definition(text, f, optional=f=='ufshcd_read_device_desc') for f in funcs))
        (temp/'reply.h').write_text(definition(text,'ufshcd_copy_query_response'))
        exe = temp/'probe'
        subprocess.run(['cc','-std=gnu11','-Wall','-Werror','-Wno-unused-function','-Wno-unused-variable','-O2',
                        *(() if repaired else ('-DREFERENCE',)), '-fsanitize=undefined','-fno-sanitize-recover=all','-I',str(temp),
                        str(Path(__file__).with_name('test_ufs_start.c')),'-o',str(exe)],check=True)
        rows = subprocess.check_output([exe],text=True).splitlines()
    keys = ('code','stored_length','max_requested','manufacturer','spec','model_reads','header_reads')
    return {name:dict(zip(keys,map(int,values.split()),strict=True)) for name,values in (line.split(':',1) for line in rows)}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('header',type=Path)
    parser.add_argument('json',type=Path)
    parser.add_argument('--verify-repair',action='store_true')
    args=parser.parse_args()
    rows=exercise(args.source,args.header,args.verify_repair)
    if args.verify_repair:
        for name,length in (('normal',0x59),('short_hint',0x59),('fallback',0x60),('short_form',0x40),('longest',255)):
            r=rows[name]
            if (r['code'],r['stored_length'],r['manufacturer'],r['spec'],r['model_reads'],r['header_reads']) != (0,length,0x01ce,0x220,1,0):
                raise SystemExit(f'{name}: {r}')
        for name in ('io_error','wrong_type','too_small','short_data','truncated','zero_length','segment_short'):
            if rows[name]['code'] >= 0 or rows[name]['model_reads']:
                raise SystemExit(f'{name}: {rows[name]}')
    args.json.parent.mkdir(parents=True,exist_ok=True)
    args.json.write_text(json.dumps(rows,indent=2)+'\n')
    print(args.json, len(rows),'UFS device identifications')
