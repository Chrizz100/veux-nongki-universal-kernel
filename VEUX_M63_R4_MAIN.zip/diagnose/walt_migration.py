"""Exercise real WALT migration accounting with the startup and final VEUX topology."""
import argparse
import json
from pathlib import Path
import subprocess
import tempfile

from test_ufs_start import definition


def exercise(source):
    text = source.read_text()
    names = ('create_subtraction_entry','get_subtraction_index','update_rq_load_subtractions',
             'update_cluster_load_subtractions','inter_cluster_migration_fixup')
    with tempfile.TemporaryDirectory() as directory:
        tmp = Path(directory)
        (tmp/'migration.h').write_text('\n'.join(definition(text, name) for name in names))
        exe = tmp/'walt-migration'
        subprocess.run(['cc','-std=c11','-Wall','-Werror','-O2','-I',tmp,
                        Path(__file__).with_suffix('.c'),'-o',exe],check=True)
        rows = subprocess.check_output([exe],text=True).splitlines()
    return {name:dict(zip(('contributions_correct','runqueue_sums_correct','deferred_debits_correct'),
                          (v=='1' for v in fields.split()),strict=True))
            for name,fields in (row.split(':',1) for row in rows)}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source',type=Path)
    parser.add_argument('report',type=Path)
    parser.add_argument('--verify-repair',action='store_true')
    args=parser.parse_args()
    rows=exercise(args.source)
    if args.verify_repair and not all(all(checks.values()) for checks in rows.values()):
        raise SystemExit(str(rows))
    args.report.parent.mkdir(parents=True,exist_ok=True)
    args.report.write_text(json.dumps(rows,indent=2)+'\n')
    print(args.report,len(rows),'migration accounting cases')
