#!/usr/bin/env python3
"""VEUX stock QGKI evidence importer. Read-only, source-only, NEVER flashes.

This importer expands *verified extracted headers*, not Android kernel sources.
It refuses unexpected TAR members, symlink escape, missing hashes, and drift.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import lzma
import os
import posixpath
import re
import shutil
import sys
import tarfile
from pathlib import Path, PurePosixPath

VERSION = '5.4.274-qgki-g82179e362f33'
IMAGE_SHA256 = '6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b'
BASE_PREFIX = 'stock-qgki/5.4.274-qgki-g82179e362f33'
REQUIRED_CONFIG = {
    'CONFIG_SCHED_WALT':'y',
    'CONFIG_ARCH_HOLI':'y',
    'CONFIG_QGKI':'y',
    'CONFIG_MODULES':'y',
    'CONFIG_MODVERSIONS':'y',
    'CONFIG_LTO_CLANG':'y',
    'CONFIG_CFI_CLANG':'y',
    'CONFIG_IKHEADERS':'y',
}

class EvidenceError(RuntimeError):
    pass


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_path(name: str) -> str:
    if '\\' in name or '\x00' in name or name.startswith('/'):
        raise EvidenceError('UNSAFE_PATH ' + repr(name))
    if name in ('.', './'):
        return ''
    while name.startswith('./'):
        name = name[2:]
    if name.startswith('/') or not name or any(p in ('', '.', '..') for p in name.split('/')):
        raise EvidenceError('UNSAFE_PATH ' + repr(name))
    return name


def inspect_header_tar(raw: bytes, *, expected_listing: list[str] | None = None):
    members = []
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as tf:
        members = tf.getmembers()
        if len(members) != 9405:
            raise EvidenceError(f'KHEADER_MEMBER_COUNT {len(members)} != 9405')
        seen = set()
        names = []
        links = []
        files = 0
        dirs = 0
        for member in members:
            raw_name = member.name
            norm = safe_path(raw_name)
            if norm in seen:
                raise EvidenceError('DUPLICATE_TAR_MEMBER ' + norm)
            seen.add(norm)
            names.append(norm)
            if member.isfile():
                files += 1
                if member.size > 6_000_000:
                    raise EvidenceError('OVERSIZED_MEMBER ' + norm)
            elif member.isdir():
                dirs += 1
            elif member.issym():
                link = member.linkname
                if not link or link.startswith('/') or '\\' in link or '\x00' in link:
                    raise EvidenceError('UNSAFE_SYMLINK ' + norm)
                target = posixpath.normpath(posixpath.join(posixpath.dirname(norm), link))
                if target in ('..', '.') or target.startswith('../') or target.startswith('/'):
                    raise EvidenceError('SYMLINK_ESCAPE ' + norm)
                links.append((norm, link, target))
            else:
                raise EvidenceError('UNSAFE_TAR_TYPE ' + norm)
        if files != 7717 or dirs != 1686 or len(links) != 2:
            raise EvidenceError(f'HEADER_MEMBER_TYPES files={files} dirs={dirs} symlinks={len(links)}')
        # Known, fully qualified original links; refuse changes to the reference evidence.
        expected_links = {
            ('include/dt-bindings/arm/msm/msm_ion_ids.h', '../../../uapi/linux/msm_ion_ids.h', 'include/uapi/linux/msm_ion_ids.h'),
            ('include/dt-bindings/input/linux-event-codes.h', '../../uapi/linux/input-event-codes.h', 'include/uapi/linux/input-event-codes.h'),
        }
        if set(links) != expected_links:
            raise EvidenceError('UNEXPECTED_HEADER_SYMLINKS')
        if expected_listing is not None:
            # Original manifest enumerates paths exactly as contained (leading './' kept).
            original_names = [m.name for m in members]
            if original_names != expected_listing:
                raise EvidenceError('HEADER_MEMBER_LIST_MISMATCH')
        try:
            release = tf.extractfile('./include/generated/utsrelease.h').read()
            autoconf = tf.extractfile('./include/generated/autoconf.h').read()
            rcu = tf.extractfile('./include/linux/rcupdate.h').read()
        except (AttributeError, KeyError, OSError) as e:
            raise EvidenceError('MISSING_GENERATED_HEADER') from e
        if VERSION.encode() not in release:
            raise EvidenceError('KERNEL_RELEASE_MISMATCH')
        if b'CONFIG_SCHED_WALT 1' not in autoconf or b'CONFIG_ARCH_HOLI 1' not in autoconf:
            raise EvidenceError('GENERATED_CONFIG_MISMATCH')
        if b'rcu_guard(' in rcu:
            raise EvidenceError('RCU_GUARD_EXPECTATION_CHANGED')
        if 'Module.symvers' in seen:
            raise EvidenceError('UNEXPECTED_MODULE_SYMVERS')
        return {'member_count':len(members),'regular_files':files,'directories':dirs,
                'internal_symlinks':len(links),'kernel_release':VERSION,
                'source_code_complete':False,'module_symvers_present':False,
                'nomount_rcu_guard_available':False}


def inspect_evidence(root: Path):
    evidence = root / 'evidence'
    mf = json.loads((evidence / 'STOCK_EXTRACTION_MANIFEST.json').read_text(encoding='utf-8'))
    if mf.get('image_sha256') != IMAGE_SHA256 or mf.get('stock_release_from_generated_utsrelease') != VERSION:
        raise EvidenceError('SOURCE_IMAGE_IDENTITY_DRIFT')
    if mf.get('image_unchanged') is not True or mf.get('flashable') is not False:
        raise EvidenceError('UNEXPECTED_FLASH_STATE')
    config = (evidence / 'stock_kernel.config').read_bytes()
    if sha(config) != mf['config_sha256'] or len(config) != mf['config_bytes']:
        raise EvidenceError('CONFIG_SHA_OR_LENGTH_MISMATCH')
    lines = config.decode('utf-8',errors='strict').splitlines()
    d={}
    for line in lines:
        if line.startswith('CONFIG_') and '=' in line:
            key,val=line.split('=',1)
            if key in d:raise EvidenceError('DUPLICATE_CONFIG '+key)
            d[key]=val
    for key,value in REQUIRED_CONFIG.items():
        if d.get(key)!=value:raise EvidenceError(f'CONFIG_MISMATCH {key}')
    if d.get('CONFIG_LOCALVERSION')!='"-qgki"':raise EvidenceError('LOCALVERSION_MISMATCH')
    if d.get('CONFIG_KSU')=='y' or d.get('CONFIG_NOMOUNT')=='y':
        raise EvidenceError('SOURCE_CONFIG_UNEXPECTED_ROOT')
    compressed = (evidence / 'stock_embedded_kheaders.tar.xz').read_bytes()
    if not compressed.startswith(b'\xfd7zXZ\x00') or sha(compressed)!=mf['kheaders_compressed_sha256'] or len(compressed)!=mf['kheaders_compressed_bytes']:
        raise EvidenceError('COMPRESSED_HEADERS_HASH_DRIFT')
    extracted = lzma.decompress(compressed)
    if sha(extracted)!=mf['kheaders_tar_sha256'] or len(extracted)!=mf['kheaders_tar_bytes']:
        raise EvidenceError('DECOMPRESSED_HEADERS_HASH_DRIFT')
    listing=(evidence/'KHEADERS_MEMBER_LIST.txt').read_text(encoding='utf-8').splitlines()
    if len(listing)!=9405:raise EvidenceError('EXPECTED_HEADER_LIST_WRONG_SIZE')
    tar_info=inspect_header_tar(extracted,expected_listing=listing)
    vdso=(evidence/'stock_embedded_vdso_elf.elf').read_bytes()
    if sha(vdso)!=mf['vdso_elf_sha256'] or len(vdso)!=mf['vdso_elf_bytes'] or not vdso.startswith(b'\x7fELF'):
        raise EvidenceError('VDSO_HASH_DRIFT')
    locks=json.loads((root/'upstream'/'UPSTREAM_LOCKS_2026-10-15.json').read_text(encoding='utf-8'))
    if locks.get('target_stock_kernel_release')!=VERSION or locks.get('do_not_use_prior_p11_p12_source_as_stock') is not True:
        raise EvidenceError('STOCK_ONLY_UPSTREAM_LOCK_DRIFT')
    required={'BaKaSU','SUSFS','NoMount'}
    if {c['component'] for c in locks['components']}!=required:
        raise EvidenceError('UPSTREAM_COMPONENT_SET_MISMATCH')
    return {'evidence_ok':True,'target_release':VERSION,'image_sha256':IMAGE_SHA256,
            'image_bytes_present':False,'image_hash_is_reference_only':True,
            'config_sha256':sha(config),'header_compressed_sha256':sha(compressed),
            'header_tar_sha256':sha(extracted),'vdso_sha256':sha(vdso),
            'kernel_config':{k:d[k] for k in REQUIRED_CONFIG},
            'tar':tar_info,'all_three_integrations_complete':False},extracted


def extract_tar_verified(tar_bytes: bytes, target: Path):
    if target.exists():raise EvidenceError('REFUSE_OVERWRITE_EXISTING_HEADERS '+str(target))
    target.mkdir(parents=True)
    with tarfile.open(fileobj=io.BytesIO(tar_bytes),mode='r:') as tf:
        members=tf.getmembers()
        # Verified beforehand, but check path safety again and never tarfile.extractall.
        for m in members:
            rel=safe_path(m.name)
            if not rel:continue
            dest=target / rel
            if m.isdir():
                dest.mkdir(parents=True,exist_ok=True)
            elif m.isfile():
                dest.parent.mkdir(parents=True,exist_ok=True)
                if dest.exists() or dest.is_symlink():raise EvidenceError('DUPLICATE_EXTRACTION '+rel)
                stream=tf.extractfile(m)
                if stream is None:raise EvidenceError('MISSING_MEMBER_BODY '+rel)
                with stream, dest.open('xb') as handle:
                    shutil.copyfileobj(stream,handle)
            elif m.issym():
                dest.parent.mkdir(parents=True,exist_ok=True)
                if dest.exists() or dest.is_symlink():raise EvidenceError('DUPLICATE_SYMLINK '+rel)
                target_rel=posixpath.normpath(posixpath.join(posixpath.dirname(rel),m.linkname))
                if target_rel.startswith('../') or target_rel == '..' or target_rel.startswith('/'):
                    raise EvidenceError('SYMLINK_ESCAPE_ON_EXTRACT')
                dest.symlink_to(m.linkname)
            else:raise EvidenceError('UNEXPECTED_MEMBER_TYPE '+rel)
    if not (target/'include/generated/utsrelease.h').is_file():
        raise EvidenceError('EXTRACTION_MISSING_RELEASE')


def stage(root: Path, out: Path, *, expand_headers=True):
    if out.exists() and any(out.iterdir()):raise EvidenceError('REFUSE_NONEMPTY_OUTPUT')
    report,tar_bytes=inspect_evidence(root)
    target=out/'stock-qgki'/VERSION
    for folder in ('reference/config','reference/archives','reference/vdso','reference/manifests','upstream','integration','audit','kheaders'):
        (target/folder).mkdir(parents=True,exist_ok=True)
    evidence=root/'evidence'
    source_files=[
        (evidence/'stock_kernel.config',target/'reference/config/stock_kernel.config'),
        (evidence/'stock_embedded_kheaders.tar.xz',target/'reference/archives/stock_embedded_kheaders.tar.xz'),
        (evidence/'stock_embedded_vdso_elf.elf',target/'reference/vdso/stock_embedded_vdso_elf.elf'),
        (evidence/'STOCK_EXTRACTION_MANIFEST.json',target/'reference/manifests/STOCK_EXTRACTION_MANIFEST.json'),
        (evidence/'KHEADERS_MEMBER_LIST.txt',target/'reference/manifests/KHEADERS_MEMBER_LIST.txt'),
        (root/'upstream/UPSTREAM_LOCKS_2026-10-15.json',target/'upstream/UPSTREAM_LOCKS_2026-10-15.json'),
    ]
    for p in (root/'audit').iterdir():
        if p.is_file():source_files.append((p,target/'audit'/p.name))
    for src,dst in source_files:
        shutil.copyfile(src,dst)
    if expand_headers:
        (target/'kheaders').rmdir()
        extract_tar_verified(tar_bytes,target/'kheaders')
    (target/'integration/README.txt').write_text('''VEUX STOCK QGKI 5.4.274 – SOURCE INTEGRATION NOT YET PERFORMED\n\nOnly Stock Image-extracted CONFIG/HEADERS/vDSO were imported.\nThe original 45,480,448 byte ARM64 Image is not included in this public GitHub ZIP.\nIts expected SHA256 is recorded in STOCK_EXTRACTION_MANIFEST.json and must\nbe compared against the original offline Image before any boot packaging.\n\nFull kernel source matching 5.4.274-qgki-g82179e362f33 is MISSING.\nModule.symvers, exact DTB/DTBO and boot-image wrapper are MISSING.\nBaKaSU, SUSFS 2.3.0 and NoMount are NOT integrated.\nNo P11/P12 rebuild or stock-near substitutes are used.\nNO BOOT.IMG / NO AK3 / NO FLASH.\n''',encoding='utf-8')
    status={
      'run_intent':'STOCK_QGKI_IMPORT_ONLY', 'target':VERSION,
      'evidence_validation':'PASS', 'directory_preparation':'PASS',
      'input_original_image_in_zip':False,'input_image_sha256':IMAGE_SHA256,
      'matching_full_kernel_sources':'NOT_PROVIDED',
      'module_symvers':'NOT_PROVIDED','stock_vendor_abi':'NOT_PROVEN',
      'bakasu':'NOT_INTEGRATED','susfs_2_3_0':'NOT_INTEGRATED','nomount':'NOT_INTEGRATED',
      'full_kernel_build':'NOT_RUN','device_test':'NOT_RUN','flash_permission':False,
      'prerequisites':['exact_full_stock_qgki_source','matching_vendor_module_abi','compatible_build_toolchain','SUSFS_2.3.0_5.4_backport'],
    }
    (target/'integration/INTEGRATION_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report['target_folder']=str(Path('stock-qgki')/VERSION)
    report['expanded_headers']=bool(expand_headers)
    report['integration_status']='BLOCKED_MISSING_FULL_STOCK_SOURCE'
    out.mkdir(parents=True,exist_ok=True)
    (out/'VEUX_STOCK_IMPORT_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'VEUX_STOCK_INTEGRATION_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (out/'README_IMPORT.txt').write_text('''STOCK QGKI IMPORT PASS / SOURCE INTEGRATION NOT STARTED\n\nThe verified stock CONFIG, embedded Linux headers and vDSO were staged.\nThe source kernel cannot be reconstructed from the ARM64 binary.\nThere is NO BakaSU, SUSFS 2.3.0 or NoMount patch/compilation/flash here.\nThis GitHub Actions runner workspace is TEMPORARY. Download the artifact\nif you need to keep the prepared folders; repo writes are disabled.\n''',encoding='utf-8')
    return report


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--source-root',required=True)
    ap.add_argument('--output-dir',required=True)
    ap.add_argument('--no-expand-headers',action='store_true')
    args=ap.parse_args()
    root=Path(args.source_root).resolve()
    if root.name!=VERSION or root.parent.name!='stock-qgki':
        raise EvidenceError('PACKAGE_LAYOUT_INCORRECT')
    report=stage(root,Path(args.output_dir).resolve(),expand_headers=not args.no_expand_headers)
    print(json.dumps(report,sort_keys=True))
    print('VEUX_STOCK_IMPORT=PASS; STOCK_WALT=Y; ROOT_INTEGRATION=NOT_STARTED; FLASH=NO')

if __name__=='__main__':
    try:main()
    except (EvidenceError,FileNotFoundError,OSError,ValueError,tarfile.TarError,lzma.LZMAError) as exc:
        print('VEUX_STOCK_IMPORT_FAIL_CLOSED: '+str(exc),file=sys.stderr)
        sys.exit(2)
