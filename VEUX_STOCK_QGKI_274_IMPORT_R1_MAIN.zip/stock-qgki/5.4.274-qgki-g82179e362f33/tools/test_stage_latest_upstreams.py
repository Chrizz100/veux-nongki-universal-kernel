import importlib.util
import pathlib
import unittest
from unittest.mock import patch

THIS=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stage_latest_upstreams',THIS/'stage_latest_upstreams.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

class UpstreamStageTests(unittest.TestCase):
    def test_01_valid_sources(self):self.assertTrue(mod.verify_sources(mod.SOURCES))
    def test_02_exact_sources_only(self):
        with self.assertRaises(mod.StageError):mod.verify_sources(mod.SOURCES[:2])
    def test_03_full_commit_hashes(self):
        for src in mod.SOURCES:
            if src['pin']:self.assertRegex(src['pin'],r'^[a-f0-9]{40}$')
    def test_04_parse_head(self):
        s='a'*40+'\trefs/heads/main\n';self.assertEqual(mod.parse_ls_remote(s,'main'),'a'*40)
    def test_05_reject_wrong_branch(self):
        with self.assertRaises(mod.StageError):mod.parse_ls_remote('a'*40+'\trefs/heads/dev','main')
    def test_06_reject_bad_oid(self):
        with self.assertRaises(mod.StageError):mod.parse_ls_remote('abc\trefs/heads/main','main')
    def test_07_reject_multiple_oids(self):
        with self.assertRaises(mod.StageError):mod.parse_ls_remote('a'*40+'\trefs/heads/main\n'+'b'*40+'\trefs/heads/main','main')
    def test_08_never_includes_nonofficial_domain(self):
        self.assertTrue(all(src['url'].startswith(('https://github.com/','https://gitlab.com/')) for src in mod.SOURCES))
    def test_09_reject_nonofficial_source(self):
        src=[dict(x) for x in mod.SOURCES];src[0]['url']='https://malicious.example/repo.git'
        with self.assertRaises(mod.StageError):mod.verify_sources(src)
    def test_10_reject_bad_branch(self):
        src=[dict(x) for x in mod.SOURCES];src[0]['branch']='main; rm -rf /'
        with self.assertRaises(mod.StageError):mod.verify_sources(src)
    def test_11_reject_bad_archive_path(self):
        src=[dict(x) for x in mod.SOURCES];src[0]['subtrees']=['../.ssh']
        with self.assertRaises(mod.StageError):mod.verify_sources(src)
    def test_12_only_requested_susfs_version(self):
        self.assertEqual(mod.SOURCES[1]['name'],'SUSFS-2.3-reference')
    def test_13_git_execution_no_shell(self):
        txt=(THIS/'stage_latest_upstreams.py').read_text()
        self.assertIn('subprocess.run([\'git\',*args]',txt)
        self.assertNotIn('shell=True',txt)
    def test_14_no_kernel_write(self):
        txt=(THIS/'stage_latest_upstreams.py').read_text()
        self.assertNotIn('git push',txt)
        self.assertNotIn('boot.img',txt.split('def run_git')[1].split('def parse_ls_remote')[0])

if __name__=='__main__':unittest.main(verbosity=2)
