import importlib.util
import json
import pathlib
import shutil
import tempfile
import unittest
from unittest.mock import patch

THIS=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('stock_import',THIS/'stock_import.py')
api=importlib.util.module_from_spec(spec)
spec.loader.exec_module(api)
ROOT=THIS.parent

class StockImportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report, cls.tarbytes=api.inspect_evidence(ROOT)

    def test_01_reference_version(self):self.assertEqual(self.report['target_release'],'5.4.274-qgki-g82179e362f33')
    def test_02_exact_image_hash_reference(self):self.assertEqual(self.report['image_sha256'],'6e513b3652aa1de599c26b6aaeefef12dac569daf8648bbb67de99932782c50b')
    def test_03_image_not_claimed_uploaded(self):self.assertIs(self.report['image_bytes_present'],False)
    def test_04_header_tar_sha(self):self.assertEqual(api.sha(self.tarbytes),'7755134abdfcd0aa0926acc7a06838256cc9da74cfbcbc12f03965461d50f262')
    def test_05_header_count(self):self.assertEqual(self.report['tar']['member_count'],9405)
    def test_06_header_types(self):self.assertEqual((self.report['tar']['regular_files'],self.report['tar']['directories'],self.report['tar']['internal_symlinks']),(7717,1686,2))
    def test_07_no_module_symvers(self):self.assertIs(self.report['tar']['module_symvers_present'],False)
    def test_08_no_complete_sources(self):self.assertIs(self.report['tar']['source_code_complete'],False)
    def test_09_nomount_rcu_port_gap(self):self.assertIs(self.report['tar']['nomount_rcu_guard_available'],False)
    def test_10_walt_y(self):self.assertEqual(self.report['kernel_config']['CONFIG_SCHED_WALT'],'y')
    def test_11_qgki_y(self):self.assertEqual(self.report['kernel_config']['CONFIG_QGKI'],'y')
    def test_12_cfi_lto_modules(self):self.assertTrue(all(self.report['kernel_config'][k]=='y' for k in ('CONFIG_LTO_CLANG','CONFIG_CFI_CLANG','CONFIG_MODULES','CONFIG_MODVERSIONS')))
    def test_13_source_image_not_patched(self):self.assertIs(self.report['all_three_integrations_complete'],False)
    def test_14_relative_archive_file_allowed(self):self.assertEqual(api.safe_path('./include/linux/fs.h'),'include/linux/fs.h')
    def test_15_archive_root_directory_allowed(self):self.assertEqual(api.safe_path('./'),'')
    def test_16_absolute_member_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('/etc/passwd')
    def test_17_dotdot_member_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('include/../../etc/shadow')
    def test_18_windows_separator_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('include\\temp')
    def test_19_double_separator_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('include//fs.h')
    def test_20_nul_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('a\x00b')
    def test_21_empty_member_rejected(self):
        with self.assertRaises(api.EvidenceError):api.safe_path('')
    def test_22_tar_list_drift_rejected(self):
        listing=(ROOT/'evidence/KHEADERS_MEMBER_LIST.txt').read_text().splitlines()
        listing[-1]='./TAMPERED'
        with self.assertRaisesRegex(api.EvidenceError,'LIST_MISMATCH'):
            api.inspect_header_tar(self.tarbytes,expected_listing=listing)
    def test_23_refuse_output_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            dst=pathlib.Path(tmp)/'out';dst.mkdir();(dst/'old').write_text('untouched')
            with self.assertRaisesRegex(api.EvidenceError,'REFUSE_NONEMPTY_OUTPUT'):
                api.stage(ROOT,dst,expand_headers=False)
            self.assertEqual((dst/'old').read_text(),'untouched')
    def test_24_reference_stage_without_expanded_headers(self):
        with tempfile.TemporaryDirectory() as tmp:
            dst=pathlib.Path(tmp)/'out'
            report=api.stage(ROOT,dst,expand_headers=False)
            base=dst/'stock-qgki'/api.VERSION
            self.assertTrue((base/'reference/config/stock_kernel.config').is_file())
            self.assertFalse((base/'kheaders/include/linux/fs.h').exists())
            status=json.loads((base/'integration/INTEGRATION_STATUS.json').read_text())
            self.assertIs(status['flash_permission'],False)
            self.assertEqual(status['susfs_2_3_0'],'NOT_INTEGRATED')
            self.assertEqual(report['integration_status'],'BLOCKED_MISSING_FULL_STOCK_SOURCE')
    def test_25_mismatched_manifest_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=pathlib.Path(tmp)/api.VERSION
            shutil.copytree(ROOT,dest)
            mf=dest/'evidence/STOCK_EXTRACTION_MANIFEST.json'
            data=json.loads(mf.read_text());data['image_sha256']='f'*64;mf.write_text(json.dumps(data))
            with self.assertRaisesRegex(api.EvidenceError,'SOURCE_IMAGE_IDENTITY_DRIFT'):
                api.inspect_evidence(dest)
    def test_26_corrupt_config_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=pathlib.Path(tmp)/api.VERSION
            shutil.copytree(ROOT,dest)
            p=dest/'evidence/stock_kernel.config'
            p.write_bytes(p.read_bytes()+b'# changed\n')
            with self.assertRaisesRegex(api.EvidenceError,'CONFIG_SHA_OR_LENGTH_MISMATCH'):
                api.inspect_evidence(dest)
    def test_27_corrupt_headers_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=pathlib.Path(tmp)/api.VERSION
            shutil.copytree(ROOT,dest)
            p=dest/'evidence/stock_embedded_kheaders.tar.xz';p.write_bytes(p.read_bytes()+b'X')
            with self.assertRaisesRegex(api.EvidenceError,'COMPRESSED_HEADERS_HASH_DRIFT'):
                api.inspect_evidence(dest)
    def test_28_corrupt_vdso_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=pathlib.Path(tmp)/api.VERSION
            shutil.copytree(ROOT,dest)
            p=dest/'evidence/stock_embedded_vdso_elf.elf';p.write_bytes(p.read_bytes()[:-1])
            with self.assertRaisesRegex(api.EvidenceError,'VDSO_HASH_DRIFT'):
                api.inspect_evidence(dest)
    def test_29_upstream_only_three_requested(self):
        locks=json.loads((ROOT/'upstream/UPSTREAM_LOCKS_2026-10-15.json').read_text())
        self.assertEqual({c['component'] for c in locks['components']},{'BaKaSU','SUSFS','NoMount'})
    def test_30_no_prior_project_kernel_code_referenced(self):
        text=(THIS/'stock_import.py').read_text()
        self.assertNotIn('P11_TO_P12_WALT',text)
        self.assertNotIn('VEUX_STOCK274_P11',text)
    def test_31_exact_two_known_symlinks(self):
        self.assertEqual(self.report['tar']['internal_symlinks'],2)
    def test_32_stock_version_not_just_5_4_274(self):
        self.assertEqual(self.report['tar']['kernel_release'],api.VERSION)
    def test_33_valid_existing_dir_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp)/'headers';p.mkdir()
            with self.assertRaisesRegex(api.EvidenceError,'REFUSE_OVERWRITE_EXISTING_HEADERS'):
                api.extract_tar_verified(self.tarbytes,p)
    def test_34_full_expanded_stage_one_header(self):
        with tempfile.TemporaryDirectory() as tmp:
            dst=pathlib.Path(tmp)/'stage'
            api.stage(ROOT,dst,expand_headers=True)
            p=dst/'stock-qgki'/api.VERSION
            self.assertTrue((p/'kheaders/include/generated/utsrelease.h').is_file())
            self.assertTrue((p/'kheaders/include/dt-bindings/input/linux-event-codes.h').is_symlink())
            self.assertFalse((p/'kheaders/Module.symvers').exists())
            self.assertFalse((p/'boot.img').exists())

if __name__=='__main__':unittest.main(verbosity=2)
