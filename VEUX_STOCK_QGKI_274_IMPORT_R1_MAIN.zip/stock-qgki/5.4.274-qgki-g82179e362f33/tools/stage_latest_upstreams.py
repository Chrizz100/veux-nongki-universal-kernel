#!/usr/bin/env python3
"""Optional source-only upstream acquisition for VEUX STOCK QGKI project.

Clones official upstream branches to immutable commit snapshots, archives selected
source directories, and writes a new SHA lock. It NEVER executes upstream code,
patches the kernel, creates a boot.img, or writes to the GitHub repository.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

SOURCES=(
 {'name':'BaKaSU','url':'https://github.com/Baka-SU/BakaSU.git','branch':'main',
  'subtrees':['kernel'], 'pin':'d7260ca1e5c128061122924d0d48754e361e135c'},
 {'name':'SUSFS-2.3-reference','url':'https://gitlab.com/simonpunk/susfs4ksu.git','branch':'gki-android12-5.10',
  'subtrees':['kernel_patches','ksu_patches'], 'pin':None},
 {'name':'NoMount','url':'https://github.com/maxsteeel/nomount.git','branch':'master',
  'subtrees':['kernel','module','userspace'], 'pin':'7046c7ad3ee0bf4ae66e80f6b93b1e30db0cb4e3'}
)
SHA40=re.compile(r'^[0-9a-f]{40}$')

class StageError(RuntimeError):pass


def run_git(*args, cwd=None, timeout=120):
    try:
        p=subprocess.run(['git',*args],cwd=cwd,timeout=timeout,check=False,
                         stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    except (subprocess.TimeoutExpired,OSError) as e:
        raise StageError('GIT_COMMAND_FAILED '+str(e)) from e
    if p.returncode:
        raise StageError('GIT_COMMAND_FAILED '+ ' '.join(args[:3])+'; '+p.stderr[-500:])
    return p.stdout.strip()


def parse_ls_remote(data: str, branch: str):
    expected='refs/heads/'+branch
    rows=[line.split('\t',1) for line in data.splitlines() if '\t' in line]
    found=[oid for oid,ref in rows if ref==expected]
    if len(found)!=1 or not SHA40.fullmatch(found[0]):
        raise StageError('UPSTREAM_HEAD_NOT_VERIFIABLE '+branch)
    return found[0]


def verify_sources(sources):
    if len(sources)!=3 or {x['name'] for x in sources}!={'BaKaSU','SUSFS-2.3-reference','NoMount'}:
        raise StageError('UNEXPECTED_UPSTREAM_SOURCES')
    for src in sources:
        if not src['url'].startswith(('https://github.com/','https://gitlab.com/')):
            raise StageError('UNTRUSTED_SOURCE_URL')
        if not re.fullmatch(r'[A-Za-z0-9_.-]+',src['branch']):raise StageError('INVALID_BRANCH')
        if src['pin'] and not SHA40.fullmatch(src['pin']):raise StageError('INVALID_PIN')
        if not src['subtrees'] or any('/' in s or s.startswith('.') for s in src['subtrees']):
            raise StageError('INVALID_ARCHIVE_SUBTREE')
    return True


def stage_upstream_source(src, output: Path):
    branch=src['branch']
    advertised=run_git('ls-remote','--exit-code',src['url'],'refs/heads/'+branch,timeout=70)
    remote_head=parse_ls_remote(advertised,branch)
    with tempfile.TemporaryDirectory(prefix='qgki-upstream-') as tmp:
        clone=Path(tmp)/'repo'
        run_git('clone','--quiet','--depth=1','--single-branch','--branch',branch,
                '--',src['url'],str(clone),timeout=240)
        local_head=run_git('rev-parse','HEAD',cwd=clone)
        if local_head != remote_head or not SHA40.fullmatch(local_head):
            raise StageError('SOURCE_MOVED_BETWEEN_RESOLVE_AND_DOWNLOAD '+src['name'])
        for subdir in src['subtrees']:
            if not (clone/subdir).is_dir():raise StageError('UPSTREAM_PATH_MISSING '+src['name']+'/'+subdir)
        if src['name']=='BaKaSU':
            config=(clone/'kernel/Kconfig').read_text(errors='replace')
            if 'config KSU_MANUAL_HOOK' not in config:
                raise StageError('BAKASU_KERNEL_5_4_HOOK_MISSING')
        elif src['name']=='NoMount':
            header=(clone/'kernel/src/nomount.h').read_text(errors='replace')
            if not re.search(r'#define\s+NOMOUNT_BASE_VERSION\s+"21"',header):
                raise StageError('NOMOUNT_VERSION_BRANCH_CHANGED_REVIEW')
        elif src['name']=='SUSFS-2.3-reference':
            # Do not claim this modern 5.10 branch is a drop-in Linux 5.4 backport.
            versions=[]
            for h in (clone/'kernel_patches').rglob('susfs.h'):
                s=h.read_text(errors='replace')
                versions+=re.findall(r'#define\s+SUSFS_VERSION\s+"([^"]+)"',s)
            if '2.3.0' not in versions:
                raise StageError('SUSFS_2_3_VERSION_NOT_PROVEN: '+repr(versions))
        name=src['name'].lower().replace('-','_')
        outfile=output/(name+'_source_snapshot.tar.gz')
        run_git('archive','--format=tar.gz','-o',str(outfile),'HEAD',*src['subtrees'],cwd=clone,timeout=120)
        if not outfile.is_file() or outfile.stat().st_size<1000:raise StageError('EMPTY_UPSTREAM_SNAPSHOT '+src['name'])
        checksum=hashlib.sha256(outfile.read_bytes()).hexdigest()
    return {'name':src['name'],'repository':src['url'],'branch':branch,
            'upstream_commit_resolved_at_run':remote_head,
            'was_previously_pinned_to_latest':remote_head==src['pin'] if src['pin'] else None,
            'previous_as_of_2026_10_15_pin':src['pin'],
            'source_archive':outfile.name,'archive_sha256':checksum,
            'verified_as_linux_5_4_backport':False,
            'source_tree_compile':'NOT_RUN','stock_binary_modified':False}


def stage(output:Path, sources=SOURCES):
    verify_sources(sources)
    if output.exists() and any(output.iterdir()):raise StageError('NONEMPTY_UPSTREAM_OUTPUT')
    output.mkdir(parents=True,exist_ok=True)
    staged=[]
    try:
        for item in sources:staged.append(stage_upstream_source(item,output))
    except Exception:
        for p in output.glob('*_source_snapshot.tar.gz'):p.unlink()
        raise
    report={'purpose':'latest_source_snapshots_ONLY','time_utc':datetime.now(timezone.utc).isoformat(),
            'kernel_version_target':'5.4.274-qgki-g82179e362f33',
            'upstreams':staged,'BakaSU_SUSFS_NoMount_in_stock_kernel':'NOT_INTEGRATED',
            'stock_kernel_build':'NOT_RUN','flash_permission':False}
    (output/'SOURCE_SNAPSHOTS.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
    return report


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output-dir',required=True)
    args=ap.parse_args()
    report=stage(Path(args.output_dir).resolve())
    print(json.dumps(report,indent=2))
    print('UPSTREAM_SNAPSHOTS_READY=PASS; STOCK_KERNEL_INTEGRATION=NOT_STARTED')

if __name__=='__main__':
    try:main()
    except (StageError,OSError,ValueError) as e:
        print('UPSTREAM_SOURCE_STAGE_FAIL_CLOSED: '+str(e),file=sys.stderr)
        sys.exit(2)
